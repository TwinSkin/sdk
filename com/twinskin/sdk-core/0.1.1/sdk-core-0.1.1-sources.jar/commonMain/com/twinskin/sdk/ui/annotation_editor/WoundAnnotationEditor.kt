@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class, kotlinx.coroutines.FlowPreview::class)

package com.twinskin.sdk.ui.annotation_editor

import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.WoundAnnotation
import com.twinskin.sdk.error
import com.twinskin.sdk.ui.annotation_editor.delineation.DelineationStore
import com.twinskin.sdk.ui.annotation_editor.delineation.Step
import com.twinskin.sdk.ui.annotation_editor.delineation.boundary.toWoundAnnotation
import com.twinskin.sdk.ui.annotation_editor.delineation.dashboard.AutoFillDialog
import com.twinskin.sdk.ui.annotation_editor.delineation.dashboard.autoFillAllWounds
import com.twinskin.sdk.ui.annotation_editor.delineation.dashboard.percentagesByType
import com.twinskin.sdk.ui.annotation_editor.delineation.dashboard.remainingFillableArea
import com.twinskin.sdk.ui.annotation_editor.delineation.draft.DraftStore
import com.twinskin.sdk.ui.annotation_editor.delineation.draft.EditorPreferences
import com.twinskin.sdk.ui.annotation_editor.delineation.draft.SettingsBackedEditorPreferences
import com.twinskin.sdk.ui.annotation_editor.polygon.draft.contentHash
import com.twinskin.sdk.ui.annotation_editor.delineation.draft.provideDraftSettings
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.ErrorScreen
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.IntroScreen
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.TissueCardAction
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.TissueDashboardScreen
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.TissueDrawingScreen
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.WoundDrawingScreen
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.resolveLocale
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.stringsFor
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.delineation.stepSaver
import com.twinskin.sdk.ui.annotation_editor.polygon.orientation.LockOrientationDuringSession
import com.twinskin.sdk.ui.annotation_editor.polygon.system.DeferSystemGesturesDuringSession
import com.twinskin.sdk.ui.theme.TwinSkinTheme
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch

/**
 * Public entry point for the wound delineation editor (spec §5–§9).
 *
 * Owns the full four-screen flow (Intro → Wound contour →
 * Tissue dashboard → per-type Tissue drawing → submit) internally;
 * the integrator's only contract is to provide the image and a
 * suspending `onDone` callback that receives the validated
 * [WoundAnnotation] wire payload (decision S).
 *
 * **Lifecycle.**
 *  - Configuration changes preserve the current [Step] via
 *    `rememberSaveable(stateSaver = stepSaver)` and the canvas
 *    content via each screen's
 *    `rememberSaveable(saver = EditorControllerSaver)`. Undo stacks
 *    are intentionally not persisted — the disk-backed draft is the
 *    real safety net for process death.
 *  - Process death + warm reopen flow through [DraftStore]:
 *    auto-saved every 500 ms while editing, surfaced on the Intro
 *    screen's "Resume previous session?" banner.
 *  - Orientation is locked to whatever the device started in for the
 *    session's duration (spec §13.5).
 *  - Uncaught exceptions from gesture loops, the auto-save coroutine,
 *    or the suspending `onDone` flush the draft and surface
 *    [ErrorScreen] (spec C1).
 *
 * @param image    The source image. Must have positive dimensions
 *                 (spec C2). Re-keying [image] resets the editor's
 *                 internal state (the image-hash-based draft slot
 *                 changes too — the new image's draft, if any, is
 *                 offered on the Intro screen).
 * @param onDone   Invoked when the clinician validates the
 *                 annotation. Suspending per decision S so the
 *                 editor can drive the submission UI (in-flight
 *                 spinner, retry snackbar on failure) before the
 *                 caller's coroutine returns. On success the
 *                 draft is cleared automatically.
 * @param onCancel Invoked when the clinician abandons the session
 *                 (back from Intro / abandon-confirmed from
 *                 WoundDrawingScreen) OR when the [ErrorScreen]'s
 *                 dismiss button is tapped. The draft survives a
 *                 cancel — the user can reopen the editor on the
 *                 same image and resume.
 * @param initial  Optional pre-seeded [WoundAnnotation] (re-edit
 *                 flow). Defaults to an empty annotation.
 */
@TwinSkinInternalApi
@Composable
public fun WoundAnnotationEditor(
    image: ImageBitmap,
    onDone: suspend (WoundAnnotation) -> Unit,
    onCancel: () -> Unit,
    initial: WoundAnnotation = WoundAnnotation(regions = emptyList()),
) {
    require(image.width > 0 && image.height > 0) {
        "image must have positive dimensions (got ${image.width} × ${image.height})"
    }

    LockOrientationDuringSession()
    DeferSystemGesturesDuringSession()

    val strings = remember { stringsFor(resolveLocale()) }
    val imageSize = remember(image) { Size(image.width.toFloat(), image.height.toFloat()) }
    val minTissueArea = remember(imageSize) {
        // Decision N — sliver floor that scales with image size so a
        // 10 MP photo doesn't accept the same fixed-area pieces as a
        // 1 MP one.
        maxOf(24f, imageSize.width * imageSize.height * 5e-5f)
    }
    // Fresh vs edit-existing mode detection. Computed early so it
    // can gate the draft-persistence effects below.
    val isEditExisting = initial.regions.isNotEmpty()

    // The draft store + editor preferences share one Settings
    // instance: drafts and the reshape-advisory flag live under the
    // SDK's dedicated `twinskin_delineation_drafts` namespace
    // (see provideDraftSettings KDoc).
    val settings = remember { provideDraftSettings() }
    val draftStore = remember(settings) { DraftStore(settings) }
    val editorPreferences: EditorPreferences =
        remember(settings) { SettingsBackedEditorPreferences(settings) }
    val imageHash = remember(image) { image.contentHash() }
    val existingDraft = remember(imageHash, isEditExisting, initial) {
        // Fresh mode never reads drafts — no Resume banner can appear in that
        // flow. Keyed on `initial` as well as `imageHash` so re-entering the
        // editor on the SAME image but with NEW seed data (e.g. the server
        // delivered an updated annotation) reloads the draft from disk instead
        // of returning the previous composition's stale cached draft — the bug
        // where Resume restored the wrong data until the user left and came
        // back (which forced a fresh composition + reload).
        if (isEditExisting) draftStore.load(imageHash) else null
    }
    val store = remember(initial, imageSize) {
        DelineationStore.fromInitial(initial, imageSize)
    }
    val logger: SdkLogger? = remember {
        runCatching { TwinSkinSdk.requireComponent().logger }.getOrNull()
    }

    var fatalError by remember { mutableStateOf<Throwable?>(null) }
    // Key the saver on imageHash so a different image (different
    // patient, different capture) doesn't inherit the previous
    // session's saved step. Without the key, a configuration-change
    // restore on a fresh image could resurrect a stale step from a
    // prior session in the same composition slot (M15.8).
    var step: Step by rememberSaveable(imageHash, stateSaver = stepSaver) {
        mutableStateOf<Step>(Step.Intro)
    }

    val exceptionHandler: CoroutineExceptionHandler =
        remember(draftStore, imageHash, isEditExisting) {
            CoroutineExceptionHandler { _, t ->
                if (isEditExisting) {
                    runCatching { draftStore.saveOrClear(imageHash, store.snapshot(), step) }
                }
                fatalError = t
            }
        }
    val scope = rememberCoroutineScope { exceptionHandler }

    var submitting by remember { mutableStateOf(false) }
    val dashboardSnackbar = remember { SnackbarHostState() }
    // Set when the dashboard's Add / MarkPresent action lands on the
    // last unresolved tissue type AND there's enough fillable area
    // to make the auto-fill shortcut meaningful — see
    // [shouldOfferAutoFill]. Null otherwise; the dialog is suppressed.
    var autoFillPrompt by remember { mutableStateOf<TissueType?>(null) }

    // M15.12 — flips to true the moment the integrator's onDone
    // callback returns successfully. The dispose-time auto-save
    // below skips when this is set, so a clean Validate doesn't
    // re-create the draft slot the validation path just cleared.
    var validatedSuccessfully by remember { mutableStateOf(false) }

    // Draft persistence is edit-existing-only. Fresh sessions never
    // write a draft to disk; re-entering fresh mode never surfaces a
    // Resume banner. The else-branch below wipes any stale draft a
    // prior edit-existing session left for the same image.
    if (isEditExisting) {
        // Auto-save on store mutation, debounced 500 ms so a per-move
        // stroke storm doesn't hammer the disk. Empty snapshots
        // (post Start Fresh, post wholesale deletion) clear the slot
        // instead of persisting an empty draft — see M15.12.
        //
        // `drop(1)` skips snapshotFlow's mount-time emission of the
        // initial revision (always 0 on a freshly-constructed store).
        // Without it, a pristine entry where the user merely opens
        // the editor would trip the auto-save 500 ms later and
        // persist the unmutated initial regions as a "draft" —
        // surfacing as a phantom Resume banner on the next entry
        // (M15.13).
        LaunchedEffect(store) {
            snapshotFlow { store.revision.value }
                .drop(1)
                .debounce(500)
                .collect { draftStore.saveOrClear(imageHash, store.snapshot(), step) }
        }
        // Flush on dispose — closes the 500 ms debounce window if the
        // user backgrounds the app mid-debounce (spec C1). Suppressed
        // after a successful Validate so we don't re-create the
        // draft slot the Validate flow just cleared (M15.12), and
        // suppressed when the user hasn't mutated the store at all
        // (revision still 0) so a pristine open-then-close leaves
        // no trace on disk (M15.13).
        DisposableEffect(Unit) {
            onDispose {
                if (!validatedSuccessfully && store.revision.value > 0) {
                    runCatching {
                        draftStore.saveOrClear(imageHash, store.snapshot(), step)
                    }
                }
            }
        }
    } else {
        // Fresh-mode entry wipes any stale draft a prior
        // edit-existing session left for the same image.
        LaunchedEffect(imageHash) {
            draftStore.clear(imageHash)
        }
    }

    val percentages by remember(store) {
        derivedStateOf { percentagesByType(store.wounds) }
    }

    val error = fatalError
    if (error != null) {
        TwinSkinTheme {
            ErrorScreen(error = error, strings = strings, onDismiss = onCancel)
        }
        return
    }

    // Fresh vs edit-existing CTA label.
    val introStartLabel =
        if (isEditExisting) strings.startDrawingButton else strings.continueButton

    TwinSkinTheme {
    when (val current = step) {
        Step.Intro -> IntroScreen(
            // M15.17 — the Resume banner surfaces whenever there's
            // anything to resume, whether that's an interrupted
            // session's draft OR the capture's already-saved
            // annotation. Previously the banner was gated on
            // `existingDraft != null` only, so re-opening a capture
            // with a saved contour but no draft showed a single
            // "Start drawing" CTA — which wired to onStart and
            // (per M15.7) wiped the imported regions the user
            // intended to edit. Treating every edit-existing entry
            // as resume-eligible lets the user explicitly choose
            // between "continue editing" (loads existing state, no
            // wipe) and "start fresh" (wipes everything).
            hasExistingState = isEditExisting,
            strings = strings,
            startActionLabel = introStartLabel,
            onResume = {
                val draft = existingDraft
                if (draft != null) {
                    // Interrupted session — restore the on-disk draft.
                    store.restore(draft.snapshot)
                } else {
                    // No draft, just the imported regions — the
                    // store is already hydrated from `initial` by
                    // `fromInitial` above, so resume is a pure
                    // navigation.
                }
                // M15.8 — always land on Wound after Resume. The
                // pre-M15.8 inferResumeStep heuristic could send the
                // user to Dashboard when every tissue card was
                // already resolved, contradicting the user's
                // expectation that Resume always returns to the
                // drawing canvas.
                step = Step.Wound
            },
            onStart = {
                draftStore.clear(imageHash)
                // M15.7 — wipe imported regions too. The pre-M15.7
                // behaviour cleared only the draft and left the
                // edit-existing seed visible; the user expects an
                // empty canvas when they tap Start fresh.
                store.clear()
                step = Step.Wound
            },
            onCancel = onCancel,
        )
        Step.Wound -> WoundDrawingScreen(
            image = image,
            imageSize = imageSize,
            store = store,
            minTissueArea = minTissueArea,
            strings = strings,
            editorPreferences = editorPreferences,
            onBack = onCancel,
            onNext = { step = Step.Dashboard },
        )
        Step.Dashboard -> {
            TissueDashboardScreen(
                cardStates = store.cardStates,
            percentages = percentages,
            isSubmitting = submitting,
            snackbarHostState = dashboardSnackbar,
            strings = strings,
            onBack = { step = Step.Wound },
            onValidate = {
                scope.launch {
                    while (true) {
                        submitting = true
                        val annotation = toWoundAnnotation(store.wounds, imageSize, logger)
                        // M15.12 — clear the draft BEFORE invoking
                        // onDone. The integrator's callback typically
                        // closes the editor (unmounting this composable
                        // and cancelling `scope`); a clear placed
                        // AFTER onDone would never run on the happy
                        // path, leaving the just-validated state on
                        // disk for the next mount to surface as a
                        // phantom Resume banner.
                        runCatching { draftStore.clear(imageHash) }
                        val result = runCatching { onDone(annotation) }
                        submitting = false
                        if (result.isSuccess) {
                            // Suppress the DisposableEffect's
                            // dispose-time auto-save so the just-cleared
                            // slot stays clear when the editor unmounts.
                            validatedSuccessfully = true
                            return@launch
                        }
                        // Retry path — re-save the draft so the user
                        // doesn't lose work mid-retry. We're still in
                        // the foreground, the editor will keep running,
                        // and the user will either tap Retry (looping
                        // back to the top) or dismiss the snackbar (in
                        // which case the dispose-time auto-save will
                        // keep what we just saved).
                        runCatching {
                            draftStore.saveOrClear(imageHash, store.snapshot(), step)
                        }
                        logger?.error("Delineation save failed", result.exceptionOrNull())
                        val outcome = dashboardSnackbar.showSnackbar(
                            message = strings.saveFailedSnackbar,
                            actionLabel = strings.retryAction,
                            duration = SnackbarDuration.Indefinite,
                        )
                        if (outcome != SnackbarResult.ActionPerformed) return@launch
                    }
                }
            },
            onCardAction = { type, action ->
                when (action) {
                    TissueCardAction.Add -> {
                        if (shouldOfferAutoFill(type, store, minTissueArea)) {
                            autoFillPrompt = type
                        } else {
                            step = Step.TissueDrawing(type)
                        }
                    }
                    TissueCardAction.Edit ->
                        step = Step.TissueDrawing(type)
                    TissueCardAction.MarkAbsent -> {
                        // Marking a type absent must also discard any already-
                        // drawn regions of that type, so the untyped remainder
                        // and the tissue-drawing canvas reflect the removal.
                        store.removeTissuesOfType(type)
                        store.setCardState(type, TissueCardState.Absent)
                    }
                    TissueCardAction.MarkPresent -> {
                        if (shouldOfferAutoFill(type, store, minTissueArea)) {
                            autoFillPrompt = type
                        } else {
                            store.setCardState(type, TissueCardState.Open)
                            step = Step.TissueDrawing(type)
                        }
                    }
                }
            },
            )
            val promptType = autoFillPrompt
            if (promptType != null) {
                val typeName = strings.tissueTypeNames[promptType] ?: promptType.wire
                AutoFillDialog(
                    title = strings.autoFillDialogTitle,
                    body = strings.autoFillDialogBody(typeName),
                    confirmLabel = strings.autoFillConfirmButton,
                    declineLabel = strings.autoFillDeclineButton,
                    onConfirm = {
                        autoFillPrompt = null
                        // Iterate across every wound until the untyped
                        // remainder is within tolerance — a single pass can
                        // miss some wounds when the boolean-difference backend
                        // yields slivers (M: 5 wounds → only 3 filled).
                        val filled = autoFillAllWounds(
                            wounds = store.wounds.toList(),
                            type = promptType,
                            minTissueArea = minTissueArea,
                        )
                        filled.forEachIndexed { i, w ->
                            if (w !== store.wounds[i]) store.replaceWound(i, w)
                        }
                        store.setCardState(promptType, TissueCardState.Drawn)
                    },
                    onDecline = {
                        autoFillPrompt = null
                        // MarkPresent path was diverted before un-Absenting
                        // the card; flip it back to Open so the drawing
                        // screen treats the card as in-progress.
                        if (store.cardStates[promptType] == TissueCardState.Absent) {
                            store.setCardState(promptType, TissueCardState.Open)
                        }
                        step = Step.TissueDrawing(promptType)
                    },
                    onDismiss = {
                        // Accidental backdrop / system-back dismiss must
                        // NOT navigate the user into the drawing screen.
                        // The card stays as it was; re-tapping "Draw
                        // area" / "Edit" opens the dialog again.
                        autoFillPrompt = null
                    },
                )
            }
        }
        is Step.TissueDrawing -> TissueDrawingScreen(
            image = image,
            imageSize = imageSize,
            store = store,
            currentType = current.type,
            strings = strings,
            onBack = { step = Step.Dashboard },
        )
    }
    }
}

/**
 * True when the dashboard should offer the last-tissue auto-fill
 * shortcut for [type]:
 *   1. The other two known types are both resolved (Drawn or
 *      Absent) — i.e. [type] is the only one left unresolved.
 *   2. The remainder area (wounds minus existing tissues) is at
 *      least one [minTissueArea] worth — under that threshold the
 *      auto-fill would produce no tissue, leading to a confusing
 *      0% Drawn card.
 *
 * [type] itself is allowed to be in any state — the prompt is
 * offered both when the user taps "Draw area" on an Open card and
 * when they tap Edit on an Absent card (un-marking it).
 */
private fun shouldOfferAutoFill(
    type: TissueType,
    store: DelineationStore,
    minTissueArea: Float,
): Boolean {
    val othersResolved = TissueType.knownValues
        .filter { it != type }
        .all { other ->
            val s = store.cardStates[other]
            s == TissueCardState.Drawn || s == TissueCardState.Absent
        }
    if (!othersResolved) return false
    return remainingFillableArea(store.wounds) >= minTissueArea
}

