package com.twinskin.sdk.sdk_client

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.SdkCaptureStore
import com.twinskin.sdk.capture.iso8601ToEpochMillis
import com.twinskin.sdk.error
import com.twinskin.sdk.transfer.UrlResolver
import com.twinskin.sdk.transfer.UrlResult
import com.twinskin.sdk.warn

/**
 * Builds a [UrlResolver] that bridges the TransferManager's retry loop to
 * the server's idempotent `startCapture` endpoint.
 *
 * Each PUT attempt asks the resolver for a fresh URL; we look the capture
 * up in [SdkCaptureStore] (keyed on the capture id, which the SDK passes
 * in as the transfer `uploadKey`), re-call `startCapture`, and map the
 * response.
 *
 * Result mapping:
 * - `queued` + `upload_url` → [UrlResult.Url] — the SDK PUTs to it.
 * - past `queued` (upload_url is null) → [UrlResult.AlreadyExist] — the
 *   server has already accepted a bundle for this id, so uploading again
 *   would clobber processing in flight.
 *
 * Failure mapping:
 * - Default is to retry. Cancelling an upload is destructive (the user's
 *   bundle is gone), so we only terminate on statuses where we're certain
 *   retrying is futile: 400 (malformed request), 403 (scope mismatch),
 *   422 (validation). Everything else — including 401 (token may refresh),
 *   404 (server state may recover), 408/429 (transient), all 5xx, and
 *   transport errors — is retryable.
 * - missing store row → [UrlResult.AlreadyExist] — the row must be
 *   inserted before this resolver ever runs, so a null lookup means
 *   internal state is gone (e.g. user wiped data); no point retrying.
 */
private val terminalStatuses = setOf(400, 403, 422)

internal fun sdkCaptureUrlResolver(
    store: SdkCaptureStore,
    serverClient: SdkServerClient,
    logger: SdkLogger = SdkLogger.None,
): UrlResolver = resolver@{ uploadKey ->
    val record = store.findById(uploadKey)
        ?: return@resolver UrlResult.AlreadyExist

    val response = try {
        serverClient.startCapture(record.request)
    } catch (e: SdkServerException) {
        return@resolver if (e.statusCode in terminalStatuses) {
            logger.error("startCapture terminal HTTP ${e.statusCode} for $uploadKey — giving up", e)
            UrlResult.AlreadyExist
        } else {
            logger.warn("startCapture HTTP ${e.statusCode} for $uploadKey — will retry", e)
            UrlResult.RetryableError
        }
    } catch (e: Exception) {
        logger.warn("startCapture transport failure for $uploadKey — will retry", e)
        return@resolver UrlResult.RetryableError
    }

    when {
        response.status == SdkCaptureStatus.QUEUED && response.uploadUrl != null ->
            UrlResult.Url(
                url = response.uploadUrl,
                expiresAtEpochMs = response.uploadUrlExpiresAt?.let { iso8601ToEpochMillis(it) },
            )
        else -> UrlResult.AlreadyExist
    }
}
