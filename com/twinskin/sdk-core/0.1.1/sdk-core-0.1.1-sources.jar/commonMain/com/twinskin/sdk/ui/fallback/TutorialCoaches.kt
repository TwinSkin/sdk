package com.twinskin.sdk.ui.fallback

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/*
 * Animated coaches. commonMain owns the motion + perspective; the host supplies
 * bitmaps via [LocalCaptureCoachImages] (vector fallback when absent).
 *
 * LOW-END PERFORMANCE: the continuous motion is driven inside `graphicsLayer`
 * blocks and `Canvas` draw lambdas (layer / draw phase) that read the animation
 * State directly, NOT in the composable body. Recomposition then happens only a
 * couple of times per loop (when `level`/`far`/`done` flip), so the orbit keeps
 * moving smoothly on weak GPUs (e.g. Samsung XCover5).
 */

/** Foreshorten factor for the tilted floor / orbit track (about cos 58 degrees). */
private const val FY = 0.52f
private const val DEG = (PI / 180.0).toFloat()
private const val TWO_PI = (2.0 * PI).toFloat()

/**
 * Elapsed seconds after which the live level coach (`fade = true`) latches hidden
 * for the rest of the session — just past the end of the first fade-out window
 * (`[3.2, 5.7)` in the 6.2 s cycle), so the explanation plays exactly once.
 */
private const val LIVE_COACH_PLAY_ONCE_SEC = 5.7f

/** Image alignment that mimics the storyboard wound `object-position: center 26%`. */
private val WOUND_ALIGN = BiasAlignment(0f, -0.48f)

@Composable
private fun PainterFill(p: Painter?, scale: ContentScale, align: Alignment = Alignment.Center) {
    if (p != null) Image(p, contentDescription = null, modifier = Modifier.fillMaxSize(), alignment = align, contentScale = scale)
}

// ── Step 1 — level scene (used by tutorial page 1 AND the live ReadyForPhoto coach) ──

/** Tutorial page 1 — the level scene, no fade. */
@Composable
internal fun LevelCoach(modifier: Modifier = Modifier) = LevelScene(modifier, fade = false)

/**
 * Live ReadyForPhoto coach — the SAME level scene as tutorial page 1, plus a
 * periodic fade-out so the operator can capture with the full preview visible.
 */
@Composable
internal fun LiveLevelCoach(modifier: Modifier = Modifier) = LevelScene(modifier, fade = true)

/**
 * Step-1 level scene: a skin floor carries the wound + marker; the phone hovers
 * parallel above it, settling level. Perspective is fixed; geometry is responsive.
 */
@Composable
private fun LevelScene(modifier: Modifier, fade: Boolean) {
    val colors = LocalAccelerometerCaptureColors.current
    val img = LocalCaptureCoachImages.current
    val tState = rememberFrameSeconds()

    val level by remember { derivedStateOf { (tState.value % 5.6f) >= 2.4f } }
    // The live coach (`fade = true`) latches hidden after one play so it doesn't
    // re-fade while the operator captures; the on-demand tutorial never hides.
    val played by remember { derivedStateOf { fade && tState.value >= LIVE_COACH_PLAY_ONCE_SEC } }
    val hidden by remember {
        derivedStateOf { played || (fade && (tState.value % 6.2f) >= 3.2f && (tState.value % 6.2f) < 5.7f) }
    }
    val edge by animateColorAsState(if (level) colors.progressComplete else Color(0xFF8FA0A3), label = "edge")
    val bubbleColor by animateColorAsState(if (level) colors.progressComplete else colors.warning, label = "bub")
    val sceneAlpha by animateFloatAsState(if (hidden) 0f else 1f, tween(550), label = "fade")
    val chip by remember {
        derivedStateOf {
            when {
                hidden -> "Then tap to capture" /* video_capture_coach_tap_to_capture */
                level -> "Level — ready to capture" /* video_capture_coach_level_ready */
                else -> "Hold flat & parallel" /* video_capture_coach_hold_flat */
            }
        }
    }

    BoxWithConstraints(modifier = modifier.graphicsLayer { alpha = sceneAlpha }) {
        val W = maxWidth
        val H = maxHeight
        // Height-driven so the scene + the phone-to-floor distance cue stay
        // proportionate inside a BOUNDED area (no stretch on short screens, no
        // balloon on tablets), clamped by width.
        val phoneH = (H * 0.42f).coerceIn(96.dp, 240.dp)
        val phoneW = (phoneH * 0.60f).coerceAtMost(W * 0.44f)
        // Grow the floor plane on the live coach (`fade = true`) — the image is
        // `Fit` and height-bound, so a taller box = a larger wound. The on-demand
        // tutorial keeps its size so it doesn't collide with the bobbing phone.
        val floorScale = if (fade) 1.5f else 1f
        val floorH = (H * 0.26f * floorScale).coerceAtLeast(48.dp)
        val floorW = (floorH * 1.55f).coerceAtMost(W * 0.96f)
        val distFont = (minOf(W, H).value * 0.045f).coerceIn(10f, 13f)

        // ── floor (tilted plane) ──
        Box(modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = H * 0.10f).size(floorW, floorH)) {
            if (img.woundMarker != null) {
                // Keep the phone-matched perspective tilt (`rotationX = 44f`) but
                // `Fit` so the whole wound stays visible, and mask to an oval so
                // the letterbox's hard bottom edge isn't a stray gray line below
                // the coach (matches the vector-fallback elliptical floor).
                Box(modifier = Modifier.fillMaxSize().clip(CircleShape).graphicsLayer { rotationX = 44f; cameraDistance = 16f * density }) {
                    PainterFill(img.woundMarker, ContentScale.Fit, WOUND_ALIGN)
                }
            } else {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width; val h = size.height; val cx = w / 2f; val cy = h * 0.5f
                    drawOval(Brush.radialGradient(listOf(Color(0xFFCBA587), Color(0xFF7E5F47)), Offset(cx, cy), w * 0.6f),
                        topLeft = Offset(w * 0.04f, h * 0.10f), size = Size(w * 0.92f, h * 0.80f))
                    val ww = w * 0.34f; val wh = ww * FY
                    drawOval(Brush.radialGradient(listOf(Color(0xFF7A2E22), Color(0xFF3A1714)), Offset(cx, cy), ww * 0.6f),
                        topLeft = Offset(cx - ww / 2f, cy - wh / 2f), size = Size(ww, wh))
                    val mk = w * 0.12f
                    drawRoundRect(Color.White, topLeft = Offset(cx + ww * 0.55f, cy - mk * FY / 2f),
                        size = Size(mk, mk * FY), cornerRadius = CornerRadius(mk * 0.15f, mk * 0.15f))
                }
            }
            // Reads tState in the draw phase so it animates without recomposition.
            Canvas(modifier = Modifier.fillMaxSize()) {
                val t = tState.value
                val mp = sin(t * (TWO_PI / 1.7f)) * 0.5f + 0.5f
                val hover = sin(t * 1.5f) * 0.5f + 0.5f
                val w = size.width; val h = size.height; val cx = w / 2f; val cy = h * 0.5f
                val shW = w * 0.30f * (0.85f + hover * 0.2f)
                drawOval(Color.Black.copy(alpha = 0.28f - hover * 0.1f),
                    topLeft = Offset(cx - shW / 2f, cy - shW * FY * 0.5f), size = Size(shW, shW * FY))
                val aw = w * (0.30f + mp * 0.06f)
                drawOval(colors.orbit, topLeft = Offset(cx - aw / 2f, cy - aw * FY / 2f), size = Size(aw, aw * FY),
                    alpha = 0.45f + mp * 0.5f,
                    style = Stroke(width = w * 0.008f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(w * 0.02f, w * 0.02f))))
            }
        }

        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            val gx = w * 0.80f; val top = h * 0.46f; val bot = h * 0.62f; val ah = h * 0.012f
            drawLine(colors.orbit, Offset(gx, top), Offset(gx, bot), strokeWidth = w * 0.006f)
            drawPath(Path().apply { moveTo(gx - ah, top + ah * 1.4f); lineTo(gx, top); lineTo(gx + ah, top + ah * 1.4f) },
                colors.orbit, style = Stroke(width = w * 0.006f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(Path().apply { moveTo(gx - ah, bot - ah * 1.4f); lineTo(gx, bot); lineTo(gx + ah, bot - ah * 1.4f) },
                colors.orbit, style = Stroke(width = w * 0.006f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        Text("20–30 cm", /* video_capture_coach_distance */ color = colors.orbit, fontSize = distFont.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = W * 0.02f, bottom = H * 0.22f))

        // Phone motion runs in graphicsLayer (layer phase), not the composable body.
        PhoneBody(
            modifier = Modifier
                .align(Alignment.TopCenter).padding(top = H * 0.04f)
                .graphicsLayer {
                    val t = tState.value
                    val p = t % 5.6f
                    val k = if (p < 2.4f) 1f - p / 2.4f else 0f
                    translationY = (-4f * sin(t * 1.5f)) * density
                    rotationX = 44f + (if (p < 2.4f) 14f * k * sin(p * 5.0f) else 0f)
                    rotationZ = if (p < 2.4f) 9f * k * cos(p * 3.6f) else 0f
                    cameraDistance = 16f * density
                }
                .size(width = phoneW, height = phoneH),
            border = edge,
            cornerRadius = phoneW * 0.16f,
            screen = {
                PainterFill(img.woundMarker, ContentScale.Crop)
                BubbleLevel(box = phoneW * 0.42f, dot = phoneW * 0.14f, tState = tState,
                    ringColor = colors.orbit, dotColor = bubbleColor)
            },
        )

        HintChip(text = chip, accent = if (level) colors.progressComplete else Color.White,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = H * 0.004f))
    }
}

// ── Step 2 / live orbit coaches ──────────────────────────────────────────────

/** Tutorial page 2 — full orbit with centre wound + completion. Fills its area. */
@Composable
internal fun OrbitCoach(modifier: Modifier = Modifier.fillMaxSize()) = OrbitScene(modifier, showCentreWound = true)

/**
 * PhotoTaken / live — ghost phone orbits over the live feed; no centre wound.
 * When [capturedStill] is supplied it paints the orbit phone's screen so the
 * recording guide previews the actual shot; null falls back to the bundled coach.
 */
@Composable
internal fun PreviewOrbitCoach(
    modifier: Modifier = Modifier.size(200.dp),
    capturedStill: Painter? = null,
) = OrbitScene(modifier, showCentreWound = false, capturedStill = capturedStill)

@Composable
private fun OrbitScene(modifier: Modifier, showCentreWound: Boolean, capturedStill: Painter? = null) {
    val colors = LocalAccelerometerCaptureColors.current
    val img = LocalCaptureCoachImages.current
    // Prefer the just-captured still, then the bundled live coach, then the marker.
    val phoneScreen = capturedStill ?: img.woundLive ?: img.woundMarker
    // The continuous frame ticker, not Animatable/tween — tween frame requests
    // stall on low-end GPUs (XCover5), the withFrameMillis vsync loop does not.
    val tState = rememberFrameSeconds()
    val period = if (showCentreWound) 9.9f else 8.5f

    // Recompose only when far/near or done flip (a few times per loop), not per frame.
    val far by remember { derivedStateOf { cos(orbitAngle(tState.value, period) * DEG) > 0f } }
    val done by remember { derivedStateOf { showCentreWound && (tState.value % period) >= 8.5f } }

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val box = minOf(maxWidth, maxHeight) * 0.96f
        // Ring geometry (track radius + dots) is kept at 0.39 on both modes while
        // only the phone grows, so enlarging the preview phone doesn't shrink the
        // sector-dot circle. The bigger phone overlapping the dots is acceptable.
        val phoneScale = if (showCentreWound) 1f else 2.0f
        val ringR = 0.39f
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(modifier = Modifier.size(box), contentAlignment = Alignment.Center) {
                // Flat circular track, no foreshortening — the orbit is a circle.
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val t = tState.value
                    val isDone = showCentreWound && (t % period) >= 8.5f
                    val a = orbitAngle(t, period)
                    val lit = if (isDone) 8 else (floor(a / 45f).toInt() + 1).coerceIn(0, 8)
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val r = size.minDimension * ringR
                    drawCircle(if (showCentreWound) colors.outline.copy(alpha = 0.45f) else Color(0x4DFFFFFF),
                        radius = r, center = c,
                        style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(2f, 6f))))
                    for (i in 0 until 8) {
                        val dr = DialMath.sectorCenterDeg(i) * DEG
                        val pt = Offset(c.x + r * sin(dr), c.y - r * cos(dr))
                        val on = i < lit
                        val col = when { isDone -> colors.progressComplete; on -> colors.orbit; else -> colors.orbitInactive }
                        if (on || isDone) drawCircle(col, size.minDimension * 0.026f, pt)
                        else drawCircle(col, size.minDimension * 0.026f, pt, style = Stroke(width = 2f))
                    }
                }
                // z-order: far phone → wound → near phone
                if (far) OrbitGhostPhone(box, { orbitAngle(tState.value, period) }, phoneScreen, phoneScale, ringR)
                if (showCentreWound) CentreWound(box * 0.46f, done, img.woundMarker, colors)
                if (!far) OrbitGhostPhone(box, { orbitAngle(tState.value, period) }, phoneScreen, phoneScale, ringR)
            }
            HintChip(
                text = if (done) "All 8 captured" /* video_capture_coach_all_captured */
                else "Move around the lesion" /* video_capture_coach_move_around */,
                accent = if (done) colors.progressComplete else Color.White,
            )
        }
    }
}

/** Orbit azimuth (deg) from elapsed seconds: 8.5 s/rev, then holds at 360 during the done window. */
private fun orbitAngle(t: Float, period: Float): Float {
    val cyc = t % period
    return if (cyc < 8.5f) (cyc / 8.5f) * 360f else 360f
}

@Composable
private fun BoxScope.OrbitGhostPhone(
    box: Dp,
    angle: () -> Float,
    screenImg: Painter?,
    scale: Float = 1f,
    orbitR: Float = 0.39f,
) {
    PhoneBody(
        modifier = Modifier
            .graphicsLayer {
                val rad = angle() * DEG
                val rPx = (box * orbitR).toPx()
                // FLAT circle path (no FY); 3D is conveyed by the per-azimuth lean only.
                translationX = rPx * sin(rad)
                translationY = -rPx * cos(rad)
                rotationX = 30f * cos(rad)
                rotationY = 30f * sin(rad)
                cameraDistance = 14f * density
            }
            .size(width = box * 0.20f * scale, height = box * 0.37f * scale),
        border = Color(0x8AFFFFFF),
        cornerRadius = box * 0.05f * scale,
        screen = { PainterFill(screenImg, ContentScale.Crop, WOUND_ALIGN) },
    )
}

@Composable
private fun BoxScope.CentreWound(diam: Dp, done: Boolean, img: Painter?, colors: AccelerometerCaptureColors) {
    Box(
        modifier = Modifier.align(Alignment.Center).size(diam).clip(CircleShape)
            .then(if (done) Modifier.border(2.5.dp, colors.progressComplete, CircleShape) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        if (img != null) PainterFill(img, ContentScale.Crop, WOUND_ALIGN)
        else Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF7A2E22), Color(0xFF34130F)))))
        if (done) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val c = Offset(size.width / 2f, size.height / 2f); val u = size.minDimension
                drawPath(Path().apply {
                    moveTo(c.x - u * 0.16f, c.y); lineTo(c.x - u * 0.04f, c.y + u * 0.13f); lineTo(c.x + u * 0.18f, c.y - u * 0.12f)
                }, colors.progressComplete, style = Stroke(width = u * 0.07f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

// ── shared pieces ────────────────────────────────────────────────────────────

/** Bubble level whose dot drifts (in the layer phase) and re-centres when level. */
@Composable
private fun BubbleLevel(box: Dp, dot: Dp, tState: State<Float>, ringColor: Color, dotColor: Color) {
    Box(modifier = Modifier.size(box).border(2.dp, Color(0x66FFFFFF), CircleShape), contentAlignment = Alignment.Center) {
        Box(modifier = Modifier.size(box * 0.42f).border(1.5.dp, ringColor.copy(alpha = 0.7f), CircleShape))
        Box(
            modifier = Modifier
                .graphicsLayer {
                    val p = tState.value % 5.6f
                    val k = if (p < 2.4f) 1f - p / 2.4f else 0f
                    translationX = (if (p < 2.4f) 9f * k * cos(p * 3.6f) else 0f) * 0.5f * density
                    translationY = (if (p < 2.4f) -14f * k * sin(p * 5.0f) else 0f) * 0.5f * density
                }
                .size(dot).background(dotColor, CircleShape),
        )
    }
}

/**
 * Stylised phone body — dark slab, coloured [border], notch/island + rear lens, and
 * a dim screen hosting [screen] (host preview image, or a vector fallback).
 */
@Composable
private fun PhoneBody(
    modifier: Modifier,
    border: Color,
    cornerRadius: Dp = 22.dp,
    screen: @Composable () -> Unit = {},
) {
    Box(
        modifier = modifier
            .background(Color(0xFF05080A), RoundedCornerShape(cornerRadius))
            .border(2.dp, border, RoundedCornerShape(cornerRadius))
            .padding(5.dp),
    ) {
        Box(
            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape((cornerRadius - 4.dp).coerceAtLeast(2.dp)))
                .background(Color(0xFF0B1113)),
            contentAlignment = Alignment.Center,
        ) { screen() }
        // The island + rear camera share ONE physical end of a device — the end
        // pointing down at the wound, which here is the edge nearest the floor —
        // so both must sit at the bottom.
        Box(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp)
                .size(width = 20.dp, height = 4.dp).background(Color.Black, RoundedCornerShape(3.dp)),
        )
        Box(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp)
                .size(6.dp).background(Color(0xFF0A0D0F), CircleShape)
                .border(1.5.dp, Color(0xCC48CAE4), CircleShape),
        )
    }
}

@Composable
private fun HintChip(text: String, accent: Color, modifier: Modifier = Modifier) {
    Text(
        text = text, color = accent, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold,
        modifier = modifier
            .background(Color(0xBC081215), RoundedCornerShape(999.dp))
            .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(999.dp))
            .padding(horizontal = 12.dp, vertical = 5.dp),
    )
}
