package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Which centre treatment the dial draws. */
public enum class DialMode { Preview, Recording, Complete }

/**
 * The hero dial. Drawn in the prototype's `viewBox 0 0 240 240` space and scaled
 * to the composable. Compose's `drawArc` measures clockwise from 3 o'clock, so
 * the prototype's 0°-is-up convention is applied as `startAngle = jsDeg − 90`.
 *
 * Guidance layers (target / too-fast / chevron / cursor / hold-level) only draw
 * in [DialMode.Recording] with a non-null [headingDeg]; a `null` heading
 * (jittery IMU / no reliable signal) falls straight back to ring + count + time.
 */
@Composable
public fun CaptureDial(
    captured: List<Boolean>,
    modifier: Modifier = Modifier,
    mode: DialMode = DialMode.Recording,
    remainingFraction: Float = 1f,
    headingDeg: Double? = null,
    speed: CaptureSpeed = CaptureSpeed.Ok,
    tiltBad: Boolean = false,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    val complete = mode == DialMode.Complete
    val recording = mode == DialMode.Recording
    val target = if (complete || headingDeg == null) null
    else DialMath.nextTarget(captured, headingDeg)

    // LOW-END: the pulses are driven by the continuous frame ticker, NOT
    // `rememberInfiniteTransition` / `animateTo(tween)` — those freeze on weak
    // GPUs (Samsung XCover5) under the composited camera preview. Reading
    // `tState` inside the Canvas draw lambda keeps the animation in the draw
    // phase, so no per-frame recomposition is needed.
    val tState = rememberFrameSeconds()

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val t = tState.value
            val targetPulse = pulse(t, periodSec = 1.25f, lo = 0.55f, hi = 1f)
            val cursorGlow = pulse(t, periodSec = 1.6f, lo = 0.4f, hi = 0.85f)
            val warnPulse = pulse(t, periodSec = 0.5f, lo = 0.35f, hi = 1f)

            val s = min(size.width, size.height) / VIEWBOX
            val center = Offset(size.width / 2f, size.height / 2f)
            val ring = RING_RADIUS * s
            val stroke = SECTOR_STROKE * s
            val timeR = TIME_ARC_RADIUS * s

            // The time arc is heading-independent, so it keeps its 12 o'clock
            // start (−90° in the 0°=3-o'clock frame).
            drawRingStroke(center, timeR, colors.outlineVariant, 2.5f * s)
            if (!complete && remainingFraction > 0.001f) {
                drawArcDeg(center, timeR, -90f, remainingFraction * 359.99f,
                    colors.secondary, 2.5f * s, cap = StrokeCap.Round)
            }

            for (i in 0 until DialMath.SECTORS) {
                val a1 = i * DialMath.SECTOR_SWEEP_DEG + SECTOR_GAP / 2f
                val a2 = (i + 1) * DialMath.SECTOR_SWEEP_DEG - SECTOR_GAP / 2f
                val covered = captured.getOrElse(i) { false }
                val col = when {
                    complete -> colors.progressComplete
                    covered -> colors.orbit
                    else -> colors.orbitInactive
                }
                drawArcDeg(center, ring, a1, a2 - a1, col, stroke, cap = StrokeCap.Round)
                if (covered && !complete) {
                    drawCircle(colors.onOrbit, radius = 2.4f * s,
                        center = polar(center, ring, DialMath.sectorCenterDeg(i)))
                }
            }

            if (target != null) {
                val a1 = target * DialMath.SECTOR_SWEEP_DEG + SECTOR_GAP / 2f
                val sweep = DialMath.SECTOR_SWEEP_DEG - SECTOR_GAP
                drawArcDeg(center, ring, a1, sweep, colors.orbit, (SECTOR_STROKE + 5) * s,
                    cap = StrokeCap.Round, alpha = 0.7f * targetPulse)
                drawArcDeg(center, ring, a1, sweep, colors.surface, stroke, cap = StrokeCap.Round)
                drawArcDeg(center, ring, a1, sweep, colors.orbit, stroke, cap = StrokeCap.Round,
                    alpha = targetPulse, pathEffect = PathEffect.dashPathEffect(floatArrayOf(3f * s, 6f * s)))
            }

            if (speed == CaptureSpeed.Fast && !complete && recording) {
                drawRingStroke(center, ring + (SECTOR_STROKE / 2f + 6f) * s, colors.warning,
                    2.5f * s, alpha = warnPulse,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(2f * s, 7f * s)))
            }

            if (target != null) {
                val ca = DialMath.sectorCenterDeg(target)
                val base = polar(center, (RING_RADIUS - SECTOR_STROKE - 11) * s, ca)
                // The path points toward 12 o'clock (screen −90°). The dial is
                // mirrored about the vertical axis (see [polar]); the radially-
                // OUTWARD rotation that aims the tip at the target sector in the
                // mirrored frame is `270 − ca` (≡ `−90 − ca`), not `90 − ca`.
                rotate(degrees = 270f - ca, pivot = base) {
                    val path = Path().apply {
                        moveTo(base.x - 7f * s, base.y + 4f * s)
                        lineTo(base.x, base.y - 5f * s)
                        lineTo(base.x + 7f * s, base.y + 4f * s)
                    }
                    drawPath(path, colors.orbit, alpha = targetPulse,
                        style = Stroke(width = 2.6f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }

            // At the reference pose the azimuth is undefined, so the cursor would
            // wander the ring. Suppress it while `tiltBad` (heading is also gated
            // to null upstream, so every heading-driven layer stays put together).
            if (recording && !complete && headingDeg != null && !tiltBad) {
                val trail = when (speed) {
                    CaptureSpeed.Fast -> 46f; CaptureSpeed.Slow -> 8f; CaptureSpeed.Ok -> 20f
                }
                val tcol = if (speed == CaptureSpeed.Fast) colors.warning else colors.orbit
                drawArcDeg(center, ring, (headingDeg - trail).toFloat(), trail, tcol, stroke,
                    cap = StrokeCap.Round, alpha = 0.35f)
                val hp = polar(center, ring, headingDeg.toFloat())
                drawCircle(tcol, radius = 14f * s, center = hp, alpha = 0.5f * (cursorGlow / 0.85f).coerceIn(0f, 1f))
                drawCircle(colors.onPrimary, radius = 8.5f * s, center = hp)
                drawCircle(tcol, radius = 4.5f * s, center = hp)
            }

            if (tiltBad && !complete && recording) {
                rotate(degrees = 14f, pivot = center) {
                    drawLine(colors.warning, Offset(center.x - 34f * s, center.y),
                        Offset(center.x + 34f * s, center.y), strokeWidth = 2.5f * s, cap = StrokeCap.Round)
                }
                drawLine(Color(0x55FFFFFF), Offset(center.x - 28f * s, center.y),
                    Offset(center.x + 28f * s, center.y), strokeWidth = 1.5f * s,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(2f * s, 4f * s)))
            }

            if (complete) {
                drawRingStroke(center, 34f * s, colors.progressComplete, 3f * s)
                val check = Path().apply {
                    moveTo(center.x - 16f * s, center.y + 1f * s)
                    lineTo(center.x - 4f * s, center.y + 12f * s)
                    lineTo(center.x + 18f * s, center.y - 12f * s)
                }
                drawPath(check, colors.progressComplete,
                    style = Stroke(width = 5f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }

        // a11y: dial drawn in fixed dp, count in sp so the text still scales.
        if (!complete) {
            when (mode) {
                DialMode.Recording -> CountLabel("${captured.count { it }}", "of 8" /* video_capture_of_eight */,
                    colors.onPrimary, colors.onSurfaceVariant)
                DialMode.Preview -> CountLabel("0", "of 8" /* video_capture_of_eight */, colors.outline, colors.outline)
                else -> Unit
            }
        }
    }
}

@Composable
private fun CountLabel(big: String, small: String, bigColor: Color, smallColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(big, color = bigColor, fontSize = 34.sp, fontWeight = FontWeight.SemiBold)
        Text(small, color = smallColor, fontSize = 13.sp)
    }
}

/** Shutter phase — the dot colour / shape carries the state signal. */
public enum class ShutterKind { TakePhoto, StartOrbit, StopRecording }

/**
 * Shutter affordance: a 64 dp white ring whose core is a white dot
 * (ReadyForPhoto), a red dot (PhotoTaken), or a red rounded square
 * (RecordingVideo). The countdown lives on the dial's inner time arc, not here.
 */
@Composable
public fun CaptureShutter(
    kind: ShutterKind,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    Box(
        modifier = modifier
            .size(64.dp)
            .background(Color.White, CircleShape)
            .border(3.dp, Color.White, CircleShape)
            .clickable { onTap() },
        contentAlignment = Alignment.Center,
    ) {
        when (kind) {
            ShutterKind.TakePhoto -> Box(Modifier.size(54.dp).background(Color.White, CircleShape))
            ShutterKind.StartOrbit -> Box(Modifier.size(50.dp).background(colors.progress.copy(alpha = 0.92f), CircleShape))
            ShutterKind.StopRecording -> Box(Modifier.size(24.dp).background(colors.progress, RoundedCornerShape(7.dp)))
        }
    }
}

// ── geometry helpers (240-unit space, mirrored about the vertical axis) ──────
//
// The heading angle fed to the dial is the SAME `theta` (`atan2(y2d, x2d)`) the
// recorded `Pie` consumes, and `Pie` / web_app's `_CapturedAnglesPainter` place
// 0° at 3 o'clock, increasing clockwise (screen +y is down). The primitives are
// drawn in that canonical 0°=right convention so sector `i` lands where web_app
// draws it.
//
// web_app's shared `computeOrientationVector` maps physical-right → screen-LEFT.
// We match that PRESENTATION-ONLY by negating the x component in [polar] — cursor,
// sectors, target, chevron base and trail all derive from `polar`, so they mirror
// together: physical tilt LEFT fills LEFT, RIGHT fills RIGHT (up/down unchanged).
// Recorded θ / `Pie` / `VideoMetaData` stay byte-identical.
// TODO: mirror web_app's own ring the same way so the two stop diverging.

internal const val VIEWBOX = 240f
internal const val RING_RADIUS = 76f
internal const val SECTOR_STROKE = 13f
internal const val SECTOR_GAP = 8f
internal const val TIME_ARC_RADIUS = 99f

/** `polar(deg, r)` → centre + (−cos·r, sin·r); mirrored about the vertical axis (see above). */
internal fun polar(center: Offset, rPx: Float, deg: Float): Offset {
    val a = deg * PI.toFloat() / 180f
    return Offset(center.x - rPx * cos(a), center.y + rPx * sin(a))
}

internal fun DrawScope.drawRingStroke(
    center: Offset, rPx: Float, color: Color, width: Float,
    alpha: Float = 1f, pathEffect: PathEffect? = null,
) {
    drawCircle(color, radius = rPx, center = center, alpha = alpha.coerceIn(0f, 1f),
        style = Stroke(width = width, pathEffect = pathEffect))
}

/**
 * Draw an arc in dial degrees — mirrored about the vertical axis to match
 * [polar]. A vertical reflection maps a clockwise arc `[start, start + sweep]` to
 * a clockwise arc starting at `180 − start` sweeping `−sweep`, so the sector arcs
 * land under their `polar`-placed covered ticks / cursor.
 */
internal fun DrawScope.drawArcDeg(
    center: Offset, rPx: Float, startDeg: Float, sweepDeg: Float,
    color: Color, width: Float, cap: StrokeCap = StrokeCap.Butt,
    alpha: Float = 1f, pathEffect: PathEffect? = null,
) {
    drawArc(
        color = color,
        startAngle = 180f - startDeg,
        sweepAngle = -sweepDeg,
        useCenter = false,
        topLeft = Offset(center.x - rPx, center.y - rPx),
        size = Size(rPx * 2f, rPx * 2f),
        alpha = alpha.coerceIn(0f, 1f),
        style = Stroke(width = width, cap = cap, pathEffect = pathEffect),
    )
}
