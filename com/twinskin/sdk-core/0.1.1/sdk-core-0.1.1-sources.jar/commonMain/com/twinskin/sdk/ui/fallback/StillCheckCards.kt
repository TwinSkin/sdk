package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
public fun LowLightCard(
    torchOn: Boolean,
    onToggleTorch: (Boolean) -> Unit,
    onRetake: () -> Unit,
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    WarnScrim(modifier) {
        WarnCard(accent = colors.warning, colors = colors) {
            IconRing(glyph = "\u2600", accent = colors.warning)
            Spacer(Modifier.height(12.dp))
            Text("Low light", /* video_capture_low_light_title */ color = colors.onSurface, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(7.dp))
            Text("Too dark for an accurate capture.", /* video_capture_low_light_body */ color = colors.onSurfaceVariant,
                fontSize = 12.5.sp, textAlign = TextAlign.Center)

            Row(
                modifier = Modifier
                    .padding(top = 15.dp)
                    .fillMaxWidth()
                    .background(colors.surface, RoundedCornerShape(11.dp))
                    .border(1.dp, colors.outlineVariant, RoundedCornerShape(11.dp))
                    .clickable { onToggleTorch(!torchOn) }
                    .padding(horizontal = 13.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("\uD83D\uDD26", fontSize = 15.sp)
                    Text("Torch on", /* video_capture_torch_on */ color = colors.onSurface, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                }
                ToggleSwitch(on = torchOn, colors = colors)
            }

            Spacer(Modifier.height(16.dp))
            PrimaryCardButton("Retake photo" /* video_capture_low_light_retake */, onClick = onRetake, colors = colors)
        }
    }
}

@Composable
public fun MarkerWarningCard(
    onRetakeWithMarker: () -> Unit,
    onContinueWithout: () -> Unit,
    modifier: Modifier = Modifier,
    markerImage: @Composable () -> Unit = {},
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    WarnScrim(modifier) {
        WarnCard(accent = colors.secondary, colors = colors) {
            Box(
                modifier = Modifier
                    .size(92.dp)
                    .background(Color.White, RoundedCornerShape(15.dp))
                    .padding(6.dp),
                contentAlignment = Alignment.Center,
            ) { markerImage() }
            Spacer(Modifier.height(11.dp))
            Text("PLACE THIS FLAT BY THE LESION", /* video_capture_marker_place_hint */ color = colors.secondary,
                fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("Marker not detected", /* video_capture_marker_not_detected_title */ color = colors.onSurface, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(7.dp))
            Text("Without it, measurements aren\u2019t available.", /* video_capture_marker_not_detected_body */
                color = colors.onSurfaceVariant, fontSize = 12.5.sp, textAlign = TextAlign.Center)

            Spacer(Modifier.height(16.dp))
            PrimaryCardButton("Retake with marker" /* video_capture_marker_retake */, onClick = onRetakeWithMarker, colors = colors)
            Spacer(Modifier.height(9.dp))
            GhostCardButton("Continue without measurement" /* video_capture_marker_continue_without */, onClick = onContinueWithout, colors = colors)
            Spacer(Modifier.height(11.dp))
            Text("OPTIONAL \u00B7 WORKS WITHOUT IT", /* video_capture_marker_optional_hint */ color = colors.outline, fontSize = 9.5.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun WarnScrim(modifier: Modifier, content: @Composable () -> Unit) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0x80060A0B), Color(0xD6060A0B))))
            .padding(horizontal = 26.dp),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun WarnCard(
    accent: Color,
    colors: AccelerometerCaptureColors,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    Column(
        modifier = Modifier
            .width(248.dp)
            .background(colors.surfaceContainer, RoundedCornerShape(18.dp))
            .border(1.dp, colors.outlineVariant, RoundedCornerShape(18.dp))
            .padding(horizontal = 19.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content,
    )
}

@Composable
private fun IconRing(glyph: String, accent: Color) {
    Box(
        modifier = Modifier
            .size(50.dp)
            .border(2.dp, accent, CircleShape),
        contentAlignment = Alignment.Center,
    ) { Text(glyph, color = accent, fontSize = 24.sp) }
}

@Composable
private fun ToggleSwitch(on: Boolean, colors: AccelerometerCaptureColors) {
    Box(
        modifier = Modifier
            .size(width = 38.dp, height = 22.dp)
            .background(if (on) colors.orbit else colors.outline, RoundedCornerShape(999.dp))
            .padding(2.dp),
        contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart,
    ) {
        Box(Modifier.size(18.dp).background(if (on) colors.onOrbit else Color(0xFF0B0F10), CircleShape))
    }
}

@Composable
internal fun PrimaryCardButton(
    label: String,
    onClick: () -> Unit,
    colors: AccelerometerCaptureColors,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(colors.orbit, RoundedCornerShape(11.dp))
            .clickable { onClick() }
            .padding(vertical = 11.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = colors.onOrbit, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
internal fun GhostCardButton(
    label: String,
    onClick: () -> Unit,
    colors: AccelerometerCaptureColors,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, colors.outline, RoundedCornerShape(11.dp))
            .clickable { onClick() }
            .padding(vertical = 11.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = colors.onSurface, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold) }
}
