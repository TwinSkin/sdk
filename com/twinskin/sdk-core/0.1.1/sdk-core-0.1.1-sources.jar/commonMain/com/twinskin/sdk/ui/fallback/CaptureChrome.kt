package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The pill that floats above the dial during recording. Priority order, highest
 * first: complete → hold-level → too-fast → too-slow → default "follow the target".
 *
 * Always pairs colour with an icon glyph + text (no colour-only signal), so it
 * survives a grayscale / colour-blind pass.
 */
public enum class CaptureStatus(
    public val glyph: String,
    public val message: String,
) {
    FollowTarget("→", "Follow the cyan target" /* video_capture_status_follow_target */),
    KeepMoving("↻", "Keep moving around the lesion" /* video_capture_status_keep_moving */),
    SlowDown("!", "Slow down — moving too fast" /* video_capture_status_slow_down */),
    HoldLevel("⌃", "Hold the phone level" /* video_capture_status_hold_level */),
    Complete("✓", "Orbit complete" /* video_capture_status_complete */);

    public companion object {
        public fun resolve(
            complete: Boolean,
            tiltBad: Boolean,
            speed: CaptureSpeed,
        ): CaptureStatus = when {
            complete -> Complete
            tiltBad -> HoldLevel
            speed == CaptureSpeed.Fast -> SlowDown
            speed == CaptureSpeed.Slow -> KeepMoving
            else -> FollowTarget
        }
    }
}

@Composable
public fun CaptureStatusLine(
    status: CaptureStatus,
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    val accent = when (status) {
        CaptureStatus.HoldLevel, CaptureStatus.SlowDown -> colors.warning
        CaptureStatus.KeepMoving -> colors.secondary
        CaptureStatus.Complete -> colors.progressComplete
        CaptureStatus.FollowTarget -> colors.orbit
    }
    val border = when (status) {
        CaptureStatus.FollowTarget, CaptureStatus.KeepMoving -> Color(0x22FFFFFF)
        else -> accent.copy(alpha = 0.45f)
    }
    Row(
        modifier = modifier
            .background(Color(0xB8081215), RoundedCornerShape(999.dp))
            .border(1.dp, border, RoundedCornerShape(999.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Text(status.glyph, color = accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Text(status.message, color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * The two-tap step pill under the shutter. Present on **every** run so the
 * two-tap flow is self-evident without the coachmark.
 *
 * @param number "1" / "2" — drawn as a cyan chip, [muted] grey once that step is done.
 */
@Composable
public fun StepPill(
    number: String,
    label: String,
    modifier: Modifier = Modifier,
    muted: Boolean = false,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    Row(
        modifier = modifier
            .background(Color(0xA8081215), RoundedCornerShape(999.dp))
            .border(1.dp, Color(0x1FFFFFFF), RoundedCornerShape(999.dp))
            .padding(horizontal = 13.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            number,
            color = if (muted) Color(0xFF0B0F10) else colors.onOrbit,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .background(if (muted) colors.outline else colors.orbit, RoundedCornerShape(5.dp))
                .padding(horizontal = 5.dp, vertical = 1.dp),
        )
        Text(label, color = colors.onSurface, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * Muted info pill — e.g. the recording "Tap to stop early" hint. Translucent
 * dark background + hairline border so it stays legible over the live feed.
 */
@Composable
public fun MutedPill(
    text: String,
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    Text(
        text = text,
        color = colors.onSurfaceVariant,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier
            .background(Color(0xA8081215), RoundedCornerShape(999.dp))
            .border(1.dp, Color(0x1FFFFFFF), RoundedCornerShape(999.dp))
            .padding(horizontal = 13.dp, vertical = 5.dp),
    )
}

/**
 * "Torch on" pill that persists once the low-light path latches the torch —
 * through Step 2 and recording.
 */
@Composable
public fun TorchPill(
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    Row(
        modifier = modifier
            .background(Color(0xC7081215), RoundedCornerShape(999.dp))
            .border(1.dp, colors.orbit.copy(alpha = 0.4f), RoundedCornerShape(999.dp))
            .padding(horizontal = 12.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Box(Modifier.size(7.dp).background(colors.orbit, CircleShape))
        Text("Torch on", /* video_capture_torch_on */ color = colors.orbit, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * Reference-photo thumbnail, bottom-left during PhotoTaken / RecordingVideo.
 * Tapping it (on PhotoTaken) opens the retake prompt. The image itself is
 * platform-injected (the captured still) via [thumbnail].
 *
 * [enabled] is `false` during RecordingVideo — a mid-record reference reset is
 * parity-affecting and out of scope — so the tap and its expand affordance are
 * suppressed while the thumbnail still shows the still for context.
 */
@Composable
public fun ReferenceThumbnail(
    onRetake: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    thumbnail: @Composable () -> Unit = {},
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    Box(
        modifier = modifier
            .size(width = 54.dp, height = 74.dp)
            .background(Color.Black, RoundedCornerShape(9.dp))
            .border(1.5.dp, Color(0x85FFFFFF), RoundedCornerShape(9.dp))
            .clickable(
                enabled = enabled,
                onClickLabel = "Retake reference photo", /* video_capture_retake_reference */
            ) { onRetake() },
    ) {
        thumbnail()
        if (enabled) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(3.dp)
                    .size(15.dp)
                    .background(Color(0xCC081215), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text("⤢", color = Color.White, fontSize = 9.sp)
            }
        }
    }
}
