@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.view

import com.twinskin.sdk.view.CaptureNetworkException
import com.twinskin.sdk.view.CaptureNotFoundException
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.onDownload
import io.ktor.client.request.header
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsChannel
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import io.ktor.http.isSuccess
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.readAvailable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

// socketTimeoutMillis bounds time *between* bytes so a mid-stream stall
// surfaces as a network error rather than freezing the UI's progress bar
// indefinitely. requestTimeoutMillis is left null because legitimate
// downloads of multi-MB GLBs over slow LTE can outlast any reasonable cap on
// total time.
private val client = HttpClient {
    install(HttpTimeout) {
        requestTimeoutMillis = null
        socketTimeoutMillis = 60_000L
        connectTimeoutMillis = 30_000L
    }
}

public actual fun cachedFileExists(path: String): Boolean {
    val f = File(path)
    return f.exists() && f.length() > 0L
}

public actual suspend fun downloadToPath(
    url: String,
    destPath: String,
    headers: Map<String, String>,
    onProgress: (bytesRead: Long, total: Long?) -> Unit,
) {
    withContext(Dispatchers.IO) {
        val dest = File(destPath)
        dest.parentFile?.mkdirs()
        // Stream into a sibling `.partial` file and atomically rename on
        // success. Without this, a process kill mid-download leaves a
        // truncated file at `destPath` that `cachedFileExists` reports as a
        // hit on next launch — handing the renderer a corrupt GLB.
        val partial = File("$destPath.partial")

        // ktor's `HttpStatement.execute { block }` requires the lambda to
        // either fully consume the response body or hit the body-channel's
        // cancel path. Returning without doing so leaves `cleanup()` (in
        // the execute `finally`) suspended forever on `body.join()` —
        // `execute` never returns to the caller, so any error never
        // propagates and the caller hangs. So on every non-2xx path we
        // drain the body first, then return the error and throw outside.
        val error: Throwable? = client.prepareGet(url) {
            headers.forEach { (name, value) -> header(name, value) }
            onDownload { bytesSentTotal, contentLength ->
                onProgress(bytesSentTotal, contentLength)
            }
        }.execute { response ->
            android.util.Log.i("TwinSkinDl", "← status=${response.status.value} url=$url")
            when {
                response.status == HttpStatusCode.NotFound -> {
                    runCatching { response.bodyAsText() }
                    CaptureNotFoundException("$url returned 404")
                }
                !response.status.isSuccess() -> {
                    val body = runCatching { response.bodyAsText() }.getOrDefault("")
                    android.util.Log.w(
                        "TwinSkinDl",
                        "non-2xx status=${response.status.value} body=$body",
                    )
                    CaptureNetworkException(
                        "$url returned ${response.status.value}: $body",
                    )
                }
                else -> {
                    val channel: ByteReadChannel = response.bodyAsChannel()
                    try {
                        FileOutputStream(partial).use { out ->
                            val buffer = ByteArray(64 * 1024)
                            while (!channel.isClosedForRead) {
                                val read = channel.readAvailable(buffer, 0, buffer.size)
                                if (read > 0) out.write(buffer, 0, read)
                            }
                        }
                    } catch (t: Throwable) {
                        partial.delete()
                        throw t
                    }
                    null
                }
            }
        }
        if (error != null) {
            partial.delete()
            throw error
        }
        // Atomic move: same filesystem (both under cacheDir) so rename is
        // the swap. Falls back to copy on cross-fs.
        if (dest.exists()) dest.delete()
        if (!partial.renameTo(dest)) {
            partial.copyTo(dest, overwrite = true)
            partial.delete()
        }
    }
}
