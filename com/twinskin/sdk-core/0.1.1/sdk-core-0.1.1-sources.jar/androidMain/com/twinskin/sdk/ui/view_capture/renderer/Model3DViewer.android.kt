@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.renderer

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.google.android.filament.gltfio.FilamentInstance
import com.twinskin.sdk.view.Asset3D
import io.github.sceneview.SceneView
import io.github.sceneview.SurfaceType
import io.github.sceneview.math.Position
import io.github.sceneview.rememberCameraNode
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberEnvironmentLoader
import io.github.sceneview.rememberMainLightNode
import io.github.sceneview.rememberModelLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Android renderer: SceneView (Filament + gltfio) loaded from a local
 * `.glb` file path.
 *
 * All [com.twinskin.sdk.view.CaptureResolver]s land a local path in
 * [Asset3D.location] by the time this composable runs (HTTP/Zip resolvers
 * download first, Local passes through), so the renderer only needs to
 * handle a file on disk.
 *
 * ### Why we don't use `rememberModelInstance`
 *
 * SceneView's [io.github.sceneview.rememberModelInstance] takes a
 * `String` location and parses it as a URI. For our absolute file
 * paths it falls into a code path that wraps the actual load in
 * `runCatching { … }.getOrNull()` and silently returns `null` on any
 * failure — concretely, the load returned null even with a `file://`
 * prefix, with no error surfaced. We instead drive the load by hand:
 * read bytes off the main thread, then call
 * `modelLoader.createModelInstance(buffer)` on the engine thread. The
 * library's `createModel(buffer, ...)` underneath adds the model to
 * `modelLoader.models`, so when this composable disposes and
 * `modelLoader.destroy()` cascades, the asset and instance are
 * cleaned up.
 *
 * ### Why `SurfaceType.TextureSurface`
 *
 * The default [SurfaceType.Surface] is a SurfaceView. After a Compose
 * mount/unmount/remount cycle inside the same Activity (e.g., user
 * opens the viewer, closes it, opens it again), the SurfaceView's
 * surface stops invalidating until something forces a redraw — a
 * touch event, a layout change. The model is rendered and interactive
 * the whole time; just not pushed to the screen. TextureView
 * (`TextureSurface`) refreshes inline on every frame and doesn't have
 * that quirk. We pay slightly worse GPU performance and lose the
 * ability to render Compose UI behind the scene, both irrelevant for
 * this viewer.
 */
@Composable
public actual fun Model3DViewer(
    asset: Asset3D,
    modifier: Modifier,
) {
    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine)
    val environmentLoader = rememberEnvironmentLoader(engine)

    var modelInstance by remember(asset.location) { mutableStateOf<FilamentInstance?>(null) }
    LaunchedEffect(asset.location, modelLoader) {
        val bytes = withContext(Dispatchers.IO) { File(asset.location).readBytes() }
        modelInstance = modelLoader.createModelInstance(ByteBuffer.wrap(bytes))
    }

    // SceneView's orbit manipulator pivots around world origin (0,0,0). A GLB
    // whose geometry isn't authored origin-centred would then swing around an
    // off-centre point, so we translate the node by the same scale as
    // `scaleToUnits = 1f` applies, landing the bounding-box centre on origin.
    val centeredPosition = remember(modelInstance) {
        modelInstance?.let { instance ->
            val box = instance.asset.boundingBox
            val center = box.center
            val halfExtent = box.halfExtent
            val maxExtent = maxOf(halfExtent[0], halfExtent[1], halfExtent[2]) * 2f
            val unitScale = if (maxExtent > 0f) 1f / maxExtent else 1f
            Position(-center[0] * unitScale, -center[1] * unitScale, -center[2] * unitScale)
        } ?: Position(0f)
    }

    SceneView(
        modifier = modifier,
        surfaceType = SurfaceType.TextureSurface,
        engine = engine,
        modelLoader = modelLoader,
        environmentLoader = environmentLoader,
        cameraNode = rememberCameraNode(engine) { position = Position(z = 4f) },
        mainLightNode = rememberMainLightNode(engine),
    ) {
        modelInstance?.let { instance ->
            ModelNode(
                modelInstance = instance,
                scaleToUnits = 1f,
                position = centeredPosition,
            )
        }
    }
}
