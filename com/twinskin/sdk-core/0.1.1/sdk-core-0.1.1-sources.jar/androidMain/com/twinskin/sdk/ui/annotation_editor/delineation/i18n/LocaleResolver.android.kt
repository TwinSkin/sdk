package com.twinskin.sdk.ui.annotation_editor.delineation.i18n

import java.util.Locale

internal actual fun resolveLocale(): String =
    Locale.getDefault().language.takeIf { it.isNotEmpty() } ?: "en"
