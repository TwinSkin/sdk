package com.twinskin.sdk.ui.fallback

import android.graphics.BitmapFactory
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
internal actual fun rememberBundledTutorialBitmap(name: TutorialAssetName): ImageBitmap? {
    val context = LocalContext.current
    var bitmap by remember(name) { mutableStateOf<ImageBitmap?>(null) }
    // Decode off main thread — 3.6 MB PNG triggered ANR on Pixel 6 when decoded inline in `remember`.
    LaunchedEffect(name) {
        bitmap = withContext(Dispatchers.IO) {
            val assetName = when (name) {
                TutorialAssetName.Do -> "twinskin_tutorial_do.png"
                TutorialAssetName.Dont -> "twinskin_tutorial_dont.png"
            }
            runCatching {
                context.assets.open(assetName).use {
                    BitmapFactory.decodeStream(it)?.asImageBitmap()
                }
            }.getOrNull()
        }
    }
    return bitmap
}
