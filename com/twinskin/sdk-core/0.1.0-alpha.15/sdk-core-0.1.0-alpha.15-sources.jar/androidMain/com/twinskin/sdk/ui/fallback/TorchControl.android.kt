package com.twinskin.sdk.ui.fallback

import androidx.camera.core.Camera

/**
 * CameraX-backed [TorchControl] for the Android accelerometer-capture
 * screen.
 *
 * The [camera] field is mutated by the
 * [com.twinskin.sdk.capture.fallback.CameraXAccelerometerVideoRecorder] once
 * `prepare()` returns and the bound camera is known — until then,
 * [isAvailable] returns `false` and [applyFlashMode] is a no-op so the
 * UI is safe to compose before the camera comes up.
 *
 * CameraX exposes a binary `enableTorch(true|false)` only — there is
 * no native auto-torch primitive (#338 owns the auto-exposure
 * heuristic on Android). The three-state UI maps to:
 * - `Off` → `enableTorch(false)`
 * - `Auto` → `enableTorch(false)` (defer to the AE loop)
 * - `On`  → `enableTorch(true)`
 *
 * No microphone permission is requested by any path here — every call
 * is on the already-bound CameraX `Camera` object, never on
 * `AudioRecord` or `AVCaptureDevice` audio inputs.
 */
public class CameraXTorchControl : TorchControl {
    private var camera: Camera? = null

    public fun bind(camera: Camera?) {
        this.camera = camera
    }

    override fun isAvailable(): Boolean =
        camera?.cameraInfo?.hasFlashUnit() == true

    override fun applyFlashMode(mode: FlashMode) {
        val c = camera ?: return
        if (!c.cameraInfo.hasFlashUnit()) return
        val on = when (mode) {
            FlashMode.On -> true
            FlashMode.Off, FlashMode.Auto -> false
        }
        c.cameraControl.enableTorch(on)
    }
}
