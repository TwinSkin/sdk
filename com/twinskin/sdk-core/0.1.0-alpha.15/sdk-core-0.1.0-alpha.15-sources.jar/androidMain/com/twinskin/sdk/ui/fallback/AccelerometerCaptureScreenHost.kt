@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.fallback

import android.app.Activity
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.media.MediaPlayer
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.compose.BackHandler
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.material3.CircularProgressIndicator
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.capture.fallback.VideoCaptureResult
import com.twinskin.sdk.capture.fallback.createAccelerometerDriver
import com.twinskin.sdk.capture.fallback.createAccelerometerVideoRecorder
import com.twinskin.sdk.ui.PermissionDeniedView
import com.twinskin.sdk.ui.capture.rememberCapturePermissionsState
import com.twinskin.sdk.TwinSkinSdk
import kotlinx.coroutines.launch

@TwinSkinInternalApi
@Composable
public fun AccelerometerCaptureScreenHost(
    metadata: SdkCaptureMetadata?,
    onDone: (CaptureSession) -> Unit,
    onCancel: () -> Unit,
    onSessionStarted: (CaptureSession) -> Unit = {},
    startSession: (SdkCaptureMetadata) -> CaptureSession = { TwinSkinSdk.startCapture(it) },
) {
    if (metadata == null) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black))
        return
    }

    val permissions = rememberCapturePermissionsState()
    LaunchedEffect(Unit) {
        if (!permissions.granted) permissions.request()
    }
    if (!permissions.granted) {
        Box(
            modifier = Modifier.fillMaxSize().background(Color.Black),
            contentAlignment = androidx.compose.ui.Alignment.Center,
        ) {
            if (permissions.denied) {
                PermissionDeniedView(
                    permanentlyDenied = permissions.permanentlyDenied,
                    onRetry = permissions.request,
                    onOpenSettings = permissions.openAppSettings,
                    onCancel = onCancel,
                )
            } else {
                CircularProgressIndicator(color = Color.White)
            }
        }
        return
    }

    val orientationContext = LocalContext.current
    DisposableEffect(Unit) {
        val activity = orientationContext.findActivity()
        val previous = activity?.requestedOrientation
        if (activity != null) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        onDispose {
            if (activity != null && previous != null) {
                activity.requestedOrientation = previous
            }
        }
    }

    val keepScreenOnView = LocalView.current
    val brightnessActivity = LocalContext.current.findActivity()
    DisposableEffect(keepScreenOnView, brightnessActivity) {
        val window = brightnessActivity?.window
        val previousKeepOn = keepScreenOnView.keepScreenOn
        val previousBrightness = window?.attributes?.screenBrightness
        keepScreenOnView.keepScreenOn = true
        window?.let {
            val params = it.attributes
            params.screenBrightness = 1f
            it.attributes = params
        }
        onDispose {
            keepScreenOnView.keepScreenOn = previousKeepOn
            window?.let {
                val params = it.attributes
                params.screenBrightness = previousBrightness
                    ?: android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                it.attributes = params
            }
        }
    }

    val scope = rememberCoroutineScope()
    val session = remember(metadata) { startSession(metadata).also(onSessionStarted) }

    val recorderContext = LocalContext.current
    val recorderLifecycleOwner = LocalLifecycleOwner.current

    // The PreviewView is created once and remembered across recomposition
    // so its surface lives long enough for CameraX to bind into it. The
    // surface provider is handed to the recorder via the factory so the
    // recorder's bindToLifecycle() can attach Preview alongside
    // VideoCapture. Without an attached Preview, some devices never
    // stream frames → recorder.stop() times out at finalization (#538).
    val previewView = remember(recorderContext) {
        PreviewView(recorderContext).apply {
            // PERFORMANCE = SurfaceView, lower latency and more
            // device-compatible. COMPATIBLE (TextureView) has been
            // observed to leave the surface blank on some Samsung
            // devices (A21S, Xcover 5) where the Camera2 backend
            // doesn't feed frames into the TextureView path. The
            // photosphere capture screen uses the same default.
            implementationMode = PreviewView.ImplementationMode.PERFORMANCE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    val recorder = remember(session, previewView) {
        createAccelerometerVideoRecorder(
            recorderContext,
            recorderLifecycleOwner,
            previewSurfaceProvider = previewView.surfaceProvider,
        )
    }

    val torchControl = remember(recorder) { CameraXTorchControl() }

    val preferences = remember(recorderContext) { sdkUserPreferences(recorderContext) }

    val controller = remember(session, recorder) {
        AccelerometerCaptureController(
            scope = scope,
            recorder = recorder,
            driver = createAccelerometerDriver(),
            takeStillPhoto = {
                recorder.takeStillPhoto(
                    "${session.workingDir.trimEnd('/')}/photo.jpg"
                )
            },
            videoOutputPath = {
                "${session.workingDir.trimEnd('/')}/video.mp4"
            },
            onResult = { result -> deliverResult(session, result, onDone) },
            onError = { /* surfaced by Error state in the screen */ },
        )
    }

    LaunchedEffect(controller) { controller.markCameraReady() }

    val cancelSession: () -> Unit = {
        scope.launch {
            try { session.cancel() } finally { onCancel() }
        }
    }
    BackHandler { cancelSession() }

    // Bind torch after `markCameraReady` runs — `LaunchedEffect`s
    // with the same key execute in source order, so this lands after
    // the bind in line 220 and reads a non-null `recorder.camera`.
    // `isAvailable()` is checked by the screen before painting the
    // flash slot, so a still-null camera just hides the button.
    LaunchedEffect(controller) { torchControl.bind(recorder.camera) }

    AccelerometerCaptureScreen(
        controller = controller,
        onCancel = cancelSession,
        torchControl = torchControl,
        userPreferences = preferences,
        cameraPreview = {
            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize(),
            )
        },
        tutorialPlayer = { AndroidTutorialVideoPlayer() },
        tutorialIllustrations = { slot -> BundledTutorialIllustrations(slot) },
    )
}

// Bundled in `:shared/src/androidMain/assets/` — see TutorialAssets.kt
// for why these aren't under composeResources/.
private const val TUTORIAL_VIDEO_ASSET_PATH = "twinskin_tutorial_video.mp4"

@Composable
private fun AndroidTutorialVideoPlayer() {
    // `VideoView.setVideoURI(file:///android_asset/...)` does not play
    // APK-bundled assets reliably; MediaPlayer needs an AssetFileDescriptor.
    // https://issuetracker.google.com/issues/36926684
    val context = LocalContext.current
    val player = remember { MediaPlayer() }
    var aspect by remember { mutableFloatStateOf(720f / 480f) }
    AndroidView(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(aspect)
            .clip(RoundedCornerShape(12.dp)),
        factory = { ctx ->
            SurfaceView(ctx).apply {
                holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) {
                        try {
                            context.assets.openFd(TUTORIAL_VIDEO_ASSET_PATH).use { afd ->
                                player.reset()
                                player.setOnErrorListener { _, what, extra ->
                                    android.util.Log.e(
                                        "TwinskinTutorial",
                                        "MediaPlayer error what=$what extra=$extra",
                                    )
                                    false
                                }
                                player.setOnVideoSizeChangedListener { _, w, h ->
                                    if (w > 0 && h > 0) aspect = w.toFloat() / h.toFloat()
                                }
                                player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                                player.isLooping = true
                                player.setSurface(holder.surface)
                                player.setOnPreparedListener { it.start() }
                                player.prepareAsync()
                            }
                        } catch (e: Exception) {
                            android.util.Log.e(
                                "TwinskinTutorial",
                                "Failed to open tutorial asset $TUTORIAL_VIDEO_ASSET_PATH",
                                e,
                            )
                        }
                    }
                    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {}
                    override fun surfaceDestroyed(holder: SurfaceHolder) {
                        player.setSurface(null)
                    }
                })
            }
        },
    )
    DisposableEffect(player) {
        onDispose {
            try { player.stop() } catch (_: IllegalStateException) {}
            player.release()
        }
    }
}

private suspend fun deliverResult(
    session: CaptureSession,
    result: VideoCaptureResult,
    onDone: (CaptureSession) -> Unit,
) {
    session.submit(result)
    onDone(session)
}

private fun android.content.Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}
