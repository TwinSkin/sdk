package com.twinskin.sdk.view

import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.capture.SdkMeasurement

/** A 3D asset resolved to a location the renderer can load. */
@TwinSkinInternalApi
public data class Asset3D(
    /** Filesystem path OR http(s) URL — renderer decides based on scheme. */
    val location: String,
    val format: Asset3DFormat,
)

@TwinSkinInternalApi
public enum class Asset3DFormat { GLB, USDZ }

/**
 * A 2D reference image resolved to a local filesystem path. The capture's
 * annotation polygon is overlaid by the renderer on top of this image.
 */
@TwinSkinInternalApi
public data class Image2DAsset(
    /** Absolute filesystem path to a JPEG/PNG file. */
    val location: String,
)

/**
 * What a [CaptureResolver] produces. The resolver streams updates, so any
 * nullable field means "not known yet" rather than "not present".
 *
 * A typical [com.twinskin.sdk.view.resolvers.CaptureIdResolver] emission
 * carries the 3D mesh ([model]) plus the 2D reference image ([image2D]),
 * the latest [annotation] traced on top of it, and the
 * [measurement] computed from it — together they back the viewer's
 * two tabs (3D / 2D). The URL/path-based resolvers
 * ([com.twinskin.sdk.view.resolvers.HttpGlbResolver],
 * [com.twinskin.sdk.view.resolvers.LocalGlbResolver]) only ever set [model].
 */
@TwinSkinInternalApi
public data class ResolvedCapture(
    val model: Asset3D? = null,
    val image2D: Image2DAsset? = null,
    val annotation: SdkAnnotation? = null,
    val measurement: SdkMeasurement? = null,
    val metadata: Map<String, String> = emptyMap(),
)
