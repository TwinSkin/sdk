@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.annotation_editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput

/**
 * Drag-to-draw canvas + region renderer shared by [GenericAnnotationEditor]
 * and [WoundAnnotationEditor]. Press starts a stroke, drag samples are
 * thinned at the canvas-pixel level to keep the polygon at a sensible
 * point count, and release commits the stroke (>= 3 thinned points) or
 * drops it. Pixel positions are normalized to the reference image's
 * 0..1 space before being passed to the state.
 *
 * Each finalized region is rendered as a translucent fill + opaque
 * outline. If the state attaches sub-regions to a region (e.g. tissue
 * contours inside a wound region), each sub-region is rendered on top
 * with the same fill/stroke pattern but at half the stroke width, so
 * the parent region's outline remains visually dominant.
 */
@Composable
internal fun PolygonEditorCanvas(state: PolygonEditorState) {
    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var lastAccepted: Offset? = null
                detectDragGestures(
                    onDragStart = { pos ->
                        val nx = (pos.x / size.width).toDouble().coerceIn(0.0, 1.0)
                        val ny = (pos.y / size.height).toDouble().coerceIn(0.0, 1.0)
                        state.startStroke(nx, ny)
                        lastAccepted = pos
                    },
                    onDrag = { change, _ ->
                        val pos = change.position
                        val last = lastAccepted
                        if (last == null || (pos - last).getDistance() >= kMinSampleSpacingPx) {
                            val nx = (pos.x / size.width).toDouble().coerceIn(0.0, 1.0)
                            val ny = (pos.y / size.height).toDouble().coerceIn(0.0, 1.0)
                            state.extendStroke(nx, ny)
                            lastAccepted = pos
                        }
                    },
                    onDragEnd = {
                        state.endStroke()
                        lastAccepted = null
                    },
                    onDragCancel = {
                        state.endStroke()
                        lastAccepted = null
                    },
                )
            },
    ) {
        for (region in state.regions) {
            if (region.points.isEmpty()) continue
            val color = parseHexColor(region.color)
            val path = Path().apply {
                val first = region.points.first()
                moveTo(first.x.toFloat() * size.width, first.y.toFloat() * size.height)
                for (i in 1 until region.points.size) {
                    val p = region.points[i]
                    lineTo(p.x.toFloat() * size.width, p.y.toFloat() * size.height)
                }
                close()
            }
            drawPath(path = path, color = color.copy(alpha = 0.25f))
            drawPath(path = path, color = color, style = Stroke(width = kStrokeWidthPx))

            for (sub in region.subRegions) {
                if (sub.contour.size < 2) continue
                val subColor = parseHexColor(sub.color)
                val subPath = Path().apply {
                    val first = sub.contour.first()
                    moveTo(first.x.toFloat() * size.width, first.y.toFloat() * size.height)
                    for (i in 1 until sub.contour.size) {
                        val p = sub.contour[i]
                        lineTo(p.x.toFloat() * size.width, p.y.toFloat() * size.height)
                    }
                    close()
                }
                drawPath(path = subPath, color = subColor.copy(alpha = 0.35f))
                drawPath(path = subPath, color = subColor, style = Stroke(width = kSubStrokeWidthPx))
            }
        }

        val pts = state.inProgressPoints
        if (pts.isNotEmpty()) {
            val color = parseHexColor(state.selectedColor)
            val path = Path().apply {
                val first = pts.first()
                moveTo(first.x.toFloat() * size.width, first.y.toFloat() * size.height)
                for (i in 1 until pts.size) {
                    val p = pts[i]
                    lineTo(p.x.toFloat() * size.width, p.y.toFloat() * size.height)
                }
            }
            drawPath(path = path, color = color, style = Stroke(width = kStrokeWidthPx))
        }
    }
}

private const val kMinSampleSpacingPx = 2.0f
private const val kStrokeWidthPx = 6.0f
private const val kSubStrokeWidthPx = 3.0f
