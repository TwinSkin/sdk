package com.twinskin.sdk.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class SdkCaptureUploadQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> selectById(captureId: String, mapper: (
    captureId: String,
    userRef: String,
    subjectRef: String,
    conditionType: String?,
    captureGroup: String?,
    bodyLocationJson: String?,
    customJson: String?,
    deviceInfoJson: String?,
    encryptedPath: String,
    transferTaskId: String?,
    annotationPending: Long,
    createdAt: Long,
    updatedAt: Long,
  ) -> T): Query<T> = SelectByIdQuery(captureId) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5),
      cursor.getString(6),
      cursor.getString(7),
      cursor.getString(8)!!,
      cursor.getString(9),
      cursor.getLong(10)!!,
      cursor.getLong(11)!!,
      cursor.getLong(12)!!
    )
  }

  public fun selectById(captureId: String): Query<SdkCaptureUpload> = selectById(captureId) {
      captureId_, userRef, subjectRef, conditionType, captureGroup, bodyLocationJson, customJson,
      deviceInfoJson, encryptedPath, transferTaskId, annotationPending, createdAt, updatedAt ->
    SdkCaptureUpload(
      captureId_,
      userRef,
      subjectRef,
      conditionType,
      captureGroup,
      bodyLocationJson,
      customJson,
      deviceInfoJson,
      encryptedPath,
      transferTaskId,
      annotationPending,
      createdAt,
      updatedAt
    )
  }

  public fun <T : Any> selectAll(mapper: (
    captureId: String,
    userRef: String,
    subjectRef: String,
    conditionType: String?,
    captureGroup: String?,
    bodyLocationJson: String?,
    customJson: String?,
    deviceInfoJson: String?,
    encryptedPath: String,
    transferTaskId: String?,
    annotationPending: Long,
    createdAt: Long,
    updatedAt: Long,
  ) -> T): Query<T> = Query(501_951_934, arrayOf("SdkCaptureUpload"), driver, "SdkCaptureUpload.sq",
      "selectAll",
      "SELECT SdkCaptureUpload.captureId, SdkCaptureUpload.userRef, SdkCaptureUpload.subjectRef, SdkCaptureUpload.conditionType, SdkCaptureUpload.captureGroup, SdkCaptureUpload.bodyLocationJson, SdkCaptureUpload.customJson, SdkCaptureUpload.deviceInfoJson, SdkCaptureUpload.encryptedPath, SdkCaptureUpload.transferTaskId, SdkCaptureUpload.annotationPending, SdkCaptureUpload.createdAt, SdkCaptureUpload.updatedAt FROM SdkCaptureUpload ORDER BY createdAt DESC") {
      cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5),
      cursor.getString(6),
      cursor.getString(7),
      cursor.getString(8)!!,
      cursor.getString(9),
      cursor.getLong(10)!!,
      cursor.getLong(11)!!,
      cursor.getLong(12)!!
    )
  }

  public fun selectAll(): Query<SdkCaptureUpload> = selectAll { captureId, userRef, subjectRef,
      conditionType, captureGroup, bodyLocationJson, customJson, deviceInfoJson, encryptedPath,
      transferTaskId, annotationPending, createdAt, updatedAt ->
    SdkCaptureUpload(
      captureId,
      userRef,
      subjectRef,
      conditionType,
      captureGroup,
      bodyLocationJson,
      customJson,
      deviceInfoJson,
      encryptedPath,
      transferTaskId,
      annotationPending,
      createdAt,
      updatedAt
    )
  }

  public fun <T : Any> selectOrphans(mapper: (
    captureId: String,
    userRef: String,
    subjectRef: String,
    conditionType: String?,
    captureGroup: String?,
    bodyLocationJson: String?,
    customJson: String?,
    deviceInfoJson: String?,
    encryptedPath: String,
    transferTaskId: String?,
    annotationPending: Long,
    createdAt: Long,
    updatedAt: Long,
  ) -> T): Query<T> = Query(-1_539_338_616, arrayOf("SdkCaptureUpload"), driver,
      "SdkCaptureUpload.sq", "selectOrphans",
      "SELECT SdkCaptureUpload.captureId, SdkCaptureUpload.userRef, SdkCaptureUpload.subjectRef, SdkCaptureUpload.conditionType, SdkCaptureUpload.captureGroup, SdkCaptureUpload.bodyLocationJson, SdkCaptureUpload.customJson, SdkCaptureUpload.deviceInfoJson, SdkCaptureUpload.encryptedPath, SdkCaptureUpload.transferTaskId, SdkCaptureUpload.annotationPending, SdkCaptureUpload.createdAt, SdkCaptureUpload.updatedAt FROM SdkCaptureUpload WHERE transferTaskId IS NULL") {
      cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5),
      cursor.getString(6),
      cursor.getString(7),
      cursor.getString(8)!!,
      cursor.getString(9),
      cursor.getLong(10)!!,
      cursor.getLong(11)!!,
      cursor.getLong(12)!!
    )
  }

  public fun selectOrphans(): Query<SdkCaptureUpload> = selectOrphans { captureId, userRef,
      subjectRef, conditionType, captureGroup, bodyLocationJson, customJson, deviceInfoJson,
      encryptedPath, transferTaskId, annotationPending, createdAt, updatedAt ->
    SdkCaptureUpload(
      captureId,
      userRef,
      subjectRef,
      conditionType,
      captureGroup,
      bodyLocationJson,
      customJson,
      deviceInfoJson,
      encryptedPath,
      transferTaskId,
      annotationPending,
      createdAt,
      updatedAt
    )
  }

  public fun selectAnnotationPending(captureId: String): Query<Long> =
      SelectAnnotationPendingQuery(captureId) { cursor ->
    cursor.getLong(0)!!
  }

  public fun insert(
    captureId: String,
    userRef: String,
    subjectRef: String,
    conditionType: String?,
    captureGroup: String?,
    bodyLocationJson: String?,
    customJson: String?,
    deviceInfoJson: String?,
    encryptedPath: String,
    transferTaskId: String?,
    annotationPending: Long,
    createdAt: Long,
    updatedAt: Long,
  ) {
    driver.execute(1_294_996_128, """
        |INSERT INTO SdkCaptureUpload (captureId, userRef, subjectRef, conditionType, captureGroup, bodyLocationJson, customJson, deviceInfoJson, encryptedPath, transferTaskId, annotationPending, createdAt, updatedAt)
        |VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 13) {
          bindString(0, captureId)
          bindString(1, userRef)
          bindString(2, subjectRef)
          bindString(3, conditionType)
          bindString(4, captureGroup)
          bindString(5, bodyLocationJson)
          bindString(6, customJson)
          bindString(7, deviceInfoJson)
          bindString(8, encryptedPath)
          bindString(9, transferTaskId)
          bindLong(10, annotationPending)
          bindLong(11, createdAt)
          bindLong(12, updatedAt)
        }
    notifyQueries(1_294_996_128) { emit ->
      emit("SdkCaptureUpload")
    }
  }

  public fun updateTransferTaskId(
    transferTaskId: String?,
    updatedAt: Long,
    captureId: String,
  ) {
    driver.execute(1_711_348_251,
        """UPDATE SdkCaptureUpload SET transferTaskId = ?, updatedAt = ? WHERE captureId = ?""", 3)
        {
          bindString(0, transferTaskId)
          bindLong(1, updatedAt)
          bindString(2, captureId)
        }
    notifyQueries(1_711_348_251) { emit ->
      emit("SdkCaptureUpload")
    }
  }

  public fun updateAnnotationPending(
    annotationPending: Long,
    updatedAt: Long,
    captureId: String,
  ) {
    driver.execute(-634_175_336,
        """UPDATE SdkCaptureUpload SET annotationPending = ?, updatedAt = ? WHERE captureId = ?""",
        3) {
          bindLong(0, annotationPending)
          bindLong(1, updatedAt)
          bindString(2, captureId)
        }
    notifyQueries(-634_175_336) { emit ->
      emit("SdkCaptureUpload")
    }
  }

  public fun deleteById(captureId: String) {
    driver.execute(1_801_227_396, """DELETE FROM SdkCaptureUpload WHERE captureId = ?""", 1) {
          bindString(0, captureId)
        }
    notifyQueries(1_801_227_396) { emit ->
      emit("SdkCaptureUpload")
    }
  }

  private inner class SelectByIdQuery<out T : Any>(
    public val captureId: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SdkCaptureUpload", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SdkCaptureUpload", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> =
        driver.executeQuery(-1_619_317_931,
        """SELECT SdkCaptureUpload.captureId, SdkCaptureUpload.userRef, SdkCaptureUpload.subjectRef, SdkCaptureUpload.conditionType, SdkCaptureUpload.captureGroup, SdkCaptureUpload.bodyLocationJson, SdkCaptureUpload.customJson, SdkCaptureUpload.deviceInfoJson, SdkCaptureUpload.encryptedPath, SdkCaptureUpload.transferTaskId, SdkCaptureUpload.annotationPending, SdkCaptureUpload.createdAt, SdkCaptureUpload.updatedAt FROM SdkCaptureUpload WHERE captureId = ?""",
        mapper, 1) {
      bindString(0, captureId)
    }

    override fun toString(): String = "SdkCaptureUpload.sq:selectById"
  }

  private inner class SelectAnnotationPendingQuery<out T : Any>(
    public val captureId: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SdkCaptureUpload", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SdkCaptureUpload", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> =
        driver.executeQuery(1_570_492_613,
        """SELECT annotationPending FROM SdkCaptureUpload WHERE captureId = ?""", mapper, 1) {
      bindString(0, captureId)
    }

    override fun toString(): String = "SdkCaptureUpload.sq:selectAnnotationPending"
  }
}
