package com.twinskin.sdk.devcapture

import com.twinskin.sdk.capture.CaptureResult
import com.twinskin.sdk.capture.io.writeBytes
import com.twinskin.sdk.sdk_client.SDK_API_PATH
import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider
import com.twinskin.sdk.sdk_client.parseSessionTokenPayload
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.HttpRequestBuilder
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsBytes
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpHeaders
import io.ktor.http.isSuccess

/**
 * Fetches the demo-capture catalog from `/api/sdk/demo/captures` and
 * downloads selected captures into a session's working dir, ready to
 * hand to `CaptureSession.submit(CaptureResult)`.
 *
 * One repository per capture session — `subjectRef` is used to mint
 * the session JWT for catalog + file requests, mirroring how
 * `SdkServerClient` works for live captures.
 */
internal class DemoCaptureRepository(
    private val httpClient: HttpClient,
    baseUrl: String,
    private val publishableKey: String,
    private val auth: SdkAuthorizationProvider,
    private val subjectRef: String,
) {
    private val apiBaseUrl: String = "${baseUrl.trimEnd('/')}$SDK_API_PATH"

    suspend fun listCatalog(): List<DemoCaptureEntry> {
        val response = httpClient.get("$apiBaseUrl/demo/captures") {
            authenticate()
        }
        if (!response.status.isSuccess()) {
            throw DemoCaptureException(
                "Failed to fetch demo catalog: ${response.status.value} " +
                    response.bodyAsText(),
            )
        }
        return response.body()
    }

    /**
     * Download [entry]'s ref + frames into [intoDir]. On any failure
     * mid-download, partial files may exist at the destination paths;
     * the caller is responsible for cleanup (typically via
     * `session.cancel()` which deletes the entire workingDir).
     *
     * Returns a `CaptureResult` with the local paths and
     * `markerVersion = null`.
     */
    suspend fun download(
        entry: DemoCaptureEntry,
        intoDir: String,
        onProgress: (downloaded: Int, total: Int) -> Unit,
    ): CaptureResult {
        val total = 1 + entry.frameUrls.size
        var done = 0
        val dirNoTrailingSlash = intoDir.trimEnd('/')

        val photoPath = "$dirNoTrailingSlash/photo.jpg"
        downloadTo(entry.refUrl, photoPath)
        done += 1
        onProgress(done, total)

        val framePaths = mutableListOf<String>()
        for ((index, url) in entry.frameUrls.withIndex()) {
            val frameName = "frame_${(index + 1).toString().padStart(3, '0')}.jpg"
            val framePath = "$dirNoTrailingSlash/$frameName"
            downloadTo(url, framePath)
            framePaths.add(framePath)
            done += 1
            onProgress(done, total)
        }

        return CaptureResult(
            photoPath = photoPath,
            framePaths = framePaths,
            markerVersion = null,
        )
    }

    private suspend fun downloadTo(url: String, destPath: String) {
        val absolute = resolveAgainstBase(url)
        val response = httpClient.get(absolute) { authenticate() }
        if (!response.status.isSuccess()) {
            throw DemoCaptureException(
                "Failed to download $absolute: ${response.status.value}",
            )
        }
        writeBytes(destPath, response.bodyAsBytes())
    }

    /**
     * The catalog endpoint returns paths relative to the SDK API root
     * (e.g. `demo/captures/<id>/<filename>`). Absolute URLs are passed
     * through unchanged so older servers (or future flexibility) still
     * work.
     */
    private fun resolveAgainstBase(url: String): String {
        if (url.startsWith("http://") || url.startsWith("https://")) return url
        return "$apiBaseUrl/${url.trimStart('/')}"
    }

    private suspend fun HttpRequestBuilder.authenticate() {
        val tokens = parseSessionTokenPayload(auth.fetchSessionToken(subjectRef))
        header(HttpHeaders.Authorization, "Bearer ${tokens.token}")
        header("X-Publishable-Key", publishableKey)
    }
}

internal class DemoCaptureException(message: String) : Exception(message)
