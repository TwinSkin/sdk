package com.twinskin.sdk.capture

/**
 * Canonical bundle filenames.
 *
 * The shape of the accompanying `manifest.json` is defined by [CaptureManifest],
 * which is generated from the Pydantic `SdkCaptureManifest` in
 * `packages/capture_pipeline/src/capture_pipeline/models.py` via
 * `packages/server/tool/generate_external_data_models.dart`.
 */
internal object CaptureBundleEntries {
    /** Reference still filename. The platform writes either `photo.jpg` or `photo.heic`. */
    const val IMAGE = "photo.jpg"
}
