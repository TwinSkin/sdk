package com.twinskin.sdk.ui.annotation_editor

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import com.twinskin.sdk.capture.Point2D
import com.twinskin.sdk.capture.TissueRegion
import com.twinskin.sdk.capture.WoundAnnotation
import com.twinskin.sdk.capture.WoundRegion

/**
 * State holder for [WoundAnnotationEditor]. Pure Kotlin so it can be
 * unit-tested without a Compose harness.
 *
 * Internally each wound region is stored as a [WoundEditorRegion] —
 * the drawn polygon plus a UI color plus the raw [TissueRegion] list
 * carried verbatim from the seed (or empty for freshly drawn regions).
 * The shared editor surface ([PolygonEditorState]) sees an [EditorRegion]
 * projection in which tissue contours are mapped to display colors via
 * [colorForTissueType]; the canvas paints those sub-regions on top of
 * the wound region's own fill+stroke.
 *
 * Tissues are not editable in v1 — they ride through unchanged unless
 * the parent region is deleted (in which case they go with it). The
 * region color picker affects the wound region's stroke only.
 */
@TwinSkinInternalApi
public class WoundAnnotationEditorState(
    initial: WoundAnnotation = WoundAnnotation(regions = emptyList()),
) : PolygonEditorState {
    private data class WoundEditorRegion(
        val points: List<EditorPoint>,
        val color: String,
        val tissues: List<TissueRegion>,
    )

    private val _regions = mutableStateListOf<WoundEditorRegion>()

    public override val regions: List<EditorRegion>
        get() = _regions.map { r ->
            EditorRegion(
                points = r.points,
                color = r.color,
                subRegions = r.tissues.map { t ->
                    EditorSubRegion(
                        contour = t.contour.map { EditorPoint(it.x, it.y) },
                        color = colorForTissueType(t.tissueType),
                    )
                },
            )
        }

    private val _inProgress = mutableStateListOf<EditorPoint>()
    public override val inProgressPoints: List<EditorPoint> get() = _inProgress

    private val _selectedColor = mutableStateOf(PolygonEditorState.DEFAULT_PALETTE.first())
    public override val selectedColor: String get() = _selectedColor.value

    init {
        _regions.addAll(
            initial.regions.map { region ->
                WoundEditorRegion(
                    points = region.contour.map { EditorPoint(it.x, it.y) },
                    color = PolygonEditorState.DEFAULT_PALETTE.first(),
                    tissues = region.tissues,
                )
            },
        )
    }

    public override fun startStroke(x: Double, y: Double) {
        _inProgress.clear()
        _inProgress.add(EditorPoint(x, y))
    }

    public override fun extendStroke(x: Double, y: Double) {
        _inProgress.add(EditorPoint(x, y))
    }

    public override fun endStroke() {
        if (_inProgress.size >= 3) {
            _regions.add(
                WoundEditorRegion(
                    points = _inProgress.toList(),
                    color = _selectedColor.value,
                    tissues = emptyList(),
                ),
            )
        }
        _inProgress.clear()
    }

    public override fun deleteRegion(index: Int) {
        if (index in _regions.indices) _regions.removeAt(index)
    }

    public override fun setRegionColor(index: Int, color: String) {
        if (index in _regions.indices) {
            _regions[index] = _regions[index].copy(color = color)
        }
    }

    public override fun selectColor(color: String) { _selectedColor.value = color }

    /**
     * Snapshot the editor's state as a [WoundAnnotation] suitable for
     * `submitAnnotation`. Each finalized polygon becomes a [WoundRegion]
     * with its tissues carried through unchanged from the seed (or
     * empty for regions the user drew during this session).
     */
    public fun toAnnotation(): WoundAnnotation =
        WoundAnnotation(
            regions = _regions.map { r ->
                WoundRegion(
                    contour = r.points.map { Point2D(x = it.x, y = it.y) },
                    tissues = r.tissues,
                )
            },
        )
}
