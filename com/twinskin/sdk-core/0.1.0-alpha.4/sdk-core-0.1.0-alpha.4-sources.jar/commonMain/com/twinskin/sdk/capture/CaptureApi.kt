package com.twinskin.sdk.capture

import com.twinskin.sdk.capture.crypto.secureRandomBytes
import com.twinskin.sdk.capture.io.deleteDirQuietly
import com.twinskin.sdk.capture.io.deleteFileQuietly
import com.twinskin.sdk.capture.io.ensureDir
import com.twinskin.sdk.capture.io.fileSize
import com.twinskin.sdk.capture.io.readFileStreaming
import com.twinskin.sdk.devcapture.DemoCaptureException
import com.twinskin.sdk.devcapture.DemoCaptureRepository
import com.twinskin.sdk.sdk_client.SdkDeviceInfo
import com.twinskin.sdk.sdk_client.SdkServerClient
import com.twinskin.sdk.transfer.TransferManager
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.currentTimeMillis
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Orchestrates the capture pipeline: build tar → encrypt → persist → hand off to
 * [TransferManager].
 *
 * ## Persistence + idempotent URL refresh
 *
 * Once a bundle is on disk, a row is written to [SdkCaptureStore] carrying every
 * field needed to re-call `POST /api/sdk/upload/start-capture`. The server endpoint
 * is idempotent on a client-supplied `capture_id`, so the `UrlResolver` passed to
 * the [TransferManager] can always obtain a fresh presigned PUT URL without the SDK
 * having to track expiry itself.
 *
 * The store row is deliberately written *after* encryption (data minimization:
 * nothing is persisted until the bundle exists on disk) and deleted only on
 * terminal success — recovery sweeps read `PENDING_UPLOAD` rows on startup to
 * re-enqueue interrupted uploads.
 */
internal class CaptureApi(
    private val transferManager: TransferManager,
    private val encryptor: BundleEncryptor,
    private val store: SdkCaptureStore,
    private val sdkVersion: String,
    private val devicePlatformInfo: DevicePlatformInfo,
    private val encryptedBundlePath: (captureId: String) -> String,
    private val workingDirForSession: (captureId: String) -> String,
    private val scope: CoroutineScope,
    /**
     * Optional — only required for [ConditionType.Generic] flows that
     * call [CaptureSession.submitAnnotation]. Tests that exercise only
     * the [ConditionType.Wound] path can leave this null.
     */
    private val serverClient: SdkServerClient? = null,
    private val devMode: Boolean = false,
    private val clock: () -> Long = ::currentTimeMillis,
    private val idGenerator: () -> String = ::randomCaptureId,
) {
    private val sessions = mutableMapOf<String, SessionEntry>()

    private val deviceInfoSnapshot: SdkDeviceInfo by lazy {
        SdkDeviceInfo(
            os = devicePlatformInfo.os,
            osVersion = devicePlatformInfo.osVersion,
            deviceManufacturer = devicePlatformInfo.deviceManufacturer,
            deviceModel = devicePlatformInfo.deviceModel,
            sdkVersion = sdkVersion,
            appVersion = devicePlatformInfo.appVersion,
            appBundleId = devicePlatformInfo.appBundleId,
            locale = devicePlatformInfo.locale,
        )
    }

    private class SessionEntry(
        val session: CaptureSession,
        var mirrorJob: Job? = null,
        var transferTaskId: String? = null,
    )

    /**
     * Start a new capture session. The server is not called until [CaptureSession.submit]
     * hands the bundle off to the transfer manager — keeping cancelled-before-submit
     * flows free of orphan server rows.
     *
     * The per-session [CaptureSession.workingDir] is created eagerly here so the
     * native capture flow can start writing into it immediately.
     */
    fun startCapture(metadata: SdkCaptureMetadata): CaptureSession {
        val id = idGenerator()
        val workingDir = workingDirForSession(id)
        ensureDir(workingDir)
        val session = CaptureSession(
            id = id,
            metadata = metadata,
            workingDir = workingDir,
            api = this,
        )
        sessions[session.id] = SessionEntry(session)
        return session
    }

    /**
     * Bundle the captured media into an encrypted archive on disk, then hand it off to
     * the transfer manager. The full pipeline runs with a fixed-size memory footprint
     * and a single pass over each media file — bytes flow straight from disk through
     * the tar writer + chunked AES-GCM encryptor.
     *
     * [result.photoPath] and every path in [result.framePaths] must be inside
     * [CaptureSession.workingDir]; the SDK rejects paths outside that directory with
     * [IllegalArgumentException].
     */
    internal suspend fun submit(session: CaptureSession, result: CaptureResult) {
        check(session.currentState is CaptureState.Idle) {
            "Session ${session.id} already submitted (state=${session.currentState})"
        }
        requirePathInside(session.workingDir, result.photoPath, "photoPath")
        require(result.framePaths.isNotEmpty()) { "framePaths must not be empty" }
        for ((idx, framePath) in result.framePaths.withIndex()) {
            requirePathInside(session.workingDir, framePath, "framePaths[$idx]")
        }
        // The bundle/encrypt pipeline does blocking file I/O + AES-GCM work; move off
        // whatever dispatcher the caller used (often the main thread, since submit is
        // typically invoked from a Compose click handler) so the UI stays responsive.
        withContext(Dispatchers.Default) {
            submitBlocking(session, result)
        }
    }

    private suspend fun submitBlocking(session: CaptureSession, result: CaptureResult) {
        // The native capture flow has placed photo + frames inside session.workingDir;
        // we delete the whole directory in the `finally` regardless of outcome.
        // If we crash before store.insert the encrypted bundle is orphaned on disk
        // (no row points to it, so recovery won't find it) — clean it up too.
        var encryptedPath: String? = null
        var persisted = false
        try {
            session.setState(CaptureState.Uploading(progressPercent = null))

            // Frame filename basenames inside the bundle archive mirror the
            // platform-written file basename so HEIC sources stay HEIC inside
            // the encrypted bundle (the server-side decrypt lambda
            // normalises every frame to JPEG before downstream consumers).
            val frameFilenames = result.framePaths.map { path ->
                path.substringAfterLast('/').substringAfterLast('\\')
            }

            val manifest = CaptureManifest(
                captureId = session.id,
                sdkVersion = sdkVersion,
                captureTimestamp = epochMillisToIso8601(clock()),
                imageFilename = CaptureBundleEntries.IMAGE,
                imageFrames = frameFilenames.map { SdkFrameEntry(filename = it) },
                markerVersion = result.markerVersion,
            )
            val manifestBytes = Json.encodeToString(manifest).encodeToByteArray()

            val photoSize = fileSize(result.photoPath)
            // For Generic captures we hand the reference image to the annotation editor
            // via `CaptureState.AwaitingAnnotation` as an on-disk path. The
            // `finally` below skips deleting `session.workingDir` so the
            // photo file survives until `submitAnnotation`/`cancel`/`fail`
            // — none of the bytes ever live in heap.
            val isOther = session.metadata.conditionType == ConditionType.Generic

            val frameSizes = result.framePaths.map { fileSize(it) }

            val path = encryptedBundlePath(session.id).also { encryptedPath = it }
            val bundleSink = encryptor.openEncryptingSink(path)
            try {
                val tar = TarStoreSink(bundleSink)
                tar.addEntry("manifest.json", manifestBytes.size.toLong()) { s ->
                    s.write(manifestBytes, 0, manifestBytes.size)
                }
                tar.addEntry(manifest.imageFilename, photoSize) { s ->
                    readFileStreaming(result.photoPath, s)
                }
                for ((i, framePath) in result.framePaths.withIndex()) {
                    tar.addEntry(frameFilenames[i], frameSizes[i]) { s ->
                        readFileStreaming(framePath, s)
                    }
                }
                tar.finish()
            } finally {
                bundleSink.close()
            }

            store.insert(
                captureId = session.id,
                request = session.metadata.toRequest(session.id, deviceInfoSnapshot),
                encryptedPath = path,
            )
            persisted = true

            val transferId = transferManager.upload(path, session.id)
            store.updateTransferTaskId(session.id, transferId)
            // No store.updateStatus here — SdkCaptureUploadStatus is derived from
            // the linked TransferTask row, which TransferManager writes to.

            val entry = sessions[session.id]
            entry?.transferTaskId = transferId
            if (isOther) {
                session.setState(CaptureState.AwaitingAnnotation(result.photoPath))
            } else {
                session.setState(CaptureState.Uploading(progressPercent = 0))
            }
            mirrorTransferInto(session, transferId)
        } catch (e: Exception) {
            session.setState(
                CaptureState.Failed(
                    stage = FailureStage.Upload,
                    message = e.message ?: e::class.simpleName ?: "unknown",
                )
            )
            throw e
        } finally {
            // Raw artefacts have no further role once we've either built the encrypted
            // bundle (success) or decided the capture is dead (failure). The encrypted
            // bundle is what recovery uses, not the raw files.
            //
            // Exception: a successfully-bundled Generic capture still needs
            // the reference photo on disk for the annotation editor — we
            // skip the workingDir delete here and clean up later in
            // `submitAnnotation` / `cancel` / `fail`.
            val keepWorkingDir = persisted &&
                session.metadata.conditionType == ConditionType.Generic
            if (!keepWorkingDir) deleteDirQuietly(session.workingDir)
            if (!persisted) encryptedPath?.let { deleteFileQuietly(it) }
        }
    }

    /**
     * devMode-only: list the server's demo catalog. The UI uses this
     * to render a picker when more than one entry exists; the
     * convenience [submitDemoCapture] path that auto-picks the first
     * entry is still available for callers that don't need a picker.
     */
    internal suspend fun listDemoCaptures(
        session: CaptureSession,
    ): List<DemoCaptureSummary> {
        val repo = demoRepoFor(session)
        return repo.listCatalog().map {
            DemoCaptureSummary(id = it.id, name = it.name)
        }
    }

    /**
     * devMode-only entry point used by the built-in CaptureScreen /
     * CaptureView "Use demo capture" buttons. Lists the server's demo
     * catalog, downloads the chosen entry's (or the first entry's, if
     * [entryId] is `null`) photo + frames into
     * [CaptureSession.workingDir], and submits the resulting
     * [CaptureResult] through [submit].
     */
    internal suspend fun submitDemoCapture(
        session: CaptureSession,
        entryId: String?,
        onProgress: (downloaded: Int, total: Int) -> Unit,
    ) {
        val repo = demoRepoFor(session)
        val catalog = repo.listCatalog()
        if (catalog.isEmpty()) {
            throw DemoCaptureException("No demo captures available on the server")
        }
        val entry = if (entryId == null) {
            catalog.first()
        } else {
            catalog.firstOrNull { it.id == entryId }
                ?: throw DemoCaptureException("Unknown demo capture id: $entryId")
        }
        val result = repo.download(
            entry = entry,
            intoDir = session.workingDir,
            onProgress = onProgress,
        )
        submit(session, result)
    }

    private fun demoRepoFor(session: CaptureSession): DemoCaptureRepository {
        check(devMode) {
            "demo-capture APIs require TwinSkinConfig.devMode = true"
        }
        val client = serverClient
            ?: error("demo-capture APIs require a serverClient on CaptureApi")
        return DemoCaptureRepository(
            httpClient = client.client,
            baseUrl = client.baseUrl,
            publishableKey = client.publishableKey,
            auth = client.auth,
            subjectRef = session.metadata.subjectRef,
        )
    }

    /**
     * Submit a discriminated-union annotation for the captured subject.
     * Drives the session state machine:
     * [CaptureState.AwaitingAnnotation] → success
     * [CaptureState.AnnotationSubmitted] | failure
     * [CaptureState.AnnotationSubmitFailed].
     *
     * Failures expose a `retry` callback that re-invokes this method on
     * [scope] so the host can wire it directly to a retry button.
     */
    internal suspend fun submitAnnotation(session: CaptureSession, annotation: SdkAnnotation) {
        val client = serverClient
            ?: error("submitAnnotation requires a serverClient on CaptureApi")
        try {
            client.submitAnnotation(
                captureId = session.id,
                subjectRef = session.metadata.subjectRef,
                annotation = annotation,
            )
            store.markAnnotationSubmitted(session.id)
            // The reference photo lived in workingDir from submit() through
            // the editor session; once the annotation is on the server we no
            // longer need it on-device.
            deleteDirQuietly(session.workingDir)
            session.setState(CaptureState.AnnotationSubmitted)
            finish(session.id)
        } catch (t: Throwable) {
            session.setState(
                CaptureState.AnnotationSubmitFailed(
                    error = t,
                    retry = { scope.launch { submitAnnotation(session, annotation) } },
                )
            )
        }
    }

    internal suspend fun cancel(session: CaptureSession) {
        val entry = sessions[session.id] ?: return
        entry.mirrorJob?.cancel()
        val transferId = entry.transferTaskId
        if (transferId != null) {
            // The TransferTask flip to CANCELLED surfaces as
            // SdkCaptureUploadStatus.CANCELLED via the derived join.
            transferManager.cancelTask(transferId)
        } else {
            // Cancel ran before a TransferTask was enqueued (either before
            // submit() touched the store, or in the narrow window between
            // store.insert and store.updateTransferTaskId). Drop any orphan
            // SdkCaptureUpload row so recover() doesn't re-enqueue it.
            store.deleteById(session.id)
        }
        session.setState(CaptureState.Cancelled)
        deleteDirQuietly(session.workingDir)
        sessions.remove(session.id)
    }

    /**
     * Surface a non-recoverable capture-side failure to integrators without going
     * through [submit]. Used by the native capture flow when it can't produce a
     * usable result. Clears [CaptureSession.workingDir] and removes the session.
     */
    internal suspend fun fail(session: CaptureSession, reason: String) {
        val entry = sessions[session.id] ?: return
        entry.mirrorJob?.cancel()
        session.setState(CaptureState.Failed(stage = FailureStage.Upload, message = reason))
        deleteDirQuietly(session.workingDir)
        sessions.remove(session.id)
    }

    /**
     * Sweep-based recovery for captures interrupted by an app kill.
     *
     * Heals orphan rows — `SdkCaptureUpload` rows with `transferTaskId IS NULL`,
     * meaning the app died between `store.insert` and `transferManager.upload`.
     * These get re-enqueued from the persisted bundle path. Rows that already
     * have a `transferTaskId` are owned by [TransferManager.launchRecovery],
     * which resumes them via the TransferTask state machine — no separate
     * status fixup is needed here, because [SdkCaptureUploadStatus] is derived
     * from the joined `TransferTask.status`.
     *
     * Safe to call repeatedly.
     */
    suspend fun recover() {
        for (record in store.findOrphans()) {
            val transferId = transferManager.upload(record.encryptedPath, record.captureId)
            store.updateTransferTaskId(record.captureId, transferId)
        }
    }

    /**
     * Fire-and-forget recovery called from `TwinSkinSdk.initialize`. Heals the
     * [SdkCaptureStore] table first (orphan captures missing a TransferTask row,
     * see [recover]), then kicks [TransferManager.launchRecovery] to reset any
     * ACTIVE uploads and retry PENDING ones. Ordering matters: step 1 restores
     * the invariant "every pending capture has a TransferTask" so step 2 sees
     * a consistent view.
     */
    fun launchRecoveryAll() {
        scope.launch {
            recover()
            transferManager.launchRecovery()
        }
    }

    /**
     * Mirror the [TransferTask] state into the in-memory [CaptureSession.state]
     * so the foreground UI (snackbars, capture screen) sees byte-level progress
     * and terminal transitions. Lives only for the life of the [CaptureSession]
     * — `observePendingUploads` does not depend on this; it reads
     * [SdkCaptureUploadStatus] derived from the same TransferTask row, which
     * keeps working even if this mirror was never attached (e.g. after a
     * process kill, on the next launch).
     */
    private fun mirrorTransferInto(session: CaptureSession, transferTaskId: String) {
        val entry = sessions[session.id] ?: return
        val isOther = session.metadata.conditionType == ConditionType.Generic
        entry.mirrorJob = transferManager.observeTask(transferTaskId)
            .onEach { task ->
                if (task == null) return@onEach
                when (TransferStatus.valueOf(task.status)) {
                    TransferStatus.PENDING,
                    TransferStatus.ACTIVE,
                    TransferStatus.UNZIPPING -> {
                        // Other sits in AwaitingAnnotation from the moment
                        // submit() returns; don't overwrite it with
                        // intermediate upload progress.
                        if (!isOther) {
                            session.setState(CaptureState.Uploading(task.progress.toInt()))
                        }
                    }
                    TransferStatus.COMPLETED -> {
                        if (isOther) {
                            // AwaitingAnnotation already emitted on submit.
                            // Stop reacting to transfer status; keep the
                            // session entry alive so submitAnnotation can
                            // drive it.
                            sessions[session.id]?.mirrorJob?.cancel()
                            sessions[session.id]?.mirrorJob = null
                        } else {
                            session.setState(CaptureState.Uploaded)
                            finish(session.id)
                        }
                    }
                    TransferStatus.CANCELLED -> {
                        session.setState(CaptureState.Cancelled)
                        // Other captures preserved workingDir for the
                        // annotation editor; clean it up now that we're
                        // bailing without an annotation submission.
                        if (isOther) deleteDirQuietly(session.workingDir)
                        finish(session.id)
                    }
                    TransferStatus.FAILED -> {
                        session.setState(
                            CaptureState.Failed(
                                stage = FailureStage.Upload,
                                message = task.errorMessage ?: "upload failed",
                            )
                        )
                        if (isOther) deleteDirQuietly(session.workingDir)
                        finish(session.id)
                    }
                }
            }
            .launchIn(scope)
    }

    private fun finish(sessionId: String) {
        sessions.remove(sessionId)?.mirrorJob?.cancel()
    }
}

private fun requirePathInside(dir: String, path: String, paramName: String) {
    val normalizedDir = dir.trimEnd('/')
    require(path.startsWith("$normalizedDir/")) {
        "$paramName must live inside session.workingDir ($normalizedDir), got: $path"
    }
}

private fun randomCaptureId(): String {
    val bytes = ByteArray(12).also { secureRandomBytes(it) }
    return "tsc_" + bytes.joinToString("") { it.toUByte().toString(16).padStart(2, '0') }
}
