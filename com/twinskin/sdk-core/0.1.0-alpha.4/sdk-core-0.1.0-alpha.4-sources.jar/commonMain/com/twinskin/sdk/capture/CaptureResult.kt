package com.twinskin.sdk.capture

/**
 * Hand-off from the platform-native capture flow to [CaptureSession.submit].
 *
 * All paths must point inside [CaptureSession.workingDir] — the SDK rejects
 * paths outside that directory so drift between native and shared sides is caught
 * at submit time rather than as a confusing failure deeper in the bundle pipeline.
 *
 * [photoPath] is the reference still (used as the annotation canvas for `Other`
 * captures and as the main photogrammetry image). [framePaths] is the burst of
 * scan frames in capture order — the bundle manifest's `image_frames` list
 * preserves the order. Each path's basename is the filename embedded in the
 * bundle tar; the SDK normalises HEIC → JPG server-side, so the SDK accepts
 * either `.jpg` or `.heic` here.
 *
 * [markerVersion] is forwarded verbatim into the bundle manifest. The server's
 * `MarkerVersionType` enum (currently `v1` / `v2` / `v3`) is the source of truth
 * for valid values; passing an unknown string surfaces as a server-side validation
 * error on decode. `null` means the native flow did not detect a marker.
 */
public data class CaptureResult(
    val photoPath: String,
    val framePaths: List<String>,
    val markerVersion: String?,
)
