@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.annotation_editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Horizontal swatch row for picking the in-progress polygon color.
 * Selecting a color updates [PolygonEditorState.selectColor]; the
 * selected swatch is rendered with a thicker border.
 */
@Composable
internal fun PolygonEditorPalette(
    state: PolygonEditorState,
    modifier: Modifier = Modifier,
    palette: List<String> = PolygonEditorState.DEFAULT_PALETTE,
) {
    Surface(
        modifier = modifier,
        color = Color.Black.copy(alpha = 0.4f),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            for (hex in palette) {
                val selected = state.selectedColor.equals(hex, ignoreCase = true)
                ColorSwatch(
                    hex = hex,
                    selected = selected,
                    onClick = { state.selectColor(hex) },
                )
            }
        }
    }
}

@Composable
internal fun ColorSwatch(
    hex: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val color = parseHexColor(hex)
    androidx.compose.foundation.layout.Box(
        modifier = modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(color)
            .border(
                width = if (selected) 3.dp else 1.dp,
                color = if (selected) Color.White else Color.White.copy(alpha = 0.6f),
                shape = CircleShape,
            )
            .pointerInput(hex) {
                detectTapGestures(onTap = { onClick() })
            },
    )
}

/**
 * Parse a CSS-style `#RRGGBB` (or `#AARRGGBB`) string into a Compose
 * [Color]. Falls back to opaque magenta on malformed input so a bad
 * value is visually obvious instead of crashing the editor.
 */
internal fun parseHexColor(hex: String): Color {
    val cleaned = hex.removePrefix("#")
    return try {
        when (cleaned.length) {
            6 -> {
                val v = cleaned.toLong(16)
                Color(
                    red = ((v shr 16) and 0xFF).toInt() / 255f,
                    green = ((v shr 8) and 0xFF).toInt() / 255f,
                    blue = (v and 0xFF).toInt() / 255f,
                    alpha = 1f,
                )
            }
            8 -> {
                val v = cleaned.toLong(16)
                Color(
                    alpha = ((v shr 24) and 0xFF).toInt() / 255f,
                    red = ((v shr 16) and 0xFF).toInt() / 255f,
                    green = ((v shr 8) and 0xFF).toInt() / 255f,
                    blue = (v and 0xFF).toInt() / 255f,
                )
            }
            else -> Color.Magenta
        }
    } catch (_: NumberFormatException) {
        Color.Magenta
    }
}
