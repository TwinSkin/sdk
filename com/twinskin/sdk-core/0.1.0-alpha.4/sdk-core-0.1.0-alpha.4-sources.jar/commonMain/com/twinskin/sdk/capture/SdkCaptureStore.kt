package com.twinskin.sdk.capture

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.sdk_client.SdkDeviceInfo
import com.twinskin.sdk.sdk_client.SdkStartCaptureRequest
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.currentTimeMillis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/**
 * Durable record written when a capture's encrypted bundle has been
 * materialized on disk and is ready to hand off to the transfer manager.
 *
 * Stores everything needed to re-call `POST /upload/start-capture` (the
 * server's idempotent entry point) so we can mint a fresh presigned PUT
 * URL whenever the TransferManager's URL resolver is asked to refresh
 * one.
 *
 * [status] is **derived** from the linked [TransferTask] row at read
 * time — there is no status column on this table. See [SdkCaptureStore]
 * for the mapping.
 */
internal data class SdkCaptureUploadRecord(
    val captureId: String,
    val request: SdkStartCaptureRequest,
    val encryptedPath: String,
    val status: SdkCaptureUploadStatus,
    val transferTaskId: String?,
    /**
     * Byte-level upload progress 0..100 from the joined [TransferTask.progress]
     * column, or null when no TransferTask row exists yet (PENDING_UPLOAD).
     * Updated by [TransferManager] in response to per-attempt
     * [TransferUpdate.Progress] callbacks from the platform provider.
     */
    val transferProgressPercent: Int?,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
)

/**
 * Public-facing capture upload status. Derived from the [TransferTask]
 * row joined on [SdkCaptureUploadRecord.transferTaskId]; the SDK does
 * not store this value. See [SdkCaptureStore.deriveStatus] for the rule.
 */
internal enum class SdkCaptureUploadStatus {
    /** Bundle is on disk; no [TransferTask] row exists yet (transferTaskId IS NULL). */
    PENDING_UPLOAD,
    /** TransferTask is in PENDING / ACTIVE / UNZIPPING. */
    UPLOADING,
    /** TransferTask is COMPLETED — or has been deleted by clearCompleted. */
    COMPLETED,
    /** TransferTask is FAILED. */
    FAILED,
    /** TransferTask is CANCELLED. */
    CANCELLED,
}

/**
 * Thin typed wrapper over the SQLDelight `SdkCaptureUpload` queries.
 *
 * Reads join with `TransferTask` to derive the public
 * [SdkCaptureUploadStatus]. The store has no `updateStatus` API — status
 * is owned by the TransferManager (which writes [TransferStatus]) and
 * surfaced here read-only.
 */
internal class SdkCaptureStore(
    private val database: TwinSkinDatabase,
    private val clock: () -> Long = ::currentTimeMillis,
    private val json: Json = Json,
) {
    private val captureQueries get() = database.sdkCaptureUploadQueries
    private val transferQueries get() = database.transferTaskQueries

    fun insert(
        captureId: String,
        request: SdkStartCaptureRequest,
        encryptedPath: String,
    ): SdkCaptureUploadRecord {
        val now = clock()
        // ConditionType.Generic captures gate upload-completion cleanup of
        // the on-device reference image on this flag — see CaptureApi
        // for the gating rule.
        val annotationPending = if (request.conditionType == ConditionType.Generic) 1L else 0L
        captureQueries.insert(
            captureId = captureId,
            userRef = request.userRef,
            subjectRef = request.subjectRef,
            conditionType = request.conditionType.toWireValue(),
            captureGroup = request.captureGroup,
            bodyLocationJson = request.bodyLocation?.let { json.encodeToString(it) },
            customJson = request.custom?.let { json.encodeToString(JsonObject(it)) },
            deviceInfoJson = request.deviceInfo?.let { json.encodeToString(it) },
            encryptedPath = encryptedPath,
            transferTaskId = null,
            annotationPending = annotationPending,
            createdAt = now,
            updatedAt = now,
        )
        return SdkCaptureUploadRecord(
            captureId = captureId,
            request = request,
            encryptedPath = encryptedPath,
            status = SdkCaptureUploadStatus.PENDING_UPLOAD,
            transferTaskId = null,
            transferProgressPercent = null,
            createdAtEpochMs = now,
            updatedAtEpochMs = now,
        )
    }

    fun findById(captureId: String): SdkCaptureUploadRecord? {
        val upload = captureQueries.selectById(captureId).executeAsOneOrNull() ?: return null
        val transfer = upload.transferTaskId?.let { id ->
            transferQueries.selectById(id).executeAsOneOrNull()
        }
        return upload.toRecord(transferStatus = transfer?.status, transferProgress = transfer?.progress)
    }

    /**
     * Captures whose `transferTaskId IS NULL` — the app died between
     * `insert` and `transferManager.upload`. Recovery re-enqueues these.
     */
    fun findOrphans(): List<SdkCaptureUploadRecord> =
        captureQueries.selectOrphans().executeAsList()
            .map { it.toRecord(transferStatus = null, transferProgress = null) }

    /**
     * Observe every row in the upload table joined with its
     * [TransferTask], sorted by creation time (newest first). Re-emits
     * whenever any row in either table is inserted, updated, or deleted.
     * The join happens in Kotlin; subscribing to both SQLDelight queries
     * (rather than a SQL JOIN) keeps the schema queries trivially
     * verifiable and lets each table's change-notifications drive
     * re-derivation independently.
     */
    fun observeAll(): Flow<List<SdkCaptureUploadRecord>> =
        combine(
            captureQueries.selectAll().asFlow().mapToList(Dispatchers.Default),
            transferQueries.selectAll().asFlow().mapToList(Dispatchers.Default),
        ) { uploads, transfers ->
            val transfersById = transfers.associateBy { it.id }
            uploads.map { upload ->
                val transfer = transfersById[upload.transferTaskId]
                upload.toRecord(
                    transferStatus = transfer?.status,
                    transferProgress = transfer?.progress,
                )
            }
        }

    fun updateTransferTaskId(captureId: String, transferTaskId: String?) {
        captureQueries.updateTransferTaskId(transferTaskId, clock(), captureId)
    }

    /**
     * True while the capture is a [ConditionType.Generic] flow that has
     * not yet had a successful [CaptureSession.submitAnnotation]. Returns
     * false for Wound captures and for any unknown id.
     */
    fun isAnnotationPending(captureId: String): Boolean =
        (captureQueries.selectAnnotationPending(captureId).executeAsOneOrNull() ?: 0L) != 0L

    /** Flip the annotation-pending flag off after a successful annotation submission. */
    fun markAnnotationSubmitted(captureId: String) {
        captureQueries.updateAnnotationPending(0L, clock(), captureId)
    }

    fun deleteById(captureId: String) {
        captureQueries.deleteById(captureId)
    }

    private fun ConditionType.toWireValue(): String = when (this) {
        ConditionType.Wound -> "wound"
        ConditionType.Generic -> "generic"
    }

    private fun String?.toConditionType(): ConditionType = when (this) {
        // Legacy rows written before [ConditionType] became typed.
        // The historical default supplied by every demo host was "wound",
        // so missing data is treated as wound rather than failing recovery.
        null, "wound" -> ConditionType.Wound
        "generic" -> ConditionType.Generic
        else -> error("unknown conditionType wire value: $this")
    }

    private fun com.twinskin.sdk.db.SdkCaptureUpload.toRecord(
        transferStatus: String?,
        transferProgress: Long?,
    ): SdkCaptureUploadRecord {
        val bodyLocation = bodyLocationJson?.let {
            json.decodeFromString<List<String>>(it)
        }
        val custom = customJson?.let {
            json.decodeFromString<Map<String, JsonElement>>(it)
        }
        val deviceInfo = deviceInfoJson?.let {
            json.decodeFromString<SdkDeviceInfo>(it)
        }
        return SdkCaptureUploadRecord(
            captureId = captureId,
            request = SdkStartCaptureRequest(
                userRef = userRef,
                subjectRef = subjectRef,
                captureId = captureId,
                conditionType = conditionType.toConditionType(),
                captureGroup = captureGroup,
                bodyLocation = bodyLocation,
                custom = custom,
                deviceInfo = deviceInfo,
            ),
            encryptedPath = encryptedPath,
            status = deriveStatus(transferTaskId, transferStatus),
            transferTaskId = transferTaskId,
            transferProgressPercent = transferProgress?.toInt(),
            createdAtEpochMs = createdAt,
            updatedAtEpochMs = updatedAt,
        )
    }

    companion object {
        /**
         * Map (transferTaskId, joined TransferTask.status) to the public
         * [SdkCaptureUploadStatus]. Single source of truth for the
         * derivation; tests and observers go through here.
         *
         *  - `transferTaskId == null` → `PENDING_UPLOAD` (capture row exists,
         *    no transfer was ever enqueued).
         *  - `transferTaskId` set, but the TransferTask row is gone (e.g.
         *    `clearCompleted` ran) → `COMPLETED`. The row only ever gets
         *    deleted from a terminal state, and treating it as COMPLETED
         *    drops it from `observePendingUploads` — the closest behavior
         *    to "success silently went away".
         *  - Otherwise the TransferStatus name maps directly.
         */
        fun deriveStatus(
            transferTaskId: String?,
            transferStatus: String?,
        ): SdkCaptureUploadStatus {
            if (transferTaskId == null) return SdkCaptureUploadStatus.PENDING_UPLOAD
            if (transferStatus == null) return SdkCaptureUploadStatus.COMPLETED
            return when (TransferStatus.valueOf(transferStatus)) {
                TransferStatus.PENDING,
                TransferStatus.ACTIVE,
                TransferStatus.UNZIPPING -> SdkCaptureUploadStatus.UPLOADING
                TransferStatus.COMPLETED -> SdkCaptureUploadStatus.COMPLETED
                TransferStatus.FAILED -> SdkCaptureUploadStatus.FAILED
                TransferStatus.CANCELLED -> SdkCaptureUploadStatus.CANCELLED
            }
        }
    }
}
