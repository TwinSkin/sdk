@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.view.LoadProgress

/**
 * Stage-agnostic loading view. Renders a determinate bar when [progress]
 * carries a fraction (download byte ratio), a spinner otherwise.
 * Intentionally does not surface stage labels like "Authorizing" to end
 * users — the stages exist as [LoadProgress] variants for tests, logs,
 * and integrator-visible error copy, not as UX noise.
 */
@TwinSkinInternalApi
@Composable
public fun ViewCaptureLoadingView(progress: LoadProgress) {
    val fraction = progress.determinateFraction()
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (fraction != null) {
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.width(240.dp),
            )
        } else {
            CircularProgressIndicator()
        }
        Spacer(Modifier.height(16.dp))
        Text("Loading…", style = MaterialTheme.typography.bodyMedium)
    }
}

private fun LoadProgress.determinateFraction(): Float? = when (this) {
    is LoadProgress.Downloading -> total?.let {
        if (it > 0) (bytesRead.toFloat() / it.toFloat()).coerceIn(0f, 1f) else null
    }
    LoadProgress.Indeterminate,
    LoadProgress.ResolvingCredentials,
    LoadProgress.ResolvingMetadata,
    -> null
}
