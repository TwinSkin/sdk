package com.twinskin.sdk.ui.annotation_editor

import com.twinskin.sdk.TwinSkinInternalApi

/**
 * Shared editing surface backing both [GenericAnnotationEditor] and
 * [WoundAnnotationEditor]. The two concrete state classes differ only
 * in the wire type they convert to/from at the boundary; the in-memory
 * editing model is identical (multi-polygon, color-tagged).
 *
 * Coordinates in [EditorPoint] are normalized to the reference image's
 * 0..1 space.
 *
 * The interaction model is finger-drag: a stroke begins on
 * [startStroke], accumulates via [extendStroke], and is committed (or
 * dropped if too small) on [endStroke].
 */
@TwinSkinInternalApi
public interface PolygonEditorState {
    public val regions: List<EditorRegion>
    public val inProgressPoints: List<EditorPoint>
    public val selectedColor: String
    public fun startStroke(x: Double, y: Double)
    public fun extendStroke(x: Double, y: Double)
    public fun endStroke()
    public fun deleteRegion(index: Int)
    public fun setRegionColor(index: Int, color: String)
    public fun selectColor(color: String)

    public companion object {
        public val DEFAULT_PALETTE: List<String> = listOf(
            "#FF6F61", "#6FA8FF", "#A0E060", "#FFD060", "#C060E0", "#60E0E0",
        )
    }
}
