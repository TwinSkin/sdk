// GENERATED FROM ../capture_pipeline/src/models/json_schema.json ($defs.SdkCaptureManifest) — DO NOT EDIT.
// Regenerate with `fvm dart run tool/generate_external_data_models.dart`
// from `packages/server/`.
package com.twinskin.sdk.capture

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonClassDiscriminator

@Serializable
internal data class CaptureManifest(
    @SerialName("capture_id") val captureId: String,
    @SerialName("sdk_version") val sdkVersion: String,
    @SerialName("capture_timestamp") val captureTimestamp: String,
    @SerialName("image_filename") val imageFilename: String,
    @SerialName("image_frames") val imageFrames: List<SdkFrameEntry>,
    @SerialName("marker_version") val markerVersion: String? = null
)

@Serializable
internal data class SdkFrameEntry(
    @SerialName("filename") val filename: String
)
