@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.view

import com.twinskin.sdk.SdkLogger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext

/**
 * Public handle returned by [com.twinskin.sdk.TwinSkinSdk.viewCapture].
 *
 * Subscribes to a [CaptureResolver] and translates its event stream into the
 * [ViewCaptureState] that the Compose screen observes. Safe to close multiple
 * times; safe to ignore if the screen observes [state] directly.
 *
 * The constructor is public so advanced integrators (and test/demo code) can
 * wrap their own [CaptureResolver] implementations. The ordinary path is
 * [com.twinskin.sdk.TwinSkinSdk.viewCapture] — use this constructor only when
 * you want to bypass source-to-resolver mapping.
 */
public class ViewCaptureSession(
    private val resolver: CaptureResolver,
    context: CoroutineContext = Dispatchers.Default,
    private val logger: SdkLogger? = null,
) {
    private val scope = CoroutineScope(context + SupervisorJob())

    private val _state = MutableStateFlow<ViewCaptureState>(
        ViewCaptureState.Loading(LoadProgress.Indeterminate)
    )
    public val state: StateFlow<ViewCaptureState> = _state.asStateFlow()

    private val job: Job = scope.launch {
        var hasResolvedOnce = false
        resolver.resolve()
            .catch { cause ->
                val error = classify(cause)
                logger?.log("viewCapture flow failed → $error", cause)
                _state.value = ViewCaptureState.Error(error)
            }
            .onCompletion {
                // A reactive resolver keeps streaming; a one-shot resolver
                // completes once the terminal Resolved has been emitted. Either
                // way, clear the isStreaming flag on completion.
                val current = _state.value
                if (current is ViewCaptureState.Ready && current.isStreaming) {
                    _state.value = current.copy(isStreaming = false)
                }
            }
            .collect { event ->
                when (event) {
                    is ResolverEvent.Progress -> {
                        if (!hasResolvedOnce) {
                            _state.value = ViewCaptureState.Loading(event.progress)
                        }
                    }
                    is ResolverEvent.Resolved -> {
                        val capture = event.capture
                        // Ready needs at least one renderable surface.
                        // Until then, we're still resolving metadata.
                        _state.value = if (capture.model == null && capture.image2D == null) {
                            ViewCaptureState.Loading(LoadProgress.ResolvingMetadata)
                        } else {
                            ViewCaptureState.Ready(
                                asset = capture.model,
                                image2D = capture.image2D,
                                annotation = capture.annotation,
                                measurement = capture.measurement,
                                metadata = capture.metadata,
                                isStreaming = !hasResolvedOnce, // reset later on completion
                            )
                        }
                        hasResolvedOnce = true
                    }
                }
            }
    }

    public fun close() {
        scope.cancel()
    }
}

private fun classify(cause: Throwable): ViewCaptureError = when (cause) {
    is kotlinx.coroutines.CancellationException -> throw cause
    is CaptureCredentialsException -> ViewCaptureError.Credentials(cause.cause ?: cause)
    is CaptureNetworkException -> ViewCaptureError.Network
    is CaptureNotFoundException -> ViewCaptureError.NotFound
    is CaptureInvalidAssetException -> ViewCaptureError.InvalidAsset(cause.reason)
    else -> if (looksLikeNetworkException(cause)) ViewCaptureError.Network
            else ViewCaptureError.Unknown(cause)
}

/**
 * Best-effort classification of raw network / IO failures thrown from inside
 * resolvers (timeouts, DNS failures, connection refused, dropped connections).
 *
 * Done by fully-qualified name rather than `is IOException` because the
 * relevant exception hierarchy differs per platform (Android: `java.io.IOException`
 * and sub-classes; iOS: ktor-darwin wraps `NSError` into its own type) and we
 * don't want to pull platform-specific types into commonMain or duplicate the
 * classifier per actual. Keeps working across ktor version bumps because it
 * only matches on stable public package prefixes.
 */
private fun looksLikeNetworkException(cause: Throwable): Boolean {
    var current: Throwable? = cause
    while (current != null) {
        val name = current::class.qualifiedName ?: current::class.simpleName ?: ""
        when {
            name.endsWith("IOException") -> return true
            name.endsWith("UnknownHostException") -> return true
            name.endsWith("SocketException") -> return true
            name.endsWith("SocketTimeoutException") -> return true
            name.endsWith("ConnectTimeoutException") -> return true
            name.endsWith("HttpRequestTimeoutException") -> return true
            name.endsWith("DarwinHttpRequestException") -> return true
        }
        current = current.cause
    }
    return false
}
