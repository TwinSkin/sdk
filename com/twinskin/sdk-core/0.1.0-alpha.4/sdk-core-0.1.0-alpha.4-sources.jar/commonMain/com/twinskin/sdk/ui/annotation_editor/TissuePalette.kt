package com.twinskin.sdk.ui.annotation_editor

import com.twinskin.sdk.TwinSkinInternalApi

/**
 * Maps a wound `TissueRegion.tissueType` string to a hex color used
 * to render that tissue's contour on top of the wound region. The
 * three clinically meaningful types get fixed colors; anything else
 * (including unknown strings, the empty string, or whitespace) falls
 * back to a neutral gray so the contour is still rendered — the
 * editor's job is to show what's there, not to silently drop data.
 *
 * Match is case-insensitive. The hex strings are the format
 * [parseHexColor] expects elsewhere in the editor.
 */
@TwinSkinInternalApi
public fun colorForTissueType(tissueType: String): String =
    when (tissueType.trim().lowercase()) {
        "necrosis" -> "#1A1A1A"
        "slough" -> "#E5C100"
        "granulation" -> "#D03A3A"
        else -> "#808080"
    }
