@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.annotation_editor

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp

/**
 * Multi-polygon wound annotation editor (content-only). Same tap-to-trace
 * flow as [GenericAnnotationEditor] but each finalized polygon serializes
 * as a [com.twinskin.sdk.capture.WoundRegion] with an empty tissues list.
 * The proper wound UX (single contour with nested tissues) replaces this
 * entirely in a follow-up. Hoist [state] in the caller and wrap in an
 * [AnnotationEditorScaffold] (or other chrome) — see GenericAnnotationEditor.
 */
@TwinSkinInternalApi
@Composable
public fun WoundAnnotationEditor(
    image: ImageBitmap,
    state: WoundAnnotationEditorState,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black),
    ) {
        Image(
            bitmap = image,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit,
        )

        PolygonEditorCanvas(state = state)

        PolygonEditorPalette(
            state = state,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp),
        )

        if (state.regions.isNotEmpty()) {
            PolygonEditorRegionStrip(
                state = state,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }

        if (state.regions.isEmpty() && state.inProgressPoints.isEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Text(
                    "Drag to trace a polygon. Release to close.",
                    color = Color.White,
                )
            }
        }
    }
}
