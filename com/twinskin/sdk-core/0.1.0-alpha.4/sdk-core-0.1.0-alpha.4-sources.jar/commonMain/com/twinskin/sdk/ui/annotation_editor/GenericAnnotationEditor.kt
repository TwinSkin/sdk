@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.annotation_editor

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp

/**
 * Multi-polygon generic annotation editor (content-only).
 *
 * Hoist [state] in the caller and wrap this composable in an
 * [AnnotationEditorScaffold] (or any other chrome) — the editor itself
 * does not provide a Cancel/Done bar so it composes cleanly under any
 * host. v1 deliberately minimal — no edit of existing polygon points, no
 * undo, no curves, no zoom/pan. Coordinates are normalized into the
 * reference image's 0..1 space so the annotation survives image resize.
 */
@TwinSkinInternalApi
@Composable
public fun GenericAnnotationEditor(
    image: ImageBitmap,
    state: GenericAnnotationEditorState,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black),
    ) {
        Image(
            bitmap = image,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit,
        )

        PolygonEditorCanvas(state = state)

        PolygonEditorPalette(
            state = state,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp),
        )

        if (state.regions.isNotEmpty()) {
            PolygonEditorRegionStrip(
                state = state,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }

        if (state.regions.isEmpty() && state.inProgressPoints.isEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Text(
                    "Drag to trace a polygon. Release to close.",
                    color = Color.White,
                )
            }
        }
    }
}
