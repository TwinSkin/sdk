@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.view.ViewCaptureError

/** Pure function of [error]. Snapshot one per variant; retry only for recoverable cases. */
@TwinSkinInternalApi
@Composable
public fun ViewCaptureErrorView(
    error: ViewCaptureError,
    onRetry: () -> Unit,
) {
    val icon: ImageVector
    val title: String
    val message: String
    val retryable: Boolean
    when (error) {
        ViewCaptureError.Network -> {
            icon = Icons.Default.CloudOff
            title = "Can't reach server"
            message = "Check your connection and try again."
            retryable = true
        }
        ViewCaptureError.NotFound -> {
            icon = Icons.Default.SearchOff
            title = "Capture not found"
            message = "This capture is unavailable or has been removed."
            retryable = false
        }
        is ViewCaptureError.Credentials -> {
            icon = Icons.Default.Lock
            title = "Couldn't get credentials"
            message = error.cause.message
                ?: "The integrator backend didn't return valid credentials for this asset."
            retryable = true
        }
        is ViewCaptureError.InvalidAsset -> {
            icon = Icons.Default.ErrorOutline
            title = "Asset unreadable"
            message = error.reason
            retryable = false
        }
        is ViewCaptureError.Unknown -> {
            icon = Icons.Default.ErrorOutline
            title = "Something went wrong"
            message = error.cause.message ?: error.cause::class.simpleName.orEmpty()
            retryable = true
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = MaterialTheme.colorScheme.error,
        )
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (retryable) {
            Spacer(Modifier.height(20.dp))
            Button(onClick = onRetry) { Text("Retry") }
        }
    }
}
