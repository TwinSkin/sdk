@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.ui.view_capture.renderer.Model3DViewer
import com.twinskin.sdk.view.Asset3D
import com.twinskin.sdk.view.Image2DAsset
import com.twinskin.sdk.view.ViewCaptureState

/**
 * Renders whichever pane(s) the resolved capture provides. Three layouts:
 *  - 3D-only: `Model3DViewer + MetadataPanel` (the original viewer).
 *  - 2D-only: `ViewCapture2DPane` (image + outline overlay + measurement).
 *  - Both:    a `TabRow` lets the user switch between the two.
 */
@TwinSkinInternalApi
@Composable
public fun ViewCaptureReadyView(
    ready: ViewCaptureState.Ready,
    onEditContour: (() -> Unit)? = null,
    isSavingAnnotation: Boolean = false,
) {
    val asset = ready.asset
    val image2D = ready.image2D
    when {
        asset != null && image2D != null -> TabbedReady(
            ready = ready,
            onEditContour = onEditContour,
            isSavingAnnotation = isSavingAnnotation,
        )
        asset != null -> SingleReady3D(asset = asset, ready = ready)
        image2D != null -> SingleReady2D(
            image2D = image2D,
            ready = ready,
            onEditContour = onEditContour,
            isSavingAnnotation = isSavingAnnotation,
        )
        // ViewCaptureState.Ready's init guarantees we never get here.
    }
}

@Composable
private fun TabbedReady(
    ready: ViewCaptureState.Ready,
    onEditContour: (() -> Unit)?,
    isSavingAnnotation: Boolean,
) {
    var selected by remember { mutableStateOf(0) }
    Column(modifier = Modifier.fillMaxSize()) {
        PrimaryTabRow(selectedTabIndex = selected) {
            Tab(selected = selected == 0, onClick = { selected = 0 }, text = { Text("3D") })
            Tab(selected = selected == 1, onClick = { selected = 1 }, text = { Text("2D") })
        }
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            when (selected) {
                0 -> Pane3D(asset = ready.asset!!)
                else -> ViewCapture2DPane(
                    image2D = ready.image2D,
                    annotation = ready.annotation,
                    measurement = ready.measurement,
                    onEditContour = onEditContour,
                    isSavingAnnotation = isSavingAnnotation,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        if (ready.metadata.isNotEmpty()) {
            MetadataPanel(metadata = ready.metadata, modifier = Modifier.heightIn(max = 200.dp))
        }
    }
}

@Composable
private fun SingleReady3D(
    asset: Asset3D,
    ready: ViewCaptureState.Ready,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            Pane3D(asset = asset)
        }
        if (ready.metadata.isNotEmpty()) {
            MetadataPanel(
                metadata = ready.metadata,
                modifier = Modifier.heightIn(max = 240.dp),
            )
        }
    }
}

@Composable
private fun SingleReady2D(
    image2D: Image2DAsset,
    ready: ViewCaptureState.Ready,
    onEditContour: (() -> Unit)?,
    isSavingAnnotation: Boolean,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxWidth().weight(1f)) {
            ViewCapture2DPane(
                image2D = image2D,
                annotation = ready.annotation,
                measurement = ready.measurement,
                onEditContour = onEditContour,
                isSavingAnnotation = isSavingAnnotation,
                modifier = Modifier.fillMaxSize(),
            )
        }
        if (ready.metadata.isNotEmpty()) {
            MetadataPanel(metadata = ready.metadata, modifier = Modifier.heightIn(max = 240.dp))
        }
    }
}

@Composable
private fun Pane3D(asset: Asset3D) {
    Model3DViewer(
        asset = asset,
        modifier = Modifier.fillMaxSize(),
    )
}
