@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.annotation_editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Bottom strip showing one chip per finalized region. Each chip
 * renders a tiny outline preview, exposes a delete (×) button, and
 * tapping the swatch opens a popover for picking a new color.
 */
@Composable
internal fun PolygonEditorRegionStrip(
    state: PolygonEditorState,
    modifier: Modifier = Modifier,
    palette: List<String> = PolygonEditorState.DEFAULT_PALETTE,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color.Black.copy(alpha = 0.55f),
    ) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            itemsIndexed(state.regions) { index, region ->
                RegionChip(
                    region = region,
                    palette = palette,
                    onDelete = { state.deleteRegion(index) },
                    onColor = { state.setRegionColor(index, it) },
                )
            }
        }
    }
}

@Composable
private fun RegionChip(
    region: EditorRegion,
    palette: List<String>,
    onDelete: () -> Unit,
    onColor: (String) -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color.White.copy(alpha = 0.12f),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Color swatch — tap to recolor.
            Box {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(parseHexColor(region.color))
                        .border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape)
                        .pointerInput(region.color) {
                            detectTapGestures(onTap = { menuOpen = true })
                        },
                )
                DropdownMenu(
                    expanded = menuOpen,
                    onDismissRequest = { menuOpen = false },
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        for (hex in palette) {
                            ColorSwatch(
                                hex = hex,
                                selected = region.color.equals(hex, ignoreCase = true),
                                onClick = {
                                    onColor(hex)
                                    menuOpen = false
                                },
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.width(6.dp))
            RegionPreview(region = region, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(4.dp))
            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Delete region",
                    tint = Color.White,
                )
            }
        }
    }
}

@Composable
private fun RegionPreview(region: EditorRegion, modifier: Modifier = Modifier) {
    val color = parseHexColor(region.color)
    Canvas(modifier = modifier) {
        if (region.points.isEmpty()) return@Canvas
        val path = Path().apply {
            val first = region.points.first()
            moveTo(first.x.toFloat() * size.width, first.y.toFloat() * size.height)
            for (i in 1 until region.points.size) {
                val p = region.points[i]
                lineTo(p.x.toFloat() * size.width, p.y.toFloat() * size.height)
            }
            close()
        }
        drawPath(path = path, color = color.copy(alpha = 0.35f))
        drawPath(path = path, color = color, style = Stroke(width = 2f))
    }
}
