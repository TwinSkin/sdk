// GENERATED FROM ../capture_pipeline/src/models/json_schema.json ($defs.SdkAnnotation) — DO NOT EDIT.
// Regenerate with `fvm dart run tool/generate_external_data_models.dart`
// from `packages/server/`.
package com.twinskin.sdk.capture

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonClassDiscriminator

@Serializable
@JsonClassDiscriminator("type")
public sealed class SdkAnnotation

@Serializable
public data class Point2D(
    @SerialName("x") val x: Double,
    @SerialName("y") val y: Double
)

@Serializable
public data class TissueRegion(
    @SerialName("tissue_type") val tissueType: String,
    @SerialName("contour") val contour: List<Point2D>
)

@Serializable
public data class WoundRegion(
    @SerialName("contour") val contour: List<Point2D>,
    @SerialName("tissues") val tissues: List<TissueRegion>
)

@Serializable
@SerialName("generic")
public data class GenericAnnotation(
    @SerialName("regions") val regions: List<GenericRegion>
) : SdkAnnotation()

@Serializable
public data class GenericRegion(
    @SerialName("points") val points: List<Point2D>,
    @SerialName("color") val color: String
)

@Serializable
@SerialName("wound")
public data class WoundAnnotation(
    @SerialName("regions") val regions: List<WoundRegion>
) : SdkAnnotation()
