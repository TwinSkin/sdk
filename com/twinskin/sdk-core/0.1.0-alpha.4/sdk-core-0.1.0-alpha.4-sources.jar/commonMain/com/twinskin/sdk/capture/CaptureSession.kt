package com.twinskin.sdk.capture

import com.twinskin.sdk.sdk_client.SdkDeviceInfo
import com.twinskin.sdk.sdk_client.SdkStartCaptureRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

/**
 * The kind of subject being captured. Required at session start so the
 * server can pick the correct downstream pipeline. Wire format mirrors
 * the server's `SdkConditionType` enum: `wound` | `generic`.
 */
@Serializable
public enum class ConditionType {
    @SerialName("wound") Wound,
    @SerialName("generic") Generic,
}

/**
 * Customer-supplied metadata required to start a capture on the server.
 * Mirrors the fields of `POST /api/sdk/upload/start-capture`.
 */
public data class SdkCaptureMetadata(
    val userRef: String,
    val subjectRef: String,
    val conditionType: ConditionType,
    val captureGroup: String? = null,
    val bodyLocation: List<String>? = null,
    val custom: Map<String, JsonElement>? = null,
) {
    internal fun toRequest(captureId: String, deviceInfo: SdkDeviceInfo?): SdkStartCaptureRequest =
        SdkStartCaptureRequest(
            userRef = userRef,
            subjectRef = subjectRef,
            captureId = captureId,
            conditionType = conditionType,
            captureGroup = captureGroup,
            bodyLocation = bodyLocation,
            custom = custom,
            deviceInfo = deviceInfo,
        )
}

/**
 * Represents one in-flight capture. Returned by [CaptureApi.startCapture].
 *
 * Observe [state] to follow the full lifecycle, or call [submit] / [cancel] /
 * [fail] to drive it. Submit is one-shot: a session that has already transitioned
 * past [CaptureState.Idle] rejects further submissions.
 *
 * [workingDir] is an absolute path to a per-session directory the SDK creates
 * eagerly. The native capture flow writes its artefacts there (conventionally
 * `photo.jpg` and one or more frame files); the SDK deletes the directory on every
 * terminal state.
 */
public class CaptureSession internal constructor(
    public val id: String,
    public val metadata: SdkCaptureMetadata,
    public val workingDir: String,
    private val api: CaptureApi,
) {
    private val _state = MutableStateFlow<CaptureState>(CaptureState.Idle)
    public val state: StateFlow<CaptureState> = _state.asStateFlow()

    /**
     * Bundle and encrypt the captured media, then hand the encrypted archive to the
     * transfer manager. Returns when the bundle has been handed off (session enters
     * [CaptureState.Uploading]); the upload itself continues asynchronously — observe
     * [state] to await [CaptureState.Uploaded] (local terminal) or
     * [CaptureState.Succeeded] (server-confirmed, only when the capture is also
     * observed via a server-aware API).
     *
     * Both paths in [result] must live inside [workingDir]; the SDK rejects paths
     * outside that directory.
     */
    @Throws(CancellationException::class, Exception::class)
    public suspend fun submit(result: CaptureResult): Unit = api.submit(this, result)

    /**
     * devMode-only: list the demo captures the server has available.
     * The built-in CaptureScreen / CaptureView use this to render a
     * picker when more than one demo is available; integrators that
     * only ever want the first entry can stick to the no-arg
     * [submitDemoCapture] convenience overload.
     */
    @Throws(CancellationException::class, Exception::class)
    public suspend fun listDemoCaptures(): List<DemoCaptureSummary> =
        api.listDemoCaptures(this)

    /**
     * devMode-only convenience: fetch a sample capture from the server,
     * download its photo + frames into [workingDir], and submit them
     * through the same path as [submit]. Used by the built-in
     * CaptureScreen / CaptureView "Use demo capture" button.
     *
     * Throws [IllegalStateException] if [TwinSkinConfig.devMode] is
     * false. Throws [DemoCaptureException] if the catalog is empty or
     * the download/submit fails. Partial files in [workingDir] on
     * failure are cleaned up by [cancel].
     *
     * @param onProgress invoked with `(downloadedFiles, totalFiles)`
     * for each photo + frame as it lands; total includes the photo.
     */
    @Throws(CancellationException::class, Exception::class)
    public suspend fun submitDemoCapture(
        onProgress: (downloaded: Int, total: Int) -> Unit = { _, _ -> },
    ): Unit = api.submitDemoCapture(this, entryId = null, onProgress)

    /**
     * devMode-only: like [submitDemoCapture] but submits a specific
     * entry from the catalog instead of auto-picking the first. Pair
     * with [listDemoCaptures] to drive a picker UI.
     *
     * Throws [DemoCaptureException] if [entryId] is not found in the
     * server's catalog.
     */
    @Throws(CancellationException::class, Exception::class)
    public suspend fun submitDemoCapture(
        entryId: String,
        onProgress: (downloaded: Int, total: Int) -> Unit,
    ): Unit = api.submitDemoCapture(this, entryId = entryId, onProgress)

    /**
     * Submit a discriminated-union annotation for the captured subject.
     * Only meaningful for [ConditionType.Generic] captures (where the
     * user has just traced a polygon annotation through the editor) — for
     * `Wound`, the server runs its own segmentation pipeline and the
     * SDK never reaches an [CaptureState.AwaitingAnnotation] state.
     */
    @Throws(CancellationException::class, Exception::class)
    public suspend fun submitAnnotation(annotation: SdkAnnotation): Unit =
        api.submitAnnotation(this, annotation)

    /** Cancel this session. Cancels the transfer if already handed off. */
    @Throws(CancellationException::class, Exception::class)
    public suspend fun cancel(): Unit = api.cancel(this)

    /**
     * Mark this session as failed without going through [submit]. Used by the
     * native capture flow when it can't produce a usable result (camera error,
     * permission revoked mid-flow, etc.). [reason] is the integrator-facing
     * diagnostic surfaced as [CaptureState.Failed.message].
     */
    @Throws(CancellationException::class, Exception::class)
    public suspend fun fail(reason: String): Unit = api.fail(this, reason)

    internal fun setState(new: CaptureState) { _state.value = new }
    internal val currentState: CaptureState get() = _state.value
}
