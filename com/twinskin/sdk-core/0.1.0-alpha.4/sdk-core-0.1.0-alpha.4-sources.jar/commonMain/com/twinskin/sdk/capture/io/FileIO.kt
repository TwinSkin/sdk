package com.twinskin.sdk.capture.io

/**
 * Minimal platform-agnostic file read primitives used by the capture bundle pipeline.
 * Scoped intentionally narrow: enough to size a file, compute its CRC, and stream its
 * bytes into the zip/encryption sinks. Anything fancier (seek, write-to-file) lives
 * elsewhere ([RandomAccessByteSink]).
 */

/** Returns the file size in bytes, or throws if the file doesn't exist. */
internal expect fun fileSize(path: String): Long

/**
 * Stream the file's bytes into [sink] sequentially. Uses an internal 8 KiB buffer; the
 * full file is never held in memory. Throws on I/O error.
 */
internal expect fun readFileStreaming(path: String, sink: ByteSink)

/** Best-effort delete; silently no-ops if the file is missing or can't be removed. */
internal expect fun deleteFileQuietly(path: String)

/** Create the directory at [path] (and any missing parents). No-op if it already exists. */
internal expect fun ensureDir(path: String)

/** Best-effort recursive delete; silently no-ops if the directory is missing or can't be removed. */
internal expect fun deleteDirQuietly(path: String)

/** Write [bytes] to [path], creating or overwriting. Throws on I/O error. */
internal expect fun writeBytes(path: String, bytes: ByteArray)
