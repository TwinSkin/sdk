package com.twinskin.sdk.ui.annotation_editor

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import com.twinskin.sdk.capture.GenericAnnotation
import com.twinskin.sdk.capture.GenericRegion
import com.twinskin.sdk.capture.Point2D

/**
 * Internal editor coordinate type — kept separate from the wire-format
 * [Point2D] so the editor's pure-Kotlin types don't leak the codegen
 * shape into UI tests. Converted at the public boundary
 * (see [GenericAnnotationEditorState.toAnnotation]).
 */
@TwinSkinInternalApi
public data class EditorPoint(val x: Double, val y: Double)

/**
 * Internal editor region type — finalized polygon plus its display color.
 *
 * [subRegions] is an optional list of contours nested inside this region
 * (e.g. tissue contours inside a wound region in the wound editor). The
 * generic editor never populates it; the canvas renders sub-regions
 * after the region's own fill+stroke when present.
 */
@TwinSkinInternalApi
public data class EditorRegion(
    val points: List<EditorPoint>,
    val color: String,
    val subRegions: List<EditorSubRegion> = emptyList(),
)

/**
 * A contour drawn inside an [EditorRegion]. Pre-colored by the state
 * (the canvas renders the color verbatim and does not need to know what
 * the sub-region semantically represents).
 */
@TwinSkinInternalApi
public data class EditorSubRegion(
    val contour: List<EditorPoint>,
    val color: String,
)

/**
 * State holder for [GenericAnnotationEditor]. Pure Kotlin (no Compose UI),
 * so it can be unit-tested in plain JVM tests without a Compose harness.
 *
 * Coordinates are stored in the reference image's normalized space
 * (0..1 on each axis) — see [EditorPoint]. Callers translate raw
 * pointer coordinates into normalized space before calling [addPoint].
 *
 * Interaction is finger-drag: a stroke begins on [startStroke],
 * accumulates via [extendStroke], and is committed as a region (>= 3
 * points) or dropped on [endStroke].
 *
 * The editor accepts a [GenericAnnotation] as `initial` and produces a
 * [GenericAnnotation] from [toAnnotation] — that's the shape the SDK
 * server expects for `ConditionType.Generic` captures.
 */
@TwinSkinInternalApi
public class GenericAnnotationEditorState(
    initial: GenericAnnotation = GenericAnnotation(regions = emptyList()),
) : PolygonEditorState {
    private val _regions = mutableStateListOf<EditorRegion>()
    public override val regions: List<EditorRegion> get() = _regions

    private val _inProgress = mutableStateListOf<EditorPoint>()
    public override val inProgressPoints: List<EditorPoint> get() = _inProgress

    private val _selectedColor = mutableStateOf(PolygonEditorState.DEFAULT_PALETTE.first())
    public override val selectedColor: String get() = _selectedColor.value

    init {
        _regions.addAll(
            initial.regions.map { region ->
                EditorRegion(
                    points = region.points.map { EditorPoint(it.x, it.y) },
                    color = region.color,
                )
            },
        )
    }

    public override fun startStroke(x: Double, y: Double) {
        _inProgress.clear()
        _inProgress.add(EditorPoint(x, y))
    }

    public override fun extendStroke(x: Double, y: Double) {
        _inProgress.add(EditorPoint(x, y))
    }

    public override fun endStroke() {
        if (_inProgress.size >= 3) {
            _regions.add(EditorRegion(points = _inProgress.toList(), color = _selectedColor.value))
        }
        _inProgress.clear()
    }

    public override fun deleteRegion(index: Int) {
        if (index in _regions.indices) _regions.removeAt(index)
    }

    public override fun setRegionColor(index: Int, color: String) {
        if (index in _regions.indices) {
            _regions[index] = _regions[index].copy(color = color)
        }
    }

    public override fun selectColor(color: String) { _selectedColor.value = color }

    /**
     * Snapshot the editor's state as a [GenericAnnotation] suitable for
     * `submitAnnotation`. Internal [EditorPoint] / [EditorRegion] are
     * mapped to the wire-format [Point2D] / [GenericRegion].
     */
    public fun toAnnotation(): GenericAnnotation =
        GenericAnnotation(
            regions = _regions.map { region ->
                GenericRegion(
                    points = region.points.map { Point2D(x = it.x, y = it.y) },
                    color = region.color,
                )
            },
        )
}
