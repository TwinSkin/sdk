package com.twinskin.sdk.ui.capture

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext

/**
 * Camera + microphone permission gate for the Android capture flow. Native to this
 * platform — the SDK no longer carries a shared permissions abstraction.
 */
internal class CapturePermissionsState internal constructor(
    val granted: Boolean,
    val denied: Boolean,
    val request: () -> Unit,
)

@Composable
internal fun rememberCapturePermissionsState(): CapturePermissionsState {
    val context = LocalContext.current
    val required = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)

    fun check(): Boolean = required.all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

    var granted by remember { mutableStateOf(check()) }
    var asked by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { result ->
        granted = result.values.all { it }
        asked = true
    }

    return CapturePermissionsState(
        granted = granted,
        denied = asked && !granted,
        request = { launcher.launch(required.toTypedArray()) },
    )
}
