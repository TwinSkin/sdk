package com.twinskin.sdk.capture.io

import java.io.File

internal actual fun fileSize(path: String): Long {
    val f = File(path)
    require(f.exists()) { "file not found: $path" }
    return f.length()
}

internal actual fun readFileStreaming(path: String, sink: ByteSink) {
    File(path).inputStream().use { input ->
        val buf = ByteArray(8 * 1024)
        while (true) {
            val n = input.read(buf)
            if (n <= 0) break
            sink.write(buf, 0, n)
        }
    }
}

internal actual fun deleteFileQuietly(path: String) {
    runCatching { File(path).delete() }
}

internal actual fun ensureDir(path: String) {
    File(path).mkdirs()
}

internal actual fun deleteDirQuietly(path: String) {
    runCatching { File(path).deleteRecursively() }
}

internal actual fun writeBytes(path: String, bytes: ByteArray) {
    File(path).writeBytes(bytes)
}
