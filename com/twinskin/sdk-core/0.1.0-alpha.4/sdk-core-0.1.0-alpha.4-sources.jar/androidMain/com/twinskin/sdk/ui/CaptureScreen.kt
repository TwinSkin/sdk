@file:OptIn(ExperimentalMaterial3Api::class, com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui

import android.app.Activity
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.util.Log
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.CaptureResult
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.DemoCaptureSummary
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.ui.capture.CameraSessionController
import com.twinskin.sdk.ui.capture.CameraSessionState
import com.twinskin.sdk.ui.capture.MarkerVersionPicker
import com.twinskin.sdk.ui.capture.rememberCapturePermissionsState
import com.twinskin.sdk.ui.post_submit.PostSubmitFlow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/**
 * Native Android capture screen.
 *
 * STABLE:
 *   - The seam to the SDK upstream — `startSession`, `session.workingDir`,
 *     `session.submit(CaptureResult(...))`, `session.cancel()`, `session.fail(reason)`.
 *   - The public `(metadata, onDone, onCancel, startSession)` parameter shape.
 *
 * REPLACE-TARGET (the colleague's playground):
 *   - The flow inside this composable: shutter / burst state machine, marker
 *     picker, sweep guidance copy, error handling, etc.
 *   - The CameraX wiring in `com.twinskin.sdk.ui.capture.CameraSessionController`.
 */
private const val BURST_DURATION_MS = 4_000L
private const val BURST_INTERVAL_MS = 250L

private sealed class FlowStep {
    data object AwaitingShutter : FlowStep()
    data object TakingPhoto : FlowStep()
    data class CapturingBurst(val taken: Int, val target: Int) : FlowStep()
    data class DownloadingDemo(val downloaded: Int, val total: Int) : FlowStep()
    data object Submitting : FlowStep()
}

@Composable
public fun CaptureScreen(
    metadata: SdkCaptureMetadata? = null,
    onDone: (CaptureSession) -> Unit = {},
    onCancel: () -> Unit = {},
    startSession: (SdkCaptureMetadata) -> CaptureSession = { TwinSkinSdk.startCapture(it) },
) {
    if (metadata == null) {
        NotWiredPlaceholder()
        return
    }

    val orientationContext = LocalContext.current
    DisposableEffect(Unit) {
        val activity = orientationContext.findActivity()
        val previous = activity?.requestedOrientation
        if (activity != null) {
            activity.requestedOrientation =
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            // CaptureScreen is normally hosted by a real Activity. If a
            // future integrator hosts it inside a non-Activity Context
            // (e.g. a service), we silently skip the lock — the rest of
            // the screen still works, the camera just won't follow our
            // orientation contract. Visible in logcat for debugging.
            Log.w(
                "CaptureScreen",
                "host context is not an Activity; skipping portrait lock",
            )
        }
        onDispose {
            if (activity != null && previous != null) {
                activity.requestedOrientation = previous
            }
        }
    }

    val permissions = rememberCapturePermissionsState()
    LaunchedEffect(Unit) { if (!permissions.granted) permissions.request() }

    val scope = rememberCoroutineScope()
    val session = remember(metadata) { startSession(metadata) }

    val cancelSession: () -> Unit = {
        scope.launch {
            try { session.cancel() } finally { onCancel() }
        }
    }

    when {
        permissions.denied -> Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            PermissionDeniedView(onRetry = permissions.request, onCancel = cancelSession)
        }
        !permissions.granted -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        else -> CaptureFlow(session, onDone, onCancel = cancelSession)
    }
}

@Composable
private fun NotWiredPlaceholder() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            "CaptureScreen needs SdkCaptureMetadata — host app has not wired one up yet.",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(24.dp),
        )
    }
}

@Composable
private fun PermissionDeniedView(onRetry: () -> Unit, onCancel: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            "Camera access is required to capture.",
            style = MaterialTheme.typography.bodyLarge,
        )
        Spacer(Modifier.height(16.dp))
        Row {
            OutlinedButton(onClick = onCancel) { Text("Cancel") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = onRetry) { Text("Grant access") }
        }
    }
}

@Composable
private fun CaptureFlow(
    session: CaptureSession,
    onDone: (CaptureSession) -> Unit,
    onCancel: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var submitted by remember { mutableStateOf(false) }

    if (submitted) {
        PostSubmitFlow(
            session = session,
            onDone = { onDone(session) },
            onCancel = onCancel,
        )
        return
    }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val controller = remember(context, lifecycleOwner, session.workingDir) {
        CameraSessionController(context, lifecycleOwner, session.workingDir)
    }
    LaunchedEffect(controller) { controller.bindToLifecycle() }
    DisposableEffect(controller) { onDispose { controller.dispose() } }

    val controllerState by controller.state.collectAsState()

    val devMode = TwinSkinSdk.devMode

    var step by remember { mutableStateOf<FlowStep>(FlowStep.AwaitingShutter) }
    var markerVersion by remember { mutableStateOf<String?>(null) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var demoPickerOptions by remember { mutableStateOf<List<DemoCaptureSummary>?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Capture") },
                navigationIcon = {
                    TextButton(onClick = onCancel) { Text("Cancel") }
                },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            CameraPreview(controller = controller, modifier = Modifier.fillMaxSize())

            if (devMode && step is FlowStep.AwaitingShutter) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp),
                    color = Color.Black.copy(alpha = 0.6f),
                    shape = MaterialTheme.shapes.small,
                ) {
                    TextButton(
                        onClick = {
                            scope.launch {
                                val catalog = try {
                                    session.listDemoCaptures()
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    errorText = e.message ?: "Demo capture failed"
                                    return@launch
                                }
                                when {
                                    catalog.isEmpty() -> {
                                        errorText = "No demo captures available on the server"
                                    }
                                    catalog.size == 1 -> {
                                        useDemoCapture(
                                            session = session,
                                            entryId = catalog.single().id,
                                            onStateChange = { step = it },
                                            onSubmitted = { submitted = true },
                                            onError = { errorText = it },
                                        )
                                    }
                                    else -> {
                                        demoPickerOptions = catalog
                                    }
                                }
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    ) {
                        Text("Use demo capture", color = Color.White)
                    }
                }
            }

            when (val s = step) {
                is FlowStep.AwaitingShutter, FlowStep.TakingPhoto -> {
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        if (s is FlowStep.AwaitingShutter) {
                            MarkerVersionPicker(
                                selected = markerVersion,
                                onSelect = { markerVersion = it },
                            )
                        }
                        ShutterButton(
                            enabled = controllerState is CameraSessionState.Ready &&
                                      s is FlowStep.AwaitingShutter,
                            onClick = {
                                scope.launch {
                                    step = FlowStep.TakingPhoto
                                    val photoPath = try {
                                        controller.takePhoto()
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: Exception) {
                                        errorText = e.message ?: "photo failed"
                                        step = FlowStep.AwaitingShutter
                                        return@launch
                                    }

                                    val target = (BURST_DURATION_MS / BURST_INTERVAL_MS).toInt()
                                    step = FlowStep.CapturingBurst(taken = 0, target = target)
                                    val framePaths = try {
                                        controller.captureBurst(
                                            durationMs = BURST_DURATION_MS,
                                            intervalMs = BURST_INTERVAL_MS,
                                        ) { taken ->
                                            step = FlowStep.CapturingBurst(taken = taken, target = target)
                                        }
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: Exception) {
                                        errorText = e.message ?: "burst failed"
                                        step = FlowStep.AwaitingShutter
                                        return@launch
                                    }

                                    step = FlowStep.Submitting
                                    try {
                                        session.submit(
                                            CaptureResult(
                                                photoPath = photoPath,
                                                framePaths = framePaths,
                                                markerVersion = markerVersion,
                                            ),
                                        )
                                        submitted = true
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: Exception) {
                                        errorText = e.message ?: "submit failed"
                                        step = FlowStep.AwaitingShutter
                                    }
                                }
                            },
                        )
                    }
                }
                is FlowStep.CapturingBurst -> {
                    BurstOverlay(taken = s.taken, target = s.target)
                }
                is FlowStep.DownloadingDemo -> {
                    DemoDownloadOverlay(downloaded = s.downloaded, total = s.total)
                }
                FlowStep.Submitting -> UploadOverlay("Preparing bundle…", null)
            }

            val ctrlErr = (controllerState as? CameraSessionState.Error)?.message
            val banner = errorText ?: ctrlErr
            if (banner != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.align(Alignment.TopCenter).padding(16.dp),
                ) {
                    Text(
                        banner,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                }
            }
        }

        demoPickerOptions?.let { options ->
            DemoCapturePickerDialog(
                options = options,
                onDismiss = { demoPickerOptions = null },
                onPick = { chosen ->
                    demoPickerOptions = null
                    scope.launch {
                        useDemoCapture(
                            session = session,
                            entryId = chosen.id,
                            onStateChange = { step = it },
                            onSubmitted = { submitted = true },
                            onError = { errorText = it },
                        )
                    }
                },
            )
        }
    }
}

@Composable
private fun DemoCapturePickerDialog(
    options: List<DemoCaptureSummary>,
    onDismiss: () -> Unit,
    onPick: (DemoCaptureSummary) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pick a demo capture") },
        text = {
            Column {
                for (option in options) {
                    TextButton(
                        onClick = { onPick(option) },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            option.name,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
private fun BurstOverlay(taken: Int, target: Int) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "Slowly sweep the camera over the area",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { (taken.toFloat() / target.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.width(240.dp),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "$taken / $target",
                color = Color.White,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun DemoDownloadOverlay(downloaded: Int, total: Int) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "Downloading demo capture…",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { (downloaded.toFloat() / total.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.width(240.dp),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "$downloaded / $total",
                color = Color.White,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

private suspend fun useDemoCapture(
    session: CaptureSession,
    entryId: String,
    onStateChange: (FlowStep) -> Unit,
    onSubmitted: () -> Unit,
    onError: (String) -> Unit,
) {
    try {
        onStateChange(FlowStep.DownloadingDemo(downloaded = 0, total = 1))
        session.submitDemoCapture(entryId = entryId) { d, t ->
            onStateChange(FlowStep.DownloadingDemo(downloaded = d, total = t))
        }
        // submitDemoCapture transitions through DownloadingDemo → Submitting
        // internally; surface Submitting once the call returns so the UI's
        // progress overlay matches.
        onStateChange(FlowStep.Submitting)
        onSubmitted()
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        onError(e.message ?: "Demo capture failed")
        onStateChange(FlowStep.AwaitingShutter)
    }
}

@Composable
private fun CameraPreview(controller: CameraSessionController, modifier: Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PreviewView(ctx).also { view ->
                view.scaleType = PreviewView.ScaleType.FILL_CENTER
                controller.preview.setSurfaceProvider(view.surfaceProvider)
            }
        },
    )
}

@Composable
private fun ShutterButton(enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(if (enabled) Color.White else Color.White.copy(alpha = 0.4f)),
        contentAlignment = Alignment.Center,
    ) {
        Button(
            onClick = onClick,
            enabled = enabled,
            shape = CircleShape,
            modifier = Modifier.size(60.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
        ) { }
    }
}

@Composable
private fun UploadOverlay(label: String, progress: Float?) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (progress != null) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.width(240.dp))
            } else {
                CircularProgressIndicator()
            }
            Spacer(Modifier.height(12.dp))
            Text(label, color = Color.White)
        }
    }
}

private tailrec fun android.content.Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
