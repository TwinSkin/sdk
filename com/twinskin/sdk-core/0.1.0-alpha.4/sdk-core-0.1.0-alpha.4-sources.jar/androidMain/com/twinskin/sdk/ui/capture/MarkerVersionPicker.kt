package com.twinskin.sdk.ui.capture

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// PLACEHOLDER for the colleague's marker auto-detection.
//
// This chip row is what the operator currently uses to tag a capture with the
// marker version. The colleague's capture flow should either:
//   1. Detect the marker automatically and build a `CaptureResult` with the
//      detected `markerVersion`, OR
//   2. Keep a similar UI element if manual override remains useful.
//
// Either way, this whole composable can be deleted; the only contract that
// survives is the `String?` value handed to `CaptureResult(markerVersion = …)`
// in `CaptureScreen.kt`.
@Composable
internal fun MarkerVersionPicker(
    selected: String?,
    onSelect: (String?) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier.padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            "Marker:",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 8.dp),
        )
        Spacer(Modifier.width(4.dp))
        NoneChip(selected = selected == null, onClick = { onSelect(null) })
        markerOptions.forEach { value ->
            FilterChip(
                selected = selected == value,
                onClick = { onSelect(value) },
                label = { Text(value) },
            )
        }
    }
}

@Composable
private fun NoneChip(selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        AssistChip(
            onClick = onClick,
            label = { Text("none") },
            colors = AssistChipDefaults.assistChipColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                labelColor = MaterialTheme.colorScheme.onSecondaryContainer,
            ),
        )
    } else {
        AssistChip(onClick = onClick, label = { Text("none") })
    }
}

/**
 * Mirror of `MarkerVersionType` in
 * `packages/server/lib/src/database/schema.dart`. Keep in sync when the server
 * adds a version. The list lives here (a placeholder) rather than in shared
 * Kotlin because the SDK forwards the value as a free-form string — the
 * server is the validator.
 */
private val markerOptions = listOf("v1", "v2", "v3")
