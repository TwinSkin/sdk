package com.twinskin.sdk.ui.capture

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import android.os.Build
import android.view.Surface
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.twinskin.sdk.capture.CaptureBundleEntries
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Phase a [CaptureScreen] is in, surfaced from the camera layer to the UI.
 * Internal so the public surface stays in [CaptureScreen] only.
 */
internal sealed class CameraSessionState {
    data object Initializing : CameraSessionState()
    data object Ready : CameraSessionState()
    data object CapturingPhoto : CameraSessionState()
    data class CapturingBurst(val taken: Int, val target: Int) : CameraSessionState()
    data class Error(val message: String) : CameraSessionState()
}

/**
 * CameraX-backed capture controller wired to the SDK's capture seam.
 *
 * Writes the reference still + every burst frame directly into [workingDir] under
 * the canonical [CaptureBundleEntries.IMAGE] / `frame_NNN.jpg` file names; the
 * caller passes the resulting paths to `CaptureSession.submit(CaptureResult(...))`.
 *
 * Replace-target: this whole file is the colleague's playground for tuning camera
 * UX (focus, exposure, resolution, marker detection). The seam upstream
 * (`CaptureSession.workingDir`, `submit`, `cancel`, `fail`) does not change.
 */
internal class CameraSessionController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val workingDir: String,
) {
    private val _state = MutableStateFlow<CameraSessionState>(CameraSessionState.Initializing)
    val state: StateFlow<CameraSessionState> = _state.asStateFlow()

    internal val preview: Preview = Preview.Builder().build()
    private val imageCapture = ImageCapture.Builder()
        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
        .build()

    private val photoFile = File(workingDir, CaptureBundleEntries.IMAGE)

    suspend fun bindToLifecycle() {
        val provider = ProcessCameraProvider.getInstance(context).awaitCompat()
        provider.unbindAll()
        // The screen above us has locked the host activity to portrait
        // (see CaptureScreen's DisposableEffect). Reading the current
        // display rotation now gives us the rotation that maps to
        // portrait on whatever device we're on — Surface.ROTATION_0 on
        // phones whose natural orientation is portrait, ROTATION_90 on
        // tablets whose natural orientation is landscape. Baking that
        // into ImageCapture means captured JPEGs are pixel-portrait
        // with no EXIF rotation needed downstream.
        imageCapture.targetRotation = currentDisplayRotation()
        provider.bindToLifecycle(
            lifecycleOwner,
            CameraSelector.DEFAULT_BACK_CAMERA,
            preview, imageCapture,
        )
        _state.value = CameraSessionState.Ready
    }

    private fun currentDisplayRotation(): Int {
        // Display.getRotation() requires API 30+; older API levels go
        // through the WindowManager's default display. Context.getDisplay()
        // is non-null on API 30+ when the context is associated with a
        // display (Activity always is); it throws UnsupportedOperationException
        // otherwise. CaptureScreen normally passes an Activity-bound context,
        // but its orientation-lock effect tolerates the non-Activity case
        // by skipping the lock and logging — match that behaviour here so a
        // degraded host doesn't crash the camera bind.
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.display.rotation
            } else {
                @Suppress("DEPRECATION")
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                @Suppress("DEPRECATION")
                wm?.defaultDisplay?.rotation ?: Surface.ROTATION_0
            }
        } catch (_: UnsupportedOperationException) {
            Surface.ROTATION_0
        }
    }

    /** Capture the reference still into `<workingDir>/photo.jpg`. */
    @SuppressLint("MissingPermission") // caller-checked by CaptureScreen
    suspend fun takePhoto(): String {
        _state.value = CameraSessionState.CapturingPhoto
        try {
            return capturePictureTo(photoFile)
        } finally {
            _state.value = CameraSessionState.Ready
        }
    }

    /**
     * Capture a burst of still photos by taking one every [intervalMs] for
     * [durationMs]. Returns the absolute paths of the captured JPEGs in capture
     * order. The first frame is taken immediately; subsequent frames respect
     * [intervalMs] until [durationMs] elapses or the deadline is hit.
     *
     * [onProgress] is invoked after each frame lands with the running count
     * (1, 2, …). The caller drives the on-screen progress indicator from there.
     */
    @SuppressLint("MissingPermission")
    suspend fun captureBurst(
        durationMs: Long,
        intervalMs: Long,
        onProgress: (taken: Int) -> Unit,
    ): List<String> {
        require(durationMs > 0) { "durationMs must be positive" }
        require(intervalMs > 0) { "intervalMs must be positive" }
        val target = (durationMs / intervalMs).toInt().coerceAtLeast(1)
        _state.value = CameraSessionState.CapturingBurst(taken = 0, target = target)
        val paths = mutableListOf<String>()
        try {
            val deadline = System.currentTimeMillis() + durationMs
            while (System.currentTimeMillis() < deadline) {
                val out = File(
                    workingDir,
                    "frame_${(paths.size + 1).toString().padStart(3, '0')}.jpg",
                )
                capturePictureTo(out)
                paths.add(out.absolutePath)
                onProgress(paths.size)
                _state.value = CameraSessionState.CapturingBurst(
                    taken = paths.size,
                    target = target,
                )
                val remaining = deadline - System.currentTimeMillis()
                if (remaining <= 0) break
                delay(minOf(intervalMs, remaining))
            }
        } finally {
            _state.value = CameraSessionState.Ready
        }
        return paths
    }

    private suspend fun capturePictureTo(file: File): String =
        suspendCancellableCoroutine { cont ->
            // CameraX appends to existing files in some configurations — clear any
            // stale image left from a previous take inside the same workingDir.
            if (file.exists()) file.delete()
            val output = ImageCapture.OutputFileOptions.Builder(file).build()
            imageCapture.takePicture(
                output,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(results: ImageCapture.OutputFileResults) {
                        cont.resume(file.absolutePath)
                    }
                    override fun onError(exception: ImageCaptureException) {
                        cont.resumeWithException(exception)
                    }
                },
            )
        }

    fun dispose() {
        try {
            ProcessCameraProvider.getInstance(context).get().unbindAll()
        } catch (e: Exception) {
            Log.w(TAG, "unbindAll failed on dispose", e)
        }
    }

    private companion object { const val TAG = "CameraSessionController" }
}

/** Adapter: [com.google.common.util.concurrent.ListenableFuture] → suspend. */
private suspend fun <T> com.google.common.util.concurrent.ListenableFuture<T>.awaitCompat(): T =
    suspendCancellableCoroutine { cont ->
        addListener({
            try { cont.resume(get()) } catch (e: Exception) { cont.resumeWithException(e) }
        }, Runnable::run)
    }
