package com.twinskin.sdk.storage

import android.content.Context
import com.twinskin.sdk.SdkLogger
import java.io.File

/**
 * Android [SdkStorage]. Rooted under `cacheDir/twinskin/` for evictable
 * state so the OS can reclaim bundle/view-capture space under storage
 * pressure — if a file disappears between a crash and the next
 * `initialize`, the recovery machinery re-creates what it needs.
 *
 * [Purpose.Databases] points at `context.getDatabasePath("dummy").parentFile`
 * — the app-private SQLite dir where both SqlDelight and PowerSync land
 * by default. Callers must filename-filter on this purpose to avoid
 * stomping unrelated DBs.
 */
internal class AndroidSdkStorage(context: Context) : SdkStorage {
    private val appContext = context.applicationContext
    private val twinskinCacheRoot: File by lazy {
        File(appContext.cacheDir, "twinskin").apply { mkdirs() }
    }

    // Databases dir is owned by the SQLite/PowerSync layer — we never create it,
    // only enumerate for sweep/wipe.
    private val databasesDir: String by lazy {
        appContext.getDatabasePath("dummy").parentFile?.absolutePath
            ?: error("Android DB dir unexpectedly null — getDatabasePath returned a file with no parent")
    }

    override fun dir(purpose: Purpose): String = when (purpose) {
        Purpose.Databases -> databasesDir
        else -> subdir(purpose.subdirName)
    }

    override fun sweep(
        purpose: Purpose,
        olderThanMs: Long,
        logger: SdkLogger,
        filter: (name: String) -> Boolean,
    ) {
        val cutoff = System.currentTimeMillis() - olderThanMs
        forEachEntry(purpose, logger) { entry ->
            if (filter(entry.name) && entry.lastModified() < cutoff) {
                deleteRecursively(entry, logger)
            }
        }
    }

    override fun wipe(
        purpose: Purpose,
        logger: SdkLogger,
        filter: (name: String) -> Boolean,
    ) {
        forEachEntry(purpose, logger) { entry ->
            if (filter(entry.name)) deleteRecursively(entry, logger)
        }
    }

    private fun subdir(name: String): String =
        File(twinskinCacheRoot, name).apply { mkdirs() }.absolutePath

    private inline fun forEachEntry(
        purpose: Purpose,
        logger: SdkLogger,
        block: (File) -> Unit,
    ) {
        runCatching {
            val root = File(dir(purpose))
            if (!root.isDirectory) return
            root.listFiles()?.forEach(block)
        }.onFailure { logger.log("SdkStorage: failed to enumerate ${purpose.name}", it) }
    }

    private fun deleteRecursively(entry: File, logger: SdkLogger) {
        runCatching {
            if (!entry.deleteRecursively()) {
                logger.log("SdkStorage: deleteRecursively returned false for ${entry.name}")
            }
        }.onFailure { logger.log("SdkStorage: failed to delete ${entry.name}", it) }
    }
}
