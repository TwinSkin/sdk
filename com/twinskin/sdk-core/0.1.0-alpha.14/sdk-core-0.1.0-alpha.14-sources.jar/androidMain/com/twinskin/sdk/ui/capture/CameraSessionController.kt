package com.twinskin.sdk.ui.capture

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.WindowManager
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.MeteringPoint
import androidx.camera.core.MeteringPointFactory
import androidx.camera.core.Preview
import androidx.camera.core.SurfaceOrientedMeteringPointFactory
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.twinskin.photosphere.Camera2Intrinsics
import com.twinskin.photosphere.KResolution
import com.twinskin.photosphere.KSource
import com.twinskin.photosphere.MarkerValidator
import com.twinskin.sdk.capture.CaptureBundleEntries
import com.twinskin.sdk.capture.PhotosphereCaptureDriver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Phase a [CaptureScreen] is in, surfaced from the camera layer to the UI.
 * Internal so the public surface stays in [CaptureScreen] only.
 */
internal sealed class CameraSessionState {
    data object Initializing : CameraSessionState()
    data object Ready : CameraSessionState()
    data object CapturingPhoto : CameraSessionState()
    data class CapturingBurst(val taken: Int, val target: Int) : CameraSessionState()
    data class Error(val message: String) : CameraSessionState()
}

/**
 * CameraX-backed capture controller wired to the SDK's capture seam.
 *
 * Writes the reference still + every burst frame directly into [workingDir] under
 * the canonical [CaptureBundleEntries.IMAGE] / `frame_NNN.jpg` file names; the
 * caller passes the resulting paths to `CaptureSession.submit(CaptureResult(...))`.
 */
internal class CameraSessionController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val workingDir: String,
) {
    private val _state = MutableStateFlow<CameraSessionState>(CameraSessionState.Initializing)
    val state: StateFlow<CameraSessionState> = _state.asStateFlow()

    /**
     * `SystemClock.elapsedRealtimeNanos` at controller creation. Anchors
     * `session_seconds` in the device-telemetry EXIF + pose_log payload
     * so an analyst can plot thermal/memory vs. elapsed capture time
     * without joining wall-clock timestamps.
     */
    private val sessionStartElapsedNs: Long = android.os.SystemClock.elapsedRealtimeNanos()

    /**
     * Most recent device-telemetry sample, set by
     * [validateAndStampJpegBytes] right before each JPEG is stamped.
     * Read once by the [PhotosphereCaptureDriver] shutter trampoline so
     * the sample taken at stamp time and the one mirrored into
     * `pose_log.json` are the same physical reading. Volatile because
     * the validator runs on a CameraX executor and the trampoline on a
     * coroutine dispatcher.
     */
    @Volatile
    internal var lastShutterTelemetry: com.twinskin.photosphere.PhotosphereDeviceTelemetry? = null
        private set

    // 4:3 aspect-ratio pin: matches the analyser's 4:3 output so both
    // use cases see the SAME sensor FOV. Without this, CameraX may
    // pick a 16:9 (or 1:1) surface for Preview while ImageAnalysis
    // lands at a different aspect — the two then represent different
    // sensor crops, which makes CoordinateTransform between the two
    // OutputTransforms semantically wrong (they don't span the same
    // normalized space). The dev-mode marker overlay relies on the
    // chain being correct.
    internal val preview: Preview = Preview.Builder()
        .setResolutionSelector(
            androidx.camera.core.resolutionselector.ResolutionSelector.Builder()
                .setAspectRatioStrategy(
                    androidx.camera.core.resolutionselector.AspectRatioStrategy
                        .RATIO_4_3_FALLBACK_AUTO_STRATEGY,
                )
                .build(),
        )
        .build()
    // MINIMIZE_LATENCY avoids a multi-frame HDR merge that stalled
    // `takePicture()` for tens of seconds on entry-level ISPs; the
    // ResolutionSelector pins highest-available, otherwise CameraX
    // defaults to ~1080p and silently caps bundle photos at ~2 MP.
    private val imageCapture = ImageCapture.Builder()
        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
        .setResolutionSelector(
            androidx.camera.core.resolutionselector.ResolutionSelector.Builder()
                .setResolutionStrategy(
                    androidx.camera.core.resolutionselector.ResolutionStrategy
                        .HIGHEST_AVAILABLE_STRATEGY,
                )
                .build(),
        )
        .build()

    // Analyser is hinted at 640×480 (PhotosphereConfig dims); flagships
    // may land at 720p+ so the analyser callback resamples down. Built
    // inside [bindToLifecycle] so the Camera2Interop capture callback
    // tracking LENS_FOCUS_DISTANCE can be installed before .build().
    private lateinit var imageAnalysis: ImageAnalysis

    /** Single-thread executor servicing the [imageAnalysis] callback. */
    private val analyserExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "twinskin-photosphere-analyser").apply { isDaemon = true }
    }

    /**
     * Executor for the shutter callback. Distinct from [analyserExecutor]
     * so a slow JPEG dispatch does not stall preview-frame analysis.
     * Owned by this controller; shut down in [dispose].
     */
    private val shutterExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "twinskin-photosphere-shutter").apply { isDaemon = true }
    }

    /**
     * Background scope for debug-image disk writes from [captureJpegBytes].
     * The arm-shutter callback resumes immediately with the encoded
     * bytes; the extra `<workingDir>/<label>_<ts>.jpg` snapshot is
     * written here so a slow filesystem cannot stall the next arm.
     */
    private val diskWriteScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * The driver-built [PhotosphereCaptureDriver.LiveFrameTap] installed
     * by [attachLiveFrameTap]. The analyser callback dereferences this
     * atomic on every frame; null = no tap wired yet (a no-op frame).
     */
    private val liveFrameTap: AtomicReference<PhotosphereCaptureDriver.LiveFrameTap?> =
        AtomicReference(null)

    /**
     * Marker-focus controller. When attached, [analyseFrame] forwards
     * the raw Y-plane (uint8) to `ingestFrame(...)` every Nth frame
     * (N=[MARKER_CADENCE]). Atomic so the analyser thread reads it
     * racelessly when the host attaches/detaches from the main thread.
     */
    private val markerFocusController: AtomicReference<MarkerFocusController?> =
        AtomicReference(null)

    /**
     * Marker-cadence gate. Touched only from the analyser thread
     * (single-thread executor). Kept on the producer side so the
     * per-frame Y-plane copy is skipped on the 4-out-of-5 frames the
     * controller would discard anyway.
     */
    private var markerFrameCounter: Int = 0

    /**
     * Capture-frame validator. Off by default; `attachCaptureValidator`
     * flips this on so the per-arm shutter path validates JPEG bytes
     * against the ref-frame anchor before they reach
     * `PhotosphereSession`. Mirrors the iOS
     * `CameraSessionController.enableBurstValidation()` toggle.
     */
    private var captureValidatorEnabled: Boolean = false

    /**
     * Continuous-torch state, mirrored here so the reference EXIF
     * stamp records the lighting the frame was captured under.
     * Volatile — read on the shutter path, written from the UI thread.
     */
    @Volatile
    private var torchEnabled: Boolean = false

    /**
     * Marker diagonal observed on the reference still (the first
     * captured frame per session). null until the ref capture
     * produces a valid marker. AF/AE lock at the ref-frame plane
     * means every per-arm view should land near this diagonal; the
     * per-arm distance gate uses ±[RELATIVE_DISTANCE_TOLERANCE] of
     * this value. Atomic so the shutter executor reads the value
     * written by an earlier ref capture racelessly.
     */
    private val referenceDiagPx: AtomicReference<Float?> = AtomicReference(null)

    /**
     * Blur variance observed on the reference still — the session's
     * gold-standard sharpness. Per-arm gate floor is
     * `ref_blur * (1 - RELATIVE_BLUR_TOLERANCE)`.
     */
    private val referenceBlurVariance: AtomicReference<Float?> = AtomicReference(null)

    private val referenceMarkerVersion: AtomicReference<String?> = AtomicReference(null)

    /**
     * Diagnostic-only — never lands in the upload manifest. Stamped
     * while the focus controller is `Locked`, so reads can lead the
     * true decode by up to `lockTimeoutMs` (3 s).
     */
    private val lastLiveMarkerSeenAtMs: AtomicReference<Long?> = AtomicReference(null)

    /**
     * 640×480 contiguous grayscale frame fed to
     * [com.twinskin.photosphere.MarkerRefine.aruco]. Allocated lazily;
     * reused thereafter (single-thread analyser executor + synchronous
     * JNI read make reuse safe). Distinct from [liveFloatBuffer] because
     * the ArUco entry point expects 8-bit Y while the backbone expects
     * float32; sharing would force a per-frame conversion. The 640×480
     * resample is mandatory because the ArUco tuning constants only
     * generalise to that resolution — native 1280×720+ input returns
     * rc=-1 even with a clearly visible marker.
     */
    private var markerByteBuffer: ByteBuffer? = null

    /**
     * Reusable direct ByteBuffer holding the float32 grayscale frame in
     * `[0, 255]` range, native byte order. Capacity is fixed at
     * `width * height * 4` bytes; the analyser refills it in-place each
     * tick and the session copies out synchronously inside
     * [com.twinskin.photosphere.PhotosphereSession.enqueueLiveFrame]
     * before the next analyser callback can fire (single-thread
     * executor, KEEP_ONLY_LATEST). Allocated lazily on first frame.
     */
    private var liveFloatBuffer: ByteBuffer? = null

    /**
     * Primitive `FloatArray` staging buffer for the analyser's Y-plane.
     * Per-pixel `DirectFloatBuffer.put(float)` is dominated by per-element
     * bounds-check + position-increment; ART vectorises primitive-array
     * stores, so staging here then bulk-transferring with
     * `asFloatBuffer().put(stage)` is dramatically faster. Allocated
     * lazily; reused thereafter (analyser-thread serial → no race).
     */
    private var liveFloatStage: FloatArray? = null

    /** Reusable row-byte scratch for the Y-plane reader. */
    private var liveRowBuffer: ByteArray? = null

    /**
     * Scratch holding the bulk-read source Y-plane. Sized at
     * `srcHeight * rowStride`; grown lazily by [readYPlaneToScratch].
     * Per-pixel `ByteBuffer.get(int)` against a direct buffer is a
     * JNI-style call (bounds check + native-memory deref) that ART does
     * not vectorise; the resampled paths issue >1.2M such reads per
     * frame at 720p. Bulk-reading into a primitive `ByteArray` once and
     * indexing `bytes[i]` collapses that to a few ms.
     * Single-thread analyser executor → no race on resize.
     */
    private var yPlaneScratch: ByteArray = ByteArray(0)

    /**
     * Primitive-array stage for the marker-focus byte resample.
     * Bilinear writes land here, then a single bulk
     * `out.put(markerByteScratch, 0, n)` flushes to the direct dst
     * buffer — same primitive-array-stores rationale as
     * [liveFloatStage].
     */
    private var markerByteScratch: ByteArray = ByteArray(0)

    /**
     * Cached K matrix. Static per device / orientation for the lifetime
     * of the camera bind, so resolved once on the first analyser frame
     * and reused; cleared on [dispose] so a re-bind picks up fresh
     * sensor metadata. Single-thread analyser executor → no race on
     * assignment.
     */
    @Volatile private var cachedAnalyserIntrinsics: FloatArray? = null

    /**
     * Static [LENS_INTRINSIC_CALIBRATION][CameraCharacteristics.LENS_INTRINSIC_CALIBRATION]
     * read once at camera-bind time via [Camera2CameraInfo]. Holds the
     * 5-element (fx, fy, cx, cy, skew) array. `CameraCharacteristics` is
     * a final class so [resolveIntrinsics] synthesises a [KResolution]
     * from this + [sensorActiveArraySize] inline. Null on devices that
     * do not advertise the static key; those fall through to the
     * bundled-profile / pinhole branch.
     */
    private var staticIntrinsicCalibration: FloatArray? = null

    /**
     * Sensor active-array size in pixels, paired with [staticIntrinsicCalibration].
     * Defines the native frame the static K is expressed in (the
     * resolver downstream rescales into the 640×480 pipeline frame).
     */
    private var sensorActiveArraySize: Size? = null

    /**
     * Cached HAL hardware level. Fed into
     * [LensFocusLockPolicy.decideStrategy] inside
     * [lockLensAndExposureForPhotosphere].
     */
    @Volatile private var cachedHardwareLevel: Int? = null

    /**
     * Cached lens calibration enum, read at bind time. Paired with
     * [cachedHardwareLevel] to pick the lens-lock strategy.
     */
    @Volatile private var cachedLensCalibration: Int? = null

    /**
     * Resolved per-HAL lens-lock strategy. Defaults to
     * `AF_MODE_OFF_ONLY` (the conservative legacy CL-079 path) so the
     * first call to [lockLensAndExposureForPhotosphere] before bind
     * completes is a no-op rather than a misfired pin-distance write.
     */
    @Volatile private var lockStrategy: LensFocusLockPolicy.Strategy =
        LensFocusLockPolicy.Strategy.AF_MODE_OFF_ONLY

    /**
     * Guard so the static HAL queries fire exactly once across
     * camera re-binds. The hardware level / lens calibration are
     * device-static; re-querying on every bind is wasteful and
     * generates duplicate logcat noise.
     */
    @Volatile private var hardwareLevelQueried: Boolean = false

    /**
     * Most-recent `LENS_FOCUS_DISTANCE` diopter value read from the
     * analyser repeating-request capture result. Updated on every
     * analyser frame (~30 Hz) by the Camera2Interop callback installed
     * in [bindToLifecycle]. Read by [lockLensAndExposureForPhotosphere]
     * to pin the converged lens position when the strategy is
     * [LensFocusLockPolicy.Strategy.AF_MODE_OFF_PIN_DISTANCE].
     */
    @Volatile private var latestFocusDistanceDiopter: Float? = null

    /** Bound CameraX [Camera] handle for focus / metering control. */
    private var boundCamera: Camera? = null

    private val photoFile = File(workingDir, CaptureBundleEntries.IMAGE)

    suspend fun bindToLifecycle() {
        val provider = ProcessCameraProvider.getInstance(context).awaitCompat()
        provider.unbindAll()
        // calibration once and resolve the per-HAL lens-lock strategy.
        // Both keys are device-static; querying once across re-binds
        // is correct and matches the upstream demo
        // (`CameraController.bind`).
        if (!hardwareLevelQueried) {
            cachedHardwareLevel = Camera2HardwareLevel.queryBackCameraHardwareLevel(context)
            cachedLensCalibration = LensFocusLockPolicy.queryBackCameraLensCalibration(context)
            lockStrategy = LensFocusLockPolicy.decideStrategy(
                hardwareLevel = cachedHardwareLevel,
                focusDistanceCalibration = cachedLensCalibration,
            )
            hardwareLevelQueried = true
            Log.i(
                TAG,
                "CL-103 hardware level=${Camera2HardwareLevel.describe(cachedHardwareLevel)}" +
                    " lensCalibration=${LensFocusLockPolicy.describeCalibration(cachedLensCalibration)}" +
                    " lockStrategy=$lockStrategy",
            )
        }
        // The screen above us has locked the host activity to portrait
        // (see CaptureScreen's DisposableEffect). Reading the current
        // display rotation now gives us the rotation that maps to
        // portrait on whatever device we're on — Surface.ROTATION_0 on
        // phones whose natural orientation is portrait, ROTATION_90 on
        // tablets whose natural orientation is landscape. Baking that
        // into ImageCapture means captured JPEGs are pixel-portrait
        // with no EXIF rotation needed downstream.
        val rotation = currentDisplayRotation()
        imageCapture.targetRotation = rotation
        // Build imageAnalysis here with Camera2Interop callback to track
        // LENS_FOCUS_DISTANCE for PIN_DISTANCE lock on FULL/LEVEL_3 HALs (Pixel 6).
        @OptIn(ExperimentalCamera2Interop::class)
        val analysisBuilder = ImageAnalysis.Builder()
            .setResolutionSelector(
                androidx.camera.core.resolutionselector.ResolutionSelector.Builder()
                    .setAspectRatioStrategy(
                        androidx.camera.core.resolutionselector.AspectRatioStrategy
                            .RATIO_4_3_FALLBACK_AUTO_STRATEGY,
                    )
                    .setResolutionStrategy(
                        androidx.camera.core.resolutionselector.ResolutionStrategy(
                            Size(ANALYSER_WIDTH, ANALYSER_HEIGHT),
                            androidx.camera.core.resolutionselector.ResolutionStrategy
                                .FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER,
                        ),
                    )
                    .build(),
            )
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
        @OptIn(ExperimentalCamera2Interop::class)
        Camera2Interop.Extender(analysisBuilder)
            .setSessionCaptureCallback(object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession,
                    request: CaptureRequest,
                    result: TotalCaptureResult,
                ) {
                    result.get(CaptureResult.LENS_FOCUS_DISTANCE)?.let { d ->
                        latestFocusDistanceDiopter = d
                    }
                }
            })
        imageAnalysis = analysisBuilder.build()
        imageAnalysis.targetRotation = rotation
        // Wire the analyser callback before binding so we never miss a
        // frame between bind and setAnalyzer.
        imageAnalysis.setAnalyzer(analyserExecutor, ::analyseFrame)
        val camera = provider.bindToLifecycle(
            lifecycleOwner,
            wideBackCameraSelector,
            preview, imageCapture, imageAnalysis,
        )
        boundCamera = camera
        logBoundLensCharacteristics(camera)
        // Camera2 interop is required for LENS_INTRINSIC_CALIBRATION.
        // read the static calibration keys once at bind time. The keys
        // are device-static (not per-frame), so a single read at
        // bind-time is correct and matches CameraX's recommendation
        // for static CameraCharacteristics access. Failure to read is
        // non-fatal: the resolver in [resolveIntrinsics] falls through
        // to the bundled-profile / pinhole branch.
        try {
            @OptIn(ExperimentalCamera2Interop::class)
            val info = Camera2CameraInfo.from(camera.cameraInfo)
            staticIntrinsicCalibration = info.getCameraCharacteristic(
                CameraCharacteristics.LENS_INTRINSIC_CALIBRATION,
            )
            sensorActiveArraySize = info.getCameraCharacteristic(
                CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE,
            )?.let { rect: Rect -> Size(rect.width(), rect.height()) }
            if (staticIntrinsicCalibration != null) {
                Log.i(
                    TAG,
                    "static LENS_INTRINSIC_CALIBRATION read: " +
                        "fx=${staticIntrinsicCalibration!![0]} " +
                        "fy=${staticIntrinsicCalibration!![1]} " +
                        "cx=${staticIntrinsicCalibration!![2]} " +
                        "cy=${staticIntrinsicCalibration!![3]} " +
                        "sensor=${sensorActiveArraySize}",
                )
            } else {
                Log.i(
                    TAG,
                    "device does not expose static LENS_INTRINSIC_CALIBRATION; " +
                        "intrinsics will fall back to bundled-profile / pinhole",
                )
            }
        } catch (e: Exception) {
            Log.w(
                TAG,
                "Camera2CameraInfo characteristic read failed; intrinsics will fall back to bundled / pinhole",
                e,
            )
            staticIntrinsicCalibration = null
            sensorActiveArraySize = null
        }
        _state.value = CameraSessionState.Ready
    }

    // CameraX crashes on an empty filter result, so fall through to the
    // back-camera input when no candidate exposes both focal length and
    // sensor width.
    // TODO(#433): replace this heuristic with the curated allow-list +
    // telemetry + devMode-override architecture.
    @OptIn(ExperimentalCamera2Interop::class)
    private val wideBackCameraSelector: CameraSelector = CameraSelector.Builder()
        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
        .addCameraFilter { cameraInfos ->
            val scored = cameraInfos.mapNotNull { info ->
                val focal35mm = computeFocal35mmEquivalent(info) ?: return@mapNotNull null
                info to kotlin.math.abs(focal35mm - TARGET_WIDE_FOCAL_35MM)
            }
            if (scored.isEmpty()) cameraInfos
            else listOf(scored.minBy { it.second }.first)
        }
        .build()

    private fun logBoundLensCharacteristics(camera: Camera) {
        try {
            @OptIn(ExperimentalCamera2Interop::class)
            val info = Camera2CameraInfo.from(camera.cameraInfo)
            val physicalId = info.cameraId
            val focal35mm = computeFocal35mmEquivalent(camera.cameraInfo)
                ?.let { "%.1f".format(it) } ?: "n/a"
            Log.i(TAG, "camera bound: physicalId=$physicalId, focal35mm=$focal35mm")
        } catch (e: Exception) {
            Log.w(TAG, "camera bound: lens characteristic read failed", e)
        }
    }

    // Score zoom lenses by their widest end so a multi-focal-length
    // logical camera is ranked by its widest physical underneath.
    @OptIn(ExperimentalCamera2Interop::class)
    private fun computeFocal35mmEquivalent(info: androidx.camera.core.CameraInfo): Float? {
        return try {
            val c = Camera2CameraInfo.from(info)
            val focals = c.getCameraCharacteristic(
                CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS,
            ) ?: return null
            if (focals.isEmpty()) return null
            val sensorSize = c.getCameraCharacteristic(
                CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE,
            ) ?: return null
            val sensorW = sensorSize.width
            if (sensorW <= 0f) return null
            focals.min() * 36f / sensorW
        } catch (_: Exception) {
            null
        }
    }

    /**
     * [PhotosphereCaptureDriver.LiveFrameTap]. The analyser callback
     * picks it up on the next tick. Calling with `null` detaches the
     * tap (frames continue to arrive but are no-op'd, useful for tests
     * and tear-down). Idempotent.
     */
    fun attachLiveFrameTap(tap: PhotosphereCaptureDriver.LiveFrameTap?) {
        liveFrameTap.set(tap)
    }

    /**
     * Install the marker-focus controller. [analyseFrame] will forward
     * the raw Y-plane to the controller on every Nth frame
     * (N=[MARKER_CADENCE]). Calling with `null` detaches the controller.
     * Idempotent.
     */
    fun attachMarkerFocusController(controller: MarkerFocusController?) {
        markerFocusController.set(controller)
    }

    internal data class AnalyserSurfaceInfo(
        val sourceWidth: Int,
        val sourceHeight: Int,
        val cropRectLeft: Int,
        val cropRectTop: Int,
        val cropRectWidth: Int,
        val cropRectHeight: Int,
        val rotationDegrees: Int,
        val outputTransform: androidx.camera.view.transform.OutputTransform,
    )

    // setUsingRotationDegrees(true) + setUsingCropRect(true) align the
    // analyser OutputTransform with PreviewView's convention (which
    // always uses rotation + crop). Required so CoordinateTransform
    // chains the two transforms across a normalized space that
    // represents the SAME physical scene region — otherwise the
    // analyser's normalized space is the full sensor buffer while
    // PreviewView's is the rotated crop, and the chain
    // collapses to garbage.
    private val imageProxyTransformFactory =
        androidx.camera.view.transform.ImageProxyTransformFactory().apply {
            isUsingRotationDegrees = true
            isUsingCropRect = true
        }

    private val analyserSurfaceInfo: AtomicReference<AnalyserSurfaceInfo?> =
        AtomicReference(null)

    /** OutputTransform cached from the first analyser frame; used by the
     *  dev-mode overlay to map analyser-pixel marker corners into
     *  preview-view pixel coords. */
    internal val attachedAnalyserSurface: AnalyserSurfaceInfo?
        get() = analyserSurfaceInfo.get()

    private val previewViewRef: AtomicReference<androidx.camera.view.PreviewView?> =
        AtomicReference(null)

    fun attachPreviewView(view: androidx.camera.view.PreviewView?) {
        previewViewRef.set(view)
    }

    internal val attachedPreviewView: androidx.camera.view.PreviewView?
        get() = previewViewRef.get()

    /**
     * Lock AF/AE/AWB so every one of the 16 arm captures shares focal
     * depth + exposure with the reference frame (mandatory for the
     * downstream MVS pipeline).
     *
     * `(poiX, poiY)` are analyser-frame pixel coords (origin top-left).
     * Both null → lock at frame centre. Non-null values are mapped
     * through a [SurfaceOrientedMeteringPointFactory] sized to the
     * analyser frame so the metering point lands on the marker
     * centroid. POI is clamped to the analyser bounds because
     * out-of-range values are rejected by CameraX.
     *
     * No-op if no camera is bound yet. Errors are swallowed-and-logged
     * because some devices do not expose AF/AE control to
     * ImageAnalysis-only pipelines and a failure must not take the
     * capture down.
     */
    fun lockFocusAndExposure(poiX: Float? = null, poiY: Float? = null) {
        val camera = boundCamera ?: run {
            Log.w(TAG, "lockFocusAndExposure called before camera bound; skipping")
            return
        }
        try {
            // Surface-oriented factory tied to the analyser shape — the
            // metering point lands at the centre of the analyser frame
            // regardless of the preview's aspect ratio. The marker
            // observer feeds [feedMarkerFocus] a 640×480 resampled
            // Y-plane so the centroid the caller passes is already in
            // this factory's coord frame — no remap needed.
            val factory: MeteringPointFactory =
                SurfaceOrientedMeteringPointFactory(
                    ANALYSER_WIDTH.toFloat(),
                    ANALYSER_HEIGHT.toFloat(),
                )
            val targetX = (poiX ?: (ANALYSER_WIDTH * 0.5f))
                .coerceIn(0f, ANALYSER_WIDTH.toFloat())
            val targetY = (poiY ?: (ANALYSER_HEIGHT * 0.5f))
                .coerceIn(0f, ANALYSER_HEIGHT.toFloat())
            val target: MeteringPoint = factory.createPoint(targetX, targetY)
            val action = FocusMeteringAction.Builder(
                target,
                FocusMeteringAction.FLAG_AF or
                    FocusMeteringAction.FLAG_AE or
                    FocusMeteringAction.FLAG_AWB,
            )
                // Disable the auto-cancel timer so the lock holds for
                // the entire 16-arm capture run; CaptureScreen tears the
                // controller down on session end which releases the lock.
                .disableAutoCancel()
                .build()
            camera.cameraControl.startFocusAndMetering(action)
            val targetLabel = if (poiX != null && poiY != null) {
                "marker centroid ($targetX, $targetY)"
            } else {
                "analyser centre"
            }
            Log.i(TAG, "lockFocusAndExposure: AF/AE/AWB locked at $targetLabel")
        } catch (e: Exception) {
            Log.w(TAG, "lockFocusAndExposure failed: ${e.message}", e)
        }
    }

    /**
     * Release the AF/AE/AWB lock taken by [lockFocusAndExposure].
     * Without it the lock survives any composable recomposition where
     * [CameraSessionController] outlives the driver, so a re-bound
     * session starts in a stale-locked state. Idempotent + no-op-safe.
     */
    fun unlockFocusAndExposure() {
        val camera = boundCamera ?: run {
            Log.w(TAG, "unlockFocusAndExposure called before camera bound; skipping")
            return
        }
        try {
            camera.cameraControl.cancelFocusAndMetering()
            Log.i(TAG, "unlockFocusAndExposure: AF/AE/AWB returned to continuous mode")
        } catch (e: Exception) {
            Log.w(TAG, "unlockFocusAndExposure failed: ${e.message}", e)
        }
    }

    /**
     * Install a true lens lock for the photosphere sweep via
     * Camera2Interop. See [LensFocusLockPolicy] for the per-HAL
     * strategy decision.
     *
     * Two-step:
     *   1. [FocusMeteringAction] converges AF/AE/AWB on the POI
     *      ([poiX], [poiY] in analyser-frame pixel coords; null
     *      defaults to analyser centre).
     *   2. Camera2Interop writes
     *      `CONTROL_AF_MODE_OFF + AE_LOCK + AWB_LOCK` on the repeating
     *      request to suspend the HAL's continuous-AF kernel.
     *
     * Without step 2, [FocusMeteringAction.disableAutoCancel] alone does
     * NOT prevent the Tensor / Pixel HAL from drifting back to
     * hyperfocal mid-sweep.
     *
     * Errors are swallowed-and-logged: a lock failure must not take
     * the capture down. On settle timeout the override is still
     * installed, pinning whatever lens position the HAL reached when
     * the timeout fired.
     */
    suspend fun lockLensAndExposureForPhotosphere(
        poiX: Float? = null,
        poiY: Float? = null,
        settleTimeoutMs: Int = LENS_LOCK_SETTLE_TIMEOUT_MS,
    ) {
        val camera = boundCamera ?: run {
            Log.w(TAG, "lockLensAndExposureForPhotosphere called before camera bound; skipping")
            return
        }
        // Step 1 — issue the metering action. Reuses the same factory /
        // POI-clamping logic [lockFocusAndExposure] uses so the metering
        // point lands on the marker centroid (or analyser centre).
        val factory = SurfaceOrientedMeteringPointFactory(
            ANALYSER_WIDTH.toFloat(),
            ANALYSER_HEIGHT.toFloat(),
        )
        val targetX = (poiX ?: (ANALYSER_WIDTH * 0.5f))
            .coerceIn(0f, ANALYSER_WIDTH.toFloat())
        val targetY = (poiY ?: (ANALYSER_HEIGHT * 0.5f))
            .coerceIn(0f, ANALYSER_HEIGHT.toFloat())
        val target = factory.createPoint(targetX, targetY)
        val action = FocusMeteringAction.Builder(
            target,
            FocusMeteringAction.FLAG_AF or
                FocusMeteringAction.FLAG_AE or
                FocusMeteringAction.FLAG_AWB,
        )
            // disableAutoCancel is technically redundant once
            // AF_MODE_OFF lands on the repeating request, but matches
            // upstream and provides a fallback if the override write
            // fails.
            .disableAutoCancel()
            .build()
        val future = try {
            camera.cameraControl.startFocusAndMetering(action)
        } catch (e: Exception) {
            Log.w(TAG, "lockLensAndExposureForPhotosphere: startFocusAndMetering threw", e)
            return
        }
        // Step 2 — await settle (best-effort). Some HALs never report
        // a stable settle; on timeout we proceed with the override
        // anyway, pinning whatever position the lens has reached.
        val settled = withTimeoutOrNull(settleTimeoutMs.toLong()) {
            suspendCancellableCoroutine<Boolean> { cont ->
                future.addListener({
                    val ok = runCatching { future.get() }
                        .map { it.isFocusSuccessful }
                        .getOrDefault(false)
                    if (cont.isActive) {
                        cont.resume(ok)
                    }
                }, shutterExecutor)
                cont.invokeOnCancellation { future.cancel(false) }
            }
        } ?: false
        if (!settled) {
            Log.i(
                TAG,
                "lockLensAndExposureForPhotosphere: settle timed out, pinning at current lens position",
            )
        }
        // Step 3 — install the Camera2 override on the repeating request.
        // Read the converged diopter from the analyser capture callback
        // (latestFocusDistanceDiopter, updated at ~30 Hz) to pin
        // LENS_FOCUS_DISTANCE on FULL/LEVEL_3 HALs (Pixel 6 Tensor: AF_MODE_OFF
        // alone drifts back to hyperfocal the moment it engages).
        val convergedDiopter = latestFocusDistanceDiopter
        val builder = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(
                CaptureRequest.CONTROL_AF_MODE,
                CameraMetadata.CONTROL_AF_MODE_OFF,
            )
            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_LOCK, true)
            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_LOCK, true)
        val effectiveStrategy =
            if (lockStrategy == LensFocusLockPolicy.Strategy.AF_MODE_OFF_PIN_DISTANCE &&
                convergedDiopter != null
            ) {
                builder.setCaptureRequestOption(
                    CaptureRequest.LENS_FOCUS_DISTANCE,
                    convergedDiopter,
                )
                LensFocusLockPolicy.Strategy.AF_MODE_OFF_PIN_DISTANCE
            } else {
                if (lockStrategy == LensFocusLockPolicy.Strategy.AF_MODE_OFF_PIN_DISTANCE) {
                    Log.w(
                        TAG,
                        "CL-103 lock-strategy=PIN_DISTANCE but no analyser frame yet;" +
                            " falling back to AF_MODE_OFF-only this round",
                    )
                }
                LensFocusLockPolicy.Strategy.AF_MODE_OFF_ONLY
            }
        try {
            @OptIn(ExperimentalCamera2Interop::class)
            Camera2CameraControl.from(camera.cameraControl)
                .setCaptureRequestOptions(builder.build())
            Log.i(
                TAG,
                "CL-103 photosphere lens-lock applied strategy=$effectiveStrategy" +
                    " resolved=$lockStrategy settled=$settled" +
                    " convergedDiopter=$convergedDiopter",
            )
        } catch (e: Exception) {
            // Non-fatal — Camera2 interop can throw if the camera
            // pipeline is mid-reconfigure. The next analyser frame is
            // unaffected; the lock simply isn't in force this session.
            Log.w(
                TAG,
                "lockLensAndExposureForPhotosphere: setCaptureRequestOptions threw",
                e,
            )
        }
    }

    /**
     * release the photosphere lens-lock posture installed by
     * [lockLensAndExposureForPhotosphere]. Idempotent. Mirrors
     * `CameraController.unlockLensAndExposure` in the XFeat DemoApp.
     *
     * Clears the Camera2 override AND cancels any in-flight metering.
     * `cancelFocusAndMetering` alone does NOT release the override —
     * that override is layered on top of CameraX's metering and
     * survives metering cancellation. Without
     * `clearCaptureRequestOptions` the lens stays frozen across the
     * next bind, which is the iOS F-3 review symptom we want to avoid
     * here. Mirror upstream's order: clear the options first, then
     * cancel metering.
     */
    fun unlockLensAndExposureForPhotosphere() {
        val camera = boundCamera ?: return
        try {
            @OptIn(ExperimentalCamera2Interop::class)
            Camera2CameraControl.from(camera.cameraControl)
                .clearCaptureRequestOptions()
            Log.i(TAG, "photosphere lens-lock cleared")
        } catch (e: Exception) {
            Log.w(
                TAG,
                "unlockLensAndExposureForPhotosphere: clearCaptureRequestOptions threw",
                e,
            )
        }
        try {
            camera.cameraControl.cancelFocusAndMetering()
        } catch (e: Exception) {
            Log.w(
                TAG,
                "unlockLensAndExposureForPhotosphere: cancelFocusAndMetering threw",
                e,
            )
        }
    }

    /**
     * True iff the bound camera exposes a controllable torch unit.
     * Front cameras and the rare flash-less device report false; the
     * reference-luminance flow then degrades to a verdict-only path.
     */
    fun hasTorchUnit(): Boolean = boundCamera?.cameraInfo?.hasFlashUnit() == true

    /** Last torch state applied via [setTorchEnabled]. */
    fun isTorchEnabled(): Boolean = torchEnabled

    /**
     * Enable or disable the bound camera's continuous torch. Returns
     * false (a no-op) when the camera is unbound or has no torch unit.
     * Errors are swallowed-and-logged: a torch failure must not take
     * capture down. The caller re-locks AE afterwards via
     * [lockLensAndExposureForPhotosphere] so per-arm shots see the
     * post-torch exposure.
     */
    fun setTorchEnabled(enabled: Boolean): Boolean {
        val camera = boundCamera ?: run {
            Log.w(TAG, "setTorchEnabled($enabled) called before camera bound; skipping")
            return false
        }
        if (!camera.cameraInfo.hasFlashUnit()) {
            Log.i(TAG, "setTorchEnabled($enabled): bound camera has no torch unit")
            return false
        }
        return try {
            camera.cameraControl.enableTorch(enabled)
            torchEnabled = enabled
            Log.i(TAG, "torch ${if (enabled) "enabled" else "disabled"}")
            true
        } catch (e: Exception) {
            Log.w(TAG, "setTorchEnabled($enabled) threw", e)
            false
        }
    }

    /**
     * Per-frame analyser timing diagnostic counter / state. See [analyseFrame].
     * Touched only from the analyser thread (single-thread executor).
     */
    private var analyserFrameCount: Int = 0
    private var prevAnalyserT0Ns: Long = 0L

    private fun perfMs(nanos: Long): Long = nanos / 1_000_000L

    /**
     * CameraX [ImageAnalysis.Analyzer] callback. Pulls the Y-plane out
     * of a [YUV_420_888][android.graphics.ImageFormat.YUV_420_888]
     * frame, expands each byte into a float32 in `[0, 255]`, resolves
     * intrinsics for the frame, and forwards to the installed
     * [liveFrameTap]. Mandatory `imageProxy.close()` runs in the
     * `finally` block to release the CameraX-owned buffer regardless
     * of any conversion or tap exception.
     */
    private fun analyseFrame(imageProxy: ImageProxy) {
        // Per-frame timing instrumentation (tag: sdk-analyser-perf).
        // Logged on frame 0, frame 1, then every 30th frame thereafter
        // so logcat-tail diagnoses live-camera pose-detection slowdowns
        // vs the XFeat DemoApp without flooding the buffer.
        val perfT0 = System.nanoTime()
        var perfT1 = perfT0
        var perfT2 = perfT0
        var perfT3 = perfT0
        var perfSrcW = -1
        var perfSrcH = -1
        // session-owned scratch buffers, close the proxy, THEN call
        // `tap.onFrame`. CameraX's analyser executor cannot deliver
        // the next frame until `proxy.close()` returns, so holding the
        // proxy open through `enqueueLiveFrame`'s ~1.2 MB memcpy +
        // pose-dispatch back-pressure (~80–300 ms on Pixel 6) was
        // squandering the entire intake budget. The buffer is safe
        // past `close()` because `enqueueLiveFrame` copies it
        // synchronously into the session's internal storage before
        // returning. Mirrors XFeat DemoApp `CameraFrameSource.kt:488-489`.
        var out: ByteBuffer? = null
        var intrinsics: FloatArray? = null
        var timestampNs: Long = 0L
        var tap: PhotosphereCaptureDriver.LiveFrameTap? = null
        try {
            // controller every Nth frame BEFORE the float32 path
            // runs. The controller reads the Y-plane synchronously
            // (the JNI call copies the ROI patch internally) so we
            // don't need to keep the imageProxy alive past this
            // call. Cadence-gating on the producer side avoids the
            // copy-to-direct-buffer cost on the 4-out-of-5 frames
            // the controller would discard.
            markerFrameCounter += 1
            val mfc = markerFocusController.get()
            if (mfc != null && markerFrameCounter % MARKER_CADENCE == 0) {
                feedMarkerFocus(imageProxy, mfc)
                if (mfc.lastObservedMarker != null) {
                    lastLiveMarkerSeenAtMs.set(SystemClock.elapsedRealtime())
                }
            }
            // Cache the analyser's OutputTransform once; the overlay
            // chains it with PreviewView.outputTransform so the chain
            // spans the same sensor crop across per-device Preview vs
            // ImageAnalysis aspect divergence.
            if (analyserSurfaceInfo.get() == null) {
                try {
                    val outT = imageProxyTransformFactory.getOutputTransform(imageProxy)
                    val cr = imageProxy.cropRect
                    val info = AnalyserSurfaceInfo(
                        sourceWidth = imageProxy.width,
                        sourceHeight = imageProxy.height,
                        cropRectLeft = cr.left,
                        cropRectTop = cr.top,
                        cropRectWidth = cr.width(),
                        cropRectHeight = cr.height(),
                        rotationDegrees = imageProxy.imageInfo.rotationDegrees,
                        outputTransform = outT,
                    )
                    analyserSurfaceInfo.set(info)
                } catch (t: Throwable) {
                    Log.w(TAG, "Failed to build analyser OutputTransform", t)
                }
            }

            tap = liveFrameTap.get()
            if (tap == null) {
                return
            }
            // Capture src dims before the Y-plane drain so we can log
            // them on frame 0 for the cross-app comparison.
            perfSrcW = imageProxy.width
            perfSrcH = imageProxy.height
            // CameraX's setTargetResolution is a *hint*: on flagships
            // (Pixel 8 et al.) the analyser frequently lands at 720p or
            // higher even when 640×480 is supported. The previous
            // implementation early-returned on size mismatch, which on
            // those devices produced a silent stall: zero frames
            // forwarded → dwell tracker never wakes → operator sees a
            // black screen forever with no UI signal.
            //
            // Fix: always downsample (or pass-through if exact) into a
            // 640×480 grayscale float32 buffer before forwarding. The
            // C side (`xfeat_config.h/w`) requires exactly 640×480, and
            // the session's `enqueueLiveFrame` `require()` enforces
            // it — so the resampler is mandatory whenever CameraX
            // delivers something else.
            //
            // Resampling strategy: center-crop to a 4:3 (`ANALYSER_WIDTH
            // : ANALYSER_HEIGHT`) aspect, then bilinear-downsample to
            // 640×480. Center-crop matches what the operator sees in
            // the preview (FILL_CENTER scaleType) so the framing they
            // line up is what XFeat actually scores. Bilinear (not
            // nearest-neighbour) — feature-detector quality drops
            // noticeably with NN downsampling per CL-091.
            //
            // For exact 640×480 input we skip the resampler entirely
            // (M-tier fleet: XCover 5, A21s) so the fast path stays
            // allocation-free.
            val srcW = imageProxy.width
            val srcH = imageProxy.height
            val buffer = ensureLiveFloatBuffer(ANALYSER_WIDTH * ANALYSER_HEIGHT)
            buffer.position(0)
            val yPlane = imageProxy.planes[0]
            val rowStride = yPlane.rowStride
            val pixelStride = yPlane.pixelStride
            val src = yPlane.buffer
            // perfT1 is the stage boundary between Y-plane acquisition
            // setup and the fill stage. The actual bulk-read happens
            // inside the fill helpers, so the "fill" sample covers
            // Y-plane bulk-read + conversion combined; splitting them
            // tighter would require double-reading on the resampled path.
            perfT1 = System.nanoTime()
            if (srcW == ANALYSER_WIDTH && srcH == ANALYSER_HEIGHT) {
                fillFloatViewExact(src, rowStride, pixelStride, buffer)
            } else {
                fillFloatViewResampled(src, srcW, srcH, rowStride, pixelStride, buffer)
            }
            perfT2 = System.nanoTime()
            // Reset position for the consumer; cap the limit at the
            // float32-encoded frame size so the session sees exactly
            // ANALYSER_WIDTH * ANALYSER_HEIGHT * 4 bytes of data.
            buffer.position(0)
            buffer.limit(ANALYSER_WIDTH * ANALYSER_HEIGHT * Float.SIZE_BYTES)
            // Hit the cache (set on the first frame after camera bind)
            // instead of paying the per-frame `resolveIntrinsics`
            // allocation. First-frame miss populates the cache.
            intrinsics = cachedAnalyserIntrinsics
                ?: resolveIntrinsics(ANALYSER_WIDTH, ANALYSER_HEIGHT)
                    .also { cachedAnalyserIntrinsics = it }
            timestampNs = imageProxy.imageInfo.timestamp
            out = buffer
        } catch (e: Exception) {
            // Swallow exceptions: any throw here propagates back into
            // CameraX's analyser executor and unbinds the entire camera
            // pipeline, which would black-screen the operator. Log and
            // let the next frame retry.
            Log.w(TAG, "analyser frame conversion failed: ${e.message}", e)
        } finally {
            // Y-plane has been drained into our reusable buffers, so
            // CameraX can dispatch the next analyser frame in parallel
            // with `tap.onFrame`'s synchronous memcpy.
            try {
                imageProxy.close()
            } catch (e: Exception) {
                Log.w(TAG, "imageProxy.close threw: ${e.message}", e)
            }
            perfT3 = System.nanoTime()
        }
        // Forward to the tap AFTER close — the buffer is session-owned
        // and `enqueueLiveFrame` copies synchronously before returning.
        if (out != null && intrinsics != null && tap != null) {
            try {
                tap.onFrame(out, intrinsics, timestampNs)
            } catch (e: Exception) {
                Log.w(TAG, "liveFrameTap.onFrame threw: ${e.message}", e)
            }
        }
        val perfT4 = System.nanoTime()
        // Log on frame 0, frame 1, then every 30 frames thereafter.
        // First-frame interval is reported as 0 (no prior frame).
        val perfFrame = analyserFrameCount
        if (perfFrame == 0 || perfFrame == 1 || perfFrame % 30 == 0) {
            val perfInterval = if (prevAnalyserT0Ns == 0L) 0L else perfT0 - prevAnalyserT0Ns
            Log.i(
                "sdk-analyser-perf",
                "frame=$perfFrame src=${perfSrcW}x${perfSrcH}" +
                    " yplane=${perfMs(perfT1 - perfT0)}ms" +
                    " fill=${perfMs(perfT2 - perfT1)}ms" +
                    " close=${perfMs(perfT3 - perfT2)}ms" +
                    " tap=${perfMs(perfT4 - perfT3)}ms" +
                    " total=${perfMs(perfT4 - perfT0)}ms" +
                    " ival=${perfMs(perfInterval)}ms",
            )
        }
        prevAnalyserT0Ns = perfT0
        analyserFrameCount = perfFrame + 1
    }

    /**
     * Allocation-free fast-path for an exact 640×480 source. Reads the
     * Y-plane row by row, honouring `rowStride` and `pixelStride`, and
     * writes `[0, 255]` floats into [out].
     */
    private fun fillFloatViewExact(
        src: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        out: ByteBuffer,
    ) {
        val w = ANALYSER_WIDTH
        val h = ANALYSER_HEIGHT
        // FloatArray and bulk-transfer once. ART vectorises primitive-
        // array stores; per-pixel `DirectFloatBuffer.put(float)` does
        // not (bounds-check + position-increment per element).
        val tmp = ensureLiveFloatStage(w * h)
        var i = 0
        if (pixelStride == 1 && rowStride == w) {
            val view = src.duplicate()
            view.order(ByteOrder.LITTLE_ENDIAN)
            view.position(0)
            val rowBuf = ensureLiveRowBuffer(w)
            for (y in 0 until h) {
                view.position(y * rowStride)
                view.get(rowBuf, 0, w)
                for (x in 0 until w) {
                    tmp[i++] = (rowBuf[x].toInt() and 0xFF).toFloat()
                }
            }
        } else {
            val view = src.duplicate()
            view.order(ByteOrder.LITTLE_ENDIAN)
            for (y in 0 until h) {
                val rowStart = y * rowStride
                for (x in 0 until w) {
                    val byte = view.get(rowStart + x * pixelStride).toInt() and 0xFF
                    tmp[i++] = byte.toFloat()
                }
            }
        }
        out.position(0)
        out.asFloatBuffer().put(tmp)
    }

    /**
     * Resample a non-VGA source frame down to 640×480.
     *
     * Pipeline:
     *   1. Center-crop the source to a 4:3 aspect rectangle —
     *      `cropW × cropH` is the largest 4:3 box centred on the
     *      source (drops left/right strips for 16:9 inputs, no-op for
     *      4:3 inputs).
     *   2. Bilinear-resample `(cropW × cropH) → (640 × 480)`, sampling
     *      in source coordinates with pixel-centre alignment.
     *
     * Bilinear (not nearest-neighbour) is required: XFeat
     * descriptor-quality drops noticeably with NN downsampling.
     */
    private fun fillFloatViewResampled(
        src: ByteBuffer,
        srcW: Int,
        srcH: Int,
        rowStride: Int,
        pixelStride: Int,
        out: ByteBuffer,
    ) {
        // Read the Y-plane into a primitive ByteArray once; all bilinear
        // samples index `bytes[...]` against the primitive array,
        // replacing >1.2M per-frame JNI-style direct-buffer reads.
        val bytes = readYPlaneToScratch(src, srcW, srcH, rowStride, pixelStride)
        val tmp = ensureLiveFloatStage(ANALYSER_WIDTH * ANALYSER_HEIGHT)
        var i = 0
        val targetAspectNum = ANALYSER_WIDTH
        val targetAspectDen = ANALYSER_HEIGHT
        // Largest 4:3 rect centred on the source: pick the dimension
        // that fits within both axes. For 16:9 input, height limits
        // (cropH = srcH, cropW = srcH * 4/3); for 4:3 input, both
        // dimensions match.
        val srcAspectNumByH = srcW * targetAspectDen
        val srcAspectDenByH = srcH * targetAspectNum
        var cropW: Int
        var cropH: Int
        if (srcAspectNumByH >= srcAspectDenByH) {
            // Source is wider than 4:3 → crop sides.
            cropH = srcH
            cropW = (srcH.toLong() * targetAspectNum / targetAspectDen).toInt()
            if (cropW > srcW) cropW = srcW
        } else {
            // Source is taller than 4:3 → crop top/bottom.
            cropW = srcW
            cropH = (srcW.toLong() * targetAspectDen / targetAspectNum).toInt()
            if (cropH > srcH) cropH = srcH
        }
        val offsetX = (srcW - cropW) / 2
        val offsetY = (srcH - cropH) / 2
        val sx = cropW.toFloat() / ANALYSER_WIDTH.toFloat()
        val sy = cropH.toFloat() / ANALYSER_HEIGHT.toFloat()
        for (y in 0 until ANALYSER_HEIGHT) {
            // Pixel-centre alignment (half-pixel shift) — required to
            // keep the resampled grid centred on the source.
            var srcYf = (y + 0.5f) * sy - 0.5f + offsetY
            if (srcYf < 0f) srcYf = 0f
            val maxY = (srcH - 1).toFloat()
            if (srcYf > maxY) srcYf = maxY
            val y0 = srcYf.toInt()
            val y1 = if (y0 + 1 < srcH) y0 + 1 else y0
            val fy = srcYf - y0
            val rowStart0 = y0 * rowStride
            val rowStart1 = y1 * rowStride
            for (x in 0 until ANALYSER_WIDTH) {
                var srcXf = (x + 0.5f) * sx - 0.5f + offsetX
                if (srcXf < 0f) srcXf = 0f
                val maxX = (srcW - 1).toFloat()
                if (srcXf > maxX) srcXf = maxX
                val x0 = srcXf.toInt()
                val x1 = if (x0 + 1 < srcW) x0 + 1 else x0
                val fx = srcXf - x0
                val p00 = bytes[rowStart0 + x0 * pixelStride].toInt() and 0xFF
                val p10 = bytes[rowStart0 + x1 * pixelStride].toInt() and 0xFF
                val p01 = bytes[rowStart1 + x0 * pixelStride].toInt() and 0xFF
                val p11 = bytes[rowStart1 + x1 * pixelStride].toInt() and 0xFF
                val top = p00 + (p10 - p00) * fx
                val bot = p01 + (p11 - p01) * fx
                val blended = top + (bot - top) * fy
                tmp[i++] = blended
            }
        }
        out.position(0)
        out.asFloatBuffer().put(tmp)
    }

    /**
     * Feed a 640×480 contiguous uint8 Y-plane to the marker-focus
     * controller. The 640×480 resample is mandatory: the bundled ArUco
     * tuning constants were validated against VGA input only, and
     * raw 720p/960p Y-planes return rc=-1 even with a visible marker
     * because adaptive-threshold + corner-refinement parameters do not
     * generalise to those resolutions.
     *
     * Pipeline:
     *   * Exact 640×480 input → fast-path: copy-to-direct (when
     *     needed) and forward with the source `rowStride`.
     *   * Other input → center-crop to 4:3, bilinear-downsample to
     *     640×480, write into [markerByteBuffer] contiguously, and
     *     forward with `rowStride = ANALYSER_WIDTH`.
     *
     * The output centroid published by [MarkerFocusController.lastObservedMarker]
     * is therefore in the **640×480 analyser frame**, which is exactly
     * the coordinate system [lockFocusAndExposure] expects (its
     * [SurfaceOrientedMeteringPointFactory] is sized to ANALYSER_WIDTH ×
     * ANALYSER_HEIGHT). No coordinate-space remapping needed at the
     * call site.
     *
     * Buffer reuse is safe because [analyseFrame] runs on a single-
     * thread executor and the controller reads synchronously inside
     * [MarkerFocusController.ingestFrame] before this method returns.
     */
    private fun feedMarkerFocus(imageProxy: ImageProxy, mfc: MarkerFocusController) {
        val srcW = imageProxy.width
        val srcH = imageProxy.height
        val yPlane = imageProxy.planes[0]
        val rowStride = yPlane.rowStride
        val pixelStride = yPlane.pixelStride
        val src = yPlane.buffer

        if (srcW == ANALYSER_WIDTH && srcH == ANALYSER_HEIGHT) {
            // Fast path: VGA stream (M-tier fleet — XCover 5, A21s).
            // Just guarantee directness and keep the native rowStride.
            if (src.isDirect && pixelStride == 1) {
                val saved = src.position()
                try {
                    src.position(0)
                    mfc.ingestFrame(
                        gray = src,
                        width = srcW,
                        height = srcH,
                        rowStride = rowStride,
                    )
                } finally {
                    src.position(saved)
                }
                return
            }
            // Non-direct or non-1 pixel stride: copy into the contiguous
            // markerByteBuffer (rowStride collapses to ANALYSER_WIDTH).
        }

        val out = ensureMarkerByteBuffer(ANALYSER_WIDTH * ANALYSER_HEIGHT)
        out.clear()
        if (srcW == ANALYSER_WIDTH && srcH == ANALYSER_HEIGHT) {
            fillByteViewExact(src, rowStride, pixelStride, out)
        } else {
            fillByteViewResampled(src, srcW, srcH, rowStride, pixelStride, out)
        }
        out.position(0)
        out.limit(ANALYSER_WIDTH * ANALYSER_HEIGHT)
        mfc.ingestFrame(
            gray = out,
            width = ANALYSER_WIDTH,
            height = ANALYSER_HEIGHT,
            rowStride = ANALYSER_WIDTH,
        )
    }

    /**
     * Copy the source Y-plane into [out] as a contiguous uint8 buffer
     * (the ArUco entry point's expected layout), honouring `rowStride`
     * and `pixelStride`. The uint8 equivalent of [fillFloatViewExact].
     */
    private fun fillByteViewExact(
        src: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        out: ByteBuffer,
    ) {
        val w = ANALYSER_WIDTH
        val h = ANALYSER_HEIGHT
        val view = src.duplicate()
        view.order(ByteOrder.LITTLE_ENDIAN)
        if (pixelStride == 1 && rowStride == w) {
            view.position(0)
            view.limit(w * h)
            out.put(view)
        } else if (pixelStride == 1) {
            val rowBuf = ByteArray(w)
            for (y in 0 until h) {
                view.position(y * rowStride)
                view.get(rowBuf, 0, w)
                out.put(rowBuf)
            }
        } else {
            for (y in 0 until h) {
                val rowStart = y * rowStride
                for (x in 0 until w) {
                    out.put(view.get(rowStart + x * pixelStride))
                }
            }
        }
    }

    /**
     * Resample the source Y-plane down to a contiguous 640×480 uint8
     * buffer. Same algorithm as [fillFloatViewResampled] (center-crop
     * to 4:3, bilinear in source coords with pixel-centre alignment)
     * but rounds to uint8 at the end.
     *
     * TODO(CL-103-followup): port to `native/` as
     * `xfeat_resample_bilinear_centercrop` and call via JNI — the
     * equivalent Swift function in `:sdk-ios` is currently a
     * line-for-line copy of this routine. Per the photosphere_capture
     * Golden Rule, shared algorithmic logic belongs in `native/`. The
     * intrinsics crop math in `resolveIntrinsics` replicates the
     * centre-crop computation for the same reason and will fold
     * together with the native port.
     */
    private fun fillByteViewResampled(
        src: ByteBuffer,
        srcW: Int,
        srcH: Int,
        rowStride: Int,
        pixelStride: Int,
        out: ByteBuffer,
    ) {
        // Read source into a primitive ByteArray once, stage the
        // bilinear output into another primitive ByteArray, then one
        // bulk `out.put(stage, 0, n)` at the end — replaces ~307k
        // per-pixel direct-buffer reads + ~307k per-pixel writes per
        // marker frame.
        val bytes = readYPlaneToScratch(src, srcW, srcH, rowStride, pixelStride)
        val dstSize = ANALYSER_WIDTH * ANALYSER_HEIGHT
        val stage = ensureMarkerByteScratch(dstSize)
        var dstIdx = 0
        val targetAspectNum = ANALYSER_WIDTH
        val targetAspectDen = ANALYSER_HEIGHT
        val srcAspectNumByH = srcW * targetAspectDen
        val srcAspectDenByH = srcH * targetAspectNum
        var cropW: Int
        var cropH: Int
        if (srcAspectNumByH >= srcAspectDenByH) {
            cropH = srcH
            cropW = (srcH.toLong() * targetAspectNum / targetAspectDen).toInt()
            if (cropW > srcW) cropW = srcW
        } else {
            cropW = srcW
            cropH = (srcW.toLong() * targetAspectDen / targetAspectNum).toInt()
            if (cropH > srcH) cropH = srcH
        }
        val offsetX = (srcW - cropW) / 2
        val offsetY = (srcH - cropH) / 2
        val sx = cropW.toFloat() / ANALYSER_WIDTH.toFloat()
        val sy = cropH.toFloat() / ANALYSER_HEIGHT.toFloat()
        for (y in 0 until ANALYSER_HEIGHT) {
            var srcYf = (y + 0.5f) * sy - 0.5f + offsetY
            if (srcYf < 0f) srcYf = 0f
            val maxY = (srcH - 1).toFloat()
            if (srcYf > maxY) srcYf = maxY
            val y0 = srcYf.toInt()
            val y1 = if (y0 + 1 < srcH) y0 + 1 else y0
            val fy = srcYf - y0
            val rowStart0 = y0 * rowStride
            val rowStart1 = y1 * rowStride
            for (x in 0 until ANALYSER_WIDTH) {
                var srcXf = (x + 0.5f) * sx - 0.5f + offsetX
                if (srcXf < 0f) srcXf = 0f
                val maxX = (srcW - 1).toFloat()
                if (srcXf > maxX) srcXf = maxX
                val x0 = srcXf.toInt()
                val x1 = if (x0 + 1 < srcW) x0 + 1 else x0
                val fx = srcXf - x0
                val p00 = bytes[rowStart0 + x0 * pixelStride].toInt() and 0xFF
                val p10 = bytes[rowStart0 + x1 * pixelStride].toInt() and 0xFF
                val p01 = bytes[rowStart1 + x0 * pixelStride].toInt() and 0xFF
                val p11 = bytes[rowStart1 + x1 * pixelStride].toInt() and 0xFF
                val top = p00 + (p10 - p00) * fx
                val bot = p01 + (p11 - p01) * fx
                val blended = top + (bot - top) * fy
                val clipped = when {
                    blended < 0f -> 0
                    blended > 255f -> 255
                    else -> (blended + 0.5f).toInt()
                }
                stage[dstIdx++] = clipped.toByte()
            }
        }
        out.put(stage, 0, dstSize)
    }

    private fun ensureMarkerByteBuffer(needed: Int): ByteBuffer {
        val current = markerByteBuffer
        if (current != null && current.capacity() >= needed) return current
        val fresh = ByteBuffer.allocateDirect(needed).order(ByteOrder.nativeOrder())
        markerByteBuffer = fresh
        return fresh
    }

    /**
     * Ensure [liveFloatBuffer] has capacity for [pixelCount] float32
     * grayscale pixels (`pixelCount * 4` bytes). Allocates on first
     * call; reuses thereafter (analyser-thread serial → no race).
     */
    private fun ensureLiveFloatBuffer(pixelCount: Int): ByteBuffer {
        val needed = pixelCount * Float.SIZE_BYTES
        val current = liveFloatBuffer
        if (current != null && current.capacity() >= needed) return current
        val fresh = ByteBuffer.allocateDirect(needed).order(ByteOrder.nativeOrder())
        liveFloatBuffer = fresh
        return fresh
    }

    /**
     * Ensure [liveFloatStage] holds at least [pixelCount] floats. See
     * the field doc for why this primitive-array stage exists.
     */
    private fun ensureLiveFloatStage(pixelCount: Int): FloatArray {
        val current = liveFloatStage
        if (current != null && current.size >= pixelCount) return current
        val fresh = FloatArray(pixelCount)
        liveFloatStage = fresh
        return fresh
    }

    private fun ensureLiveRowBuffer(width: Int): ByteArray {
        val current = liveRowBuffer
        if (current != null && current.size >= width) return current
        val fresh = ByteArray(width)
        liveRowBuffer = fresh
        return fresh
    }

    /**
     * Bulk-read the source Y-plane into [yPlaneScratch], honouring
     * `rowStride` and `pixelStride`, and return the scratch reference
     * for caller-side primitive-array indexing.
     *
     * Sized at `srcH * rowStride` (not `srcW * srcH`) so downstream
     * `rowStart + x * pixelStride` indexing stays valid with stride
     * padding. For the typical `pixelStride == 1 && rowStride == srcW`
     * case this collapses to `srcW * srcH`.
     */
    private fun readYPlaneToScratch(
        src: ByteBuffer,
        srcW: Int,
        srcH: Int,
        rowStride: Int,
        pixelStride: Int,
    ): ByteArray {
        val needed = srcH * rowStride
        if (yPlaneScratch.size < needed) {
            yPlaneScratch = ByteArray(needed)
        }
        val bytes = yPlaneScratch
        val view = src.duplicate()
        view.order(ByteOrder.LITTLE_ENDIAN)
        if (pixelStride == 1 && rowStride == srcW) {
            view.position(0)
            view.get(bytes, 0, srcW * srcH)
        } else if (pixelStride == 1) {
            // Stride padding: bulk-read each row at its native offset
            // so caller indexing `rowStart + x` continues to work.
            for (y in 0 until srcH) {
                view.position(y * rowStride)
                view.get(bytes, y * rowStride, srcW)
            }
        } else {
            // Exotic pixelStride > 1 — bulk-read the whole stride-padded
            // plane (cheaper than per-pixel `view.get(int)`), caller
            // indexes with pixelStride.
            view.position(0)
            view.get(bytes, 0, needed)
        }
        return bytes
    }

    /**
     * Ensure [markerByteScratch] holds at least [size] bytes. Sized
     * once at 640×480; never grows past that under steady state.
     */
    private fun ensureMarkerByteScratch(size: Int): ByteArray {
        if (markerByteScratch.size < size) {
            markerByteScratch = ByteArray(size)
        }
        return markerByteScratch
    }

    /**
     * Resolve the 9-float row-major K matrix for the current frame.
     * Walks [Camera2Intrinsics.resolveK]'s priority order:
     *   1. Per-frame `LENS_INTRINSIC_CALIBRATION` — not currently
     *      surfaced by the ImageAnalysis pipeline (CameraX does not
     *      expose `CaptureResult` per-frame on the analyser path); we
     *      pass `null` and let the resolver fall through.
     *   2. Static `LENS_INTRINSIC_CALIBRATION` from
     *      [CameraCharacteristics] when the device advertises it.
     *   3. 65° pinhole synthesised at analyser dims.
     *
     * The resolver returns K in its `nativeWidth × nativeHeight` frame.
     * The session's `xfeat_adjust_k` expects K in `(pipelineW,
     * pipelineH)` — when those differ (a sensor-active K is in the
     * native sensor frame), we rescale K by the
     * `pipelineW / nativeWidth` and `pipelineH / nativeHeight` ratios
     * so the focal/principal point lands inside the analyser frame.
     */
    private fun resolveIntrinsics(pipelineW: Int, pipelineH: Int): FloatArray {
        // When the device exposes a static LENS_INTRINSIC_CALIBRATION,
        // build a [KResolution] in the STATIC_LENS_INTRINSIC branch
        // ourselves. We can't pass a CameraCharacteristics proxy to
        // [Camera2Intrinsics.resolveK] (final class), so we reproduce
        // the static-K path inline and hand off to the resolver only
        // for the pinhole fallback when the static key is absent.
        val staticK = staticIntrinsicCalibration
        val sensorSize = sensorActiveArraySize
        val resolution: KResolution = if (staticK != null && staticK.size == 5) {
            // intrinsic5ToK: drop skew, emit row-major 3×3.
            val k3x3 = floatArrayOf(
                staticK[0], 0.0f, staticK[2],
                0.0f, staticK[1], staticK[3],
                0.0f, 0.0f, 1.0f,
            )
            KResolution(
                kMatrix = k3x3,
                source = KSource.STATIC_LENS_INTRINSIC,
                nativeWidth = sensorSize?.width ?: pipelineW,
                nativeHeight = sensorSize?.height ?: pipelineH,
            )
        } else {
            // No static K → pinhole fallback. We pass `chars = null`
            // because CameraCharacteristics is a final class and we
            // cannot synthesise one; the resolver's
            // SENSOR_INFO_ACTIVE_ARRAY_SIZE lookup is only consulted
            // when `perFrame` or static K is present, neither of which
            // applies here.
            Camera2Intrinsics.resolveK(
                perFrame = null,
                chars = null,
                pipelineW = pipelineW,
                pipelineH = pipelineH,
            )
        }
        val k = resolution.kMatrix
        val nw = resolution.nativeWidth
        val nh = resolution.nativeHeight
        if (nw == pipelineW && nh == pipelineH) return k
        // Two-step rescale: the analyser path centre-crops the source
        // to the pipeline aspect (see fillByteViewResampled) before the
        // bilinear downsample. Skipping the crop step leaves cx/cy in
        // the uncropped sensor frame — on any sensor-active K with
        // (nw, nh) ≫ (pipelineW, pipelineH) that shifts the principal
        // point by hundreds of source pixels and biases every pose solve.
        //
        // 1. compute the largest pipelineW:pipelineH crop centred on
        //    (nw, nh) (same logic as fillByteViewResampled);
        // 2. shift cx, cy by the crop offset;
        // 3. scale by pipelineW / cropW (diagonal-only) — matches the
        //    iOS path and the original intent of the comment below.
        var cropW: Int
        var cropH: Int
        if (nw.toLong() * pipelineH >= nh.toLong() * pipelineW) {
            cropH = nh
            cropW = (nh.toLong() * pipelineW / pipelineH).toInt()
            if (cropW > nw) cropW = nw
        } else {
            cropW = nw
            cropH = (nw.toLong() * pipelineH / pipelineW).toInt()
            if (cropH > nh) cropH = nh
        }
        val offsetX = (nw - cropW) / 2
        val offsetY = (nh - cropH) / 2
        val sx = pipelineW.toFloat() / cropW.toFloat()
        val sy = pipelineH.toFloat() / cropH.toFloat()
        // K' = diag(sx, sy, 1) · (K with cx, cy shifted by crop offset).
        return floatArrayOf(
            k[0] * sx, k[1] * sx, (k[2] - offsetX) * sx,
            k[3] * sy, k[4] * sy, (k[5] - offsetY) * sy,
            k[6], k[7], k[8],
        )
    }

    private fun currentDisplayRotation(): Int {
        // Display.getRotation() requires API 30+; older API levels go
        // through the WindowManager's default display. Context.getDisplay()
        // is non-null on API 30+ when the context is associated with a
        // display (Activity always is); it throws UnsupportedOperationException
        // otherwise. CaptureScreen normally passes an Activity-bound context,
        // but its orientation-lock effect tolerates the non-Activity case
        // by skipping the lock and logging — match that behaviour here so a
        // degraded host doesn't crash the camera bind.
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.display.rotation
            } else {
                @Suppress("DEPRECATION")
                val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                @Suppress("DEPRECATION")
                wm?.defaultDisplay?.rotation ?: Surface.ROTATION_0
            }
        } catch (_: UnsupportedOperationException) {
            Surface.ROTATION_0
        }
    }

    /** Capture the reference still into `<workingDir>/photo.jpg`. */
    @SuppressLint("MissingPermission") // caller-checked by CaptureScreen
    suspend fun takePhoto(): String {
        _state.value = CameraSessionState.CapturingPhoto
        try {
            return capturePictureTo(photoFile)
        } finally {
            _state.value = CameraSessionState.Ready
        }
    }

    /**
     * Capture a burst of still photos by taking one every [intervalMs] for
     * [durationMs]. Returns the absolute paths of the captured JPEGs in capture
     * order. The first frame is taken immediately; subsequent frames respect
     * [intervalMs] until [durationMs] elapses or the deadline is hit.
     *
     * [onProgress] is invoked after each frame lands with the running count
     * (1, 2, …). The caller drives the on-screen progress indicator from there.
     */
    @SuppressLint("MissingPermission")
    suspend fun captureBurst(
        durationMs: Long,
        intervalMs: Long,
        onProgress: (taken: Int) -> Unit,
    ): List<String> {
        require(durationMs > 0) { "durationMs must be positive" }
        require(intervalMs > 0) { "intervalMs must be positive" }
        val target = (durationMs / intervalMs).toInt().coerceAtLeast(1)
        _state.value = CameraSessionState.CapturingBurst(taken = 0, target = target)
        val paths = mutableListOf<String>()
        try {
            val deadline = System.currentTimeMillis() + durationMs
            while (System.currentTimeMillis() < deadline) {
                val out = File(
                    workingDir,
                    "frame_${(paths.size + 1).toString().padStart(3, '0')}.jpg",
                )
                capturePictureTo(out)
                paths.add(out.absolutePath)
                onProgress(paths.size)
                _state.value = CameraSessionState.CapturingBurst(
                    taken = paths.size,
                    target = target,
                )
                val remaining = deadline - System.currentTimeMillis()
                if (remaining <= 0) break
                delay(minOf(intervalMs, remaining))
            }
        } finally {
            _state.value = CameraSessionState.Ready
        }
        return paths
    }

    private suspend fun capturePictureTo(file: File): String =
        suspendCancellableCoroutine { cont ->
            // CameraX appends to existing files in some configurations — clear any
            // stale image left from a previous take inside the same workingDir.
            if (file.exists()) file.delete()
            val output = ImageCapture.OutputFileOptions.Builder(file).build()
            imageCapture.takePicture(
                output,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(results: ImageCapture.OutputFileResults) {
                        cont.resume(file.absolutePath)
                    }
                    override fun onError(exception: ImageCaptureException) {
                        cont.resumeWithException(exception)
                    }
                },
            )
        }

    /**
     * Capture a single JPEG and return the encoded bytes directly for
     * the arm loop. Uses [ImageCapture.OnImageCapturedCallback] on
     * [shutterExecutor] and extracts the bytes from the [ImageProxy]
     * at callback time, which saves the 50-120 ms/arm round-trip the
     * disk-write + Main-dispatch + readBytes() path incurred.
     *
     * Side effect: the encoded bytes are also written to
     * `<workingDir>/<label>_<timestampMs>.jpg` via a fire-and-forget
     * coroutine on [diskWriteScope]; the arm path does NOT block on it.
     *
     * The reference-still / burst paths continue to use
     * [capturePictureTo] which preserves the [OnImageSavedCallback] +
     * disk-write semantics callers depend on.
     */
    @SuppressLint("MissingPermission")
    suspend fun captureJpegBytes(label: String): ByteArray =
        suspendCancellableCoroutine { cont ->
            imageCapture.takePicture(
                // Background executor (single-thread, owned by this
                // controller). Do NOT use ContextCompat.getMainExecutor —
                // that's the regression we're undoing.
                shutterExecutor,
                object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        val bytes = try {
                            extractJpegBytes(image)
                        } catch (t: Throwable) {
                            // Close before resuming; the analyser is
                            // back-pressured by un-closed proxies.
                            try { image.close() } catch (_: Throwable) {}
                            cont.resumeWithException(t)
                            return
                        }
                        try { image.close() } catch (t: Throwable) {
                            Log.w(TAG, "captureJpegBytes: image.close threw", t)
                        }
                        // Fire-and-forget debug-copy write; errors are
                        // logged but never block the arm path.
                        diskWriteFanout(bytes, label, System.currentTimeMillis())
                        cont.resume(bytes)
                    }
                    override fun onError(exception: ImageCaptureException) {
                        cont.resumeWithException(exception)
                    }
                },
            )
        }

    /**
     * Pull the encoded JPEG out of the CameraX [ImageProxy].
     *
     * The first plane of an `ImageCapture` JPEG proxy holds the full
     * encoded buffer. `buffer.position()` is not guaranteed to be zero,
     * so we copy `buffer.remaining()` starting at the current position.
     */
    private fun extractJpegBytes(image: ImageProxy): ByteArray {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return bytes
    }

    /**
     * Debug-snapshot retention. Fire-and-forget — the arm-shutter
     * path has already resumed by the time this runs and failures
     * are logged but never block the next arm.
     */
    private fun diskWriteFanout(bytes: ByteArray, label: String, timestampMs: Long) {
        val target = File(workingDir, "${label}_$timestampMs.jpg")
        diskWriteScope.launch {
            try {
                target.outputStream().use { it.write(bytes) }
            } catch (t: Throwable) {
                Log.w(TAG, "diskWriteFanout failed for ${target.name}: ${t.message}", t)
            }
        }
    }

    fun dispose() {
        // Detach the tap first so the in-flight analyser callback
        // (if any) drops on the next read.
        liveFrameTap.set(null)
        // Drop the marker-focus controller so any in-flight analyser
        // tick skips ingestFrame cleanly.
        markerFocusController.set(null)
        markerByteBuffer = null
        // Clear the analyzer before unbind; the executor is then idle
        // and can be shut down without dropping queued frames.
        try {
            imageAnalysis.clearAnalyzer()
        } catch (e: Exception) {
            Log.w(TAG, "clearAnalyzer failed on dispose", e)
        }
        try {
            ProcessCameraProvider.getInstance(context).get().unbindAll()
        } catch (e: Exception) {
            Log.w(TAG, "unbindAll failed on dispose", e)
        }
        try {
            analyserExecutor.shutdown()
        } catch (e: Exception) {
            Log.w(TAG, "analyser executor shutdown failed", e)
        }
        // Shut down the shutter executor + disk-write scope owned by
        // this controller. Idempotent if either was never used.
        try {
            shutterExecutor.shutdown()
        } catch (e: Exception) {
            Log.w(TAG, "shutter executor shutdown failed", e)
        }
        try {
            diskWriteScope.cancel()
        } catch (e: Exception) {
            Log.w(TAG, "diskWriteScope cancel failed", e)
        }
        boundCamera = null
        torchEnabled = false
        staticIntrinsicCalibration = null
        sensorActiveArraySize = null
        liveFloatBuffer = null
        liveFloatStage = null
        liveRowBuffer = null
        // Reset scratches so a subsequent re-bind picks up fresh sizes.
        yPlaneScratch = ByteArray(0)
        markerByteScratch = ByteArray(0)
        // Drop the cached K so a re-bind (different camera, orientation
        // flip, rotation-lock toggle) picks up fresh sensor metadata.
        cachedAnalyserIntrinsics = null
    }

    // MARK: - Capture-frame validator

    /**
     * Outcome of [validateAndStampJpegBytes]. `stampedBytes` is the
     * input JPEG with `TIFF.Artist` + `TIFF.ImageDescription`
     * stamped via `androidx.exifinterface.media.ExifInterface`
     * (parallel to the iOS sibling). When [accepted] is false the
     * caller (shutter callback / ref provider) should drop the
     * frame — return null to the driver so the bundle skips that
     * view. The ref-still path treats [accepted] as a hint only;
     * the ref is always persisted because it anchors every per-arm
     * gate, and a ref capture with no marker simply falls back to
     * the wide absolute defaults on future shots.
     */
    data class ValidatedJpegResult(
        val stampedBytes: ByteArray,
        val verdict: MarkerValidator.CaptureVerdict,
        val accepted: Boolean,
        val diagPx: Float,
        val blurVariance: Float,
        val refDiagPx: Float?,
        val refBlurVariance: Float?,
        val decodeWidth: Int,
        val decodeHeight: Int,
        /** Scene-luminance verdict — non-null only on the reference still. */
        val refLuminance: MarkerValidator.RefLuminance?,
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is ValidatedJpegResult) return false
            if (!stampedBytes.contentEquals(other.stampedBytes)) return false
            return verdict == other.verdict
                && accepted == other.accepted
                && diagPx == other.diagPx
                && blurVariance == other.blurVariance
                && refDiagPx == other.refDiagPx
                && refBlurVariance == other.refBlurVariance
                && decodeWidth == other.decodeWidth
                && decodeHeight == other.decodeHeight
                && refLuminance == other.refLuminance
        }
        override fun hashCode(): Int {
            var h = stampedBytes.contentHashCode()
            h = 31 * h + verdict.hashCode()
            h = 31 * h + accepted.hashCode()
            h = 31 * h + diagPx.hashCode()
            h = 31 * h + blurVariance.hashCode()
            h = 31 * h + (refDiagPx?.hashCode() ?: 0)
            h = 31 * h + (refBlurVariance?.hashCode() ?: 0)
            h = 31 * h + decodeWidth
            h = 31 * h + decodeHeight
            h = 31 * h + (refLuminance?.hashCode() ?: 0)
            return h
        }
    }

    /**
     * Opt the per-arm shutter path into capture-frame validation.
     * Idempotent. Mirrors iOS's `enableBurstValidation()`.
     */
    fun attachCaptureValidator() {
        captureValidatorEnabled = true
        Log.i(TAG, "capture-frame validator enabled")
    }

    /**
     * Forget the cached reference diagonal / blur — call when a
     * fresh session begins so the next ref capture re-anchors the
     * gate.
     */
    fun resetValidatorState() {
        referenceDiagPx.set(null)
        referenceBlurVariance.set(null)
        referenceMarkerVersion.set(null)
        lastLiveMarkerSeenAtMs.set(null)
    }

    fun lastReferenceMarkerVersion(): String? = referenceMarkerVersion.get()

    fun lastLiveMarkerSeenAtMs(): Long? = lastLiveMarkerSeenAtMs.get()

    /**
     * Validate one captured JPEG and stamp the validation metrics
     * into its EXIF (`TIFF.Artist` + `TIFF.ImageDescription`,
     * mirroring the iOS layout — those fields survive
     * `PhotosphereSession.writeViewExif`'s pass through `saveAttributes`
     * which only mutates MAKE / MODEL / SOFTWARE / DATETIME /
     * ORIENTATION / EXPOSURE / ISO / UserComment).
     *
     * Always returns a non-null [ValidatedJpegResult] — the
     * validator-disabled / decode-failed / validator-throws short
     * circuits each stamp a sentinel Artist value
     * (`=no_validator` / `=skipped_no_preview` / `=skipped_validator_error`)
     * so every frame in the bundle is self-describing. The reference
     * path passes `isReference = true`; that capture is always
     * accepted and the result.refDiag / refBlur are recorded for
     * future per-arm gates.
     */
    fun validateAndStampJpegBytes(
        jpeg: ByteArray,
        isReference: Boolean,
        originalMeanLuma: Float? = null,
    ): ValidatedJpegResult {
        // Sample telemetry ONCE at the top of the stamp path. The same
        // sample lands in TIFF.Copyright (via stampValidationExif /
        // stampArtistOnly) and in pose_log.json (via lastShutterTelemetry
        // → driver trampoline → PhotosphereShutterResult). One probe
        // per photo, never on the analyser hot path.
        val telemetry = com.twinskin.photosphere.PhotosphereDeviceTelemetrySampler.sample(
            context = context,
            sessionStartElapsedNs = sessionStartElapsedNs,
        )
        lastShutterTelemetry = telemetry
        if (!captureValidatorEnabled) {
            return ValidatedJpegResult(
                stampedBytes = stampArtistOnly(jpeg, "TWINSKIN_VALIDATION=no_validator", telemetry) ?: jpeg,
                verdict = MarkerValidator.CaptureVerdict.OK,
                accepted = true,
                diagPx = 0f,
                blurVariance = 0f,
                refDiagPx = null,
                refBlurVariance = null,
                decodeWidth = 0,
                decodeHeight = 0,
                refLuminance = null,
            )
        }
        val decoded = decodeJpegToGrayscale(
            jpeg,
            VALIDATION_DECODE_MAX_PIXEL_SIZE,
            includeRgba = isReference,
        )
            ?: run {
                Log.w(TAG, "validateAndStampJpegBytes: JPEG decode failed (${jpeg.size} bytes)")
                return ValidatedJpegResult(
                    stampedBytes = stampArtistOnly(jpeg, "TWINSKIN_VALIDATION=skipped_no_preview", telemetry) ?: jpeg,
                    verdict = MarkerValidator.CaptureVerdict.OK,
                    accepted = true,
                    diagPx = 0f,
                    blurVariance = 0f,
                    refDiagPx = null,
                    refBlurVariance = null,
                    decodeWidth = 0,
                    decodeHeight = 0,
                    refLuminance = null,
                )
            }
        val params = paramsForUpcomingCapture(isReference)
        val validation = try {
            MarkerValidator.validateCapture(
                gray = decoded.buffer,
                width = decoded.width,
                height = decoded.height,
                rowStride = decoded.width,
                roiX0 = 0,
                roiY0 = 0,
                roiX1 = decoded.width,
                roiY1 = decoded.height,
                params = params,
            )
        } catch (t: Throwable) {
            Log.w(TAG, "validateAndStampJpegBytes: validateCapture threw: ${t.message}", t)
            return ValidatedJpegResult(
                stampedBytes = stampArtistOnly(jpeg, "TWINSKIN_VALIDATION=skipped_validator_error", telemetry) ?: jpeg,
                verdict = MarkerValidator.CaptureVerdict.OK,
                accepted = true,
                diagPx = 0f,
                blurVariance = 0f,
                refDiagPx = null,
                refBlurVariance = null,
                decodeWidth = decoded.width,
                decodeHeight = decoded.height,
                refLuminance = null,
            )
        }
        if (isReference) {
            if (validation.verdict != MarkerValidator.CaptureVerdict.MARKER_NOT_FOUND) {
                referenceDiagPx.set(validation.diagPx)
                if (validation.blurVariance > 0f) {
                    referenceBlurVariance.set(validation.blurVariance)
                }
            } else {
                referenceDiagPx.set(null)
                referenceBlurVariance.set(null)
            }
            // Verdict-independent — a far or blurry ref that still
            // decodes the id counts as detected.
            referenceMarkerVersion.set(
                if (validation.detection?.markerId == EXPECTED_ARUCO_MARKER_ID) {
                    MARKER_VERSION_V3
                } else {
                    null
                },
            )
        }
        // Read after the ref-update block so the ref image self-references
        // its own diag/blur in TIFF.ImageDescription (matches iOS).
        val refDiag = referenceDiagPx.get()
        val refBlur = referenceBlurVariance.get()
        Log.i(
            TAG,
            "frame validated: ref=$isReference verdict=${validation.verdict}" +
                " diag=${validation.diagPx} blur=${validation.blurVariance}" +
                " decode=${decoded.width}x${decoded.height}" +
                " band=[${params.minDiagPx},${params.maxDiagPx}]" +
                " blurFloor=${params.minBlurVariance}" +
                " refDiag=${refDiag ?: "n/a"} refBlur=${refBlur ?: "n/a"}",
        )
        // Reuses the RGBA buffer from the single decode above; the
        // per-arm path never decodes RGBA.
        val refLuminance: MarkerValidator.RefLuminance? =
            if (isReference && decoded.rgba != null) {
                try {
                    MarkerValidator.evalRefLuminance(
                        rgba = decoded.rgba,
                        width = decoded.width,
                        height = decoded.height,
                        rowStride = decoded.width * 4,
                        blurOk = validation.verdict != MarkerValidator.CaptureVerdict.BLURRY,
                    )
                } catch (t: Throwable) {
                    Log.w(TAG, "validateAndStampJpegBytes: evalRefLuminance threw: ${t.message}", t)
                    null
                }
            } else {
                null
            }
        val accepted = isReference || validation.verdict == MarkerValidator.CaptureVerdict.OK
        val stamped = stampValidationExif(
            jpeg = jpeg,
            verdict = validation.verdict,
            diagPx = validation.diagPx,
            blurVariance = validation.blurVariance,
            decodeWidth = decoded.width,
            decodeHeight = decoded.height,
            refDiagPx = refDiag,
            refBlurVariance = refBlur,
            refLuminance = refLuminance,
            torchEnabled = torchEnabled,
            originalMeanLuma = originalMeanLuma ?: refLuminance?.meanLuma,
            telemetry = telemetry,
        ) ?: jpeg
        return ValidatedJpegResult(
            stampedBytes = stamped,
            verdict = validation.verdict,
            accepted = accepted,
            diagPx = validation.diagPx,
            blurVariance = validation.blurVariance,
            refDiagPx = refDiag,
            refBlurVariance = refBlur,
            decodeWidth = decoded.width,
            decodeHeight = decoded.height,
            refLuminance = refLuminance,
        )
    }

    /**
     * Pick the threshold band for the upcoming capture. Reference
     * still + any per-arm shot taken before a ref establishes a
     * marker → wide absolute defaults; per-arm with ref on record
     * → tight ±tolerance band centred on the ref-frame values.
     */
    private fun paramsForUpcomingCapture(
        isReference: Boolean,
    ): MarkerValidator.CaptureValidationParams {
        if (isReference) {
            return MarkerValidator.CaptureValidationParams(
                minDiagPx = DEFAULT_MIN_DIAG_PX,
                maxDiagPx = DEFAULT_MAX_DIAG_PX,
                minBlurVariance = DEFAULT_MIN_BLUR_VARIANCE,
            )
        }
        val refDiag = referenceDiagPx.get()
        val refBlur = referenceBlurVariance.get()
        val minDiag = if (refDiag != null && refDiag > 0f) {
            refDiag * (1f - RELATIVE_DISTANCE_TOLERANCE)
        } else {
            DEFAULT_MIN_DIAG_PX
        }
        val maxDiag = if (refDiag != null && refDiag > 0f) {
            refDiag * (1f + RELATIVE_DISTANCE_TOLERANCE)
        } else {
            DEFAULT_MAX_DIAG_PX
        }
        val minBlur = if (refBlur != null && refBlur > 0f) {
            refBlur * (1f - RELATIVE_BLUR_TOLERANCE)
        } else {
            DEFAULT_MIN_BLUR_VARIANCE
        }
        return MarkerValidator.CaptureValidationParams(
            minDiagPx = minDiag,
            maxDiagPx = maxDiag,
            minBlurVariance = minBlur,
        )
    }

    /**
     * Decode the JPEG to a packed-uint8 grayscale ByteBuffer.
     * Uses [BitmapFactory.Options.inSampleSize] to downsample at
     * decode time (cheap — picks the closest 1/2^N JPEG DCT scale),
     * then Rec.601 integer-luminance conversion from ARGB pixels.
     */
    private data class DecodedFrame(
        val buffer: ByteBuffer,
        /** Packed RGBA, present only when [decodeJpegToGrayscale] was
         *  asked for it — feeds the native reference-luminance probe. */
        val rgba: ByteBuffer?,
        val width: Int,
        val height: Int,
    )

    private fun decodeJpegToGrayscale(
        jpeg: ByteArray,
        maxLongSide: Int,
        includeRgba: Boolean = false,
    ): DecodedFrame? {
        val sizeOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, sizeOpts)
        val srcW = sizeOpts.outWidth
        val srcH = sizeOpts.outHeight
        if (srcW <= 0 || srcH <= 0) return null
        val longSide = maxOf(srcW, srcH)
        var sample = 1
        while (longSide / (sample * 2) >= maxLongSide) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size, opts) ?: return null
        // inSampleSize is a power-of-2 cap, so the decode can still exceed
        // maxLongSide by up to ~2x. Bilinear-resample to the exact cap so
        // diag_px / blur_var stay comparable to the iOS thumbnail path.
        val decodedLong = maxOf(decoded.width, decoded.height)
        val bitmap = if (decodedLong > maxLongSide) {
            val scale = maxLongSide.toDouble() / decodedLong
            val targetW = (decoded.width * scale + 0.5).toInt().coerceAtLeast(1)
            val targetH = (decoded.height * scale + 0.5).toInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(decoded, targetW, targetH, /* filter = */ true)
            if (scaled !== decoded) decoded.recycle()
            scaled
        } else {
            decoded
        }
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        bitmap.recycle()
        val gray = ByteBuffer.allocateDirect(w * h).order(ByteOrder.nativeOrder())
        val rgba = if (includeRgba) {
            ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
        } else {
            null
        }
        for (p in pixels) {
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            // Rec.601 integer luminance (76*R + 150*G + 30*B) >> 8.
            val luma = (76 * r + 150 * g + 30 * b) shr 8
            gray.put((luma and 0xFF).toByte())
            if (rgba != null) {
                rgba.put(r.toByte())
                rgba.put(g.toByte())
                rgba.put(b.toByte())
                rgba.put(0xFF.toByte())
            }
        }
        gray.rewind()
        rgba?.rewind()
        return DecodedFrame(gray, rgba, w, h)
    }

    /**
     * Stamp the validation metrics into the JPEG via a temp-file
     * dance with `androidx.exifinterface.media.ExifInterface`
     * (the library can read from an `InputStream` but only writes
     * back to the `File`/`String` constructor's target).
     *
     * Writes:
     *   TIFF.Artist           = "TWINSKIN_VALIDATION=ran"
     *   TIFF.ImageDescription = "TWINSKIN_VALIDATION;verdict=…;
     *                            diag_px=…;blur_var=…;decode=WxH;
     *                            ref_diag=…;ref_blur=…"
     *
     * Both fields survive `PhotosphereSession.writeViewExif`'s
     * subsequent `saveAttributes` because that pass only mutates
     * MAKE / MODEL / SOFTWARE / DATETIME / ORIENTATION / EXPOSURE /
     * ISO / UserComment.
     *
     * Returns null on any ExifInterface failure (caller falls back
     * to un-stamped bytes).
     */
    /** Stamp only TIFF.Artist, no ImageDescription. Used on the
     *  validator-disabled / decode-failed paths so an analyst can
     *  still tell those frames apart from "validator decoded and
     *  scored a verdict". Mirrors iOS's =no_validator / =skipped_no_preview
     *  Artist values. */
    private fun stampArtistOnly(
        jpeg: ByteArray,
        artist: String,
        telemetry: com.twinskin.photosphere.PhotosphereDeviceTelemetry? = null,
    ): ByteArray? {
        val tempFile = File.createTempFile("twinskin_validation_", ".jpg", context.cacheDir)
        return try {
            tempFile.writeBytes(jpeg)
            val exif = androidx.exifinterface.media.ExifInterface(tempFile.absolutePath)
            exif.setAttribute(
                androidx.exifinterface.media.ExifInterface.TAG_ARTIST,
                artist,
            )
            if (telemetry != null) {
                exif.setAttribute(
                    androidx.exifinterface.media.ExifInterface.TAG_COPYRIGHT,
                    telemetry.exifPayload(),
                )
            }
            exif.saveAttributes()
            tempFile.readBytes()
        } catch (t: Throwable) {
            Log.w(TAG, "stampArtistOnly failed: ${t.message}", t)
            null
        } finally {
            try { tempFile.delete() } catch (_: Throwable) {}
        }
    }

    private fun stampValidationExif(
        jpeg: ByteArray,
        verdict: MarkerValidator.CaptureVerdict,
        diagPx: Float,
        blurVariance: Float,
        decodeWidth: Int,
        decodeHeight: Int,
        refDiagPx: Float?,
        refBlurVariance: Float?,
        refLuminance: MarkerValidator.RefLuminance? = null,
        torchEnabled: Boolean = false,
        /** Mean luma of the FIRST (pre-torch) reference shot — equals
         *  [refLuminance].meanLuma when the accepted shot is the first. */
        originalMeanLuma: Float? = null,
        telemetry: com.twinskin.photosphere.PhotosphereDeviceTelemetry? = null,
    ): ByteArray? {
        val verdictName = when (verdict) {
            MarkerValidator.CaptureVerdict.OK -> "ok"
            MarkerValidator.CaptureVerdict.MARKER_NOT_FOUND -> "markerNotFound"
            MarkerValidator.CaptureVerdict.TOO_FAR -> "tooFar"
            MarkerValidator.CaptureVerdict.TOO_CLOSE -> "tooClose"
            MarkerValidator.CaptureVerdict.BLURRY -> "blurry"
        }
        val refDiagStr = refDiagPx?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: "n/a"
        val refBlurStr = refBlurVariance?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: "n/a"
        // The reference-still luminance + torch block must stay
        // byte-for-byte aligned with the iOS sibling in
        // CameraSessionController.swift.
        val description = if (refLuminance != null) {
            String.format(
                java.util.Locale.US,
                "TWINSKIN_VALIDATION;verdict=%s;diag_px=%.2f;blur_var=%.2f;" +
                    "decode=%dx%d;ref_diag=%s;ref_blur=%s;" +
                    "mean_y=%.2f;dark_share=%.4f;bright_share=%.4f;torch=%s;" +
                    "orig_mean_y=%.2f",
                verdictName,
                diagPx,
                blurVariance,
                decodeWidth,
                decodeHeight,
                refDiagStr,
                refBlurStr,
                refLuminance.meanLuma,
                refLuminance.darkPixelShare,
                refLuminance.brightPixelShare,
                if (torchEnabled) "on" else "off",
                originalMeanLuma ?: refLuminance.meanLuma,
            )
        } else {
            String.format(
                java.util.Locale.US,
                "TWINSKIN_VALIDATION;verdict=%s;diag_px=%.2f;blur_var=%.2f;" +
                    "decode=%dx%d;ref_diag=%s;ref_blur=%s",
                verdictName,
                diagPx,
                blurVariance,
                decodeWidth,
                decodeHeight,
                refDiagStr,
                refBlurStr,
            )
        }
        // ExifInterface requires a file path, not bytes. The scratch
        // file MUST NOT land under workingDir — session.submit
        // validates that every path in CaptureResult is inside
        // workingDir, and a stray *.jpg from a crash between
        // createTempFile and delete would get picked up by the bundle
        // builder. cacheDir is OS-cleared on pressure.
        val tempFile = File.createTempFile("twinskin_validation_", ".jpg", context.cacheDir)
        return try {
            tempFile.writeBytes(jpeg)
            val exif = androidx.exifinterface.media.ExifInterface(tempFile.absolutePath)
            exif.setAttribute(
                androidx.exifinterface.media.ExifInterface.TAG_ARTIST,
                "TWINSKIN_VALIDATION=ran",
            )
            exif.setAttribute(
                androidx.exifinterface.media.ExifInterface.TAG_IMAGE_DESCRIPTION,
                description,
            )
            if (telemetry != null) {
                exif.setAttribute(
                    androidx.exifinterface.media.ExifInterface.TAG_COPYRIGHT,
                    telemetry.exifPayload(),
                )
            }
            exif.saveAttributes()
            tempFile.readBytes()
        } catch (t: Throwable) {
            Log.w(TAG, "stampValidationExif failed: ${t.message}", t)
            null
        } finally {
            try { tempFile.delete() } catch (_: Throwable) {}
        }
    }

    private companion object {
        const val TAG = "CameraSessionController"

        /**
         * Canonical 35-mm-equivalent focal length of a smartphone's
         * standard wide (1x) back camera. Pixel main wide ≈ 25 mm,
         * Samsung A21s main wide ≈ 26 mm, iPhone main wide ≈ 26 mm —
         * ultrawides cluster at ~13 mm and teles at ≥50 mm, so 26 is a
         * safe centre for the wide-lens scorer.
         */
        private const val TARGET_WIDE_FOCAL_35MM: Float = 26f


        /**
         * Analyser frame width. Matches `PhotosphereConfig().width`;
         * changing this without also changing the session config will
         * trip a `require()` in `enqueueLiveFrame`.
         */
        const val ANALYSER_WIDTH = 640

        /**
         * Analyser frame height. Matches `PhotosphereConfig().height`.
         */
        const val ANALYSER_HEIGHT = 480

        /**
         * Cadence at which analyser frames are forwarded to the
         * marker-focus controller. At ~30 fps analyser cadence this
         * gives ~6 Hz ArUco probing, well under the controller's
         * `lockTimeoutMs` revert window.
         */
        const val MARKER_CADENCE: Int = 5

        // ─── Capture-frame validator thresholds ──────────────────────────
        //
        // These six values must stay in sync with the iOS sibling at
        // `packages/sdk/sdk-ios/Sources/Capture/CameraSessionController.swift`.
        // See `packages/sdk/CLAUDE.md` "Cross-cutting: capture-frame
        // validator thresholds" — drift produces silent verdict
        // divergence across platforms.

        /** Long-side pixel cap when decoding the captured JPEG to
         *  grayscale before ArUco refinement. 1280 keeps a typical
         *  wound-distance marker at 100-250 px on a side at ~25 ms
         *  decode cost on flagship Android. */
        private const val VALIDATION_DECODE_MAX_PIXEL_SIZE: Int = 1280

        /** Symmetric tolerance around `referenceDiagPx` for the per-
         *  arm distance gate. ±25% of the ref-frame diagonal. */
        private const val RELATIVE_DISTANCE_TOLERANCE: Float = 0.25f

        /** Lower-bound tolerance for the per-arm blur gate as a
         *  fraction of `referenceBlurVariance`. 0.3 → per-arm shots
         *  must reach ≥70% of the ref's Laplacian variance. */
        private const val RELATIVE_BLUR_TOLERANCE: Float = 0.3f

        /** Wide absolute distance band applied to the reference
         *  still + any per-arm shot taken before the ref establishes
         *  a marker. */
        private const val DEFAULT_MIN_DIAG_PX: Float = 20f
        private const val DEFAULT_MAX_DIAG_PX: Float = 400f

        /** Absolute Laplacian-variance floor for the fallback path
         *  (no ref established yet). */
        private const val DEFAULT_MIN_BLUR_VARIANCE: Float = 150f

        /**
         * Settle timeout for [lockLensAndExposureForPhotosphere].
         * 800 ms is the upper bound observed for AF settle on
         * LIMITED-HAL devices; FULL HALs settle within 200-400 ms.
         */
        const val LENS_LOCK_SETTLE_TIMEOUT_MS: Int = 800

        /** ArUco dictionary id of the current ("v3") TwinSkin marker. */
        private const val EXPECTED_ARUCO_MARKER_ID: Int = 16
        private const val MARKER_VERSION_V3: String = "v3"
    }
}

/** Adapter: [com.google.common.util.concurrent.ListenableFuture] → suspend. */
private suspend fun <T> com.google.common.util.concurrent.ListenableFuture<T>.awaitCompat(): T =
    suspendCancellableCoroutine { cont ->
        addListener({
            try { cont.resume(get()) } catch (e: Exception) { cont.resumeWithException(e) }
        }, Runnable::run)
    }
