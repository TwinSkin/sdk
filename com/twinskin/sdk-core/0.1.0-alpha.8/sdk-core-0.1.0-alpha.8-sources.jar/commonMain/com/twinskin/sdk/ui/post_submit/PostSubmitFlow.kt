@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.post_submit

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.CaptureState
import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.GenericAnnotation
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.ui.annotation_editor.AnnotationEditorScaffold
import com.twinskin.sdk.ui.annotation_editor.GenericAnnotationEditor
import com.twinskin.sdk.ui.annotation_editor.GenericAnnotationEditorState
import com.twinskin.sdk.ui.annotation_editor.WoundAnnotationEditor
import com.twinskin.sdk.ui.annotation_editor.WoundAnnotationEditorState
import com.twinskin.sdk.ui.annotation_editor.loadImageFromPath
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Drives a capture session from `submit()` to the integrator's `onDone`,
 * routing on [ConditionType]:
 *   - [ConditionType.Wound] → dismisses immediately. Upload continues async via
 *     `TransferManager`; the embedder observes progress through
 *     `TwinSkinSdk.captures.observePendingUploads`.
 *   - [ConditionType.Generic] → observes [CaptureSession.state] and renders the
 *     polygon editor ([CaptureState.AwaitingAnnotation]), a 500 ms confirmation
 *     ([CaptureState.AnnotationSubmitted]), or a retry banner
 *     ([CaptureState.AnnotationSubmitFailed]); any pre-AwaitingAnnotation
 *     state shows a "Preparing…" overlay.
 *
 * Used directly by Android's CaptureScreen and embedded on iOS via
 * `PostSubmitFlowViewController`. Centralising the routing here keeps the
 * platform camera screens condition-type-agnostic — they only need to flip a
 * `submitted` flag after `session.submit(...)` returns.
 */
@TwinSkinInternalApi
@Composable
public fun PostSubmitFlow(
    session: CaptureSession,
    onDone: () -> Unit,
    onCancel: () -> Unit,
) {
    if (session.metadata.conditionType == ConditionType.Wound) {
        LaunchedEffect(Unit) { onDone() }
        return
    }

    val state by session.state.collectAsState()
    val scope = rememberCoroutineScope()

    when (val s = state) {
        is CaptureState.AwaitingAnnotation -> AnnotationEditorView(
            session = session,
            photoPath = s.photoPath,
            previous = s.previous,
            scope = scope,
            onCancel = onCancel,
        )
        is CaptureState.AnnotationSubmitted -> {
            LaunchedEffect(Unit) {
                delay(500)
                onDone()
            }
            SubmittedOverlay()
        }
        is CaptureState.AnnotationSubmitFailed ->
            AnnotationSubmitErrorBanner(error = s.error, onRetry = s.retry, onBack = s.back)
        else -> PreparingOverlay()
    }
}

@Composable
private fun AnnotationEditorView(
    session: CaptureSession,
    photoPath: String,
    previous: SdkAnnotation?,
    scope: CoroutineScope,
    onCancel: () -> Unit,
) {
    var image by remember(photoPath) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(photoPath) {
        image = withContext(Dispatchers.Default) { loadImageFromPath(photoPath) }
    }
    val loaded = image
    if (loaded == null) {
        PreparingOverlay()
        return
    }
    val submit: (SdkAnnotation) -> Unit = { annotation ->
        scope.launch {
            try {
                session.submitAnnotation(annotation)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Re-emerges as CaptureState.AnnotationSubmitFailed.
            }
        }
    }
    when (session.metadata.conditionType) {
        ConditionType.Generic -> {
            // `previous` is non-null when the session re-entered AwaitingAnnotation
            // via AnnotationSubmitFailed.back — re-seed the editor with the regions
            // the user had just tried to submit so they can revise rather than redraw.
            val state = remember(previous) {
                GenericAnnotationEditorState(
                    initial = (previous as? GenericAnnotation)
                        ?: GenericAnnotation(regions = emptyList()),
                )
            }
            AnnotationEditorScaffold(
                title = "Trace annotation",
                onCancel = onCancel,
                onDone = { submit(state.toAnnotation()) },
            ) { padding ->
                Box(Modifier.padding(padding)) {
                    GenericAnnotationEditor(image = loaded, state = state)
                }
            }
        }
        // Unreachable today — gated upstream by CaptureApi.submit().
        ConditionType.Wound -> {
            val state = remember { WoundAnnotationEditorState() }
            AnnotationEditorScaffold(
                title = "Trace wound",
                onCancel = onCancel,
                onDone = { submit(state.toAnnotation()) },
            ) { padding ->
                Box(Modifier.padding(padding)) {
                    WoundAnnotationEditor(image = loaded, state = state)
                }
            }
        }
    }
}

@Composable
private fun PreparingOverlay() {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator()
            Spacer(Modifier.height(12.dp))
            Text("Preparing bundle…", color = Color.White)
        }
    }
}

@Composable
private fun SubmittedOverlay() {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        Text("Annotation submitted", color = Color.White)
    }
}

@Composable
private fun AnnotationSubmitErrorBanner(
    error: Throwable,
    onRetry: () -> Unit,
    onBack: (() -> Unit)?,
) {
    Column(
        modifier = Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            "Annotation submit failed: ${error.message ?: error::class.simpleName ?: "unknown"}",
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White,
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (onBack != null) {
                OutlinedButton(onClick = onBack) { Text("Edit") }
            }
            Button(onClick = onRetry) { Text("Retry") }
        }
    }
}
