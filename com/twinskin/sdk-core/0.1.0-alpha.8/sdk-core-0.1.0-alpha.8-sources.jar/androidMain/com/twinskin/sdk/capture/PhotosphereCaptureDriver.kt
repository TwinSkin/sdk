package com.twinskin.sdk.capture

import android.content.Context
import android.util.Log
import com.twinskin.photosphere.PhotosphereSession
import com.twinskin.photosphere.PhotosphereShutterResult
import com.twinskin.photosphere.PhotosphereState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicReference

/**
 * Owns a [PhotosphereSession] for the lifetime of a `CaptureScreen`
 * presentation. Thin platform adapter: Kotlin state plumbing only, no
 * per-frame compute (algorithmic core stays in the shared C ABI of
 * `:photosphere_capture`).
 */
internal class PhotosphereCaptureDriver private constructor(
    private val session: PhotosphereSession,
    private val workingDir: File,
) {
    /** Coarse round-progress milestones; pose-level UI subscribes to [state] instead. */
    sealed class RoundEvent {
        data class RoundWaiting(val round: Int) : RoundEvent()
        data class Capturing(val round: Int, val arm: Int) : RoundEvent()
        data class RoundComplete(val round: Int) : RoundEvent()
        data object AllRoundsDone : RoundEvent()
        data class Aborted(val reason: String) : RoundEvent()
    }

    private val driverScope: CoroutineScope =
        CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _events = MutableSharedFlow<RoundEvent>(
        replay = 0,
        extraBufferCapacity = EVENT_BUFFER_CAPACITY,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST,
    )

    val events: SharedFlow<RoundEvent> = _events.asSharedFlow()

    /** Passthrough of the session's fine-grained state for the capture overlay. */
    val state: StateFlow<PhotosphereState> = session.state

    private var relayJob: Job? = null

    /**
     * Installed post-construction; the session was wired with a stable
     * trampoline that dereferences this property at fire time. Atomic
     * so the UI installer (Compose `LaunchedEffect`) and the session's
     * fire-time read can race safely.
     */
    private val shutterCallback: AtomicReference<(suspend (Int) -> ByteArray?)?> =
        AtomicReference(null)

    /**
     * Single-shot ref-capture guard: the first live frame wins
     * [refBeginIfNeeded] and runs [captureReference]; subsequent
     * frames wait until [refBound] flips true (success) or [refReset]
     * runs (failure → next frame retries).
     */
    private val refCaptureMutex = Mutex()
    @Volatile private var refInFlight: Boolean = false
    @Volatile private var refBound: Boolean = false

    internal val isRefBound: Boolean get() = refBound

    private suspend fun refBeginIfNeeded(): Boolean = refCaptureMutex.withLock {
        if (refBound || refInFlight) return@withLock false
        refInFlight = true
        true
    }

    private suspend fun refMarkBound() = refCaptureMutex.withLock {
        refBound = true
        refInFlight = false
    }

    private suspend fun refReset() = refCaptureMutex.withLock {
        refInFlight = false
    }

    init {
        startStateRelay()
    }

    private fun startStateRelay() {
        relayJob = driverScope.launch {
            session.state.collectLatest { snapshot ->
                when (val stage = snapshot.stage) {
                    is PhotosphereState.Stage.RoundWaiting ->
                        _events.emit(RoundEvent.RoundWaiting(stage.round))
                    is PhotosphereState.Stage.Capturing ->
                        _events.emit(RoundEvent.Capturing(stage.round, stage.targetArm))
                    is PhotosphereState.Stage.RoundComplete ->
                        _events.emit(RoundEvent.RoundComplete(stage.round))
                    is PhotosphereState.Stage.Done ->
                        _events.emit(RoundEvent.AllRoundsDone)
                    is PhotosphereState.Stage.Aborted ->
                        _events.emit(RoundEvent.Aborted(stage.reason.message ?: "aborted"))
                    is PhotosphereState.Stage.RefCapture,
                    is PhotosphereState.Stage.Aiming,
                    is PhotosphereState.Stage.OnTarget,
                    -> Unit
                }
            }
        }
    }

    /** Bind the reference frame; must run once before [enqueueLiveFrame]. */
    suspend fun captureReference(
        refBuffer: FloatArray,
        intrinsics: FloatArray,
        fullResJPEG: ByteArray,
    ) {
        session.captureReference(
            refBuffer = refBuffer,
            intrinsics = intrinsics,
            fullResJPEG = fullResJPEG,
        )
    }

    /**
     * Forward a live analyser frame. Non-blocking; silent no-op when
     * ref is unbound or the session is post-cancel/finalize.
     */
    fun enqueueLiveFrame(
        grayBuffer: ByteBuffer,
        intrinsics: FloatArray,
        timestampNs: Long,
    ) {
        session.enqueueLiveFrame(
            grayBuffer = grayBuffer,
            intrinsics = intrinsics,
            timestampNs = timestampNs,
        )
    }

    /**
     * Returns a [LiveFrameTap] with first-frame-or-enqueue policy: the
     * first live frame triggers [captureReference] via
     * [refJpegProvider]; every subsequent frame goes to
     * [enqueueLiveFrame]. The first-frame trigger is single-shot so
     * concurrent deliveries cannot race the ref-binding state machine;
     * transient [refJpegProvider] / [captureReference] failures reset
     * the guard so the next frame retries.
     *
     * @param tapHostScope coroutine scope owned by the camera-side
     *     producer; the per-frame ref-or-enqueue work runs here so
     *     the producer's executor thread isn't blocked by session-
     *     side mutex contention.
     * @param refJpegProvider invoked exactly once on the winning
     *     first-frame path; returning `null` resets the guard.
     */
    fun buildLiveFrameTap(
        tapHostScope: CoroutineScope,
        refJpegProvider: suspend () -> ByteArray?,
    ): LiveFrameTap = LiveFrameTap { grayBuffer, intrinsics, timestampNs ->
        // Fast path: once refBound is set, run enqueueLiveFrame
        // synchronously to avoid per-frame coroutine + mutex
        // allocations on the analyser hot path. The @Volatile read
        // pairs with refMarkBound's release.
        if (refBound) {
            enqueueLiveFrame(
                grayBuffer = grayBuffer,
                intrinsics = intrinsics,
                timestampNs = timestampNs,
            )
            return@LiveFrameTap
        }
        tapHostScope.launch {
            if (refBeginIfNeeded()) {
                try {
                    val jpegBytes = refJpegProvider() ?: run {
                        Log.w(LOG_TAG, "captureReference aborted: refJpegProvider returned null")
                        refReset()
                        return@launch
                    }
                    val refBuffer = grayBufferToFloatArray(grayBuffer)
                    captureReference(
                        refBuffer = refBuffer,
                        intrinsics = intrinsics,
                        fullResJPEG = jpegBytes,
                    )
                    refMarkBound()
                } catch (e: kotlinx.coroutines.CancellationException) {
                    refReset()
                    throw e
                } catch (e: Exception) {
                    Log.w(LOG_TAG, "captureReference failed: ${e.message}", e)
                    refReset()
                }
                return@launch
            }
            // Loser of the refBeginIfNeeded race: another launch is
            // running captureReference. The winner's refBound=true
            // unblocks the synchronous fast path for future ticks.
        }
    }

    /**
     * Read a direct ByteBuffer of `height*width*4` float32 bytes
     * (range `[0, 255]`, matching the session's enqueueLiveFrame
     * contract) into a FloatArray verbatim.
     */
    private fun grayBufferToFloatArray(buf: ByteBuffer): FloatArray {
        val view = buf.duplicate().order(ByteOrder.nativeOrder())
        view.position(0)
        val floatView = view.asFloatBuffer()
        val out = FloatArray(floatView.remaining())
        floatView.get(out)
        return out
    }

    fun interface LiveFrameTap {
        fun onFrame(grayBuffer: ByteBuffer, intrinsics: FloatArray, timestampNs: Long)
    }

    /**
     * Register the per-arm shutter callback. Invoked once per
     * `OnTarget → Capturing` transition with a flat `viewIndex`
     * (0..15 primary, up to 0..31 with bonus rounds). Returning
     * `null` aborts the commit and the state machine drops back to
     * Aiming. The driver wraps the bytes in
     * [PhotosphereShutterResult] internally so callers don't need
     * to import `:photosphere_capture`.
     */
    fun setShutterCallback(
        callback: suspend (viewIndex: Int) -> ByteArray?,
    ) {
        shutterCallback.set(callback)
    }

    /**
     * Write the bundle (ref + view JPEGs, `index.json`, peer
     * `frame_log.jsonl` + `pose_log.json`) into [workingDir] and
     * return the [CaptureResult] for [CaptureSession.submit]. The
     * peer files ride along with the bundle directory; the submit
     * packing pass picks them up by directory enumeration.
     *
     * @param partial skip the all-16-primary-arms gate (development /
     *     partial captures only).
     */
    suspend fun finalize(partial: Boolean = false): CaptureResult {
        relayJob?.cancel()
        try {
            val sessionDir = session.finalize(partial = partial)
            return bundleDirToCaptureResult(sessionDir)
        } finally {
        }
    }

    /** Abort the in-flight session. Idempotent. */
    fun cancel() {
        relayJob?.cancel()
        session.cancel()
        driverScope.cancel()
    }

    companion object {
        private const val EVENT_BUFFER_CAPACITY: Int = 8
        private const val LOG_TAG: String = "PhotosphereCaptureDriver"

        /**
         * Construct a driver bound to [workingDir]. The session uses
         * [workingDir] as both `sessionDir` (in-flight sidecars) and
         * its finalize destination. The session is wired with a
         * stable trampoline shutter callback so [setShutterCallback]
         * can install the real callback post-construction.
         */
        suspend fun create(
            context: Context,
            workingDir: File,
            // Optional override for the on-target gate threshold;
            // `null` keeps the session-side production default (3°).
            // Synthetic-replay callers raise this to 8° because
            // placeholder-K scenes recover tilt magnitudes that drift
            // 4-6° vs the 20° target ring.
            onTargetDistanceDeg: Float? = null,
            // Sensor→display phi rotation. Live-camera path passes
            // 90f (CameraX analyser is landscape, UI is portrait);
            // synthetic-replay frames are pre-rotated and pass 0f.
            phiOffsetDeg: Float = 0f,
        ): PhotosphereCaptureDriver {
            workingDir.mkdirs()
            // Forward-declared so the trampoline can dereference the
            // not-yet-constructed driver's shutterCallback field.
            // Assigned below before any session state transition can
            // fire the callback.
            val driverRef = AtomicReference<PhotosphereCaptureDriver?>(null)
            val shutterTrampoline: suspend (Int) -> PhotosphereShutterResult? = { viewIndex ->
                val cb = driverRef.get()?.shutterCallback?.get()
                if (cb == null) {
                    null
                } else {
                    val bytes = cb(viewIndex)
                    if (bytes == null) null else PhotosphereShutterResult(bytes = bytes)
                }
            }
            val session = if (onTargetDistanceDeg != null) {
                PhotosphereSession.create(
                    context = context,
                    sessionDir = workingDir,
                    shutterCallback = shutterTrampoline,
                    onTargetDistanceDeg = onTargetDistanceDeg,
                    phiOffsetDeg = phiOffsetDeg,
                )
            } else {
                PhotosphereSession.create(
                    context = context,
                    sessionDir = workingDir,
                    shutterCallback = shutterTrampoline,
                    phiOffsetDeg = phiOffsetDeg,
                )
            }
            return PhotosphereCaptureDriver(
                session = session,
                workingDir = workingDir,
            ).also { driverRef.set(it) }
        }
    }
}
