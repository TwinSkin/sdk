# Capture (Android) — handover notes

This directory holds the Android-native capture flow that ships with the SDK.
It's a **placeholder implementation** built so the rest of the SDK can be
exercised end-to-end while the proper capture pipeline is developed.

## What you're replacing

- `CameraSessionController.kt` — CameraX wrapper (`Preview`, `ImageCapture`,
  `VideoCapture`/`Recorder`). Replace freely: ARCore, Camera2 directly,
  depth/ToF, manual focus, anything. The screen treats it as an opaque
  controller exposing photo + video capture.
- ~~`MarkerVersionPicker.kt`~~ — REMOVED in CL-103 Phase 6 Android
  Part 1 fixup (2026-05-07). The picker was placeholder operator-
  tagging UI; OQ-2 AUTO-DETECT replaces it with a per-frame marker
  classifier wired into `PhotosphereCaptureDriver` (landing in a
  follow-up). The only surviving contract is the `String?` handed to
  `CaptureResult(markerVersion = …)` in `../CaptureScreen.kt` — set
  `null` until the auto-detect Kotlin shim lands. Mirrors the iOS
  removal in `packages/sdk/sdk-ios/Sources/Capture/CLAUDE.md`.
- `CapturePermissions.kt` — minimal Compose-side runtime permission gate
  (CAMERA + RECORD_AUDIO). Replace or extend as needed.

The composable that drives the flow lives one level up
(`com.twinskin.sdk.ui.CaptureScreen` in `../CaptureScreen.kt`). The state
machine, marker picker placement, and 20-second video timer all live there.

## What you must not change (the seam)

The shared SDK depends on this exact contract:

```kotlin
val session = TwinSkinSdk.startCapture(metadata)
// session.workingDir is an absolute path — write the reference still + N
// burst frames there. Conventional file names: CaptureBundleEntries.IMAGE
// = "photo.jpg" for the still; burst frames named "frame_001.jpg",
// "frame_002.jpg", … (or .heic — the server normalises both to JPG).
val result = CaptureResult(
    photoPath = "${session.workingDir}/${CaptureBundleEntries.IMAGE}",
    framePaths = (1..16).map { i ->
        "${session.workingDir}/frame_${i.toString().padStart(3, '0')}.jpg"
    },
    markerVersion = "v3", // or null if no marker detected
)
session.submit(result)        // success path (suspends)
// — or —
session.cancel()              // user backed out (suspends)
// — or —
session.fail(reason = "…")     // unrecoverable error (suspends)
```

- `session.workingDir` is created eagerly by the SDK; you only write files into
  it.
- `session.submit(result)` validates the paths are inside `workingDir` and
  rejects otherwise (`IllegalArgumentException`).
- The SDK deletes `workingDir` on every terminal state (Uploaded / Cancelled /
  Failed). Don't delete files yourself.
- `markerVersion` is forwarded as a free-form `String?` into the bundle
  manifest. The server's `MarkerVersionType` enum (currently `v1` / `v2` /
  `v3`, see `packages/server/lib/src/database/schema.dart`) is the validator —
  unknown values surface as a server-side error on decode. Pass `null` if no
  marker was detected.

The public Composable consumed by integrators (`androidApp/`,
`flutter_plugin/android/`, etc.) is `com.twinskin.sdk.ui.CaptureScreen` —
parameter signature must stay unchanged so existing call sites keep working.

## Things the placeholder does today

- Permissions: requests CAMERA + RECORD_AUDIO via the Compose
  `ActivityResultContracts.RequestMultiplePermissions` launcher.
- Single shutter button → photo, then auto-starts video recording.
- Video runs up to 20 s with a manual stop button; auto-stops at 20 s if the
  user doesn't tap it.
- ~~Marker version picker (chip row above the shutter).~~ REMOVED
  alongside `MarkerVersionPicker.kt` (see above).
- `session.submit(CaptureResult(...))` then dismisses via `onDone`.
- `Cancel` → `session.cancel()` then `onCancel`.
- Portrait-only orientation: `CaptureScreen` (one level up) locks the
  host activity to `SCREEN_ORIENTATION_PORTRAIT` while the screen is on
  top, and `CameraSessionController.bindToLifecycle` pins
  `ImageCapture.targetRotation` to the current display rotation (which
  the lock makes deterministic). Captured JPEGs are pixel-portrait with
  no EXIF rotation. The decrypt lambda re-rotates landscape input as a
  safety net — see
  `packages/capture_pipeline/src/capture_pipeline/image_normalize.py`.
  If you replace the controller, preserve this contract or update the
  lambda's expectations.

Abrupt screen-leaves without hitting Cancel currently leak the session's
`workingDir` until the next process kills it. If that becomes a problem,
plumb a long-lived coroutine scope and call `session.cancel()` from a
`DisposableEffect`.

## Things the placeholder does NOT do (open for you)

- Tap-to-focus / exposure compensation.
- Real-time marker detection.
- Distance / orientation hints to the operator.
- Depth or ToF data capture (would be additional artefacts inside `workingDir`
  — coordinate with the iOS / shared sides if you want to add new fields to
  `CaptureResult` and `SdkCaptureManifest`).
- Photo / video quality tuning beyond CameraX `Quality.HD`.
