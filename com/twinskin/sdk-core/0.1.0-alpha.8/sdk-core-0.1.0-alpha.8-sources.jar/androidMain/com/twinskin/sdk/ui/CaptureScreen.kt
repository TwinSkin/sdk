@file:OptIn(ExperimentalMaterial3Api::class, com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui

import android.app.Activity
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.util.Log
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.twinskin.photosphere.PhotosphereState
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.DemoCaptureSummary
import com.twinskin.sdk.capture.PhotosphereCaptureDriver
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.ui.capture.CameraSessionController
import com.twinskin.sdk.ui.capture.CameraSessionState
import com.twinskin.sdk.ui.capture.RimbaudReplayFrameSource
import com.twinskin.sdk.ui.capture.rememberCapturePermissionsState
import com.twinskin.sdk.ui.post_submit.PostSubmitFlow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Native Android capture screen, backed by CameraX + XFeat
 *
 * STABLE:
 *   - The seam to the SDK upstream — `startSession`, `session.workingDir`,
 *     `session.submit(CaptureResult(...))`, `session.cancel()`, `session.fail(reason)`.
 *   - The public `(metadata, onDone, onCancel, startSession)` parameter shape
 *     is a hard gate — do not change.
 *
 * `CaptureProgressOverlay` (Round X / 4 + linear progress bar) with the
 * XFeat DemoApp's full per-arm capture UX:
 *   - 4-arm cross overlay (R1-R4 × 4 arms = 16 primary slots) anchored
 *     to screen centre; current-round arms highlighted; ghost-dashed
 *     prior rounds; green when committed, amber for the active target;
 *     orange live-cursor dot at `currentAzEstimate` whose radial offset
 *     scales with `currentTiltMagDeg / 20°`.
 *   - Progress legend below: R1 cardinals / R2 22.5° / R3 45° / R4 67.5°
 *     each with `●●○○ 2 / 4`-style bullets. Coverage `+N` chip surfaces
 *     when any bonus arm (idx ≥ 16) is committed.
 *   - Banner copy adapts to `PhotosphereState.Stage`.
 * Driven by [PhotosphereCaptureDriver.state]
 *     as a passthrough of the upstream session's StateFlow. Coarse
 *     `RoundEvent` subscription is retained for AllRoundsDone /
 *     Aborted side-effects (focus unlock, finalize, marker reset).
 *
 * The screen exposes an explicit "Capture
 * reference" button with first-tap gating. The earlier auto-fire-on-first-frame
 * path (driver grabs R0 the moment the LiveFrameTap delivers a frame) is replaced
 * with an operator-gated invocation: the button's `onClick` flips a
 * boolean that opens the gate the next live frame can pass through.
 */
@Composable
public fun CaptureScreen(
    metadata: SdkCaptureMetadata? = null,
    onDone: (CaptureSession) -> Unit = {},
    onCancel: () -> Unit = {},
    startSession: (SdkCaptureMetadata) -> CaptureSession = { TwinSkinSdk.startCapture(it) },
    // the screen skips CameraX bind + camera-permission gating and
    // feeds the capture pipeline from a bundled MP4 trajectory (decoded
    // via [com.twinskin.sdk.ui.capture.RimbaudReplayFrameSource]).
    // Lets integrators exercise the full capture → finalize → upload
    // pipeline without a camera (CI, smoke tests, mocked QA). Spec:
    // `docs/tracking/cl103-rimbaud-synthetic-replay-spec-2026-05-08.md`.
    replaySource: CaptureReplaySource? = null,
) {
    if (metadata == null) {
        NotWiredPlaceholder()
        return
    }

    val orientationContext = LocalContext.current
    DisposableEffect(Unit) {
        val activity = orientationContext.findActivity()
        val previous = activity?.requestedOrientation
        if (activity != null) {
            activity.requestedOrientation =
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            Log.w(
                "CaptureScreen",
                "host context is not an Activity; skipping portrait lock",
            )
        }
        onDispose {
            if (activity != null && previous != null) {
                activity.requestedOrientation = previous
            }
        }
    }

    // Operator request 2026-05-08: keep the screen on at full brightness
    // for the entire duration of the capture screen. Without this, an
    // inactive-screen timeout mid-sweep pauses the camera analyser and
    // aborts the dwell counter; full brightness ensures the operator
    // can see the cross-bar and arm-progress chrome under indoor
    // lighting. Both knobs revert on dispose so the rest of the host
    // app keeps the system default.
    val keepScreenOnView = LocalView.current
    val brightnessActivity = LocalContext.current.findActivity()
    DisposableEffect(keepScreenOnView, brightnessActivity) {
        val window = brightnessActivity?.window
        val previousKeepOn = keepScreenOnView.keepScreenOn
        val previousBrightness = window?.attributes?.screenBrightness
        keepScreenOnView.keepScreenOn = true
        window?.let {
            val params = it.attributes
            params.screenBrightness = 1f
            it.attributes = params
        }
        onDispose {
            keepScreenOnView.keepScreenOn = previousKeepOn
            window?.let {
                val params = it.attributes
                params.screenBrightness = previousBrightness
                    ?: android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                it.attributes = params
            }
        }
    }

    val permissions = rememberCapturePermissionsState()
    // MP4; no camera permission is needed. Skip the request entirely
    // so the operator does not hit a permission prompt for a feature
    // that does not touch the camera.
    LaunchedEffect(Unit) {
        if (replaySource == null && !permissions.granted) permissions.request()
    }

    val scope = rememberCoroutineScope()
    val session = remember(metadata) { startSession(metadata) }

    val cancelSession: () -> Unit = {
        scope.launch {
            try { session.cancel() } finally { onCancel() }
        }
    }

    when {
        replaySource != null -> CaptureFlow(
            session = session,
            onDone = onDone,
            onCancel = cancelSession,
            replaySource = replaySource,
        )
        permissions.denied -> Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            PermissionDeniedView(onRetry = permissions.request, onCancel = cancelSession)
        }
        !permissions.granted -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        else -> CaptureFlow(session, onDone, onCancel = cancelSession)
    }
}

@Composable
private fun NotWiredPlaceholder() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            "CaptureScreen needs SdkCaptureMetadata — host app has not wired one up yet.",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(24.dp),
        )
    }
}

@Composable
private fun PermissionDeniedView(onRetry: () -> Unit, onCancel: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            "Camera access is required to capture.",
            style = MaterialTheme.typography.bodyLarge,
        )
        Spacer(Modifier.height(16.dp))
        Row {
            OutlinedButton(onClick = onCancel) { Text("Cancel") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = onRetry) { Text("Grant access") }
        }
    }
}

/**
 * Demo-only `useDemoCapture` overlay state. The XFeat overlay reads
 * everything else off [PhotosphereCaptureDriver.state]; this enum is
 * only required for the developer "Use demo capture" button which
 * downloads a server-side bundle and so doesn't pass through the live
 * driver state machine.
 */
private sealed class DemoStep {
    data class Downloading(val downloaded: Int, val total: Int) : DemoStep()
    data object Submitting : DemoStep()
}

@Composable
private fun CaptureFlow(
    session: CaptureSession,
    onDone: (CaptureSession) -> Unit,
    onCancel: () -> Unit,
    // when non-null, [CaptureFlow] runs in synthetic-replay
    // mode: skip CameraX bind, pre-open `refGateOpen`, instantiate a
    // [RimbaudReplayFrameSource] tied to the integrator-supplied scene
    // directory, and feed its uint8 + float32 outputs to the existing
    // [CameraSessionController.attachMarkerFocusController] +
    // [PhotosphereCaptureDriver.LiveFrameTap] seams.
    replaySource: CaptureReplaySource? = null,
) {
    val scope = rememberCoroutineScope()
    var submitted by remember { mutableStateOf(false) }

    if (submitted) {
        PostSubmitFlow(
            session = session,
            onDone = { onDone(session) },
            onCancel = onCancel,
        )
        return
    }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val controller = remember(context, lifecycleOwner, session.workingDir) {
        CameraSessionController(context, lifecycleOwner, session.workingDir)
    }
    // focus controller. The controller drives the AF/AE POI override:
    // when its state is `Locked`, the first RoundWaiting branch reads
    // `lastObservedMarker` and hands the centroid to
    // `controller.lockFocusAndExposure(...)`. When unlocked /
    // searching / reacquiring, the lock falls back to analyser-centre.
    val markerFocus = remember(controller) {
        com.twinskin.sdk.ui.capture.MarkerFocusController()
    }
    LaunchedEffect(controller) {
        controller.attachMarkerFocusController(markerFocus)
        // permission, no preview). Driver bootstrap below is gated on
        // [replaySource] non-null instead of the controller's Ready
        // state, so skipping the camera bind keeps the screen clean
        // (no AndroidView preview surface, no CameraX lifecycle).
        if (replaySource == null) {
            controller.bindToLifecycle()
        }
    }
    DisposableEffect(controller) {
        onDispose {
            controller.unlockLensAndExposureForPhotosphere()
            controller.dispose()
        }
    }

    val controllerState by controller.state.collectAsState()

    val devMode = TwinSkinSdk.devMode

    // camera controller is `Ready`. The driver loads the ORT backbone
    // twice (ref + live ctx) and binds the dwell tracker; failures
    // surface as a banner and the operator can cancel.
    var driver by remember { mutableStateOf<PhotosphereCaptureDriver?>(null) }
    var bootstrapError by remember { mutableStateOf<String?>(null) }
    var liveFrameTap by remember {
        mutableStateOf<PhotosphereCaptureDriver.LiveFrameTap?>(null)
    }
    // Operator-gated reference
    // capture. An earlier path auto-fired `captureReference`
    // on the first live frame (driver-built `LiveFrameTap`'s
    // refBeginIfNeeded race); this flag flips the gate from CLOSED
    // to OPEN when the operator taps "Capture reference". Until
    // OPEN, every live frame is dropped at the camera-side wrapper
    // tap below. Once OPEN, the underlying driver-built tap takes
    // over and the first arriving frame fires
    // `driver.captureReference(...)` as designed
    // (single-shot guarded by the actor-isolated refBeginIfNeeded).
    // AtomicBoolean rather than mutableStateOf so the camera
    // analyser thread (which is *not* the Compose recomposition
    // thread) reads the latest value without a snapshot read.
    val refGateOpen = remember { AtomicBoolean(false) }
    // so the DisposableEffect tear-down can stop it. Distinct from the
    // outer [replaySource] composable param (which is the integrator-
    // supplied scene metadata).
    var replayFrameSource by remember { mutableStateOf<RimbaudReplayFrameSource?>(null) }
    // Defect-2 fix (operator brief 2026-05-08) — separate
    // Dispatchers.Default scope for the replay path's
    // [PhotosphereCaptureDriver.buildLiveFrameTap] tapHostScope. See
    // the "Default dispatcher" comment in the replay LaunchedEffect
    // below for the starvation-avoidance rationale. Cancelled in the
    // DisposableEffect alongside the replay engine.
    val replayDriverScope = remember {
        kotlinx.coroutines.CoroutineScope(
            kotlinx.coroutines.SupervisorJob() + Dispatchers.Default,
        )
    }
    // [replayDriverScope] for the LIVE camera path. The earlier port
    // passed `tapHostScope = this` (the LaunchedEffect coroutine
    // scope) which inherits AndroidUiDispatcher.Main, so every
    // analyser tick re-dispatched the LiveFrameTap body — including
    // the ~1.2 MB synchronized memcpy in
    // PhotosphereSession.enqueueLiveFrame and the per-frame
    // refCaptureMutex acquire — onto Main. On Pixel 6 the X1 cores
    // make the analyser thread fast enough that Main is constantly
    // queue-stuffed with these jobs while it's also painting the
    // photosphere overlay (cross / legend / banner) at 60 fps, which
    // hitches both UI and pose updates. The XFeat DemoApp's
    // CameraFrameSource.attachAnalyser calls
    // `session.enqueueLiveFrame(...)` synchronously from the
    // analyser thread (off-Main); mirror that posture here by
    // dispatching to a Default-pool scope. See
    // docs/tracking/cl103-live-camera-perf-analysis-2026-05-08.md
    // §D1 for the full code-trace and rationale.
    val liveDriverScope = remember {
        kotlinx.coroutines.CoroutineScope(
            kotlinx.coroutines.SupervisorJob() + Dispatchers.Default,
        )
    }
    LaunchedEffect(controller, session.workingDir, replaySource) {
        if (driver != null) return@LaunchedEffect
        // Replay path: bypass the camera-Ready wait entirely. The
        // driver is heavy to instantiate (ORT load); we want it up
        // ASAP so the replay engine can begin feeding frames as soon
        // as the operator picked a scene.
        if (replaySource != null) {
            try {
                // Stage + construct the replay engine first so its
                // `latestRefJpeg()` accessor is reachable from the
                // driver's `refJpegProvider` closure below. The engine
                // does not start decoding until `source.start(...)` is
                // called further down.
                val sceneDir = replaySource.sceneDir
                if (!sceneDir.isDirectory) {
                    Log.w(
                        "CaptureScreen",
                        "synthetic replay scene dir is not a directory: ${sceneDir.absolutePath}",
                    )
                }
                val source = RimbaudReplayFrameSource(
                    sceneDir = sceneDir,
                    workingDir = File(session.workingDir),
                )
                replayFrameSource = source

                val drv = PhotosphereCaptureDriver.create(
                    context = context,
                    workingDir = File(session.workingDir),
                    // an 8° on-target threshold to match the working
                    // XFeat DemoApp at
                    // `evaluate-xfeat-lighterglue/.../MainActivity.kt:1082-1104`
                    // (`REPLAY_ON_TARGET_DEG = 8f`). Placeholder-K
                    // scenes ship with recovered tilt magnitudes that
                    // drift 4-6° vs. the 20° target ring, so the 3°
                    // production threshold never fires on these
                    // replay frames and the per-arm dwell window
                    // never closes. Live-camera path keeps the 3°
                    // production default (no `onTargetDistanceDeg`
                    // arg there).
                    onTargetDistanceDeg = REPLAY_ON_TARGET_DEG,
                )
                // Step 2.5 (2026-05-08) — return latest decoded MP4
                // frame's JPEG bytes (was null, which the C ABI treats
                // as a failed arm, breaking per-view bundles).
                drv.setShutterCallback { _ -> source.latestFrameJpeg() }
                val driverTap = drv.buildLiveFrameTap(
                    tapHostScope = replayDriverScope,
                    refJpegProvider = {
                        // Spin-wait for the replay engine's first
                        // decoded JPEG. Pre-opened gate + bounded poll.
                        var bytes = source.latestRefJpeg()
                        var attempts = 0
                        while (bytes == null && attempts < REF_JPEG_POLL_MAX) {
                            kotlinx.coroutines.delay(REF_JPEG_POLL_DELAY_MS)
                            bytes = source.latestRefJpeg()
                            attempts += 1
                        }
                        if (bytes == null) {
                            Log.w(
                                "CaptureScreen",
                                "replay refJpegProvider gave up after " +
                                    "${REF_JPEG_POLL_MAX * REF_JPEG_POLL_DELAY_MS} ms",
                            )
                        }
                        bytes
                    },
                )
                refGateOpen.set(true)
                val gatedTap = PhotosphereCaptureDriver.LiveFrameTap {
                    grayBuffer, intrinsics, timestampNs ->
                    if (!refGateOpen.get()) return@LiveFrameTap
                    driverTap.onFrame(grayBuffer, intrinsics, timestampNs)
                }
                liveFrameTap = gatedTap
                controller.attachLiveFrameTap(gatedTap)
                driver = drv

                source.start(
                    markerSink = { gray, w, h, rowStride ->
                        markerFocus.ingestFrame(
                            gray = gray,
                            width = w,
                            height = h,
                            rowStride = rowStride,
                        )
                    },
                    liveTap = gatedTap,
                    logSink = { },
                    // the session reaches terminal stage.
                    isSessionTerminal = {
                        val stage = drv.state.value.stage
                        stage is PhotosphereState.Stage.Done ||
                            stage is PhotosphereState.Stage.Aborted
                    },
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                bootstrapError = "XFeat init failed: ${e.message ?: e::class.simpleName ?: "unknown"}"
            }
            return@LaunchedEffect
        }
        // Live path: wait for the camera to be ready before
        // instantiating the driver.
        controller.state.collect { st ->
            if (st is CameraSessionState.Ready && driver == null) {
                try {
                    val drv = PhotosphereCaptureDriver.create(
                        context = context,
                        workingDir = File(session.workingDir),
                        phiOffsetDeg = LIVE_CAMERA_PHI_OFFSET_DEG,
                    )

                    // CameraSessionController.captureJpegBytes (off-Main
                    // OnImageCapturedCallback) instead of takePhoto +
                    // readBytes; saves 50-120 ms/arm × 16 arms/sweep.
                    drv.setShutterCallback { viewIndex ->
                        try {
                            controller.captureJpegBytes(label = "view_$viewIndex")
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            Log.w(
                                "CaptureScreen",
                                "shutter callback failed: ${e.message}",
                                e,
                            )
                            null
                        }
                    }

                    val driverTap = drv.buildLiveFrameTap(
                        // [liveDriverScope] declaration above for
                        // rationale. The prior `tapHostScope = this`
                        // (Main-immediate via LaunchedEffect) put the
                        // 1.2 MB synchronized memcpy in
                        // PhotosphereSession.enqueueLiveFrame and the
                        // refCaptureMutex acquire on Main; this scope
                        // is Default-pool so the analyser-side work
                        // stays off Main. Cancelled in the same
                        // DisposableEffect that owns `replayDriverScope`.
                        tapHostScope = liveDriverScope,
                        refJpegProvider = {
                            try {
                                val bytes = File(controller.takePhoto()).readBytes()
                                // Camera2 AF_MODE_OFF + AE_LOCK + AWB_LOCK
                                // override SYNCHRONOUSLY here, before the
                                // ref bytes are returned to the driver
                                // (and therefore before any live frame is
                                // enqueued). Mirrors XFeat DemoApp
                                // MainActivity.kt onCaptureReference,
                                // which calls source.lockFocusAndExposure
                                // immediately after captureReference
                                // resumes.
                                //
                                // Previous posture (lockLens fired from
                                // RoundEvent.RoundWaiting, ~10–25 frames
                                // / ~330–830 ms after the shutter on
                                // Pixel 6) left a window in which
                                // takePicture had already cancelled the
                                // pre-ref ArUco FocusMeteringAction and
                                // CONTINUOUS_PICTURE AF was free to
                                // hunt; AF_MODE_OFF then pinned the lens
                                // at whatever drifted position it had
                                // wandered to. See
                                // docs/tracking/cl103-focus-lock-timing-diff-2026-05-10.md.
                                val obs = markerFocus.lastObservedMarker
                                if (obs != null) {
                                    controller.lockLensAndExposureForPhotosphere(
                                        poiX = obs.centroidX,
                                        poiY = obs.centroidY,
                                    )
                                } else {
                                    controller.lockLensAndExposureForPhotosphere()
                                }
                                bytes
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                Log.w(
                                    "CaptureScreen",
                                    "captureReference fullres failed: ${e.message}",
                                    e,
                                )
                                null
                            }
                        },
                    )
                    // driver-built tap with an operator gate. While
                    // `refGateOpen` is false (pre-button-tap) every
                    // analyser frame is silently dropped — neither
                    // `captureReference` nor `enqueueLiveFrame` are
                    // invoked, so the dwell tracker stays asleep and
                    // the session sits in `RefCapture`. Once the
                    // operator taps "Capture reference" the gate
                    // flips OPEN; from that moment forward frames
                    // pass straight through to the driver-built tap,
                    // which runs its own `refBeginIfNeeded` guard
                    // for the single-shot ref capture path. Mirrors
                    // iOS `CaptureView.swift` post-port: same
                    // semantics, AtomicBoolean for thread-safety
                    // since the analyser callback fires off a
                    // dedicated CameraX executor.
                    val gatedTap = PhotosphereCaptureDriver.LiveFrameTap {
                        grayBuffer, intrinsics, timestampNs ->
                        if (!refGateOpen.get()) return@LiveFrameTap
                        driverTap.onFrame(grayBuffer, intrinsics, timestampNs)
                    }
                    liveFrameTap = gatedTap
                    controller.attachLiveFrameTap(gatedTap)
                    driver = drv
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    bootstrapError = "XFeat init failed: ${e.message ?: e::class.simpleName ?: "unknown"}"
                }
            }
        }
    }
    DisposableEffect(driver) {
        // entry. The delegated `var driver` would otherwise be captured by
        // REFERENCE in `onDispose`, so the first null→drv transition (which
        // disposes the previous null-keyed effect) would read the NEW value
        // and call `cancel()` on the freshly-built driver, immediately
        // aborting the session. Snapshotting captures the PRIOR key value,
        // mirroring iOS `deinit` semantics: first dispose is a no-op; only
        // screen-exit with `current = drv` triggers `drv.cancel()`.
        //
        // tap-detach (`controller.attachLiveFrameTap(null)` +
        // first null→drv transition disposed the null-keyed effect and
        // cleared the tap that the LaunchedEffect had JUST installed
        // (~28 ms earlier). Symptom on Pixel 6: every analyser frame
        // observes `liveFrameTap == null`, so `gatedTap.onFrame` never
        // fires, `captureReference` is never invoked, and the operator's
        // "Capture reference" tap silently drops on the floor with no
        // visible feedback. Gate the tap-detach on `current != null`
        // (same posture as `current?.cancel()` above): only the real
        // screen-exit dispose (where the snapshot captured `drv`) tears
        // down the tap.
        val current = driver
        onDispose {
            if (current != null) {
                current.cancel()
                // Detach the tap from the controller so any in-flight
                // analyser callback drops the frame instead of forwarding
                // it to the cancelled driver. Belt-and-suspenders with
                // CameraSessionController.dispose's own tap clear.
                controller.attachLiveFrameTap(null)
                liveFrameTap = null
                replayFrameSource?.stop()
                replayFrameSource = null
                // Defect-2 fix — cancel the replay tap-host scope so
                // any in-flight ref-capture / enqueue coroutines
                // unwind cleanly with the driver.
                replayDriverScope.cancel()
                // the live-camera tap-host scope.
                liveDriverScope.cancel()
            }
        }
    }

    var demoStep by remember { mutableStateOf<DemoStep?>(null) }
    var submitting by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var demoPickerOptions by remember { mutableStateOf<List<DemoCaptureSummary>?>(null) }
    // `refGateOpen`. Set true on the "Capture reference" button tap;
    // hides the button on the next recomposition. The actor-side
    // gate is still the source of truth for the live-frame tap (it
    // runs on the camera analyser thread); this flag is for UI
    // visibility only.
    var refButtonTapped by remember { mutableStateOf(false) }

    // milestone side-effects (focus lock at first RoundWaiting,
    // unlock + finalize at AllRoundsDone, abort handling). The
    // overlay itself reads off `driver.state` for the per-arm tile
    // grid + live cursor — see [XFeatPhotosphereOverlay] below.
    LaunchedEffect(driver) {
        val drv = driver ?: return@LaunchedEffect
        var focusLocked = false
        drv.events.collect { ev ->
            when (ev) {
                is PhotosphereCaptureDriver.RoundEvent.RoundWaiting -> {
                    if (!focusLocked) {
                        // Camera2 hard lens-lock
                        // is now installed inline with ref capture
                        // inside refJpegProvider, BEFORE any live frame
                        // is enqueued. This branch only flips the
                        // focusLocked guard and detaches the marker
                        // focus controller post-lock.
                        focusLocked = true
                        // OI-067 / D2 — detach the marker-focus controller
                        // now that focus is locked. ArUco runs every 5th
                        // analyser frame (~6 Hz, 5-10 ms/call) on the same
                        // single thread that feeds XFeat inference; running
                        // it for all 16 arms burns ~50-60 ms/sec of
                        // analyser-thread budget. We no longer need marker
                        // detection during the sweep — re-attach at
                        // AllRoundsDone / Aborted so the next session finds
                        // the controller live.
                        controller.attachMarkerFocusController(null)
                    }
                }
                is PhotosphereCaptureDriver.RoundEvent.Capturing,
                is PhotosphereCaptureDriver.RoundEvent.RoundComplete,
                -> Unit // Per-arm UI handled by overlay reading state.
                is PhotosphereCaptureDriver.RoundEvent.AllRoundsDone -> {
                    controller.unlockLensAndExposureForPhotosphere()
                    controller.attachMarkerFocusController(markerFocus)
                    markerFocus.reset()
                    focusLocked = false
                    submitting = true
                    try {
                        val result = drv.finalize()
                        session.submit(result)
                        submitted = true
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        errorText = e.message ?: "submit failed"
                        submitting = false
                    }
                }
                is PhotosphereCaptureDriver.RoundEvent.Aborted -> {
                    controller.unlockLensAndExposureForPhotosphere()
                    controller.attachMarkerFocusController(markerFocus)
                    markerFocus.reset()
                    focusLocked = false
                    errorText = "Capture aborted: ${ev.reason}"
                }
            }
        }
    }

    // per-arm overlay. Null until the driver has been instantiated +
    // its first state snapshot has propagated.
    val driverState: PhotosphereState? = driver?.state?.collectAsState()?.value

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (replaySource != null) "Capture (replay)" else "Capture") },
                navigationIcon = {
                    TextButton(onClick = onCancel) { Text("Cancel") }
                },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (replaySource != null) {
                val replayBitmap = replayFrameSource?.replayFrameFlow?.collectAsState()?.value
                Box(
                    modifier = Modifier.fillMaxSize().background(Color.Black),
                    contentAlignment = Alignment.Center,
                ) {
                    if (replayBitmap != null) {
                        Image(
                            bitmap = replayBitmap.asImageBitmap(),
                            contentDescription = "replay frame",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                    } else if (driverState == null) {
                        Text("Loading replay scene…", color = Color.White)
                    }
                }
            } else {
                CameraPreview(controller = controller, modifier = Modifier.fillMaxSize())
            }

            if (driverState != null && demoStep == null && !submitting) {
                XFeatPhotosphereOverlay(state = driverState)
            }

            // + — operator-gated "Capture
            // reference" button. Replay pre-opens refGateOpen so the
            // first decoded frame fires captureReference automatically.
            if (replaySource == null
                && driverState != null
                && driverState.stage is PhotosphereState.Stage.RefCapture
                && demoStep == null
                && !submitting
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(bottom = BOTTOM_CHROME_PADDING_DP.dp + 80.dp)
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Button(onClick = {
                        refButtonTapped = true
                        refGateOpen.set(true)
                    }) {
                        Text(text = "Capture reference")
                    }
                }
            }

            if (devMode && demoStep == null && !submitting && driverState == null) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp),
                    color = Color.Black.copy(alpha = 0.6f),
                    shape = MaterialTheme.shapes.small,
                ) {
                    TextButton(
                        onClick = {
                            scope.launch {
                                val catalog = try {
                                    session.listDemoCaptures()
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    errorText = e.message ?: "Demo capture failed"
                                    return@launch
                                }
                                when {
                                    catalog.isEmpty() -> {
                                        errorText = "No demo captures available on the server"
                                    }
                                    catalog.size == 1 -> {
                                        useDemoCapture(
                                            session = session,
                                            entryId = catalog.single().id,
                                            onStateChange = { demoStep = it },
                                            onSubmitted = { submitted = true },
                                            onError = { errorText = it },
                                        )
                                    }
                                    else -> {
                                        demoPickerOptions = catalog
                                    }
                                }
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    ) {
                        Text("Use demo capture", color = Color.White)
                    }
                }
            }

            when (val ds = demoStep) {
                is DemoStep.Downloading -> DemoDownloadOverlay(downloaded = ds.downloaded, total = ds.total)
                DemoStep.Submitting -> UploadOverlay("Preparing bundle…", null)
                null -> {
                    if (submitting) UploadOverlay("Preparing bundle…", null)
                }
            }

            val ctrlErr = (controllerState as? CameraSessionState.Error)?.message
            val banner = errorText ?: bootstrapError ?: ctrlErr
            if (banner != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.align(Alignment.TopCenter).padding(16.dp),
                ) {
                    Text(
                        banner,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                }
            }
        }

        demoPickerOptions?.let { options ->
            DemoCapturePickerDialog(
                options = options,
                onDismiss = { demoPickerOptions = null },
                onPick = { chosen ->
                    demoPickerOptions = null
                    scope.launch {
                        useDemoCapture(
                            session = session,
                            entryId = chosen.id,
                            onStateChange = { demoStep = it },
                            onSubmitted = { submitted = true },
                            onError = { errorText = it },
                        )
                    }
                },
            )
        }
    }
}

@Composable
private fun DemoCapturePickerDialog(
    options: List<DemoCaptureSummary>,
    onDismiss: () -> Unit,
    onPick: (DemoCaptureSummary) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pick a demo capture") },
        text = {
            Column {
                for (option in options) {
                    TextButton(
                        onClick = { onPick(option) },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            option.name,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

/**
 * XFeat-DemoApp per-arm capture overlay
 *
 * Replaces the v6.1 single-progress-bar `CaptureProgressOverlay`. The
 * overlay reads off the upstream [PhotosphereState] (capturedArms,
 * currentRound, currentAzEstimate, currentTiltMagDeg, stage) and
 * renders the same chrome the XFeat DemoApp ships.
 */
@Composable
private fun XFeatPhotosphereOverlay(state: PhotosphereState) {
    Box(Modifier.fillMaxSize()) {
        PhotosphereCrossOverlay(
            state = state,
            modifier = Modifier.fillMaxSize().align(Alignment.Center),
        )

        PhotosphereBanner(
            state = state,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 16.dp)
                .padding(top = TOP_BAR_HEIGHT_DP.dp + BANNER_TOP_GAP_DP.dp)
                .height(BANNER_HEIGHT_DP.dp),
        )

        ProgressLegend(
            state = state,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(bottom = BOTTOM_CHROME_PADDING_DP.dp)
                .padding(horizontal = 16.dp),
        )
    }
}

@Composable
private fun PhotosphereBanner(
    state: PhotosphereState,
    modifier: Modifier = Modifier,
) {
    val stage = state.stage
    val (title, subtitle) = when (stage) {
        is PhotosphereState.Stage.RefCapture ->
            "Initialising reference…" to
                "The reference frame anchors all 16 orbit views."
        is PhotosphereState.Stage.RoundWaiting -> {
            val done = state.capturedArms.count { (it / 4) + 1 == stage.round }
            "Round ${stage.round} of 4" to
                "$done / 4 captured. Hold the phone toward the next arm."
        }
        is PhotosphereState.Stage.Aiming ->
            "Round ${stage.round} of 4" to "Aim toward the highlighted arm."
        is PhotosphereState.Stage.OnTarget ->
            "Round ${stage.round} of 4" to "On target — hold steady."
        is PhotosphereState.Stage.Capturing ->
            "Capturing arm ${stage.targetArm}…" to "Hold steady — XFeat is firing."
        is PhotosphereState.Stage.RoundComplete ->
            "Round ${stage.round} complete" to "Next round…"
        is PhotosphereState.Stage.Done ->
            "All 16 angles captured." to "Finalising bundle…"
        is PhotosphereState.Stage.Aborted ->
            "Session aborted." to (stage.reason.message ?: "")
    }
    val errText = state.currentError?.message
    Column(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = subtitle,
            color = Color.White.copy(alpha = 0.75f),
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (errText != null) {
            Text(
                text = errText,
                color = AMBER,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun PhotosphereCrossOverlay(
    state: PhotosphereState,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = min(size.width, size.height) * CROSS_RADIUS_FRAC

        for (globalIdx in state.capturedArms) {
            if (globalIdx >= PRIMARY_ARM_COUNT) continue
            val round = (globalIdx / ARMS_PER_ROUND) + 1
            val az = ARM_AZIMUTHS[globalIdx]
            val (x, y) = armEndpoint(cx, cy, radius, az)
            drawLine(
                color = if (round == state.currentRound) GREEN else GREEN.copy(alpha = GHOST_ALPHA),
                start = Offset(cx, cy),
                end = Offset(x, y),
                strokeWidth = ARM_STROKE_PX,
                cap = StrokeCap.Round,
            )
        }

        val currentRound = state.currentRound
        val activeArmIdx = activeArmIndex(state)
        for (arm in 0 until ARMS_PER_ROUND) {
            val globalIdx = (currentRound - 1) * ARMS_PER_ROUND + arm
            if (state.capturedArms.contains(globalIdx)) continue
            if (globalIdx >= PRIMARY_ARM_COUNT) continue
            val az = ARM_AZIMUTHS[globalIdx]
            val (x, y) = armEndpoint(cx, cy, radius, az)
            val color = if (arm == activeArmIdx) AMBER else GRAY_ARM
            drawLine(
                color = color,
                start = Offset(cx, cy),
                end = Offset(x, y),
                strokeWidth = ARM_STROKE_PX,
                cap = StrokeCap.Round,
            )
        }

        drawCircle(
            color = Color(COLOR_REF_FILL),
            radius = radius * REF_DISC_RADIUS_FRAC,
            center = Offset(cx, cy),
            style = Stroke(width = ARM_STROKE_PX),
        )

        val az = state.currentAzEstimate
        val mag = state.currentTiltMagDeg
        if (az != null && mag != null) {
            val dotRadius = (mag / TILT_MAG_REF_DEG * radius).coerceAtMost(radius * LIVE_DOT_MAX_RADIUS_FRAC)
            val (lx, ly) = armEndpoint(cx, cy, dotRadius, az)
            drawCircle(
                color = AMBER,
                radius = LIVE_DOT_SIZE_PX,
                center = Offset(lx, ly),
            )
        }
    }
}

private fun activeArmIndex(state: PhotosphereState): Int? =
    when (val stage = state.stage) {
        is PhotosphereState.Stage.Aiming -> stage.targetArm
        is PhotosphereState.Stage.OnTarget -> stage.targetArm
        is PhotosphereState.Stage.Capturing -> stage.targetArm
        else -> null
    }

private fun armEndpoint(
    cx: Float,
    cy: Float,
    radius: Float,
    azDeg: Float,
): Pair<Float, Float> {
    val rad = Math.toRadians(azDeg.toDouble())
    val x = cx + radius * sin(rad).toFloat()
    val y = cy + radius * cos(rad).toFloat()
    return x to y
}

@Composable
private fun ProgressLegend(
    state: PhotosphereState,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .padding(8.dp),
    ) {
        for (round in 1..4) {
            val armStates = (0 until ARMS_PER_ROUND).map { arm ->
                val globalIdx = (round - 1) * ARMS_PER_ROUND + arm
                state.capturedArms.contains(globalIdx)
            }
            val done = armStates.count { it }
            val bullets = armStates.joinToString(separator = "") { if (it) "●" else "○" }
            val roundLabel = when (round) {
                1 -> "R1 cardinals"
                2 -> "R2 22.5°    "
                3 -> "R3 45°      "
                else -> "R4 67.5°    "
            }
            val color = if (round == state.currentRound) Color.White else Color.White.copy(alpha = 0.55f)
            Text(
                text = "$roundLabel  $bullets  $done / 4",
                color = color,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
            )
        }
        val coverageCount = state.capturedArms.count { it >= PRIMARY_ARM_COUNT }
        if (coverageCount > 0) {
            Text(
                text = "Coverage    +$coverageCount",
                color = COVERAGE_CYAN,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
            )
        }
    }
}

@Composable
private fun DemoDownloadOverlay(downloaded: Int, total: Int) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "Downloading demo capture…",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { (downloaded.toFloat() / total.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.width(240.dp),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "$downloaded / $total",
                color = Color.White,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

private suspend fun useDemoCapture(
    session: CaptureSession,
    entryId: String,
    onStateChange: (DemoStep?) -> Unit,
    onSubmitted: () -> Unit,
    onError: (String) -> Unit,
) {
    try {
        onStateChange(DemoStep.Downloading(downloaded = 0, total = 1))
        session.submitDemoCapture(entryId = entryId) { d, t ->
            onStateChange(DemoStep.Downloading(downloaded = d, total = t))
        }
        onStateChange(DemoStep.Submitting)
        onSubmitted()
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        onError(e.message ?: "Demo capture failed")
        onStateChange(null)
    }
}

@Composable
private fun CameraPreview(controller: CameraSessionController, modifier: Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PreviewView(ctx).also { view ->
                // PERFORMANCE (SurfaceView) explicitly. CameraX 1.4+
                // defaults to PERFORMANCE, but a future version
                // flipping the default would silently regress to
                // COMPATIBLE (TextureView), which on Camera2-LIMITED
                // HALs (XCover5, A21s) routes ImageCapture through
                // CameraX's GL surface processor and adds 1-3× per-arm
                // wall-clock. The XFeat DemoApp pins this explicitly
                // (`PhotosphereCaptureScreen.kt:170`) for the same
                // reason — match that posture.
                view.implementationMode = PreviewView.ImplementationMode.PERFORMANCE
                view.scaleType = PreviewView.ScaleType.FILL_CENTER
                controller.preview.setSurfaceProvider(view.surfaceProvider)
            }
        },
    )
}

@Composable
private fun UploadOverlay(label: String, progress: Float?) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (progress != null) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.width(240.dp))
            } else {
                CircularProgressIndicator()
            }
            Spacer(Modifier.height(12.dp))
            Text(label, color = Color.White)
        }
    }
}

private tailrec fun android.content.Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

// --- XFeat overlay constants (mirrors XFeat DemoApp) ------------------

private val ARM_AZIMUTHS: FloatArray = floatArrayOf(
    0f, 90f, 180f, 270f,
    22.5f, 112.5f, 202.5f, 292.5f,
    45f, 135f, 225f, 315f,
    67.5f, 157.5f, 247.5f, 337.5f,
    11.25f, 101.25f, 191.25f, 281.25f,
    33.75f, 123.75f, 213.75f, 303.75f,
    56.25f, 146.25f, 236.25f, 326.25f,
    78.75f, 168.75f, 258.75f, 348.75f,
)

private const val ARMS_PER_ROUND: Int = 4
private const val PRIMARY_ARM_COUNT: Int = 16

/** Defect-2 / replay refJpegProvider — bounded poll for the replay
 *  engine's first decoded frame. ~2 s upper bound (40 × 50 ms) —
 *  generous enough to absorb codec startup on slower devices, short
 *  enough to surface a missing-scene error before the operator gives
 *  up. */
private const val REF_JPEG_POLL_DELAY_MS: Long = 50L
private const val REF_JPEG_POLL_MAX: Int = 40

/**
 * synthetic-replay path. Mirrors the working XFeat DemoApp at
 * `evaluate-xfeat-lighterglue/.../MainActivity.kt:1784`
 * (`REPLAY_ON_TARGET_DEG = 8f`). Placeholder-K scenes ship with
 * recovered tilt magnitudes that drift 4-6° vs. the 20° target ring,
 * so the 3° production threshold (`PhotosphereMath
 * .ON_TARGET_DISTANCE_DEG`) never fires on replay and the per-arm
 * dwell window never closes. Live-camera path keeps the production
 * default — only the replay branch passes this through to
 * [PhotosphereCaptureDriver.create].
 */
private const val REPLAY_ON_TARGET_DEG: Float = 8f

/**
 * OI-066 fix (2026-05-08) — sensor→display phi rotation applied on the
 * live-camera path. CameraX's `ImageAnalysis` ships 640×480 landscape
 * YUV regardless of display orientation while the capture UI is
 * portrait-locked, so the recovered `tilt_phi` is 90° offset from the
 * on-screen cross frame. Without this offset, the bar cursor drifts
 * 90° from the operator's actual orientation (tilting "up" lights the
 * "left" bar, etc). Mirrors XFeat DemoApp
 * `LIVE_CAMERA_PHI_OFFSET_DEG` at
 * `evaluate-xfeat-lighterglue/.../MainActivity.kt:1796` and iOS
 * `phiOffsetDeg = 90` at `PhotosphereCaptureView.swift:838-845`.
 * Replay path uses `0f` (frames already in display frame).
 */
private const val LIVE_CAMERA_PHI_OFFSET_DEG: Float = 90f

private const val TOP_BAR_HEIGHT_DP: Int = 56
private const val BANNER_TOP_GAP_DP: Int = 4
private const val BANNER_HEIGHT_DP: Int = 56
private const val BOTTOM_CHROME_PADDING_DP: Int = 12

private const val CROSS_RADIUS_FRAC: Float = 0.38f
private const val REF_DISC_RADIUS_FRAC: Float = 0.2f
private const val TILT_MAG_REF_DEG: Float = 20f
private const val LIVE_DOT_MAX_RADIUS_FRAC: Float = 1.2f
private const val LIVE_DOT_SIZE_PX: Float = 11f
private const val ARM_STROKE_PX: Float = 5f
private const val GHOST_ALPHA: Float = 0.4f

private const val COLOR_REF_FILL: Long = 0xFF222222
private val GRAY_ARM: Color = Color(0xFF4A4A4A)
private val GREEN: Color = Color(0xFF2EB872)
private val AMBER: Color = Color(0xFFFF9F1C)
private val COVERAGE_CYAN: Color = Color(red = 0.28f, green = 0.79f, blue = 0.89f)
