package com.twinskin.sdk.capture

import java.io.File

/**
 * Bridges the on-disk photosphere bundle layout to the SDK's
 * [CaptureResult] / [CaptureSession.submit] contract. Renames
 * `ref.jpg → photo.jpg` post-finalize on Android (the Kotlin
 * `PhotosphereSession` has no storage-adapter extension point, so
 * the rename runs after the session writes rather than at write
 * time as iOS does); the rename is idempotent so a process kill
 * between finalize and bridge run is recoverable.
 */

/**
 * Maps the bundle in [sessionDir] to a [CaptureResult] for
 * [CaptureSession.submit]. Renames `ref.jpg → photo.jpg`
 * idempotently, enumerates `view_NN_rXaY.jpg` in lexicographic
 * (= capture-slot) order, and returns `markerVersion = null`
 * because the native marker auto-detect is stubbed on Android.
 *
 * Peer files (`index.json`, `frame_log.jsonl`, `pose_log.json`)
 * are not surfaced through [CaptureResult]; the submit packing
 * pass discovers them by enumerating the bundle directory.
 *
 * @throws IllegalStateException if the rename fails or `photo.jpg`
 *     is missing afterwards.
 */
internal fun bundleDirToCaptureResult(sessionDir: File): CaptureResult {
    val refOnDisk = File(sessionDir, "ref.jpg")
    val canonicalRef = File(sessionDir, "photo.jpg")
    // CameraSessionController.takePhoto wrote a full-resolution
    // photo.jpg during ref capture (~3 MB on Pixel 6). The
    // photosphere session subsequently wrote the downsampled
    // `ref.jpg` via compressJpegIfNeeded. We always want the
    // downsampled ref to be the canonical bundle photo so it matches
    // the view-file resolution and tracks the integrator's
    // `maxLongEdgePx` budget — delete the stale full-res blob if
    // present, then rename. Without the delete, the
    // `renameTo`-only-if-target-absent guard left a 4× resolution
    // mismatch between ref and views in the uploaded bundle.
    if (refOnDisk.exists()) {
        if (canonicalRef.exists()) canonicalRef.delete()
        check(refOnDisk.renameTo(canonicalRef)) {
            "rename ${refOnDisk.absolutePath} → ${canonicalRef.absolutePath} failed"
        }
    }
    check(canonicalRef.exists()) {
        "expected photo.jpg in ${sessionDir.absolutePath} after finalize"
    }

    // Whitelist the canonical photosphere bundle naming so non-bundle
    // files in the same directory (e.g. `CameraSessionController`'s
    // `diskWriteFanout` debug snapshots written as
    // `view_<idx>_<timestampMs>.jpg`) don't get scooped into the
    // encrypted upload. The photosphere session emits
    // `view_NN_rXaY.jpg` where NN is two zero-padded digits, X is the
    // round (1..8), and Y is the arm (0..3).
    val viewFilePattern = Regex("""^view_\d{2}_r\d+a\d+\.jpg$""")
    val viewFiles = sessionDir
        .listFiles { f -> viewFilePattern.matches(f.name) }
        ?.sortedBy { it.name }
        .orEmpty()

    return CaptureResult(
        photoPath = canonicalRef.absolutePath,
        framePaths = viewFiles.map { it.absolutePath },
        markerVersion = null,
    )
}
