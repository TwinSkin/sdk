@file:OptIn(ExperimentalMaterial3Api::class, com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui

import android.app.Activity
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.util.Log
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.twinskin.photosphere.PhotosphereMath
import com.twinskin.photosphere.PhotosphereState
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.DemoCaptureSummary
import com.twinskin.sdk.capture.PhotosphereCaptureDriver
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.ui.capture.CameraSessionController
import com.twinskin.sdk.ui.capture.CameraSessionState
import com.twinskin.sdk.ui.capture.PhotosphereExposureMode
import com.twinskin.sdk.ui.capture.PhotosphereFocusMode
import com.twinskin.sdk.ui.capture.PhotosphereFocusPolicy
import com.twinskin.sdk.ui.capture.RimbaudReplayFrameSource
import com.twinskin.sdk.ui.annotation_editor.toImageBitmap
import com.twinskin.sdk.ui.capture.rememberCapturePermissionsState
import com.twinskin.sdk.ui.photosphere_tutorial.PhotosphereTutorialOverlay
import com.twinskin.sdk.ui.photosphere_tutorial.PhotosphereTutorialPrefs
import com.twinskin.sdk.ui.post_submit.PostSubmitFlow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Native Android capture screen, backed by CameraX + XFeat
 *
 * STABLE:
 *   - The seam to the SDK upstream — `startSession`, `session.workingDir`,
 *     `session.submit(CaptureResult(...))`, `session.cancel()`, `session.fail(reason)`.
 *   - The public `(metadata, onDone, onCancel, startSession)` parameter shape
 *     is a hard gate — do not change.
 *
 * `CaptureProgressOverlay` (Round X / 4 + linear progress bar) with the
 * XFeat DemoApp's full per-arm capture UX:
 *   - 4-arm cross overlay (R1-R4 × 4 arms = 16 primary slots) anchored
 *     to screen centre; current-round arms highlighted; ghost-dashed
 *     prior rounds; green when committed, amber for the active target;
 *     orange live-cursor dot at `currentAzEstimate` whose radial offset
 *     scales with `currentTiltMagDeg / 20°`.
 *   - Progress legend below: R1 cardinals / R2 22.5° / R3 45° / R4 67.5°
 *     each with `●●○○ 2 / 4`-style bullets. Coverage `+N` chip surfaces
 *     when any bonus arm (idx ≥ 16) is committed.
 *   - Banner copy adapts to `PhotosphereState.Stage`.
 * Driven by [PhotosphereCaptureDriver.state]
 *     as a passthrough of the upstream session's StateFlow. Coarse
 *     `RoundEvent` subscription is retained for AllRoundsDone /
 *     Aborted side-effects (focus unlock, finalize, marker reset).
 *
 * The screen exposes an explicit "Capture
 * reference" button with first-tap gating. The earlier auto-fire-on-first-frame
 * path (driver grabs R0 the moment the LiveFrameTap delivers a frame) is replaced
 * with an operator-gated invocation: the button's `onClick` flips a
 * boolean that opens the gate the next live frame can pass through.
 */
@Composable
public fun CaptureScreen(
    metadata: SdkCaptureMetadata? = null,
    onDone: (CaptureSession) -> Unit = {},
    onCancel: () -> Unit = {},
    startSession: (SdkCaptureMetadata) -> CaptureSession = { TwinSkinSdk.startCapture(it) },
    // the screen skips CameraX bind + camera-permission gating and
    // feeds the capture pipeline from a bundled MP4 trajectory (decoded
    // via [com.twinskin.sdk.ui.capture.RimbaudReplayFrameSource]).
    // Lets integrators exercise the full capture → finalize → upload
    // pipeline without a camera (CI, smoke tests, mocked QA). Spec:
    // `docs/tracking/cl103-rimbaud-synthetic-replay-spec-2026-05-08.md`.
    replaySource: CaptureReplaySource? = null,
) {
    if (metadata == null) {
        NotWiredPlaceholder()
        return
    }

    val orientationContext = LocalContext.current
    DisposableEffect(Unit) {
        val activity = orientationContext.findActivity()
        val previous = activity?.requestedOrientation
        if (activity != null) {
            activity.requestedOrientation =
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            Log.w(
                "CaptureScreen",
                "host context is not an Activity; skipping portrait lock",
            )
        }
        onDispose {
            if (activity != null && previous != null) {
                activity.requestedOrientation = previous
            }
        }
    }

    // Operator request 2026-05-08: keep the screen on at full brightness
    // for the entire duration of the capture screen. Without this, an
    // inactive-screen timeout mid-sweep pauses the camera analyser and
    // aborts the dwell counter; full brightness ensures the operator
    // can see the cross-bar and arm-progress chrome under indoor
    // lighting. Both knobs revert on dispose so the rest of the host
    // app keeps the system default.
    val keepScreenOnView = LocalView.current
    val brightnessActivity = LocalContext.current.findActivity()
    DisposableEffect(keepScreenOnView, brightnessActivity) {
        val window = brightnessActivity?.window
        val previousKeepOn = keepScreenOnView.keepScreenOn
        val previousBrightness = window?.attributes?.screenBrightness
        keepScreenOnView.keepScreenOn = true
        window?.let {
            val params = it.attributes
            params.screenBrightness = 1f
            it.attributes = params
        }
        onDispose {
            keepScreenOnView.keepScreenOn = previousKeepOn
            window?.let {
                val params = it.attributes
                params.screenBrightness = previousBrightness
                    ?: android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                it.attributes = params
            }
        }
    }

    val permissions = rememberCapturePermissionsState()
    // MP4; no camera permission is needed. Skip the request entirely
    // so the operator does not hit a permission prompt for a feature
    // that does not touch the camera.
    LaunchedEffect(Unit) {
        if (replaySource == null && !permissions.granted) permissions.request()
    }

    val scope = rememberCoroutineScope()
    val session = remember(metadata) { startSession(metadata) }

    val cancelSession: () -> Unit = {
        scope.launch {
            try { session.cancel() } finally { onCancel() }
        }
    }

    when {
        replaySource != null -> CaptureFlow(
            session = session,
            onDone = onDone,
            onCancel = cancelSession,
            replaySource = replaySource,
        )
        permissions.denied -> Box(
            Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            PermissionDeniedView(
                permanentlyDenied = permissions.permanentlyDenied,
                onRetry = permissions.request,
                onOpenSettings = permissions.openAppSettings,
                onCancel = cancelSession,
            )
        }
        !permissions.granted -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        else -> CaptureFlow(session, onDone, onCancel = cancelSession)
    }
}

@Composable
private fun NotWiredPlaceholder() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            "CaptureScreen needs SdkCaptureMetadata — host app has not wired one up yet.",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(24.dp),
        )
    }
}

@Composable
private fun PermissionDeniedView(
    permanentlyDenied: Boolean,
    onRetry: () -> Unit,
    onOpenSettings: () -> Unit,
    onCancel: () -> Unit,
) {
    val message = if (permanentlyDenied) {
        "Camera access is required to capture. Enable it in app settings."
    } else {
        "Camera access is required to capture."
    }
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(message, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(16.dp))
        Row {
            OutlinedButton(onClick = onCancel) { Text("Cancel") }
            Spacer(Modifier.width(8.dp))
            if (permanentlyDenied) {
                Button(onClick = onOpenSettings) { Text("Open settings") }
            } else {
                Button(onClick = onRetry) { Text("Grant access") }
            }
        }
    }
}

/**
 * Demo-only `useDemoCapture` overlay state. The XFeat overlay reads
 * everything else off [PhotosphereCaptureDriver.state]; this enum is
 * only required for the developer "Use demo capture" button which
 * downloads a server-side bundle and so doesn't pass through the live
 * driver state machine.
 */
private sealed class DemoStep {
    data class Downloading(val downloaded: Int, val total: Int) : DemoStep()
    data object Submitting : DemoStep()
}

@Composable
private fun CaptureFlow(
    session: CaptureSession,
    onDone: (CaptureSession) -> Unit,
    onCancel: () -> Unit,
    // when non-null, [CaptureFlow] runs in synthetic-replay
    // mode: skip CameraX bind, pre-open `refGateOpen`, instantiate a
    // [RimbaudReplayFrameSource] tied to the integrator-supplied scene
    // directory, and feed its uint8 + float32 outputs to the existing
    // [CameraSessionController.attachMarkerFocusController] +
    // [PhotosphereCaptureDriver.LiveFrameTap] seams.
    replaySource: CaptureReplaySource? = null,
) {
    val scope = rememberCoroutineScope()
    var submitted by remember { mutableStateOf(false) }

    if (submitted) {
        PostSubmitFlow(
            session = session,
            onDone = { onDone(session) },
            onCancel = onCancel,
        )
        return
    }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val controller = remember(context, lifecycleOwner, session.workingDir) {
        CameraSessionController(context, lifecycleOwner, session.workingDir)
    }
    // focus controller. The controller drives the AF/AE POI override:
    // when its state is `Locked`, the first RoundWaiting branch reads
    // `lastObservedMarker` and hands the centroid to
    // `controller.lockFocusAndExposure(...)`. When unlocked /
    // searching / reacquiring, the lock falls back to analyser-centre.
    val markerFocus = remember(controller) {
        com.twinskin.sdk.ui.capture.MarkerFocusController()
    }
    LaunchedEffect(controller) {
        controller.attachMarkerFocusController(markerFocus)
        // permission, no preview). Driver bootstrap below is gated on
        // [replaySource] non-null instead of the controller's Ready
        // state, so skipping the camera bind keeps the screen clean
        // (no AndroidView preview surface, no CameraX lifecycle).
        if (replaySource == null) {
            controller.bindToLifecycle()
        }
    }
    DisposableEffect(controller) {
        onDispose {
            controller.unlockLensAndExposureForPhotosphere()
            controller.dispose()
        }
    }

    val controllerState by controller.state.collectAsState()

    val devMode = TwinSkinSdk.devMode

    // camera controller is `Ready`. The driver loads the ORT backbone
    // twice (ref + live ctx) and binds the dwell tracker; failures
    // surface as a banner and the operator can cancel.
    var driver by remember { mutableStateOf<PhotosphereCaptureDriver?>(null) }
    var bootstrapError by remember { mutableStateOf<String?>(null) }
    var liveFrameTap by remember {
        mutableStateOf<PhotosphereCaptureDriver.LiveFrameTap?>(null)
    }
    // Operator-gated reference
    // capture. An earlier path auto-fired `captureReference`
    // on the first live frame (driver-built `LiveFrameTap`'s
    // refBeginIfNeeded race); this flag flips the gate from CLOSED
    // to OPEN when the operator taps "Capture reference". Until
    // OPEN, every live frame is dropped at the camera-side wrapper
    // tap below. Once OPEN, the underlying driver-built tap takes
    // over and the first arriving frame fires
    // `driver.captureReference(...)` as designed
    // (single-shot guarded by the actor-isolated refBeginIfNeeded).
    // AtomicBoolean rather than mutableStateOf so the camera
    // analyser thread (which is *not* the Compose recomposition
    // thread) reads the latest value without a snapshot read.
    val refGateOpen = remember { AtomicBoolean(false) }
    // Tutorial overlay drives `pausedForTutorial` to drain the analyser
    // input while it's visible (CameraX has no preview-disable parallel
    // to AVCapture, so the black scrim covers the preview by overdraw).
    val pausedForTutorial = remember { AtomicBoolean(false) }
    var tutorialRefJpegBytes by remember { mutableStateOf<ByteArray?>(null) }
    var tutorialDismissed by remember { mutableStateOf(false) }
    var tutorialReopenRequested by remember { mutableStateOf(false) }
    // so the DisposableEffect tear-down can stop it. Distinct from the
    // outer [replaySource] composable param (which is the integrator-
    // supplied scene metadata).
    var replayFrameSource by remember { mutableStateOf<RimbaudReplayFrameSource?>(null) }
    // Defect-2 fix (operator brief 2026-05-08) — separate
    // Dispatchers.Default scope for the replay path's
    // [PhotosphereCaptureDriver.buildLiveFrameTap] tapHostScope. See
    // the "Default dispatcher" comment in the replay LaunchedEffect
    // below for the starvation-avoidance rationale. Cancelled in the
    // DisposableEffect alongside the replay engine.
    val replayDriverScope = remember {
        kotlinx.coroutines.CoroutineScope(
            kotlinx.coroutines.SupervisorJob() + Dispatchers.Default,
        )
    }
    // [replayDriverScope] for the LIVE camera path. The earlier port
    // passed `tapHostScope = this` (the LaunchedEffect coroutine
    // scope) which inherits AndroidUiDispatcher.Main, so every
    // analyser tick re-dispatched the LiveFrameTap body — including
    // the ~1.2 MB synchronized memcpy in
    // PhotosphereSession.enqueueLiveFrame and the per-frame
    // refCaptureMutex acquire — onto Main. On Pixel 6 the X1 cores
    // make the analyser thread fast enough that Main is constantly
    // queue-stuffed with these jobs while it's also painting the
    // photosphere overlay (cross / legend / banner) at 60 fps, which
    // hitches both UI and pose updates. The XFeat DemoApp's
    // CameraFrameSource.attachAnalyser calls
    // `session.enqueueLiveFrame(...)` synchronously from the
    // analyser thread (off-Main); mirror that posture here by
    // dispatching to a Default-pool scope. See
    // docs/tracking/cl103-live-camera-perf-analysis-2026-05-08.md
    // §D1 for the full code-trace and rationale.
    val liveDriverScope = remember {
        kotlinx.coroutines.CoroutineScope(
            kotlinx.coroutines.SupervisorJob() + Dispatchers.Default,
        )
    }
    LaunchedEffect(controller, session.workingDir, replaySource) {
        if (driver != null) return@LaunchedEffect
        // Replay path: bypass the camera-Ready wait entirely. The
        // driver is heavy to instantiate (ORT load); we want it up
        // ASAP so the replay engine can begin feeding frames as soon
        // as the operator picked a scene.
        if (replaySource != null) {
            try {
                // Stage + construct the replay engine first so its
                // `latestRefJpeg()` accessor is reachable from the
                // driver's `refJpegProvider` closure below. The engine
                // does not start decoding until `source.start(...)` is
                // called further down.
                val sceneDir = replaySource.sceneDir
                if (!sceneDir.isDirectory) {
                    Log.w(
                        "CaptureScreen",
                        "synthetic replay scene dir is not a directory: ${sceneDir.absolutePath}",
                    )
                }
                val source = RimbaudReplayFrameSource(
                    sceneDir = sceneDir,
                    workingDir = File(session.workingDir),
                )
                replayFrameSource = source

                val drv = PhotosphereCaptureDriver.create(
                    context = context,
                    workingDir = File(session.workingDir),
                    // an 8° on-target threshold to match the working
                    // XFeat DemoApp at
                    // `evaluate-xfeat-lighterglue/.../MainActivity.kt:1082-1104`
                    // (`REPLAY_ON_TARGET_DEG = 8f`). Placeholder-K
                    // scenes ship with recovered tilt magnitudes that
                    // drift 4-6° vs. the 20° target ring, so the 3°
                    // production threshold never fires on these
                    // replay frames and the per-arm dwell window
                    // never closes. Live-camera path keeps the 3°
                    // production default (no `onTargetDistanceDeg`
                    // arg there).
                    onTargetDistanceDeg = REPLAY_ON_TARGET_DEG,
                    verboseFrameLogs = TwinSkinSdk.verboseFrameLogs,
                )
                // Step 2.5 (2026-05-08) — return latest decoded MP4
                // frame's JPEG bytes (was null, which the C ABI treats
                // as a failed arm, breaking per-view bundles).
                drv.setShutterCallback { _ -> source.latestFrameJpeg() }
                val driverTap = drv.buildLiveFrameTap(
                    tapHostScope = replayDriverScope,
                    refJpegProvider = {
                        // Spin-wait for the replay engine's first
                        // decoded JPEG. Pre-opened gate + bounded poll.
                        var bytes = source.latestRefJpeg()
                        var attempts = 0
                        while (bytes == null && attempts < REF_JPEG_POLL_MAX) {
                            kotlinx.coroutines.delay(REF_JPEG_POLL_DELAY_MS)
                            bytes = source.latestRefJpeg()
                            attempts += 1
                        }
                        if (bytes == null) {
                            Log.w(
                                "CaptureScreen",
                                "replay refJpegProvider gave up after " +
                                    "${REF_JPEG_POLL_MAX * REF_JPEG_POLL_DELAY_MS} ms",
                            )
                        } else {
                            tutorialRefJpegBytes = bytes
                        }
                        bytes
                    },
                )
                refGateOpen.set(true)
                val gatedTap = PhotosphereCaptureDriver.LiveFrameTap {
                    grayBuffer, intrinsics, timestampNs ->
                    if (!refGateOpen.get()) return@LiveFrameTap
                    if (pausedForTutorial.get()) return@LiveFrameTap
                    driverTap.onFrame(grayBuffer, intrinsics, timestampNs)
                }
                liveFrameTap = gatedTap
                controller.attachLiveFrameTap(gatedTap)
                driver = drv

                source.start(
                    markerSink = { gray, w, h, rowStride ->
                        markerFocus.ingestFrame(
                            gray = gray,
                            width = w,
                            height = h,
                            rowStride = rowStride,
                        )
                    },
                    liveTap = gatedTap,
                    logSink = { },
                    // the session reaches terminal stage.
                    isSessionTerminal = {
                        val stage = drv.state.value.stage
                        stage is PhotosphereState.Stage.Done ||
                            stage is PhotosphereState.Stage.Aborted
                    },
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                bootstrapError = "XFeat init failed: ${e.message ?: e::class.simpleName ?: "unknown"}"
            }
            return@LaunchedEffect
        }
        // Live path: wait for the camera to be ready before
        // instantiating the driver.
        controller.state.collect { st ->
            if (st is CameraSessionState.Ready && driver == null) {
                try {
                    val drv = PhotosphereCaptureDriver.create(
                        context = context,
                        workingDir = File(session.workingDir),
                        phiOffsetDeg = LIVE_CAMERA_PHI_OFFSET_DEG,
                        verboseFrameLogs = TwinSkinSdk.verboseFrameLogs,
                    )

                    // Enable per-arm validator so captured JPEGs are
                    // gated against the ref-frame anchor (distance
                    // band + blur floor) and stamped with
                    // TWINSKIN_VALIDATION EXIF before the bundle
                    // sees them. Mirrors iOS's
                    // CaptureView.enableBurstValidation() call.
                    controller.attachCaptureValidator()
                    // CameraSessionController.captureJpegBytes (off-Main
                    // OnImageCapturedCallback) instead of takePhoto +
                    // readBytes; saves 50-120 ms/arm × 16 arms/sweep.
                    drv.setShutterCallback { viewIndex ->
                        try {
                            val raw = controller.captureJpegBytes(label = "view_$viewIndex")
                            val validated = controller.validateAndStampJpegBytes(
                                jpeg = raw,
                                isReference = false,
                            )
                            if (validated.accepted) {
                                validated.stampedBytes
                            } else {
                                Log.i(
                                    "CaptureScreen",
                                    "view_$viewIndex rejected:" +
                                        " verdict=${validated.verdict}" +
                                        " diag=${validated.diagPx}" +
                                        " blur=${validated.blurVariance}",
                                )
                                null
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            Log.w(
                                "CaptureScreen",
                                "shutter callback failed: ${e.message}",
                                e,
                            )
                            null
                        }
                    }

                    val driverTap = drv.buildLiveFrameTap(
                        // [liveDriverScope] declaration above for
                        // rationale. The prior `tapHostScope = this`
                        // (Main-immediate via LaunchedEffect) put the
                        // 1.2 MB synchronized memcpy in
                        // PhotosphereSession.enqueueLiveFrame and the
                        // refCaptureMutex acquire on Main; this scope
                        // is Default-pool so the analyser-side work
                        // stays off Main. Cancelled in the same
                        // DisposableEffect that owns `replayDriverScope`.
                        tapHostScope = liveDriverScope,
                        refJpegProvider = {
                            try {
                                val rawBytes = File(controller.takePhoto()).readBytes()
                                // Reference capture: always accepted
                                // (anchor for every per-arm gate), but
                                // we still run validation so we can
                                // (a) stamp ref-frame EXIF and
                                // (b) record referenceDiagPx /
                                // referenceBlurVariance for the
                                // per-arm gates that follow.
                                val validated = controller.validateAndStampJpegBytes(
                                    jpeg = rawBytes,
                                    isReference = true,
                                )
                                val bytes = validated.stampedBytes
                                // Camera2 AF_MODE_OFF + AE_LOCK + AWB_LOCK
                                // override SYNCHRONOUSLY here, before the
                                // ref bytes are returned to the driver
                                // (and therefore before any live frame is
                                // enqueued). Mirrors XFeat DemoApp
                                // MainActivity.kt onCaptureReference,
                                // which calls source.lockFocusAndExposure
                                // immediately after captureReference
                                // resumes.
                                //
                                // Previous posture (lockLens fired from
                                // RoundEvent.RoundWaiting, ~10–25 frames
                                // / ~330–830 ms after the shutter on
                                // Pixel 6) left a window in which
                                // takePicture had already cancelled the
                                // pre-ref ArUco FocusMeteringAction and
                                // CONTINUOUS_PICTURE AF was free to
                                // hunt; AF_MODE_OFF then pinned the lens
                                // at whatever drifted position it had
                                // wandered to. See
                                // docs/tracking/cl103-focus-lock-timing-diff-2026-05-10.md.
                                val obs = markerFocus.lastObservedMarker
                                val markerPoi = obs?.let {
                                    android.graphics.PointF(it.centroidX, it.centroidY)
                                }
                                val decision =
                                    PhotosphereFocusPolicy.refShutterLockDecision(markerPoi)
                                controller.lockLensAndExposureForPhotosphere(
                                    poiX = decision.pointOfInterest?.x,
                                    poiY = decision.pointOfInterest?.y,
                                )
                                tutorialRefJpegBytes = bytes
                                bytes
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                Log.w(
                                    "CaptureScreen",
                                    "captureReference fullres failed: ${e.message}",
                                    e,
                                )
                                null
                            }
                        },
                    )
                    // driver-built tap with an operator gate. While
                    // `refGateOpen` is false (pre-button-tap) every
                    // analyser frame is silently dropped — neither
                    // `captureReference` nor `enqueueLiveFrame` are
                    // invoked, so the dwell tracker stays asleep and
                    // the session sits in `RefCapture`. Once the
                    // operator taps "Capture reference" the gate
                    // flips OPEN; from that moment forward frames
                    // pass straight through to the driver-built tap,
                    // which runs its own `refBeginIfNeeded` guard
                    // for the single-shot ref capture path. Mirrors
                    // iOS `CaptureView.swift` post-port: same
                    // semantics, AtomicBoolean for thread-safety
                    // since the analyser callback fires off a
                    // dedicated CameraX executor.
                    val gatedTap = PhotosphereCaptureDriver.LiveFrameTap {
                        grayBuffer, intrinsics, timestampNs ->
                        if (!refGateOpen.get()) return@LiveFrameTap
                        if (pausedForTutorial.get()) return@LiveFrameTap
                        driverTap.onFrame(grayBuffer, intrinsics, timestampNs)
                    }
                    liveFrameTap = gatedTap
                    controller.attachLiveFrameTap(gatedTap)
                    driver = drv
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    bootstrapError = "XFeat init failed: ${e.message ?: e::class.simpleName ?: "unknown"}"
                }
            }
        }
    }
    DisposableEffect(driver) {
        // entry. The delegated `var driver` would otherwise be captured by
        // REFERENCE in `onDispose`, so the first null→drv transition (which
        // disposes the previous null-keyed effect) would read the NEW value
        // and call `cancel()` on the freshly-built driver, immediately
        // aborting the session. Snapshotting captures the PRIOR key value,
        // mirroring iOS `deinit` semantics: first dispose is a no-op; only
        // screen-exit with `current = drv` triggers `drv.cancel()`.
        //
        // tap-detach (`controller.attachLiveFrameTap(null)` +
        // first null→drv transition disposed the null-keyed effect and
        // cleared the tap that the LaunchedEffect had JUST installed
        // (~28 ms earlier). Symptom on Pixel 6: every analyser frame
        // observes `liveFrameTap == null`, so `gatedTap.onFrame` never
        // fires, `captureReference` is never invoked, and the operator's
        // "Capture reference" tap silently drops on the floor with no
        // visible feedback. Gate the tap-detach on `current != null`
        // (same posture as `current?.cancel()` above): only the real
        // screen-exit dispose (where the snapshot captured `drv`) tears
        // down the tap.
        val current = driver
        onDispose {
            if (current != null) {
                current.cancel()
                // Detach the tap from the controller so any in-flight
                // analyser callback drops the frame instead of forwarding
                // it to the cancelled driver. Belt-and-suspenders with
                // CameraSessionController.dispose's own tap clear.
                controller.attachLiveFrameTap(null)
                liveFrameTap = null
                replayFrameSource?.stop()
                replayFrameSource = null
                // Defect-2 fix — cancel the replay tap-host scope so
                // any in-flight ref-capture / enqueue coroutines
                // unwind cleanly with the driver.
                replayDriverScope.cancel()
                // the live-camera tap-host scope.
                liveDriverScope.cancel()
            }
        }
    }

    var demoStep by remember { mutableStateOf<DemoStep?>(null) }
    var submitting by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var demoPickerOptions by remember { mutableStateOf<List<DemoCaptureSummary>?>(null) }
    // `refGateOpen`. Set true on the "Capture reference" button tap;
    // hides the button on the next recomposition. The actor-side
    // gate is still the source of truth for the live-frame tap (it
    // runs on the camera analyser thread); this flag is for UI
    // visibility only.
    var refButtonTapped by remember { mutableStateOf(false) }

    // milestone side-effects (focus lock at first RoundWaiting,
    // unlock + finalize at AllRoundsDone, abort handling). The
    // overlay itself reads off `driver.state` for the per-arm tile
    // grid + live cursor — see [XFeatPhotosphereOverlay] below.
    LaunchedEffect(driver) {
        val drv = driver ?: return@LaunchedEffect
        var focusLocked = false
        drv.events.collect { ev ->
            when (ev) {
                is PhotosphereCaptureDriver.RoundEvent.RoundWaiting -> {
                    if (!focusLocked) {
                        // Camera2 hard lens-lock
                        // is now installed inline with ref capture
                        // inside refJpegProvider, BEFORE any live frame
                        // is enqueued. This branch only flips the
                        // focusLocked guard and detaches the marker
                        // focus controller post-lock.
                        focusLocked = true
                        // OI-067 / D2 — detach the marker-focus controller
                        // now that focus is locked. ArUco runs every 5th
                        // analyser frame (~6 Hz, 5-10 ms/call) on the same
                        // single thread that feeds XFeat inference; running
                        // it for all 16 arms burns ~50-60 ms/sec of
                        // analyser-thread budget. We no longer need marker
                        // detection during the sweep — re-attach at
                        // AllRoundsDone / Aborted so the next session finds
                        // the controller live.
                        controller.attachMarkerFocusController(null)
                    }
                }
                is PhotosphereCaptureDriver.RoundEvent.Capturing,
                is PhotosphereCaptureDriver.RoundEvent.RoundComplete,
                -> Unit // Per-arm UI handled by overlay reading state.
                is PhotosphereCaptureDriver.RoundEvent.AllRoundsDone -> {
                    val obs = markerFocus.lastObservedMarker
                    val markerPoi = obs?.let {
                        android.graphics.PointF(it.centroidX, it.centroidY)
                    }
                    val decision = PhotosphereFocusPolicy.decide(
                        stage = PhotosphereState.Stage.Done,
                        markerPoi = markerPoi,
                    )
                    if (decision.focusMode == PhotosphereFocusMode.ContinuousAutoFocus) {
                        controller.unlockLensAndExposureForPhotosphere()
                    }
                    controller.attachMarkerFocusController(markerFocus)
                    markerFocus.reset()
                    focusLocked = false
                    submitting = true
                    // Submit overlay covers the preview; free CameraX so
                    // the JPEG-compress fan-out has heap headroom.
                    controller.dispose()
                    try {
                        val result = drv.finalize()
                        session.submit(result)
                        submitted = true
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // Camera is already disposed; keep the overlay up
                        // so the dead preview stays hidden — the operator
                        // can only Cancel from the top-bar action now.
                        errorText = e.message ?: "submit failed"
                    }
                }
                is PhotosphereCaptureDriver.RoundEvent.Aborted -> {
                    val obs = markerFocus.lastObservedMarker
                    val markerPoi = obs?.let {
                        android.graphics.PointF(it.centroidX, it.centroidY)
                    }
                    val decision = PhotosphereFocusPolicy.decide(
                        stage = drv.state.value.stage,
                        markerPoi = markerPoi,
                    )
                    if (decision.focusMode == PhotosphereFocusMode.ContinuousAutoFocus) {
                        controller.unlockLensAndExposureForPhotosphere()
                    }
                    controller.attachMarkerFocusController(markerFocus)
                    markerFocus.reset()
                    focusLocked = false
                    errorText = "Capture aborted: ${ev.reason}"
                }
            }
        }
    }

    // per-arm overlay. Null until the driver has been instantiated +
    // its first state snapshot has propagated.
    val driverState: PhotosphereState? = driver?.state?.collectAsState()?.value

    val tutorialContext = context
    // Seed from SharedPreferences; subsequent toggles update this
    // state synchronously via `onDontShowAgainChanged`.
    var dontShowAgainState by remember(tutorialContext) {
        mutableStateOf(PhotosphereTutorialPrefs.dontShowAgain(tutorialContext))
    }
    val shouldShowTutorial = tutorialRefJpegBytes != null
        && !tutorialDismissed
        && (!dontShowAgainState || tutorialReopenRequested)
    val tutorialReopenEnabled = tutorialRefJpegBytes != null
        && !shouldShowTutorial
        && (driverState?.capturedArms?.isEmpty() ?: true)

    // Free the ref JPEG (and its decoded ImageBitmap) once the
    // operator commits any arm; the tutorial is unreachable from then
    // on, so keeping ~3–5 MB + the RGBA bitmap resident is waste.
    val firstArmCommitted = driverState?.capturedArms?.isNotEmpty() == true
    LaunchedEffect(firstArmCommitted) {
        if (firstArmCommitted) {
            tutorialRefJpegBytes = null
        }
    }

    // Top-level Box so the overlay covers status bar + TopAppBar
    // (parity with iOS `.ignoresSafeArea()`); rendering inside the
    // Scaffold content lambda would inherit its inset padding.
    Box(Modifier.fillMaxSize()) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (replaySource != null) "Capture (replay)" else "Capture") },
                navigationIcon = {
                    TextButton(onClick = onCancel) { Text("Cancel") }
                },
                actions = {
                    if (tutorialReopenEnabled) {
                        TextButton(onClick = {
                            tutorialReopenRequested = true
                            tutorialDismissed = false
                        }) {
                            Text("?")
                        }
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (replaySource != null) {
                val replayBitmap = replayFrameSource?.replayFrameFlow?.collectAsState()?.value
                Box(
                    modifier = Modifier.fillMaxSize().background(Color.Black),
                    contentAlignment = Alignment.Center,
                ) {
                    if (replayBitmap != null) {
                        Image(
                            bitmap = replayBitmap.asImageBitmap(),
                            contentDescription = "replay frame",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                    } else if (driverState == null) {
                        Text("Loading replay scene…", color = Color.White)
                    }
                }
            } else {
                CameraPreview(
                    controller = controller,
                    modifier = Modifier.fillMaxSize(),
                )
                if (devMode) {
                    com.twinskin.sdk.ui.capture.MarkerDebugOverlay(
                        markerFocus = markerFocus,
                        controller = controller,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }

            if (replaySource == null &&
                driverState == null &&
                demoStep == null &&
                !submitting &&
                bootstrapError == null &&
                controllerState !is CameraSessionState.Error
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.55f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color.White)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Preparing camera…",
                            color = Color.White,
                            style = MaterialTheme.typography.bodyLarge,
                        )
                    }
                }
            }

            if (driverState != null && demoStep == null && !submitting) {
                XFeatPhotosphereOverlay(state = driverState)
            }

            // + — operator-gated "Capture
            // reference" button. Replay pre-opens refGateOpen so the
            // first decoded frame fires captureReference automatically.
            if (replaySource == null
                && driverState != null
                && driverState.stage is PhotosphereState.Stage.RefCapture
                && demoStep == null
                && !submitting
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(bottom = BOTTOM_CHROME_PADDING_DP.dp + 80.dp)
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Button(onClick = {
                        refButtonTapped = true
                        refGateOpen.set(true)
                    }) {
                        Text(text = "Capture reference")
                    }
                }
            }

            // devMode-only demo-capture shortcut. Kept visible for the whole
            // capture (not just the sub-second pre-driver window) so the
            // bypass is actually reachable — by a developer and by the e2e
            // test. `demoStep`/`submitting` still hide it once a demo
            // capture is under way.
            if (devMode && demoStep == null && !submitting) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp),
                    color = Color.Black.copy(alpha = 0.6f),
                    shape = MaterialTheme.shapes.small,
                ) {
                    TextButton(
                        onClick = {
                            scope.launch {
                                val catalog = try {
                                    session.listDemoCaptures()
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    errorText = e.message ?: "Demo capture failed"
                                    return@launch
                                }
                                when {
                                    catalog.isEmpty() -> {
                                        errorText = "No demo captures available on the server"
                                    }
                                    catalog.size == 1 -> {
                                        useDemoCapture(
                                            session = session,
                                            entryId = catalog.single().id,
                                            onStateChange = { demoStep = it },
                                            onSubmitted = { submitted = true },
                                            onError = { errorText = it },
                                        )
                                    }
                                    else -> {
                                        demoPickerOptions = catalog
                                    }
                                }
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    ) {
                        Text("Use demo capture", color = Color.White)
                    }
                }
            }

            when (val ds = demoStep) {
                is DemoStep.Downloading -> DemoDownloadOverlay(downloaded = ds.downloaded, total = ds.total)
                DemoStep.Submitting -> UploadOverlay("Preparing bundle…", null)
                null -> {
                    if (submitting) {
                        UploadOverlay(
                            errorText ?: "Preparing bundle…",
                            null,
                            showSpinner = errorText == null,
                        )
                    }
                }
            }

            val ctrlErr = (controllerState as? CameraSessionState.Error)?.message
            val banner = errorText ?: bootstrapError ?: ctrlErr
            if (banner != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.align(Alignment.TopCenter).padding(16.dp),
                ) {
                    Text(
                        banner,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                }
            }
        }

        demoPickerOptions?.let { options ->
            DemoCapturePickerDialog(
                options = options,
                onDismiss = { demoPickerOptions = null },
                onPick = { chosen ->
                    demoPickerOptions = null
                    scope.launch {
                        useDemoCapture(
                            session = session,
                            entryId = chosen.id,
                            onStateChange = { demoStep = it },
                            onSubmitted = { submitted = true },
                            onError = { errorText = it },
                        )
                    }
                },
            )
        }
    }

    val tutorialBytes = tutorialRefJpegBytes
    if (shouldShowTutorial && tutorialBytes != null) {
        val refImage = remember(tutorialBytes) {
            tutorialBytes.toImageBitmap()
        }
        PhotosphereTutorialOverlay(
            refImage = refImage,
            seenAtLeastOnce = PhotosphereTutorialPrefs
                .seenAtLeastOnce(tutorialContext),
            dontShowAgainInitial = dontShowAgainState,
            onPauseChanged = { paused ->
                pausedForTutorial.set(paused)
            },
            onDontShowAgainChanged = { value ->
                dontShowAgainState = value
                PhotosphereTutorialPrefs
                    .setDontShowAgain(tutorialContext, value)
            },
            onDismiss = {
                PhotosphereTutorialPrefs.markSeen(tutorialContext)
                tutorialDismissed = true
                tutorialReopenRequested = false
            },
        )
    }
    }
}

@Composable
private fun DemoCapturePickerDialog(
    options: List<DemoCaptureSummary>,
    onDismiss: () -> Unit,
    onPick: (DemoCaptureSummary) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pick a demo capture") },
        text = {
            Column {
                for (option in options) {
                    TextButton(
                        onClick = { onPick(option) },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            option.name,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

/**
 * XFeat-DemoApp per-arm capture overlay
 *
 * Replaces the v6.1 single-progress-bar `CaptureProgressOverlay`. The
 * overlay reads off the upstream [PhotosphereState] (capturedArms,
 * currentRound, currentAzEstimate, currentTiltMagDeg, stage) and
 * renders the same chrome the XFeat DemoApp ships.
 */
@Composable
private fun XFeatPhotosphereOverlay(state: PhotosphereState) {
    Box(Modifier.fillMaxSize()) {
        PhotosphereRingOverlay(
            state = state,
            modifier = Modifier.fillMaxSize().align(Alignment.Center),
        )

        PhotosphereBanner(
            state = state,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 16.dp)
                .padding(top = TOP_BAR_HEIGHT_DP.dp + BANNER_TOP_GAP_DP.dp)
                .height(BANNER_HEIGHT_DP.dp),
        )

        ProgressLegend(
            state = state,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(bottom = BOTTOM_CHROME_PADDING_DP.dp)
                .padding(horizontal = 16.dp),
        )
    }
}

@Composable
private fun PhotosphereBanner(
    state: PhotosphereState,
    modifier: Modifier = Modifier,
) {
    val stage = state.stage
    val bins = ringBinsCovered(state.capturedArms)
    val (title, subtitle) = when (stage) {
        is PhotosphereState.Stage.RefCapture ->
            "Initialising reference…" to
                "The reference frame anchors all 16 ring sectors."
        is PhotosphereState.Stage.RoundWaiting ->
            "$bins / $BIN_COUNT sectors captured" to
                "Aim toward the highlighted sector."
        is PhotosphereState.Stage.Aiming ->
            "$bins / $BIN_COUNT sectors captured" to
                "Aim toward the highlighted sector."
        is PhotosphereState.Stage.OnTarget ->
            "$bins / $BIN_COUNT sectors captured" to "On target — hold steady."
        is PhotosphereState.Stage.Capturing ->
            "$bins / $BIN_COUNT sectors captured" to "Hold steady — XFeat is firing."
        is PhotosphereState.Stage.RoundComplete ->
            "$bins / $BIN_COUNT sectors captured" to "Next sector…"
        is PhotosphereState.Stage.Done ->
            "All $BIN_COUNT sectors captured." to "Finalising bundle…"
        is PhotosphereState.Stage.Aborted ->
            "Session aborted." to (stage.reason.message ?: "")
    }
    val errText = state.currentError?.message
    Column(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = subtitle,
            color = Color.White.copy(alpha = 0.75f),
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (errText != null) {
            Text(
                text = errText,
                color = AMBER,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun PhotosphereRingOverlay(
    state: PhotosphereState,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val baseRadius = min(size.width, size.height) * RING_RADIUS_FRAC

        val binCount = IntArray(BIN_COUNT)
        for (globalIdx in state.capturedArms) {
            if (globalIdx < 0 || globalIdx >= ARM_BIN.size) continue
            binCount[ARM_BIN[globalIdx]]++
        }

        val pickerBin: Int? = activeRoundAndArm(state)?.let { (round, arm) ->
            val globalIdx = (round - 1) * ARMS_PER_ROUND + arm
            ARM_BIN.getOrNull(globalIdx)
        }
        // Amber rule: a sector only shows orange while it is still
        // gray (0 captures). If the picker is currently targeting a
        // sector that already has a capture (the operator is mid-
        // sweep across it), redirect the amber to the closest
        // remaining gray sector so the visual hint never sits on a
        // light-green or full-green slice.
        val activeBin: Int? = when {
            pickerBin == null -> null
            pickerBin in 0 until BIN_COUNT && binCount[pickerBin] == 0 -> pickerBin
            else -> nearestGrayBin(binCount, state.currentAzEstimate)
        }

        val innerR = baseRadius * RING_INNER_FRAC
        val outerNormal = baseRadius * RING_OUTER_NORMAL_FRAC
        val outerCardinal = baseRadius * RING_OUTER_CARDINAL_FRAC

        for (bin in 0 until BIN_COUNT) {
            val isCardinal = bin % BINS_PER_CARDINAL == 0
            val outer = if (isCardinal) outerCardinal else outerNormal
            val baseColor = when {
                binCount[bin] >= 2 -> GREEN
                binCount[bin] == 1 -> GREEN_LIGHT
                else -> SECTOR_EMPTY
            }
            val color = if (bin == activeBin) AMBER else baseColor
            drawRingSector(
                cx = cx, cy = cy,
                inner = innerR, outer = outer,
                startAzDeg = bin * SECTOR_SPAN_DEG - BIN_CENTER_OFFSET_DEG,
                sweepDeg = SECTOR_SPAN_DEG,
                gapDeg = SECTOR_GAP_DEG,
                color = color,
            )
        }

        for (bin in 0 until BIN_COUNT step BINS_PER_CARDINAL) {
            val az = bin * SECTOR_SPAN_DEG
            drawCardinalTiltChevron(cx, cy, outerCardinal, az)
        }

        drawCircle(
            color = Color(COLOR_REF_FILL),
            radius = baseRadius * REF_DISC_RADIUS_FRAC,
            center = Offset(cx, cy),
            style = Stroke(width = ARM_STROKE_PX),
        )

        val az = state.currentAzEstimate
        val mag = state.currentTiltMagDeg
        if (az != null && mag != null) {
            val dotRadius = (mag / TILT_MAG_REF_DEG * baseRadius)
                .coerceAtMost(baseRadius * LIVE_DOT_MAX_RADIUS_FRAC)
            val (lx, ly) = armEndpoint(cx, cy, dotRadius, az)
            val center = Offset(lx, ly)
            drawCircle(
                color = Color.Black,
                radius = LIVE_DOT_SIZE_PX + LIVE_DOT_OUTLINE_PX,
                center = center,
            )
            drawCircle(
                color = Color.White,
                radius = LIVE_DOT_SIZE_PX,
                center = center,
            )
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRingSector(
    cx: Float,
    cy: Float,
    inner: Float,
    outer: Float,
    startAzDeg: Float,
    sweepDeg: Float,
    gapDeg: Float,
    color: Color,
) {
    val halfGap = gapDeg / 2f
    val a0 = startAzDeg + halfGap
    val a1 = startAzDeg + sweepDeg - halfGap
    val sweep = a1 - a0
    if (sweep <= 0f) return
    val steps = (sweep / 1.5f).toInt().coerceAtLeast(4)
    val path = Path()
    fun point(r: Float, azDeg: Float): Offset {
        val rad = Math.toRadians(azDeg.toDouble())
        return Offset(cx + r * sin(rad).toFloat(), cy + r * cos(rad).toFloat())
    }
    var first = true
    for (i in 0..steps) {
        val t = i.toFloat() / steps
        val a = a0 + sweep * t
        val p = point(outer, a)
        if (first) { path.moveTo(p.x, p.y); first = false } else path.lineTo(p.x, p.y)
    }
    for (i in 0..steps) {
        val t = i.toFloat() / steps
        val a = a1 - sweep * t
        val p = point(inner, a)
        path.lineTo(p.x, p.y)
    }
    path.close()
    drawPath(path = path, color = color)
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCardinalTiltChevron(
    cx: Float,
    cy: Float,
    sectorOuter: Float,
    azDeg: Float,
) {
    val rad = Math.toRadians(azDeg.toDouble())
    val sinA = sin(rad).toFloat()
    val cosA = cos(rad).toFloat()
    val tipR = sectorOuter + CARDINAL_CHEVRON_GAP_PX + CARDINAL_CHEVRON_LEN_PX
    val baseR = sectorOuter + CARDINAL_CHEVRON_GAP_PX
    val tip = Offset(cx + tipR * sinA, cy + tipR * cosA)
    val baseCenter = Offset(cx + baseR * sinA, cy + baseR * cosA)
    val perpSin = cosA
    val perpCos = -sinA
    val left = Offset(
        baseCenter.x + CARDINAL_CHEVRON_HALF_W_PX * perpSin,
        baseCenter.y + CARDINAL_CHEVRON_HALF_W_PX * perpCos,
    )
    val right = Offset(
        baseCenter.x - CARDINAL_CHEVRON_HALF_W_PX * perpSin,
        baseCenter.y - CARDINAL_CHEVRON_HALF_W_PX * perpCos,
    )
    val path = Path().apply {
        moveTo(tip.x, tip.y)
        lineTo(left.x, left.y)
        lineTo(right.x, right.y)
        close()
    }
    drawPath(path = path, color = AMBER)
}

private fun activeRoundAndArm(state: PhotosphereState): Pair<Int, Int>? =
    when (val stage = state.stage) {
        is PhotosphereState.Stage.Aiming -> stage.round to stage.targetArm
        is PhotosphereState.Stage.OnTarget -> stage.round to stage.targetArm
        is PhotosphereState.Stage.Capturing -> stage.round to stage.targetArm
        else -> null
    }

private fun armEndpoint(
    cx: Float,
    cy: Float,
    radius: Float,
    azDeg: Float,
): Pair<Float, Float> {
    val rad = Math.toRadians(azDeg.toDouble())
    val x = cx + radius * sin(rad).toFloat()
    val y = cy + radius * cos(rad).toFloat()
    return x to y
}

@Composable
private fun ProgressLegend(
    state: PhotosphereState,
    modifier: Modifier = Modifier,
) {
    val bins = ringBinsCovered(state.capturedArms)
    val bonusExtras = (state.capturedArms.size - bins).coerceAtLeast(0)
    Column(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .padding(8.dp),
    ) {
        Text(
            text = "Sectors  $bins / $BIN_COUNT",
            color = Color.White,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
        )
        if (bonusExtras > 0) {
            Text(
                text = "Coverage  +$bonusExtras",
                color = COVERAGE_CYAN,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
            )
        }
    }
}

@Composable
private fun DemoDownloadOverlay(downloaded: Int, total: Int) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "Downloading demo capture…",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { (downloaded.toFloat() / total.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.width(240.dp),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "$downloaded / $total",
                color = Color.White,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

private suspend fun useDemoCapture(
    session: CaptureSession,
    entryId: String,
    onStateChange: (DemoStep?) -> Unit,
    onSubmitted: () -> Unit,
    onError: (String) -> Unit,
) {
    try {
        onStateChange(DemoStep.Downloading(downloaded = 0, total = 1))
        session.submitDemoCapture(entryId = entryId) { d, t ->
            onStateChange(DemoStep.Downloading(downloaded = d, total = t))
        }
        onStateChange(DemoStep.Submitting)
        onSubmitted()
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        onError(e.message ?: "Demo capture failed")
        onStateChange(null)
    }
}

@Composable
private fun CameraPreview(
    controller: CameraSessionController,
    modifier: Modifier,
) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PreviewView(ctx).also { view ->
                // PERFORMANCE (SurfaceView) explicitly. CameraX 1.4+
                // defaults to PERFORMANCE, but a future version
                // flipping the default would silently regress to
                // COMPATIBLE (TextureView), which on Camera2-LIMITED
                // HALs (XCover5, A21s) routes ImageCapture through
                // CameraX's GL surface processor and adds 1-3× per-arm
                // wall-clock. The XFeat DemoApp pins this explicitly
                // (`PhotosphereCaptureScreen.kt:170`) for the same
                // reason — match that posture.
                view.implementationMode = PreviewView.ImplementationMode.PERFORMANCE
                view.scaleType = PreviewView.ScaleType.FILL_CENTER
                controller.preview.setSurfaceProvider(view.surfaceProvider)
                controller.attachPreviewView(view)
            }
        },
    )
}

@Composable
private fun UploadOverlay(label: String, progress: Float?, showSpinner: Boolean = true) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (showSpinner) {
                if (progress != null) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.width(240.dp))
                } else {
                    CircularProgressIndicator()
                }
                Spacer(Modifier.height(12.dp))
            }
            Text(label, color = Color.White)
        }
    }
}

private tailrec fun android.content.Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

// --- XFeat overlay constants (mirrors XFeat DemoApp) ------------------

private val ARM_AZIMUTHS: FloatArray = floatArrayOf(
    0f, 90f, 180f, 270f,
    22.5f, 112.5f, 202.5f, 292.5f,
    45f, 135f, 225f, 315f,
    67.5f, 157.5f, 247.5f, 337.5f,
    11.25f, 101.25f, 191.25f, 281.25f,
    33.75f, 123.75f, 213.75f, 303.75f,
    56.25f, 146.25f, 236.25f, 326.25f,
    78.75f, 168.75f, 258.75f, 348.75f,
)

private const val ARMS_PER_ROUND: Int = 4
private const val PRIMARY_ARM_COUNT: Int = 16

private const val SECTOR_SPAN_DEG: Float = 22.5f
private const val BINS_PER_CARDINAL: Int = 4

private const val BIN_CENTER_OFFSET_DEG: Float = SECTOR_SPAN_DEG / 2f

private val BIN_COUNT: Int = PhotosphereMath.BIN_COUNT
private val ARM_BIN: List<Int> = PhotosphereMath.BIN_OF_VIEW_INDEX

private fun ringBinsCovered(captured: Set<Int>): Int =
    PhotosphereMath.binsCovered(captured)

/** Closest 0-capture sector to [currentAzDeg] (degrees), or null when
 *  every sector already has at least one capture. */
private fun nearestGrayBin(binCount: IntArray, currentAzDeg: Float?): Int? {
    var best: Int? = null
    var bestDist = Float.MAX_VALUE
    val heading = ((currentAzDeg ?: 0f) % 360f + 360f) % 360f
    for (bin in 0 until BIN_COUNT) {
        if (binCount[bin] != 0) continue
        val center = bin * SECTOR_SPAN_DEG
        val raw = kotlin.math.abs(heading - center) % 360f
        val dist = if (raw > 180f) 360f - raw else raw
        if (dist < bestDist) {
            bestDist = dist
            best = bin
        }
    }
    return best
}

/** Defect-2 / replay refJpegProvider — bounded poll for the replay
 *  engine's first decoded frame. ~2 s upper bound (40 × 50 ms) —
 *  generous enough to absorb codec startup on slower devices, short
 *  enough to surface a missing-scene error before the operator gives
 *  up. */
private const val REF_JPEG_POLL_DELAY_MS: Long = 50L
private const val REF_JPEG_POLL_MAX: Int = 40

/**
 * synthetic-replay path. Mirrors the working XFeat DemoApp at
 * `evaluate-xfeat-lighterglue/.../MainActivity.kt:1784`
 * (`REPLAY_ON_TARGET_DEG = 8f`). Placeholder-K scenes ship with
 * recovered tilt magnitudes that drift 4-6° vs. the 20° target ring,
 * so the 3° production threshold (`PhotosphereMath
 * .ON_TARGET_DISTANCE_DEG`) never fires on replay and the per-arm
 * dwell window never closes. Live-camera path keeps the production
 * default — only the replay branch passes this through to
 * [PhotosphereCaptureDriver.create].
 */
private const val REPLAY_ON_TARGET_DEG: Float = 8f

/**
 * OI-066 fix (2026-05-08) — sensor→display phi rotation applied on the
 * live-camera path. CameraX's `ImageAnalysis` ships 640×480 landscape
 * YUV regardless of display orientation while the capture UI is
 * portrait-locked, so the recovered `tilt_phi` is 90° offset from the
 * on-screen cross frame. Without this offset, the bar cursor drifts
 * 90° from the operator's actual orientation (tilting "up" lights the
 * "left" bar, etc). Mirrors XFeat DemoApp
 * `LIVE_CAMERA_PHI_OFFSET_DEG` at
 * `evaluate-xfeat-lighterglue/.../MainActivity.kt:1796` and iOS
 * `phiOffsetDeg = 90` at `PhotosphereCaptureView.swift:838-845`.
 * Replay path uses `0f` (frames already in display frame).
 */
private const val LIVE_CAMERA_PHI_OFFSET_DEG: Float = 90f

private const val TOP_BAR_HEIGHT_DP: Int = 56
private const val BANNER_TOP_GAP_DP: Int = 4
private const val BANNER_HEIGHT_DP: Int = 56
private const val BOTTOM_CHROME_PADDING_DP: Int = 12

private const val RING_RADIUS_FRAC: Float = 0.38f
private const val RING_INNER_FRAC: Float = 0.55f
private const val RING_OUTER_NORMAL_FRAC: Float = 0.85f
private const val RING_OUTER_CARDINAL_FRAC: Float = 1.10f
private const val SECTOR_GAP_DEG: Float = 1.5f
private const val CARDINAL_CHEVRON_GAP_PX: Float = 4f
private const val CARDINAL_CHEVRON_LEN_PX: Float = 14f
private const val CARDINAL_CHEVRON_HALF_W_PX: Float = 7f

private const val REF_DISC_RADIUS_FRAC: Float = 0.2f
private const val TILT_MAG_REF_DEG: Float = 20f
private const val LIVE_DOT_MAX_RADIUS_FRAC: Float = 1.2f
private const val LIVE_DOT_SIZE_PX: Float = 11f
private const val LIVE_DOT_OUTLINE_PX: Float = 3f
private const val ARM_STROKE_PX: Float = 5f

private const val COLOR_REF_FILL: Long = 0xFF222222
private val SECTOR_EMPTY: Color = Color(0x55FFFFFF)
private val GREEN: Color = Color(0xFF2EB872)
private val GREEN_LIGHT: Color = Color(0xFFA8E6BB)
private val AMBER: Color = Color(0xFFFF9F1C)
private val COVERAGE_CYAN: Color = Color(red = 0.28f, green = 0.79f, blue = 0.89f)
