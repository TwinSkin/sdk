package com.twinskin.sdk.ui.annotation_editor.delineation.canvas

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType

/**
 * Painter stack for [DrawingCanvas]. Each function is a pure
 * `DrawScope` extension over canvas-pixel geometry; callers must
 * convert image-pixel vertices via [imageToCanvas] before invoking.
 * Keeping painters in canvas-px lets a future `Modifier.graphicsLayer`
 * on the image painter compose additively.
 *
 * Clinical colours (necrosis = near-black, slough = yellow,
 * granulation = red) match spec §8.2.
 */

/**
 * Outline + fill of a closed polygon. Thick stroke when focused
 * (spec §6.3.2).
 */
internal fun DrawScope.drawClosedPolygon(
    canvasPoly: List<Offset>,
    color: Color,
    focused: Boolean,
) {
    if (canvasPoly.size < 3) return
    val path = pathOf(canvasPoly, closed = true)
    drawPath(path, color = color.copy(alpha = if (focused) 0.25f else 0.15f), style = Fill)
    drawPath(
        path = path,
        color = color,
        style = Stroke(width = if (focused) 6f else 4f),
    )
}

/**
 * Read-only wound contour shown on screen 4 — dashed orange, no
 * fill. Dashed pattern distinguishes "context wound" from the
 * solid-rendered editable wound on screen 2; orange (rather than
 * gray) keeps it legible on dark photos and distinct from
 * [TissueType.Necrosis] near-black.
 */
internal fun DrawScope.drawDashedWound(canvasPoly: List<Offset>) {
    if (canvasPoly.size < 3) return
    drawPath(
        path = pathOf(canvasPoly, closed = true),
        color = ClosedPolygonColor,
        style = Stroke(
            width = 5f,
            pathEffect = PathEffect.dashPathEffect(intervals = floatArrayOf(12f, 6f)),
        ),
    )
}

/** Open in-progress stroke — dashed green polyline, no fill. */
internal fun DrawScope.drawOpenStroke(canvasPoly: List<Offset>, color: Color = OpenStrokeColor) {
    if (canvasPoly.size < 2) return
    drawPath(
        path = pathOf(canvasPoly, closed = false),
        color = color,
        style = Stroke(
            width = 6f,
            pathEffect = PathEffect.dashPathEffect(intervals = floatArrayOf(8f, 4f)),
        ),
    )
}

/**
 * Enlarged dot at the open stroke's first point when closure is
 * imminent (spec §6.2.5). Halo radii are sized to the closure-zone
 * trigger radius — the cue grows visibly before the trigger fires.
 * [color] defaults to [OpenStrokeColor]; the tissue screen passes
 * the tissue type's clinical colour.
 */
internal fun DrawScope.drawFirstPointHalo(canvasPos: Offset, color: Color = OpenStrokeColor) {
    drawCircle(
        color = color.copy(alpha = 0.3f),
        radius = 22f,
        center = canvasPos,
    )
    drawCircle(
        color = color,
        radius = 12f,
        center = canvasPos,
    )
}

/**
 * U6 non-traversal contact cue — translucent red dot at the
 * projection point of the most recent clamp. The caller supplies
 * [alpha] so it can drive the 250 ms fade on touch-up via
 * `animateFloatAsState`.
 */
internal fun DrawScope.drawNonTraversalCue(canvasPos: Offset, alpha: Float) {
    if (alpha <= 0f) return
    drawCircle(
        color = NonTraversalCueColor.copy(alpha = (alpha * 0.6f).coerceIn(0f, 1f)),
        radius = 12f,
        center = canvasPos,
    )
}

/** Spec §8.2 clinical colour for a tissue type. Falls back to gray for [TissueType.Other]. */
internal fun clinicalColorFor(type: TissueType): Color = when (type) {
    TissueType.Necrosis -> Color(0xFF1A1A1A)
    TissueType.Slough -> Color(0xFFE0C200)
    TissueType.Granulation -> Color(0xFFD12A2A)
    is TissueType.Other -> Color(0xFF888888)
}

internal val OpenStrokeColor: Color = Color(0xFF2AB07A)            // green
internal val ClosedPolygonColor: Color = Color(0xFFE07A2A)         // wound orange
internal val NonTraversalCueColor: Color = Color(0xFFD12A2A)       // red

private fun pathOf(poly: List<Offset>, closed: Boolean): Path {
    val path = Path()
    path.moveTo(poly[0].x, poly[0].y)
    for (i in 1 until poly.size) path.lineTo(poly[i].x, poly[i].y)
    if (closed) path.close()
    return path
}
