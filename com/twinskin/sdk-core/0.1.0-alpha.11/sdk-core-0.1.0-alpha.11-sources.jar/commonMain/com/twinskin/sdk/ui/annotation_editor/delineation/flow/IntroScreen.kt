package com.twinskin.sdk.ui.annotation_editor.delineation.flow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Help
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.annotation_editor.delineation.Step
import com.twinskin.sdk.ui.annotation_editor.delineation.help.HelpDialog
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.Strings
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType

/**
 * Annotation editor entry screen (spec §5). Layout matches the
 * Flutter `manual_contour_intro.dart` reference: a large step
 * title, two instructional paragraphs, the no-auto-save warning
 * banner at the bottom, and a footer with Cancel + Start drawing.
 *
 * The Resume banner (SDK-specific — Flutter has no equivalent)
 * appears above the instructional content when [hasDraft] is true,
 * replacing Start drawing in the footer with its own Resume /
 * Start fresh buttons. Cancel stays in the footer either way so
 * the user always has an escape hatch.
 *
 * The help icon on the top app bar opens [HelpDialog] over
 * `strings.helpSlides.intro` (M12 content). The back arrow on the
 * top app bar mirrors Cancel — the integrator's back-stack wiring
 * (system back / nav-bar back) also calls [onCancel].
 *
 * The draft-clear-on-Start-fresh semantics belong to M13: the
 * `onStart` lambda is wired upstream as
 * `{ draftStore.clear(imageHash); step = Step.Wound }` so an
 * explicit "Start fresh" intent doesn't leave the stale draft
 * around for the next session entry.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun IntroScreen(
    hasDraft: Boolean,
    strings: Strings,
    /**
     * Label for the primary CTA when [hasDraft] is false.
     * WoundAnnotationEditor passes [Strings.startDrawingButton] in
     * edit-existing mode and [Strings.continueButton] in fresh mode.
     */
    startActionLabel: String,
    onResume: () -> Unit,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var showHelp by remember { mutableStateOf(false) }
    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(strings.introTitle) },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.backContentDescription,
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showHelp = true }) {
                        Icon(Icons.Outlined.Help, contentDescription = strings.helpContentDescription)
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 24.dp),
                verticalArrangement = Arrangement.spacedBy(0.dp),
            ) {
                if (hasDraft) {
                    ResumeBanner(strings = strings, onResume = onResume, onStartFresh = onStart)
                    Spacer(Modifier.height(24.dp))
                }
                Spacer(Modifier.height(40.dp))
                Text(
                    text = strings.introStep1Title,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Medium,
                )
                Spacer(Modifier.height(28.dp))
                Text(
                    text = strings.introStep1DescriptionP1,
                    fontSize = 16.sp,
                    lineHeight = 24.sp,
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    text = strings.introStep1DescriptionP2,
                    fontSize = 16.sp,
                    lineHeight = 24.sp,
                )
            }
            WarningBanner(
                strings = strings,
                modifier = Modifier.padding(horizontal = 24.dp),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 24.dp, top = 8.dp, end = 24.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onCancel) { Text(strings.cancelButton) }
                if (!hasDraft) {
                    Spacer(Modifier.width(12.dp))
                    Button(
                        onClick = onStart,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                    ) { Text(startActionLabel) }
                }
            }
        }
    }
    if (showHelp) {
        HelpDialog(
            slides = strings.helpSlides.intro,
            strings = strings,
            onClose = { showHelp = false },
        )
    }
}

@Composable
private fun WarningBanner(strings: Strings, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = strings.warningBanner,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun ResumeBanner(
    strings: Strings,
    onResume: () -> Unit,
    onStartFresh: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.elevatedCardElevation(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                strings.resumeBanner,
                style = MaterialTheme.typography.bodyLarge,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = onResume,
                    modifier = Modifier.weight(1f),
                ) { Text(strings.resumeButton) }
                TextButton(
                    onClick = onStartFresh,
                    modifier = Modifier.weight(1f),
                ) { Text(strings.startFreshButton) }
            }
        }
    }
}

/**
 * Decides which step a resumed session lands on, given the
 * persisted card states (spec §5 + §7.1). If every known tissue
 * type's state is `Drawn` or `Absent`, the dashboard is the
 * appropriate landing — the user has finished drawing and is
 * either about to validate or back from a partial review.
 * Otherwise the wound drawing screen is the safe landing: the
 * dashboard would be incomplete (some types still `Open`) and
 * sending the user there would imply premature progress.
 *
 * Empty / partial [cardStates] maps fall back to `Step.Wound`.
 *
 * Pure helper — testable without a Compose harness. M13's
 * resume path calls it with the snapshot's `cardStates`.
 */
internal fun inferResumeStep(cardStates: Map<TissueType, TissueCardState>): Step {
    if (cardStates.isEmpty()) return Step.Wound
    val knownStates = TissueType.knownValues.map { cardStates[it] }
    if (knownStates.any { it == null }) return Step.Wound
    val allResolved = knownStates.all {
        it == TissueCardState.Drawn || it == TissueCardState.Absent
    }
    return if (allResolved) Step.Dashboard else Step.Wound
}
