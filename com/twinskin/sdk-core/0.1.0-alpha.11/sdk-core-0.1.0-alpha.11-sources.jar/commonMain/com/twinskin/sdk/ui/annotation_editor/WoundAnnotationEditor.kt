@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class, kotlinx.coroutines.FlowPreview::class)

package com.twinskin.sdk.ui.annotation_editor

import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.WoundAnnotation
import com.twinskin.sdk.ui.annotation_editor.delineation.DelineationStore
import com.twinskin.sdk.ui.annotation_editor.delineation.Step
import com.twinskin.sdk.ui.annotation_editor.delineation.boundary.toWoundAnnotation
import com.twinskin.sdk.ui.annotation_editor.delineation.dashboard.percentagesByType
import com.twinskin.sdk.ui.annotation_editor.delineation.draft.DraftStore
import com.twinskin.sdk.ui.annotation_editor.delineation.draft.EditorPreferences
import com.twinskin.sdk.ui.annotation_editor.delineation.draft.SettingsBackedEditorPreferences
import com.twinskin.sdk.ui.annotation_editor.delineation.draft.contentHash
import com.twinskin.sdk.ui.annotation_editor.delineation.draft.provideDraftSettings
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.ErrorScreen
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.IntroScreen
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.TissueCardAction
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.TissueDashboardScreen
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.TissueDrawingScreen
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.WoundDrawingScreen
import com.twinskin.sdk.ui.annotation_editor.delineation.flow.inferResumeStep
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.resolveLocale
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.stringsFor
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState
import com.twinskin.sdk.ui.annotation_editor.delineation.orientation.LockOrientationDuringSession
import com.twinskin.sdk.ui.annotation_editor.delineation.stepSaver
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.launch

/**
 * Public entry point for the wound delineation editor (spec §5–§9).
 *
 * Owns the full four-screen flow (Intro → Wound contour →
 * Tissue dashboard → per-type Tissue drawing → submit) internally;
 * the integrator's only contract is to provide the image and a
 * suspending `onDone` callback that receives the validated
 * [WoundAnnotation] wire payload (decision S).
 *
 * **Lifecycle.**
 *  - Configuration changes preserve the current [Step] via
 *    `rememberSaveable(stateSaver = stepSaver)` and the canvas
 *    content via each screen's
 *    `rememberSaveable(saver = EditorControllerSaver)`. Undo stacks
 *    are intentionally not persisted — the disk-backed draft is the
 *    real safety net for process death.
 *  - Process death + warm reopen flow through [DraftStore]:
 *    auto-saved every 500 ms while editing, surfaced on the Intro
 *    screen's "Resume previous session?" banner.
 *  - Orientation is locked to whatever the device started in for the
 *    session's duration (spec §13.5).
 *  - Uncaught exceptions from gesture loops, the auto-save coroutine,
 *    or the suspending `onDone` flush the draft and surface
 *    [ErrorScreen] (spec C1).
 *
 * @param image    The source image. Must have positive dimensions
 *                 (spec C2). Re-keying [image] resets the editor's
 *                 internal state (the image-hash-based draft slot
 *                 changes too — the new image's draft, if any, is
 *                 offered on the Intro screen).
 * @param onDone   Invoked when the clinician validates the
 *                 annotation. Suspending per decision S so the
 *                 editor can drive the submission UI (in-flight
 *                 spinner, retry snackbar on failure) before the
 *                 caller's coroutine returns. On success the
 *                 draft is cleared automatically.
 * @param onCancel Invoked when the clinician abandons the session
 *                 (back from Intro / abandon-confirmed from
 *                 WoundDrawingScreen) OR when the [ErrorScreen]'s
 *                 dismiss button is tapped. The draft survives a
 *                 cancel — the user can reopen the editor on the
 *                 same image and resume.
 * @param initial  Optional pre-seeded [WoundAnnotation] (re-edit
 *                 flow). Defaults to an empty annotation.
 */
@TwinSkinInternalApi
@Composable
public fun WoundAnnotationEditor(
    image: ImageBitmap,
    onDone: suspend (WoundAnnotation) -> Unit,
    onCancel: () -> Unit,
    initial: WoundAnnotation = WoundAnnotation(regions = emptyList()),
) {
    require(image.width > 0 && image.height > 0) {
        "image must have positive dimensions (got ${image.width} × ${image.height})"
    }

    LockOrientationDuringSession()

    val strings = remember { stringsFor(resolveLocale()) }
    val imageSize = remember(image) { Size(image.width.toFloat(), image.height.toFloat()) }
    val minTissueArea = remember(imageSize) {
        // Decision N — sliver floor that scales with image size so a
        // 10 MP photo doesn't accept the same fixed-area pieces as a
        // 1 MP one.
        maxOf(24f, imageSize.width * imageSize.height * 5e-5f)
    }
    // Fresh vs edit-existing mode detection. Computed early so it
    // can gate the draft-persistence effects below.
    val isEditExisting = initial.regions.isNotEmpty()

    // The draft store + editor preferences share one Settings
    // instance: drafts and the reshape-advisory flag live under the
    // SDK's dedicated `twinskin_delineation_drafts` namespace
    // (see provideDraftSettings KDoc).
    val settings = remember { provideDraftSettings() }
    val draftStore = remember(settings) { DraftStore(settings) }
    val editorPreferences: EditorPreferences =
        remember(settings) { SettingsBackedEditorPreferences(settings) }
    val imageHash = remember(image) { image.contentHash() }
    val existingDraft = remember(imageHash, isEditExisting) {
        // Fresh mode never reads drafts — no Resume banner can
        // appear in that flow.
        if (isEditExisting) draftStore.load(imageHash) else null
    }
    val store = remember(initial, imageSize) {
        DelineationStore.fromInitial(initial, imageSize)
    }
    val logger: SdkLogger? = remember {
        runCatching { TwinSkinSdk.requireComponent().logger }.getOrNull()
    }

    var fatalError by remember { mutableStateOf<Throwable?>(null) }
    var step: Step by rememberSaveable(stateSaver = stepSaver) {
        mutableStateOf<Step>(Step.Intro)
    }

    val exceptionHandler: CoroutineExceptionHandler =
        remember(draftStore, imageHash, isEditExisting) {
            CoroutineExceptionHandler { _, t ->
                if (isEditExisting) {
                    runCatching { draftStore.save(imageHash, store.snapshot(), step) }
                }
                fatalError = t
            }
        }
    val scope = rememberCoroutineScope { exceptionHandler }

    var submitting by remember { mutableStateOf(false) }
    val dashboardSnackbar = remember { SnackbarHostState() }

    // Draft persistence is edit-existing-only. Fresh sessions never
    // write a draft to disk; re-entering fresh mode never surfaces a
    // Resume banner. The else-branch below wipes any stale draft a
    // prior edit-existing session left for the same image.
    if (isEditExisting) {
        // Auto-save on store mutation, debounced 500 ms so a per-move
        // stroke storm doesn't hammer the disk.
        LaunchedEffect(store) {
            snapshotFlow { store.revision.value }
                .debounce(500)
                .collect { draftStore.save(imageHash, store.snapshot(), step) }
        }
        // Auto-save on step change (no debounce — navigation is rare
        // and user-initiated). Without this, a user who navigates
        // Intro → Wound, then closes the app before drawing anything,
        // returns to Intro on next launch instead of Wound.
        LaunchedEffect(Unit) {
            snapshotFlow { step }
                .collect { current -> draftStore.save(imageHash, store.snapshot(), current) }
        }
        // Flush on dispose — closes the 500 ms debounce window if the
        // user backgrounds the app mid-debounce (spec C1).
        DisposableEffect(Unit) {
            onDispose {
                runCatching { draftStore.save(imageHash, store.snapshot(), step) }
            }
        }
    } else {
        // Fresh-mode entry wipes any stale draft a prior
        // edit-existing session left for the same image.
        LaunchedEffect(imageHash) {
            draftStore.clear(imageHash)
        }
    }

    val percentages by remember(store) {
        derivedStateOf { percentagesByType(store.wounds) }
    }

    val error = fatalError
    if (error != null) {
        ErrorScreen(error = error, strings = strings, onDismiss = onCancel)
        return
    }

    // Fresh vs edit-existing CTA label.
    val introStartLabel =
        if (isEditExisting) strings.startDrawingButton else strings.continueButton

    when (val current = step) {
        Step.Intro -> IntroScreen(
            // existingDraft is already null in fresh mode (the
            // remember above gates the disk read on isEditExisting),
            // but the explicit && keeps the IntroScreen contract
            // self-documenting: the Resume banner only appears in
            // edit-existing mode.
            hasDraft = isEditExisting && existingDraft != null,
            strings = strings,
            startActionLabel = introStartLabel,
            onResume = {
                existingDraft?.let { draft ->
                    store.restore(draft.snapshot)
                    step = inferResumeStep(store.cardStates)
                }
            },
            onStart = {
                draftStore.clear(imageHash)
                step = Step.Wound
            },
            onCancel = onCancel,
        )
        Step.Wound -> WoundDrawingScreen(
            image = image,
            imageSize = imageSize,
            store = store,
            minTissueArea = minTissueArea,
            strings = strings,
            editorPreferences = editorPreferences,
            onBack = onCancel,
            onNext = { step = Step.Dashboard },
        )
        Step.Dashboard -> TissueDashboardScreen(
            cardStates = store.cardStates,
            percentages = percentages,
            isSubmitting = submitting,
            snackbarHostState = dashboardSnackbar,
            strings = strings,
            onBack = { step = Step.Wound },
            onValidate = {
                scope.launch {
                    while (true) {
                        submitting = true
                        val result = runCatching {
                            onDone(toWoundAnnotation(store.wounds, imageSize, logger))
                        }
                        submitting = false
                        if (result.isSuccess) {
                            draftStore.clear(imageHash)
                            return@launch
                        }
                        logger?.log("Delineation save failed", result.exceptionOrNull())
                        val outcome = dashboardSnackbar.showSnackbar(
                            message = strings.saveFailedSnackbar,
                            actionLabel = strings.retryAction,
                            duration = SnackbarDuration.Indefinite,
                        )
                        if (outcome != SnackbarResult.ActionPerformed) return@launch
                    }
                }
            },
            onCardAction = { type, action ->
                when (action) {
                    TissueCardAction.Add, TissueCardAction.Edit ->
                        step = Step.TissueDrawing(type)
                    TissueCardAction.MarkAbsent ->
                        store.setCardState(type, TissueCardState.Absent)
                    TissueCardAction.MarkPresent -> {
                        store.setCardState(type, TissueCardState.Open)
                        step = Step.TissueDrawing(type)
                    }
                }
            },
        )
        is Step.TissueDrawing -> TissueDrawingScreen(
            image = image,
            imageSize = imageSize,
            store = store,
            currentType = current.type,
            strings = strings,
            onBack = { step = Step.Dashboard },
        )
    }
}
