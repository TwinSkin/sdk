@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.capture.SdkMeasurement
import com.twinskin.sdk.ui.annotation_editor.loadImageFromPath
import com.twinskin.sdk.view.Image2DAsset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Host for [Capture2DView] that knows how to turn an [Image2DAsset]
 * (path on disk) into the [ImageBitmap] the stateless view needs.
 *
 * Decoding happens off the main thread; while it's in flight, the
 * underlying [Capture2DView] shows its built-in loading indicator.
 * If the path changes between recompositions (the resolver may
 * download a fresh image as PowerSync ticks), the bitmap is
 * re-decoded from the new path.
 *
 * When [onEditContour] is non-null, an "Edit contour" FAB is overlaid
 * in the bottom-right once the bitmap has loaded — its filled tonal
 * background reads against the underlying photo, where a transparent
 * outlined button on top of skin tones disappears.
 */
@TwinSkinInternalApi
@Composable
public fun ViewCapture2DPane(
    image2D: Image2DAsset?,
    annotation: SdkAnnotation?,
    measurement: SdkMeasurement?,
    modifier: Modifier = Modifier,
    onEditContour: (() -> Unit)? = null,
    isSavingAnnotation: Boolean = false,
) {
    val location = image2D?.location
    var bitmap by remember(location) { mutableStateOf<ImageBitmap?>(null) }
    var loadError by remember(location) { mutableStateOf<String?>(null) }

    LaunchedEffect(location) {
        if (location == null) {
            bitmap = null
            loadError = null
            return@LaunchedEffect
        }
        try {
            bitmap = withContext(Dispatchers.Default) { loadImageFromPath(location) }
            loadError = null
        } catch (t: Throwable) {
            TwinSkinSdk.requireComponent().logger.log("Failed to load 2D image at $location", t)
            bitmap = null
            loadError = "Couldn't load the image."
        }
    }

    val err = loadError
    if (err != null) {
        Box(
            modifier = modifier.fillMaxSize().background(Color.Black).padding(16.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(err, color = MaterialTheme.colorScheme.error)
        }
        return
    }
    Box(modifier = modifier.fillMaxSize()) {
        Capture2DView(
            image = bitmap,
            annotation = annotation,
            measurement = measurement,
            modifier = Modifier.fillMaxSize(),
        )
        if (onEditContour != null && bitmap != null) {
            ExtendedFloatingActionButton(
                onClick = onEditContour,
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 4.dp),
                icon = { Icon(Icons.Default.Edit, contentDescription = null) },
                text = { Text("Edit contour") },
            )
        }
        if (isSavingAnnotation) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp),
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.secondaryContainer,
                shadowElevation = 2.dp,
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        strokeWidth = 2.dp,
                    )
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = "Saving annotation…",
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                    )
                }
            }
        }
    }
}
