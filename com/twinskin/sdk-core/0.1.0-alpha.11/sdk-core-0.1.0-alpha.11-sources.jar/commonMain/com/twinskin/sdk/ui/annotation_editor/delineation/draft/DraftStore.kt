package com.twinskin.sdk.ui.annotation_editor.delineation.draft

import com.russhwolf.settings.Settings
import com.russhwolf.settings.set
import com.twinskin.sdk.ui.annotation_editor.delineation.Step
import com.twinskin.sdk.ui.annotation_editor.delineation.StoreSnapshot

/**
 * Disk-backed slot for the in-progress delineation, keyed by an
 * [ImageBitmap] content hash so the same image always opens the same
 * draft. One slot per image; saving overwrites; clearing removes.
 *
 * Backing store is provided via [provideDraftSettings] (per-platform
 * `SharedPreferences` / `NSUserDefaults` / in-memory for tests). The
 * store itself is platform-agnostic — it speaks the [Settings]
 * interface only.
 *
 * Save is *not* internally debounced — the caller (M13's root
 * composable) wraps mutations in a 500 ms `LaunchedEffect` debouncer
 * so the per-stroke storm doesn't hammer the file system.
 */
internal class DraftStore(private val settings: Settings) {

    /** Returns the saved draft for [imageHash], or null when nothing is stored. */
    fun load(imageHash: String): DraftCodec.Decoded? {
        val raw = settings.getStringOrNull(keyFor(imageHash)) ?: return null
        return DraftCodec.decode(raw)
    }

    /** Persists [snapshot] + [currentStep] under [imageHash], overwriting any prior draft. */
    fun save(imageHash: String, snapshot: StoreSnapshot, currentStep: Step) {
        settings[keyFor(imageHash)] = DraftCodec.encode(snapshot, currentStep)
    }

    /** Removes the draft for [imageHash]. Idempotent — clearing an empty slot is a no-op. */
    fun clear(imageHash: String) {
        settings.remove(keyFor(imageHash))
    }

    private fun keyFor(imageHash: String): String = "$KEY_PREFIX:$imageHash"

    private companion object {
        // Namespaced inside the [Settings] backing store so non-draft
        // keys (if anything else ever shares this Settings instance)
        // don't collide.
        const val KEY_PREFIX = "draft.v1"
    }
}
