package com.twinskin.sdk.ui.annotation_editor.delineation.i18n

import com.twinskin.sdk.ui.annotation_editor.delineation.help.CloseByProximityDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.OneTypeAtATimeDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.OtherTypeReadOnlyDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.ReshapeParentWoundDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.ReshapeWoundDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.ResumeOpenStrokeDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.TissueInsideWoundDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.TraceWoundDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType

/**
 * English (en) implementation of [Strings] — the v1 ship locale.
 * FR / NL / DE land as separate object implementations in v1.1
 * when localised content is delivered.
 *
 * Plural strings use the parenthetical-(s) form ("N tissue
 * region(s) updated") — acceptable for EN but doesn't generalise.
 * v1.1 will introduce a real plural helper alongside the
 * non-EN locales.
 *
 * **M12 placeholder.** [helpSlides] ships one placeholder slide
 * per screen pointing future readers at M12. The help dialog in
 * `IntroScreen` (and the four per-screen help dialogs M12 will
 * add) reads from this structure so the M12 content drop is a
 * pure-text PR with no consumer-side changes.
 */
internal object EnStrings : Strings {

    // ── Intro screen ─────────────────────────────────────────────
    override val introTitle: String = "Wound delineation"
    override val introStep1Title: String = "Step 1 of 2 — Draw the contour"
    override val introStep1DescriptionP1: String =
        "Trace the outer boundary of the area as accurately as possible."
    override val introStep1DescriptionP2: String =
        "Follow the visible edges and avoid including surrounding skin."
    override val startDrawingButton: String = "Start drawing"
    override val continueButton: String = "Continue"
    override val warningBanner: String =
        "Your work is only saved at final validation. Avoid leaving the app before then."
    override val resumeBanner: String =
        "A previous session was interrupted. Resume where you left off?"
    override val resumeButton: String = "Resume"
    override val startFreshButton: String = "Start fresh"
    override val startButton: String = "Start"
    override val helpDialogTitle: String = "Help"
    override val helpDialogPlaceholderBody: String = "Help content — to be written in M12."
    override val closeButton: String = "Close"

    // ── Common chrome ────────────────────────────────────────────
    override val helpContentDescription: String = "Help"
    override val backContentDescription: String = "Back"
    override val backButton: String = "Back"
    override val cancelButton: String = "Cancel"

    // ── Tissue dashboard ─────────────────────────────────────────
    override val dashboardTitle: String = "Tissue composition"
    override val dashboardStep2Title: String = "Step 2 of 2 — Select and draw tissues"
    override val validateButton: String = "Validate"
    override val validateDialogTitle: String = "Validate the delineation?"
    override val validateDialogBody: String =
        "You will no longer be able to modify contours and tissues after validation."
    override val saving: String = "Saving…"
    override val untypedFooter: (remainder: Int) -> String = { remainder -> "Untyped: $remainder %" }

    // ── Wound drawing ────────────────────────────────────────────
    override val woundTitle: String = "Wound contour"
    override val undoButton: String = "Undo"
    override val deleteButton: String = "Delete"
    override val nextButton: String = "Next"
    override val tooFarFromOpenStroke: String =
        "Too far from the current open stroke. delete it or resume closer."
    override val reshapeAdvisoryTitle: String = "Reshaping wounds with tissues"
    override val reshapeAdvisoryBody: String =
        "When you reshape a wound that contains tissues, the tissues are automatically " +
            "adjusted to fit the new wound boundary. Tissues that fall entirely outside the " +
            "new boundary will be removed."
    override val dontShowAgainCheckbox: String = "Don't show this again"
    override val okButton: String = "OK"
    override val deleteDialogTitle: String = "Delete this wound?"
    override val deleteDialogBody: (tissueCount: Int) -> String = { count ->
        "It contains $count tissue region(s). Deleting the wound removes its tissues as well."
    }
    override val abandonDialogTitle: String = "Leave the editor?"
    override val abandonDialogBody: String =
        "Your work is only saved at final validation. Leaving now discards every wound and " +
            "tissue you've drawn so far."
    override val leaveButton: String = "Leave"
    override val stayButton: String = "Stay"
    override val tissuesAdjustedSnack: (updated: Int, removed: Int) -> String = { updated, removed ->
        "$updated tissue region(s) updated, $removed removed."
    }

    // ── Tissue drawing ───────────────────────────────────────────
    override val tissueDrawingTitle: (typeName: String) -> String = { name -> "$name tissue" }
    override val doneButton: String = "Done"

    // ── Root (validate retry) ────────────────────────────────────
    override val saveFailedSnackbar: String = "Save failed."
    override val retryAction: String = "Retry"

    // ── Error screen ─────────────────────────────────────────────
    override val errorScreenTitle: String = "Something went wrong"
    override val errorScreenBody: String =
        "Your work has been saved as a draft. Reopen the editor to continue where you left off."
    override val dismissButton: String = "Dismiss"

    // ── A11y ─────────────────────────────────────────────────────
    override val woundCanvasContentDescription: String =
        "Wound drawing canvas. Two fingers to zoom and pan."
    override val tissueCanvasContentDescription: String =
        "Tissue drawing canvas. Two fingers to zoom and pan."
    override val magnifierContentDescription: String =
        "Magnifier showing a 2x zoom of the area around your finger."
    override val helpPreviousSlide: String = "Previous slide"
    override val helpNextSlide: String = "Next slide"

    // ── Tissue card buttons ──────────────────────────────────────
    override val tissueCardAddTissue: String = "Draw area"
    override val tissueCardEdit: String = "Edit"
    override val tissueCardMarkAbsent: String = "Not present"

    // ── Tissue type names ────────────────────────────────────────
    override val tissueTypeNames: Map<TissueType, String> = mapOf(
        TissueType.Necrosis to "Necrosis",
        TissueType.Slough to "Slough",
        TissueType.Granulation to "Granulation",
    )

    // ── Help slides ──────────────────────────────────────────────
    //
    // Layout: Intro × 2 (text-only), WoundDrawing × 4 (gesture
    // diagrams), Dashboard × 2 (text-only), TissueDrawing × 4
    // (gesture diagrams). Diagrams reuse the canvas painters so
    // help rendering matches the drawing surface.
    override val helpSlides: HelpSlideStrings = HelpSlideStrings(
        intro = listOf(
            HelpSlide(
                title = "What this editor does",
                body = "Trace the wound's outline, then label each tissue type you " +
                    "see inside it. The result is a structured annotation the server " +
                    "uses to compute area, perimeter, and tissue composition.",
            ),
            HelpSlide(
                title = "Your work is saved at validation",
                body = "Drafts are kept locally so you can pause and resume on the same " +
                    "image. Final saving happens only when you tap Validate on the " +
                    "tissue composition screen. Leaving before validation discards " +
                    "everything you've drawn.",
            ),
        ),
        woundDrawing = listOf(
            HelpSlide(
                title = "Trace the wound's edge",
                body = "Drag your finger along the wound's outline. The contour appears " +
                    "as a dashed green line while you draw.",
                diagram = { TraceWoundDiagram() },
            ),
            HelpSlide(
                title = "Close by returning to the start",
                body = "Lift your finger near the point where you started — a green halo " +
                    "appears as you approach. The wound is then sealed and shown in " +
                    "orange.",
                diagram = { CloseByProximityDiagram() },
            ),
            HelpSlide(
                title = "Resume an unfinished stroke",
                body = "If you lift your finger before closing, the stroke stays " +
                    "in progress. Touch within 50 pixels of the last point to keep " +
                    "going. Touch further away and a snackbar reminds you to start " +
                    "closer.",
                diagram = { ResumeOpenStrokeDiagram() },
            ),
            HelpSlide(
                title = "Reshape an existing wound",
                body = "Tap a sealed wound to focus it, then drag near its contour to " +
                    "deform it. Vertices nearest your finger move the most; vertices " +
                    "outside the 40-pixel radius stay put. If the wound already has " +
                    "tissues, the editor asks before applying changes.",
                diagram = { ReshapeWoundDiagram() },
            ),
        ),
        tissueDashboard = listOf(
            HelpSlide(
                title = "Three tissue types per wound",
                body = "Necrosis, slough, and granulation. Each card shows whether " +
                    "you've drawn that type, marked it absent, or haven't decided yet. " +
                    "Validate is enabled once every type has a state.",
            ),
            HelpSlide(
                title = "Percentages and the untyped remainder",
                body = "The percentage on each Drawn card is the share of the wound " +
                    "occupied by that tissue type. When the typed types don't add up " +
                    "to 100 %, the leftover area is labelled Untyped — that's wound " +
                    "surface you haven't classified yet.",
            ),
        ),
        tissueDrawing = listOf(
            HelpSlide(
                title = "Tissues live inside a wound",
                body = "Every tissue you draw must lie inside one of the wounds you " +
                    "traced earlier. The wound's outline is shown as a dashed " +
                    "dark-gray line on this screen.",
                diagram = { TissueInsideWoundDiagram() },
            ),
            HelpSlide(
                title = "One tissue type at a time",
                body = "You're drawing only the current type on this screen. Other " +
                    "tissue types are visible in their clinical colour but are " +
                    "read-only — go back to the dashboard to edit them.",
                diagram = { OneTypeAtATimeDiagram() },
            ),
            HelpSlide(
                title = "The parent wound contains your stroke",
                body = "If your finger drifts past the wound's edge while drawing or " +
                    "reshaping, the contour slides along the boundary instead of " +
                    "crossing it. A red dot briefly marks the contact point.",
                diagram = { ReshapeParentWoundDiagram() },
            ),
            HelpSlide(
                title = "Other-type tissues aren't editable here",
                body = "Tissues of types other than the current one render with a " +
                    "muted outline and ignore touch input. Switch types from the " +
                    "dashboard if you need to change them.",
                diagram = { OtherTypeReadOnlyDiagram() },
            ),
        ),
    )
}
