package com.twinskin.sdk.ui.annotation_editor.delineation.engine

import androidx.compose.ui.geometry.Offset
import com.twinskin.sdk.geometry.distanceToPolyline
import com.twinskin.sdk.geometry.pointInPolygon

/**
 * Pure routing function — turns a single touch-down into a
 * [GestureKind] decision per the spec §10.2 priority tree.
 * Stateless; reads the controller's exposed state but never mutates.
 *
 * Priority order, top wins:
 *   1. `activeGesture != null` → [GestureKind.None] (single-action
 *      invariant P3; M8's gesture loop should suppress redundant
 *      downs anyway).
 *   2. open stroke in flight:
 *        a. touch within [OpenStroke.RESUME_ZONE_CANVAS_PX] of the
 *           last sample → [GestureKind.Resume] (the controller will
 *           append future moves to the same OpenStroke).
 *        b. otherwise → [GestureKind.None] + the controller emits
 *           a `TooFarFromOpenStroke` signal.
 *   3. focused polygon AND touch within 15 canvas-px of its contour
 *      → [GestureKind.Reshape].
 *   4. touch inside any editable polygon → [GestureKind.Tap]
 *      (resolved on touch-up).
 *   5. touch outside every editable polygon — eligibility for a new
 *      stroke:
 *        - on screen 4 (`ctx.containmentPolygons != null`), the
 *          touch must be inside at least one containment wound;
 *          otherwise → [GestureKind.None] (silent no-op per spec
 *          §8.3).
 *        - on screen 2 (no containment) → [GestureKind.Stroke].
 *
 * Closure (spec §6.2.5) is **not** a routing decision — it fires on
 * touch-up. While the open stroke exists and the finger sits in the
 * closure zone, the router still returns [GestureKind.Resume]; the
 * controller decides at touch-up whether to seal the polygon.
 */
internal object GestureRouter {

    /**
     * Canvas-pixel tolerance for "near the focused polygon's
     * contour" (spec §6.3.3). Sized to a typical finger-contact
     * patch — same touch-target band as the closure zone.
     */
    const val RESHAPE_GRAB_CANVAS_PX: Float = 25f

    fun route(
        touchDownCanvas: Offset,
        state: EditorController,
        ctx: GestureCtx,
    ): GestureKind {
        // 1. Single-action invariant.
        if (state.activeGesture != null) return GestureKind.None

        val touchDownImage = ctx.canvasToImage(touchDownCanvas)

        // 2. Open stroke gating.
        val openStroke = state.openStroke
        if (openStroke != null) {
            val lastCanvas = ctx.imageToCanvas(openStroke.lastSampleImagePx)
            return if (openStroke.isWithinResumeZone(touchDownCanvas, lastCanvas)) {
                GestureKind.Resume
            } else {
                GestureKind.None
            }
        }

        // 3. Reshape near focused contour.
        val focusedIdx = state.focusedIndex
        if (focusedIdx != null) {
            val focused = state.polygons[focusedIdx]
            val canvasDist = distanceToPolyline(touchDownImage, focused) * ctx.canvasFromImageScale
            if (canvasDist <= RESHAPE_GRAB_CANVAS_PX) {
                return GestureKind.Reshape(focusedIdx)
            }
        }

        // 4. Tap on any editable polygon.
        for (poly in state.polygons) {
            if (pointInPolygon(touchDownImage, poly)) return GestureKind.Tap
        }

        // 4.5. Touch-down inside a forbidden polygon is rejected as
        // silent no-op (spec §8.4). The controller's per-move clamp
        // can't move the seed point retroactively, so without this
        // gate a stroke would visibly start inside forbidden geometry.
        if (ctx.forbiddenInteriors.any { pointInPolygon(touchDownImage, it) }) {
            return GestureKind.None
        }

        // 5. New-stroke eligibility.
        val containment = ctx.containmentPolygons
        return if (containment != null) {
            if (containment.any { pointInPolygon(touchDownImage, it) }) GestureKind.Stroke
            else GestureKind.None
        } else {
            GestureKind.Stroke
        }
    }
}
