package com.twinskin.sdk.ui.annotation_editor.delineation.canvas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

/**
 * Top-anchored magnifier strip (spec §6.9.1) — 80 dp tall, full
 * canvas width, 2× crop centred on the current finger position.
 * Falls back to the image centre when no finger has touched yet.
 *
 * **Crosshair-at-centre contract.** The red crosshair always sits
 * at the strip centre. The image is translated (not clamped via a
 * src-rect) so the finger's image-pixel position lands at the
 * strip centre even when the finger is at or past an image edge —
 * pixels beyond the image bounds show [MagnifierVoidColor].
 *
 * **Overlay rendering.** Polygons, open stroke, closure halo, etc.
 * are re-rendered at effective magnification with the painter stack
 * shared with the main canvas. Stroke widths are absolute
 * canvas-pixel values, so the magnified overlay matches the main
 * canvas physically.
 *
 * **Clipping.** Compose Canvas doesn't clip to its bounds by
 * default; without [Modifier.clipToBounds] on the outer Box,
 * overlay vertices outside the source rect would draw into the
 * parent Box and overlap the main canvas.
 *
 * **Zoom tracking.** Effective magnification is
 * `BASE_MAGNIFICATION × canvasZoomScale` — pinching the canvas
 * scales the strip too, so it always shows pixels at strictly
 * higher magnification than the canvas.
 *
 * Pure presentation: owns no state. The host (DrawingCanvas) passes
 * the latest finger position and overlay state in image-pixel
 * coordinates; the image and every overlay use the same
 * `imageToStrip` transform.
 */
@Composable
internal fun MagnifierBar(
    image: ImageBitmap,
    imageSize: Size,
    fingerImagePx: Offset?,
    contentDescription: String,
    modifier: Modifier = Modifier,
    overlay: MagnifierOverlay = MagnifierOverlay.Empty,
    canvasZoomScale: Float = 1f,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(80.dp)
            .clipToBounds()
            .background(MagnifierVoidColor)
            .semantics {
                this.contentDescription = contentDescription
            },
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(80.dp)) {
            val stripSize = Size(size.width, size.height)
            // Fall back to the image centre when no finger has
            // touched — gives the strip a stable preview rather
            // than a void-filled strip on first paint.
            val finger = fingerImagePx ?: Offset(imageSize.width * 0.5f, imageSize.height * 0.5f)
            val effectiveMagnification = BASE_MAGNIFICATION * canvasZoomScale

            // Anchor the image so finger.x/finger.y lands at strip
            // centre. Image origin can be negative or far past the
            // strip width — the outer Box's clipToBounds() handles
            // overdraw, the void background fills wherever the
            // image doesn't reach.
            val imageOriginX = stripSize.width * 0.5f - finger.x * effectiveMagnification
            val imageOriginY = stripSize.height * 0.5f - finger.y * effectiveMagnification

            drawImage(
                image = image,
                dstOffset = IntOffset(imageOriginX.toInt(), imageOriginY.toInt()),
                dstSize = IntSize(
                    (imageSize.width * effectiveMagnification).toInt().coerceAtLeast(1),
                    (imageSize.height * effectiveMagnification).toInt().coerceAtLeast(1),
                ),
            )

            fun toStrip(p: Offset): Offset =
                imageToStrip(p, finger, stripSize, effectiveMagnification)

            for (dashed in overlay.dashedWoundsImagePx) {
                drawDashedWound(dashed.map(::toStrip))
            }
            for (poly in overlay.polygonsImagePx) {
                drawClosedPolygon(
                    canvasPoly = poly.outline.map(::toStrip),
                    color = poly.color,
                    focused = poly.focused,
                )
            }
            overlay.openStrokeImagePx?.let { stroke ->
                drawOpenStroke(stroke.map(::toStrip), color = overlay.openStrokeColor)
            }
            overlay.firstPointHaloImagePx?.let { firstPt ->
                drawFirstPointHalo(toStrip(firstPt), color = overlay.openStrokeColor)
            }
            overlay.nonTraversalCueImagePx?.let { (cuePos, alpha) ->
                drawNonTraversalCue(toStrip(cuePos), alpha = alpha)
            }

            // Crosshair at strip centre — always under the finger
            // by construction. Drawn last so it sits above the
            // overlay strokes.
            val centre = Offset(stripSize.width * 0.5f, stripSize.height * 0.5f)
            drawCircle(
                color = NonTraversalCueColor,
                radius = 3.dp.toPx(),
                center = centre,
                style = Stroke(width = 0.5.dp.toPx()),
            )
        }
    }
}

/**
 * Image-pixel state the magnifier re-renders inside its viewport.
 * Polygon outlines are in image-px so the magnifier can apply its
 * own image-to-strip transform per-vertex (the main canvas's
 * image-to-canvas transform is different and would be wrong here).
 */
internal data class MagnifierOverlay(
    val polygonsImagePx: List<MagnifierPolygon>,
    val openStrokeImagePx: List<Offset>?,
    /** Colour for the open stroke + closure halo. */
    val openStrokeColor: Color = OpenStrokeColor,
    val firstPointHaloImagePx: Offset?,
    val dashedWoundsImagePx: List<List<Offset>>,
    val nonTraversalCueImagePx: Pair<Offset, Float>?,
) {
    companion object {
        val Empty: MagnifierOverlay = MagnifierOverlay(
            polygonsImagePx = emptyList(),
            openStrokeImagePx = null,
            openStrokeColor = OpenStrokeColor,
            firstPointHaloImagePx = null,
            dashedWoundsImagePx = emptyList(),
            nonTraversalCueImagePx = null,
        )
    }
}

internal data class MagnifierPolygon(
    val outline: List<Offset>,
    val color: Color,
    val focused: Boolean,
)

/**
 * Pure transform from image-pixel space to magnifier-strip-px.
 * The finger's image-pixel position [fingerImagePx] always lands at
 * the strip centre; image points further from the finger land
 * further from the centre, scaled by [magnification]:
 *
 *   strip(p) = (p - finger) × magnification + stripCentre
 *
 * Points far enough from the finger to project outside [stripSize]
 * are returned as out-of-strip coordinates — the caller's
 * `clipToBounds` handles overdraw. There is no source-rect clamping:
 * the strip is anchored on the finger, not on the image.
 */
internal fun imageToStrip(
    p: Offset,
    fingerImagePx: Offset,
    stripSize: Size,
    magnification: Float,
): Offset = Offset(
    (p.x - fingerImagePx.x) * magnification + stripSize.width * 0.5f,
    (p.y - fingerImagePx.y) * magnification + stripSize.height * 0.5f,
)

/**
 * Magnification at canvas zoom = 1×. Effective magnification when
 * the canvas is pinch-zoomed is `BASE_MAGNIFICATION × zoomScale`
 * — see the [MagnifierBar] KDoc.
 */
private const val BASE_MAGNIFICATION: Float = 2f

/**
 * Fills the strip wherever the translated image doesn't reach
 * (i.e. when the finger is at or past an image edge). Subdued
 * near-black so it doesn't compete with overlay colours.
 */
private val MagnifierVoidColor: Color = Color(0xFF2A2A2A)
