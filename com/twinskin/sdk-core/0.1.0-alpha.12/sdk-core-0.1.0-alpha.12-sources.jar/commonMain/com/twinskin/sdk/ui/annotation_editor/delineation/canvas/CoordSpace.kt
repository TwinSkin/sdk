package com.twinskin.sdk.ui.annotation_editor.delineation.canvas

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import kotlin.math.min

/**
 * Canvas↔image coordinate conversions for the delineation editor.
 *
 * Two transforms compose:
 *   1. A **fit transform** centres the source image inside the canvas
 *      with `BoxFit.scaleDown + Alignment.Center` — the image is
 *      downscaled to fit but never upscaled past native, and any
 *      excess canvas space letterboxes around it.
 *   2. A **zoom/pan transform** — uniform scale ≥ 1 (1 = fully
 *      fitted, 15 = max-zoom per spec §6.8) plus a canvas-pixel
 *      offset for two-finger pan.
 *
 * The two are exposed as a single combined transform tuple
 * (`scale`, `pan`) — the resulting canvas-pixel position of an
 * image-pixel point `p` is:
 *
 * ```
 *  canvasPos = canvasOriginAtFit + (p * fitScale * scale) + pan
 * ```
 *
 * where `canvasOriginAtFit` is the top-left of the fitted-but-not-
 * zoomed image inside the canvas (centring offset).
 *
 * Plan §M7 line 526 originally sketched `zoomPan: Matrix4`. We use
 * `(scale: Float, pan: Offset)` instead — same information for the
 * uniform-scale + translation-only case the editor supports in v1,
 * matches the engine's `GestureCtx` shape, and the lazy Matrix4
 * needed by M8's `Modifier.graphicsLayer` can be built locally in
 * the canvas.
 */

/** Base fit (no zoom) — centres the image inside the canvas with `scaleDown`. */
internal data class FitTransform(
    /** Image-pixel → canvas-pixel uniform scale at zoom = 1. */
    val fitScale: Float,
    /** Canvas-pixel offset of the image's top-left at fit. */
    val origin: Offset,
    /** Canvas-pixel dimensions of the fitted image (`fitScale × imageSize`). */
    val fittedSize: Size,
)

/**
 * Computes the base fit. Image is centred; if it's smaller than the
 * canvas, no upscale happens (`fitScale = 1`) and letterboxing fills
 * the surrounding canvas.
 */
internal fun fitTransform(canvasSize: Size, imageSize: Size): FitTransform {
    require(canvasSize.width > 0f && canvasSize.height > 0f) {
        "canvasSize must be positive (got $canvasSize)"
    }
    require(imageSize.width > 0f && imageSize.height > 0f) {
        "imageSize must be positive (got $imageSize)"
    }
    val scaleToFitX = canvasSize.width / imageSize.width
    val scaleToFitY = canvasSize.height / imageSize.height
    val fitScale = min(min(scaleToFitX, scaleToFitY), 1f)   // scaleDown: never upscale
    val fittedW = imageSize.width * fitScale
    val fittedH = imageSize.height * fitScale
    val originX = (canvasSize.width - fittedW) * 0.5f
    val originY = (canvasSize.height - fittedH) * 0.5f
    return FitTransform(
        fitScale = fitScale,
        origin = Offset(originX, originY),
        fittedSize = Size(fittedW, fittedH),
    )
}

/**
 * Image-pixel point → canvas-pixel point under the combined transform.
 *
 * @param imagePos      point in image-pixel space
 * @param canvasSize    canvas (viewport) size in canvas pixels
 * @param imageSize     source image size in image pixels
 * @param zoomScale     uniform scale from the [ZoomPanController]
 *                      (≥ 1; 1 = fully fitted)
 * @param zoomPan       canvas-pixel offset from the [ZoomPanController]
 */
internal fun imageToCanvas(
    imagePos: Offset,
    canvasSize: Size,
    imageSize: Size,
    zoomScale: Float,
    zoomPan: Offset,
): Offset {
    val fit = fitTransform(canvasSize, imageSize)
    val effectiveScale = fit.fitScale * zoomScale
    val canvasCenter = Offset(canvasSize.width * 0.5f, canvasSize.height * 0.5f)
    // Zoom around the canvas centre so the centred image stays centred
    // at scale 1; pan then adds the user's two-finger translation.
    val centred = Offset(
        canvasCenter.x + (imagePos.x - imageSize.width * 0.5f) * effectiveScale,
        canvasCenter.y + (imagePos.y - imageSize.height * 0.5f) * effectiveScale,
    )
    return centred + zoomPan
}

/** Canvas-pixel point → image-pixel point. Inverse of [imageToCanvas]. */
internal fun canvasToImage(
    canvasPos: Offset,
    canvasSize: Size,
    imageSize: Size,
    zoomScale: Float,
    zoomPan: Offset,
): Offset {
    val fit = fitTransform(canvasSize, imageSize)
    val effectiveScale = fit.fitScale * zoomScale
    val canvasCenter = Offset(canvasSize.width * 0.5f, canvasSize.height * 0.5f)
    val centred = canvasPos - zoomPan
    return Offset(
        imageSize.width * 0.5f + (centred.x - canvasCenter.x) / effectiveScale,
        imageSize.height * 0.5f + (centred.y - canvasCenter.y) / effectiveScale,
    )
}

/**
 * Canvas-pixel distance for a given image-pixel distance under the
 * combined transform. Uniform scale — direction-independent.
 */
internal fun imageToCanvasDistance(
    imagePx: Float,
    canvasSize: Size,
    imageSize: Size,
    zoomScale: Float,
): Float = imagePx * fitTransform(canvasSize, imageSize).fitScale * zoomScale

/** Image-pixel distance for a given canvas-pixel distance. */
internal fun canvasToImageDistance(
    canvasPx: Float,
    canvasSize: Size,
    imageSize: Size,
    zoomScale: Float,
): Float = canvasPx / (fitTransform(canvasSize, imageSize).fitScale * zoomScale)
