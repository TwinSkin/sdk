package com.twinskin.sdk.ui.annotation_editor.delineation.engine

import androidx.compose.ui.geometry.Offset
import com.twinskin.sdk.geometry.nearestPointOnPolyline
import com.twinskin.sdk.geometry.pointInPolygon

/**
 * Non-traversal rule (spec §6.4) — primitives the controller calls
 * to enforce that strokes and reshapes can never cross another
 * polygon (or escape a parent wound on screen 4).
 *
 * The "sliding" behaviour the spec describes (§6.4.1) emerges from
 * per-sample projection: each new finger position that lands inside
 * a forbidden polygon is projected to the closest point on that
 * polygon's boundary; as the finger drifts, the projection slides
 * along the boundary. No explicit sliding state needed.
 */

/**
 * Two-stage clamp for an in-progress stroke sample.
 *
 *   1. If [confinementOutline] is set and [candidate] falls outside,
 *      project to the nearest point on its boundary (the stroke
 *      can't escape its parent wound on screen 4).
 *   2. If the result lands inside any polygon in [forbiddenInteriors],
 *      project to that polygon's nearest boundary point (strokes
 *      hug other polygons rather than crossing them).
 *
 * Iterates up to [maxIterations] times — the second projection can
 * itself land inside a third polygon (overlap-of-overlap edge case).
 * Three iterations are sufficient in practice; the spec doesn't
 * promise convergence in pathological inputs but the medical
 * geometry never produces them.
 */
internal fun clipStrokeSample(
    candidate: Offset,
    forbiddenInteriors: List<List<Offset>>,
    confinementOutline: List<Offset>? = null,
    maxIterations: Int = 3,
): Offset {
    var p = candidate
    repeat(maxIterations) {
        var changed = false

        if (confinementOutline != null && !pointInPolygon(p, confinementOutline)) {
            val (_, projected) = nearestPointOnPolyline(p, confinementOutline)
            if (projected != p) {
                p = projected
                changed = true
            }
        }

        for (forbidden in forbiddenInteriors) {
            if (pointInPolygon(p, forbidden)) {
                val (_, projected) = nearestPointOnPolyline(p, forbidden)
                if (projected != p) {
                    p = projected
                    changed = true
                }
                break  // re-evaluate from the top so confinement check sees the new p
            }
        }

        if (!changed) return p
    }
    return p
}

/**
 * Per-vertex apply of [clipStrokeSample] — used on the polygon
 * after [applyReshape] + [relaxNeighbourhood] to clamp every moved
 * vertex against the same two-stage rule. Returns a new list;
 * does not mutate [deformed].
 */
internal fun clampReshapeAgainstNeighbours(
    deformed: List<Offset>,
    forbiddenInteriors: List<List<Offset>>,
    confinementOutline: List<Offset>? = null,
): List<Offset> = deformed.map { v ->
    clipStrokeSample(v, forbiddenInteriors, confinementOutline)
}
