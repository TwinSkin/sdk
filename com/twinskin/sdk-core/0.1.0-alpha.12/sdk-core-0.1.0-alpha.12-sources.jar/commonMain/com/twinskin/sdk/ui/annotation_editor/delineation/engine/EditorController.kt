package com.twinskin.sdk.ui.annotation_editor.delineation.engine

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import com.twinskin.sdk.geometry.distanceToPolyline
import com.twinskin.sdk.geometry.segmentCrossesAnyForbidden

/**
 * Per-canvas state machine for the wound / tissue editor.
 *
 * Owns its **working** polygon list and the transient gesture state
 * (open stroke, active gesture, undo stack, focus). The cross-screen
 * `DelineationStore` is the canonical source of truth — the screen
 * (M11) wires controller mutations down to the store on commit.
 *
 * **Single-finger contract.** This controller assumes single-finger
 * input. Multi-finger arbitration (zoom/pan vs draw, second-finger
 * ignored during an active gesture per spec §6.7) is M8's gesture-
 * loop responsibility. Calling [onTouchDown] while
 * [activeGesture] is non-null returns immediately — the touch is
 * silently dropped, no signal is emitted (multi-touch suppression
 * is M8's contract; the controller doesn't second-guess it).
 *
 * **Revision counter.** A `mutableStateOf<Int>` that bumps on every
 * mutation. The drawing canvas (M8) observes this and re-paints
 * once per change rather than walking the polygon list during
 * Compose's recomposition-scope inference.
 *
 * **Undo.** Snapshot-of-state stack capped at 100 entries (C3).
 * Open-stroke palier undo lives inside [OpenStroke]; full undo
 * (`undo()`) routes there first if a stroke is in flight, only
 * popping the controller's stack when no open stroke is active.
 */
internal class EditorController(
    /**
     * Source of monotonic time stamps for the M15.19 active-draw
     * leash bypass. Defaults to the platform monotonic clock;
     * tests inject a [kotlin.time.TestTimeSource] so they can
     * advance the clock deterministically across move events.
     */
    private val timeSource: kotlin.time.TimeSource = kotlin.time.TimeSource.Monotonic,
) {

    private val _polygons: MutableList<List<Offset>> = mutableListOf()
    val polygons: List<List<Offset>> get() = _polygons

    var focusedIndex: Int? = null
        private set

    var openStroke: OpenStroke? = null
        private set

    var activeGesture: ActiveGesture? = null
        private set

    private val _revision = mutableStateOf(0)
    val revision: State<Int> get() = _revision

    /**
     * Image-pixel position of the most recent stroke sample that the
     * non-traversal clip pushed off the user's raw finger position
     * (spec §6.4.1). The canvas reads this to render the U6
     * non-traversal contact cue.
     *
     * Set by [onTouchMove] on every clamped sample; cleared on every
     * non-clamped sample and on [onTouchUp] — the canvas's 250 ms
     * fade-out smooths the visual on boundary-crossing transitions.
     * Reshape clamps don't feed this; stroke is the only feeder.
     */
    private val _lastStrokeClampContact = mutableStateOf<Offset?>(null)
    val lastStrokeClampContact: State<Offset?> get() = _lastStrokeClampContact

    private val _undoStack: ArrayDeque<UndoEntry> = ArrayDeque()

    /** Test / introspection accessor. */
    val undoStackSize: Int get() = _undoStack.size

    // ----- one-shot UI signal sink -----

    private val _signals: ArrayDeque<UiSignal> = ArrayDeque()

    /** Pops the oldest unread signal, or null if none. M11 drains this in a LaunchedEffect. */
    fun consumeSignal(): UiSignal? = _signals.removeFirstOrNull()

    /** Test-only — read without consuming. */
    val pendingSignals: List<UiSignal> get() = _signals.toList()

    /**
     * Attaches an opaque [state] payload to the most-recently-pushed
     * undo entry. Host screens use this to colocate their external
     * snapshot with the controller's UndoEntry so the two can't
     * drift on undo / rotation / cap-driven eviction. No-op if the
     * undo stack is empty.
     */
    fun attachSideStateToTopUndo(state: Any?) {
        val top = _undoStack.removeLastOrNull() ?: return
        _undoStack.addLast(top.copy(sideState = state))
    }

    // ----- per-gesture transient state -----

    /** Max canvas-px the cursor has moved from `Tap.downAt` during the current Tap. */
    private var tapMaxMoveCanvasPx: Float = 0f

    /**
     * Raw finger canvas position from the previous pointer event,
     * used to compute `canvasStepLenPx` for stroke sampling.
     *
     * Why raw (not the open stroke's EMA-smoothed tail): the user's
     * **finger speed** is what drives palier accumulation
     * (spec §6.2.4 measures cumulative *finger* travel, not the
     * smoothed polyline length). Using the EMA tail here would make
     * each step undercount by the EMA lag, throwing off palier
     * counts on every stroke.
     */
    private var prevTouchCanvas: Offset? = null

    /**
     * Timestamp of the most recently accepted stroke sample. The
     * stroke-branch finger leash bypasses its drift check when a
     * sample was accepted within [CONTINUOUS_DRAW_GAP] — the user
     * is in active-draw mode, not wandering, so the per-frame
     * delta is allowed to exceed [FINGER_LEASH_CANVAS_PX] (which a
     * fast continuous trace ~2700 canvas-px/sec routinely does on
     * a 60 Hz pointer stream). The leash re-engages after the
     * silence window, restoring the M15.1a wander-detection
     * semantic. M15.19.
     *
     * **Lifecycle.** No explicit reset on touch-down / touch-up:
     * the leash's `polyline.size >= 2` guard skips the first move
     * after a fresh `OpenStroke` is constructed, so a stale mark
     * from a prior gesture doesn't get a chance to incorrectly
     * bypass the leash before this mark is overwritten by the
     * first accepted sample of the new gesture.
     */
    private var lastSampleAcceptedMark: kotlin.time.TimeMark? = null

    // ----- pointer events -----

    fun onTouchDown(touchDownCanvas: Offset, ctx: GestureCtx) {
        if (activeGesture != null) return  // multi-touch suppression — M8's job
        val open = openStroke

        when (val kind = GestureRouter.route(touchDownCanvas, this, ctx)) {
            GestureKind.None -> {
                // Distinguish "no-op" from "too-far-from-open-stroke" —
                // the latter surfaces a snackbar. Other Nones are
                // silent (spec §6.3.4, §6.3.5, §8.3).
                if (open != null) emit(UiSignal.TooFarFromOpenStroke)
            }

            GestureKind.Stroke -> {
                pushUndo()
                val seed = ctx.canvasToImage(touchDownCanvas)
                val newStroke = OpenStroke(seed)
                openStroke = newStroke
                activeGesture = ActiveGesture.Stroke(newStroke)
                focusedIndex = null   // P5: open stroke is the new focus
                prevTouchCanvas = touchDownCanvas
                bump()
            }

            GestureKind.Resume -> {
                check(open != null) { "router returned Resume but openStroke is null" }
                activeGesture = ActiveGesture.Stroke(open)
                prevTouchCanvas = touchDownCanvas
                bump()
            }

            is GestureKind.Reshape -> {
                val poly = _polygons[kind.polygonIdx]
                activeGesture = ActiveGesture.Reshape(
                    polygonIdx = kind.polygonIdx,
                    undoStartSnapshot = poly.toList(),
                )
                prevTouchCanvas = touchDownCanvas
                bump()
            }

            GestureKind.Tap -> {
                activeGesture = ActiveGesture.Tap(touchDownCanvas)
                tapMaxMoveCanvasPx = 0f
                prevTouchCanvas = touchDownCanvas
                bump()
            }
        }
    }

    fun onTouchMove(touchCanvas: Offset, ctx: GestureCtx) {
        when (val gesture = activeGesture) {
            null -> return

            is ActiveGesture.Stroke -> {
                val prev = prevTouchCanvas ?: touchCanvas
                val stepDx = touchCanvas.x - prev.x
                val stepDy = touchCanvas.y - prev.y
                val stepCanvas = kotlin.math.sqrt(stepDx * stepDx + stepDy * stepDy)
                val rawImage = ctx.canvasToImage(touchCanvas)
                val forbidden = effectiveForbidden(ctx)
                // Finger leash: while the finger sits in free space,
                // pause sampling once it drifts > FINGER_LEASH_CANVAS_PX
                // from the open stroke's polyline. The gesture stays
                // alive; the next move within the leash resumes.
                //
                // Inside a forbidden polygon the leash is bypassed so
                // the legitimate "hug the boundary" gesture isn't
                // frozen — the per-sample projection and the Layer 2
                // segment-crossing detector keep non-traversal safe
                // on that path.
                val fingerInsideForbidden = forbidden.any {
                    com.twinskin.sdk.geometry.pointInPolygon(rawImage, it)
                }
                val polyline = gesture.openStroke.samples
                // M15.19 — bypass the leash while the gesture is in
                // active-draw mode. If a sample was accepted within
                // CONTINUOUS_DRAW_GAP the per-frame delta is just the
                // pointer-stream cadence (~16 ms on 60 Hz) × the
                // user's tracing speed; at 2700 canvas-px/sec that's
                // ~45 px per frame, right at the leash boundary. A
                // momentary spike past the leash is normal continuous
                // drawing, not wander. The leash re-engages once
                // CONTINUOUS_DRAW_GAP of silence has elapsed, so a
                // user who pauses then lifts the finger and moves
                // somewhere far still gets the wander-detection
                // semantic from M15.1a.
                val recentlyAccepted = lastSampleAcceptedMark?.let {
                    it.elapsedNow() < CONTINUOUS_DRAW_GAP
                } == true
                if (!recentlyAccepted &&
                    !fingerInsideForbidden &&
                    polyline.size >= 2 &&
                    ctx.canvasFromImageScale > 0f
                ) {
                    val leashImagePx = FINGER_LEASH_CANVAS_PX / ctx.canvasFromImageScale
                    if (distanceToPolyline(rawImage, polyline, closed = false) > leashImagePx) {
                        _lastStrokeClampContact.value = null
                        bump()
                        return
                    }
                }
                val sampleImage = clipStrokeSample(
                    candidate = rawImage,
                    forbiddenInteriors = forbidden,
                    confinementOutline = ctx.confinementOutline,
                )
                // Layer 2 teleport detector: catches the thin-polygon
                // case the finger leash misses — a fast finger crosses
                // a polygon ≤ leash-wide entirely within the leash
                // distance, so the pre/post samples both sit near the
                // polyline but the segment between them traverses the
                // polygon's interior. Drop the sample (no clamp event;
                // cue stays as-is).
                if (segmentCrossesAnyForbidden(
                        from = gesture.openStroke.lastSampleImagePx,
                        to = sampleImage,
                        forbidden = forbidden,
                    )
                ) {
                    bump()
                    return
                }
                // Clear the cue on non-clamping moves so the contact
                // dot doesn't stick when the finger leaves the
                // boundary; the canvas's 250 ms fade smooths the
                // boundary-crossing oscillation visually.
                if (sampleImage != rawImage) {
                    _lastStrokeClampContact.value = sampleImage
                } else {
                    _lastStrokeClampContact.value = null
                }
                // Re-clip the EMA-smoothed sample inside OpenStroke so
                // a finger that crosses past a forbidden polygon
                // doesn't let EMA lag drift the rendered stroke back
                // into the forbidden interior.
                gesture.openStroke.addSampleImagePx(
                    p = sampleImage,
                    canvasStepLenPx = stepCanvas,
                    clip = { p ->
                        clipStrokeSample(
                            candidate = p,
                            forbiddenInteriors = forbidden,
                            confinementOutline = ctx.confinementOutline,
                        )
                    },
                )
                // M15.19 — feed the active-draw clock so the next move
                // can recognize this gesture as in-flight and bypass
                // the leash drift check.
                lastSampleAcceptedMark = timeSource.markNow()
                prevTouchCanvas = touchCanvas
                bump()
            }

            is ActiveGesture.Reshape -> {
                val polygon = _polygons[gesture.polygonIdx]
                if (polygon.isEmpty()) return
                val fingerImage = ctx.canvasToImage(touchCanvas)
                val reshapeForbidden =
                    effectiveForbidden(ctx, excludeIdx = gesture.polygonIdx)

                // Finger leash for reshape — same shape as the Stroke
                // branch above (freeze on free-space drift past
                // FINGER_LEASH_CANVAS_PX; bypass inside a forbidden
                // polygon so a legitimate hug-along-boundary works).
                val fingerInsideForbidden = reshapeForbidden.any {
                    com.twinskin.sdk.geometry.pointInPolygon(fingerImage, it)
                }
                if (!fingerInsideForbidden &&
                    polygon.size >= 2 &&
                    ctx.canvasFromImageScale > 0f
                ) {
                    val leashImagePx = FINGER_LEASH_CANVAS_PX / ctx.canvasFromImageScale
                    if (distanceToPolyline(fingerImage, polygon, closed = true) > leashImagePx) {
                        bump()
                        return
                    }
                }

                // Anchor: vertex currently closest to the finger.
                // Recomputed per-move so the anchor "slides" along the
                // contour as the finger drifts (spec §6.3.3).
                val anchorIdx = closestVertexIdx(polygon, fingerImage)

                val deformed = applyReshape(
                    polygon = polygon,
                    fingerImagePx = fingerImage,
                    anchorIdx = anchorIdx,
                    influenceCanvasPx = RESHAPE_INFLUENCE_CANVAS_PX,
                    canvasFromImageScale = ctx.canvasFromImageScale,
                ).toMutableList()

                relaxNeighbourhood(
                    polygon = deformed,
                    anchorIdx = anchorIdx,
                    windowSize = RESHAPE_RELAX_WINDOW,
                )

                val clamped = clampReshapeAgainstNeighbours(
                    deformed = deformed,
                    forbiddenInteriors = reshapeForbidden,
                    confinementOutline = ctx.confinementOutline,
                )
                // Layer 2 teleport detector, applied per vertex: a
                // per-frame motion whose chord crosses a forbidden
                // polygon's interior is refused (vertex stays put),
                // catching the thin-polygon case the leash misses.
                _polygons[gesture.polygonIdx] = clamped.mapIndexed { i, newV ->
                    val oldV = polygon[i]
                    if (segmentCrossesAnyForbidden(oldV, newV, reshapeForbidden)) {
                        oldV
                    } else {
                        newV
                    }
                }
                prevTouchCanvas = touchCanvas
                bump()
            }

            is ActiveGesture.Tap -> {
                val dx = touchCanvas.x - gesture.downAt.x
                val dy = touchCanvas.y - gesture.downAt.y
                val moved = kotlin.math.sqrt(dx * dx + dy * dy)
                if (moved > tapMaxMoveCanvasPx) tapMaxMoveCanvasPx = moved
            }
        }
    }

    fun onTouchUp(touchCanvas: Offset, ctx: GestureCtx) {
        when (val gesture = activeGesture) {
            null -> return

            is ActiveGesture.Stroke -> {
                val stroke = gesture.openStroke
                val firstCanvas = ctx.imageToCanvas(stroke.firstPoint)
                if (stroke.isClosureCandidate(touchCanvas, firstCanvas)) {
                    commitClosure(stroke)
                }
                // Otherwise stroke stays open — finger lifted mid-stroke.
                activeGesture = null
                // Painter watches this clear to start the 250 ms fade-out
                // of the U6 non-traversal contact cue.
                _lastStrokeClampContact.value = null
                bump()
            }

            is ActiveGesture.Reshape -> {
                // Push pre-reshape state only if the polygon actually
                // changed — an aborted reshape (touch-up without
                // movement) leaves no undo footprint.
                val current = _polygons[gesture.polygonIdx]
                if (current != gesture.undoStartSnapshot) {
                    // Re-densify back to canonical [2, 10] image-px
                    // spacing (spec §6.3.3) — the cosine-falloff +
                    // relax pass bunches vertices near the anchor.
                    val densified = reDensify(current)
                    // Degenerate-reshape guard: a hug gesture inside
                    // a forbidden polygon can clamp many vertices to
                    // the same boundary point, collapsing densify
                    // below 3 vertices. Revert and emit no signal.
                    if (densified.size < 3) {
                        _polygons[gesture.polygonIdx] = gesture.undoStartSnapshot
                    } else {
                        val pre = _polygons.toMutableList()
                        pre[gesture.polygonIdx] = gesture.undoStartSnapshot
                        pushUndo(UndoEntry(pre, focusedIndex))
                        _polygons[gesture.polygonIdx] = densified
                        // Signal the screen so it can run the
                        // tissue-reclip cascade and colocate its
                        // store snapshot on the new undo entry.
                        emit(
                            UiSignal.ReshapeCommitted(
                                polygonIdx = gesture.polygonIdx,
                                preReshapeOutline = gesture.undoStartSnapshot,
                                postReshapeOutline = densified,
                            ),
                        )
                    }
                }
                activeGesture = null
                prevTouchCanvas = null
                bump()
            }

            is ActiveGesture.Tap -> {
                if (tapMaxMoveCanvasPx <= TAP_SLOP_CANVAS_PX) {
                    // Resolve focus — find the polygon under the down position.
                    val downImage = ctx.canvasToImage(gesture.downAt)
                    val idx = _polygons.indexOfFirst {
                        com.twinskin.sdk.geometry.pointInPolygon(downImage, it)
                    }
                    if (idx >= 0 && idx != focusedIndex) {
                        focusedIndex = idx
                    }
                }
                // Significant drag → silent no-op per spec §6.3.4 / §6.3.5.
                activeGesture = null
                prevTouchCanvas = null
                tapMaxMoveCanvasPx = 0f
                bump()
            }
        }
    }

    // ----- toolbar / programmatic ops -----

    /**
     * Undo dispatcher. Open-stroke palier undo (M3) takes precedence
     * when a stroke is in flight; otherwise pops the committed-state
     * stack.
     *
     * **Signal contract.** [UiSignal.UndoApplied] is emitted only
     * when popping a commit-level entry that actually changes the
     * polygon list. Palier rollback (in-stroke) never emits — the
     * screen has no parallel snapshot for an in-flight stroke. A
     * no-op commit-level pop (an orphan stroke-start entry whose
     * stroke was drained without closing) also skips emission so
     * the screen's `storeUndoStack` doesn't drift out of lockstep
     * with `_undoStack`.
     */
    fun undo() {
        val open = openStroke
        if (open != null) {
            open.rollbackOnePalier()
            if (open.isEmpty()) {
                openStroke = null
                // If undo drained the stroke mid-gesture, drop the
                // gesture too — otherwise the next onTouchMove would
                // mutate a stroke the controller no longer considers
                // active. Spec §6.7 says toolbar buttons are disabled
                // during gestures so the canonical UI flow can't hit
                // this, but the controller defends regardless.
                activeGesture = null
                prevTouchCanvas = null
                focusedIndex = if (_polygons.isNotEmpty()) _polygons.lastIndex else null
            }
            bump()
            return
        }
        val entry = _undoStack.removeLastOrNull() ?: return
        val polygonsChanged = entry.polygons != _polygons
        _polygons.clear()
        _polygons.addAll(entry.polygons)
        // Preserve spec P5 ("if any polygon exists, something is
        // focused"). The pre-commit entry captures the transient
        // null-focus set on stroke-start, so falling back to the
        // most recently restored polygon's index keeps the
        // invariant intact when entry.focusedIndex is null.
        focusedIndex = entry.focusedIndex
            ?: if (_polygons.isNotEmpty()) _polygons.lastIndex else null
        bump()
        if (polygonsChanged) emit(UiSignal.UndoApplied(entry.sideState))
    }

    /**
     * Deletes the focused polygon, OR discards the in-flight open
     * stroke when one exists. Caller (M11) gates this behind a
     * confirmation dialog when a focused polygon has dependent
     * tissues — the controller doesn't model tissue cascades.
     *
     * **Open-stroke discard.** Per spec §6 / U13b, Delete during an
     * open stroke aborts the stroke without committing. No signal
     * is emitted (the stroke never reached the store) and no fresh
     * undo entry is pushed; the existing stroke-start entry stays in
     * place and the conditional UndoApplied emit keeps the
     * screen-side snapshot in lockstep on later undo. The
     * pre-stroke focus is restored.
     *
     * For a committed polygon, emits [UiSignal.PolygonDeleted] so
     * the screen mirrors the removal into its store.
     */
    fun deleteFocused() {
        val open = openStroke
        if (open != null) {
            openStroke = null
            activeGesture = null
            prevTouchCanvas = null
            _lastStrokeClampContact.value = null
            // Restore the pre-stroke focus from the stroke-start
            // UndoEntry — that entry is on top of _undoStack because
            // onTouchDown.Stroke pushes it before clearing focus.
            // Without this restore, deleting an open stroke would
            // strip focus from the polygon that had it before the
            // stroke began (violates the focus-permanence invariant).
            focusedIndex = _undoStack.lastOrNull()?.focusedIndex
                ?: if (_polygons.isNotEmpty()) _polygons.lastIndex else null
            bump()
            return
        }
        val idx = focusedIndex ?: return
        if (idx !in _polygons.indices) return
        pushUndo()
        val deleted = _polygons[idx]
        _polygons.removeAt(idx)
        focusedIndex = if (_polygons.isNotEmpty()) _polygons.lastIndex else null
        bump()
        emit(UiSignal.PolygonDeleted(polygonIdx = idx, deletedPolygon = deleted))
    }

    /**
     * Aborts the in-flight gesture. No signal is emitted.
     *
     *  - **Reshape.** Reverts the polygon to its `undoStartSnapshot`.
     *  - **Stroke.** Discards the in-flight open stroke entirely and
     *    restores the pre-stroke focus (see [deleteFocused]'s
     *    open-stroke path). To clear `activeGesture` while leaving
     *    the stroke open, interact with [openStroke] directly.
     *  - **Tap.** Clears transient tap state; no polygon mutation.
     */
    fun cancelActiveGesture() {
        when (val gesture = activeGesture) {
            null -> return
            is ActiveGesture.Reshape -> {
                if (gesture.polygonIdx in _polygons.indices) {
                    _polygons[gesture.polygonIdx] = gesture.undoStartSnapshot
                }
                activeGesture = null
                prevTouchCanvas = null
                bump()
            }
            is ActiveGesture.Stroke -> {
                openStroke = null
                activeGesture = null
                prevTouchCanvas = null
                _lastStrokeClampContact.value = null
                // Mirror the deleteFocused open-stroke path: restore
                // the pre-stroke focus so a cancel can't leave the
                // controller in `polygons.isNotEmpty() && focus == null`.
                focusedIndex = _undoStack.lastOrNull()?.focusedIndex
                    ?: if (_polygons.isNotEmpty()) _polygons.lastIndex else null
                bump()
            }
            is ActiveGesture.Tap -> {
                activeGesture = null
                prevTouchCanvas = null
                tapMaxMoveCanvasPx = 0f
                bump()
            }
        }
    }

    fun focusPolygon(idx: Int) {
        require(idx in _polygons.indices) {
            "focus index $idx out of bounds (polygon count=${_polygons.size})"
        }
        if (idx != focusedIndex) {
            focusedIndex = idx
            bump()
        }
    }

    // ----- internals -----

    private fun commitClosure(stroke: OpenStroke) {
        val raw = stroke.samples
        // Append firstPoint if the stroke didn't already loop back,
        // then re-densify so the committed outline has segments in
        // [2, 10] image-px (spec §6.2.5 step 2).
        val closed = if (raw.isNotEmpty() && raw.first() != raw.last()) raw + raw.first() else raw
        val densified = reDensify(closed)
        // Spec §20 invariant E1 / INV-6a — every committed polygon
        // has size ≥ 3. A leash-heavy stroke whose samples coalesced
        // near the first point can densify down to ≤ 2 vertices;
        // refusing to commit in that case keeps the invariant
        // load-bearing. The open stroke
        // is discarded and no signal is emitted (nothing reached
        // the store). Restore the pre-stroke focus to keep spec P5.
        if (densified.size < 3) {
            openStroke = null
            _lastStrokeClampContact.value = null
            focusedIndex = _undoStack.lastOrNull()?.focusedIndex
                ?: if (_polygons.isNotEmpty()) _polygons.lastIndex else null
            return
        }
        pushUndo()
        _polygons.add(densified)
        val newIdx = _polygons.lastIndex
        focusedIndex = newIdx
        openStroke = null
        // Defensive: clear any non-traversal contact carried into the
        // closure path so the painter doesn't ghost a stale cue when
        // the next stroke starts.
        _lastStrokeClampContact.value = null
        emit(UiSignal.StrokeClosed(polygonIdx = newIdx))
    }

    private fun pushUndo() {
        pushUndo(UndoEntry(polygons = _polygons.toList(), focusedIndex = focusedIndex))
    }

    private fun pushUndo(entry: UndoEntry) {
        if (_undoStack.size >= UNDO_STACK_MAX) {
            _undoStack.removeFirst()
        }
        _undoStack.addLast(entry)
    }

    /**
     * Forbidden-interior set for the stroke and reshape clamps:
     * [GestureCtx.forbiddenInteriors] (the parent wound and
     * other-type tissues) plus the controller's own editable
     * polygons. Including the latter is what keeps wound↔wound and
     * same-type-tissue↔same-type-tissue traversals from leaking past
     * the gesture-loop's forbidden set, which by construction
     * excludes everything the controller owns.
     *
     * [excludeIdx] omits the polygon being reshaped (reshape is
     * allowed to deform its own outline). Pass `null` for
     * stroke-clamp calls — every editable polygon is forbidden.
     */
    private fun effectiveForbidden(
        ctx: GestureCtx,
        excludeIdx: Int? = null,
    ): List<List<Offset>> = if (excludeIdx == null) {
        ctx.forbiddenInteriors + _polygons
    } else {
        ctx.forbiddenInteriors + _polygons.filterIndexed { i, _ -> i != excludeIdx }
    }

    private fun closestVertexIdx(polygon: List<Offset>, point: Offset): Int {
        var bestIdx = 0
        var bestDist2 = Float.POSITIVE_INFINITY
        for ((i, v) in polygon.withIndex()) {
            val dx = v.x - point.x
            val dy = v.y - point.y
            val d2 = dx * dx + dy * dy
            if (d2 < bestDist2) {
                bestDist2 = d2
                bestIdx = i
            }
        }
        return bestIdx
    }

    /**
     * Queues a [UiSignal] and bumps revision. The bump is required:
     * signals emitted from a path that doesn't otherwise mutate
     * visible state would otherwise sit in `_signals` until the
     * next bumping op woke the screen's snapshotFlow collector.
     */
    private fun emit(signal: UiSignal) {
        _signals.addLast(signal)
        bump()
    }

    private fun bump() {
        _revision.value += 1
    }

    internal companion object {
        /** Spec §6.3.1 — touch-up within this many canvas-px of touch-down counts as a tap. */
        const val TAP_SLOP_CANVAS_PX: Float = 4f

        /**
         * Spec §10.6.1 — finger leash distance for the non-traversal
         * teleport defence. A finger that drifts further than this
         * from the active polyline / contour pauses the gesture
         * until it returns within the leash.
         */
        const val FINGER_LEASH_CANVAS_PX: Float = 45f

        /**
         * M15.19 — active-draw bypass window for the stroke-branch
         * leash. If a sample was accepted within this window, the
         * next move skips the leash drift check (the user is
         * tracing continuously, not wandering). 100 ms covers ~6
         * frames at 60 Hz — well above any pointer-stream cadence
         * spike and well below human "pause and reconsider"
         * timescales (~200 ms+), so the wander semantic kicks back
         * in on real pauses without false-positives on fast strokes.
         */
        val CONTINUOUS_DRAW_GAP: kotlin.time.Duration =
            kotlin.time.Duration.parse("100ms")

        /** Spec C3 — cap on the controller-level undo stack. */
        const val UNDO_STACK_MAX: Int = 100

        /** Spec §6.3.3 — reshape influence radius (zoom-independent). */
        const val RESHAPE_INFLUENCE_CANVAS_PX: Float = 40f

        /**
         * Number of vertices on each side of the anchor that participate
         * in the relaxation pass (§6.3.3). Matches the Flutter
         * reference's window heuristic — wide enough to smooth the
         * cosine-falloff residual, narrow enough not to bleed into
         * the rest of the polygon.
         */
        const val RESHAPE_RELAX_WINDOW: Int = 8

        /**
         * Builds a controller pre-populated with [polygons] and
         * [focusedIndex]. Used by `ControllerSaver` to restore canvas
         * state across configuration changes; the undo stack, open
         * stroke, and active gesture are intentionally not restored
         * (the disk-backed draft is the safety net for process death).
         */
        fun fromState(
            polygons: List<List<Offset>>,
            focusedIndex: Int? = null,
            timeSource: kotlin.time.TimeSource = kotlin.time.TimeSource.Monotonic,
        ): EditorController {
            require(focusedIndex == null || focusedIndex in polygons.indices) {
                "focusedIndex $focusedIndex out of bounds for polygons.size=${polygons.size}"
            }
            val c = EditorController(timeSource = timeSource)
            for (p in polygons) c._polygons.add(p.toList())
            c.focusedIndex = focusedIndex
            return c
        }
    }
}
