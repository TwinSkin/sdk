package com.twinskin.sdk.ui.annotation_editor.delineation.canvas

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Painter stack for [DrawingCanvas]. Each function is a pure
 * `DrawScope` extension over canvas-pixel geometry; callers must
 * convert image-pixel vertices via [imageToCanvas] before invoking.
 * Keeping painters in canvas-px lets a future `Modifier.graphicsLayer`
 * on the image painter compose additively.
 *
 * Clinical colours (necrosis = near-black, slough = yellow,
 * granulation = red) match spec §8.2.
 *
 * **Stroke-width contract (M15.5).** All stroke widths are expressed
 * in dp (density-independent pixels) and resolved via [scaledStrokePx]
 * so they look the same physical thickness on every device density.
 * The painters that draw the editable contour ([drawClosedPolygon],
 * [drawDashedWound], [drawOpenStroke]) also multiply their dp width
 * by the caller's [DrawingCanvas] `zoomScale` (capped at
 * [MAX_STROKE_ZOOM_MULTIPLIER]) so the contour stays visually
 * prominent when the user pinch-zooms in for detail work. Halo and
 * cue radii intentionally stay scale-invariant — they mark fingertip
 * ergonomics measured in canvas-px (closure-zone trigger, projection
 * point) and should not balloon as the underlying image is zoomed.
 */

/**
 * Hard cap on the multiplicative zoom factor applied to stroke widths.
 * A 15× pinch-zoom must not produce a 30-dp contour line; ~4× is the
 * upper bound where stroke prominence stops helping and starts
 * obscuring the wound the user is annotating.
 */
internal const val MAX_STROKE_ZOOM_MULTIPLIER: Float = 4f

/**
 * Resolves a dp-expressed stroke width to device pixels, with the
 * M15.5 zoom-scale multiplier applied and capped. Extracted as a
 * pure helper so the dp-and-zoom contract can be unit-tested without
 * spinning up a full Compose draw scope — see `PaintersTest`.
 */
internal fun Density.scaledStrokePx(baseDp: Dp, zoomScale: Float = 1f): Float =
    baseDp.toPx() * zoomScale.coerceAtMost(MAX_STROKE_ZOOM_MULTIPLIER)

/**
 * Outline + fill of a closed polygon. Stroke width scales with
 * [zoomScale] (spec §6.3.2). The focused polygon's fill is a
 * radial gradient brightening toward its centroid (M15.10), giving
 * a clear visual highlight without needing a thicker stroke —
 * round-18's "make the focus thicker" pass produced strokes that
 * were too prominent on high-density screens; M15.10 walks them
 * back to the pre-M15.5 weight and uses the gradient to carry the
 * focus signal instead.
 */
internal fun DrawScope.drawClosedPolygon(
    canvasPoly: List<Offset>,
    color: Color,
    focused: Boolean,
    zoomScale: Float = 1f,
) {
    if (canvasPoly.size < 3) return
    val path = pathOf(canvasPoly, closed = true)
    if (focused) {
        val centroid = polygonCentroid(canvasPoly)
        val radius = polygonBoundsRadius(canvasPoly, centroid)
        drawPath(
            path = path,
            brush = Brush.radialGradient(
                colors = listOf(color.copy(alpha = 0.45f), color.copy(alpha = 0.10f)),
                center = centroid,
                radius = radius,
            ),
            style = Fill,
        )
    } else {
        drawPath(path, color = color.copy(alpha = 0.12f), style = Fill)
    }
    val widthDp = if (focused) 2.dp else 1.dp
    drawPath(
        path = path,
        color = color,
        style = Stroke(width = scaledStrokePx(widthDp, zoomScale)),
    )
}

/**
 * Read-only wound contour shown on screen 4 — dashed orange, no
 * fill. Dashed pattern distinguishes "context wound" from the
 * solid-rendered editable wound on screen 2; orange (rather than
 * gray) keeps it legible on dark photos and distinct from
 * [TissueType.Necrosis] near-black. Stroke width scales with
 * [zoomScale].
 */
internal fun DrawScope.drawDashedWound(canvasPoly: List<Offset>, zoomScale: Float = 1f) {
    if (canvasPoly.size < 3) return
    drawPath(
        path = pathOf(canvasPoly, closed = true),
        color = ClosedPolygonColor,
        style = Stroke(
            width = scaledStrokePx(0.875.dp, zoomScale),
            pathEffect = PathEffect.dashPathEffect(intervals = floatArrayOf(12f, 6f)),
        ),
    )
}

/**
 * Open in-progress stroke — dashed green polyline, no fill. Stroke
 * width scales with [zoomScale].
 */
internal fun DrawScope.drawOpenStroke(
    canvasPoly: List<Offset>,
    color: Color = OpenStrokeColor,
    zoomScale: Float = 1f,
) {
    if (canvasPoly.size < 2) return
    drawPath(
        path = pathOf(canvasPoly, closed = false),
        color = color,
        style = Stroke(
            width = scaledStrokePx(1.25.dp, zoomScale),
            pathEffect = PathEffect.dashPathEffect(intervals = floatArrayOf(8f, 4f)),
        ),
    )
}

/**
 * Enlarged dot at the open stroke's first point when closure is
 * imminent (spec §6.2.5). Halo radii are sized to the closure-zone
 * trigger radius — the cue grows visibly before the trigger fires.
 * [color] defaults to [OpenStrokeColor]; the tissue screen passes
 * the tissue type's clinical colour. Radii are zoom-invariant — the
 * closure-zone is measured in canvas-px regardless of pinch-zoom.
 */
internal fun DrawScope.drawFirstPointHalo(canvasPos: Offset, color: Color = OpenStrokeColor) {
    drawCircle(
        color = color.copy(alpha = 0.3f),
        radius = 7.dp.toPx(),
        center = canvasPos,
    )
    drawCircle(
        color = color,
        radius = 4.dp.toPx(),
        center = canvasPos,
    )
}

/**
 * U6 non-traversal contact cue — translucent red dot at the
 * projection point of the most recent clamp. The caller supplies
 * [alpha] so it can drive the 250 ms fade on touch-up via
 * `animateFloatAsState`. Radius is zoom-invariant — the cue marks a
 * canvas-px projection point, not an image feature.
 */
internal fun DrawScope.drawNonTraversalCue(canvasPos: Offset, alpha: Float) {
    if (alpha <= 0f) return
    drawCircle(
        color = NonTraversalCueColor.copy(alpha = (alpha * 0.6f).coerceIn(0f, 1f)),
        radius = 4.dp.toPx(),
        center = canvasPos,
    )
}

/** Spec §8.2 clinical colour for a tissue type. Falls back to gray for [TissueType.Other]. */
internal fun clinicalColorFor(type: TissueType): Color = when (type) {
    TissueType.Necrosis -> Color(0xFF1A1A1A)
    TissueType.Slough -> Color(0xFFE0C200)
    TissueType.Granulation -> Color(0xFFD12A2A)
    is TissueType.Other -> Color(0xFF888888)
}

internal val OpenStrokeColor: Color = Color(0xFF2AB07A)            // green
internal val ClosedPolygonColor: Color = Color(0xFFE07A2A)         // wound orange
internal val NonTraversalCueColor: Color = Color(0xFFD12A2A)       // red

private fun pathOf(poly: List<Offset>, closed: Boolean): Path {
    val path = Path()
    path.moveTo(poly[0].x, poly[0].y)
    for (i in 1 until poly.size) path.lineTo(poly[i].x, poly[i].y)
    if (closed) path.close()
    return path
}

/**
 * Arithmetic mean of [canvasPoly]'s vertices — used as the centre
 * of the M15.10 focused-polygon radial gradient. The simple mean is
 * intentional: a true area-weighted centroid would track shape
 * skew more faithfully but produces visually surprising gradient
 * centres on convex shapes (gradient bias toward the "fat" side
 * of an elongated polygon), and the dense-by-construction
 * delineation polygons (~5 image-px spacing per spec §6.2.2) keep
 * the arithmetic mean close enough to the visual centre that the
 * difference is imperceptible at typical zoom levels.
 *
 * Internal-visibility for [PaintersTest] coverage of the gradient
 * placement contract — there's no per-vertex Compose state shape
 * suitable for an in-painter pure test.
 */
internal fun polygonCentroid(canvasPoly: List<Offset>): Offset {
    if (canvasPoly.isEmpty()) return Offset.Zero
    var sx = 0f
    var sy = 0f
    for (p in canvasPoly) {
        sx += p.x
        sy += p.y
    }
    val n = canvasPoly.size.toFloat()
    return Offset(sx / n, sy / n)
}

/**
 * Distance from [centroid] to the farthest vertex of [canvasPoly],
 * with a 1-px floor so a degenerate single-point polygon doesn't
 * collapse the gradient to a zero-radius brush (which Compose
 * treats as undefined and renders as a hard-edged disc). This is
 * the M15.10 gradient's outer fade distance — colours hit the
 * `alpha = 0.10f` stop here.
 */
internal fun polygonBoundsRadius(canvasPoly: List<Offset>, centroid: Offset): Float {
    var maxR2 = 0f
    for (p in canvasPoly) {
        val dx = p.x - centroid.x
        val dy = p.y - centroid.y
        val r2 = dx * dx + dy * dy
        if (r2 > maxR2) maxR2 = r2
    }
    return max(1f, sqrt(maxR2))
}
