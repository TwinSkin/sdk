package com.twinskin.sdk.ui.annotation_editor.delineation.help

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.ui.annotation_editor.delineation.canvas.ClosedPolygonColor
import com.twinskin.sdk.ui.annotation_editor.delineation.canvas.NonTraversalCueColor
import com.twinskin.sdk.ui.annotation_editor.delineation.canvas.OpenStrokeColor
import com.twinskin.sdk.ui.annotation_editor.delineation.canvas.clinicalColorFor
import com.twinskin.sdk.ui.annotation_editor.delineation.canvas.drawClosedPolygon
import com.twinskin.sdk.ui.annotation_editor.delineation.canvas.drawDashedWound
import com.twinskin.sdk.ui.annotation_editor.delineation.canvas.drawFirstPointHalo
import com.twinskin.sdk.ui.annotation_editor.delineation.canvas.drawOpenStroke
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Compose-drawn gesture diagrams for the help dialog. Each diagram
 * renders inside a [DiagramSurface] sized to ~200×120 dp, reusing
 * the canvas painters so the rendering is pixel-identical to what
 * the clinician sees while drawing — not abstract iconography.
 *
 * Two help-only primitives ([drawFingerCircle], [drawMotionArrow])
 * extend the painter vocabulary with gesture-illustration cues
 * (where the finger is, which direction it's moving). They live
 * here, not in `painters.kt`, because they only appear in help and
 * aren't part of the canvas's runtime rendering.
 */

// ── Help-only DrawScope primitives ───────────────────────────────────

/** Gray filled disc representing the user's fingertip in help diagrams. */
internal fun DrawScope.drawFingerCircle(at: Offset, radiusPx: Float = 12f) {
    drawCircle(
        color = Color(0xFF555555),
        radius = radiusPx,
        center = at,
    )
    // Subtle outline so the finger reads against any background.
    drawCircle(
        color = Color.White,
        radius = radiusPx,
        center = at,
        style = Stroke(width = 1.5f),
    )
}

/**
 * Solid line + triangular arrowhead from [from] to [to]. Used in
 * diagrams to show finger motion direction and reshape
 * displacement.
 */
internal fun DrawScope.drawMotionArrow(
    from: Offset,
    to: Offset,
    color: Color = Color(0xFF333333),
    strokeWidthPx: Float = 2f,
    arrowheadSizePx: Float = 10f,
) {
    drawLine(
        color = color,
        start = from,
        end = to,
        strokeWidth = strokeWidthPx,
    )
    val theta = atan2(to.y - from.y, to.x - from.x)
    val wing = PI.toFloat() / 6f   // 30°
    val p1 = Offset(
        to.x - arrowheadSizePx * cos(theta - wing),
        to.y - arrowheadSizePx * sin(theta - wing),
    )
    val p2 = Offset(
        to.x - arrowheadSizePx * cos(theta + wing),
        to.y - arrowheadSizePx * sin(theta + wing),
    )
    val head = Path().apply {
        moveTo(to.x, to.y)
        lineTo(p1.x, p1.y)
        lineTo(p2.x, p2.y)
        close()
    }
    drawPath(head, color = color)
}

// ── DiagramSurface wrapper ───────────────────────────────────────────

/**
 * Standard surface every diagram renders into. Fixed height so the
 * help dialog's pager pages have consistent geometry. The Surface
 * provides the themed background (light/dark adaptive) and the
 * rounded clip; the inner Canvas does the painting.
 */
@Composable
private fun DiagramSurface(content: DrawScope.() -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .padding(12.dp),
        ) {
            content()
        }
    }
}

// ── Shape helpers (canvas-pixel polygons in the diagram's own space) ─

/**
 * 12-vertex ellipse-like blob centred at [center] with semi-axes
 * [rx]/[ry], jittered slightly so it reads as a wound shape rather
 * than a perfect ellipse. Deterministic — no random — so goldens
 * are stable.
 */
private fun woundBlob(center: Offset, rx: Float, ry: Float): List<Offset> {
    val jitter = floatArrayOf(1.0f, 0.95f, 1.08f, 0.92f, 1.05f, 0.97f, 1.02f, 1.06f, 0.96f, 1.04f, 0.98f, 1.03f)
    return List(jitter.size) { i ->
        val theta = i * 2f * PI.toFloat() / jitter.size
        val r = jitter[i]
        Offset(center.x + rx * r * cos(theta), center.y + ry * r * sin(theta))
    }
}

/**
 * Partial arc of the same shape — [progress] in `[0, 1]` controls
 * how much of the perimeter is drawn (used to show "stroke
 * partially traced").
 */
private fun woundArc(center: Offset, rx: Float, ry: Float, progress: Float): List<Offset> {
    val full = woundBlob(center, rx, ry)
    val n = (full.size * progress).toInt().coerceAtLeast(2)
    return full.take(n)
}

// ── Wound-drawing diagrams ───────────────────────────────────────────

@Composable
internal fun TraceWoundDiagram() = DiagramSurface {
    val center = Offset(size.width * 0.5f, size.height * 0.55f)
    val wound = woundBlob(center, rx = size.width * 0.32f, ry = size.height * 0.38f)
    drawClosedPolygon(wound, color = ClosedPolygonColor, focused = false)
    // Finger near the top vertex; arrow tracing along the next two edges.
    val v0 = wound.first()
    val v1 = wound[1]
    drawFingerCircle(at = v0)
    drawMotionArrow(from = v0, to = v1, color = OpenStrokeColor)
}

@Composable
internal fun CloseByProximityDiagram() = DiagramSurface {
    val center = Offset(size.width * 0.5f, size.height * 0.55f)
    // Show ~85% of the perimeter drawn as an open stroke, with the
    // halo at the start point and the finger approaching it.
    val arc = woundArc(center, rx = size.width * 0.32f, ry = size.height * 0.38f, progress = 0.85f)
    drawOpenStroke(arc)
    val start = arc.first()
    drawFirstPointHalo(start)
    // Finger sitting just below + left of the halo, approaching the close.
    val finger = Offset(start.x - 22f, start.y + 18f)
    drawFingerCircle(at = finger)
    drawMotionArrow(from = finger, to = start, color = OpenStrokeColor)
}

@Composable
internal fun ResumeOpenStrokeDiagram() = DiagramSurface {
    val center = Offset(size.width * 0.5f, size.height * 0.55f)
    // ~55% drawn as open stroke; finger approaching the tail to resume.
    val arc = woundArc(center, rx = size.width * 0.32f, ry = size.height * 0.38f, progress = 0.55f)
    drawOpenStroke(arc)
    val tail = arc.last()
    val finger = Offset(tail.x + 28f, tail.y + 8f)
    drawFingerCircle(at = finger)
    drawMotionArrow(from = finger, to = tail, color = OpenStrokeColor)
}

@Composable
internal fun ReshapeWoundDiagram() = DiagramSurface {
    val center = Offset(size.width * 0.5f, size.height * 0.55f)
    val wound = woundBlob(center, rx = size.width * 0.30f, ry = size.height * 0.35f)
    drawClosedPolygon(wound, color = ClosedPolygonColor, focused = true)
    // Pick a side vertex; finger drags it outward (showing reshape direction).
    val vertex = wound[wound.size / 4]   // a vertex on the right side
    val outward = Offset(vertex.x + 30f, vertex.y - 4f)
    drawFingerCircle(at = vertex)
    drawMotionArrow(from = vertex, to = outward, color = NonTraversalCueColor)
}

// ── Tissue-drawing diagrams ──────────────────────────────────────────

@Composable
internal fun TissueInsideWoundDiagram() = DiagramSurface {
    val center = Offset(size.width * 0.5f, size.height * 0.55f)
    // Outer dashed wound (read-only context on screen 4).
    val wound = woundBlob(center, rx = size.width * 0.36f, ry = size.height * 0.42f)
    drawDashedWound(wound)
    // Inner tissue (granulation = red).
    val tissue = woundBlob(
        center = Offset(center.x - 12f, center.y + 4f),
        rx = size.width * 0.16f,
        ry = size.height * 0.18f,
    )
    drawClosedPolygon(tissue, color = clinicalColorFor(TissueType.Granulation), focused = true)
}

@Composable
internal fun OneTypeAtATimeDiagram() = DiagramSurface {
    val center = Offset(size.width * 0.5f, size.height * 0.55f)
    val wound = woundBlob(center, rx = size.width * 0.42f, ry = size.height * 0.42f)
    drawDashedWound(wound)
    // Three small tissues, one focused (current type), the others
    // rendered as muted other-type tissues (thin outline, no fill
    // emphasis).
    val current = woundBlob(
        center = Offset(center.x - 40f, center.y - 10f),
        rx = 22f, ry = 18f,
    )
    val muted1 = woundBlob(
        center = Offset(center.x + 24f, center.y + 16f),
        rx = 18f, ry = 14f,
    )
    val muted2 = woundBlob(
        center = Offset(center.x + 30f, center.y - 20f),
        rx = 14f, ry = 12f,
    )
    drawClosedPolygon(muted1, color = clinicalColorFor(TissueType.Necrosis), focused = false)
    drawClosedPolygon(muted2, color = clinicalColorFor(TissueType.Slough), focused = false)
    drawClosedPolygon(current, color = clinicalColorFor(TissueType.Granulation), focused = true)
}

@Composable
internal fun ReshapeParentWoundDiagram() = DiagramSurface {
    val center = Offset(size.width * 0.5f, size.height * 0.55f)
    val wound = woundBlob(center, rx = size.width * 0.40f, ry = size.height * 0.42f)
    drawDashedWound(wound)
    // Tissue near the wound boundary; finger drags it outward — clamp
    // arrow shows the tissue can't cross the parent wound.
    val tissue = woundBlob(
        center = Offset(center.x + size.width * 0.18f, center.y),
        rx = 22f, ry = 18f,
    )
    drawClosedPolygon(tissue, color = clinicalColorFor(TissueType.Granulation), focused = true)
    val edgeVertex = tissue[tissue.size / 4]   // a vertex on the right side
    val attempted = Offset(edgeVertex.x + 22f, edgeVertex.y)
    drawFingerCircle(at = edgeVertex)
    drawMotionArrow(from = edgeVertex, to = attempted, color = NonTraversalCueColor)
}

@Composable
internal fun OtherTypeReadOnlyDiagram() = DiagramSurface {
    val center = Offset(size.width * 0.5f, size.height * 0.55f)
    val wound = woundBlob(center, rx = size.width * 0.40f, ry = size.height * 0.42f)
    drawDashedWound(wound)
    // Current type (granulation) rendered focused; other type
    // (necrosis) rendered as a muted, thinner outline to signal
    // "not editable from here".
    val current = woundBlob(
        center = Offset(center.x - 28f, center.y - 6f),
        rx = 22f, ry = 18f,
    )
    val readOnly = woundBlob(
        center = Offset(center.x + 28f, center.y + 12f),
        rx = 20f, ry = 16f,
    )
    drawClosedPolygon(readOnly, color = clinicalColorFor(TissueType.Necrosis), focused = false)
    drawClosedPolygon(current, color = clinicalColorFor(TissueType.Granulation), focused = true)
    // Lock-icon-style indicator near the read-only tissue: small ×
    // mark to imply "can't touch".
    val lockAt = Offset(center.x + 28f, center.y + 12f)
    val tick = 4f
    drawLine(
        color = Color(0xFF888888),
        start = Offset(lockAt.x - tick, lockAt.y - tick),
        end = Offset(lockAt.x + tick, lockAt.y + tick),
        strokeWidth = 2f,
    )
    drawLine(
        color = Color(0xFF888888),
        start = Offset(lockAt.x - tick, lockAt.y + tick),
        end = Offset(lockAt.x + tick, lockAt.y - tick),
        strokeWidth = 2f,
    )
}

// ── Size helper for unused-import-safety ─────────────────────────────

@Suppress("unused")
private val _sizeRef: Size = Size(0f, 0f)
