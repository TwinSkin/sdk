@file:OptIn(ExperimentalMaterial3Api::class, com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.annotation_editor

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.TwinSkinInternalApi

/**
 * Shared chrome around the annotation editors. The editors themselves are
 * pure content; each host (PostSubmitFlow, ViewCaptureScreenHost, the demo
 * screens) wraps the editor in this scaffold so the bar lives at the same
 * composition level as the host's other chrome — avoiding the double-bar
 * stack-up that happens when the editor carries its own Scaffold under an
 * outer NavigationStack (iOS) or Scaffold (Android).
 */
@TwinSkinInternalApi
@Composable
public fun AnnotationEditorScaffold(
    title: String,
    onCancel: () -> Unit,
    onDone: () -> Unit,
    doneEnabled: Boolean = true,
    content: @Composable (PaddingValues) -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    TextButton(onClick = onCancel) { Text("Cancel") }
                },
                actions = {
                    Button(
                        onClick = onDone,
                        enabled = doneEnabled,
                        colors = ButtonDefaults.textButtonColors(),
                    ) { Text("Done") }
                    Spacer(Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
                ),
            )
        },
        content = content,
    )
}
