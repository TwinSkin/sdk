package com.twinskin.sdk.capture

import java.io.File

/**
 * Bridges the on-disk photosphere bundle layout to the SDK's
 * [CaptureResult] / [CaptureSession.submit] contract. The
 * `PhotosphereSession` writes the ref as `ref_image.jpg` and per-view
 * frames as `view_AAA_rXaY.jpg` (AAA = azimuth, 000-359); this bridge
 * enumerates them in lexicographic (= azimuth) order.
 */

/**
 * Maps the bundle in [sessionDir] to a [CaptureResult] for
 * [CaptureSession.submit]. Returns `markerVersion = null` because the
 * native marker auto-detect is stubbed on Android.
 *
 * Peer files (`index.json`, `frame_log.jsonl`, `pose_log.json`)
 * are not surfaced through [CaptureResult]; the submit packing
 * pass discovers them by enumerating the bundle directory.
 *
 * @throws IllegalStateException if `ref_image.jpg` is missing.
 */
internal fun bundleDirToCaptureResult(sessionDir: File): CaptureResult {
    val canonicalRef = File(sessionDir, "ref_image.jpg")
    check(canonicalRef.exists()) {
        "expected ref_image.jpg in ${sessionDir.absolutePath} after finalize"
    }

    // Whitelist the canonical photosphere bundle naming so non-bundle
    // files in the same directory (e.g. `CameraSessionController`'s
    // `diskWriteFanout` debug snapshots) don't get scooped into the
    // encrypted upload. The photosphere session emits
    // `view_AAA_rXaY.jpg` where AAA is three zero-padded digits of
    // azimuth (000..359), X is the round (1..8), and Y is the arm (0..3).
    val viewFilePattern = Regex("""^view_\d{3}_r\d+a\d+\.jpg$""")
    val viewFiles = sessionDir
        .listFiles { f -> viewFilePattern.matches(f.name) }
        ?.sortedBy { it.name }
        .orEmpty()

    return CaptureResult(
        photoPath = canonicalRef.absolutePath,
        framePaths = viewFiles.map { it.absolutePath },
        markerVersion = null,
    )
}
