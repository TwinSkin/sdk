package com.twinskin.sdk.ui.annotation_editor.delineation.system

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect

@Composable
internal actual fun DeferSystemGesturesDuringSession() {
    // Android's back-swipe and home-bar gestures don't intercept a
    // mid-stroke MotionEvent the way iOS's screen-edge gestures do,
    // so the M15.6 problem doesn't manifest on Android in v1. Still
    // drive the counter for symmetry with the iOS actual — tests
    // asserting counter behaviour see consistent semantics across
    // targets, and a future PredictiveBackHandler hook can plug in
    // here without changing the call site.
    DisposableEffect(Unit) {
        SystemGesturesLockCounter.enter()
        onDispose { SystemGesturesLockCounter.exit() }
    }
}
