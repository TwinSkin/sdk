@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class, kotlinx.cinterop.ExperimentalForeignApi::class)

package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.interop.UIKitView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.ComposeUIViewController
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.capture.fallback.VideoCaptureResult
import com.twinskin.sdk.capture.fallback.createAccelerometerDriver
import com.twinskin.sdk.capture.fallback.createAccelerometerVideoRecorder
import kotlinx.cinterop.readValue
import kotlinx.coroutines.launch
import platform.AVFoundation.AVCaptureVideoPreviewLayer
import platform.AVFoundation.AVLayerVideoGravityResizeAspect
import platform.AVFoundation.AVLayerVideoGravityResizeAspectFill
import platform.AVFoundation.AVPlayer
import platform.AVFoundation.AVPlayerItemDidPlayToEndTimeNotification
import platform.AVFoundation.AVPlayerLayer
import platform.AVFoundation.currentItem
import platform.AVFoundation.pause
import platform.AVFoundation.play
import platform.AVFoundation.seekToTime
import platform.CoreGraphics.CGRectZero
import platform.CoreMedia.kCMTimeZero
import platform.Foundation.NSNotificationCenter
import platform.Foundation.NSOperationQueue
import platform.Foundation.NSURL
import platform.UIKit.UIView
import platform.UIKit.UIViewController
import platform.darwin.NSObjectProtocol

// Cancel routing: in-screen Cancel TopBar goes through
// `session.cancel()` inline; swipe-to-dismiss bypasses the Compose
// tree (DisposableEffect.onDispose only runs controller.cancel()), so
// [onSessionStarted] hands the live session up to Swift's
// CapturePresenter.DismissBridge for the same `session.cancel()`.
@TwinSkinInternalApi
public fun AccelerometerCaptureViewController(
    metadata: SdkCaptureMetadata,
    onDone: (CaptureSession) -> Unit = {},
    onCancel: () -> Unit = {},
    onSessionStarted: (CaptureSession) -> Unit = {},
    tutorialAssetPaths: TutorialAssetPaths = TutorialAssetPaths(),
): UIViewController = ComposeUIViewController {
    val scope = rememberCoroutineScope()
    val session = remember(metadata) {
        TwinSkinSdk.startCapture(metadata).also(onSessionStarted)
    }
    // Concrete iOS type so the preview layer can attach to the SAME
    // AVCaptureSession the recorder owns — without a preview layer on
    // a running session, didFinishRecordingTo never fires (#538).
    val recorder = remember { createAccelerometerVideoRecorder() }
    val controller = remember(session, recorder) {
        AccelerometerCaptureController(
            scope = scope,
            recorder = recorder,
            driver = createAccelerometerDriver(),
            takeStillPhoto = {
                recorder.takeStillPhoto(
                    "${session.workingDir.trimEnd('/')}/photo.jpg"
                )
            },
            videoOutputPath = {
                "${session.workingDir.trimEnd('/')}/video.mov"
            },
            onResult = { result -> deliverResult(session, result, onDone) },
        )
    }
    val torchControl = remember(recorder) { AVCaptureDeviceTorchControl() }
    val preferences = remember { defaultSdkUserPreferences() }
    LaunchedEffect(controller) {
        controller.markCameraReady()
        torchControl.bind(recorder.videoDevice)
    }
    CompositionLocalProvider(LocalTutorialAssetPaths provides tutorialAssetPaths) {
        AccelerometerCaptureScreen(
            controller = controller,
            onCancel = {
                scope.launch {
                    try { session.cancel() } finally { onCancel() }
                }
            },
            torchControl = torchControl,
            userPreferences = preferences,
            cameraPreview = {
                UIKitView(
                    factory = {
                        val view = PreviewContainerView()
                        val layer = AVCaptureVideoPreviewLayer(session = recorder.session)
                        layer.videoGravity = AVLayerVideoGravityResizeAspectFill
                        view.previewLayer = layer
                        view.layer.addSublayer(layer)
                        view
                    },
                    modifier = Modifier.fillMaxSize(),
                )
            },
            tutorialPlayer = { IosTutorialVideoPlayer() },
            tutorialIllustrations = { slot -> BundledTutorialIllustrations(slot) },
        )
    }
}

// Preview layer needs explicit frame propagation, else renders at
// (0,0,0,0) → black screen with the session still running.
private class PreviewContainerView : UIView(frame = CGRectZero.readValue()) {
    var previewLayer: AVCaptureVideoPreviewLayer? = null

    override fun layoutSubviews() {
        super.layoutSubviews()
        previewLayer?.setFrame(bounds)
    }
}

@Composable
private fun IosTutorialVideoPlayer() {
    val videoPath = LocalTutorialAssetPaths.current.videoMp4
    if (videoPath == null) {
        Box(modifier = Modifier.fillMaxWidth().aspectRatio(720f / 480f))
        return
    }
    val player = remember(videoPath) {
        AVPlayer(uRL = NSURL.fileURLWithPath(videoPath))
    }
    DisposableEffect(player) {
        val observer: NSObjectProtocol = NSNotificationCenter.defaultCenter.addObserverForName(
            name = AVPlayerItemDidPlayToEndTimeNotification,
            `object` = player.currentItem,
            queue = NSOperationQueue.mainQueue,
            usingBlock = {
                player.seekToTime(kCMTimeZero.readValue())
                player.play()
            },
        )
        onDispose {
            NSNotificationCenter.defaultCenter.removeObserver(observer)
            player.pause()
        }
    }
    UIKitView(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(720f / 480f)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x33FFFFFF)),
        factory = {
            val view = PlayerContainerView()
            val layer = AVPlayerLayer.playerLayerWithPlayer(player)
            layer.videoGravity = AVLayerVideoGravityResizeAspect
            view.playerLayer = layer
            view.layer.addSublayer(layer)
            player.play()
            view
        },
    )
}

private class PlayerContainerView : UIView(frame = CGRectZero.readValue()) {
    var playerLayer: AVPlayerLayer? = null

    // AVPlayerLayer doesn't auto-track its host UIView's bounds; propagate.
    override fun layoutSubviews() {
        super.layoutSubviews()
        playerLayer?.setFrame(bounds)
    }
}

private suspend fun deliverResult(
    session: CaptureSession,
    result: VideoCaptureResult,
    onDone: (CaptureSession) -> Unit,
) {
    session.submit(result)
    onDone(session)
}
