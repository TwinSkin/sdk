package com.twinskin.sdk.ui.annotation_editor.delineation.i18n

import platform.Foundation.NSLocale
import platform.Foundation.currentLocale
import platform.Foundation.languageCode

internal actual fun resolveLocale(): String =
    NSLocale.currentLocale.languageCode.takeIf { it.isNotEmpty() } ?: "en"
