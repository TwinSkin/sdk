@file:OptIn(ExperimentalForeignApi::class, com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.renderer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.UIKitView
import com.twinskin.sdk.view.Asset3D
import kotlinx.cinterop.ExperimentalForeignApi
import platform.CoreGraphics.CGRectMake
import platform.UIKit.UIView

/**
 * iOS renderer: delegates to [Ios3DRenderer.factory], registered by the
 * Swift `sdk-ios` package at SDK init time. See [Ios3DRenderer] for details.
 */
@Composable
@Suppress("DEPRECATION") // Compose Multiplatform 1.10 still ships the deprecated UIKitView API as the only stable interop entry point.
public actual fun Model3DViewer(
    asset: Asset3D,
    modifier: Modifier,
) {
    val factory = Ios3DRenderer.factory
    if (factory == null) {
        NoRendererPlaceholder(modifier)
        return
    }
    key(asset.location) {
        UIKitView(
            modifier = modifier,
            factory = { factory(asset.location) },
            update = { /* host handles its own recompose */ },
        )
    }
}

@Composable
private fun NoRendererPlaceholder(modifier: Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF1A1F24))
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "iOS 3D renderer not registered.\n" +
                "Integrators must register a factory on " +
                "Ios3DRenderer — the sdk-ios package does this " +
                "automatically in TwinSkin.initialize(_:).",
            color = Color.White,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Suppress("unused")
private fun zeroFrame() = CGRectMake(0.0, 0.0, 0.0, 0.0)

@Suppress("unused")
private fun noopUIView(): UIView = UIView(frame = zeroFrame())
