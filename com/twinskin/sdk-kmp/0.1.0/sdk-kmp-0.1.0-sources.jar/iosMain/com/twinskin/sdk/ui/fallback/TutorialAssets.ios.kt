@file:OptIn(kotlinx.cinterop.ExperimentalForeignApi::class)

package com.twinskin.sdk.ui.fallback

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.usePinned
import org.jetbrains.skia.Image
import platform.Foundation.NSData
import platform.Foundation.dataWithContentsOfFile
import platform.posix.memcpy

@Composable
internal actual fun rememberBundledTutorialBitmap(name: TutorialAssetName): ImageBitmap? {
    val paths = LocalTutorialAssetPaths.current
    val path = when (name) {
        TutorialAssetName.Do -> paths.doPng
        TutorialAssetName.Dont -> paths.dontPng
    } ?: return null
    return remember(path) { loadBundledImage(path) }
}

private fun loadBundledImage(path: String): ImageBitmap? {
    val data = NSData.dataWithContentsOfFile(path) ?: return null
    val len = data.length.toInt()
    if (len == 0) return null
    val bytes = ByteArray(len)
    bytes.usePinned { pinned -> memcpy(pinned.addressOf(0), data.bytes, data.length) }
    return runCatching { Image.makeFromEncoded(bytes).toComposeImageBitmap() }.getOrNull()
}
