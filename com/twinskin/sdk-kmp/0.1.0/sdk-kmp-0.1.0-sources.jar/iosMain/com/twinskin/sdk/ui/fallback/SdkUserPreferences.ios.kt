package com.twinskin.sdk.ui.fallback

import platform.Foundation.NSUserDefaults

/**
 * `UserDefaults`-backed iOS actual. Uses a private suite
 * `com.twinskin.sdk.preferences` so the SDK's prefs live alongside
 * (but not inside) the host app's `standardUserDefaults`.
 */
public class NSUserDefaultsSdkUserPreferences(
    suiteName: String = SUITE_NAME,
) : SdkUserPreferences {

    private val defaults: NSUserDefaults =
        // K/N binding declares the suite-name initialiser as nullable
        // in Obj-C, but in practice returns a fresh instance for any
        // valid (non-empty) suite name. Treat it as non-null.
        NSUserDefaults(suiteName = suiteName)

    override var tutorialDontShowAgain: Boolean
        get() = defaults.boolForKey(KEY_TUTORIAL_DONT_SHOW_AGAIN)
        set(value) {
            defaults.setBool(value, forKey = KEY_TUTORIAL_DONT_SHOW_AGAIN)
        }

    public companion object {
        public const val SUITE_NAME: String = "com.twinskin.sdk.preferences"
        public const val KEY_TUTORIAL_DONT_SHOW_AGAIN: String = "tutorialDontShowAgain"
    }
}

public actual fun defaultSdkUserPreferences(): SdkUserPreferences =
    NSUserDefaultsSdkUserPreferences()
