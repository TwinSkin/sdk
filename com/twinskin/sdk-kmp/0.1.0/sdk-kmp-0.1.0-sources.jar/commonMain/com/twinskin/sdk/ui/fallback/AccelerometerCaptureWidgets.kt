package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.capture.fallback.Pie
import kotlin.math.min

/**
 * 8-segment pie-ring overlay surfaced during `RecordingVideo`. Each
 * 45° arc fills the moment the underlying boolean in [pie] flips.
 * Mirror of the web_app's `CapturedAnglesWidget`
 * (`packages/web_app/lib/src/ui/widgets/video_capture_ring.dart`).
 *
 * Animation polish (animate-on-fill etc.) is out of scope per the
 * #504 ticket — v1 ships a simple binary fill.
 */
@Composable
public fun PieRing(
    pie: Pie,
    modifier: Modifier = Modifier,
    primaryColor: Color = LocalAccelerometerCaptureColors.current.orbit,
    inactiveColor: Color = LocalAccelerometerCaptureColors.current.orbitInactive,
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val diameter = min(w, h)
            val stroke = diameter * 0.06f
            val radius = diameter / 2f - stroke
            val center = Offset(w / 2f, h / 2f)
            val sectors = pie.capturedAngles.size
            val sweepDeg = 360f / sectors
            val arcSize = Size(radius * 2f, radius * 2f)
            val topLeft = Offset(center.x - radius, center.y - radius)
            // Small inter-sector gap so the ring reads as 8 segments
            // (rather than a single ring) before any fill lands.
            val gapDeg = sweepDeg * 0.06f
            for (i in 0 until sectors) {
                val startDeg = i * sweepDeg + gapDeg / 2f
                val sweep = sweepDeg - gapDeg
                val color = if (pie.capturedAngles[i]) primaryColor else inactiveColor
                drawArc(
                    color = color,
                    startAngle = startDeg,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke),
                )
            }
        }
        val percent = (pie.percentage * 100).toInt()
        Text(
            text = if (percent >= 100) "100%" else "$percent%",
            color = LocalAccelerometerCaptureColors.current.onPrimary,
            fontSize = 18.sp,
        )
    }
}

/**
 * Threshold at which [CountdownRing] flips from `progressColor` to
 * `completeColor`. Mirrors web_app's `_CircleProgressPainter` switch
 * (`packages/web_app/lib/src/app/mobile/camera/ui/capture_button.dart:109`).
 */
internal const val COUNTDOWN_RING_COMPLETE_THRESHOLD: Float = 0.79f

/**
 * Single-sweep countdown ring drawn around the shutter during
 * `RecordingVideo`. Fill fraction is `elapsedMs / durationMs`; ring
 * colour is `progressColor` (red) under 79% and `completeColor`
 * (green) at-or-above 79%, matching web_app's `_CircleProgressPainter`.
 *
 * The web_app draws ONLY the progress arc — no background track —
 * with `StrokeCap.Round`. SDK mirrors that.
 */
@Composable
public fun CountdownRing(
    elapsedMs: Long,
    totalMs: Long,
    modifier: Modifier = Modifier,
    progressColor: Color = LocalAccelerometerCaptureColors.current.progress,
    completeColor: Color = LocalAccelerometerCaptureColors.current.progressComplete,
) {
    val progress = if (totalMs <= 0L) 0f else
        (elapsedMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f)
    val color = if (progress > COUNTDOWN_RING_COMPLETE_THRESHOLD) completeColor else progressColor
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val diameter = min(w, h)
        val stroke = diameter * 0.06f
        val radius = diameter / 2f - stroke
        val arcSize = Size(radius * 2f, radius * 2f)
        val topLeft = Offset(w / 2f - radius, h / 2f - radius)
        drawArc(
            color = color,
            startAngle = -90f,
            sweepAngle = 360f * progress,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = stroke, cap = StrokeCap.Round),
        )
    }
}

/**
 * Web-app-parity shutter affordance: a hairline ring around an inner
 * dot, where the dot colour carries the phase signal — light in
 * `ReadyForPhoto`, error-coloured in `PhotoTaken` so the operator
 * sees "armed for video" without re-reading the screen. Mirrors the
 * web_app's `CircularProgressButton` two-layer composition
 * (`packages/web_app/lib/src/app/mobile/camera/ui/capture_button.dart`).
 *
 * Default sizes follow the web_app: 70 dp outer ring, 60 dp inner dot,
 * 2 dp stroke.
 */
@Composable
internal fun ShutterIndicator(
    ringColor: Color,
    dotColor: Color,
    modifier: Modifier = Modifier,
    outerSizeDp: Int = 70,
    innerSizeDp: Int = 60,
) {
    Box(modifier = modifier.size(outerSizeDp.dp), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(outerSizeDp.dp)
                .border(width = 2.dp, color = ringColor, shape = CircleShape),
        )
        Box(
            modifier = Modifier
                .size(innerSizeDp.dp)
                .background(color = dotColor, shape = CircleShape),
        )
    }
}

/**
 * Filled inner circle drawn inside [CountdownRing] during
 * `RecordingVideo` so the operator keeps a visible tap target inside
 * the progress arc. Mirrors web_app's `CircularProgressButton` inner
 * 60-dp `onSurface` circle (`capture_button.dart:74-82`); the dedicated
 * stop button was dropped in MR-4 (AC-3.2) so the ring itself is the
 * tap target.
 */
@Composable
internal fun RecordingInnerIndicator(
    color: Color,
    modifier: Modifier = Modifier,
    sizeDp: Int = 60,
) {
    Box(
        modifier = modifier
            .size(sizeDp.dp)
            .background(color = color, shape = CircleShape),
    )
}
