@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.view.resolvers

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.crypto.sha256
import com.twinskin.sdk.view.Asset3D
import com.twinskin.sdk.view.Asset3DFormat
import com.twinskin.sdk.view.CaptureCredentialsException
import com.twinskin.sdk.view.CaptureResolver
import com.twinskin.sdk.view.LoadProgress
import com.twinskin.sdk.view.ResolvedCapture
import com.twinskin.sdk.view.ResolverEvent
import com.twinskin.sdk.view.cachedFileExists
import com.twinskin.sdk.view.downloadToPath
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow

/**
 * Downloads a GLB from [url] into [cacheDir] and emits the local path
 * when done.
 *
 * Progress is reported via [ResolverEvent.Progress]; the terminal event
 * carries the resolved [Asset3D].
 *
 * Headers from [headersProvider] are attached to the initial GET only;
 * HTTP redirects drop them so sensitive tokens don't leak to
 * third-party hosts.
 *
 * ## Cache semantics
 *
 * The on-disk filename is derived deterministically from [url] (via
 * [stableUrlHash]) and stable across resolver instances. On a cache
 * hit, the existing file is returned without re-downloading — the
 * `headersProvider` is also skipped, so re-opening the same capture
 * is effectively free and works offline.
 *
 * This works because asset URLs returned by the SDK server embed an
 * immutable S3 key (`<env>/<captureId>/<run>/preview.glb`): the URL
 * changes whenever the bytes change, so the stable filename is also
 * a stable content identifier.
 *
 * Cache eviction is handled at the storage layer:
 * [com.twinskin.sdk.view.cleanupStaleViewCaptureFiles] ages out
 * entries older than [com.twinskin.sdk.view.STALE_VIEW_CAPTURE_WINDOW_MS]
 * on every SDK init, on top of OS-level cache reclamation under
 * storage pressure. Re-downloads after eviction are transparent
 * since filenames are content-addressed.
 */
@TwinSkinInternalApi
public class HttpGlbResolver(
    private val url: String,
    private val cacheDir: String,
    private val fileName: String = "glb-${stableUrlHash(url)}.glb",
    private val headersProvider: suspend () -> Map<String, String> = { emptyMap() },
    private val logger: SdkLogger? = null,
) : CaptureResolver {

    override fun resolve(): Flow<ResolverEvent> = channelFlow {
        val destPath = "$cacheDir/$fileName"

        if (cachedFileExists(destPath)) {
            logger?.log("[viewCapture glb $url] cache HIT at $destPath; skipping download")
            send(
                ResolverEvent.Resolved(
                    ResolvedCapture(
                        model = Asset3D(location = destPath, format = Asset3DFormat.GLB),
                    ),
                ),
            )
            return@channelFlow
        }

        send(ResolverEvent.Progress(LoadProgress.ResolvingCredentials))
        val headers = try {
            headersProvider()
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            logger?.log("[viewCapture glb $url] credentials FAILED", t)
            throw CaptureCredentialsException(t)
        }
        logger?.log(
            "[viewCapture glb $url] credentials resolved (${headers.size} header(s)); starting download"
        )
        send(ResolverEvent.Progress(LoadProgress.Downloading(bytesRead = 0, total = null)))
        try {
            downloadToPath(url, destPath, headers) { bytesRead, total ->
                trySend(ResolverEvent.Progress(LoadProgress.Downloading(bytesRead, total)))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            logger?.log(
                "[viewCapture glb $url] download FAILED: ${t::class.simpleName}: ${t.message}",
                t,
            )
            throw t
        }
        logger?.log("[viewCapture glb $url] download complete → $destPath")
        send(
            ResolverEvent.Resolved(
                ResolvedCapture(
                    model = Asset3D(location = destPath, format = Asset3DFormat.GLB),
                ),
            ),
        )
    }
}

/**
 * Stable, lowercase hex hash of [url] suitable for use as a filename
 * stem. Truncated SHA-256 (first 8 bytes → 16 hex chars, ~64 bits)
 * gives a birthday-collision bound of ~2^32 URLs — well above what any
 * single device's cache will ever hold, while keeping filenames short.
 * The same URL maps to the same filename across Android, iOS and JVM.
 */
internal fun stableUrlHash(url: String): String {
    val digest = sha256(url.encodeToByteArray())
    val sb = StringBuilder(16)
    for (i in 0 until 8) {
        val b = digest[i].toInt() and 0xff
        sb.append(b.toString(16).padStart(2, '0'))
    }
    return sb.toString()
}
