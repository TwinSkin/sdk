package com.twinskin.sdk.sdk_client

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Internal, parsed view of the `POST /api/sdk/sessions/token` response
 * body the integrator forwards through [SdkAuthorizationProvider].
 * Integrators never construct or return this type — they deal only in
 * the opaque JSON string.
 *
 * [token] is the unified session JWT: sent as `Authorization: Bearer`
 * on every upload call AND handed to PowerSync as the sync credential.
 *
 * Timestamps are ISO-8601 strings on the wire (matching the server's
 * JSON encoding); callers who need a typed moment-in-time can parse
 * them themselves.
 */
@Serializable
internal data class MintSessionTokenResponse(
    val token: String,
    @SerialName("expires_at") val expiresAt: String,
)

private val sessionTokenJson = Json { ignoreUnknownKeys = true }

/**
 * Parse the opaque payload returned by
 * [SdkAuthorizationProvider.fetchSessionToken]. Throws with a clear
 * diagnostic when the JSON is malformed — that indicates the
 * integrator's backend is not forwarding Twinskin's session-token
 * response shape.
 */
internal fun parseSessionTokenPayload(json: String): MintSessionTokenResponse =
    try {
        sessionTokenJson.decodeFromString(MintSessionTokenResponse.serializer(), json)
    } catch (e: Exception) {
        throw IllegalStateException(
            "SdkAuthorizationProvider.fetchSessionToken returned a payload " +
                "the SDK could not parse as a Twinskin session-token response. " +
                "Expected the verbatim body of POST /api/sdk/sessions/token.",
            e,
        )
    }
