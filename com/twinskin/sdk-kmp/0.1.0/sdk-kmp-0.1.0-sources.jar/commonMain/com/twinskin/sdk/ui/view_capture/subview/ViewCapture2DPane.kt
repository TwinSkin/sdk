@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.capture.SdkMeasurement
import com.twinskin.sdk.ui.annotation_editor.loadImageFromPath
import com.twinskin.sdk.view.Image2DAsset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Host for [Capture2DView] that knows how to turn an [Image2DAsset]
 * (path on disk) into the [ImageBitmap] the stateless view needs.
 *
 * Decoding happens off the main thread; while it's in flight, the
 * underlying [Capture2DView] shows its built-in loading indicator.
 * If the path changes between recompositions (the resolver may
 * download a fresh image as PowerSync ticks), the bitmap is
 * re-decoded from the new path.
 *
 * The "Edit contour" affordance is owned by the parent
 * [ViewCaptureReadyView] as a Scaffold-anchored FAB, so it's shared with
 * the 3D tab and not drawn here.
 */
@TwinSkinInternalApi
@Composable
public fun ViewCapture2DPane(
    image2D: Image2DAsset?,
    annotation: SdkAnnotation?,
    measurement: SdkMeasurement?,
    modifier: Modifier = Modifier,
    isSavingAnnotation: Boolean = false,
    showReadout: Boolean = true,
) {
    val location = image2D?.location
    var bitmap by remember(location) { mutableStateOf<ImageBitmap?>(null) }
    var loadError by remember(location) { mutableStateOf<String?>(null) }

    LaunchedEffect(location) {
        if (location == null) {
            bitmap = null
            loadError = null
            return@LaunchedEffect
        }
        try {
            bitmap = withContext(Dispatchers.Default) { loadImageFromPath(location) }
            loadError = null
        } catch (t: Throwable) {
            TwinSkinSdk.requireComponent().logger.log("Failed to load 2D image at $location", t)
            bitmap = null
            loadError = "Couldn't load the image."
        }
    }

    val err = loadError
    if (err != null) {
        Box(
            modifier = modifier.fillMaxSize().background(Color.Black).padding(16.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(err, color = MaterialTheme.colorScheme.error)
        }
        return
    }
    // M15.14 — promotes the prior top-left "Saving annotation…" pill into a
    // full-pane backdrop + centered spinner inside Capture2DView, AND hides
    // the (stale) annotation overlay while a submit is in flight.
    //
    // The "Edit contour" affordance is no longer drawn here — it's a
    // Scaffold-anchored FAB owned by ViewCaptureReadyView so it sits
    // consistently across the 2D and 3D tabs.
    Capture2DView(
        image = bitmap,
        annotation = annotation,
        measurement = measurement,
        modifier = modifier.fillMaxSize(),
        isSubmitting = isSavingAnnotation,
        showReadout = showReadout,
    )
}
