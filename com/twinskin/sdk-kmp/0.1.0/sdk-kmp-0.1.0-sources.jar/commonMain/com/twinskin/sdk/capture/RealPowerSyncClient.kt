package com.twinskin.sdk.capture

import com.powersync.PowerSyncDatabase
import com.powersync.connectors.PowerSyncBackendConnector
import com.powersync.db.SqlCursor
import com.twinskin.sdk.SdkLogger
import kotlin.time.Duration.Companion.hours
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Concrete [PowerSyncClient] built on top of a real
 * [PowerSyncDatabase]. Platform code (Android / iOS) constructs the
 * [PowerSyncDatabase] — only those layers know how to build a
 * platform `DatabaseDriverFactory` — and hands it here so the rest of
 * the server-state machinery stays in `commonMain`.
 *
 * The constructor kicks off [PowerSyncDatabase.connect] on the
 * provided [scope] so the watch query starts receiving rows as soon
 * as PowerSync establishes the first sync checkpoint. The connector
 * owns the auth round-trip, not this class.
 */
internal class RealPowerSyncClient(
    private val database: PowerSyncDatabase,
    connector: PowerSyncBackendConnector,
    scope: CoroutineScope,
    private val logger: SdkLogger? = null,
) : PowerSyncClient {

    init {
        scope.launch {
            try {
                database.connect(connector)
                // `sdk_captures` is a non-auto-subscribe stream — the server
                // only replicates rows to clients that explicitly subscribe.
                // Without this call the watch query stays empty forever.
                database.syncStream(SdkCapturePowerSyncSchema.STREAM_NAME, emptyMap())
                    .subscribe(ttl = 1.hours)
            } catch (t: Throwable) {
                logger?.log(
                    "PowerSync connect/subscribe failed for stream " +
                        "'${SdkCapturePowerSyncSchema.STREAM_NAME}'",
                    t,
                )
            }
        }
    }

    override fun watchCaptures(subjectRef: String): Flow<List<CaptureEntry>> =
        // Force the watch onto a background dispatcher — the cursor
        // mapper runs on whatever thread PowerSync uses, which on JVM
        // is a shared pool but on Darwin can be the main queue if the
        // caller collects from a SwiftUI `.task`.
        flow {
            val upstream = database.watch(
                sql = watchSdkCapturesSql(),
                parameters = emptyList(),
                throttleMs = 16L,
            ) { cursor -> cursorToRow(cursor, logger).toCaptureEntry(logger) }
            upstream.collect { emit(it) }
        }.flowOn(Dispatchers.Default)

    override suspend fun close() {
        database.close()
    }
}

/**
 * Stable on-disk SQLite filename per subject. PowerSync writes one
 * DB file per `PowerSyncDatabase` instance; scoping by subject keeps
 * two concurrent `observeSubject` calls from racing on the same
 * file.
 *
 * The filename combines a short human-readable prefix (first 24
 * sanitized chars of `subjectRef`) with an 8-char hex hash of the
 * full ref. The hash prevents collisions between subject refs that
 * share a truncated prefix; the prefix keeps filenames greppable
 * during debugging. Kotlin's `String.hashCode()` is specified to
 * match Java's algorithm, so the filename is stable cross-platform.
 */
internal const val SDK_CAPTURES_DB_PREFIX: String = "twinskin_sdk_captures_"

internal fun sdkCapturesDbFilename(subjectRef: String): String {
    val sanitized = subjectRef.map { c ->
        if (c.isLetterOrDigit() || c == '_' || c == '-') c else '_'
    }.joinToString("")
    val prefix = if (sanitized.length <= 24) sanitized else sanitized.take(24)
    val hash = subjectRef.hashCode().toUInt().toString(16).padStart(8, '0')
    return "$SDK_CAPTURES_DB_PREFIX${prefix}_$hash.db"
}

internal fun cursorToRow(cursor: SqlCursor, logger: SdkLogger? = null): ServerCaptureRow {
    val id = cursor.getString(0) ?: run {
        logger?.log("sdk_captures.id is null — PowerSync schema drift")
        ""
    }
    val subjectRef = cursor.getString(1) ?: ""
    val status = cursor.getString(2) ?: ""
    val errorReason = cursor.getString(3)
    val lastAdvancedAtIso = cursor.getString(4) ?: ""
    val referenceImageKey = cursor.getString(5)
    val resultPreview3dGlbKey = cursor.getString(6)
    val annotationJson = cursor.getString(7)
    val resultJson = cursor.getString(8)
    val isMeasurementCalculating = (cursor.getLong(9) ?: 0L) != 0L
    val conditionType = parseConditionTypeOrNull(cursor.getString(10))
    return ServerCaptureRow(
        id = id,
        subjectRef = subjectRef,
        status = status,
        errorReason = errorReason,
        lastAdvancedAtEpochMs = iso8601ToEpochMillis(lastAdvancedAtIso) ?: 0L,
        referenceImageKey = referenceImageKey,
        resultPreview3dGlbKey = resultPreview3dGlbKey,
        annotationJson = annotationJson,
        resultJson = resultJson,
        isMeasurementCalculating = isMeasurementCalculating,
        conditionType = conditionType,
    )
}
