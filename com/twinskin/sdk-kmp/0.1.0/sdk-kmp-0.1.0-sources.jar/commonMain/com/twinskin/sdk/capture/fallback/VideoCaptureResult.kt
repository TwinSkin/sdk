package com.twinskin.sdk.capture.fallback

/** All paths must point inside [com.twinskin.sdk.capture.CaptureSession.workingDir]. */
public data class VideoCaptureResult(
    val photoPath: String,
    val videoPath: String,
    val videoMetadata: VideoMetaData,
)
