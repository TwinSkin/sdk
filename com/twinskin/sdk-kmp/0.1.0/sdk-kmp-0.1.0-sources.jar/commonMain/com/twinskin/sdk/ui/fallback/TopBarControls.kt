package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FlashAuto
import androidx.compose.material.icons.outlined.FlashOff
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material.icons.outlined.QuestionMark
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

@Composable
internal fun FlashButton(
    mode: FlashMode,
    onClick: () -> Unit,
) {
    val colors = LocalAccelerometerCaptureColors.current
    val icon: ImageVector = when (mode) {
        FlashMode.Off -> Icons.Outlined.FlashOff
        FlashMode.Auto -> Icons.Outlined.FlashAuto
        FlashMode.On -> Icons.Outlined.FlashOn
    }
    Box(
        modifier = Modifier
            .size(36.dp)
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = when (mode) {
                FlashMode.Off -> "Flash off" /* video_capture_flash_off */
                FlashMode.Auto -> "Flash auto" /* video_capture_flash_auto */
                FlashMode.On -> "Flash on" /* video_capture_flash_on */
            },
            tint = colors.onPrimary,
        )
    }
}

@Composable
internal fun HelpButton(onClick: () -> Unit) {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        modifier = Modifier
            .size(36.dp)
            .border(width = 2.dp, color = colors.onPrimary, shape = CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Outlined.QuestionMark,
            contentDescription = "Help", /* video_capture_help */
            tint = colors.onPrimary,
        )
    }
}
