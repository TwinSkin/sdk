package com.twinskin.sdk.ui.annotation_editor.delineation.help

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.HelpSlide
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.Strings
import kotlinx.coroutines.launch

/**
 * Paginated help dialog for one of the four flow screens (spec
 * §M12). Renders the supplied [slides] list inside a Material3
 * [AlertDialog] with a [HorizontalPager] for slide-by-slide
 * navigation:
 *
 *  - Per-page: title (titleMedium) → optional Compose-drawn
 *    diagram → body (bodyMedium).
 *  - Bottom row: page-indicator dots + previous / next arrows on
 *    multi-slide decks; the "Next" arrow swaps to a "Close" button
 *    on the last slide.
 *  - Single-slide case: skips the pager chrome entirely.
 *
 * Strings flow in via [strings]: the arrow contentDescriptions,
 * close button label, and (in the future) localised slide content
 * all live in the [Strings] interface.
 */
@Composable
internal fun HelpDialog(
    slides: List<HelpSlide>,
    strings: Strings,
    onClose: () -> Unit,
) {
    if (slides.isEmpty()) {
        // Defensive — shouldn't happen because every help-screen
        // list has at least one slide. Close immediately rather
        // than render an empty dialog.
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text(strings.helpDialogTitle) },
            text = { Text(strings.helpDialogPlaceholderBody) },
            confirmButton = {
                TextButton(onClick = onClose) { Text(strings.closeButton) }
            },
        )
        return
    }
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { slides.size })
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(strings.helpDialogTitle) },
        text = {
            Column {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxWidth(),
                ) { pageIdx ->
                    SlideContent(slide = slides[pageIdx])
                }
                if (slides.size > 1) {
                    Spacer(Modifier.height(12.dp))
                    PageIndicatorDots(
                        pageCount = slides.size,
                        currentPage = pagerState.currentPage,
                    )
                }
            }
        },
        confirmButton = {
            // The confirm button is always present. On the last slide
            // (or single-slide deck) it reads "Close"; otherwise it
            // advances the pager. The dismiss button to the left is
            // "Previous" on multi-slide decks past the first page.
            val isLast = pagerState.currentPage == slides.size - 1
            if (isLast) {
                TextButton(onClick = onClose) { Text(strings.closeButton) }
            } else {
                IconButton(onClick = {
                    scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                }) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = strings.helpNextSlide,
                    )
                }
            }
        },
        dismissButton = {
            val isFirst = pagerState.currentPage == 0
            if (slides.size > 1 && !isFirst) {
                IconButton(onClick = {
                    scope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) }
                }) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = strings.helpPreviousSlide,
                    )
                }
            }
        },
    )
}

@Composable
private fun SlideContent(slide: HelpSlide) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(slide.title, style = MaterialTheme.typography.titleMedium)
        slide.diagram?.invoke()
        Text(slide.body, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun PageIndicatorDots(pageCount: Int, currentPage: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
    ) {
        repeat(pageCount) { i ->
            val isActive = i == currentPage
            val color = if (isActive) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
            }
            Box(
                modifier = Modifier
                    .padding(horizontal = 3.dp)
                    .size(if (isActive) 10.dp else 8.dp),
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth().height(if (isActive) 10.dp else 8.dp),
                    shape = CircleShape,
                    color = color,
                ) {}
            }
            // Keep a non-zero gap even on the last dot for visual breathing.
            if (i < pageCount - 1) Spacer(Modifier.width(2.dp))
        }
    }
}
