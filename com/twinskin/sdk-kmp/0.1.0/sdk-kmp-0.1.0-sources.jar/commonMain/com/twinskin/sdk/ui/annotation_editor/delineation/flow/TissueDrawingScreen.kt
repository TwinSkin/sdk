package com.twinskin.sdk.ui.annotation_editor.delineation.flow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.annotation_editor.delineation.DelineationStore
import com.twinskin.sdk.ui.annotation_editor.polygon.canvas.DrawingCanvas
import com.twinskin.sdk.ui.annotation_editor.polygon.canvas.ZoomPanController
import com.twinskin.sdk.ui.annotation_editor.polygon.canvas.clinicalColorFor
import com.twinskin.sdk.ui.annotation_editor.polygon.draft.EditorControllerSaver
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.EditorController
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.UiSignal
import com.twinskin.sdk.ui.annotation_editor.delineation.help.HelpDialog
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.Strings
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Tissue
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound
import com.twinskin.sdk.ui.annotation_editor.delineation.ui_helpers.EditorBar
import com.twinskin.sdk.ui.annotation_editor.delineation.ui_helpers.EditorToolbar
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.HapticEvent
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.TransientHint
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.emit
import com.twinskin.sdk.ui.theme.TwinSkinColors
import kotlinx.coroutines.delay

/**
 * Screen 4 — per-type tissue drawing (spec §8). Hosts a
 * [DrawingCanvas] parameterised for the [currentType] tissue: every
 * existing wound is rendered as a read-only outline; tissues of
 * **other** types within those wounds are read-only filled
 * polygons; the controller's polygon list is the in-flight
 * **same-type** tissue list.
 *
 * **Parent-wound resolution** is delegated to [DrawingCanvas]:
 * stroke start picks the wound containing the touch-down position
 * as `confinementOutline`; reshape uses the focused tissue's
 * centroid to pick its parent wound.
 *
 * **Sync model.** Tissues are NOT mirrored to the store per-commit
 * here — instead, the controller accumulates the user's strokes
 * and the screen writes them back to the store on **Back**. This
 * is cheaper than per-commit store mutations (each tissue stroke
 * would otherwise trigger a store mutation + revision bump) and
 * matches spec §8's "draw all tissues of this type, then go back"
 * flow. The undo machinery still works inside the screen via the
 * controller's `_undoStack`.
 *
 * The screen-level `storeUndoStack` is therefore not needed here —
 * the only store mutation happens on Back, and Back is the gate
 * for tissue-list commit, not an undoable event.
 *
 * **Non-traversal haptic** mirrors WoundDrawingScreen.
 *
 * **Card-state recompute on Back** per spec §7.3: if the user
 * drew at least one tissue of this type, mark Drawn; if zero
 * tissues remain and the type was Drawn, demote to Open. Absent
 * is sacred — the user reached this screen via "Mark present"
 * which set the state to Open first, so Absent shouldn't appear
 * here on entry.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun TissueDrawingScreen(
    image: ImageBitmap,
    imageSize: Size,
    store: DelineationStore,
    currentType: TissueType,
    strings: Strings,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val controller: EditorController = rememberSaveable(saver = EditorControllerSaver) {
        // Invariant: if a tracé of the current type exists, a polygon
        // is focused. Seed with lastIndex so re-entry lands on the
        // last-drawn tissue; without this the Delete button would be
        // disabled-on-entry even when a tissue is on the canvas.
        val existing = store.tissuesOfType(currentType).map { it.outline }
        EditorController.fromState(
            polygons = existing,
            focusedIndex = if (existing.isNotEmpty()) existing.lastIndex else null,
        )
    }
    val zoomPan: ZoomPanController = remember(imageSize) {
        ZoomPanController(canvasSize = Size.Zero, imageSize = imageSize)
    }
    val snackbarHostState: SnackbarHostState = remember { SnackbarHostState() }
    val haptic = LocalHapticFeedback.current

    // TooFar transient hint — mirrors WoundDrawingScreen.
    var tooFarHint by remember { mutableStateOf<String?>(null) }
    var tooFarNonce by remember { mutableStateOf(0) }
    LaunchedEffect(tooFarNonce) {
        if (tooFarHint != null) {
            delay(1200)
            tooFarHint = null
        }
    }

    // Read-only context: wounds + tissues of OTHER types. Recomputed
    // when the store changes (e.g., a Back-then-Forward navigation).
    val otherTypeTissues: List<Tissue> = remember(store, currentType, store.revision.value) {
        store.wounds.flatMap { it.tissues }.filter { it.type != currentType }
    }

    // On Back: write the controller's polygons back to the store as
    // tissues of this type, then recompute the card state. The
    // DisposableEffect's onDispose fires when the composable leaves
    // composition — which happens on navigation back from the screen.
    DisposableEffect(controller, store, currentType) {
        onDispose {
            commitTissuesToStore(store, currentType, controller.polygons)
        }
    }

    // Non-traversal haptic on null→non-null transition only.
    LaunchedEffect(controller) {
        var prev: Offset? = null
        snapshotFlow { controller.lastStrokeClampContact.value }.collect { current ->
            if (current != null && prev == null) {
                haptic.emit(HapticEvent.NonTraversalContact)
            }
            prev = current
        }
    }

    // Signal drain. The tissue screen doesn't mirror commits to the
    // store per-stroke (commit happens on Back), so most signals
    // here are haptic-only or snackbar-only.
    LaunchedEffect(controller) {
        snapshotFlow { controller.revision.value }.collect {
            while (true) {
                val signal = controller.consumeSignal() ?: break
                when (signal) {
                    UiSignal.TooFarFromOpenStroke -> {
                        tooFarHint = strings.tooFarFromOpenStroke
                        tooFarNonce += 1
                    }
                    is UiSignal.StrokeClosed -> haptic.emit(HapticEvent.StrokeCommit)
                    is UiSignal.ReshapeCommitted -> haptic.emit(HapticEvent.ReshapeCommit)
                    is UiSignal.PolygonDeleted -> haptic.emit(HapticEvent.DeleteConfirmed)
                    is UiSignal.UndoApplied -> Unit
                }
            }
        }
    }

    @Suppress("UNUSED_VARIABLE") val rev = controller.revision.value

    val typeName = strings.tissueTypeNames[currentType] ?: currentType.wire
    var showHelp by remember { mutableStateOf(false) }

    Surface(modifier = modifier.fillMaxSize(), color = TwinSkinColors.Surface) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                EditorBar(
                    title = strings.tissueDrawingTitle(typeName),
                    onBack = onBack,
                    backContentDescription = strings.backContentDescription,
                    onHelp = { showHelp = true },
                    helpContentDescription = strings.helpContentDescription,
                )
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    // tissueParentSource = the controller's polygons typed as
                    // the current type, used by DrawingCanvas for parent-wound
                    // resolution on reshape gestures. polygonColorAt paints
                    // each editable polygon in the current type's clinical
                    // color.
                    val currentTissues: List<Tissue> =
                        controller.polygons.map { Tissue(currentType, it) }
                    val currentTypeColor = clinicalColorFor(currentType)
                    DrawingCanvas(
                        image = image,
                        imageSize = imageSize,
                        controller = controller,
                        zoomPan = zoomPan,
                        readOnlyWounds = store.wounds,
                        readOnlyOtherTissues = otherTypeTissues,
                        canvasContentDescription = strings.tissueCanvasContentDescription,
                        magnifierContentDescription = strings.magnifierContentDescription,
                        polygonColorAt = { currentTypeColor },
                        tissueParentSource = currentTissues,
                        openStrokeColor = currentTypeColor,
                    )
                    TransientHint(
                        text = tooFarHint,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 16.dp),
                    )
                }
                TissueLegendRow(
                    currentType = currentType,
                    currentTypeName = typeName,
                    otherTypesPresent = otherTypeTissues.map { it.type }.distinct(),
                    strings = strings,
                )
                EditorToolbar(
                    undoLabel = strings.undoButton,
                    onUndo = { controller.undo() },
                    undoEnabled = controller.undoStackSize > 0 || controller.openStroke != null,
                    deleteLabel = strings.deleteButton,
                    onDelete = { controller.deleteFocused() },
                    deleteEnabled = controller.focusedIndex != null ||
                        controller.openStroke != null,
                    // Done is the explicit forward action; the onDispose
                    // commit path persists the tissues, so onBack() is
                    // enough to surface them on the dashboard.
                    primaryLabel = strings.doneButton,
                    onPrimary = onBack,
                    primaryEnabled = true,
                )
            }
            SnackbarHost(
                snackbarHostState,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }

    if (showHelp) {
        HelpDialog(
            slides = strings.helpSlides.tissueDrawing,
            strings = strings,
            onClose = { showHelp = false },
        )
    }
}

/**
 * Prototype legend strip (`WeTissueScreen` legend row): a small
 * clinical-color square + the tissue-type name for the type being
 * drawn and for each read-only other type present on the canvas.
 *
 * Labels are the existing localised [Strings.tissueTypeNames] only —
 * the prototype's "(drawing)" / "(locked)" / "Wound outline"
 * qualifiers have no string keys, and the i18n maintenance rule
 * forbids introducing English literals outside the strings layer, so
 * the chips carry the clinical color + the type name (the load-bearing
 * signal) without the parenthetical qualifier.
 */
@Composable
private fun TissueLegendRow(
    currentType: TissueType,
    currentTypeName: String,
    otherTypesPresent: List<TissueType>,
    strings: Strings,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 22.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LegendChip(color = clinicalColorFor(currentType), label = currentTypeName, muted = false)
        for (type in otherTypesPresent) {
            if (type == currentType) continue
            val name = strings.tissueTypeNames[type] ?: type.wire
            LegendChip(color = clinicalColorFor(type), label = name, muted = true)
        }
    }
}

@Composable
private fun LegendChip(color: Color, label: String, muted: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
            modifier = Modifier.size(13.dp),
            shape = RoundedCornerShape(4.dp),
            color = color.copy(alpha = if (muted) 0.7f else 1f),
        ) {}
        Spacer(Modifier.width(7.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
            ),
            color = TwinSkinColors.Ink2.copy(alpha = if (muted) 0.7f else 1f),
        )
    }
}

private fun commitTissuesToStore(
    store: DelineationStore,
    currentType: TissueType,
    polygons: List<List<Offset>>,
) {
    // Replace tissues of [currentType] across every wound. Each
    // tissue's parent wound is implicit at the geometry level — the
    // gesture loop only seeds strokes inside a containment wound,
    // so by construction each tissue lies inside exactly one wound.
    // Parent resolution at commit uses [resolveParentWoundIdx]
    // (centroid-first, robust to tissues whose vertex 0 lands on the
    // wound boundary after a reshape reclip).
    val newAssignments: List<Pair<Int, Tissue>> = polygons.mapNotNull { outline ->
        if (outline.isEmpty()) return@mapNotNull null
        val parentIdx = resolveParentWoundIdx(outline, store.wounds)
        if (parentIdx < 0) null else parentIdx to Tissue(currentType, outline)
    }
    // Group by parent wound, then for each wound build the new
    // tissue list (other-type tissues kept verbatim, currentType
    // tissues replaced wholesale).
    val grouped: Map<Int, List<Tissue>> = newAssignments.groupBy({ it.first }, { it.second })
    for (idx in store.wounds.indices) {
        val existing = store.wounds[idx]
        val keptOthers = existing.tissues.filter { it.type != currentType }
        val newOfType = grouped[idx].orEmpty()
        val updatedTissues = keptOthers + newOfType
        if (updatedTissues != existing.tissues) {
            store.replaceWound(idx, Wound(existing.outline, updatedTissues))
        }
    }
    // Card state per spec §7.3.
    val hasAny = polygons.isNotEmpty()
    val previous = store.cardStates[currentType] ?: TissueCardState.Open
    val next = when {
        hasAny -> TissueCardState.Drawn
        previous == TissueCardState.Drawn -> TissueCardState.Open
        else -> previous
    }
    if (next != previous) store.setCardState(currentType, next)
}

/**
 * Robust parent-wound resolution for the Done-on-tissue-screen
 * commit path. Two-strategy lookup:
 *
 *  1. Area-weighted polygon centroid → pointInPolygon. Works for
 *     convex tissues and is robust to vertex 0 landing on the
 *     wound boundary after a reshape reclip.
 *  2. Majority-vertex vote — covers concave tissues whose centroid
 *     lands outside the polygon (e.g. a U-shape with the centroid
 *     in the open mouth). Ties resolve to the lowest wound index.
 *
 * Returns the wound's index, or -1 if the tissue has no contact
 * with any wound (the gesture loop's containment gating shouldn't
 * allow this, but defended).
 */
internal fun resolveParentWoundIdx(
    outline: List<Offset>,
    wounds: List<Wound>,
): Int {
    if (outline.isEmpty() || wounds.isEmpty()) return -1

    val centroid = com.twinskin.sdk.geometry.centroid(outline)
    val byCentroid = wounds.indexOfFirst {
        com.twinskin.sdk.geometry.pointInPolygon(centroid, it.outline)
    }
    if (byCentroid >= 0) return byCentroid

    val voteCount = IntArray(wounds.size)
    for (v in outline) {
        for (i in wounds.indices) {
            if (com.twinskin.sdk.geometry.pointInPolygon(v, wounds[i].outline)) {
                voteCount[i]++
                break
            }
        }
    }
    val maxVotes = voteCount.maxOrNull() ?: 0
    if (maxVotes > 0) return voteCount.indexOf(maxVotes)
    return -1
}
