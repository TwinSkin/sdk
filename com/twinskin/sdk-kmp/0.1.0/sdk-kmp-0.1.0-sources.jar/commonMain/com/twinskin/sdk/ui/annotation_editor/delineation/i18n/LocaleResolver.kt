package com.twinskin.sdk.ui.annotation_editor.delineation.i18n

/**
 * The host platform's current language code, normalised to a
 * lowercase 2-letter form when possible (e.g., "en", "fr", "nl",
 * "de"). Implementation pulls from `Locale.getDefault().language`
 * on Android/JVM and `NSLocale.currentLocale.languageCode` on iOS.
 *
 * Falls back to "en" when the platform reports an empty or
 * malformed locale.
 */
internal expect fun resolveLocale(): String

/**
 * Dispatches to the [Strings] implementation for [locale]. Today
 * every locale resolves to [EnStrings]; the [locale] argument is
 * accepted (and normalised) so the dispatch site is already in
 * place when FR/NL/DE content lands in v1.1.
 */
// TODO(v1.1): add FR/NL/DE branches by reintroducing the lowercase + region-stripped lookup.
@Suppress("UNUSED_PARAMETER")
internal fun stringsFor(locale: String): Strings = EnStrings
