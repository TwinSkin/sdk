@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.GenericMeasurement
import com.twinskin.sdk.capture.SdkMeasurement
import com.twinskin.sdk.capture.WoundMeasurement
import kotlin.math.abs
import kotlin.math.roundToLong

/**
 * One measurement block per annotated region (spec §Viewer / §Measure).
 *
 * A capture can carry several regions — every polygon the user traces in the
 * generic editor, or every wound in the delineation flow, produces its own
 * [com.twinskin.sdk.capture.RegionMeasurement]. The viewer must surface all of
 * them, not just the first; this section iterates the full
 * [SdkMeasurement.regions] list and labels each "Region N" when there is more
 * than one.
 *
 * Shared by the 2D pane ([Capture2DView]) and the 3D tab's details
 * ([ViewCaptureReadyView]) so both render measurements identically.
 */
@TwinSkinInternalApi
@Composable
public fun MeasurementsSection(
    measurement: SdkMeasurement,
    modifier: Modifier = Modifier,
    isSubmitting: Boolean = false,
) {
    val readouts = measurement.toMeasurementReadouts()
    if (readouts.isEmpty()) return
    val showRegionLabels = readouts.size > 1
    Column(
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = if (showRegionLabels) "Measurements" else "Measurement",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
        )
        readouts.forEachIndexed { index, readout ->
            MeasurementRegionRows(
                readout = readout,
                regionLabel = if (showRegionLabels) "Region ${index + 1}" else null,
                isSubmitting = isSubmitting,
            )
        }
    }
}

/** Per-region measurement readout in display order. */
internal data class MeasurementReadout(
    val surfaceMm2: Double,
    val perimeterMm: Double?,
    val maxDepthMm: Double?,
    val volumeMm3: Double?,
)

internal fun SdkMeasurement.toMeasurementReadouts(): List<MeasurementReadout> = when (this) {
    is GenericMeasurement -> regions.map {
        MeasurementReadout(it.surfaceMm2, it.perimeterMm, it.maxDepthMm, it.volumeMm3)
    }
    is WoundMeasurement -> regions.map {
        MeasurementReadout(it.surfaceMm2, it.perimeterMm, it.maxDepthMm, it.volumeMm3)
    }
}

@Composable
private fun MeasurementRegionRows(
    readout: MeasurementReadout,
    regionLabel: String?,
    isSubmitting: Boolean = false,
) {
    // M15.18 — while a submit is in flight the cached measurement is the
    // PRE-Validate value, so each value cell is swapped for a "Calculating…"
    // placeholder (labels stay so the panel structure is recognizable).
    val rows = buildList {
        add("Surface" to (if (isSubmitting) null else formatMm2(readout.surfaceMm2)))
        if (isSubmitting || readout.perimeterMm != null) {
            add("Perimeter" to (if (isSubmitting) null else formatMm(readout.perimeterMm!!)))
        }
        if (isSubmitting || readout.maxDepthMm != null) {
            add("Max depth" to (if (isSubmitting) null else formatMm(readout.maxDepthMm!!)))
        }
        if (isSubmitting || readout.volumeMm3 != null) {
            add("Volume" to (if (isSubmitting) null else formatMm3(readout.volumeMm3!!)))
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (regionLabel != null) {
            Text(
                regionLabel,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Medium,
            )
        }
        for ((label, value) in rows) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(label, style = MaterialTheme.typography.bodyMedium)
                if (value == null) {
                    CalculatingText(
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Normal,
                    )
                } else {
                    Text(
                        value,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
    }
}

// Format helpers (commonMain has no printf-style float formatter).

private fun formatMm(valueMm: Double): String =
    if (valueMm >= 10) "${roundTo1(valueMm / 10)} cm" else "${roundTo1(valueMm)} mm"

private fun formatMm2(valueMm2: Double): String {
    val cm2 = valueMm2 / 100.0
    return if (cm2 >= 1) "${roundTo2(cm2)} cm²" else "${roundTo1(valueMm2)} mm²"
}

private fun formatMm3(valueMm3: Double): String {
    val cm3 = valueMm3 / 1000.0
    return if (cm3 >= 1) "${roundTo2(cm3)} cm³" else "${roundTo1(valueMm3)} mm³"
}

private fun roundTo1(v: Double): String = v.formatFixed(decimals = 1)
private fun roundTo2(v: Double): String = v.formatFixed(decimals = 2)

private fun Double.formatFixed(decimals: Int): String {
    var factor = 1L
    repeat(decimals) { factor *= 10 }
    val scaled = (this * factor).roundToLong()
    val sign = if (scaled < 0) "-" else ""
    val mag = abs(scaled)
    val frac = (mag % factor).toString().padStart(decimals, '0').trimEnd('0')
    return if (frac.isEmpty()) "$sign${mag / factor}" else "$sign${mag / factor}.$frac"
}
