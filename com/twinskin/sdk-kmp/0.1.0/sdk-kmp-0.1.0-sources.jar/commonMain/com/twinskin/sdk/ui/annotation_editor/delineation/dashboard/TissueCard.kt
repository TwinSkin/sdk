package com.twinskin.sdk.ui.annotation_editor.delineation.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.Strings
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState
import com.twinskin.sdk.ui.theme.BrandCard
import com.twinskin.sdk.ui.theme.TwinSkinColors

/**
 * Dashboard card for one of the three known tissue types (spec §7.1),
 * rebuilt against the Claude Design prototype `TissueCard`
 * (`screens_wound_editor.jsx`):
 *
 *  - **Top row** in every state: a clinical-color swatch, the type
 *    name (16 sp, w700), and — when [TissueCardState.Drawn] — the
 *    large percentage (20 sp, w700) pushed to the trailing edge.
 *  - **Button row** in every state: a teal "Draw area" / "Edit"
 *    button on a `tintHi` fill (with a pin / ruler glyph), beside a
 *    "Not present" toggle that flips to a teal-outlined "✓ Not
 *    present" when the card is [TissueCardState.Absent].
 *  - The whole card dims to 60% opacity when Absent.
 *
 * **Edit-on-Absent semantics.** The "Draw area" / "Edit" button on
 * an Absent card un-Absents the type and navigates to the drawing
 * screen, so it routes through [onMarkPresent] (the dispatcher
 * transitions to Open and navigates). On a Drawn card it routes
 * through [onEdit] (navigate only); on an Open card it routes
 * through [onAdd].
 *
 * Per the i18n maintenance rule, every label flows through
 * [Strings]. The prototype's per-state descriptive subtitle
 * ("N% of wound area", "Not delineated yet", "Marked not present")
 * has no string key in the locked [Strings] surface, so it is
 * omitted here rather than hardcoded — the clinical color swatch,
 * the type name, the percentage, and the Absent toggle state carry
 * the same information non-textually / through existing keys.
 */
@Composable
internal fun TissueCard(
    state: TissueCardState,
    percentage: Int,
    tissueTypeName: String,
    /**
     * The clinical color for this tissue type (from
     * `painters.kt#clinicalColorFor`). Rendered as a legend swatch so
     * color is never the sole signal — it pairs with the type name and
     * the % (spec §A11y). Passed in rather than re-derived so the
     * clinical color stays authored in one place.
     */
    colorDot: Color,
    strings: Strings,
    onAdd: () -> Unit,
    onEdit: () -> Unit,
    onMarkAbsent: () -> Unit,
    onMarkPresent: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val drawn = state == TissueCardState.Drawn
    val absent = state == TissueCardState.Absent
    BrandCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .alpha(if (absent) 0.6f else 1f),
    ) {
        Column(modifier = Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ColorSwatch(colorDot, size = 16.dp)
                Spacer(Modifier.width(12.dp))
                Text(
                    text = tissueTypeName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                    ),
                    color = TwinSkinColors.Ink,
                    modifier = Modifier.weight(1f),
                )
                if (drawn) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "$percentage",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                            ),
                            color = TwinSkinColors.Ink,
                        )
                        Text(
                            text = "%",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = TwinSkinColors.Ink2,
                            modifier = Modifier.padding(start = 1.dp, bottom = 2.dp),
                        )
                    }
                }
            }
            Spacer(Modifier.height(13.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Draw area / Edit — teal label on a tintHi fill.
                TintedActionButton(
                    label = if (drawn || absent) strings.tissueCardEdit
                    else strings.tissueCardAddTissue,
                    icon = if (drawn || absent) Icons.Filled.Edit else Icons.Outlined.LocationOn,
                    onClick = {
                        when {
                            drawn -> onEdit()
                            absent -> onMarkPresent()
                            else -> onAdd()
                        }
                    },
                    modifier = Modifier.weight(1f),
                )
                // Not present / ✓ Not present toggle.
                AbsentToggleButton(
                    label = strings.tissueCardMarkAbsent,
                    absent = absent,
                    onClick = {
                        if (absent) onMarkPresent() else onMarkAbsent()
                    },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun ColorSwatch(color: Color, size: androidx.compose.ui.unit.Dp) {
    val needsBorder = color == TwinSkinColors.TissueNecrosis
    Surface(
        modifier = Modifier
            .size(size)
            .then(
                if (needsBorder) {
                    Modifier.border(
                        BorderStroke(1.dp, Color(0xFF555555)),
                        RoundedCornerShape(5.dp),
                    )
                } else {
                    Modifier
                },
            ),
        shape = RoundedCornerShape(5.dp),
        color = color,
    ) {}
}

@Composable
private fun TintedActionButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        color = TwinSkinColors.TintHi,
    ) {
        Row(
            modifier = Modifier.padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TwinSkinColors.Teal,
                modifier = Modifier.size(16.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                ),
                color = TwinSkinColors.Teal,
            )
        }
    }
}

@Composable
private fun AbsentToggleButton(
    label: String,
    absent: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val borderColor = if (absent) TwinSkinColors.Teal else TwinSkinColors.Line
    val fill = if (absent) TwinSkinColors.TintHi else Color.Transparent
    val content = if (absent) TwinSkinColors.Teal else TwinSkinColors.Ink2
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        color = fill,
        border = BorderStroke(1.5.dp, borderColor),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (absent) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = null,
                    tint = content,
                    modifier = Modifier.size(15.dp),
                )
                Spacer(Modifier.width(5.dp))
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontSize = 13.sp,
                    fontWeight = if (absent) FontWeight.Bold else FontWeight.SemiBold,
                ),
                color = content,
            )
        }
    }
}
