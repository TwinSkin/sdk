package com.twinskin.sdk.ui.annotation_editor.polygon.engine

import androidx.compose.ui.geometry.Offset

/**
 * The user's in-progress stroke before closure (spec §6.2). Pure value
 * object — no Compose dependency, no canvas knowledge beyond the
 * `canvasStepLenPx` argument the caller computes per pointer-move.
 *
 * Samples live in image-pixel space; the cumulative length the caller
 * sees and the undo-palier boundaries live in canvas-pixel space (so
 * the per-palier feel is zoom-independent — see spec §6.2.6).
 *
 * **Paliers** (spec §6.2.4): every [PALIER_CANVAS_PX] of cumulative
 * canvas length seals one palier and starts the next. Undo always
 * pops one palier-worth at a time so the user doesn't have to undo
 * 50 individual samples to back off a 50 px arc. The example from
 * spec §6.2.4 — *"230 px traveled → 5 undos to 0 px"* — is the
 * gate test.
 *
 * **Smoothing (U10).** Raw samples come in jittery; an EMA
 * (`α = 0.4`) is applied inside [addSampleImagePx] so the model
 * never sees the raw stream. The EMA is seeded with [firstPoint] —
 * `firstPoint` itself (the constructor argument) is therefore stored
 * unchanged, and every later added sample is smoothed against the
 * running EMA. Three-sample lag at 60 Hz works out to ~50 ms,
 * imperceptible for a contour-tracing gesture; tune `α` upward
 * (less smoothing) if a future profile shows the lag mattering on
 * iOS.
 *
 * **Internal representation.** A list-of-paliers (each palier is a
 * `List<Offset>`) instead of the flat-samples + parallel-lengths
 * shape sketched in the plan. Same public contract; cleaner undo —
 * a palier rollback is a single `removeAt`/`clear`, not "find the
 * sample index that crossed N×50 px". The flat [samples] view is
 * computed by [paliersFlattened].
 */
internal class OpenStroke(initialPoint: Offset) {

    /** First sample of the stroke. Immutable; used by closure-by-proximity (spec §6.2.5). */
    val firstPoint: Offset = initialPoint

    /**
     * One element per palier; the last is the in-progress one.
     * Paliers carry only samples added via [addSampleImagePx];
     * [firstPoint] lives outside the palier list so a full rollback
     * cannot accidentally erase it.
     */
    private val _paliers: MutableList<MutableList<Offset>> =
        mutableListOf(mutableListOf())

    /** Canvas-px traveled within each palier; `last()` is the in-progress one. */
    private val _palierLenCanvas: MutableList<Float> = mutableListOf(0f)

    /** Running EMA in image-px. Seeded with the first point. */
    private var ema: Offset = initialPoint

    /** Flat view of every sample — `firstPoint` then every palier's samples in order. */
    val samples: List<Offset>
        get() {
            val out = ArrayList<Offset>(1 + _paliers.sumOf { it.size })
            out.add(firstPoint)
            for (palier in _paliers) out.addAll(palier)
            return out
        }

    /**
     * Appends a smoothed copy of [p] to the current palier and
     * advances the cumulative canvas length by [canvasStepLenPx]
     * (the caller computes that as the canvas distance between the
     * previous and current finger positions). When the in-progress
     * palier crosses [PALIER_CANVAS_PX], it's sealed and a new empty
     * palier becomes the head — so the next sample starts fresh.
     *
     * **Post-EMA clip.** [clip] is applied twice: once to
     * the raw input candidate before it feeds the EMA, then again
     * to the EMA result before storing. The second pass exists
     * because EMA smoothing has multi-sample lag — without it, a
     * finger that briefly clipped against a forbidden polygon then
     * jumped past it would let the EMA drift back into the polygon
     * for several samples (the rendered stroke visibly crosses the
     * forbidden interior even though every raw candidate was
     * clipped). Re-seeding [ema] with the post-clip result keeps
     * future EMA passes operating from a position outside the
     * forbidden set so the clipping stays stable.
     */
    fun addSampleImagePx(
        p: Offset,
        canvasStepLenPx: Float,
        clip: (Offset) -> Offset = { it },
    ) {
        val candidateClipped = clip(p)
        val rawEma = Offset(
            x = EMA_ALPHA * candidateClipped.x + (1f - EMA_ALPHA) * ema.x,
            y = EMA_ALPHA * candidateClipped.y + (1f - EMA_ALPHA) * ema.y,
        )
        val storedSample = clip(rawEma)
        ema = storedSample
        _paliers.last().add(storedSample)
        val newHeadLen = _palierLenCanvas.last() + canvasStepLenPx
        _palierLenCanvas[_palierLenCanvas.lastIndex] = newHeadLen
        if (newHeadLen >= PALIER_CANVAS_PX) {
            _paliers.add(mutableListOf())
            _palierLenCanvas.add(0f)
        }
    }

    /** Sum of every palier's traveled canvas length. */
    fun cumulativeLengthCanvasPx(): Float = _palierLenCanvas.sum()

    /**
     * Pops one palier-worth of work (spec §6.2.4):
     *   - If the in-progress palier has any traveled length, discard
     *     just that — the user undoes their unfinished arc back to
     *     the last 50 px boundary.
     *   - Otherwise the head is empty (we just sealed a palier and
     *     started a fresh one); drop that empty head and discard the
     *     last completed palier.
     *
     * No-op when fully rolled back ([isEmpty] is already true).
     *
     * Resets the EMA seed to the surviving tail sample (or [firstPoint]
     * if the stroke is back to its initial single point). Without
     * this, a second stroke after rollback would smooth against a
     * stale EMA from the discarded portion.
     */
    fun rollbackOnePalier() {
        if (isEmpty()) return
        if (_palierLenCanvas.last() > 0f) {
            // Discard the in-progress palier's content + length.
            _paliers.last().clear()
            _palierLenCanvas[_palierLenCanvas.lastIndex] = 0f
        } else {
            // Empty in-progress head — drop it, then clear the last
            // completed palier so it becomes a fresh empty head.
            _paliers.removeAt(_paliers.lastIndex)
            _palierLenCanvas.removeAt(_palierLenCanvas.lastIndex)
            _paliers.last().clear()
            _palierLenCanvas[_palierLenCanvas.lastIndex] = 0f
        }
        // Re-seed the EMA so future samples aren't smoothed against
        // a no-longer-present sample.
        ema = samples.lastOrNull() ?: firstPoint
    }

    /** True when no samples have been added (or rollback brought us back here). */
    fun isEmpty(): Boolean = cumulativeLengthCanvasPx() == 0f

    /**
     * O(1) accessor for the last stored sample in image-pixel space.
     * Used by the gesture router (M4) to compute the canvas-px
     * resume-distance check (spec §6.2.3) without walking the
     * full sample list on every pointer-down.
     *
     * Returns [firstPoint] when no samples have been added yet — the
     * EMA seed coincides with the first stored sample at that moment.
     */
    val lastSampleImagePx: Offset get() = ema

    /**
     * True when the touch-down at [fingerCanvasPos] meets both closure
     * conditions (spec §6.2.5):
     *   - cumulative stroke length ≥ [CLOSURE_MIN_LENGTH_CANVAS_PX]
     *   - finger ≤ [CLOSURE_ZONE_CANVAS_PX] from [firstPointCanvasPos]
     *
     * `firstPointCanvasPos` is the caller-provided canvas-pixel
     * projection of [firstPoint] (the caller owns the transform).
     * Closure itself fires when the finger lifts while in the zone —
     * this helper is also the gate the M8 canvas uses to render the
     * first-point halo (spec §6.2.5 visual cue).
     */
    fun isClosureCandidate(fingerCanvasPos: Offset, firstPointCanvasPos: Offset): Boolean {
        if (cumulativeLengthCanvasPx() < CLOSURE_MIN_LENGTH_CANVAS_PX) return false
        val dx = fingerCanvasPos.x - firstPointCanvasPos.x
        val dy = fingerCanvasPos.y - firstPointCanvasPos.y
        return dx * dx + dy * dy <= CLOSURE_ZONE_CANVAS_PX * CLOSURE_ZONE_CANVAS_PX
    }

    /**
     * True when [fingerCanvasPos] is within the [RESUME_ZONE_CANVAS_PX]
     * "resume" radius of [lastSampleCanvasPos] — i.e. the user is
     * picking the stroke back up after lifting (spec §6.2.3). Outside
     * this radius, a touch-down does nothing (the router emits the
     * "too far" snackbar).
     */
    fun isWithinResumeZone(fingerCanvasPos: Offset, lastSampleCanvasPos: Offset): Boolean {
        val dx = fingerCanvasPos.x - lastSampleCanvasPos.x
        val dy = fingerCanvasPos.y - lastSampleCanvasPos.y
        return dx * dx + dy * dy <= RESUME_ZONE_CANVAS_PX * RESUME_ZONE_CANVAS_PX
    }

    internal companion object {
        /** Spec §6.2.4. */
        const val PALIER_CANVAS_PX: Float = 50f

        /** EMA weight on the new raw sample (U10). 0.4 ≈ 3-sample lag. */
        const val EMA_ALPHA: Float = 0.4f

        /**
         * Spec §6.2.5 — closure zone radius around the first point.
         * Revised per M14 round 1 device testing: 20f (spec's
         * theoretical value) was smaller than a typical adult finger
         * contact patch and users couldn't reliably trigger closure.
         * 45f matches industry-typical small-target tap zones.
         */
        const val CLOSURE_ZONE_CANVAS_PX: Float = 45f

        /** Spec §6.2.5 — minimum stroke length before closure is eligible. */
        const val CLOSURE_MIN_LENGTH_CANVAS_PX: Float = 100f

        /** Spec §6.2.3 — resume zone radius around the last stored sample. */
        const val RESUME_ZONE_CANVAS_PX: Float = 50f
    }
}
