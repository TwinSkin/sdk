@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Renders capture metadata as a generic key/value list.
 *
 * Phase 0: [metadata] is a plain [Map]. When PowerSync lands and we know the
 * typed shape of measurements / notes / subject, this panel will grow
 * purpose-built subviews ([SubjectHeader], [MeasurementsList], [NotesList]);
 * until then, the generic list keeps the contract honest.
 */
@TwinSkinInternalApi
@Composable
public fun MetadataPanel(
    metadata: Map<String, String>,
    modifier: Modifier = Modifier,
    isSubmitting: Boolean = false,
) {
    if (metadata.isEmpty()) return
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Capture details", style = MaterialTheme.typography.titleSmall)
            HorizontalDivider()
            metadata.entries.forEach { (key, value) ->
                // M15.18 — measurement-derived rows go stale the
                // moment the user validates a new contour: the
                // cached metadata still carries the pre-submit
                // values until PowerSync delivers the server's
                // recomputed measurement. Swap them for a
                // "Calculating…" placeholder so the panel doesn't
                // lie about surface / perimeter / etc. during the
                // refresh window. Static rows ("Captured",
                // "Analysis") render unchanged.
                val staleNow = isSubmitting && key in MEASUREMENT_METADATA_KEYS
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        key,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (staleNow) {
                        // M15.20 — animated placeholder mirrors the
                        // MeasurementsPanel treatment so all stale
                        // surfaces pulse together.
                        CalculatingText(
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Normal,
                        )
                    } else {
                        Text(
                            value,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }
        }
    }
}

/**
 * Keys that [com.twinskin.sdk.view.resolvers.CaptureIdResolver] mints
 * for the measurement-derived rows on the capture-details metadata
 * map. Kept in sync with `addGenericRegion` / `addWoundRegion` in
 * that file — if either side adds a new measurement row, mirror it
 * here so the M15.18 stale-on-submit swap covers it.
 */
private val MEASUREMENT_METADATA_KEYS: Set<String> = setOf(
    "Surface area",
    "Perimeter",
    "Max depth",
    "Volume",
    "Length",
    "Width",
)
