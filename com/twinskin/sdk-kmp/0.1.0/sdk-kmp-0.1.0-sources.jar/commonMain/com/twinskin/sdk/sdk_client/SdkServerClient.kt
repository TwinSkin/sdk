package com.twinskin.sdk.sdk_client

import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.SdkAnnotation
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement

/**
 * Thin Ktor-backed client for the SDK server's session-token API.
 * Hand-written (rather than generated from `openapi_public.json`)
 * because the SDK's auth flow — dynamic session bearer + static
 * publishable-key header, plus 401-driven refresh — is awkward to
 * express through the Kotlin OpenAPI generator.
 *
 * [baseUrl] is the Twinskin API server's scheme+host(+port) root and
 * [publishableKey] are the static bits; [auth] supplies the dynamic
 * session bearer token on every call so a 401-driven retry picks up a
 * refreshed token transparently. The `/api/sdk` URL prefix the API
 * surface lives under is appended internally — see [apiBaseUrl].
 *
 * **When you add a new method here**, also add a case to the Dart
 * cross-SDK integration test at
 * `packages/server/integration_test/api/sdk/sdk_client_jvm_test.dart`
 * (+ the matching subcommand in `SdkClientCli.kt`). That test
 * exercises this client against the real running server and is how we
 * catch wire-format drift.
 */
internal open class SdkServerClient(
    internal val baseUrl: String,
    internal val publishableKey: String,
    internal val auth: SdkAuthorizationProvider,
    httpClient: HttpClient? = null,
) {
    private val ownsClient = httpClient == null
    internal val client = httpClient ?: HttpClient {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    /** `<baseUrl>/api/sdk` — the prefix every Twinskin SDK HTTP API hangs off. */
    internal val apiBaseUrl: String = "${baseUrl.trimEnd('/')}$SDK_API_PATH"

    open suspend fun startCapture(request: SdkStartCaptureRequest): SdkStartCaptureResponse {
        // The session-token payload is subject-scoped, so the provider
        // is asked per-request. Callers (e.g. the capture pipeline)
        // already have a subject for every upload; pulling it off the
        // request is the least invasive wiring.
        val tokens = parseSessionTokenPayload(
            auth.fetchSessionToken(request.subjectRef),
        )
        val response = client.post("$apiBaseUrl/upload/start-capture") {
            header(HttpHeaders.Authorization, "Bearer ${tokens.token}")
            header("X-Publishable-Key", publishableKey)
            contentType(ContentType.Application.Json)
            setBody(request)
        }
        if (!response.status.isSuccess()) {
            throw SdkServerException(response.status.value, response.bodyAsText())
        }
        return response.body()
    }

    /**
     * Submit a discriminated-union annotation for an existing capture.
     * The server allocates a new measurement revision per call;
     * submitting again supersedes the previous one. Authenticated as
     * the same session bearer as [startCapture] — looked up by the
     * capture's subject ref so the provider's subject-scoped payload
     * still applies.
     *
     * The wire format is the kotlinx.serialization JSON encoding of
     * [SdkAnnotation], whose `type` discriminator selects the
     * `wound`/`generic` variant on the server.
     */
    open suspend fun submitAnnotation(
        captureId: String,
        subjectRef: String,
        annotation: SdkAnnotation,
    ): SubmitAnnotationResponse {
        val tokens = parseSessionTokenPayload(
            auth.fetchSessionToken(subjectRef),
        )
        val response = client.post("$apiBaseUrl/upload/submit-annotation") {
            header(HttpHeaders.Authorization, "Bearer ${tokens.token}")
            header("X-Publishable-Key", publishableKey)
            contentType(ContentType.Application.Json)
            setBody(SubmitAnnotationRequest(captureId = captureId, annotation = annotation))
        }
        if (!response.status.isSuccess()) {
            throw SdkServerException(response.status.value, response.bodyAsText())
        }
        return response.body()
    }

    fun close() {
        if (ownsClient) client.close()
    }
}

internal class SdkServerException(val statusCode: Int, val responseBody: String) :
    RuntimeException("SDK server returned $statusCode: $responseBody")

/**
 * URL prefix every Twinskin SDK HTTP API hangs off (sessions, upload,
 * status, asset, demo captures). Appended to [TwinSkinConfig.baseUrl] —
 * which is the server's scheme+host(+port) root — by the SDK internals.
 */
internal const val SDK_API_PATH: String = "/api/sdk"

@Serializable
internal data class SdkStartCaptureRequest(
    @SerialName("user_ref") val userRef: String,
    @SerialName("subject_ref") val subjectRef: String,
    @SerialName("condition_type") val conditionType: ConditionType,
    @SerialName("capture_id") val captureId: String? = null,
    @SerialName("capture_group") val captureGroup: String? = null,
    @SerialName("body_location") val bodyLocation: List<String>? = null,
    val custom: Map<String, JsonElement>? = null,
    @SerialName("device_info") val deviceInfo: SdkDeviceInfo? = null,
)

/**
 * Phone metadata collected at SDK init and sent on every
 * `POST /upload/start-capture`. Stored verbatim on the server's
 * `sdk_captures.device_info` jsonb column for support triage. All
 * fields nullable: a platform that can't surface a value sends null
 * for that key, and the server tolerates a fully-null block.
 */
@Serializable
internal data class SdkDeviceInfo(
    val os: String? = null,
    @SerialName("os_version") val osVersion: String? = null,
    @SerialName("device_manufacturer") val deviceManufacturer: String? = null,
    @SerialName("device_model") val deviceModel: String? = null,
    @SerialName("sdk_version") val sdkVersion: String? = null,
    @SerialName("app_version") val appVersion: String? = null,
    @SerialName("app_bundle_id") val appBundleId: String? = null,
    val locale: String? = null,
)

@Serializable
internal data class SdkStartCaptureResponse(
    @SerialName("capture_id") val captureId: String,
    val status: SdkCaptureStatus,
    /**
     * Present iff [status] is [SdkCaptureStatus.QUEUED]. Past queued the
     * server has already accepted a bundle for this id and the SDK must
     * stop uploading — see `StartCaptureResponse` docs on the server.
     */
    @SerialName("upload_url") val uploadUrl: String? = null,
    @SerialName("upload_url_expires_at") val uploadUrlExpiresAt: String? = null,
)

@Serializable
internal data class SubmitAnnotationRequest(
    @SerialName("capture_id") val captureId: String,
    val annotation: SdkAnnotation,
)

@Serializable
internal data class SubmitAnnotationResponse(
    val revision: Int,
)

@Serializable
internal enum class SdkCaptureStatus {
    @SerialName("queued") QUEUED,
    @SerialName("in_progress") IN_PROGRESS,
    @SerialName("completed") COMPLETED,
    @SerialName("failed") FAILED,
}
