package com.twinskin.sdk.ui.annotation_editor.generic.i18n

/** English (en) implementation of [GenericStrings] — v1 ship locale. */
internal object GenericEnStrings : GenericStrings {

    override val introTitle: String = "Trace annotation"
    override val introDescription: String =
        "Draw the contours of the area(s) of interest."
    override val warningBanner: String =
        "Your work is only saved at final validation. Avoid leaving the app before then."
    override val resumeBanner: String =
        "This image already has annotations. Continue editing them, or start fresh?"
    override val resumeButton: String = "Resume"
    override val startFreshButton: String = "Start fresh"
    override val continueButton: String = "Continue"

    override val helpContentDescription: String = "Help"
    override val backContentDescription: String = "Back"
    override val backButton: String = "Back"
    override val cancelButton: String = "Cancel"

    override val drawingTitle: String = "Annotation"
    override val undoButton: String = "Undo"
    override val deleteButton: String = "Delete"
    override val validateButton: String = "Validate"
    override val tooFarFromOpenStroke: String =
        "Touch back closer to the open stroke to continue it."
    override val abandonDialogTitle: String = "Leave the editor?"
    override val abandonDialogBody: String =
        "Your work is only saved at final validation. Leaving now discards every " +
            "polygon you've drawn so far."
    override val leaveButton: String = "Leave"
    override val stayButton: String = "Stay"

    override val saveFailedSnackbar: String = "Save failed."
    override val retryAction: String = "Retry"

    override val canvasContentDescription: String =
        "Annotation canvas. Two fingers to zoom and pan."
    override val magnifierContentDescription: String =
        "Magnifier showing a 2x zoom of the area around your finger."
}
