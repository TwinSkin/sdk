package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.capture.fallback.Pie

/**
 * Accelerometer-capture capture screen — operator-facing three-phase Compose
 * Multiplatform composable. Wired by the Android `SdkAccelerometerCaptureActivity`
 * and the iOS `AccelerometerCaptureView` SwiftUI shell; the camera-preview
 * surface is injected via the [cameraPreview] slot so the same
 * composable can drive a `PreviewView` on Android and a UIKit
 * `AVCaptureVideoPreviewLayer` on iOS.
 *
 * State machine: see [AccelerometerCaptureScreenState] for the transition
 * table. The screen reads [controller]'s state flow and dispatches
 * UI events back to it; the controller owns the recorder / driver /
 * timer lifecycles.
 *
 * Cancel path: the platform host wires [onCancel] to its own
 * back-press / swipe-dismiss path. The composable calls
 * [AccelerometerCaptureController.cancel] on dispose so a process kill or
 * navigation-away cleans up the recorder + driver regardless of how
 * the operator left the screen.
 */
@Composable
public fun AccelerometerCaptureScreen(
    controller: AccelerometerCaptureController,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
    torchControl: TorchControl? = null,
    userPreferences: SdkUserPreferences = SdkUserPreferences.inMemory(),
    cameraPreview: @Composable () -> Unit = {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black))
    },
    tutorialPlayer: @Composable () -> Unit = { TutorialVideoPlaceholder() },
    tutorialIllustrations: @Composable (TutorialIllustrationSlot) -> Unit = {},
) {
    val state by controller.state.collectAsState()
    val colors = LocalAccelerometerCaptureColors.current

    DisposableEffect(controller) {
        onDispose { controller.cancel() }
    }

    var showExitConfirm by remember { mutableStateOf(false) }
    var showTutorial by remember { mutableStateOf(false) }
    var showFirstRun by remember {
        mutableStateOf(!userPreferences.tutorialDontShowAgain)
    }
    var flashMode by remember { mutableStateOf(FlashMode.Off) }

    val confirmExit: () -> Unit = { showExitConfirm = true }
    // Local capture so Kotlin can narrow the nullable param inside
    // the slot lambda (function-param smart-cast doesn't apply).
    val torch: TorchControl? = torchControl
    val flashSupported = torch?.isAvailable() == true

    Box(modifier = modifier.fillMaxSize().background(colors.surface)) {
        cameraPreview()

        when (val s = state) {
            is AccelerometerCaptureScreenState.Initializing -> {
                Box(
                    modifier = Modifier.fillMaxSize().background(colors.scrim),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = colors.onPrimary)
                        Text(
                            text = "Starting camera…", /* video_capture_initializing */
                            color = colors.onPrimary,
                            modifier = Modifier.padding(top = 12.dp),
                        )
                    }
                }
            }
            is AccelerometerCaptureScreenState.Error -> {
                ErrorOverlay(message = s.message, onDismiss = onCancel)
            }
            is AccelerometerCaptureScreenState.Submitting -> {
                SubmittingOverlay(progressPercent = s.progressPercent)
            }
            else -> Unit
        }

        TopBar(
            onCancel = confirmExit,
            onHelp = { showTutorial = true },
            // Hide the help button during the first-run overlay — the
            // tutorial is already on-screen.
            helpVisible = !showFirstRun,
            // Flash is exposed in Phase 1 / Phase 2 only; the recording
            // phase hides every chrome affordance bar the stop ring.
            flashSlot = if (flashSupported && torch != null && state.isFlashAllowed()) {
                {
                    FlashButton(
                        mode = flashMode,
                        onClick = {
                            val next = nextFlashMode(flashMode)
                            flashMode = next
                            torch.applyFlashMode(next)
                        },
                    )
                }
            } else null,
        )

        Column(
            modifier = Modifier.fillMaxSize().padding(bottom = 32.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val piePreview: Pie? = when (val s = state) {
                is AccelerometerCaptureScreenState.PhotoTaken -> Pie.empty()
                is AccelerometerCaptureScreenState.RecordingVideo -> s.pie
                else -> null
            }
            if (piePreview != null) {
                PieRing(
                    pie = piePreview,
                    modifier = Modifier.size(220.dp).padding(bottom = 16.dp),
                )
            }
            BottomShutter(state = state, controller = controller)
        }

        if (showExitConfirm) {
            ExitConfirmationDialog(
                onConfirm = {
                    showExitConfirm = false
                    onCancel()
                },
                onDismiss = { showExitConfirm = false },
            )
        }

        if (showFirstRun && state is AccelerometerCaptureScreenState.ReadyForPhoto) {
            FirstRunTutorialOverlay(
                preferences = userPreferences,
                onDismiss = { showFirstRun = false },
                illustrations = tutorialIllustrations,
            )
        }

        if (showTutorial) {
            TutorialOverlay(
                onDismiss = { showTutorial = false },
                tutorialPlayer = tutorialPlayer,
            )
        }
    }
}

@Composable
private fun TopBar(
    onCancel: () -> Unit,
    onHelp: () -> Unit,
    helpVisible: Boolean,
    flashSlot: (@Composable () -> Unit)?,
) {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.topBarBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        // Close icon in a circle, matching web_app's `Icons.close_sharp`
        // framing on the InstructionsDialog leading slot.
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .size(36.dp)
                .border(width = 2.dp, color = colors.onPrimary, shape = CircleShape)
                .clickable { onCancel() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Outlined.Close,
                contentDescription = "Cancel", /* video_capture_cancel */
                tint = colors.onPrimary,
            )
        }
        Text(
            text = "Capture", /* video_capture_title */
            color = colors.onPrimary,
            modifier = Modifier.align(Alignment.Center),
            fontSize = 16.sp,
        )
        Row(
            modifier = Modifier.align(Alignment.CenterEnd),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (flashSlot != null) {
                flashSlot()
                Spacer(modifier = Modifier.width(8.dp))
            }
            if (helpVisible) {
                HelpButton(onClick = onHelp)
            }
        }
    }
}

@Composable
private fun BottomShutter(
    state: AccelerometerCaptureScreenState,
    controller: AccelerometerCaptureController,
) {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        modifier = Modifier.size(96.dp),
        contentAlignment = Alignment.Center,
    ) {
        when (state) {
            is AccelerometerCaptureScreenState.ReadyForPhoto -> {
                ShutterIndicator(
                    ringColor = colors.onSurface,
                    dotColor = colors.onSurface,
                    modifier = Modifier.clickable { controller.takePhoto() },
                )
            }
            is AccelerometerCaptureScreenState.PhotoTaken -> {
                ShutterIndicator(
                    ringColor = colors.onSurface,
                    dotColor = colors.error,
                    modifier = Modifier.clickable { controller.startRecording() },
                )
            }
            is AccelerometerCaptureScreenState.RecordingVideo -> {
                Box(
                    modifier = Modifier
                        .size(70.dp)
                        .clickable { controller.requestStop() },
                    contentAlignment = Alignment.Center,
                ) {
                    CountdownRing(
                        elapsedMs = state.elapsedMs,
                        totalMs = VIDEO_CAPTURE_DURATION_MS,
                        progressColor = colors.progress,
                        completeColor = colors.progressComplete,
                        modifier = Modifier.size(70.dp),
                    )
                    RecordingInnerIndicator(color = colors.onSurface)
                }
            }
            else -> Unit
        }
    }
}

@Composable
private fun SubmittingOverlay(progressPercent: Int?) {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        modifier = Modifier.fillMaxSize().background(colors.scrim),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (progressPercent == null) {
                CircularProgressIndicator(color = colors.onPrimary)
                Text(
                    text = "Preparing bundle…", /* video_capture_preparing */
                    color = colors.onPrimary,
                    modifier = Modifier.padding(top = 12.dp),
                )
            } else {
                LinearProgressIndicator(
                    progress = { progressPercent / 100f },
                    color = colors.onPrimary,
                    modifier = Modifier.fillMaxWidth(0.6f),
                )
                Text(
                    text = "Uploading… $progressPercent%", /* video_capture_uploading */
                    color = colors.onPrimary,
                    modifier = Modifier.padding(top = 12.dp),
                )
            }
        }
    }
}

@Composable
private fun ErrorOverlay(message: String, onDismiss: () -> Unit) {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        modifier = Modifier.fillMaxSize().background(colors.errorScrim),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp),
        ) {
            Text(
                text = "Capture failed", /* video_capture_error_title */
                color = colors.onPrimary,
                fontSize = 18.sp,
            )
            Text(
                text = message,
                color = colors.onPrimary,
                modifier = Modifier.padding(top = 12.dp),
            )
            Box(
                modifier = Modifier
                    .padding(top = 24.dp)
                    .background(colors.onPrimary, shape = CircleShape)
                    .clickable { onDismiss() }
                    .padding(horizontal = 24.dp, vertical = 12.dp),
            ) {
                Text(
                    text = "Close", /* video_capture_error_dismiss */
                    color = colors.surface,
                )
            }
        }
    }
}

private fun AccelerometerCaptureScreenState.isFlashAllowed(): Boolean = when (this) {
    is AccelerometerCaptureScreenState.ReadyForPhoto,
    is AccelerometerCaptureScreenState.PhotoTaken -> true
    else -> false
}
