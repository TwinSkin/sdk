package com.twinskin.sdk.capture.fallback

import kotlin.math.PI
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Driver is not reusable; a second `start()` is a no-op. */
public interface AccelerometerDriver {
    public val angleThreshold: Double
    public fun start(): StateFlow<Pie>
    public fun stop(): VideoMetaData
}

/** `accept*` methods MUST be called from a single producer thread per stream. */
internal class AccelerometerSampleAccumulator(
    val angleThreshold: Double,
) {
    val pie: MutableStateFlow<Pie> = MutableStateFlow(Pie.empty())

    private var initialAcc: OrientationMath.Vec3? = null
    private val accEvents = mutableListOf<AccelerometerData>()
    private val userAccEvents = mutableListOf<AccelerometerData>()
    private val gyroEvents = mutableListOf<AccelerometerData>()
    private val magnetoEvents = mutableListOf<AccelerometerData>()

    fun acceptAccelerometer(sample: AccelerometerData) {
        // web_app shape: the first sample latches gravity via
        // `stream.first` and is NOT appended to `_savedAccEvents`; only
        // subsequent events flow through `.listen(_onAccelemeterEvent)`,
        // which logs them. AC #3 calls for byte-identical JSON, so the
        // gravity-latch sample is dropped from the log here too.
        val initial = initialAcc ?: run {
            initialAcc = OrientationMath.Vec3(sample.x, sample.y, sample.z)
            return
        }
        accEvents += sample
        val v = OrientationMath.computeOrientationVector(
            initial,
            OrientationMath.Vec3(sample.x, sample.y, sample.z),
        )
        if (v.intensity >= angleThreshold) {
            pie.value = pie.value.copyWithAngle(v.theta)
        }
    }

    fun acceptUserAccelerometer(sample: AccelerometerData) {
        userAccEvents += sample
    }

    fun acceptGyroscope(sample: AccelerometerData) {
        gyroEvents += sample
    }

    fun acceptMagnetometer(sample: AccelerometerData) {
        magnetoEvents += sample
    }

    fun snapshotMetadata(): VideoMetaData = VideoMetaData(
        accelerometerData = if (accEvents.isEmpty()) null else accEvents.toList(),
        gyroscoptData = if (gyroEvents.isEmpty()) null else gyroEvents.toList(),
        userAccelerometerData =
            if (userAccEvents.isEmpty()) null else userAccEvents.toList(),
        // Magnetometer is intentionally excluded from the returned
        // payload — matches the web_app's `getSavedData`. The samples
        // are still gathered in [magnetoEvents] for parity with the
        // web_app's behaviour and to keep the door open for a future
        // sensor-fusion pass.
        magnetoscopeData = null,
    )
}

public val DEFAULT_ANGLE_THRESHOLD: Double = PI / 6.0

public expect fun createAccelerometerDriver(angleThreshold: Double): AccelerometerDriver

public fun createAccelerometerDriver(): AccelerometerDriver =
    createAccelerometerDriver(DEFAULT_ANGLE_THRESHOLD)

internal fun MutableStateFlow<Pie>.readOnly(): StateFlow<Pie> = this.asStateFlow()
