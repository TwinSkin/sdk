// GENERATED FILE — regenerate via `fvm dart run tool/database_builder.dart` from `packages/server/`.
// Source: packages/server/powersync/sync_rules.yaml (stream: sdk_captures)
// Do not edit by hand.
package com.twinskin.sdk.capture

import com.powersync.db.schema.Column
import com.powersync.db.schema.Schema
import com.powersync.db.schema.Table

internal object SdkCapturePowerSyncSchema {
    const val STREAM_NAME: String = "sdk_captures"
    const val SDK_CAPTURES_TABLE: String = "sdk_captures"
    const val SDK_MEASUREMENTS_TABLE: String = "sdk_measurements"

    val schema: Schema = Schema(
        Table(
            name = SDK_CAPTURES_TABLE,
            columns = listOf(
                Column.text("environment_id"),
                Column.text("subject_ref"),
                Column.text("user_ref"),
                Column.text("status"),
                Column.text("error_code"),
                Column.text("error_reason"),
                Column.text("queued_at"),
                Column.text("started_at"),
                Column.text("completed_at"),
                Column.text("last_advanced_at"),
                Column.text("body_location"),
                Column.text("capture_group"),
                Column.text("custom"),
                Column.text("capture_mode"),
                Column.text("condition_type"),
                Column.text("result_reference_image_key"),
                Column.text("result_reference_image_thumb_key"),
                Column.text("result_reference_image_medium_key"),
                Column.text("result_preview_3d_glb_key"),
                Column.text("result_annotated_image_key"),
                Column.integer("latest_measurement_revision"),
                Column.text("latest_annotation"),
                Column.text("latest_annotation_received_at"),
            ),
        ),
        Table(
            name = SDK_MEASUREMENTS_TABLE,
            columns = listOf(
                Column.text("capture_id"),
                Column.integer("revision"),
                Column.text("status"),
                Column.text("annotation"),
                Column.text("result"),
                Column.text("created_at"),
                Column.text("completed_at"),
            ),
        ),
    )
}
