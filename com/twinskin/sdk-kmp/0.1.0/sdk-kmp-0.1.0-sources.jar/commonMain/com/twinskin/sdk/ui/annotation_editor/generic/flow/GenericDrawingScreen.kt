package com.twinskin.sdk.ui.annotation_editor.generic.flow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.ui.annotation_editor.generic.GenericStore
import com.twinskin.sdk.ui.annotation_editor.generic.GenericStoreSnapshot
import com.twinskin.sdk.ui.annotation_editor.generic.i18n.GenericStrings
import com.twinskin.sdk.ui.annotation_editor.polygon.canvas.DrawingCanvas
import com.twinskin.sdk.ui.annotation_editor.polygon.canvas.ZoomPanController
import com.twinskin.sdk.ui.annotation_editor.polygon.draft.EditorControllerSaver
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.EditorController
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.UiSignal
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.ConfirmDialog
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.HapticEvent
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.TransientHint
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.emit
import com.twinskin.sdk.ui.theme.PrimaryButton
import kotlinx.coroutines.delay

/**
 * Drawing screen for the generic editor. Derivative of
 * `WoundDrawingScreen` with the wound-specific machinery removed:
 *  - No reshape advisory `LaunchedEffect`.
 *  - No delete-with-tissues confirmation — delete is instant on the
 *    focused polygon (or discards the in-flight open stroke).
 *  - No card-state recompute on commit.
 *  - No help dialog.
 *
 * **Controller / store sync.** Same `UiSignal` drain as the wound
 * screen but applied to [GenericStore] mutations:
 *  - [UiSignal.StrokeClosed] → `store.addPolygon(outline)`.
 *  - [UiSignal.ReshapeCommitted] → `store.replacePolygon(idx, outline)`.
 *  - [UiSignal.PolygonDeleted] → `store.removePolygon(idx)`.
 *  - [UiSignal.UndoApplied] → `store.restore(sideState)` using the
 *    [GenericStoreSnapshot] colocated on the controller's UndoEntry
 *    (attached via [EditorController.attachSideStateToTopUndo]).
 *  - [UiSignal.TooFarFromOpenStroke] → transient hint banner.
 *
 * **Bottom bar.** Single row: Undo / Delete / Validate. Open strokes
 * paint in the engine's default green and committed polygons in the
 * shared orange (`ClosedPolygonColor`) — same uniform palette as the
 * wound editor.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun GenericDrawingScreen(
    image: ImageBitmap,
    imageSize: Size,
    store: GenericStore,
    strings: GenericStrings,
    onBack: () -> Unit,
    onValidate: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // Key the saver on the store reference so a fresh hydration in
    // GenericAnnotationEditor (new initial / imageSize) invalidates
    // the controller slot and re-runs the seeding lambda. Mirrors the
    // wound screen's M15.16 fix.
    val controller: EditorController = rememberSaveable(store, saver = EditorControllerSaver) {
        val existing = store.polygons.toList()
        EditorController.fromState(
            polygons = existing,
            focusedIndex = if (existing.isNotEmpty()) existing.lastIndex else null,
        )
    }
    val zoomPan: ZoomPanController = remember(imageSize) {
        ZoomPanController(canvasSize = Size.Zero, imageSize = imageSize)
    }
    val snackbarHostState: SnackbarHostState = remember { SnackbarHostState() }
    val haptic = LocalHapticFeedback.current

    var pendingAbandon by remember { mutableStateOf(false) }

    // TooFar transient hint — same UX as the wound screen.
    var tooFarHint by remember { mutableStateOf<String?>(null) }
    var tooFarNonce by remember { mutableStateOf(0) }
    LaunchedEffect(tooFarNonce) {
        if (tooFarHint != null) {
            delay(1200)
            tooFarHint = null
        }
    }

    // Non-traversal haptic on null→non-null transition only.
    LaunchedEffect(controller) {
        var prev: Offset? = null
        snapshotFlow { controller.lastStrokeClampContact.value }.collect { current ->
            if (current != null && prev == null) {
                haptic.emit(HapticEvent.NonTraversalContact)
            }
            prev = current
        }
    }

    // Signal drain: applies controller events to the generic store.
    LaunchedEffect(controller, store) {
        snapshotFlow { controller.revision.value }.collect {
            while (true) {
                val signal = controller.consumeSignal() ?: break
                when (signal) {
                    UiSignal.TooFarFromOpenStroke -> {
                        tooFarHint = strings.tooFarFromOpenStroke
                        tooFarNonce += 1
                    }
                    is UiSignal.StrokeClosed -> {
                        controller.attachSideStateToTopUndo(store.snapshot())
                        val newOutline = controller.polygons[signal.polygonIdx]
                        store.addPolygon(newOutline)
                        haptic.emit(HapticEvent.StrokeCommit)
                    }
                    is UiSignal.ReshapeCommitted -> {
                        controller.attachSideStateToTopUndo(store.snapshot())
                        store.replacePolygon(signal.polygonIdx, signal.postReshapeOutline)
                        haptic.emit(HapticEvent.ReshapeCommit)
                    }
                    is UiSignal.PolygonDeleted -> {
                        controller.attachSideStateToTopUndo(store.snapshot())
                        store.removePolygon(signal.polygonIdx)
                        haptic.emit(HapticEvent.DeleteConfirmed)
                    }
                    is UiSignal.UndoApplied -> {
                        val snapshot = signal.sideState as? GenericStoreSnapshot
                        if (snapshot != null) store.restore(snapshot)
                    }
                }
            }
        }
    }

    // Force recompose of bottom bar on controller state changes.
    @Suppress("UNUSED_VARIABLE") val rev = controller.revision.value

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(strings.drawingTitle) },
                navigationIcon = {
                    IconButton(onClick = {
                        if (controller.polygons.isNotEmpty()) pendingAbandon = true else onBack()
                    }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.backContentDescription,
                        )
                    }
                },
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 3.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // Prototype tints both secondary text actions teal
                    // (the deep brand action color); Validate stays the
                    // slate-filled PrimaryButton.
                    TextButton(
                        onClick = { controller.undo() },
                        enabled = controller.undoStackSize > 0 || controller.openStroke != null,
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = MaterialTheme.colorScheme.secondary,
                        ),
                    ) { Text(strings.undoButton) }
                    TextButton(
                        onClick = {
                            controller.deleteFocused()
                        },
                        enabled = controller.focusedIndex != null || controller.openStroke != null,
                        colors = ButtonDefaults.textButtonColors(
                            contentColor = MaterialTheme.colorScheme.secondary,
                        ),
                    ) { Text(strings.deleteButton) }
                    PrimaryButton(
                        text = strings.validateButton,
                        onClick = onValidate,
                        enabled = isGenericValidateEnabled(controller),
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            DrawingCanvas(
                image = image,
                imageSize = imageSize,
                controller = controller,
                zoomPan = zoomPan,
                readOnlyWounds = emptyList(),
                readOnlyOtherTissues = emptyList(),
                canvasContentDescription = strings.canvasContentDescription,
                magnifierContentDescription = strings.magnifierContentDescription,
            )
            TransientHint(
                text = tooFarHint,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 16.dp),
            )
        }
    }

    if (pendingAbandon) {
        ConfirmDialog(
            title = strings.abandonDialogTitle,
            body = strings.abandonDialogBody,
            destructiveLabel = strings.leaveButton,
            cancelLabel = strings.stayButton,
            onConfirm = {
                pendingAbandon = false
                onBack()
            },
            onCancel = { pendingAbandon = false },
        )
    }
}

/**
 * Validate button enable predicate. Mirrors `WoundDrawingScreen`'s
 * Next gate: at least one committed polygon and no in-flight open
 * stroke. Extracted for `GenericDrawingScreenTest` coverage.
 */
internal fun isGenericValidateEnabled(controller: EditorController): Boolean =
    controller.polygons.isNotEmpty() && controller.openStroke == null
