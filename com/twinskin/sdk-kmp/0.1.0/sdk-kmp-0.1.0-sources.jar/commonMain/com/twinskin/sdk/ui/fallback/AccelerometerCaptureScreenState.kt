package com.twinskin.sdk.ui.fallback

import com.twinskin.sdk.capture.fallback.Pie

/**
 * The four operator-visible phases of the accelerometer-capture capture flow,
 * plus terminal `Error` and the in-between `Submitting` upload state.
 *
 * Mirrors the web_app's `CompleteCaptureScreen` mental model
 * (`packages/web_app/lib/src/app/mobile/camera/complete_capture_screen.dart`):
 * frame -> shoot still -> orbit 20 s -> hand off bundle. The SDK
 * uses a sealed-class state instead of the web_app's bag of booleans
 * so unit tests can pin every transition.
 *
 * Transition table:
 *
 * | From            | Trigger                              | To              |
 * |-----------------|--------------------------------------|-----------------|
 * | [Initializing]  | permissions granted + camera ready   | [ReadyForPhoto] |
 * | [ReadyForPhoto] | shutter tap (`takeStillPhoto()`)     | [PhotoTaken]    |
 * | [PhotoTaken]    | shutter tap (`startRecording()`)     | [RecordingVideo]|
 * | [RecordingVideo]| stop tap OR 20 s timer               | [Submitting]    |
 * | [Submitting]    | bundle uploaded                      | screen finishes |
 * | any             | unrecoverable error                  | [Error]         |
 */
public sealed class AccelerometerCaptureScreenState {

    /** Permissions and camera bind are in flight. */
    public data object Initializing : AccelerometerCaptureScreenState()

    /** Preview is live; tapping the shutter takes the single still. */
    public data object ReadyForPhoto : AccelerometerCaptureScreenState()

    /**
     * The still photo has been captured to [stillPath]; the screen is
     * ready for the operator's second tap, which starts the 20 s
     * recording.
     */
    public data class PhotoTaken(val stillPath: String) : AccelerometerCaptureScreenState()

    /**
     * Recording is in flight. [elapsedMs] ticks once per timer pulse
     * (driving the countdown ring around the stop button); [pie] is
     * the [com.twinskin.sdk.capture.fallback.AccelerometerDriver]'s
     * latest snapshot, driving the 8-segment ring overlay.
     */
    public data class RecordingVideo(
        val elapsedMs: Long,
        val pie: Pie,
    ) : AccelerometerCaptureScreenState()

    /**
     * Bundle is being packed and uploaded. [progressPercent] is the
     * byte-level upload progress once the transfer is running; `null`
     * during the bundle-pack window.
     */
    public data class Submitting(val progressPercent: Int?) : AccelerometerCaptureScreenState()

    /**
     * Terminal error. Cancel + retake-from-phase-1 is the only
     * recovery path in v1 — mid-recording recovery (open question on
     * #504) is parked.
     */
    public data class Error(val message: String) : AccelerometerCaptureScreenState()
}

/**
 * Recording duration is fixed at 20 s in v1 to match the web_app
 * default. A `TwinSkinConfiguration.videoCaptureDurationMs` knob is
 * parked for Capture v2.1; if integrators ask we add it then.
 */
public const val VIDEO_CAPTURE_DURATION_MS: Long = 20_000L

/**
 * Cadence the `RecordingVideo` timer ticks at. Drives the countdown
 * ring's progress fraction (`elapsedMs / VIDEO_CAPTURE_DURATION_MS`).
 * Public so the iOS Swift bridge can read it as a Swift-side
 * constant without re-deriving the cadence per platform.
 */
public const val VIDEO_CAPTURE_TIMER_TICK_MS: Long = 50L
