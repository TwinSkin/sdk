package com.twinskin.sdk.ui.fallback

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** Defaults mirror the web_app's `complete_capture_screen.dart` palette. */
@Immutable
public data class AccelerometerCaptureColors(
    val surface: Color = Color(0xFF0F1416),
    val onSurface: Color = Color(0xFFDEE3E5),
    val error: Color = Color(0xFFFFB4AB),
    val orbit: Color = Color(0xFF94EAFF),
    val orbitInactive: Color = Color(0x33FFFFFF),
    val progress: Color = Color(0xFFD32F2F),
    val progressComplete: Color = Color(0xFF2E7D32),
    val scrim: Color = Color(0xCC000000),
    val errorScrim: Color = Color(0xE6000000),
    val topBarBackground: Color = Color(0x99000000),
    val onPrimary: Color = Color.White,
)

public val LocalAccelerometerCaptureColors: androidx.compose.runtime.ProvidableCompositionLocal<AccelerometerCaptureColors> =
    staticCompositionLocalOf { AccelerometerCaptureColors() }
