package com.twinskin.sdk.ui.fallback

public enum class FlashMode { Off, Auto, On }

// Cycle order matches web_app's flashModeCycle: off → auto → on → off.
// Android CameraX has no auto-torch primitive, so Auto degrades to Off
// there; iOS maps Auto to AVCaptureDevice's auto torch.
public val FLASH_MODE_CYCLE: List<FlashMode> = listOf(FlashMode.Off, FlashMode.Auto, FlashMode.On)

public fun nextFlashMode(current: FlashMode): FlashMode {
    val idx = FLASH_MODE_CYCLE.indexOf(current)
    return FLASH_MODE_CYCLE[(idx + 1) % FLASH_MODE_CYCLE.size]
}

// applyFlashMode is idempotent + cheap; UI may call it on every
// shutter-state change. No actual implementation requests the
// microphone permission (AC-#525-5 regression guard).
public interface TorchControl {
    public fun isAvailable(): Boolean
    public fun applyFlashMode(mode: FlashMode)
}

public class NoopTorchControl(
    private val available: Boolean = true,
) : TorchControl {
    private var lastApplied: FlashMode? = null
    public val applied: List<FlashMode> get() = appliedHistory.toList()
    private val appliedHistory = mutableListOf<FlashMode>()
    override fun isAvailable(): Boolean = available
    override fun applyFlashMode(mode: FlashMode) {
        lastApplied = mode
        appliedHistory.add(mode)
    }
    public fun lastFlashMode(): FlashMode? = lastApplied
}
