package com.twinskin.sdk.devcapture

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * One catalog entry returned by `GET /api/sdk/demo/captures`.
 *
 * URLs are absolute — the SDK does an HTTP GET on each verbatim and
 * does not interpret the path structure. That's the contract that lets
 * the server transparently swap from disk-served files to presigned
 * S3 GETs without an SDK release.
 */
@Serializable
internal data class DemoCaptureEntry(
    val id: String,
    val name: String,
    @SerialName("ref_url") val refUrl: String,
    @SerialName("frame_urls") val frameUrls: List<String>,
    // Default null keeps legacy catalogs that omit the field deserialisable.
    @SerialName("marker_version") val markerVersion: String? = null,
)
