package com.twinskin.sdk.ui.annotation_editor.delineation.i18n

import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType

/**
 * User-facing strings for the wound delineation editor.
 *
 * **Maintenance rule.** Every user-facing literal in the
 * `delineation/` source tree goes through this interface. No
 * `Text("...")`, `contentDescription = "..."`, or dialog `body =
 * "..."` literal should contain English (or any natural-language)
 * text outside [EnStrings] (and the per-locale implementations
 * v1.1 will add). The grep gate `rg '"[A-Z][a-z]+'` across
 * `delineation/` should return zero hits except for the
 * `i18n/EnStrings.kt` file itself.
 *
 * **Parameterised strings** are exposed as lambdas (`(Int) ->
 * String`, etc.). The v1 EN implementation uses the parenthetical-
 * (s) trick for plurals — e.g., "$n tissue region(s)". Real plural
 * rules (FR/NL/DE) come in v1.1 when those locales' content lands.
 *
 * **TissueType.Other.** Unknown wire strings ([TissueType.Other])
 * don't appear in [tissueTypeNames]; callers fall back to
 * `type.wire` when the map lookup misses (handled at the call
 * site via `?: type.wire`).
 *
 */
internal interface Strings {

    // ── Intro screen ─────────────────────────────────────────────
    val introTitle: String
    val introStep1Title: String
    val introStep1DescriptionP1: String
    val introStep1DescriptionP2: String
    val startDrawingButton: String   // Edit-existing mode.
    val continueButton: String       // Fresh mode.
    val warningBanner: String
    val resumeBanner: String
    val resumeButton: String
    val startFreshButton: String
    val startButton: String
    val helpDialogTitle: String
    val helpDialogPlaceholderBody: String
    val closeButton: String

    // ── Common chrome ────────────────────────────────────────────
    val helpContentDescription: String
    val backContentDescription: String
    /** Visible label on a footer / inline Back button. Distinct from
     *  [backContentDescription], which is the screen-reader hint on
     *  an icon-only back arrow — locales render the two differently. */
    val backButton: String
    val cancelButton: String

    // ── Tissue dashboard ─────────────────────────────────────────
    val dashboardTitle: String
    val dashboardStep2Title: String
    val validateButton: String
    val validateDialogTitle: String
    val validateDialogBody: String
    val saving: String
    val untypedFooter: (remainder: Int) -> String
    val autoFillDialogTitle: String
    val autoFillDialogBody: (typeName: String) -> String
    val autoFillConfirmButton: String   // EN: "Auto-fill"
    val autoFillDeclineButton: String   // EN: "Draw"

    // ── Wound drawing ────────────────────────────────────────────
    val woundTitle: String
    val undoButton: String
    val deleteButton: String
    val nextButton: String
    val tooFarFromOpenStroke: String
    val reshapeAdvisoryTitle: String
    val reshapeAdvisoryBody: String
    val dontShowAgainCheckbox: String
    val okButton: String
    val deleteDialogTitle: String
    val deleteDialogBody: (tissueCount: Int) -> String
    val abandonDialogTitle: String
    val abandonDialogBody: String
    val leaveButton: String
    val stayButton: String
    val tissuesAdjustedSnack: (updated: Int, removed: Int) -> String

    // ── Tissue drawing ───────────────────────────────────────────
    val tissueDrawingTitle: (typeName: String) -> String
    val doneButton: String           // Primary CTA on TissueDrawingScreen.

    // ── Root (validate retry) ────────────────────────────────────
    val saveFailedSnackbar: String
    val retryAction: String

    // ── Error screen ─────────────────────────────────────────────
    val errorScreenTitle: String
    val errorScreenBody: String
    val dismissButton: String

    // ── A11y ─────────────────────────────────────────────────────
    val woundCanvasContentDescription: String
    val tissueCanvasContentDescription: String
    val magnifierContentDescription: String
    val helpPreviousSlide: String
    val helpNextSlide: String

    // ── Tissue card buttons ──────────────────────────────────────
    val tissueCardAddTissue: String   // EN: "Draw area".
    val tissueCardEdit: String
    val tissueCardMarkAbsent: String  // EN: "Not present" — also doubles as the Absent-state pill label.

    // ── Tissue type names ────────────────────────────────────────
    /**
     * Display names for the three [TissueType.knownValues] entries.
     * [TissueType.Other] is intentionally absent — call sites use
     * `tissueTypeNames[type] ?: type.wire` to fall back to the raw
     * wire string for unknown types.
     */
    val tissueTypeNames: Map<TissueType, String>

    // ── Help slides (M12 content) ────────────────────────────────
    val helpSlides: HelpSlideStrings
}
