package com.twinskin.sdk.capture

import kotlinx.coroutines.flow.Flow

/**
 * Observe captures known to this SDK instance.
 *
 * Obtained from `TwinSkinSdk.captures`. The observer never owns the capture
 * lifecycle — it's a read-only view. All methods return cold Flows; work only
 * happens while a collector is active.
 *
 * Two entry points, two levels of opt-in:
 *
 *  - [observePendingUploads] is the cheap one: local-only state, no
 *    authentication, no network. Safe to subscribe at app launch.
 *  - [observeSubject] merges local state with server-side analysis
 *    state via a subject-scoped PowerSync connection opened lazily on
 *    first collection. It's the opt-in for server-side observation.
 */
public interface CaptureObserver {
    /**
     * Captures currently being uploaded from this device, plus any rows that
     * have terminally failed. Use this to drive a background-upload indicator
     * paired with [CaptureApi.startCapture] calls.
     *
     * Inclusion rules:
     *  - `Uploading` (the in-flight states `PENDING_UPLOAD` / `UPLOADING`) → emitted.
     *  - `Failed(stage = Upload)` → emitted indefinitely. `Failed` is reserved
     *    for SDK bugs the platform retry stack couldn't recover from; surfacing
     *    those rows is the integrator's signal that something needs an SDK fix.
     *  - `Uploaded` (succeeded) and `Cancelled` (host called cancel) → dropped
     *    immediately. The upload either succeeded silently or was acknowledged
     *    by the caller, so there's nothing left to show.
     *
     * Device-scoped (any subject). No authentication, no network — free to
     * subscribe at app launch. Never opens a PowerSync connection.
     */
    public fun observePendingUploads(): Flow<List<PendingUpload>>

    /**
     * Subject-scoped feed of every capture for [subjectRef] known to either
     * side: on-device rows from the local store and server rows streamed over
     * PowerSync. Server state wins on conflicts; local-only rows surface with
     * their on-device [CaptureState]. Rows in a post-upload limbo (local says
     * `Uploaded`, server hasn't yet created the row) are smoothed to
     * [CaptureState.Analyzing] so UIs don't flicker between "upload done" and
     * "server working".
     *
     * Calling this method is the opt-in for server-side observation: a
     * PowerSync client is created on first collection, shared across
     * collectors of the same subject, and closed ~5s after the last collector
     * cancels. Different subjects = different clients.
     *
     * Auth-fetch failures (network blip, integrator backend down) are not
     * surfaced to the collector — the SDK retries with capped-exponential
     * backoff and logs each attempt via [com.twinskin.sdk.SdkLogger]. The
     * flow stays open and emits as soon as a successful PowerSync
     * connection is established.
     */
    public fun observeSubject(subjectRef: String): Flow<List<CaptureEntry>>

    /**
     * Reactive view of a single capture row. Re-uses the subject-scoped
     * PowerSync connection opened by [observeSubject] for the same
     * subject — so a host already observing the subject doesn't open a
     * second client.
     *
     * Emits `null` when the capture id is absent from the subject's
     * stream (not yet synced, or deleted server-side). When the row
     * appears the flow emits the populated [CaptureEntry] and re-emits
     * on every subsequent change.
     */
    public fun observeCapture(captureId: String, subjectRef: String): Flow<CaptureEntry?>
}

/**
 * Snapshot of a single capture's local upload state, as seen by
 * [CaptureObserver.observePendingUploads]. Only two variants of
 * [CaptureState] appear here: [CaptureState.Uploading] (in flight) or
 * [CaptureState.Failed] with [FailureStage.Upload] (terminal SDK bug).
 * `Uploaded` and `Cancelled` rows are filtered out by the observer — see
 * [CaptureObserver.observePendingUploads] for the contract.
 */
public data class PendingUpload(
    val captureId: String,
    val subjectRef: String,
    val state: CaptureState,
    val updatedAtEpochMs: Long,
)

/**
 * Snapshot of a single capture's merged (local + server) state, as seen by
 * [CaptureObserver.observeSubject]. Every [CaptureState] variant is reachable
 * here; server-only variants like [CaptureState.Analyzing] / [CaptureState.Succeeded]
 * or [CaptureState.Failed] with [FailureStage.Server] flow through this type
 * exclusively.
 */
public data class CaptureEntry(
    val captureId: String,
    val subjectRef: String,
    val state: CaptureState,
    val updatedAtEpochMs: Long,
    /**
     * S3 key of the SDK-readable reference 2D image. Lives under
     * `sdk-results/<captureId>/<runId>/reference.jpg` — the decrypt
     * lambda writes this copy alongside its internal `sdk-work/`
     * working copy. Null until the decrypt stage completes.
     */
    val referenceImageKey: String? = null,
    /** S3 key of the photogrammetry-result GLB. Null until 3D construction completes. */
    val resultPreview3dGlbKey: String? = null,
    /** Latest annotation submitted by the user. Null until the user submits one. */
    val latestAnnotation: SdkAnnotation? = null,
    /** Latest measurement from the latest successful revision. Null until measure_3d completes. */
    val latestMeasurement: SdkMeasurement? = null,
    /** True iff a measure step for a newer revision is queued or in flight. */
    val isMeasurementCalculating: Boolean = false,
    /** Capture condition type; null when unknown (legacy/unsynced rows). Selects the annotation editor on edit-contour. */
    val conditionType: ConditionType? = null,
)
