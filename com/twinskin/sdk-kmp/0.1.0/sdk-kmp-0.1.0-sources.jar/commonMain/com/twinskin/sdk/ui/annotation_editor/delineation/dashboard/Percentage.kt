package com.twinskin.sdk.ui.annotation_editor.delineation.dashboard

import androidx.compose.ui.graphics.Path
import com.twinskin.sdk.geometry.difference
import com.twinskin.sdk.geometry.pathArea
import com.twinskin.sdk.geometry.polygonToPath
import com.twinskin.sdk.geometry.signedArea
import com.twinskin.sdk.geometry.union
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound
import kotlin.math.absoluteValue

/**
 * Percentage breakdown of the three known tissue types over the
 * union of every wound's area (spec §7.2 dashboard, decision L
 * exclusive-union algorithm).
 *
 * **Algorithm.** Per-type unions are computed first (one [Path] per
 * type, accumulated via [union] over every tissue of that type
 * across every wound). Types are then sorted by gross area ascending
 * and walked in order — each type's net area is the [difference]
 * against the running "already claimed" path, so overlapping regions
 * are awarded to the **smallest** type. This matches the
 * Flutter reference and the clinical intuition: a small necrosis
 * island visually drawn on top of a larger slough region reads as
 * "necrosis with slough around it", not "slough that swallowed the
 * necrosis". The plan-update gate test (a U-shaped slough wrapping
 * a granulation island whose centroid sits inside the granulation)
 * is the case strict-containment heuristics get wrong; this
 * exclusive-union pass gets right.
 *
 * **Sum-exceeds-100 defence.** Two stages keep the integer sum in
 * `[0, 100]`. First, numerical noise in [pathArea] over Skia's
 * tessellation can push the raw net-area sum slightly above the
 * wounds-union area; when that happens the per-type net areas are
 * scaled down by `woundsUnionArea / rawTotal` so the un-rounded
 * sum is ≤ 100. Second, **largest-remainder apportionment** turns
 * the three un-rounded percentages into integers whose sum is
 * exactly `floor(rawTotalPct)` — naïve `roundToInt` on each value
 * independently can carry three small remainders all upward at
 * once and produce a sum of 101 or 102 (e.g.,
 * `39.6 + 40.6 + 20.4 → 40 + 41 + 20 = 101`). The Hare-quota /
 * largest-remainder method floors each value and then distributes
 * the leftover units to the types with the largest fractional
 * remainders.
 *
 * **`Other` tissues.** [TissueType.Other] tissues are excluded from
 * the percentage computation and from the returned map. Their area
 * falls into the implicit untyped remainder — the dashboard renders
 * `100 − sum(known)` as "other" without naming the variant. Per the
 * M2 design discussion: the three known types are the only ones the
 * UI surfaces with a clinical label; round-tripped unknown types
 * survive in the wire format but don't earn a dashboard slot.
 *
 * **Map shape.** Always returns all three [TissueType.knownValues]
 * keys, even when their value is 0 — sparse maps would force `?: 0`
 * at every M11 call site.
 *
 * **Empty / degenerate inputs.** Returns all-zeros when
 * `woundsUnionArea < 1` image-pixel² (covers both the empty-wounds
 * case and the all-degenerate-outlines case in one guard, no
 * division by zero).
 *
 * **Performance.** Three [union] + three [difference] + four
 * [pathArea] calls per invocation. Sub-millisecond for the typical
 * 1–3 wound, 1–3 tissue-per-type case but recomputed on every
 * dashboard recomposition. M11 should wrap the call in
 * `remember(store.wounds, store.revision.value)` or
 * `derivedStateOf` to memoise across recompositions until the wound
 * list actually changes.
 */
internal fun percentagesByType(wounds: List<Wound>): Map<TissueType, Int> {
    val zeros = TissueType.knownValues.associateWith { 0 }

    val woundsUnionArea = wounds.sumOf { signedArea(it.outline).absoluteValue.toDouble() }
    if (woundsUnionArea < ZERO_AREA_EPSILON) return zeros

    val perType: Map<TissueType, Path> = TissueType.knownValues.associateWith { type ->
        val paths = wounds
            .flatMap { wound -> wound.tissues.filter { it.type == type } }
            .map { polygonToPath(it.outline) }
        if (paths.isEmpty()) Path() else paths.reduce { acc, p -> union(acc, p) ?: acc }
    }

    val grossArea: Map<TissueType, Double> = perType.mapValues { (_, p) -> pathArea(p).toDouble() }

    val sortedTypes = TissueType.knownValues.sortedBy { grossArea.getValue(it) }

    var claimed = Path()
    val netArea = mutableMapOf<TissueType, Double>()
    for (t in sortedTypes) {
        val perTypePath = perType.getValue(t)
        val exclusive = difference(perTypePath, claimed) ?: perTypePath
        netArea[t] = pathArea(exclusive).toDouble()
        claimed = union(claimed, perTypePath) ?: claimed
    }

    val rawTotal = netArea.values.sum()
    val scale = if (rawTotal > woundsUnionArea) woundsUnionArea / rawTotal else 1.0

    // Un-rounded per-type percentages (Double). After the scale
    // factor above, the sum is ≤ 100 modulo float noise.
    val raws: Map<TissueType, Double> = TissueType.knownValues.associateWith { t ->
        (netArea.getValue(t) * scale / woundsUnionArea * 100.0).coerceAtLeast(0.0)
    }

    // Largest-remainder apportionment. Floor each value, then
    // distribute the leftover (target − sum-of-floors) units to
    // the types with the largest fractional remainders. Guarantees
    // the integer sum equals floor(rawTotalPct).
    val target = raws.values.sum().coerceIn(0.0, 100.0).toInt()
    val floors: MutableMap<TissueType, Int> = TissueType.knownValues
        .associateWith { raws.getValue(it).toInt() }
        .toMutableMap()
    var remaining = target - floors.values.sum()
    if (remaining > 0) {
        val byFractionalRemainder = raws.entries.sortedByDescending { it.value - it.value.toInt() }
        for ((t, _) in byFractionalRemainder) {
            if (remaining <= 0) break
            floors[t] = floors.getValue(t) + 1
            remaining--
        }
    }
    return floors
}

private const val ZERO_AREA_EPSILON: Double = 1.0
