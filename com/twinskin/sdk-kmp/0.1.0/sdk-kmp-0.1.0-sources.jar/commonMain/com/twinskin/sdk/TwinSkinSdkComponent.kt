package com.twinskin.sdk

import com.twinskin.sdk.capture.CaptureApi
import com.twinskin.sdk.capture.CaptureObserver
import com.twinskin.sdk.capture.SdkCaptureStore
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.sdk_client.SdkServerClient
import com.twinskin.sdk.storage.SdkStorage
import com.twinskin.sdk.transfer.TransferManager
import com.twinskin.sdk.transfer.UrlResolver
import com.twinskin.sdk.transfer.ZipEngine

/**
 * The internal wiring graph built by platform-specific `initialize`
 * functions. Kept constructor-injected so tests and advanced integrators
 * can still build a component (or bypass it entirely and wire
 * [CaptureApi] themselves) without going through the [TwinSkinSdk]
 * singleton.
 */
internal class TwinSkinSdkComponent(
    val captureApi: CaptureApi,
    val transferManager: TransferManager,
    val serverClient: SdkServerClient,
    val store: SdkCaptureStore,
    val database: TwinSkinDatabase,
    val urlResolver: UrlResolver,
    val zipEngine: ZipEngine,
    val storage: SdkStorage,
    val captureObserver: CaptureObserver,
    val logger: SdkLogger = SdkLogger.None,
    val devMode: Boolean = false,
    val verboseFrameLogs: Boolean = false,
    val captureMode: CaptureMode = CaptureMode.AccelerometerCapture,
)
