package com.twinskin.sdk.geometry

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.PathSegment
import kotlin.math.absoluteValue

/**
 * Converts a closed polygon (vertex list) to a Compose [Path]. Walks
 * the vertices in order, closing the path at the end.
 *
 * Empty/degenerate input returns an empty [Path].
 */
internal fun polygonToPath(poly: List<Offset>): Path {
    val path = Path()
    if (poly.isEmpty()) return path
    path.moveTo(poly[0].x, poly[0].y)
    for (i in 1 until poly.size) {
        path.lineTo(poly[i].x, poly[i].y)
    }
    path.close()
    return path
}

/**
 * Splits [path] into one polygon per sub-path by walking the verb
 * stream via [Path.iterator].
 *
 *  - `Move` finalises the in-flight sub-path and starts a new one.
 *  - `Line`/`Quadratic`/`Conic`/`Cubic` append their end point. Curves,
 *    if present, are linearised end-only. For boolean-op results
 *    between polygons both Android and Skia emit lines, so this is the
 *    common case; downstream callers re-densify so any coarseness
 *    introduced by a stray curve is absorbed.
 *  - `Close`/`Done` finalise the in-flight sub-path.
 *
 * Sub-paths with fewer than 3 distinct vertices are dropped — they're
 * artifacts of degenerate booleans, not real polygons.
 *
 * Returned sub-paths may or may not carry a trailing duplicate of the
 * first vertex depending on which `Path` backend emitted the verb
 * stream (Android's native `Path` and Skia's `SkPath` differ here).
 * Consumers should treat each list as logically closed and not rely on
 * a specific length — area, point-in-polygon, and the boolean
 * primitives are all robust to a duplicated final vertex.
 */
internal fun pathToPolygons(path: Path): List<List<Offset>> {
    val out = mutableListOf<List<Offset>>()
    var current: MutableList<Offset>? = null

    fun finalise() {
        val c = current
        if (c != null && c.size >= 3) out += c.toList()
        current = null
    }

    fun appendEnd(seg: PathSegment, xIdx: Int, yIdx: Int) {
        val end = Offset(seg.points[xIdx], seg.points[yIdx])
        val start = Offset(seg.points[0], seg.points[1])
        val c = current ?: mutableListOf<Offset>().also { it.add(start); current = it }
        c.appendUnique(end)
    }

    for (seg in path.iterator()) {
        when (seg.type) {
            PathSegment.Type.Move -> {
                finalise()
                current = mutableListOf(Offset(seg.points[0], seg.points[1]))
            }
            PathSegment.Type.Line -> appendEnd(seg, 2, 3)
            PathSegment.Type.Quadratic -> appendEnd(seg, 4, 5)
            PathSegment.Type.Conic -> appendEnd(seg, 4, 5)
            PathSegment.Type.Cubic -> appendEnd(seg, 6, 7)
            PathSegment.Type.Close, PathSegment.Type.Done -> finalise()
        }
    }
    finalise()
    return out
}

private fun MutableList<Offset>.appendUnique(p: Offset) {
    if (isEmpty() || (last() - p).getDistanceSquared() > 1e-6f) add(p)
}

/**
 * Boolean intersect — `a ∩ b`. Returns `null` when the backend's
 * `Path.op` bails (pathological inputs — self-intersection, NaN, etc.);
 * callers must treat that as a failure rather than an empty path.
 */
internal fun intersect(a: Path, b: Path): Path? = booleanOp(a, b, PathOperation.Intersect)

/** Boolean union — `a ∪ b`. `null` on backend failure. */
internal fun union(a: Path, b: Path): Path? = booleanOp(a, b, PathOperation.Union)

/** Boolean difference — `a \ b`. `null` on backend failure. */
internal fun difference(a: Path, b: Path): Path? = booleanOp(a, b, PathOperation.Difference)

private fun booleanOp(a: Path, b: Path, op: PathOperation): Path? {
    val result = Path()
    return if (result.op(a, b, op)) result else null
}

/**
 * Net area of [path] accounting for polygon-with-hole topology.
 * `Path.op` (Difference/Union) encodes holes as separate sub-paths,
 * and orientation isn't a stable contract — so we infer outer-vs-hole
 * by containment: a sub-path is a hole when another sub-path's bbox
 * strictly contains its bbox AND its centroid sits inside that other.
 * Outer areas are added, hole areas subtracted. Falls back to 0 when
 * floating noise produces a tiny negative.
 */
internal fun pathArea(path: Path): Float {
    val polys = pathToPolygons(path)
    if (polys.isEmpty()) return 0f
    val boxes = polys.map { bbox(it) }
    val centroids = polys.map { centroid(it) }
    var area = 0f
    for (i in polys.indices) {
        val absArea = signedArea(polys[i]).absoluteValue
        val isHole = polys.indices.any { j ->
            j != i &&
                bboxStrictlyContains(boxes[j], boxes[i]) &&
                pointInPolygon(centroids[i], polys[j])
        }
        area += if (isHole) -absArea else absArea
    }
    return area.coerceAtLeast(0f)
}

private fun bboxStrictlyContains(outer: androidx.compose.ui.geometry.Rect, inner: androidx.compose.ui.geometry.Rect): Boolean {
    if (outer.left > inner.left) return false
    if (outer.top > inner.top) return false
    if (outer.right < inner.right) return false
    if (outer.bottom < inner.bottom) return false
    // At least one dimension must be strictly larger so equal-bbox
    // polygons (e.g. duplicates) aren't mutually classified as holes.
    return outer.left < inner.left ||
        outer.top < inner.top ||
        outer.right > inner.right ||
        outer.bottom > inner.bottom
}
