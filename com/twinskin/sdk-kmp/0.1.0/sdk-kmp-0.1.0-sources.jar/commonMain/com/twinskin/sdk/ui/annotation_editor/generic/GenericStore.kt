package com.twinskin.sdk.ui.annotation_editor.generic

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import com.twinskin.sdk.capture.GenericAnnotation
import com.twinskin.sdk.geometry.denormalise
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.reDensify

/**
 * Single source of truth for the generic editor — a flat list of
 * polygons in image-px. Sibling to `DelineationStore` with the wound
 * machinery stripped out: no wounds, no tissues, no card states, no
 * disk-backed draft.
 *
 * Compose observation is split across two channels:
 *   - The underlying [SnapshotStateList] lets widgets read individual
 *     polygons and recompose on per-cell changes.
 *   - The lightweight [revision] counter is the wake-up the drawing
 *     canvas reads — one `State<Int>` change per mutation rather than
 *     iterating the polygon list during recomposition scoping.
 *
 * Construction goes through [fromInitial] (re-edit from a wire seed).
 * `restore` re-densifies imported polygons so the polygon-engine's
 * `[2, 10]` image-px vertex-spacing invariant always holds even if
 * the snapshot carried sparser data.
 */
@Stable
internal class GenericStore private constructor(
    initialPolygons: List<List<Offset>>,
    val imageSize: Size,
) {
    private val _polygons: SnapshotStateList<List<Offset>> =
        mutableStateListOf<List<Offset>>().also { it.addAll(initialPolygons) }
    private val _revision = mutableStateOf(0)

    val polygons: List<List<Offset>> get() = _polygons

    /** Bumps on every mutation. Canvas readers observe this instead of the lists. */
    val revision: State<Int> get() = _revision

    fun addPolygon(outline: List<Offset>) {
        _polygons.add(outline)
        bump()
    }

    fun replacePolygon(idx: Int, outline: List<Offset>) {
        requireIdx(idx)
        _polygons[idx] = outline
        bump()
    }

    fun removePolygon(idx: Int) {
        requireIdx(idx)
        _polygons.removeAt(idx)
        bump()
    }

    fun clear() {
        _polygons.clear()
        bump()
    }

    /** Captures the mutable state. Used for undo (sideState on the controller's UndoEntry). */
    fun snapshot(): GenericStoreSnapshot = GenericStoreSnapshot(
        polygons = _polygons.toList(),
    )

    /**
     * Restores [s] into this store, bumping [revision] once. Every
     * restored polygon is run through [reDensify] so the reshape
     * engine's `[2, 10]` image-px vertex-spacing invariant always
     * holds even if the snapshot carried sparser data. Idempotent
     * on already-dense outlines.
     */
    fun restore(s: GenericStoreSnapshot) {
        _polygons.clear()
        _polygons.addAll(s.polygons.map { reDensify(it) })
        bump()
    }

    private fun requireIdx(idx: Int) {
        require(idx in _polygons.indices) {
            "polygon index $idx out of bounds (size=${_polygons.size})"
        }
    }

    private fun bump() {
        _revision.value = _revision.value + 1
    }

    companion object {
        /**
         * Hydrates from a [GenericAnnotation] seed: denormalises every
         * `Point2D` from `[0..1]` to image-pixel `Offset` and
         * re-densifies the outline to the canonical `[2, 10]` image-px
         * vertex spacing the reshape engine assumes (sparse external
         * polygons would otherwise give the raised-cosine falloff
         * nothing to grip).
         */
        fun fromInitial(annotation: GenericAnnotation, imageSize: Size): GenericStore {
            val polygons = annotation.regions.map { region ->
                reDensify(
                    region.points.map { p ->
                        denormalise(Offset(p.x.toFloat(), p.y.toFloat()), imageSize)
                    },
                )
            }
            return GenericStore(
                initialPolygons = polygons,
                imageSize = imageSize,
            )
        }
    }
}

/** Value snapshot of the store — used by undo (M4) and any future draft codec. */
@Immutable
internal data class GenericStoreSnapshot(
    val polygons: List<List<Offset>>,
)
