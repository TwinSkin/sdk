package com.twinskin.sdk.ui.annotation_editor.generic.i18n

/**
 * String table for the generic annotation editor. Minimal compared
 * to the wound editor's `Strings` — no tissue terminology, no help
 * slides, no reshape advisory.
 *
 * v1 ships EN only ([GenericEnStrings]). Future locales mirror the
 * wound editor's `EnStrings`/`FrStrings`/… pattern; the
 * polygon/-level `LocaleResolver` decides which implementation to
 * hand the editor.
 */
internal interface GenericStrings {

    // ── Intro screen ──────────────────────────────────────────────
    val introTitle: String
    val introDescription: String
    val warningBanner: String
    val resumeBanner: String
    val resumeButton: String
    val startFreshButton: String
    val continueButton: String

    // ── Common chrome ─────────────────────────────────────────────
    val helpContentDescription: String
    val backContentDescription: String
    val backButton: String
    val cancelButton: String

    // ── Drawing screen ────────────────────────────────────────────
    val drawingTitle: String
    val undoButton: String
    val deleteButton: String
    val validateButton: String
    val tooFarFromOpenStroke: String
    val abandonDialogTitle: String
    val abandonDialogBody: String
    val leaveButton: String
    val stayButton: String

    // ── Root (validate retry) ─────────────────────────────────────
    val saveFailedSnackbar: String
    val retryAction: String

    // ── A11y ──────────────────────────────────────────────────────
    val canvasContentDescription: String
    val magnifierContentDescription: String
}
