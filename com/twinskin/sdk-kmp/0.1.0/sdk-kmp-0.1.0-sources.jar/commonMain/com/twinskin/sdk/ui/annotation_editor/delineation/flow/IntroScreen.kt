package com.twinskin.sdk.ui.annotation_editor.delineation.flow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.annotation_editor.delineation.help.HelpDialog
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.Strings
import com.twinskin.sdk.ui.annotation_editor.delineation.ui_helpers.EditorBar
import com.twinskin.sdk.ui.theme.BrandCard
import com.twinskin.sdk.ui.theme.PrimaryButton
import com.twinskin.sdk.ui.theme.TwinSkinColors

/**
 * Annotation editor entry screen (spec §5), rebuilt pixel-for-pixel
 * against the Claude Design prototype `WeIntroScreen`
 * (`screens_wound_editor.jsx`): a prototype [EditorBar], an optional
 * white "Resume / Start fresh" card, a `Step 1 of 2 — Draw the
 * contour` title (24 sp, medium), two instructional paragraphs, the
 * `tintMid` no-auto-save warning banner pinned above the footer, and
 * a trailing Cancel + Continue footer (Continue only in fresh mode).
 *
 * The Resume banner (SDK-specific — Flutter has no equivalent)
 * appears above the instructional content when [hasExistingState]
 * is true, replacing Continue in the footer with its own
 * Resume / Start fresh buttons. Cancel stays in the footer either
 * way so the user always has an escape hatch. "Existing state"
 * (M15.17) covers both an on-disk draft from an interrupted
 * session AND the capture's already-saved annotation: the user
 * needs an explicit choice between continuing to edit and
 * starting fresh whenever the canvas would otherwise open with
 * non-empty seed.
 *
 * The help icon on the bar opens [HelpDialog] over
 * `strings.helpSlides.intro` (M12 content). The back arrow mirrors
 * Cancel — the integrator's back-stack wiring (system back /
 * nav-bar back) also calls [onCancel].
 */
@Composable
internal fun IntroScreen(
    /**
     * Whether the editor has anything to resume — an on-disk draft
     * from an interrupted session OR an already-saved annotation
     * passed in via `initial`. When true, the Resume banner is shown
     * and the bottom single CTA is hidden; the banner's two buttons
     * route to [onResume] / [onStart] respectively.
     */
    hasExistingState: Boolean,
    strings: Strings,
    /**
     * Label for the primary CTA when [hasExistingState] is false
     * (fresh mode, nothing to resume). WoundAnnotationEditor passes
     * [Strings.startDrawingButton] in edit-existing mode and
     * [Strings.continueButton] in fresh mode.
     */
    startActionLabel: String,
    onResume: () -> Unit,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var showHelp by remember { mutableStateOf(false) }
    Surface(
        modifier = modifier.fillMaxSize(),
        color = TwinSkinColors.Surface,
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            EditorBar(
                title = strings.introTitle,
                onBack = onCancel,
                backContentDescription = strings.backContentDescription,
                onHelp = { showHelp = true },
                helpContentDescription = strings.helpContentDescription,
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp),
            ) {
                Spacer(Modifier.height(24.dp))
                if (hasExistingState) {
                    ResumeBanner(strings = strings, onResume = onResume, onStartFresh = onStart)
                    Spacer(Modifier.height(24.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    text = strings.introStep1Title,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Medium,
                    color = TwinSkinColors.Ink,
                )
                Spacer(Modifier.height(24.dp))
                Text(
                    text = strings.introStep1DescriptionP1,
                    style = MaterialTheme.typography.bodyLarge,
                    color = TwinSkinColors.Ink2,
                )
                Spacer(Modifier.height(16.dp))
                Text(
                    text = strings.introStep1DescriptionP2,
                    style = MaterialTheme.typography.bodyLarge,
                    color = TwinSkinColors.Ink2,
                )
                Spacer(Modifier.height(24.dp))
            }
            // Prototype warning banner: tintMid surface, error-tinted
            // warning glyph, ink2 body. Distinct from the generic
            // `WarningBanner` (surfaceVariant) so it matches
            // `WeIntroScreen`'s bottom strip exactly.
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                shape = RoundedCornerShape(12.dp),
                color = TwinSkinColors.TintMid,
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Warning,
                        contentDescription = null,
                        tint = TwinSkinColors.Error,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = strings.warningBanner,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Medium,
                        ),
                        color = TwinSkinColors.Ink2,
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(start = 24.dp, top = 12.dp, end = 24.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(
                    onClick = onCancel,
                    colors = ButtonDefaults.textButtonColors(contentColor = TwinSkinColors.Teal),
                ) { Text(strings.cancelButton) }
                if (!hasExistingState) {
                    Spacer(Modifier.width(12.dp))
                    PrimaryButton(text = startActionLabel, onClick = onStart)
                }
            }
        }
    }
    if (showHelp) {
        HelpDialog(
            slides = strings.helpSlides.intro,
            strings = strings,
            onClose = { showHelp = false },
        )
    }
}

/**
 * Prototype resume card (`WeIntroScreen` "isEdit" block): white
 * `card` surface, the resume prompt copy, then a Resume (teal-filled
 * pill) + Start fresh (teal-text pill) button row.
 */
@Composable
private fun ResumeBanner(
    strings: Strings,
    onResume: () -> Unit,
    onStartFresh: () -> Unit,
) {
    BrandCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text = strings.resumeBanner,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = TwinSkinColors.Ink,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Button(
                    onClick = onResume,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TwinSkinColors.Teal,
                        contentColor = TwinSkinColors.OnTeal,
                    ),
                ) { Text(strings.resumeButton) }
                TextButton(
                    onClick = onStartFresh,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.textButtonColors(contentColor = TwinSkinColors.Teal),
                ) { Text(strings.startFreshButton) }
            }
        }
    }
}
