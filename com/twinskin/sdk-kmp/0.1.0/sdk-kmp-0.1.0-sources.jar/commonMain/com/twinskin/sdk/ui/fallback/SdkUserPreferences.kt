package com.twinskin.sdk.ui.fallback

public interface SdkUserPreferences {
    public var tutorialDontShowAgain: Boolean

    public companion object {
        public fun inMemory(initial: Boolean = false): SdkUserPreferences =
            InMemorySdkUserPreferences(initial)
    }
}

internal class InMemorySdkUserPreferences(
    initial: Boolean = false,
) : SdkUserPreferences {
    override var tutorialDontShowAgain: Boolean = initial
}

public expect fun defaultSdkUserPreferences(): SdkUserPreferences
