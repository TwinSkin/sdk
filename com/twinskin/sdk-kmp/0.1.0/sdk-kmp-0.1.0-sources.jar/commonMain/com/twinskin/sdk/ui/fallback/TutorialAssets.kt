package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp

// Compose Multiplatform's `composeResources/` does not pack into the
// AAR or the K/N framework when `:shared` uses the
// `com.android.kotlin.multiplatform.library` plugin (CMP 1.10.0 bug —
// `copyAndroidMainComposeResourcesToAndroidAssets.outputDirectory`
// is never wired; `:shared` has no `mergeAndroidMainAssets` task).
// Tutorial bitmaps therefore live in `:android-sdk/src/main/assets/`
// (the standard-AGP facade module — merged into the consuming APK's
// `assets/` and read here via `context.assets.open(name)`) and
// `sdk-ios/Sources/Resources/` (resolved by Swift from `Bundle.module`
// and forwarded as paths via the `LocalTutorialAssetPaths` CompositionLocal).
// See packages/sdk/CLAUDE.md ("demo-shared can't use Compose Resources").

/**
 * iOS-only side channel for the tutorial bitmap paths. The Swift
 * `AccelerometerCaptureView` resolves `Bundle.module.path(forResource:)` and
 * supplies the absolute paths via the iOS `AccelerometerCaptureViewController`
 * entry point. Android ignores this — assets are read from the AAR's
 * `assets/` folder by name.
 */
public data class TutorialAssetPaths(
    val doPng: String? = null,
    val dontPng: String? = null,
    val videoMp4: String? = null,
)

public val LocalTutorialAssetPaths: ProvidableCompositionLocal<TutorialAssetPaths> =
    staticCompositionLocalOf { TutorialAssetPaths() }

@Composable
internal expect fun rememberBundledTutorialBitmap(name: TutorialAssetName): ImageBitmap?

internal enum class TutorialAssetName { Do, Dont }

/**
 * Default tutorial-illustrations slot wiring used by both the Android
 * and iOS hosts. Used as the `tutorialIllustrations` slot of
 * [AccelerometerCaptureScreen].
 */
@Composable
internal fun BundledTutorialIllustrations(slot: TutorialIllustrationSlot) {
    when (slot) {
        TutorialIllustrationSlot.DoDont -> {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                TutorialIllustrationTile(
                    asset = TutorialAssetName.Do,
                    modifier = Modifier.weight(1f),
                )
                TutorialIllustrationTile(
                    asset = TutorialAssetName.Dont,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        TutorialIllustrationSlot.OrbitExample -> {
            // No dedicated orbit asset bundled; reuse the `do` framing
            // as a close-enough orbit reference until #525 ships one.
            TutorialIllustrationTile(
                asset = TutorialAssetName.Do,
                modifier = Modifier.fillMaxWidth().height(220.dp),
            )
        }
    }
}

@Composable
private fun TutorialIllustrationTile(
    asset: TutorialAssetName,
    modifier: Modifier = Modifier,
) {
    val bitmap = rememberBundledTutorialBitmap(asset)
    Box(
        modifier = modifier
            .height(160.dp)
            .background(color = Color(0x33FFFFFF), shape = RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            Image(
                painter = BitmapPainter(bitmap),
                contentDescription = null,
                modifier = Modifier.fillMaxSize().padding(8.dp),
                contentScale = ContentScale.Fit,
            )
        }
    }
}
