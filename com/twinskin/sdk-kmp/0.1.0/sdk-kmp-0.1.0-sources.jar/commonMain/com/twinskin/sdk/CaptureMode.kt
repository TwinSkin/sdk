package com.twinskin.sdk

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Which capture pipeline a SDK instance runs. Selected once at
 * [TwinSkinConfig] / [TwinSkinConfiguration] time and read by the
 * capture-screen launcher and the upload pipeline through
 * [TwinSkinSdk.captureMode].
 *
 * Wire format mirrors the value persisted to [SdkCaptureUpload.captureMode]
 * and stamped on each capture row so the upload pipeline can pick the
 * matching bundle layout long after the originating session has ended.
 */
@Serializable
public enum class CaptureMode {
    @SerialName("photosphere") Photosphere,
    @SerialName("accelerometer_capture") AccelerometerCapture,
    ;

    internal fun toWireValue(): String = when (this) {
        Photosphere -> "photosphere"
        AccelerometerCapture -> "accelerometer_capture"
    }

    public companion object {
        internal fun fromWireValue(value: String?): CaptureMode = when (value) {
            // Legacy rows written before [CaptureMode] was persisted default to
            // photosphere — the only pipeline shipped at the time.
            null, "photosphere" -> Photosphere
            "accelerometer_capture" -> AccelerometerCapture
            else -> error("unknown captureMode wire value: $value")
        }
    }
}
