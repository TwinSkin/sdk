package com.twinskin.sdk.ui.annotation_editor.polygon.canvas

import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerId
import com.twinskin.sdk.ui.annotation_editor.delineation.canvas.parentWoundIdxAt
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Tissue
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.EditorController
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.GestureCtx

/**
 * The body of [DrawingCanvas]'s `awaitEachGesture` loop (spec §6.7
 * and §6.8). Extracted into its own file so the composable stays
 * readable.
 *
 * **State machine.** Three modes:
 *  - `Ambiguous` — first finger is down but the canvas hasn't yet
 *    decided whether this is a 1-finger draw or a 2-finger pinch.
 *    Stays here for at most one pointer-event tick.
 *  - `Draw` — single-finger gesture, routed through [EditorController].
 *    Additional pointer-downs are silently ignored per spec §6.7.
 *  - `Pinch` — two-finger gesture, drives [ZoomPanController]. Stays
 *    pinch until all fingers lift, even if one of the two goes up
 *    early (the remaining finger does NOT promote to draw — picking
 *    up where the user left off would be jarring).
 *
 * **Why ambiguous-first.** Compose delivers pointer-down events
 * one-at-a-time even for "simultaneous" two-finger gestures (the
 * second pointer typically arrives on the very next event frame).
 * Committing to draw on the first down would lose every pinch
 * whose second finger lands ~16 ms later. The ambiguous tick
 * resolves on the next event: if pressed pointers >= 2, pinch; else
 * commit to draw.
 *
 * **Tap finalisation.** When the user lifts the only finger while
 * still ambiguous (e.g. a clean tap with no drift), the loop fires
 * [EditorController.onTouchDown] followed immediately by
 * [EditorController.onTouchUp] at the down position so the
 * controller's tap-or-focus path runs. Without this, a fast tap
 * would be silently dropped.
 *
 * **Parent-wound resolution.** On screen 4 the canvas tracks the
 * "currently active" parent wound (set on stroke start; updated by
 * the host's LaunchedEffect on focus change for reshape). The
 * gesture loop reads it via [getActiveParentWoundIdx] for every
 * [GestureCtx] build, so the controller's stroke clamp and reshape
 * clamp both see the same confinement outline.
 */
internal suspend fun AwaitPointerEventScope.drawCanvasGesture(
    controller: EditorController,
    zoomPan: ZoomPanController,
    canvasSizeRead: () -> Size,
    imageSize: Size,
    readOnlyWounds: List<Wound>,
    readOnlyOtherTissues: List<Tissue>,
    /**
     * True when this canvas is hosting tissue editing on screen 4
     * (the tissue list is mutated per-move during reshape). The
     * gesture loop only needs the boolean to decide containment +
     * new-stroke eligibility; the tissue list itself is read
     * through `rememberUpdatedState` so pointerInput keys stay
     * stable across the reshape.
     */
    onScreen4: Boolean,
    onFingerCanvasUpdate: (Offset?) -> Unit,
    getActiveParentWoundIdx: () -> Int?,
    setActiveParentWoundIdx: (Int?) -> Unit,
) {
    val first = awaitFirstDown(requireUnconsumed = false)
    first.consume()
    onFingerCanvasUpdate(first.position)

    val woundOutlines: List<List<Offset>> = readOnlyWounds.map { it.outline }
    val forbiddenOutlines: List<List<Offset>> = readOnlyOtherTissues.map { it.outline }

    fun buildCtx(parentIdxOverride: Int? = null): GestureCtx {
        val cs = canvasSizeRead()
        val fit = fitTransform(cs, imageSize)
        val effectiveScale = fit.fitScale * zoomPan.scale
        // Pan in GestureCtx terms = canvas-px offset of the image's
        // top-left under the combined transform.
        val panX = (cs.width - imageSize.width * effectiveScale) * 0.5f + zoomPan.offset.x
        val panY = (cs.height - imageSize.height * effectiveScale) * 0.5f + zoomPan.offset.y
        val parentIdx = parentIdxOverride ?: getActiveParentWoundIdx()
        val confinement = if (onScreen4 && parentIdx != null && parentIdx in readOnlyWounds.indices) {
            readOnlyWounds[parentIdx].outline
        } else {
            null
        }
        return GestureCtx(
            canvasSize = cs,
            imageSize = imageSize,
            canvasFromImageScale = effectiveScale,
            pan = Offset(panX, panY),
            containmentPolygons = if (onScreen4) woundOutlines else null,
            forbiddenInteriors = forbiddenOutlines,
            confinementOutline = confinement,
        )
    }

    var mode: Mode = Mode.Ambiguous
    val primaryId: PointerId = first.id
    var secondaryId: PointerId? = null
    var prevPrimary: Offset = first.position
    var prevSecondary: Offset? = null

    while (true) {
        val event = awaitPointerEvent()
        val pressed = event.changes.filter { it.pressed }

        when (mode) {
            Mode.Ambiguous -> {
                if (pressed.size >= 2) {
                    val a = pressed[0]
                    val b = pressed[1]
                    secondaryId = if (a.id == primaryId) b.id else a.id
                    prevPrimary = if (a.id == primaryId) a.position else b.position
                    prevSecondary = if (a.id == primaryId) b.position else a.position
                    mode = Mode.Pinch
                    onFingerCanvasUpdate(null)
                    for (c in event.changes) c.consume()
                } else {
                    val primary = pressed.firstOrNull { it.id == primaryId }
                    if (primary != null) {
                        val parentIdx = if (onScreen4) {
                            val downImage = canvasToImage(
                                canvasPos = first.position,
                                canvasSize = canvasSizeRead(),
                                imageSize = imageSize,
                                zoomScale = zoomPan.scale,
                                zoomPan = zoomPan.offset,
                            )
                            val idx = parentWoundIdxAt(downImage, woundOutlines)
                            setActiveParentWoundIdx(idx)
                            idx
                        } else {
                            null
                        }
                        val downCtx = buildCtx(parentIdxOverride = parentIdx)
                        controller.onTouchDown(first.position, downCtx)
                        if (primary.position != first.position) {
                            controller.onTouchMove(primary.position, buildCtx(parentIdxOverride = parentIdx))
                            prevPrimary = primary.position
                        }
                        onFingerCanvasUpdate(primary.position)
                        primary.consume()
                        mode = Mode.Draw
                    }
                }
            }

            Mode.Draw -> {
                val primary = pressed.firstOrNull { it.id == primaryId }
                if (primary != null) {
                    if (primary.position != prevPrimary) {
                        controller.onTouchMove(primary.position, buildCtx())
                        prevPrimary = primary.position
                    }
                    onFingerCanvasUpdate(primary.position)
                    primary.consume()
                }
                for (c in event.changes) {
                    if (c.id != primaryId) c.consume()
                }
            }

            Mode.Pinch -> {
                val a = pressed.firstOrNull { it.id == primaryId }
                val b = pressed.firstOrNull { it.id == secondaryId }
                val pp = prevSecondary
                if (a != null && b != null && pp != null) {
                    val ratio = pinchScaleRatio(a.position, b.position, prevPrimary, pp)
                    val centroid = pinchCentroid(a.position, b.position)
                    val prevCentroid = pinchCentroid(prevPrimary, pp)
                    zoomPan.setScaleAnchored(zoomPan.scale * ratio, centroid)
                    zoomPan.translateClamped(centroid - prevCentroid)
                    prevPrimary = a.position
                    prevSecondary = b.position
                }
                for (c in event.changes) c.consume()
                onFingerCanvasUpdate(null)
            }
        }

        if (pressed.isEmpty()) {
            when (mode) {
                Mode.Ambiguous -> {
                    // Pure tap — fire down/up at the original position
                    // so the controller's tap-or-focus path runs.
                    val ctx = buildCtx()
                    controller.onTouchDown(first.position, ctx)
                    controller.onTouchUp(first.position, ctx)
                }
                Mode.Draw -> {
                    controller.onTouchUp(prevPrimary, buildCtx())
                }
                Mode.Pinch -> {
                    // Pinch is presentation-only — nothing to commit.
                }
            }
            setActiveParentWoundIdx(null)
            // Hold the magnifier's tracked finger position on touch-up
            // for Draw and Ambiguous (tap) so the strip stays frozen
            // on the last position. Pinch clears it — a crosshair
            // after a two-finger gesture would be misleading.
            if (mode == Mode.Pinch) {
                onFingerCanvasUpdate(null)
            }
            break
        }
    }
}

private enum class Mode { Ambiguous, Draw, Pinch }
