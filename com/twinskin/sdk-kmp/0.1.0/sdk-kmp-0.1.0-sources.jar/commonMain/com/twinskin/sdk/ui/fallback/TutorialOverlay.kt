package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * On-demand tutorial sheet opened by the [HelpButton] in the top bar.
 * Mirrors the web_app's `InstructionsDialog` (full-screen video player
 * over a black scaffold; title "How to capture?"; circle-bordered close).
 *
 * The video player itself is a platform-specific slot — common code
 * draws a placeholder, native hosts inject a real player. This keeps
 * `:shared` free of `androidx.media3` / `AVKit` dependencies while
 * still owning the screen layout.
 */
@Composable
public fun TutorialOverlay(
    onDismiss: () -> Unit,
    tutorialPlayer: @Composable () -> Unit = { TutorialVideoPlaceholder() },
) {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(enabled = false) {},
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .border(width = 2.dp, color = colors.onPrimary, shape = CircleShape)
                        .clickable { onDismiss() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Close,
                        contentDescription = "Close tutorial", /* video_capture_tutorial_close */
                        tint = colors.onPrimary,
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Text(
                        text = "How to capture?", /* video_capture_tutorial_title */
                        color = colors.onPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                Spacer(modifier = Modifier.size(40.dp))
            }
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f).padding(16.dp),
                contentAlignment = Alignment.Center,
            ) {
                tutorialPlayer()
            }
        }
    }
}

/**
 * Default placeholder; hosts may override [AccelerometerCaptureScreen]'s
 * `tutorialPlayer` slot with a platform-specific player (Android
 * `VideoView`; iOS Swift `AVPlayer` is a follow-up).
 */
@Composable
internal fun TutorialVideoPlaceholder() {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .background(
                color = Color(0x33FFFFFF),
                shape = RoundedCornerShape(12.dp),
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "Tutorial video", /* video_capture_tutorial_video_placeholder */
            color = colors.onPrimary,
            fontSize = 14.sp,
        )
    }
}

/** Mirrors web_app's `InfoOverlay`; gated by [SdkUserPreferences.tutorialDontShowAgain]. */
@Composable
public fun FirstRunTutorialOverlay(
    preferences: SdkUserPreferences,
    onDismiss: () -> Unit,
    illustrations: @Composable (TutorialIllustrationSlot) -> Unit = {},
) {
    val colors = LocalAccelerometerCaptureColors.current
    var step by remember { mutableStateOf(TutorialStep.PhotoPrep) }
    var dontShowAgain by remember { mutableStateOf(preferences.tutorialDontShowAgain) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            FirstRunAppBar(
                title = when (step) {
                    TutorialStep.PhotoPrep -> "Take a picture" /* photo_pattern_wound */
                    TutorialStep.VideoOrbit -> "Record a video" /* photo_wound */
                },
                onClose = if (step == TutorialStep.VideoOrbit) onDismiss else null,
                onPrimaryColor = colors.onPrimary,
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    modifier = Modifier.fillMaxWidth().weight(1f).padding(20.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    illustrations(
                        when (step) {
                            TutorialStep.PhotoPrep -> TutorialIllustrationSlot.DoDont
                            TutorialStep.VideoOrbit -> TutorialIllustrationSlot.OrbitExample
                        },
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = when (step) {
                        TutorialStep.PhotoPrep ->
                            "Ensure the wound is centered in the image.\n" +
                                "Keep the camera parallel to the wound’s surface.\n" +
                                "Include the surrounding skin (periwound area).\n" +
                                "Ensure the calibration marker is fully visible."
                        /* complete_capture_info_part_1 */
                        TutorialStep.VideoOrbit ->
                            "Move around the wound to capture it from different angles.\n" +
                                "Ensure the wound and the surrounding skin (periwound area) " +
                                "are visible in all frames.\n" +
                                "The recording ends when the button circle is completely " +
                                "green (20 seconds)."
                        /* complete_capture_info_part_2 */
                    },
                    color = colors.onPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Normal,
                    textAlign = TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(10.dp))
                DontShowAgainRow(
                    checked = dontShowAgain,
                    onCheckedChange = { value ->
                        dontShowAgain = value
                        preferences.tutorialDontShowAgain = value
                    },
                    onPrimaryColor = colors.onPrimary,
                )
                Spacer(modifier = Modifier.height(8.dp))
                FirstRunCtaButton(
                    text = when (step) {
                        TutorialStep.PhotoPrep -> "Take a picture" /* button_take_picture */
                        TutorialStep.VideoOrbit -> "Take a Video" /* button_take_video */
                    },
                    onClick = {
                        when (step) {
                            TutorialStep.PhotoPrep -> step = TutorialStep.VideoOrbit
                            TutorialStep.VideoOrbit -> onDismiss()
                        }
                    },
                    onPrimaryColor = colors.onPrimary,
                )
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun FirstRunAppBar(
    title: String,
    onClose: (() -> Unit)?,
    onPrimaryColor: Color,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 16.dp),
    ) {
        if (onClose != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .size(40.dp)
                    .border(width = 2.dp, color = onPrimaryColor, shape = CircleShape)
                    .clickable { onClose() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Outlined.Close,
                    contentDescription = "Close tutorial", /* video_capture_first_run_close */
                    tint = onPrimaryColor,
                )
            }
        }
        Text(
            text = title,
            color = onPrimaryColor,
            modifier = Modifier.align(Alignment.Center),
            fontSize = 20.sp,
            fontWeight = FontWeight.Normal,
        )
    }
}

@Composable
private fun DontShowAgainRow(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    onPrimaryColor: Color,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
        )
        Box(modifier = Modifier.clickable { onCheckedChange(!checked) }) {
            Text(
                text = "Don’t show again", /* case_capture_help_do_not_show_again */
                color = onPrimaryColor,
                fontSize = 14.sp,
            )
        }
    }
}

@Composable
private fun FirstRunCtaButton(
    text: String,
    onClick: () -> Unit,
    onPrimaryColor: Color,
) {
    // CameraTextButton parity: filled button, onInverseSurface-ish bg,
    // white text. Sized to content with horizontal padding.
    Box(
        modifier = Modifier
            .background(
                color = Color(0xFF424242),
                shape = RoundedCornerShape(20.dp),
            )
            .clickable { onClick() }
            .padding(horizontal = 24.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

/** Internal helper enum for [FirstRunTutorialOverlay]'s step state. */
internal enum class TutorialStep { PhotoPrep, VideoOrbit }

/**
 * Slot identifier for the platform-specific illustration the overlay
 * renders at each step.
 */
public enum class TutorialIllustrationSlot { DoDont, OrbitExample }

@Composable
public fun ExitConfirmationDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.errorScrim)
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .padding(32.dp)
                .background(colors.surface, shape = RoundedCornerShape(12.dp))
                .clickable(enabled = false) {}
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = "Cancel capture?", /* video_capture_exit_title */
                color = colors.onPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "The current photo and any in-progress recording will be discarded.",
                /* video_capture_exit_body */
                color = colors.onPrimary,
                fontSize = 14.sp,
            )
            Spacer(modifier = Modifier.height(24.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .border(width = 2.dp, color = colors.onPrimary, shape = RoundedCornerShape(8.dp))
                        .clickable { onDismiss() }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = "Keep capturing", /* video_capture_exit_dismiss */
                        color = colors.onPrimary,
                        fontSize = 14.sp,
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(colors.error, shape = RoundedCornerShape(8.dp))
                        .clickable { onConfirm() }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = "Cancel", /* video_capture_exit_confirm */
                        color = colors.surface,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}
