package com.twinskin.sdk.capture

/**
 * Canonical bundle filenames.
 *
 * The shape of the accompanying `manifest.json` is defined by [CaptureManifest],
 * which is generated from the Pydantic `SdkCaptureManifest` in
 * `packages/capture_pipeline/src/capture_pipeline/models.py` via
 * `packages/server/tool/generate_external_data_models.dart`.
 */
internal object CaptureBundleEntries {
    /** Reference still filename inside the encrypted bundle.
     *  Sorts before every `view_AAA_rXaY.jpg` entry lexicographically
     *  ('r' < 'v'), matching the on-disk naming the photosphere session
     *  writes. */
    const val IMAGE = "ref_image.jpg"

    /** Per-photo telemetry log packed alongside the JPEGs on every
     *  capture (the photosphere session writes one entry per committed
     *  view, regardless of `verboseFrameLogs`). */
    const val POSE_LOG = "pose_log.json"

    /** Per-analyser-tick metrics. Verbose-only — present in the bundle
     *  iff `TwinSkinConfiguration.verboseFrameLogs=true`. */
    const val FRAME_LOG = "frame_log.jsonl"

    /** Reference-frame keypoints, one-shot at `captureReference`.
     *  Verbose-only — same gate as [FRAME_LOG]. */
    const val REFERENCE_KEYPOINTS = "reference_keypoints.json"

    /** Video filename inside `accelerometer_capture` bundles produced by the
     *  Android `CameraXAccelerometerVideoRecorder`. */
    const val VIDEO_FILENAME_MP4 = "video.mp4"

    /** Video filename inside `accelerometer_capture` bundles produced by the
     *  iOS `AVFoundationAccelerometerVideoRecorder`. */
    const val VIDEO_FILENAME_MOV = "video.mov"

    /** Companion sensor log packed next to the video on
     *  `accelerometer_capture` bundles. Surfaced on the manifest via
     *  `video_metadata_filename` — NOT listed in [KNOWN_SIDECARS] so
     *  the decrypt-side whitelist extractor doesn't pick it up
     *  alongside the SDK-pipeline sidecars. */
    const val VIDEO_METADATA_FILENAME = "video_metadata.json"

    /** Sidecar filenames the submit packing pass enumerates in the
     *  capture's working directory. Order is the deterministic wire
     *  order in `manifest.sidecars` — `CaptureApiTest` pins it. */
    val KNOWN_SIDECARS: List<String> = listOf(POSE_LOG, FRAME_LOG, REFERENCE_KEYPOINTS)
}
