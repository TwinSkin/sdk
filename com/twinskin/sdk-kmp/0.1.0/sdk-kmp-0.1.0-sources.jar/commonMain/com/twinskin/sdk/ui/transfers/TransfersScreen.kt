@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.transfers

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.CaptureState
import com.twinskin.sdk.capture.PendingUpload
import com.twinskin.sdk.ui.theme.IconChip
import com.twinskin.sdk.ui.theme.TwinSkinColors
import com.twinskin.sdk.ui.theme.TwinSkinTheme

/**
 * Vertical brand background gradient from the prototype (`tokens.jsx`
 * `BG_GRADIENT`): top cyan-tint → surface → white.
 */
private val TransfersBackground = Brush.verticalGradient(
    0.0f to Color(0xFFDDF0F9),
    0.32f to Color(0xFFEAF6FB),
    0.68f to TwinSkinColors.Surface,
    1.0f to Color(0xFFFFFFFF),
)

/**
 * Transfers — Module B. A stateless, on-brand list rendered from the
 * `TwinSkin.captures.observePendingUploads()` stream (one [TransferCard] per
 * [PendingUpload]) in the prototype's transfer-card visual language
 * (`screens_flow.jsx` → `UploadScreen`). The queue survives app restarts; the
 * SDK re-emits the full list on every change, so this screen just renders
 * whatever it's given.
 *
 * Stateless by design (mirrors [com.twinskin.sdk.ui.view_capture.ViewCaptureScreen]):
 * use [TransfersScreenHost] to wire it to the live stream, or call this
 * directly in tests / previews.
 *
 * @param uploads      Current queue snapshot.
 * @param onRetry      Re-enqueue a failed upload.
 * @param onViewResult Open the 3D result for a finished capture.
 * @param onClose      Dismiss the transfers surface.
 */
@TwinSkinInternalApi
@Composable
@Suppress("LongParameterList")
public fun TransfersScreen(
    uploads: List<PendingUpload>,
    onRetry: (PendingUpload) -> Unit = {},
    onViewResult: (PendingUpload) -> Unit = {},
    onClose: () -> Unit = {},
) {
    TwinSkinTheme {
        Box(
            Modifier
                .fillMaxSize()
                .background(TransfersBackground),
        ) {
            // Background fills edge-to-edge; content insets below the status /
            // navigation bars so it starts under the clock/battery strip.
            Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                TransfersTopBar(onClose = onClose)
                if (uploads.isEmpty()) {
                    EmptyState(modifier = Modifier.fillMaxSize())
                } else {
                    TransfersList(uploads, onRetry, onViewResult)
                }
            }
        }
    }
}

@Composable
private fun TransfersList(
    uploads: List<PendingUpload>,
    onRetry: (PendingUpload) -> Unit,
    onViewResult: (PendingUpload) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 24.dp, end = 24.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp),
    ) {
        item { Header(uploads) }
        items(items = uploads, key = { it.captureId }) { upload ->
            TransferCard(
                upload = upload,
                onRetry = { onRetry(upload) },
                onViewResult = { onViewResult(upload) },
            )
        }
        item {
            Spacer(Modifier.height(5.dp))
            ResilienceLine()
        }
    }
}

/**
 * Eyebrow + H1 header summarising the queue. Reads green ("Upload complete" /
 * "Sent to TwinSkin.") once every in-flight upload has resolved, matching the
 * prototype's `done`-driven copy.
 */
@Composable
private fun Header(uploads: List<PendingUpload>) {
    val allDone = uploads.none { it.state is CaptureState.Uploading }
    val eyebrowColor = if (allDone) TwinSkinColors.Success else MaterialTheme.colorScheme.onSurfaceVariant
    Column(Modifier.padding(top = 6.dp, bottom = 6.dp)) {
        Text(
            text = (if (allDone) "Upload complete" else "Uploading").uppercase(),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = eyebrowColor,
        )
        Spacer(Modifier.height(9.dp))
        Text(
            text = if (allDone) "Sent to TwinSkin." else "Sending to TwinSkin…",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = "Transfers run in the background and survive app restarts — you can keep working.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** 34px circular outlined close button + centered "Transfers" title (prototype TopBar). */
@Composable
private fun TransfersTopBar(onClose: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 8.dp)
            .height(46.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .size(34.dp)
                .clip(CircleShape)
                .border(1.5.dp, MaterialTheme.colorScheme.outline, CircleShape)
                .clickable(onClick = onClose),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Close",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp),
            )
        }
        Text(
            text = "Transfers",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun EmptyState(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
    ) {
        IconChip(icon = Icons.Filled.CloudUpload, contentDescription = null)
        Text(
            "No transfers in flight.",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
        )
        Text(
            "Start a capture to see the upload queue here.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

/** Info-glyph resilience reassurance from the prototype's footer note. */
@Composable
private fun ResilienceLine() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Outlined.Info,
            contentDescription = null,
            tint = TwinSkinColors.Hint,
            modifier = Modifier.size(17.dp),
        )
        Spacer(Modifier.width(9.dp))
        Text(
            text = "If the app closes, the SDK resumes the transfer on next launch.",
            style = MaterialTheme.typography.bodySmall,
            color = TwinSkinColors.Hint,
        )
    }
}
