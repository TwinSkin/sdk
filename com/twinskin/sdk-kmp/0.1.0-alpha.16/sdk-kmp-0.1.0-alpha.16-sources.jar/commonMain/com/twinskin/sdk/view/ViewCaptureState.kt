package com.twinskin.sdk.view

import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.capture.SdkMeasurement

/** Top-level UI state. Pure data; produced by [ViewCaptureSession]. */
@TwinSkinInternalApi
public sealed class ViewCaptureState {
    public data class Loading(val progress: LoadProgress) : ViewCaptureState()
    public data class Error(val error: ViewCaptureError) : ViewCaptureState()

    /**
     * At least one of [asset] (3D mesh) or [image2D] (2D reference frame)
     * is required. The viewer renders tabs only when both are present —
     * otherwise it shows whichever pane has data.
     */
    public data class Ready(
        val asset: Asset3D? = null,
        val image2D: Image2DAsset? = null,
        val annotation: SdkAnnotation? = null,
        /** Latest physical measurement; null when no measurement yet. */
        val measurement: SdkMeasurement? = null,
        val metadata: Map<String, String> = emptyMap(),
        /** True while a reactive resolver (e.g. PowerSync) is still emitting updates. */
        val isStreaming: Boolean = false,
        /** True iff a measure step for a newer revision is queued or in flight. */
        val isMeasurementCalculating: Boolean = false,
    ) : ViewCaptureState() {
        init {
            require(asset != null || image2D != null) {
                "ViewCaptureState.Ready requires asset and/or image2D — both null is not Ready."
            }
        }
    }
}

@TwinSkinInternalApi
public sealed class LoadProgress {
    public object Indeterminate : LoadProgress()

    /**
     * Emitted while a `CaptureSource.GlbUrl` `headersProvider` is
     * running (e.g. minting a session token). Short-lived — flips to
     * [Downloading] as soon as the fetch starts.
     */
    public object ResolvingCredentials : LoadProgress()
    public data class Downloading(val bytesRead: Long, val total: Long?) : LoadProgress()
    public object ResolvingMetadata : LoadProgress()
}

@TwinSkinInternalApi
public sealed class ViewCaptureError {
    public object Network : ViewCaptureError()
    public object NotFound : ViewCaptureError()

    /**
     * The integrator's `headersProvider` threw — usually a token-mint
     * failure or auth refresh failure. Retry re-invokes the provider.
     */
    public data class Credentials(val cause: Throwable) : ViewCaptureError()
    public data class InvalidAsset(val reason: String) : ViewCaptureError()
    public data class Unknown(val cause: Throwable) : ViewCaptureError()
}
