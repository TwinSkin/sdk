package com.twinskin.sdk.ui.annotation_editor.delineation.system

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect

@Composable
internal actual fun DeferSystemGesturesDuringSession() {
    DisposableEffect(Unit) {
        SystemGesturesLockCounter.enter()
        onDispose { SystemGesturesLockCounter.exit() }
    }
}
