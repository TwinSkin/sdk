@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk

import com.twinskin.sdk.ui.annotation_editor.delineation.orientation.OrientationLockCounter
import kotlinx.cinterop.ExperimentalForeignApi
import platform.UIKit.UIApplication
import platform.UIKit.UIInterfaceOrientationLandscapeLeft
import platform.UIKit.UIInterfaceOrientationLandscapeRight
import platform.UIKit.UIInterfaceOrientationMask
import platform.UIKit.UIInterfaceOrientationMaskAll
import platform.UIKit.UIInterfaceOrientationMaskLandscapeLeft
import platform.UIKit.UIInterfaceOrientationMaskLandscapeRight
import platform.UIKit.UIInterfaceOrientationMaskPortrait
import platform.UIKit.UIInterfaceOrientationMaskPortraitUpsideDown
import platform.UIKit.UIInterfaceOrientationPortrait
import platform.UIKit.UIInterfaceOrientationPortraitUpsideDown
import platform.UIKit.UIWindowScene

/**
 * iOS-only integrator hooks for UIKit-side concerns the SDK can't
 * resolve on its own (orientation lock during the annotation
 * editor session, future UIKit lifecycle hooks).
 *
 * **Orientation lock — required `AppDelegate` wire-up.**
 *
 * The SDK declares an orientation preference via
 * [preferredOrientationMask] while a session is active. UIKit
 * consults the host app's `supportedInterfaceOrientationsFor` on
 * every orientation event; forward the property from there:
 *
 * ```swift
 * func application(
 *     _ app: UIApplication,
 *     supportedInterfaceOrientationsFor window: UIWindow?
 * ) -> UIInterfaceOrientationMask {
 *     return TwinSkin.uiKit.preferredOrientationMask
 * }
 * ```
 *
 * One-time wire-up at app init. No callback registration; the
 * property is read on demand. When no editor session is active the
 * mask returns `UIInterfaceOrientationMaskAll` so the host app's
 * normal orientation rules are preserved.
 *
 * **Declare-intent-only.** This is the SDK's preference, not a force.
 * UIKit consults [preferredOrientationMask] on the next orientation
 * event — typically on the next layout pass (within a frame of the
 * editor opening). If your host needs immediate rotation, call
 * `setNeedsUpdateOfSupportedInterfaceOrientations()` (iOS 16+) in
 * the same flow that opens the editor; pre-iOS-16 hosts rely on the
 * defer-to-next-layout behaviour, which matches the editor's typical
 * UX (the canvas is laid out within a frame or two of opening
 * anyway).
 */
public object TwinSkinUiKit {

    /**
     * The orientation mask captured at the moment the first
     * annotation-editor session entered. Mutated only from the
     * main thread via [captureEntryOrientation] before the
     * counter increments (same call site, same thread).
     */
    private var entryMask: UIInterfaceOrientationMask = UIInterfaceOrientationMaskAll

    /**
     * The orientation mask the integrator should return from
     * `supportedInterfaceOrientationsFor`. Defaults to
     * `UIInterfaceOrientationMaskAll` when no annotation-editor
     * session is active (the host app's normal orientation rules
     * apply); switches to the **entry-time orientation** of the
     * outermost active session for as long as that session lives
     * (spec §13.5 — the canvas geometry must not change
     * mid-session, regardless of which physical orientation the
     * clinician was holding the device in when they opened the
     * editor).
     *
     * "Active session" is tracked via [OrientationLockCounter] —
     * a re-entrant depth counter the annotation editor's
     * `LockOrientationDuringSession()` composable increments on
     * enter and decrements on dispose.
     */
    public val preferredOrientationMask: UIInterfaceOrientationMask
        get() = if (OrientationLockCounter.depth > 0) entryMask else UIInterfaceOrientationMaskAll

    /**
     * Called by `Orientation.ios.kt::LockOrientationDuringSession`
     * before [OrientationLockCounter.enter]. On the **outermost**
     * enter (depth 0 → 1) we snapshot the current interface
     * orientation; nested enters preserve that snapshot so the
     * lock semantics are "freeze the outermost session's entry
     * orientation", not "follow rotation across nested sessions".
     */
    internal fun captureEntryOrientation() {
        if (OrientationLockCounter.depth == 0) {
            entryMask = currentInterfaceOrientationMask()
        }
    }
}

/**
 * Reads the current interface orientation from the active
 * [UIWindowScene] and maps it to the matching single-orientation
 * mask. If no scene is reachable at this instant (early launch,
 * scene-detach race), the lock degrades to a no-op
 * (`UIInterfaceOrientationMaskAll`) rather than guessing portrait —
 * a wrong guess would force-rotate a landscape host out of its
 * orientation, which is the opposite of "lock the entry orientation".
 */
private fun currentInterfaceOrientationMask(): UIInterfaceOrientationMask {
    val scenes = UIApplication.sharedApplication.connectedScenes
    val windowScene = scenes
        .filterIsInstance<UIWindowScene>()
        .firstOrNull()
        ?: return UIInterfaceOrientationMaskAll
    return when (windowScene.interfaceOrientation) {
        UIInterfaceOrientationLandscapeLeft -> UIInterfaceOrientationMaskLandscapeLeft
        UIInterfaceOrientationLandscapeRight -> UIInterfaceOrientationMaskLandscapeRight
        UIInterfaceOrientationPortraitUpsideDown -> UIInterfaceOrientationMaskPortraitUpsideDown
        UIInterfaceOrientationPortrait -> UIInterfaceOrientationMaskPortrait
        else -> UIInterfaceOrientationMaskAll
    }
}

/**
 * Extension property mirroring [TwinSkinSdk.iosBackground]'s shape.
 * iOS integrators access the UIKit hooks via
 * `TwinSkin.uiKit.preferredOrientationMask` from their `AppDelegate`.
 */
public val TwinSkinSdk.uiKit: TwinSkinUiKit get() = TwinSkinUiKit
