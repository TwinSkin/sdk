@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.view.resolvers

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.CaptureEntry
import com.twinskin.sdk.capture.CaptureObserver
import com.twinskin.sdk.capture.CaptureState
import com.twinskin.sdk.capture.GenericMeasurement
import com.twinskin.sdk.capture.RegionMeasurement
import com.twinskin.sdk.capture.SdkMeasurement
import com.twinskin.sdk.capture.WoundMeasurement
import com.twinskin.sdk.capture.WoundRegionMeasurement
import com.twinskin.sdk.capture.epochMillisToIso8601
import com.twinskin.sdk.view.Asset3D
import com.twinskin.sdk.view.Asset3DFormat
import com.twinskin.sdk.view.CaptureNotFoundException
import com.twinskin.sdk.view.CaptureResolver
import com.twinskin.sdk.view.Image2DAsset
import com.twinskin.sdk.view.LoadProgress
import com.twinskin.sdk.view.ResolvedCapture
import com.twinskin.sdk.view.ResolverEvent
import com.twinskin.sdk.view.cachedFileExists
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.roundToInt
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow

/**
 * Reactive resolver: subscribes to the capture's PowerSync row and
 * emits a fresh [ResolverEvent.Resolved] whenever the joined row
 * changes (status, asset key, latest annotation). Asset downloads are
 * gated on key changes — annotation edits don't trigger redownloads.
 *
 * Cache layout: `<cacheDir>/<captureId>-<sha256(s3Key) hex16>.<ext>`.
 * Stable per S3 key, so a re-opened capture is offline-friendly. Flat
 * (no per-capture subdir) so [SdkStorage.sweep] can age out unused
 * entries by their own file mtime — a subdir's mtime doesn't track
 * the freshness of files inside it.
 *
 * Asset URL minting and download are injected so tests can drive the
 * resolver without an HTTP server. Production wires
 * `assetUrlBuilder` to mint the session-token Authorization header
 * pair, and `downloadAsset` to call `downloadToPath`.
 */
internal class CaptureIdResolver(
    private val captureId: String,
    private val subjectRef: String,
    private val captureObserver: CaptureObserver,
    private val assetUrlBuilder: suspend (s3Key: String) -> Pair<String, Map<String, String>>,
    private val cacheDir: String,
    private val downloadAsset: suspend (url: String, destPath: String, headers: Map<String, String>) -> Unit,
    private val logger: SdkLogger? = null,
) : CaptureResolver {

    /** Convenience constructor used in tests where headers are uninteresting. */
    constructor(
        captureId: String,
        subjectRef: String,
        captureObserver: CaptureObserver,
        assetUrlBuilder: suspend (s3Key: String) -> Pair<String, Map<String, String>>,
        cacheDir: String,
        downloadAsset: suspend (url: String, destPath: String) -> Unit,
    ) : this(
        captureId = captureId,
        subjectRef = subjectRef,
        captureObserver = captureObserver,
        assetUrlBuilder = assetUrlBuilder,
        cacheDir = cacheDir,
        downloadAsset = { url, dest, _ -> downloadAsset(url, dest) },
        logger = null,
    )

    override fun resolve(): Flow<ResolverEvent> = channelFlow {
        var lastImageKey: String? = null
        var image2DPath: String? = null
        var lastGlbKey: String? = null
        var glbPath: String? = null

        captureObserver.observeCapture(captureId, subjectRef).collect { row ->
            if (row == null) {
                throw CaptureNotFoundException(
                    "Capture $captureId not found for subject $subjectRef",
                )
            }
            // 2D first — usually lands first in the pipeline.
            val imageKey = row.referenceImageKey
            if (imageKey != null && imageKey != lastImageKey) {
                send(ResolverEvent.Progress(LoadProgress.Downloading(0L, null)))
                image2DPath = downloadIfMissing(imageKey, "jpg")
                lastImageKey = imageKey
            }
            val glbKey = row.resultPreview3dGlbKey
            if (glbKey != null && glbKey != lastGlbKey) {
                send(ResolverEvent.Progress(LoadProgress.Downloading(0L, null)))
                glbPath = downloadIfMissing(glbKey, "glb")
                lastGlbKey = glbKey
            }
            val resolved = ResolvedCapture(
                model = glbPath?.let { Asset3D(it, Asset3DFormat.GLB) },
                image2D = image2DPath?.let { Image2DAsset(it) },
                annotation = row.latestAnnotation,
                measurement = row.latestMeasurement,
                metadata = buildMetadata(row),
                isMeasurementCalculating = row.isMeasurementCalculating,
            )
            send(ResolverEvent.Resolved(resolved))
        }
    }

    private suspend fun downloadIfMissing(s3Key: String, ext: String): String {
        val destPath = "$cacheDir/$captureId-${stableUrlHash(s3Key)}.$ext"
        if (cachedFileExists(destPath)) {
            logger?.log("[viewCapture cap-id $captureId] cache HIT $s3Key → $destPath")
            return destPath
        }
        val (url, headers) = try {
            assetUrlBuilder(s3Key)
        } catch (e: CancellationException) { throw e }
        catch (t: Throwable) {
            logger?.log("[viewCapture cap-id $captureId] credentials FAILED for $s3Key", t)
            throw t
        }
        try {
            downloadAsset(url, destPath, headers)
        } catch (e: CancellationException) { throw e }
        catch (t: Throwable) {
            logger?.log(
                "[viewCapture cap-id $captureId] download FAILED for $s3Key: " +
                    "${t::class.simpleName}: ${t.message}",
                t,
            )
            throw t
        }
        logger?.log("[viewCapture cap-id $captureId] downloaded $s3Key → $destPath")
        return destPath
    }

    /**
     * Clinician-facing summary. Skips internal fields (capture id, subject
     * ref, raw status) — those help SDK debugging but aren't useful at the
     * bedside. Order is intentional: when first, then how big, then how
     * deep.
     */
    private fun buildMetadata(row: CaptureEntry): Map<String, String> = buildMap {
        put("Captured", formatCaptureTimestamp(row.updatedAtEpochMs))
        if (row.state != CaptureState.Succeeded) {
            put("Analysis", humanStatus(row.state))
        }
        row.latestMeasurement?.let { addMeasurementRows(it) }
    }
}

private fun MutableMap<String, String>.addMeasurementRows(m: SdkMeasurement) {
    when (m) {
        is GenericMeasurement -> m.regions.firstOrNull()?.let { addGenericRegion(it) }
        is WoundMeasurement -> m.regions.firstOrNull()?.let { addWoundRegion(it) }
    }
}

private fun MutableMap<String, String>.addGenericRegion(r: RegionMeasurement) {
    put("Surface area", formatSurface(r.surfaceMm2))
    r.perimeterMm?.let { put("Perimeter", formatLength(it)) }
    r.maxDepthMm?.let { put("Max depth", formatLength(it)) }
    r.volumeMm3?.let { put("Volume", formatVolume(it)) }
}

private fun MutableMap<String, String>.addWoundRegion(r: WoundRegionMeasurement) {
    put("Surface area", formatSurface(r.surfaceMm2))
    r.perimeterMm?.let { put("Perimeter", formatLength(it)) }
    r.maxDepthMm?.let { put("Max depth", formatLength(it)) }
    r.volumeMm3?.let { put("Volume", formatVolume(it)) }
    r.length?.physicalLength?.let { put("Length", formatLength(it)) }
    r.width?.physicalLength?.let { put("Width", formatLength(it)) }
}

private fun formatSurface(mm2: Double): String {
    val cm2 = mm2 / 100.0
    return "${formatOneDecimal(cm2)} cm²"
}

private fun formatLength(mm: Double): String {
    if (mm >= 10.0) return "${formatOneDecimal(mm / 10.0)} cm"
    return "${formatOneDecimal(mm)} mm"
}

private fun formatVolume(mm3: Double): String {
    val cm3 = mm3 / 1000.0
    return "${formatOneDecimal(cm3)} cm³"
}

private fun formatOneDecimal(value: Double): String {
    val rounded = (value * 10.0).roundToInt() / 10.0
    val whole = rounded.toLong()
    val tenths = ((rounded - whole) * 10.0).roundToInt().let { if (it < 0) -it else it }
    return "$whole.$tenths"
}

/**
 * `epochMillisToIso8601` returns `YYYY-MM-DDTHH:MM:SSZ`. Trim seconds for
 * a calmer clinician-facing timestamp; keep `UTC` so callers reading
 * across time zones aren't misled.
 */
private fun formatCaptureTimestamp(epochMs: Long): String {
    if (epochMs <= 0L) return "—"
    val iso = epochMillisToIso8601(epochMs)
    val tIdx = iso.indexOf('T')
    if (tIdx < 0 || iso.length < tIdx + 6) return iso
    val date = iso.substring(0, tIdx)
    val hourMinute = iso.substring(tIdx + 1, tIdx + 6)
    return "$date $hourMinute UTC"
}

private fun humanStatus(state: CaptureState): String = when (state) {
    CaptureState.Analyzing -> "in progress"
    CaptureState.Succeeded -> "completed"
    is CaptureState.Failed -> "failed"
    is CaptureState.Uploading -> "uploading"
    CaptureState.Uploaded -> "uploaded"
    CaptureState.Cancelled -> "cancelled"
    CaptureState.Idle -> "pending"
    is CaptureState.AwaitingAnnotation -> "awaiting annotation"
    CaptureState.AnnotationSubmitted -> "in progress"
    is CaptureState.AnnotationSubmitFailed -> "annotation failed"
}
