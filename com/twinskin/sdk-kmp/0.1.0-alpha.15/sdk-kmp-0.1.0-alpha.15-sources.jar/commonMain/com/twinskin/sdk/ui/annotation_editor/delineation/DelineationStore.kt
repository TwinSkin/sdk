package com.twinskin.sdk.ui.annotation_editor.delineation

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import com.twinskin.sdk.capture.WoundAnnotation
import com.twinskin.sdk.geometry.denormalise
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.reDensify
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Tissue
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound

/**
 * Single source of truth for the delineation feature — the list of
 * drawn wounds (with their nested tissues), the per-type card states
 * on the dashboard (screen 3), and the source image's pixel size.
 *
 * Compose observation is split across two channels:
 *   - The underlying [SnapshotStateList] / [SnapshotStateMap] let
 *     widgets read individual elements (toolbar buttons, dashboard
 *     cards) and recompose on per-cell changes.
 *   - The lightweight [revision] counter is the wake-up the drawing
 *     canvas reads — one `State<Int>` change per mutation rather than
 *     iterating every wound's polygon list during recomposition
 *     scoping.
 *
 * Construction goes through [fromInitial] (re-edit from a wire
 * seed). To resume from a disk-backed draft, hydrate an empty store
 * and call [restore] — that path runs the densify pass the reshape
 * engine relies on. Wire emission is M9's job (`ToWoundAnnotation`).
 *
 * **Thread-safety.** All mutating methods must be called from a
 * Compose-aware context (typically the main thread). The underlying
 * `SnapshotStateList` / `SnapshotStateMap` honour Compose's snapshot
 * isolation only when accessed from the same snapshot scope. Reads
 * from arbitrary threads are snapshot-safe but may return stale
 * values relative to in-flight mutations.
 *
 * Returned collection views ([wounds], [cardStates]) are typed as
 * `List` / `Map`. Callers must NOT cast them to mutable collections —
 * doing so bypasses [revision] and silently breaks recomposition.
 */
@Stable
internal class DelineationStore private constructor(
    initialWounds: List<Wound>,
    initialCardStates: Map<TissueType, TissueCardState>,
    val imageSize: Size,
) {
    private val _wounds: SnapshotStateList<Wound> =
        mutableStateListOf<Wound>().also { it.addAll(initialWounds) }
    private val _cardStates: SnapshotStateMap<TissueType, TissueCardState> =
        mutableStateMapOf<TissueType, TissueCardState>().also { it.putAll(initialCardStates) }
    private val _revision = mutableStateOf(0)

    val wounds: List<Wound> get() = _wounds
    val cardStates: Map<TissueType, TissueCardState> get() = _cardStates

    /** Bumps on every mutation. Canvas readers observe this instead of the lists. */
    val revision: State<Int> get() = _revision

    fun addWound(w: Wound) {
        _wounds.add(w)
        bump()
    }

    fun replaceWound(idx: Int, w: Wound) {
        require(idx in _wounds.indices) {
            "wound index $idx out of bounds (size=${_wounds.size})"
        }
        _wounds[idx] = w
        bump()
    }

    fun removeWound(idx: Int) {
        require(idx in _wounds.indices) {
            "wound index $idx out of bounds (size=${_wounds.size})"
        }
        _wounds.removeAt(idx)
        bump()
    }

    fun setCardState(t: TissueType, s: TissueCardState) {
        require(t !is TissueType.Other) {
            "card states are only defined for the three known tissue types " +
                "(necrosis / slough / granulation); got Other(\"${t.wire}\")"
        }
        _cardStates[t] = s
        bump()
    }

    /** Tissues across every wound, filtered by [t]. */
    fun tissuesOfType(t: TissueType): List<Tissue> =
        _wounds.flatMap { it.tissues }.filter { it.type == t }

    /**
     * Empties the store — drops every wound and resets every known
     * tissue card to [TissueCardState.Open]. Used by the Intro screen's
     * "Start fresh" path (M15.7) so that discarding a draft on an
     * edit-existing entry also discards the imported regions; the
     * user lands on a genuinely empty canvas, matching their mental
     * model of "start fresh = blank slate."
     */
    fun clear() {
        _wounds.clear()
        _cardStates.clear()
        for (type in TissueType.knownValues) {
            _cardStates[type] = TissueCardState.Open
        }
        bump()
    }

    /** Captures the mutable state. Used for undo (M4) and the disk-backed draft (M2b). */
    fun snapshot(): StoreSnapshot = StoreSnapshot(
        wounds = _wounds.toList(),
        cardStates = _cardStates.toMap(),
    )

    /**
     * Restores [s] into this store, bumping [revision] once. Every
     * restored outline is run through [reDensify] so the reshape
     * engine's `[2, 10]` image-px vertex spacing invariant always
     * holds even if the snapshot carried sparser data. The pass is
     * idempotent on already-dense outlines.
     */
    fun restore(s: StoreSnapshot) {
        _wounds.clear()
        _wounds.addAll(s.wounds.map { it.densified() })
        _cardStates.clear()
        _cardStates.putAll(s.cardStates)
        bump()
    }

    private fun Wound.densified(): Wound = Wound(
        outline = reDensify(outline),
        tissues = tissues.map { Tissue(type = it.type, outline = reDensify(it.outline)) },
    )

    private fun bump() {
        _revision.value = _revision.value + 1
    }

    companion object {
        /**
         * Hydrates from a [WoundAnnotation] seed:
         *   - denormalises every `Point2D` from `[0..1]` to image-pixel `Offset`
         *   - parses each tissue type via [TissueType.fromWire] (unknowns
         *     survive as [TissueType.Other] and round-trip in M9)
         *   - seeds [cardStates] to [TissueCardState.Drawn] for the known
         *     types present in the seed; [TissueCardState.Open] for the
         *     other knowns. [TissueType.Other] never appears in the
         *     card-state map.
         */
        fun fromInitial(annotation: WoundAnnotation, imageSize: Size): DelineationStore {
            // Re-densify every imported outline to the canonical
            // `[2, 10]` image-px vertex spacing the reshape engine
            // assumes. External `WoundAnnotation`s can carry sparse
            // outlines (~6–8 vertices for a hexagon) on which the
            // raised-cosine falloff has nothing to grip. Idempotent
            // on already-dense outlines.
            val wounds = annotation.regions.map { region ->
                Wound(
                    outline = reDensify(
                        region.contour.map { p ->
                            denormalise(Offset(p.x.toFloat(), p.y.toFloat()), imageSize)
                        },
                    ),
                    tissues = region.tissues.map { t ->
                        Tissue(
                            type = TissueType.fromWire(t.tissueType),
                            outline = reDensify(
                                t.contour.map { p ->
                                    denormalise(Offset(p.x.toFloat(), p.y.toFloat()), imageSize)
                                },
                            ),
                        )
                    },
                )
            }
            val seenKnown: Set<TissueType> = wounds.asSequence()
                .flatMap { it.tissues.asSequence() }
                .map { it.type }
                .filter { it in TissueType.knownValues }
                .toSet()
            val cardStates: Map<TissueType, TissueCardState> = TissueType.knownValues
                .associateWith { if (it in seenKnown) TissueCardState.Drawn else TissueCardState.Open }
            return DelineationStore(
                initialWounds = wounds,
                initialCardStates = cardStates,
                imageSize = imageSize,
            )
        }
    }
}

/** Value snapshot of the store — used by undo (M4) and the draft codec (M2b). */
@Immutable
internal data class StoreSnapshot(
    val wounds: List<Wound>,
    val cardStates: Map<TissueType, TissueCardState>,
)
