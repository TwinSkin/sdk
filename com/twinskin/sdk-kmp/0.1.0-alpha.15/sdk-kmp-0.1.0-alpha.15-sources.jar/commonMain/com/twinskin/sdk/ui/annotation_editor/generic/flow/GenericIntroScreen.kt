package com.twinskin.sdk.ui.annotation_editor.generic.flow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.annotation_editor.generic.i18n.GenericStrings

/**
 * Generic editor entry screen. Derivative of the wound editor's
 * `IntroScreen` with the wound-specific framing stripped:
 *
 *  - No "Step 1 of 2" — the generic editor is a single drawing step.
 *  - No help icon — no help slides for v1.
 *  - Body is one instructional paragraph, not two.
 *
 * The Resume banner appears above the body when [hasExistingState]
 * is true (the caller passed a non-empty `initial`). Cancel stays
 * in the footer either way; the single primary CTA is hidden when
 * the Resume banner takes over.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun GenericIntroScreen(
    hasExistingState: Boolean,
    strings: GenericStrings,
    onResume: () -> Unit,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(strings.introTitle) },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.backContentDescription,
                        )
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 24.dp),
            ) {
                if (hasExistingState) {
                    ResumeBanner(strings, onResume, onStart)
                    Spacer(Modifier.height(24.dp))
                }
                Spacer(Modifier.height(40.dp))
                Text(
                    text = strings.introTitle,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Medium,
                )
                Spacer(Modifier.height(28.dp))
                Text(
                    text = strings.introDescription,
                    fontSize = 16.sp,
                    lineHeight = 24.sp,
                )
            }
            WarningBanner(strings, modifier = Modifier.padding(horizontal = 24.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 24.dp, top = 8.dp, end = 24.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = onCancel) { Text(strings.cancelButton) }
                if (!hasExistingState) {
                    Spacer(Modifier.width(12.dp))
                    Button(
                        onClick = onStart,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                    ) { Text(strings.continueButton) }
                }
            }
        }
    }
}

@Composable
private fun WarningBanner(strings: GenericStrings, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = strings.warningBanner,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

@Composable
private fun ResumeBanner(
    strings: GenericStrings,
    onResume: () -> Unit,
    onStartFresh: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.elevatedCardElevation(),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                strings.resumeBanner,
                style = MaterialTheme.typography.bodyLarge,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Button(
                    onClick = onResume,
                    modifier = Modifier.weight(1f),
                ) { Text(strings.resumeButton) }
                TextButton(
                    onClick = onStartFresh,
                    modifier = Modifier.weight(1f),
                ) { Text(strings.startFreshButton) }
            }
        }
    }
}
