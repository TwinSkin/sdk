package com.twinskin.sdk.ui.annotation_editor.delineation.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.Strings
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState

/**
 * Dashboard card for one of the three known tissue types
 * (spec §7.1). Layout matches the Flutter
 * `manual_contour_tissue_intro.dart` reference: three distinct
 * visual states rather than a row of toggle-able buttons.
 *
 *  - [TissueCardState.Open]   — top row: type name only.
 *                               Below: "Draw area" (primary) +
 *                               "Not present" (surfaceContainerHigh).
 *  - [TissueCardState.Drawn]  — top row: type name + "Edit" button
 *                               (right-aligned).
 *                               Below: large percentage (28sp, w700,
 *                               primary color).
 *  - [TissueCardState.Absent] — top row: type name + "Edit" button
 *                               (right-aligned).
 *                               Below: gray "Not present" pill.
 *
 * **Edit-on-Absent semantics.** Tapping Edit on an Absent card
 * un-Absents the type and navigates to the tissue drawing screen,
 * so the Absent-state Edit button calls [onMarkPresent] (the
 * dispatcher transitions to Open and navigates). The Drawn-state
 * Edit button calls [onEdit] (navigate only).
 *
 * Callbacks are flat (Compose convention). The caller wires all
 * four lambdas; the card invokes only the ones relevant to its
 * current state.
 */
@Composable
internal fun TissueCard(
    state: TissueCardState,
    percentage: Int,
    tissueTypeName: String,
    strings: Strings,
    onAdd: () -> Unit,
    onEdit: () -> Unit,
    onMarkAbsent: () -> Unit,
    onMarkPresent: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = RoundedCornerShape(12.dp),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = tissueTypeName,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                when (state) {
                    TissueCardState.Open -> Unit
                    TissueCardState.Drawn, TissueCardState.Absent -> {
                        Spacer(Modifier.weight(1f))
                        val editCallback =
                            if (state == TissueCardState.Drawn) onEdit else onMarkPresent
                        Button(
                            onClick = editCallback,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                contentColor = MaterialTheme.colorScheme.onSurface,
                            ),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        ) {
                            Text(strings.tissueCardEdit, fontSize = 14.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            when (state) {
                TissueCardState.Open -> Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        onClick = onAdd,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                    ) {
                        Text(
                            text = strings.tissueCardAddTissue,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                    Button(
                        onClick = onMarkAbsent,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            contentColor = MaterialTheme.colorScheme.onSurface,
                        ),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp),
                    ) {
                        Text(strings.tissueCardMarkAbsent, fontSize = 14.sp)
                    }
                }
                TissueCardState.Drawn -> Text(
                    text = "$percentage%",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                )
                TissueCardState.Absent -> Surface(
                    shape = RoundedCornerShape(30.dp),
                    color = Color(0xFFEEEEEE),
                ) {
                    Text(
                        text = strings.tissueCardMarkAbsent,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        fontSize = 14.sp,
                        color = Color.Black,
                    )
                }
            }
        }
    }
}
