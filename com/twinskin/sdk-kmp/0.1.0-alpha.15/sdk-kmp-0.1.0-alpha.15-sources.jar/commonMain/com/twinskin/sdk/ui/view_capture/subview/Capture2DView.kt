@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.capture.GenericAnnotation
import com.twinskin.sdk.capture.GenericMeasurement
import com.twinskin.sdk.capture.Point2D
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.capture.SdkMeasurement
import com.twinskin.sdk.capture.WoundAnnotation
import com.twinskin.sdk.capture.WoundMeasurement
import com.twinskin.sdk.ui.layout.imageRectInBox
import kotlin.math.abs
import kotlin.math.roundToLong

/**
 * Stateless 2D pane: shows the reference image with the annotation polygon
 * overlaid on top, and a measurement readout below.
 *
 * Annotation coordinates are normalized 0..1 in the reference image's
 * frame (the same convention the [com.twinskin.sdk.ui.annotation_editor.GenericAnnotationEditor]
 * produces when the user traces a polygon), so the overlay tracks the
 * displayed image regardless of layout size.
 *
 * Pass [image] = null to render a loading state — useful while the
 * host is decoding bytes off disk.
 */
@TwinSkinInternalApi
@Composable
public fun Capture2DView(
    image: ImageBitmap?,
    annotation: SdkAnnotation?,
    measurement: SdkMeasurement?,
    modifier: Modifier = Modifier,
    isSubmitting: Boolean = false,
) {
    val polygons = annotation?.toRenderablePolygons().orEmpty()
    val readouts = measurement?.toMeasurementReadouts().orEmpty()
    Column(modifier = modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            if (image == null) {
                CircularProgressIndicator()
            } else {
                Image(
                    bitmap = image,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit,
                )
                // M15.14 — hide the annotation overlay while a submit
                // is in flight: the value currently in `annotation` is
                // the pre-edit one (the local cache hasn't refreshed
                // yet), so showing it under the spinner would surface
                // stale data the user just changed. The optimistic
                // update from M15.11 replaces this with the new value
                // the instant `submitAnnotation` succeeds.
                if (polygons.isNotEmpty() && !isSubmitting) {
                    AnnotationOverlay(
                        polygons = polygons,
                        imageWidth = image.width,
                        imageHeight = image.height,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                if (isSubmitting) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.35f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }
        }
        if (readouts.isNotEmpty()) {
            HorizontalDivider()
            MeasurementsPanel(
                readouts = readouts,
                isSubmitting = isSubmitting,
                modifier = Modifier.heightIn(max = 280.dp),
            )
        }
    }
}

/** View-model for one polygon to render on the 2D pane: a sequence of normalized-coordinate vertices. */
private data class RenderablePolygon(
    val points: List<Point2D>,
)

/** Per-region measurement readout in display order. */
private data class MeasurementReadout(
    val surfaceMm2: Double,
    val perimeterMm: Double?,
    val maxDepthMm: Double?,
    val volumeMm3: Double?,
)

private fun SdkAnnotation.toRenderablePolygons(): List<RenderablePolygon> = when (this) {
    is GenericAnnotation -> regions.map { RenderablePolygon(points = it.points) }
    is WoundAnnotation -> regions.map { RenderablePolygon(points = it.contour) }
}

private fun SdkMeasurement.toMeasurementReadouts(): List<MeasurementReadout> = when (this) {
    is GenericMeasurement -> regions.map {
        MeasurementReadout(
            surfaceMm2 = it.surfaceMm2,
            perimeterMm = it.perimeterMm,
            maxDepthMm = it.maxDepthMm,
            volumeMm3 = it.volumeMm3,
        )
    }
    is WoundMeasurement -> regions.map {
        MeasurementReadout(
            surfaceMm2 = it.surfaceMm2,
            perimeterMm = it.perimeterMm,
            maxDepthMm = it.maxDepthMm,
            volumeMm3 = it.volumeMm3,
        )
    }
}

@Composable
private fun AnnotationOverlay(
    polygons: List<RenderablePolygon>,
    imageWidth: Int,
    imageHeight: Int,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        val rect = imageRectInBox(
            imageWidth = imageWidth,
            imageHeight = imageHeight,
            boxWidth = size.width,
            boxHeight = size.height,
        )
        if (rect.displayWidth <= 0f || rect.displayHeight <= 0f) return@Canvas
        val strokePx = 2.dp.toPx()
        val color = OverlayPolygonColor
        for (polygon in polygons) {
            if (polygon.points.size < 2) continue
            val path = Path().apply {
                val first = polygon.points.first()
                moveTo(
                    rect.offsetX + first.x.toFloat() * rect.displayWidth,
                    rect.offsetY + first.y.toFloat() * rect.displayHeight,
                )
                for (i in 1 until polygon.points.size) {
                    val p = polygon.points[i]
                    lineTo(
                        rect.offsetX + p.x.toFloat() * rect.displayWidth,
                        rect.offsetY + p.y.toFloat() * rect.displayHeight,
                    )
                }
                close()
            }
            drawPath(path = path, color = color.copy(alpha = 0.25f))
            drawPath(path = path, color = color, style = Stroke(width = strokePx))
        }
    }
}

/** Renders one summary block per region. */
@Composable
private fun MeasurementsPanel(
    readouts: List<MeasurementReadout>,
    isSubmitting: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val showRegionLabels = readouts.size > 1
    Column(
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = if (showRegionLabels) "Measurements" else "Measurement",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold,
        )
        readouts.forEachIndexed { index, readout ->
            MeasurementRows(
                readout = readout,
                regionLabel = if (showRegionLabels) "Region ${index + 1}" else null,
                isSubmitting = isSubmitting,
            )
        }
    }
}

@Composable
private fun MeasurementRows(
    readout: MeasurementReadout,
    regionLabel: String?,
    isSubmitting: Boolean = false,
) {
    // M15.18 — while a submit is in flight the cached measurement is
    // the PRE-Validate value, so rendering it verbatim would lie
    // (e.g. show the old surface area against the user's new contour).
    // Replace each value cell with a "Calculating…" placeholder until
    // the server returns the recomputed measurement. Labels stay so
    // the panel structure is recognizable; all four rows always
    // render during submit even when the prior measurement had null
    // optional fields, since the new measurement may well populate
    // them and the consistent template is less disorienting than
    // rows that appear/disappear when the values arrive.
    //
    // M15.20 — the placeholder animates its trailing dots via
    // [CalculatingText] so the user can see the system is alive
    // while waiting. Falls back to plain formatted numerics once
    // the submit window closes.
    val rows = buildList {
        add("Surface" to (if (isSubmitting) null else formatMm2(readout.surfaceMm2)))
        if (isSubmitting || readout.perimeterMm != null) {
            add("Perimeter" to (if (isSubmitting) null else formatMm(readout.perimeterMm!!)))
        }
        if (isSubmitting || readout.maxDepthMm != null) {
            add("Max depth" to (if (isSubmitting) null else formatMm(readout.maxDepthMm!!)))
        }
        if (isSubmitting || readout.volumeMm3 != null) {
            add("Volume" to (if (isSubmitting) null else formatMm3(readout.volumeMm3!!)))
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (regionLabel != null) {
            Text(
                regionLabel,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Medium,
            )
        }
        for ((label, value) in rows) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(label, style = MaterialTheme.typography.bodyMedium)
                if (value == null) {
                    CalculatingText(
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Normal,
                    )
                } else {
                    Text(
                        value,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
    }
}

// Format helpers — promote to a shared util once another caller appears.

private fun formatMm(valueMm: Double): String =
    if (valueMm >= 10) "${roundTo1(valueMm / 10)} cm" else "${roundTo1(valueMm)} mm"

private fun formatMm2(valueMm2: Double): String {
    val cm2 = valueMm2 / 100.0
    return if (cm2 >= 1) "${roundTo2(cm2)} cm²" else "${roundTo1(valueMm2)} mm²"
}

private val OverlayPolygonColor: Color = Color(0xFFFF6F61)

private fun formatMm3(valueMm3: Double): String {
    val cm3 = valueMm3 / 1000.0
    return if (cm3 >= 1) "${roundTo2(cm3)} cm³" else "${roundTo1(valueMm3)} mm³"
}

private fun roundTo1(v: Double): String = v.formatFixed(decimals = 1)
private fun roundTo2(v: Double): String = v.formatFixed(decimals = 2)

// commonMain has no printf-style float formatter (String.format is JVM-only),
// so we round in integer space to avoid surprises like 1.10000000000001.
private fun Double.formatFixed(decimals: Int): String {
    var factor = 1L
    repeat(decimals) { factor *= 10 }
    val scaled = (this * factor).roundToLong()
    val sign = if (scaled < 0) "-" else ""
    val mag = abs(scaled)
    val frac = (mag % factor).toString().padStart(decimals, '0').trimEnd('0')
    return if (frac.isEmpty()) "$sign${mag / factor}" else "$sign${mag / factor}.$frac"
}
