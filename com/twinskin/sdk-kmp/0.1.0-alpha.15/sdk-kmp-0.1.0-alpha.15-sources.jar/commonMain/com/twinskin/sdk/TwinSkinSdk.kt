@file:OptIn(TwinSkinInternalApi::class)

package com.twinskin.sdk

import com.twinskin.sdk.capture.CaptureObserver
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.view.CaptureSource
import com.twinskin.sdk.view.ViewCaptureSession
import com.twinskin.sdk.view.resolvers.CaptureIdResolver
import com.twinskin.sdk.view.resolvers.HttpGlbResolver
import com.twinskin.sdk.view.resolvers.LocalGlbResolver
import kotlin.concurrent.Volatile

/**
 * Public façade for the TwinSkin SDK. Host apps only touch two entry
 * points:
 *
 * - `initialize(...)` — called once from the application entry point
 *   (Android: `fun TwinSkinSdk.initialize(app, config)` from androidMain;
 *   iOS: `fun TwinSkinSdk.initialize(config)` from iosMain).
 * - [startCapture] — open a fresh capture session; the `CaptureScreen`
 *   composable drives it.
 *
 * Everything inside the SDK is wired via constructor-injected components
 * (see [TwinSkinSdkComponent]). This object is only the final façade so
 * integrators don't have to assemble the graph themselves.
 */
public object TwinSkinSdk {
    @Volatile
    private var component: TwinSkinSdkComponent? = null

    /** Open a new capture session. The server is only contacted when the session is submitted. */
    public fun startCapture(metadata: SdkCaptureMetadata): CaptureSession =
        requireComponent().captureApi.startCapture(metadata)

    /**
     * Observe captures known to this SDK instance. The returned [CaptureObserver]
     * is a read-only view; it never drives capture lifecycle. See
     * [CaptureObserver.observePendingUploads] for the canonical use case
     * (background upload progress UI).
     */
    public val captures: CaptureObserver
        get() = requireComponent().captureObserver

    /**
     * `true` when [TwinSkinConfig.devMode] was set on init. Read by the
     * built-in capture screens to decide whether to surface the
     * "Use demo capture" affordance.
     */
    public val devMode: Boolean
        get() = requireComponent().devMode

    /**
     * `true` when [TwinSkinConfig.verboseFrameLogs] was set on init.
     * Read by the photosphere capture screens to decide whether to
     * write the on-device diagnostic sidecars — see the field on
     * [TwinSkinConfig] for the full list + storage footprint.
     */
    public val verboseFrameLogs: Boolean
        get() = requireComponent().verboseFrameLogs

    public val captureMode: CaptureMode
        get() = requireComponent().captureMode

    /**
     * Diagnostic surface — see [TwinSkinDebug]. Not part of the stable
     * public API; the schema can change in any minor release.
     */
    public val debug: TwinSkinDebug
        get() = TwinSkinDebug(requireComponent())

    /**
     * View a previously-captured 3D model. Returns a [ViewCaptureSession] whose
     * `state` StateFlow the host Compose screen observes. Close the session
     * when the screen is torn down.
     */
    public fun viewCapture(source: CaptureSource): ViewCaptureSession {
        val component = requireComponent()
        val resolver = when (source) {
            is CaptureSource.LocalGlb -> LocalGlbResolver(source.path)
            is CaptureSource.GlbUrl -> HttpGlbResolver(
                url = source.url,
                cacheDir = component.storage.dir(Purpose.ViewCapture),
                headersProvider = source.headersProvider,
                logger = component.logger,
            )
            is CaptureSource.CaptureId -> {
                val serverClient = component.serverClient
                CaptureIdResolver(
                    captureId = source.id,
                    subjectRef = source.subjectRef,
                    captureObserver = component.captureObserver,
                    assetUrlBuilder = { s3Key ->
                        // The /asset redirect endpoint is session-token authenticated.
                        // The 302 target is a presigned S3 URL that expects no auth —
                        // headers are stripped on redirect by `downloadToPath`.
                        val tokens = com.twinskin.sdk.sdk_client.parseSessionTokenPayload(
                            serverClient.auth.fetchSessionToken(source.subjectRef),
                        )
                        val url = "${serverClient.apiBaseUrl}/asset?key=$s3Key"
                        val headers = mapOf(
                            io.ktor.http.HttpHeaders.Authorization to "Bearer ${tokens.token}",
                            "X-Publishable-Key" to serverClient.publishableKey,
                        )
                        url to headers
                    },
                    cacheDir = component.storage.dir(com.twinskin.sdk.storage.Purpose.ViewCapture),
                    downloadAsset = { url, destPath, headers ->
                        com.twinskin.sdk.view.downloadToPath(
                            url = url,
                            destPath = destPath,
                            headers = headers,
                            onProgress = { _, _ -> },
                        )
                    },
                    logger = component.logger,
                )
            }
        }
        return ViewCaptureSession(resolver, logger = component.logger)
    }

    /**
     * Idempotent: a second call is a no-op so hosts that (for example) wire
     * initialization from both an `Application` and a splash screen don't have
     * to guard it themselves. Any [TwinSkinSdkComponent] built for the second
     * call is discarded.
     */
    internal fun install(built: TwinSkinSdkComponent): Boolean {
        if (component != null) return false
        component = built
        return true
    }

    internal val isInitialized: Boolean get() = component != null

    internal fun requireComponent(): TwinSkinSdkComponent =
        component ?: error("TwinSkinSdk.initialize(...) must be called before using the SDK.")

    /** For tests only — clears the installed component so the next `initialize` succeeds. */
    internal fun resetForTests() {
        component = null
    }
}

/**
 * Integrator-supplied configuration. [baseUrl] is the Twinskin API server's
 * scheme+host(+port) root — e.g. `https://prod.dermatoo.com` — and defaults
 * to production; demo / local-dev hosts pass an override. The SDK appends
 * `/api/sdk` for API calls and `/powersync` for the realtime stream itself,
 * so integrators only configure the host once.
 */
public data class TwinSkinConfig(
    val publishableKey: String,
    val authorizationProvider: SdkAuthorizationProvider,
    val baseUrl: String = PROD_BASE_URL,
    val logger: SdkLogger? = null,
    /**
     * When true, the camera screen surfaces a "Use demo capture" button that
     * downloads a server-served capture and submits it through the normal
     * upload pipeline. Intended for QA / demo / integrator-test builds; leave
     * `false` in production.
     */
    val devMode: Boolean = false,
    /**
     * Umbrella opt-in for the SDK's on-device diagnostic sidecars:
     * `frame_log.jsonl`, `pose_log.json`, `reference_keypoints.json`,
     * and the per-Nth analyser-frame grayscale JPEGs under
     * `live_frames/`. None of these ever ride the encrypted upload
     * bundle (the tar packer whitelists `view_NN_rXaY.jpg` only), but
     * when `true` they accumulate ~25–120 MB per capture in the app
     * sandbox. Default `false` so a Release build is silent on disk;
     * integrators flip it on for field-issue triage.
     */
    val verboseFrameLogs: Boolean = false,
    /**
     * Which capture pipeline this SDK instance launches when
     * [TwinSkin.startCapture] is called. Default
     * [CaptureMode.Photosphere] preserves the historical behaviour
     * (every capture today runs the photosphere screen);
     * [CaptureMode.AccelerometerCapture] opts into the accelerometer + video
     * pipeline. The selected mode is stamped on every persisted
     * capture row so the upload pipeline can pick the matching bundle
     * layout long after the originating session has ended.
     */
    val captureMode: CaptureMode = CaptureMode.Photosphere,
) {
    public companion object {
        public const val PROD_BASE_URL: String = "https://prod.dermatoo.com"
    }
}
