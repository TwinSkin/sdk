package com.twinskin.sdk.ui.annotation_editor.delineation.flow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.Strings

/**
 * Last-resort UI shown when the root composable catches an
 * uncaught throwable from a gesture loop, the auto-save flow, or
 * the suspending `onDone` callback (spec C1). The draft has
 * already been flushed by the [kotlinx.coroutines.CoroutineExceptionHandler]
 * before this composes, so the user's work is preserved on disk;
 * the dismiss button just exits the editor (the integrator handles
 * what to do next — typically navigate back to the host app).
 */
@Composable
internal fun ErrorScreen(
    error: Throwable,
    strings: Strings,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.surface,
    ) {
        Box(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(
                    imageVector = Icons.Filled.ErrorOutline,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.height(48.dp),
                )
                Text(
                    text = strings.errorScreenTitle,
                    style = MaterialTheme.typography.headlineSmall,
                )
                Text(
                    text = strings.errorScreenBody,
                    style = MaterialTheme.typography.bodyMedium,
                )
                error.message?.let { msg ->
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = onDismiss) { Text(strings.dismissButton) }
            }
        }
    }
}
