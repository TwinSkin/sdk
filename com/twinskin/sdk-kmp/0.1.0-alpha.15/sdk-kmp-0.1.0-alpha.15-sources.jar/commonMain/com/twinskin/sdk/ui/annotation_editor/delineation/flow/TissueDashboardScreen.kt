package com.twinskin.sdk.ui.annotation_editor.delineation.flow

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Help
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.annotation_editor.delineation.dashboard.TissueCard
import com.twinskin.sdk.ui.annotation_editor.delineation.help.HelpDialog
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.Strings
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.ConfirmDialog
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.HapticEvent
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.emit

/**
 * Actions a [TissueCard] can request, dispatched per [TissueType]
 * to the [TissueDashboardScreen]'s `onCardAction` callback. M13's
 * dispatcher maps each `(type, action)` pair to the appropriate
 * store mutation or navigation jump:
 *
 *  - [Add] / [Edit] → navigate to `Step.TissueDrawing(type)`.
 *  - [MarkAbsent]   → `store.setCardState(type, Absent)`.
 *  - [MarkPresent]  → `store.setCardState(type, Open)` and
 *                     navigate to `Step.TissueDrawing(type)` so
 *                     the user can start drawing the type they
 *                     just un-marked as absent.
 *
 * The Dashboard composable itself is screen-pure — it doesn't know
 * what these actions resolve to, only that they fire when a card
 * button is tapped. This keeps the screen testable in isolation and
 * the dispatch logic centralised in M13.
 */
internal sealed class TissueCardAction {
    data object Add : TissueCardAction()
    data object Edit : TissueCardAction()
    data object MarkAbsent : TissueCardAction()
    data object MarkPresent : TissueCardAction()
}

/**
 * Screen 3 — tissue composition dashboard (spec §7). Body layout:
 * a large Step 2 title, three [TissueCard]s (one per
 * [TissueType.knownValues]) in a scrollable region, an
 * untyped-remainder footer, and an inline Back / Validate row at
 * the bottom. No Scaffold bottomBar — the inline footer carries
 * its own `windowInsetsPadding`.
 *
 * **Untyped remainder** — when the typed percentages sum to less
 * than 100, the footer renders "Untyped: N%" where N is
 * `100 − sum(known)`. Largest-remainder apportionment guarantees
 * the integer sum is ≤ 100, so the remainder is rendered without
 * defensive coercion.
 *
 * **Validate flow** — button click opens a [ConfirmDialog] with
 * the "you can't modify after this" warning; confirmation fires
 * a [HapticEvent.ValidateEmitted] haptic and invokes [onValidate].
 *
 * **Submission overlay** — when [isSubmitting] is true, a
 * full-screen scrim covers the screen with a centred
 * [CircularProgressIndicator] and "Saving…" text. User input is
 * blocked during this state.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun TissueDashboardScreen(
    cardStates: Map<TissueType, TissueCardState>,
    percentages: Map<TissueType, Int>,
    isSubmitting: Boolean,
    snackbarHostState: SnackbarHostState,
    strings: Strings,
    onBack: () -> Unit,
    onValidate: () -> Unit,
    onCardAction: (TissueType, TissueCardAction) -> Unit,
    modifier: Modifier = Modifier,
) {
    val haptic = LocalHapticFeedback.current
    var showValidateConfirm by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(strings.dashboardTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.backContentDescription,
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showHelp = true }) {
                        Icon(Icons.Outlined.Help, contentDescription = strings.helpContentDescription)
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            Column(modifier = Modifier.fillMaxSize()) {
                Text(
                    text = strings.dashboardStep2Title,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(
                        start = 24.dp, top = 24.dp, end = 24.dp, bottom = 12.dp,
                    ),
                )
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(vertical = 8.dp),
                ) {
                    items(items = TissueType.knownValues) { type ->
                        TissueCard(
                            state = cardStates[type] ?: TissueCardState.Open,
                            percentage = percentages[type] ?: 0,
                            tissueTypeName = strings.tissueTypeNames[type] ?: type.wire,
                            strings = strings,
                            onAdd = { onCardAction(type, TissueCardAction.Add) },
                            onEdit = { onCardAction(type, TissueCardAction.Edit) },
                            onMarkAbsent = { onCardAction(type, TissueCardAction.MarkAbsent) },
                            onMarkPresent = { onCardAction(type, TissueCardAction.MarkPresent) },
                        )
                    }
                    item {
                        UntypedRemainderFooter(percentages, strings)
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(start = 24.dp, top = 8.dp, end = 24.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(
                        onClick = onBack,
                        enabled = !isSubmitting,
                    ) { Text(strings.backButton) }
                    Spacer(Modifier.width(12.dp))
                    Button(
                        onClick = { showValidateConfirm = true },
                        enabled = isValidateEnabled(cardStates) && !isSubmitting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                    ) { Text(strings.validateButton) }
                }
            }
            if (isSubmitting) {
                SubmissionOverlay(strings)
            }
        }
    }

    if (showValidateConfirm) {
        ConfirmDialog(
            title = strings.validateDialogTitle,
            body = strings.validateDialogBody,
            destructiveLabel = strings.validateButton,
            cancelLabel = strings.cancelButton,
            onConfirm = {
                showValidateConfirm = false
                haptic.emit(HapticEvent.ValidateEmitted)
                onValidate()
            },
            onCancel = { showValidateConfirm = false },
        )
    }

    if (showHelp) {
        HelpDialog(
            slides = strings.helpSlides.tissueDashboard,
            strings = strings,
            onClose = { showHelp = false },
        )
    }
}

@Composable
private fun UntypedRemainderFooter(percentages: Map<TissueType, Int>, strings: Strings) {
    val remainder = untypedRemainder(percentages)
    if (remainder <= 0) return
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Text(
            text = strings.untypedFooter(remainder),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(16.dp),
        )
    }
}

@Composable
private fun SubmissionOverlay(strings: Strings) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.4f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator()
            Spacer(Modifier.height(12.dp))
            Text(
                strings.saving,
                color = Color.White,
                style = MaterialTheme.typography.bodyLarge,
            )
        }
    }
}

/**
 * True when every [TissueType.knownValues] entry has a resolved
 * state ([TissueCardState.Drawn] or [TissueCardState.Absent]) in
 * [cardStates]. The Dashboard's Validate button is enabled only
 * when this holds — the user must explicitly resolve every type
 * before submission (spec §7.3).
 *
 * Missing keys count as unresolved: a `cardStates` map without
 * an entry for one of the known types returns `false`.
 *
 * Pure helper for jvmTest coverage.
 */
internal fun isValidateEnabled(cardStates: Map<TissueType, TissueCardState>): Boolean {
    for (type in TissueType.knownValues) {
        val state = cardStates[type] ?: return false
        if (state != TissueCardState.Drawn && state != TissueCardState.Absent) return false
    }
    return true
}

/**
 * Per spec §7.2 — the wound area not covered by any known typed
 * tissue is the "untyped" remainder, `100 − sum(known percentages)`.
 * Largest-remainder apportionment keeps the integer sum in
 * `[0, 100]`, so the remainder is in `[0, 100]` without defensive
 * coercion. Pure helper for jvmTest coverage.
 */
internal fun untypedRemainder(percentages: Map<TissueType, Int>): Int =
    (100 - percentages.values.sum()).coerceIn(0, 100)

