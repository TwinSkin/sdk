@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk

import com.twinskin.sdk.capture.BundleEncryptor
import com.twinskin.sdk.capture.CaptureApi
import com.twinskin.sdk.capture.DefaultCaptureObserver
import com.twinskin.sdk.capture.IosPowerSyncClientFactory
import com.twinskin.sdk.capture.SdkCaptureStore
import com.twinskin.sdk.capture.ServerCaptureSource
import com.twinskin.sdk.capture.STALE_SDK_CAPTURE_DB_WINDOW_MS
import com.twinskin.sdk.capture.captureEncryptionPublicKeyDer
import com.twinskin.sdk.capture.cleanupStaleSdkCaptureDbs
import com.twinskin.sdk.capture.observeAndPruneBundles
import com.twinskin.sdk.capture.systemDevicePlatformInfo
import com.twinskin.sdk.db.DatabaseDriverFactory
import com.twinskin.sdk.db.TwinSkinDatabaseHolder
import com.twinskin.sdk.sdk_client.SdkServerClient
import com.twinskin.sdk.sdk_client.sdkCaptureUrlResolver
import com.twinskin.sdk.storage.IosSdkStorage
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.transfer.BackgroundTransferHandler
import com.twinskin.sdk.transfer.CAPTURE_URL_SESSION_IDENTIFIER
import com.twinskin.sdk.transfer.IosTransferManagerBuilder
import com.twinskin.sdk.transfer.NoOpZipEngine
import com.twinskin.sdk.view.STALE_VIEW_CAPTURE_WINDOW_MS
import com.twinskin.sdk.view.cleanupStaleViewCaptureFiles
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * iOS entry point. Call exactly once from the application entry point
 * (e.g. in `AppDelegate.application(_:didFinishLaunchingWithOptions:)`).
 */
public fun TwinSkinSdk.initialize(config: TwinSkinConfig) {
    if (isInitialized) return
    val database = TwinSkinDatabaseHolder.acquire(DatabaseDriverFactory("twinskin_transfers.db"))
    val store = SdkCaptureStore(database)
    // SupervisorJob so a failing child (e.g. a crashed recovery sweep) doesn't
    // cancel the whole scope and silently brick subsequent captures.
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val serverClient = SdkServerClient(
        baseUrl = config.baseUrl,
        publishableKey = config.publishableKey,
        auth = config.authorizationProvider,
    )
    val logger = config.logger ?: SdkLogger.None
    val resolver = sdkCaptureUrlResolver(store, serverClient, logger)

    val zipEngine = NoOpZipEngine()
    val builder = IosTransferManagerBuilder(
        database = database,
        sessionIdentifier = CAPTURE_URL_SESSION_IDENTIFIER,
        resolveUrl = { uploadKey, completion ->
            scope.launch { completion(resolver(uploadKey)) }
        },
        zipEngine = zipEngine,
    )
    val transferManager = builder.build()
    val provider = builder.provider
        ?: error("IosTransferManagerBuilder.build() did not populate provider")

    // Wire the singleton background-event bridge to the SDK-internal
    // provider so capture uploads survive iOS app suspension. The
    // integrator's AppDelegate forwards
    // application(_:handleEventsForBackgroundURLSession:completionHandler:)
    // and the BGProcessingTask wakeup into TwinSkin.iosBackground —
    // both end up here.
    BackgroundTransferHandler.configure(provider)
    BackgroundTransferHandler.reconnectOnLaunch()
    BackgroundTransferHandler.logger = logger
    BackgroundTransferHandler.refreshHook = { _, uploadKey -> resolver(uploadKey) }
    BackgroundTransferHandler.onUploadRetryRequested = {
        transferManager.launchRecoverPendingUploads()
    }

    val storage = IosSdkStorage()

    val captureApi = CaptureApi(
        transferManager = transferManager,
        encryptor = BundleEncryptor(captureEncryptionPublicKeyDer()),
        store = store,
        sdkVersion = "ios",
        devicePlatformInfo = systemDevicePlatformInfo(),
        encryptedBundlePath = { captureId ->
            "${storage.dir(Purpose.EncryptedBundles)}/sdk-capture-$captureId.bin"
        },
        workingDirForSession = { captureId ->
            "${storage.dir(Purpose.CaptureWorking)}/$captureId"
        },
        scope = scope,
        serverClient = serverClient,
        devMode = config.devMode,
        demoCacheDir = { storage.dir(Purpose.DemoCache) },
    )

    val serverCaptureSource = ServerCaptureSource(
        scope = scope,
        baseUrl = config.baseUrl,
        authProvider = config.authorizationProvider,
        powerSyncFactory = IosPowerSyncClientFactory(scope, logger),
        logger = logger,
    )

    install(
        TwinSkinSdkComponent(
            captureApi = captureApi,
            transferManager = transferManager,
            serverClient = serverClient,
            store = store,
            database = database,
            urlResolver = resolver,
            zipEngine = zipEngine,
            storage = storage,
            captureObserver = DefaultCaptureObserver(store, serverCaptureSource),
            logger = logger,
            devMode = config.devMode,
            verboseFrameLogs = config.verboseFrameLogs,
        ),
    )

    // Heal orphan captures (SdkCaptureUpload rows without a TransferTask) then
    // re-kick ACTIVE/PENDING transfers from a previous launch.
    captureApi.launchRecoveryAll()

    // Kotlin/Native has no public Dispatchers.IO — Dispatchers.Default is a
    // multi-threaded worker pool and is the recommended place to run blocking I/O.
    scope.launch { cleanupStaleSdkCaptureDbs(storage, STALE_SDK_CAPTURE_DB_WINDOW_MS, logger) }
    scope.launch { cleanupStaleViewCaptureFiles(storage, STALE_VIEW_CAPTURE_WINDOW_MS, logger) }
    scope.launch { observeAndPruneBundles(storage, transferManager, logger) }
}
