package com.twinskin.sdk.ui.annotation_editor.delineation.dashboard

import androidx.compose.ui.graphics.Path
import com.twinskin.sdk.geometry.difference
import com.twinskin.sdk.geometry.pathToPolygons
import com.twinskin.sdk.geometry.polygonToPath
import com.twinskin.sdk.geometry.signedArea
import com.twinskin.sdk.geometry.union
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.reDensify
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Tissue
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound
import kotlin.math.absoluteValue

/**
 * "Last tissue auto-fill" — the dashboard offers this as a shortcut
 * when only one tissue type is left unresolved. Assigns the wound
 * area not already covered by any existing tissue (of any type) to
 * [type], yielding the wound with the new fill polygons appended
 * to its [Wound.tissues] list. Returns the wound unchanged when no
 * fillable space remains (existing tissues already tile the wound).
 *
 * **Min-area filter.** Fill polygons whose absolute area is below
 * [minTissueArea] are discarded — the boolean-difference backend
 * yields sub-pixel slivers along clamped boundaries that aren't
 * worth materialising as separate tissues.
 *
 * Yielded polygons are re-densified to the canonical `[2, 10]`
 * image-px vertex spacing the reshape engine assumes.
 */
internal fun autoFillRemainingTissue(
    wound: Wound,
    type: TissueType,
    minTissueArea: Float,
): Wound {
    if (wound.outline.size < 3) return wound
    val remainingPath = remainingPath(wound) ?: return wound
    val newTissues = pathToPolygons(remainingPath)
        .filter { signedArea(it).absoluteValue >= minTissueArea }
        .map { Tissue(type = type, outline = reDensify(it)) }
    if (newTissues.isEmpty()) return wound
    return Wound(
        outline = wound.outline,
        tissues = wound.tissues + newTissues,
    )
}

/**
 * Total image-px² area of the union of every wound's outline that
 * isn't already covered by some tissue. The dispatcher consults
 * this before showing the auto-fill prompt: when the remainder
 * falls below the same `minTissueArea` floor the per-wound fill
 * uses, the dialog would lead to a no-op fill (or a 0% Drawn
 * card) and is suppressed.
 */
internal fun remainingFillableArea(wounds: List<Wound>): Float {
    var total = 0f
    for (wound in wounds) {
        val remainingPath = remainingPath(wound) ?: continue
        for (poly in pathToPolygons(remainingPath)) {
            total += signedArea(poly).absoluteValue
        }
    }
    return total
}

private fun remainingPath(wound: Wound): Path? {
    if (wound.outline.size < 3) return null
    val woundPath = polygonToPath(wound.outline)
    val existingPaths = wound.tissues
        .filter { it.outline.size >= 3 }
        .map { polygonToPath(it.outline) }
    if (existingPaths.isEmpty()) return woundPath
    val existingUnion = existingPaths.reduce { acc, p -> union(acc, p) ?: acc }
    return difference(woundPath, existingUnion)
}
