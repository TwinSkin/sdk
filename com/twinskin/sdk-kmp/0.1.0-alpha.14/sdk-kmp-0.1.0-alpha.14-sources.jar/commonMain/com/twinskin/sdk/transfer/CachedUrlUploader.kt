package com.twinskin.sdk.transfer

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.io.deleteFileQuietly
import com.twinskin.sdk.db.TwinSkinDatabase

internal sealed class CachedUploadOutcome {
    object Done : CachedUploadOutcome()
    object NeedsRefresh : CachedUploadOutcome()
    object RetryLater : CachedUploadOutcome()
    data class PermanentFailure(val reason: String) : CachedUploadOutcome()
}

internal sealed class HttpPutResult {
    object Success : HttpPutResult()
    object UrlExpired : HttpPutResult()
    data class ClientError(val statusCode: Int) : HttpPutResult()
    object TransientError : HttpPutResult()
}

internal typealias HttpPutFn = suspend (
    url: String,
    localPath: String,
    onProgress: suspend (Long, Long) -> Unit,
) -> HttpPutResult

internal class CachedUrlUploader(
    private val database: TwinSkinDatabase,
    private val httpPut: HttpPutFn,
    private val clock: () -> Long,
    private val logger: SdkLogger,
) {
    suspend fun attempt(
        taskId: String,
        onProgress: suspend (Long, Long) -> Unit = { _, _ -> },
    ): CachedUploadOutcome {
        val row = database.transferTaskQueries.selectById(taskId).executeAsOneOrNull()
            ?: return CachedUploadOutcome.PermanentFailure("task row not found")

        if (!fileExists(row.localPath)) {
            val msg = "File not found: ${row.localPath}"
            database.transferTaskQueries.updateStatusAndError(
                status = TransferStatus.FAILED.name,
                errorMessage = msg,
                updatedAt = clock(),
                id = taskId,
            )
            return CachedUploadOutcome.PermanentFailure(msg)
        }

        val cachedUrl = row.presignedUrl
        val expiresAt = row.presignedUrlExpiresAt
        val now = clock()
        val urlIsUsable = cachedUrl != null && expiresAt != null && now < expiresAt - SAFETY_MARGIN_MS
        if (!urlIsUsable) return CachedUploadOutcome.NeedsRefresh

        return when (val result = httpPut(cachedUrl, row.localPath, onProgress)) {
            HttpPutResult.Success -> {
                database.transferTaskQueries.updateStatus(
                    status = TransferStatus.COMPLETED.name,
                    updatedAt = clock(),
                    id = taskId,
                )
                // A background worker can finish while the app is dead, when
                // the prune sweep that would reclaim the bundle isn't running.
                deleteFileQuietly(row.localPath)
                CachedUploadOutcome.Done
            }
            HttpPutResult.UrlExpired -> {
                database.transferTaskQueries.clearPresignedUrl(updatedAt = clock(), id = taskId)
                CachedUploadOutcome.NeedsRefresh
            }
            is HttpPutResult.ClientError -> {
                val msg = "PUT failed: HTTP ${result.statusCode}"
                logger.log("CachedUrlUploader[$taskId] $msg")
                database.transferTaskQueries.updateStatusAndError(
                    status = TransferStatus.FAILED.name,
                    errorMessage = msg,
                    updatedAt = clock(),
                    id = taskId,
                )
                CachedUploadOutcome.PermanentFailure(msg)
            }
            HttpPutResult.TransientError -> {
                logger.log("CachedUrlUploader[$taskId] transient PUT failure — RetryLater")
                CachedUploadOutcome.RetryLater
            }
        }
    }

    private companion object {
        const val SAFETY_MARGIN_MS = 60_000L
    }
}
