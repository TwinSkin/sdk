package com.twinskin.sdk.capture

/**
 * Canonical bundle filenames.
 *
 * The shape of the accompanying `manifest.json` is defined by [CaptureManifest],
 * which is generated from the Pydantic `SdkCaptureManifest` in
 * `packages/capture_pipeline/src/capture_pipeline/models.py` via
 * `packages/server/tool/generate_external_data_models.dart`.
 */
internal object CaptureBundleEntries {
    /** Reference still filename inside the encrypted bundle.
     *  Sorts before every `view_AAA_rXaY.jpg` entry lexicographically
     *  ('r' < 'v'), matching the on-disk naming the photosphere session
     *  writes. */
    const val IMAGE = "ref_image.jpg"

    /** Per-photo telemetry log packed alongside the JPEGs on every
     *  capture (the photosphere session writes one entry per committed
     *  view, regardless of `verboseFrameLogs`). */
    const val POSE_LOG = "pose_log.json"

    /** Per-analyser-tick metrics. Verbose-only — present in the bundle
     *  iff `TwinSkinConfiguration.verboseFrameLogs=true`. */
    const val FRAME_LOG = "frame_log.jsonl"

    /** Reference-frame keypoints, one-shot at `captureReference`.
     *  Verbose-only — same gate as [FRAME_LOG]. */
    const val REFERENCE_KEYPOINTS = "reference_keypoints.json"

    /** Sidecar filenames the submit packing pass enumerates in the
     *  capture's working directory. Order is the deterministic wire
     *  order in `manifest.sidecars` — `CaptureApiTest` pins it. */
    val KNOWN_SIDECARS: List<String> = listOf(POSE_LOG, FRAME_LOG, REFERENCE_KEYPOINTS)
}
