package com.twinskin.sdk.db.shared

import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.twinskin.sdk.db.SdkCaptureUploadQueries
import com.twinskin.sdk.db.TransferTaskQueries
import com.twinskin.sdk.db.TwinSkinDatabase
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<TwinSkinDatabase>.schema: SqlSchema<QueryResult.Value<Unit>>
  get() = TwinSkinDatabaseImpl.Schema

internal fun KClass<TwinSkinDatabase>.newInstance(driver: SqlDriver): TwinSkinDatabase = TwinSkinDatabaseImpl(driver)

private class TwinSkinDatabaseImpl(
  driver: SqlDriver,
) : TransacterImpl(driver),
    TwinSkinDatabase {
  override val sdkCaptureUploadQueries: SdkCaptureUploadQueries = SdkCaptureUploadQueries(driver)

  override val transferTaskQueries: TransferTaskQueries = TransferTaskQueries(driver)

  public object Schema : SqlSchema<QueryResult.Value<Unit>> {
    override val version: Long
      get() = 1

    override fun create(driver: SqlDriver): QueryResult.Value<Unit> {
      driver.execute(null, """
          |CREATE TABLE SdkCaptureUpload (
          |    captureId       TEXT    NOT NULL PRIMARY KEY,
          |    userRef         TEXT    NOT NULL,
          |    subjectRef      TEXT    NOT NULL,
          |    conditionType   TEXT,
          |    captureGroup    TEXT,
          |    bodyLocationJson TEXT,
          |    customJson      TEXT,
          |    deviceInfoJson  TEXT,
          |    encryptedPath   TEXT    NOT NULL,
          |    transferTaskId  TEXT,
          |    -- 1 while a ConditionType.Generic capture is still waiting for the
          |    -- user to trace and submit an annotation; flipped to 0 by the
          |    -- submitAnnotation success path. Wound captures are written with 0.
          |    annotationPending  INTEGER NOT NULL DEFAULT 0,
          |    createdAt       INTEGER NOT NULL DEFAULT 0,
          |    updatedAt       INTEGER NOT NULL DEFAULT 0
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE TransferTask (
          |    id           TEXT    NOT NULL PRIMARY KEY,
          |    url          TEXT    NOT NULL,
          |    localPath    TEXT    NOT NULL,
          |    type         TEXT    NOT NULL,
          |    status       TEXT    NOT NULL,
          |    progress     INTEGER NOT NULL DEFAULT 0,
          |    errorMessage TEXT,
          |    unzip        INTEGER NOT NULL DEFAULT 0,
          |    headers      TEXT,
          |    createdAt    INTEGER NOT NULL DEFAULT 0,
          |    updatedAt    INTEGER NOT NULL DEFAULT 0,
          |    presignedUrl              TEXT,
          |    presignedUrlExpiresAt     INTEGER
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE UNIQUE INDEX TransferTask_active_upload
          |    ON TransferTask(url)
          |    WHERE type = 'UPLOAD' AND status IN ('PENDING', 'ACTIVE', 'UNZIPPING')
          """.trimMargin(), 0)
      return QueryResult.Unit
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.Value<Unit> = QueryResult.Unit
  }
}
