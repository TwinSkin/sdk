@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk

import androidx.compose.ui.window.ComposeUIViewController
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.ui.post_submit.PostSubmitFlow
import com.twinskin.sdk.ui.view_capture.ViewCaptureScreenHost
import com.twinskin.sdk.view.CaptureSource
import platform.UIKit.UIViewController

// Capture on iOS is a pure-SwiftUI view (sdk-ios/Sources/CaptureView.swift) backed
// by AVFoundation, not a Compose screen — there is no CaptureViewController
// counterpart here. The other view controllers below are still Compose-on-iOS.

public fun ViewCaptureViewController(
    source: CaptureSource,
    onClose: () -> Unit = {},
): UIViewController = ComposeUIViewController {
    ViewCaptureScreenHost(source = source, onClose = onClose)
}

public fun PostSubmitFlowViewController(
    session: CaptureSession,
    onDone: () -> Unit = {},
    onCancel: () -> Unit = {},
): UIViewController = ComposeUIViewController {
    PostSubmitFlow(session = session, onDone = onDone, onCancel = onCancel)
}
