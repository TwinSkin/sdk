package com.twinskin.sdk.view

/**
 * JVM stub. The `viewCapture` / resolver stack is Android-and-iOS-only;
 * the `shared` module's JVM target exists purely for CLI tools (e.g.
 * `sdkClientCli`) and never reaches this code path. Throws if called so
 * we notice quickly if someone wires it into a JVM flow by mistake.
 */
actual suspend fun downloadToPath(
    url: String,
    destPath: String,
    onProgress: (bytesRead: Long, total: Long?) -> Unit,
) {
    throw UnsupportedOperationException(
        "downloadToPath is Android/iOS-only; the JVM target has no viewCapture resolvers."
    )
}
