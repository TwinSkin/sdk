package com.twinskin.sdk.capture.prototype

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember

@Composable
actual fun rememberCapturePermissionsState(): CapturePermissionsState = remember {
    object : CapturePermissionsState {
        override val granted: Boolean = false
        override val denied: Boolean = true
        override fun request() = Unit
    }
}
