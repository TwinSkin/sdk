@file:JvmName("SdkClientCli")

package com.twinskin.sdk.tool

import com.twinskin.sdk.sdk_client.ConstantSessionTokenProvider
import com.twinskin.sdk.sdk_client.SdkServerClient
import com.twinskin.sdk.sdk_client.SdkServerException
import com.twinskin.sdk.sdk_client.SdkStartCaptureRequest
import com.twinskin.sdk.sdk_client.SdkStartCaptureResponse
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlin.system.exitProcess

/**
 * Thin CLI wrapper around [SdkServerClient], used by the Dart
 * cross-SDK integration test at
 * `packages/server/integration_test/api/sdk/sdk_client_jvm_test.dart`
 * to exercise the real Kotlin client against the real running server
 * without embedding a JVM into the Dart test process.
 *
 * Writes the response JSON to stdout and exits 0 on success. On
 * [SdkServerException], writes an error envelope to stdout and exits
 * non-zero so the Dart side can assert on the failure shape.
 *
 * Usage:
 *   java -jar sdk-client-cli.jar <subcommand> --flag value ...
 *
 * Subcommands:
 *   start-capture  --base-url, --publishable-key, --session-token,
 *                  --user-ref, --subject-ref,
 *                  [--capture-id], [--condition-type],
 *                  [--capture-group], [--body-location ...],
 *                  [--powersync-url]
 *                    (repeat --body-location to pass multiple values;
 *                     --powersync-url is only needed by upcoming
 *                     observeSubject tests — REST-only callers omit it)
 */
fun main(args: Array<String>) {
    if (args.isEmpty()) {
        System.err.println("usage: <subcommand> --flag value ...")
        exitProcess(64)
    }
    val subcommand = args[0]
    val flags = parseFlags(args.drop(1))

    try {
        val response: JsonElement = runBlocking {
            when (subcommand) {
                "start-capture" -> runStartCapture(flags)
                else -> {
                    System.err.println("unknown subcommand: $subcommand")
                    exitProcess(64)
                }
            }
        }
        println(jsonFormat.encodeToString(JsonElement.serializer(), response))
    } catch (e: SdkServerException) {
        val payload = buildJsonObject {
            put("error", JsonPrimitive(e.message))
            put("statusCode", JsonPrimitive(e.statusCode))
            put("responseBody", JsonPrimitive(e.responseBody))
        }
        println(jsonFormat.encodeToString(JsonObject.serializer(), payload))
        exitProcess(1)
    }
}

private val jsonFormat = Json { ignoreUnknownKeys = true }

private suspend fun runStartCapture(flags: Flags): JsonElement {
    // Build the opaque session-token payload the integrator's backend
    // would return — same wire shape as `POST /api/sdk/sessions/token`.
    // Expires-at is nominally ISO-8601; the CLI never exercises
    // expiry-driven refresh so a fixed placeholder is fine for the
    // current cross-SDK test.
    val sessionTokenJson = buildJsonObject {
        put("token", JsonPrimitive(flags.required("--session-token")))
        put(
            "expires_at",
            JsonPrimitive(flags.optional("--expires-at") ?: "2099-01-01T00:00:00Z"),
        )
        flags.optional("--powersync-url")?.let {
            put("powersync_url", JsonPrimitive(it))
        }
    }.toString()
    val client = SdkServerClient(
        baseUrl = flags.required("--base-url"),
        publishableKey = flags.required("--publishable-key"),
        auth = ConstantSessionTokenProvider(sessionTokenJson),
    )
    try {
        val request = SdkStartCaptureRequest(
            userRef = flags.required("--user-ref"),
            subjectRef = flags.required("--subject-ref"),
            captureId = flags.optional("--capture-id"),
            conditionType = flags.optional("--condition-type"),
            captureGroup = flags.optional("--capture-group"),
            bodyLocation = flags.multi("--body-location").takeIf { it.isNotEmpty() },
        )
        val response = client.startCapture(request)
        return jsonFormat.encodeToJsonElement(
            SdkStartCaptureResponse.serializer(),
            response,
        )
    } finally {
        client.close()
    }
}

private class Flags(
    private val singles: Map<String, String>,
    private val multis: Map<String, List<String>>,
) {
    fun required(key: String): String =
        singles[key] ?: error("missing required flag $key")
    fun optional(key: String): String? = singles[key]
    fun multi(key: String): List<String> = multis[key] ?: emptyList()
}

private val multiValueFlags = setOf("--body-location")

private fun parseFlags(args: List<String>): Flags {
    require(args.size % 2 == 0) {
        "expected paired --flag value args, got $args"
    }
    val singles = mutableMapOf<String, String>()
    val multis = mutableMapOf<String, MutableList<String>>()
    for (chunk in args.chunked(2)) {
        val (k, v) = chunk[0] to chunk[1]
        if (k in multiValueFlags) {
            multis.getOrPut(k) { mutableListOf() }.add(v)
        } else {
            singles[k] = v
        }
    }
    return Flags(singles, multis)
}
