package com.twinskin.sdk.ui

import androidx.compose.runtime.Composable

@Composable
actual fun View3DSceneKitScreen() {
    // SceneKit is not available on JVM
}
