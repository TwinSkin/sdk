@file:JvmName("EncryptCli")

package com.twinskin.sdk.capture.tool

import com.twinskin.sdk.capture.BundleEncryptor
import java.io.File
import java.util.Base64

/**
 * Thin CLI wrapper around [BundleEncryptor.openEncryptingSink]. Used by the
 * capture_pipeline Python cross-SDK test (see `tests/test_cross_sdk_decrypt.py`)
 * to prove that bundles encrypted by the SDK decrypt correctly in Python.
 *
 * Usage:
 *   java -cp ... com.twinskin.sdk.capture.tool.EncryptCli \
 *     --plaintext path/to/input.zip \
 *     --public-key path/to/public.pem \
 *     --out path/to/encrypted.bin
 */
fun main(args: Array<String>) {
    val parsed = parseArgs(args)
    val plaintext = File(parsed.getValue("--plaintext")).readBytes()
    val publicKeyDer = readPemAsDer(File(parsed.getValue("--public-key")))
    val outPath = parsed.getValue("--out")

    val sink = BundleEncryptor(publicKeyDer).openEncryptingSink(outPath)
    sink.write(plaintext, 0, plaintext.size)
    sink.close()
}

private fun parseArgs(args: Array<String>): Map<String, String> {
    require(args.size % 2 == 0) { "expected paired --flag value args, got ${args.toList()}" }
    return args.toList().chunked(2).associate { (k, v) -> k to v }
}

/** Strip the PEM envelope (header/footer/whitespace) and base64-decode the body. */
private fun readPemAsDer(file: File): ByteArray {
    val body = file.readText()
        .lineSequence()
        .filterNot { it.startsWith("-----") }
        .joinToString("")
        .replace("\\s".toRegex(), "")
    return Base64.getDecoder().decode(body)
}
