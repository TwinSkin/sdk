package com.twinskin.sdk.view

/** JVM stub — see [Downloader.jvm.kt] for the rationale. */
internal actual fun listGlbFiles(dir: String): List<String> = emptyList()
