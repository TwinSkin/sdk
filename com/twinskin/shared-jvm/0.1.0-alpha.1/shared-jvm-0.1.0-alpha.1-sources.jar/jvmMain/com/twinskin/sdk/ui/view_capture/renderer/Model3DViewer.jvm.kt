package com.twinskin.sdk.ui.view_capture.renderer

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.twinskin.sdk.view.Asset3D

/**
 * JVM stub for the renderer. The `shared` module's JVM target exists for
 * CLI tooling (e.g. `sdkClientCli`, used by the Python cross-SDK test) and
 * never composes UI. This empty body keeps the expect/actual graph
 * satisfied without dragging a desktop 3D engine into the JVM classpath.
 */
@Composable
actual fun Model3DViewer(
    asset: Asset3D,
    ar: Boolean,
    modifier: Modifier,
) {
    // No-op: JVM target doesn't render.
}
