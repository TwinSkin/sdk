package com.twinskin.sdk.capture.prototype

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private class JvmStubCaptureController : CaptureController {
    private val _state = MutableStateFlow<CaptureControllerState>(
        CaptureControllerState.Error("JVM has no camera"),
    )
    override val state: StateFlow<CaptureControllerState> = _state.asStateFlow()
    override suspend fun takePhoto(): ByteArray = error("JVM has no camera")
    override suspend fun startRecording(): Unit = error("JVM has no camera")
    override suspend fun stopRecording(): String = error("JVM has no camera")
    override fun dispose() = Unit
}

@Composable
actual fun rememberPrototypeCaptureController(): CaptureController =
    remember { JvmStubCaptureController() }

@Composable
actual fun CameraPreview(controller: CaptureController, modifier: Modifier) {
    Box(modifier = modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Text("No camera on JVM", color = Color.White)
    }
}
