package com.twinskin.sdk.db

import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.jdbc.sqlite.JdbcSqliteDriver

actual class DatabaseDriverFactory actual constructor(@Suppress("UNUSED_PARAMETER") dbName: String) {
    actual fun create(): SqlDriver =
        JdbcSqliteDriver(JdbcSqliteDriver.IN_MEMORY)
            .also { TwinSkinDatabase.Schema.create(it) }
}
