package com.twinskin.sdk.capture.io

import java.io.File
import java.io.RandomAccessFile

// JVM actual is identical to the Android one — both use java.io.RandomAccessFile.
// Kept as a separate file only because the androidMain / jvmMain source sets are siblings.
internal actual class RandomAccessByteSink actual constructor(path: String) {

    private val raf: RandomAccessFile
    private var appendPos: Long = 0L
    private var closed = false

    init {
        val file = File(path)
        file.parentFile?.mkdirs()
        raf = RandomAccessFile(file, "rw")
        raf.setLength(0)
    }

    actual fun write(src: ByteArray, off: Int, len: Int) {
        if (len == 0) return
        if (raf.filePointer != appendPos) raf.seek(appendPos)
        raf.write(src, off, len)
        appendPos += len
    }

    actual fun writeAt(pos: Long, src: ByteArray, off: Int, len: Int) {
        if (len == 0) return
        raf.seek(pos)
        raf.write(src, off, len)
    }

    actual fun close() {
        if (closed) return
        closed = true
        raf.close()
    }
}
