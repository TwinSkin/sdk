package com.twinskin.photosphere

import java.nio.ByteBuffer

/** Kotlin facade for `marker_validate_capture` (C). Reentrant. */
object MarkerValidator {
    enum class CaptureVerdict(val code: Int) {
        OK(0),
        MARKER_NOT_FOUND(1),
        TOO_FAR(2),
        TOO_CLOSE(3),
        BLURRY(4),
        ;

        companion object {
            /** Unknown verdict falls back to MARKER_NOT_FOUND so an
             *  outdated client rejects rather than silently ships
             *  frames a newer native side wanted dropped. */
            fun fromCode(code: Int): CaptureVerdict =
                entries.firstOrNull { it.code == code } ?: MARKER_NOT_FOUND
        }
    }

    /**
     * Distance + blur thresholds the gate compares against.
     * Pass zero for both diagonal bounds to disable the distance
     * gate, or zero for `minBlurVariance` to disable the blur gate.
     * See `marker_api.h` for the units note on `minBlurVariance`
     * (uint8 Laplacian variance, ~65k× larger than the [0,1]-domain
     * `xfeat_laplacian_variance`).
     */
    data class CaptureValidationParams(
        val minDiagPx: Float = 0f,
        val maxDiagPx: Float = 0f,
        val minBlurVariance: Float = 0f,
    )

    /**
     * Refined marker geometry returned alongside the validation
     * verdict (null when verdict is `MARKER_NOT_FOUND`).
     */
    data class Detection(
        /** Sub-pixel corners in full-frame space: tl, tr, br, bl -> xy. */
        val corners: FloatArray,
        val markerId: Int,
        val confidence: Float,
    ) {
        init {
            require(corners.size == 8) { "corners must have 8 floats (4 corners × 2)" }
        }

        val centroidX: Float
            get() = (corners[0] + corners[2] + corners[4] + corners[6]) * 0.25f
        val centroidY: Float
            get() = (corners[1] + corners[3] + corners[5] + corners[7]) * 0.25f

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is Detection) return false
            if (!corners.contentEquals(other.corners)) return false
            if (markerId != other.markerId) return false
            return confidence == other.confidence
        }

        override fun hashCode(): Int {
            var h = corners.contentHashCode()
            h = 31 * h + markerId
            h = 31 * h + confidence.hashCode()
            return h
        }
    }

    /**
     * Validation result. `detection` is non-null whenever a marker
     * was refined (every verdict except `MARKER_NOT_FOUND`). On
     * `TOO_FAR` / `TOO_CLOSE` the blur compute is skipped by the C
     * short-circuit and `blurVariance` will be 0.
     */
    data class CaptureValidation(
        val verdict: CaptureVerdict,
        val diagPx: Float,
        val blurVariance: Float,
        val detection: Detection?,
    )

    /**
     * Run the capture validator on a Y-plane image and ROI.
     *
     * @param gray direct [ByteBuffer] holding an 8-bit Y plane,
     *     row-major (rowStride >= width).
     * @param width frame pixel width.
     * @param height frame pixel height.
     * @param rowStride bytes per row in [gray].
     * @param roiX0 inclusive top-left x of the search ROI.
     * @param roiY0 inclusive top-left y.
     * @param roiX1 exclusive bottom-right x.
     * @param roiY1 exclusive bottom-right y.
     * @param params distance + blur thresholds (defaults disable
     *     both gates — useful when the caller only wants the diag /
     *     blur numbers for telemetry).
     * @throws PhotosphereError on malformed inputs or when the
     *     native marker-finder extension is not linked.
     */
    fun validateCapture(
        gray: ByteBuffer,
        width: Int,
        height: Int,
        rowStride: Int,
        roiX0: Int,
        roiY0: Int,
        roiX1: Int,
        roiY1: Int,
        params: CaptureValidationParams = CaptureValidationParams(),
    ): CaptureValidation {
        require(gray.isDirect) { "gray must be a direct ByteBuffer" }
        require(width > 0 && height > 0) { "width and height must be positive" }
        require(rowStride >= width) { "rowStride ($rowStride) must be >= width ($width)" }
        require(roiX1 > roiX0 && roiY1 > roiY0) { "ROI must have positive area" }

        val verdictOut = IntArray(1)
        val scalarsOut = FloatArray(2)
        val cornersOut = FloatArray(8)
        val markerMetaOut = FloatArray(2)

        val rc =
            nativeValidateCapture(
                gray,
                width,
                height,
                rowStride,
                roiX0,
                roiY0,
                roiX1,
                roiY1,
                params.minDiagPx,
                params.maxDiagPx,
                params.minBlurVariance,
                verdictOut,
                scalarsOut,
                cornersOut,
                markerMetaOut,
            )
        if (rc != STATUS_OK) {
            throw PhotosphereError.fromCode(rc, "marker_validate_capture rc=$rc")
        }
        val verdict = CaptureVerdict.fromCode(verdictOut[0])
        val detection =
            if (verdict == CaptureVerdict.MARKER_NOT_FOUND) {
                null
            } else {
                Detection(
                    corners = cornersOut,
                    markerId = markerMetaOut[0].toInt(),
                    confidence = markerMetaOut[1],
                )
            }
        return CaptureValidation(
            verdict = verdict,
            diagPx = scalarsOut[0],
            blurVariance = scalarsOut[1],
            detection = detection,
        )
    }

    init {
        // Soft-load on the host JVM so unit-test class-init doesn't
        // blow up; the first real JNI call surfaces a load failure.
        runCatching { System.loadLibrary("photosphere_native") }
    }

    @JvmStatic private external fun nativeValidateCapture(
        gray: ByteBuffer,
        width: Int,
        height: Int,
        rowStride: Int,
        roiX0: Int,
        roiY0: Int,
        roiX1: Int,
        roiY1: Int,
        minDiagPx: Float,
        maxDiagPx: Float,
        minBlurVariance: Float,
        verdictOut: IntArray,
        scalarsOut: FloatArray,
        cornersOut: FloatArray,
        markerMetaOut: FloatArray,
    ): Int

    private const val STATUS_OK: Int = 0
}
