package com.twinskin.photosphere

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeFormatterBuilder
import java.time.temporal.ChronoField
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Writes two sidecars next to `index.json`:
 *
 *  * `pose_log.json` — per-commit entries. Always-on, ships in release.
 *    Rewritten atomically per commit via tmp-file + `renameTo` so a
 *    mid-session crash still leaves a parseable record.
 *  * `frame_log.jsonl` — per-analyser-tick metrics. DEBUG-only — callers
 *    gate on `BuildConfig.DEBUG` before enqueueing so release builds
 *    pay zero per-frame cost. Bounded to 500 KB by trimming the
 *    oldest 500 lines, checked every 1000 frames.
 *
 * All writes hop onto a private single-threaded executor so the
 * caller's analyser-delegate thread never blocks on file I/O.
 *
 * Field names and the `%.3f` float format mirror iOS so a single
 * cross-platform parser handles both bundles.
 */
internal class PhotospherePosePerCaptureLogger(
    private val sessionDir: File,
) {
    /** Keeps [appendCommit] below detekt's `LongParameterList` cap. */
    @Suppress("LongParameterList")
    data class CommitArgs(
        val slotIndex: Int,
        val armRound: Int,
        val armIndex: Int,
        val targetAzimuthDeg: Float,
        val measuredTiltMagDeg: Float?,
        val measuredTiltPhiDeg: Float?,
        val greatCircleDistanceDeg: Float?,
        val numCheiralityInliers: Int,
        val jpegFilename: String,
        val numMatches: Int? = null,
        val confidence: Float? = null,
        val rotation: FloatArray? = null,
        val translation: FloatArray? = null,
    )

    private val poseLogFile: File = File(sessionDir, POSE_LOG_FILENAME)
    private val frameLogFile: File = File(sessionDir, FRAME_LOG_FILENAME)

    // Single-threaded executor. Callers never wait on it; [flush] is
    // the only synchronous barrier.
    private val executor =
        Executors.newSingleThreadExecutor { r ->
            Thread(r, "xfeat-pose-logger").apply { isDaemon = true }
        }

    // Accumulating commit list — owned by the executor thread; never
    // touched from the public surface. Rewriting the full array on
    // each commit gives the consumer a parseable snapshot even if the
    // session crashes mid-capture. Caps at 32 (16 primary + 16 bonus
    // arms); the rewrite cost is negligible.
    private val commitEntries: MutableList<JSONObject> = mutableListOf()

    // Frame-log byte/line accounting. Owned by the executor thread.
    private var frameLineCount: Long = 0L

    /**
     * Append a per-commit entry to `pose_log.json`. The full array is
     * rewritten atomically (tmp-file + `renameTo`) so a crash mid-
     * capture leaves a parseable snapshot of the arms that committed.
     *
     * Safe to call from any thread. Returns immediately; the actual
     * disk write happens on the logger's private executor.
     */
    fun appendCommit(args: CommitArgs) {
        val timestamp = currentTimestampIso8601()
        executor.execute {
            val entry = JSONObject()
            // Insertion order mirrors the cross-platform sorted-keys
            // emitter; all keys are pure snake_case ASCII so insertion
            // order and sort order match.
            entry.put(KEY_SLOT_INDEX, args.slotIndex)
            entry.put(KEY_ARM_ROUND, args.armRound)
            entry.put(KEY_ARM_INDEX, args.armIndex)
            entry.put(KEY_TARGET_AZIMUTH_DEG, args.targetAzimuthDeg.toDouble())
            putNullableFloat(entry, KEY_MEASURED_TILT_MAG_DEG, args.measuredTiltMagDeg)
            putNullableFloat(entry, KEY_MEASURED_TILT_PHI_DEG, args.measuredTiltPhiDeg)
            putNullableFloat(entry, KEY_GREAT_CIRCLE_DISTANCE_DEG, args.greatCircleDistanceDeg)
            entry.put(KEY_NUM_CHEIRALITY_INLIERS, args.numCheiralityInliers)
            entry.put(KEY_JPEG_FILENAME, args.jpegFilename)
            entry.put(KEY_TIMESTAMP_ISO8601, timestamp)
            putNullableInt(entry, KEY_NUM_MATCHES, args.numMatches)
            putNullableFloat(entry, KEY_CONFIDENCE, args.confidence)
            putNullableFloatArray(entry, KEY_ROTATION, args.rotation)
            putNullableFloatArray(entry, KEY_TRANSLATION, args.translation)
            commitEntries.add(entry)
            rewritePoseLog()
        }
    }

    /**
     * Append a per-frame entry to `frame_log.jsonl`. **DEBUG-only** —
     * callers MUST gate on [BuildConfig.DEBUG] before invoking this
     * method so release builds avoid even the arg-prep cost. The
     * internal append still runs unconditionally if called; the gating
     * is the caller's responsibility.
     *
     * Safe to call from any thread. Returns immediately; the formatter
     * + write hops onto the private executor.
     */
    /** Per-frame metrics. Keeps [appendFrame] below detekt's `LongParameterList` cap. */
    @Suppress("LongParameterList")
    data class FrameArgs(
        val tiltMag: Float?,
        val tiltPhi: Float?,
        val inliers: Int?,
        val gate: String,
        val arm: Int?,
        val frameAgeMs: Float?,
        val numMatches: Int? = null,
        val confidence: Float? = null,
        val targetDistanceDeg: Float? = null,
        val rotation: FloatArray? = null,
        val translation: FloatArray? = null,
        /** Detected live-frame keypoints (x0,y0,x1,y1,...) — length = 2*N_live. */
        val liveKeypoints: FloatArray? = null,
        /** Parallel arrays of length matchCount giving the survivor mutual matches. */
        val matchIdxLive: IntArray? = null,
        val matchIdxRef: IntArray? = null,
        val matchCossim: FloatArray? = null,
        /** Per-frame camera intrinsics K in row-major [fx,0,cx,0,fy,cy,0,0,1]. */
        val intrinsics: FloatArray? = null,
    )

    fun appendFrame(args: FrameArgs) {
        val timestamp = currentTimestampIso8601()
        executor.execute {
            // Hand-rolled JSON keeps the wire format stable across
            // platforms: JSONObject would re-order numeric keys in
            // some implementations, the literal builder is unambiguous.
            val line =
                buildString {
                    append('{')
                    append("\"").append(KEY_FRAME_T).append("\":\"").append(timestamp).append("\",")
                    append("\"").append(KEY_FRAME_TILT_MAG).append("\":").append(formatFloat(args.tiltMag)).append(',')
                    append("\"").append(KEY_FRAME_TILT_PHI).append("\":").append(formatFloat(args.tiltPhi)).append(',')
                    append("\"").append(KEY_FRAME_INLIERS).append("\":").append(formatNullableInt(args.inliers)).append(',')
                    append("\"").append(KEY_FRAME_GATE).append("\":\"").append(args.gate).append("\",")
                    append("\"").append(KEY_FRAME_ARM).append("\":").append(formatNullableInt(args.arm)).append(',')
                    append("\"").append(KEY_FRAME_FRAME_AGE_MS).append("\":").append(formatFloat(args.frameAgeMs)).append(',')
                    append("\"").append(KEY_NUM_MATCHES).append("\":").append(formatNullableInt(args.numMatches)).append(',')
                    append("\"").append(KEY_CONFIDENCE).append("\":").append(formatFloat(args.confidence)).append(',')
                    append("\"").append(KEY_TARGET_DISTANCE_DEG).append("\":").append(formatFloat(args.targetDistanceDeg)).append(',')
                    append("\"").append(KEY_ROTATION).append("\":").append(formatNullableFloatArray(args.rotation)).append(',')
                    append("\"").append(KEY_TRANSLATION).append("\":").append(formatNullableFloatArray(args.translation)).append(',')
                    append("\"").append(KEY_LIVE_KEYPOINTS).append("\":").append(formatNullableFloatArray(args.liveKeypoints)).append(',')
                    append("\"").append(KEY_MATCH_IDX_LIVE).append("\":").append(formatNullableIntArray(args.matchIdxLive)).append(',')
                    append("\"").append(KEY_MATCH_IDX_REF).append("\":").append(formatNullableIntArray(args.matchIdxRef)).append(',')
                    append("\"").append(KEY_MATCH_COSSIM).append("\":").append(formatNullableFloatArray(args.matchCossim)).append(',')
                    append("\"").append(KEY_INTRINSICS).append("\":").append(formatNullableFloatArray(args.intrinsics))
                    append("}\n")
                }
            appendFrameLine(line)
            frameLineCount += 1
            if (frameLineCount % FRAME_LOG_CHECK_INTERVAL == 0L) {
                trimFrameLogIfOversized()
            }
        }
    }

    /**
     * Write the reference frame's detected keypoints once after
     * `captureReference` succeeds. Layout: flat (x0,y0,x1,y1,...) float
     * array under `keypoints`, plus the keypoint count under
     * `keypoint_count`. Safe to call from any thread; serialised on the
     * logger's executor.
     */
    fun writeReferenceKeypoints(refKeypoints: FloatArray) {
        executor.execute {
            val obj = JSONObject()
            obj.put("keypoint_count", refKeypoints.size / 2)
            val arr = JSONArray()
            for (f in refKeypoints) arr.put(f.toDouble())
            obj.put("keypoints", arr)
            obj.put("written_at", currentTimestampIso8601())
            val file = File(sessionDir, REFERENCE_KEYPOINTS_FILENAME)
            val tmp = File(sessionDir, "$REFERENCE_KEYPOINTS_FILENAME.tmp")
            try {
                FileOutputStream(tmp).use { fos ->
                    fos.write(obj.toString(JSON_INDENT).toByteArray(Charsets.UTF_8))
                    fos.fd.sync()
                }
                if (!tmp.renameTo(file)) {
                    file.delete()
                    tmp.renameTo(file)
                }
            } catch (t: Throwable) {
                Log.w(LOG_TAG, "reference_keypoints.json write failed: ${t.message}")
                tmp.delete()
            }
        }
    }

    /**
     * Synchronously drain the logger's serial executor so every
     * previously-enqueued `appendCommit` (and `appendFrame` if any)
     * has fully written to disk before this returns.
     *
     * Without this barrier, the session's finalize could return the
     * bundle URL while the last `appendCommit` for the final arm was
     * still in flight on this executor, and any caller that enumerates
     * the bundle would run before `pose_log.json` hit the filesystem.
     *
     * Safe to call from any thread; MUST NOT be called from the
     * logger's own executor (would deadlock — the submitted barrier
     * task can never run while the calling task holds the worker).
     */
    fun flush() {
        // Submit a no-op and await it — `submit().get()` acts as a
        // synchronous barrier on the serial executor.
        try {
            executor.submit {}.get(FLUSH_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        } catch (t: Throwable) {
            // Best-effort barrier — if the executor was already shut
            // down or the task was interrupted, log and move on. The
            // bundle finalize must not throw on a sidecar.
            Log.w(LOG_TAG, "flush() barrier failed: ${t.message}")
        }
    }

    /**
     * Stop the logger's executor. Idempotent. Called from
     * `PhotosphereSession.close` so a session that never
     * finalized still releases the worker thread. Drains pending tasks
     * first via [flush] so the last writes are not silently dropped.
     */
    fun close() {
        flush()
        executor.shutdown()
    }

    // -- Internals ---------------------------------------------------------

    private fun rewritePoseLog() {
        val arr = JSONArray()
        for (e in commitEntries) {
            arr.put(e)
        }
        val pretty = arr.toString(JSON_INDENT)
        // Atomic rewrite via tmp-file + renameTo so a mid-session crash
        // never leaves a half-written file.
        val tmp = File(sessionDir, "$POSE_LOG_FILENAME.tmp")
        try {
            FileOutputStream(tmp).use { fos ->
                fos.write(pretty.toByteArray(Charsets.UTF_8))
                fos.fd.sync()
            }
            // Atomic rename. On POSIX this is rename(2), which guarantees
            // the destination either points at the new contents or the
            // old, never a half-written file.
            if (!tmp.renameTo(poseLogFile)) {
                // Fallback: delete + rename (Windows-style only; no-op
                // on Android). We stay best-effort here so a transient
                // FS hiccup doesn't break the session.
                poseLogFile.delete()
                tmp.renameTo(poseLogFile)
            }
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "pose_log.json write failed: ${t.message}")
            tmp.delete()
        }
    }

    private fun appendFrameLine(line: String) {
        try {
            // RandomAccessFile gives us seekToEnd + write without an
            // intermediate read.
            RandomAccessFile(frameLogFile, "rw").use { raf ->
                raf.seek(raf.length())
                raf.write(line.toByteArray(Charsets.UTF_8))
            }
        } catch (t: Throwable) {
            // Best-effort sidecar — drop a frame rather than abort the
            // live loop.
            Log.d(LOG_TAG, "frame_log.jsonl append failed: ${t.message}")
        }
    }

    private fun trimFrameLogIfOversized() {
        val length = frameLogFile.length()
        if (length <= FRAME_LOG_MAX_BYTES) return
        try {
            val raw = frameLogFile.readText(Charsets.UTF_8)
            val lines = raw.split('\n')
            if (lines.size <= FRAME_LOG_TRIM_LINES) return
            val kept = lines.drop(FRAME_LOG_TRIM_LINES).joinToString("\n")
            // Atomic rewrite — same tmp-file pattern as the pose-log to
            // keep a tail-truncated frame log parseable on crash.
            val tmp = File(sessionDir, "$FRAME_LOG_FILENAME.tmp")
            FileOutputStream(tmp).use { fos ->
                fos.write(kept.toByteArray(Charsets.UTF_8))
                fos.fd.sync()
            }
            if (!tmp.renameTo(frameLogFile)) {
                frameLogFile.delete()
                tmp.renameTo(frameLogFile)
            }
        } catch (t: Throwable) {
            Log.d(LOG_TAG, "frame_log.jsonl trim failed: ${t.message}")
        }
    }

    private fun putNullableFloat(
        obj: JSONObject,
        key: String,
        value: Float?,
    ) {
        if (value == null) {
            obj.put(key, JSONObject.NULL)
        } else {
            obj.put(key, value.toDouble())
        }
    }

    private fun putNullableInt(
        obj: JSONObject,
        key: String,
        value: Int?,
    ) {
        if (value == null) {
            obj.put(key, JSONObject.NULL)
        } else {
            obj.put(key, value)
        }
    }

    private fun putNullableFloatArray(
        obj: JSONObject,
        key: String,
        value: FloatArray?,
    ) {
        if (value == null) {
            obj.put(key, JSONObject.NULL)
            return
        }
        val arr = JSONArray()
        for (f in value) arr.put(f.toDouble())
        obj.put(key, arr)
    }

    private fun formatFloat(value: Float?): String =
        if (value == null) {
            "null"
        } else {
            String.format(Locale.ROOT, "%.3f", value)
        }

    private fun formatNullableInt(value: Int?): String = value?.toString() ?: "null"

    private fun formatNullableFloatArray(value: FloatArray?): String {
        if (value == null) return "null"
        return buildString {
            append('[')
            for (i in value.indices) {
                if (i > 0) append(',')
                append(String.format(Locale.ROOT, "%.6f", value[i]))
            }
            append(']')
        }
    }

    private fun formatNullableIntArray(value: IntArray?): String {
        if (value == null) return "null"
        return buildString {
            append('[')
            for (i in value.indices) {
                if (i > 0) append(',')
                append(value[i])
            }
            append(']')
        }
    }

    private fun currentTimestampIso8601(): String = ISO_8601_FORMATTER.format(OffsetDateTime.now(ZoneOffset.UTC))

    companion object {
        private const val LOG_TAG: String = "xfeat-pose-logger"

        const val POSE_LOG_FILENAME: String = "pose_log.json"
        const val FRAME_LOG_FILENAME: String = "frame_log.jsonl"
        const val REFERENCE_KEYPOINTS_FILENAME: String = "reference_keypoints.json"

        private const val JSON_INDENT: Int = 2

        // Frame-log trim policy. Raised for Tier-2 sidecars: per-frame
        // lines now carry the detected keypoints + match arrays
        // (~5-30 KB per line at top_k=256/2048), so the 500 KB ceiling
        // would trim every ~20-100 frames. 50 MB covers a ~60s capture
        // at 30 fps without dropping diagnostic frames.
        private const val FRAME_LOG_MAX_BYTES: Long = 50_000_000L
        private const val FRAME_LOG_TRIM_LINES: Int = 500
        private const val FRAME_LOG_CHECK_INTERVAL: Long = 1_000L

        // Cap on flush() blocking — best-effort. The barrier task is a
        // no-op so should drain in <100 ms even on a fully loaded
        // executor; 5 s is a wide tolerance for a thrashing device.
        private const val FLUSH_TIMEOUT_MS: Long = 5_000L

        // CommitEntry JSON keys.
        const val KEY_SLOT_INDEX: String = "slot_index"
        const val KEY_ARM_ROUND: String = "arm_round"
        const val KEY_ARM_INDEX: String = "arm_index"
        const val KEY_TARGET_AZIMUTH_DEG: String = "target_azimuth_deg"
        const val KEY_MEASURED_TILT_MAG_DEG: String = "measured_tilt_mag_deg"
        const val KEY_MEASURED_TILT_PHI_DEG: String = "measured_tilt_phi_deg"
        const val KEY_GREAT_CIRCLE_DISTANCE_DEG: String = "great_circle_distance_deg"
        const val KEY_NUM_CHEIRALITY_INLIERS: String = "num_cheirality_inliers"
        const val KEY_JPEG_FILENAME: String = "jpeg_filename"
        const val KEY_TIMESTAMP_ISO8601: String = "timestamp_iso8601"
        const val KEY_NUM_MATCHES: String = "num_matches"
        const val KEY_CONFIDENCE: String = "confidence"
        const val KEY_ROTATION: String = "rotation"
        const val KEY_TRANSLATION: String = "translation"
        const val KEY_TARGET_DISTANCE_DEG: String = "target_distance_deg"

        // FrameEntry JSON keys.
        const val KEY_FRAME_T: String = "t"
        const val KEY_FRAME_TILT_MAG: String = "tilt_mag"
        const val KEY_FRAME_TILT_PHI: String = "tilt_phi"
        const val KEY_FRAME_INLIERS: String = "inliers"
        const val KEY_FRAME_GATE: String = "gate"
        const val KEY_FRAME_ARM: String = "arm"
        const val KEY_FRAME_FRAME_AGE_MS: String = "frame_age_ms"
        const val KEY_LIVE_KEYPOINTS: String = "live_keypoints"
        const val KEY_MATCH_IDX_LIVE: String = "match_idx_live"
        const val KEY_MATCH_IDX_REF: String = "match_idx_ref"
        const val KEY_MATCH_COSSIM: String = "match_cossim"
        const val KEY_INTRINSICS: String = "intrinsics"

        // ISO-8601 with fractional milliseconds + UTC offset
        // (e.g. `2026-05-04T10:11:12.345Z`).
        private val ISO_8601_FORMATTER: DateTimeFormatter =
            DateTimeFormatterBuilder()
                .append(DateTimeFormatter.ISO_LOCAL_DATE)
                .appendLiteral('T')
                .appendValue(ChronoField.HOUR_OF_DAY, 2)
                .appendLiteral(':')
                .appendValue(ChronoField.MINUTE_OF_HOUR, 2)
                .appendLiteral(':')
                .appendValue(ChronoField.SECOND_OF_MINUTE, 2)
                .appendFraction(ChronoField.MILLI_OF_SECOND, 3, 3, true)
                .appendOffsetId()
                .toFormatter(Locale.ROOT)

        /**
         * Test hook — produces an ISO-8601 timestamp string for the
         * given epoch-millisecond instant using the same formatter the
         * production emitter uses. Lets unit tests build deterministic
         * fixtures without spinning up a logger.
         */
        @Suppress("unused")
        internal fun formatIso8601ForTest(epochMillis: Long): String =
            ISO_8601_FORMATTER.format(
                OffsetDateTime.ofInstant(Instant.ofEpochMilli(epochMillis), ZoneOffset.UTC),
            )
    }
}
