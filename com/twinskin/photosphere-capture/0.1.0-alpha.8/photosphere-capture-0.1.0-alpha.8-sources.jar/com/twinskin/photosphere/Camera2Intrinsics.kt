package com.twinskin.photosphere

import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureResult
import android.os.Build

/**
 * Camera2 -> K helpers.
 *
 * K source priority (see docs/06 § "K source priority (per-device)"):
 *   Priority 1. Per-frame `LENS_INTRINSIC_CALIBRATION` from
 *     [CaptureResult] on OIS-equipped flagships with DEPTH_OUTPUT.
 *   Priority 2. Bundled profile keyed by [Build.MODEL]. Currently
 *     only "SM-G525F" (Galaxy XCover 5) ships here; add more as they
 *     get calibrated per docs/06 § "Bundled checkerboard calibration
 *     procedure".
 *   Priority 3. 65 degree pinhole fallback. Rotation bias up to 5 deg,
 *     translation direction error up to 15 deg; smoke-test grade only.
 *
 * The [resolveK] entry point walks the priority order and returns the
 * first source that yields a usable 3x3.
 *
 * Note: XCover 5's Exynos 850 does not advertise `DEPTH_OUTPUT`, so
 * [CaptureResult.LENS_INTRINSIC_CALIBRATION] is expected null. That is
 * the point of the bundled profile + pinhole fallback on that device.
 */
object Camera2Intrinsics {
    /** Build-model identifiers for which we ship a bundled K profile. */
    private const val MODEL_GALAXY_XCOVER_5: String = "SM-G525F"

    /**
     * Galaxy XCover 5 (SM-G525F) rear-camera profile. Placeholder values
     * — docs/06 § "Bundled calibration profile" calls for a 20-image
     * checkerboard calibration run. That run is deferred to M5/M6 (see
     * OI-010); until then the values below approximate the expected
     * reference (4608x3456 SENSOR_INFO_ACTIVE_ARRAY_SIZE, ~65 deg
     * horizontal FoV). Native dims measured live on device (P0 task 1
     * / tools/on-device-test/dump-intrinsics); the previous 4160x3120
     * pair was an incorrect marketing-spec figure and produced a 10.8%
     * fx inflation after scaling to the 640×480 analyser frame.
     *
     * The fx/fy pair below is expressed in the sensor's 4608x3456 active
     * array. Callers that feed the pipeline a 480x640 (or any other)
     * image pass this through `PhotosphereRunner.adjustIntrinsics(...)` to
     * rescale into the input frame.
     */
    fun bundledGalaxyXCover5(): CameraKProfile =
        CameraKProfile(
            model = MODEL_GALAXY_XCOVER_5,
            nativeWidth = 4608,
            nativeHeight = 3456,
            fx = 3232.0f,
            fy = 3232.0f,
            cx = 2304.0f,
            cy = 1728.0f,
            distortionK1 = -0.08f,
            distortionK2 = 0.12f,
            source =
                "docs/06 § Bundled calibration profile — placeholder, " +
                    "pending 20-image checkerboard run in M5/M6 (OI-010)",
        )

    /**
     * Read the K array from a [CaptureResult] if the device exposes
     * per-frame calibration. Returns null when the field is missing
     * (the XCover case). Typically non-null only on OIS-equipped
     * flagships where `DEPTH_OUTPUT` is advertised.
     */
    fun readPerFrameK(result: CaptureResult): FloatArray? {
        val k = result.get(CaptureResult.LENS_INTRINSIC_CALIBRATION) ?: return null
        return intrinsic5ToK(k)
    }

    /**
     * Read the static K from [CameraCharacteristics]. On XCover this
     * returns null; on flagships it returns the factory-calibrated K
     * in sensor-active pixel coordinates.
     */
    fun readStaticK(chars: CameraCharacteristics): FloatArray? {
        val k = chars.get(CameraCharacteristics.LENS_INTRINSIC_CALIBRATION) ?: return null
        return intrinsic5ToK(k)
    }

    /**
     * Walk the priority order. The [perFrame] argument is the result of
     * [readPerFrameK] on the most recent frame (may be null). [chars]
     * is passed through so we can look up the static K when the
     * per-frame field is missing but the camera still advertises a
     * calibration. [pipelineW] / [pipelineH] are the photosphere input shape
     * used for the 65 deg pinhole fallback only.
     *
     * The returned [KResolution] carries the native frame the K is
     * expressed in (`nativeWidth` / `nativeHeight`). This is critical:
     * `xfeat_adjust_k` assumes K is already in `(inW × inH)` coords,
     * and feeding it a sensor-active K with bitmap dims would slide the
     * principal point outside the pipeline frame — the Stage-6
     * cheirality-0 class of bug.
     */
    fun resolveK(
        perFrame: FloatArray?,
        chars: CameraCharacteristics?,
        pipelineW: Int,
        pipelineH: Int,
        modelKey: String = Build.MODEL,
    ): KResolution {
        val sensorActive = chars?.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
        if (perFrame != null) {
            val nw = sensorActive?.width() ?: pipelineW
            val nh = sensorActive?.height() ?: pipelineH
            return KResolution(perFrame, KSource.PER_FRAME_LENS_INTRINSIC, nw, nh)
        }
        val staticK = chars?.let { readStaticK(it) }
        if (staticK != null) {
            val nw = sensorActive?.width() ?: pipelineW
            val nh = sensorActive?.height() ?: pipelineH
            return KResolution(staticK, KSource.STATIC_LENS_INTRINSIC, nw, nh)
        }
        val profile = bundledProfile(modelKey)
        if (profile != null) {
            return KResolution(
                floatArrayOf(
                    profile.fx,
                    0.0f,
                    profile.cx,
                    0.0f,
                    profile.fy,
                    profile.cy,
                    0.0f,
                    0.0f,
                    1.0f,
                ),
                KSource.BUNDLED_PROFILE,
                profile.nativeWidth,
                profile.nativeHeight,
            )
        }
        // Pinhole K is synthesised at pipeline dims, so its native frame
        // equals (pipelineW, pipelineH) by construction.
        return KResolution(
            PhotosphereFixtures.pinhole65Degrees(pipelineW, pipelineH),
            KSource.PINHOLE_65DEG_FALLBACK,
            pipelineW,
            pipelineH,
        )
    }

    private fun bundledProfile(model: String): CameraKProfile? =
        when (model) {
            MODEL_GALAXY_XCOVER_5 -> bundledGalaxyXCover5()
            else -> null
        }

    /** `LENS_INTRINSIC_CALIBRATION` is `[fx, fy, cx, cy, s]`; we drop s
     *  (skew; zero on every phone camera we target) and emit the 3x3. */
    private fun intrinsic5ToK(k: FloatArray): FloatArray {
        require(k.size == INTRINSIC_CALIBRATION_SIZE) {
            "LENS_INTRINSIC_CALIBRATION must have 5 elements"
        }
        return floatArrayOf(
            k[0],
            0.0f,
            k[2],
            0.0f,
            k[1],
            k[3],
            0.0f,
            0.0f,
            1.0f,
        )
    }

    private const val INTRINSIC_CALIBRATION_SIZE = 5
}

/** A bundled calibration profile loaded from the library resources. */
data class CameraKProfile(
    val model: String,
    val nativeWidth: Int,
    val nativeHeight: Int,
    val fx: Float,
    val fy: Float,
    val cx: Float,
    val cy: Float,
    val distortionK1: Float,
    val distortionK2: Float,
    val source: String,
)

/** Where the resolved K ultimately came from — useful for telemetry
 *  and for the M3 exit criterion "null-rate over 100 frames". */
enum class KSource {
    PER_FRAME_LENS_INTRINSIC,
    STATIC_LENS_INTRINSIC,
    BUNDLED_PROFILE,
    PINHOLE_65DEG_FALLBACK,
}

/**
 * Carries the resolved K plus the native frame the K is expressed in.
 *
 * `xfeat_adjust_k` (common/xfeat/intrinsics.c) trusts that K is already
 * in `(inW × inH)` pixel coords and performs rotate → centre-crop →
 * uniform-scale in that frame. A bundled profile's K lives in the
 * sensor's active-array coords (e.g. 4608×3456 for the XCover 5), NOT
 * in bitmap coords — the [nativeWidth] / [nativeHeight] pair is the
 * authoritative (inW, inH) to pass into `adjustIntrinsics`.
 */
data class KResolution(
    val kMatrix: FloatArray,
    val source: KSource,
    val nativeWidth: Int,
    val nativeHeight: Int,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is KResolution) return false
        if (!kMatrix.contentEquals(other.kMatrix)) return false
        if (source != other.source) return false
        if (nativeWidth != other.nativeWidth) return false
        return nativeHeight == other.nativeHeight
    }

    override fun hashCode(): Int {
        var result = kMatrix.contentHashCode()
        result = 31 * result + source.hashCode()
        result = 31 * result + nativeWidth
        result = 31 * result + nativeHeight
        return result
    }
}
