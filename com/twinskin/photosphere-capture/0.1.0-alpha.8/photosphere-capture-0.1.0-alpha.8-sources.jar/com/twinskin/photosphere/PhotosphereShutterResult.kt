package com.twinskin.photosphere

/**
 * Per-view sensor metadata captured at shutter time. Emitted under
 * `views[i].sensor` in `index.json`.
 *
 * Fields are independently nullable — some HALs return `null` for
 * individual `CaptureResult` keys even when the wider
 * `TotalCaptureResult` is available. Absent keys are omitted from the
 * JSON (NOT emitted as `null`) so consumers can use `has()` probes.
 *
 * [lensPosition] units differ across platforms: Android reports it in
 * dioptres (0 = infinity), iOS reports a normalised `[0.0, 1.0]`.
 * Consumers must branch on `build.platform`.
 */
data class PhotosphereViewSensor(
    val exposureDurationNs: Long? = null,
    val iso: Int? = null,
    val lensPosition: Float? = null,
    val timestampNs: Long? = null,
)

/**
 * Return type of the session's `shutterCallback`.
 *
 * `sensor` is hardware-sourced; `captureStartedNs` and
 * `captureCallReturnedNs` are software-measured monotonic timestamps
 * (boot-relative `SystemClock.elapsedRealtimeNanos`). Synthetic-replay
 * backends pass `null` for all three.
 *
 * The session emits all three at the top level of each `views[i]`
 * entry (NOT under `sensor`). Together with the session-side
 * `captureEndedNs` they separate per-arm shutter-call latency
 * (`captureCallReturnedNs - captureStartedNs`) from intent-to-durable
 * (`captureEndedNs - captureStartedNs`).
 */
data class PhotosphereShutterResult(
    val bytes: ByteArray,
    val sensor: PhotosphereViewSensor? = null,
    val captureStartedNs: Long? = null,
    val captureCallReturnedNs: Long? = null,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PhotosphereShutterResult) return false
        if (!bytes.contentEquals(other.bytes)) return false
        if (sensor != other.sensor) return false
        if (captureStartedNs != other.captureStartedNs) return false
        return captureCallReturnedNs == other.captureCallReturnedNs
    }

    override fun hashCode(): Int {
        var result = bytes.contentHashCode()
        result = 31 * result + (sensor?.hashCode() ?: 0)
        result = 31 * result + (captureStartedNs?.hashCode() ?: 0)
        result = 31 * result + (captureCallReturnedNs?.hashCode() ?: 0)
        return result
    }
}
