package com.twinskin.photosphere

/**
 * Configuration for an [PhotosphereRunner] instance.
 *
 * Mirrors the iOS [`PhotosphereConfig`](https://example/ios/PhotosphereConfig.swift)
 * surface; divergence kept minimal so test fixtures and tuning numbers
 * stay comparable across platforms.
 *
 * @property height Input height fed to the backbone. Must be divisible
 *     by 32 and match the exported `.ort` file's input shape.
 * @property width Input width fed to the backbone. Same constraint.
 * @property topK Maximum keypoints kept after NMS.
 * @property nmsThresh Heatmap threshold for the 5x5 max-pool NMS.
 * @property minCossim Mutual-NN cosine-similarity filter. Tune per
 *     device build (~0.82 flagship fp16, ~0.75 XCover int8 per docs/04).
 * @property minCheiralityInliers Minimum MAGSAC cheirality inliers required
 *     for Stage 6 pose acceptance. `0` (the default) means "use the C-side
 *     default" (`xfeat_api.h` — currently 15, being lowered to 5 by the
 *     parallel P0-task-3 C-engineer commit). Callers tune this per
 *     use-case: replay mode uses 8 for Blender-rendered trajectories
 *     where inter-arm parallax is smaller; live photosphere after P0
 *     may use 5 or 6. Mirrors the iOS
 *     `PhotosphereConfig.minCheiralityInliers` default-zero convention.
 * @property modelAssetPath Explicit override for the asset to load. When
 *     `null` (the default), [PhotosphereRunner.create] runs the per-device
 *     dispatch (OI-013): fp32 on Cortex-A55 XCover boards (no SDOT, int8
 *     gave no speedup and thermal-throttled), int8 on Pixel 8 / other
 *     SDOT-capable devices, fp32 as the conservative unknown-device
 *     fallback. Set a non-null value to bypass the dispatch entirely —
 *     tests and advanced callers use this to pin a specific artifact.
 */
data class PhotosphereConfig(
    val height: Int = 480,
    val width: Int = 640,
    val topK: Int = 2048,
    val nmsThresh: Float = 0.05f,
    val minCossim: Float = 0.82f,
    val minCheiralityInliers: Int = 0,
    val modelAssetPath: String? = null,
)

/**
 * JPEG compression applied to all captured images (ref + views) at
 * finalize time, before the bundle zip is assembled and uploaded.
 *
 * Default: enabled at 700 KB target. Two-pass bounded approach:
 *   1. Encode at [initialQuality] (typically 80).
 *   2. If result > [targetKB] KB, encode at [fallbackQuality] (65).
 *   3. If still > target, encode at [minQuality] floor and accept.
 * PNG views (viewLossless = true) are passed through unchanged.
 *
 * Performance: ~100-150 ms per image on Pixel 6. A 17-image session
 * adds ~2 s at finalize but saves ~30 s of upload on cellular.
 */
data class PhotosphereCompressionConfig(
    /** Whether compression is applied. When `false`, bytes are written
     *  verbatim (original camera JPEG quality, typically 5-8 MB). */
    val enabled: Boolean = true,
    /** Maximum target size in KB per image. Default 700 KB. */
    val targetKB: Int = 700,
    /** Quality tried first (0-100). Default 80. */
    val initialQuality: Int = 80,
    /** Quality tried if first pass exceeds target. Default 65. */
    val fallbackQuality: Int = 65,
    /** Minimum quality floor (0-100). Never go below this regardless
     *  of target. Default 30 — XFeat does NOT consume these bytes
     *  (it operates on the live analyser luma frame), so the floor
     *  is driven entirely by downstream MVS reconstruction. The
     *  share_xav benchmark's q=40 reference was wound-skin imagery
     *  (smooth content, ~525 KB per 12 MP image); real captures with
     *  more high-frequency content (edges, surroundings) land 2-3×
     *  larger at the same quality. q=30 brings the typical-content
     *  floor under ~1 MB while staying above the q=20-25 threshold
     *  where blocking + chroma washout become visibly destructive
     *  to MVS texture coverage. */
    val minQuality: Int = 30,
) {
    companion object {
        /** Compression disabled — bytes written verbatim. */
        val Disabled = PhotosphereCompressionConfig(enabled = false)
        /** Default: enabled, 700 KB target. */
        val Default = PhotosphereCompressionConfig()
    }
}

/**
 * Canonical asset paths shipped in the library's `src/main/assets/`
 * tree. Kept in one place so the Camera2 test harness, the soak driver,
 * and any host-side tooling reach the same filenames.
 *
 * Both artifacts ship in the AAR; the per-device dispatch in
 * [PhotosphereRunner.pickDefaultAssetPath] picks between them at session-
 * construction time. The int8 artifact is the QDQ-quantised backbone
 * landed by the c-engineer/ml-engineer (docs/04 § QDQ, VALIDATION.md);
 * fp32 is the reference path used on boards whose cores lack SDOT — on
 * XCover 5 (Cortex-A55) the int8 gain vanishes and thermal headroom
 * actually drops (OI-013, VALIDATION.md § M5 XCover int8 soak FAIL).
 */
object PhotosphereAssets {
    const val INT8_480X640: String = "photosphere/XFeatBackbone_480x640.int8.sim.onnx"
    const val FP32_480X640: String = "photosphere/XFeatBackbone_480x640.onnx"
}

/**
 * Execution provider requested at ORT session construction. The Kotlin
 * enum maps to the JNI-side native configuration; the JNI layer is free
 * to fall back to a less-preferred EP when the device rejects the
 * request, and the chosen EP is reported back via [ActualExecutionProvider].
 */
enum class PreferredExecutionProvider {
    /** NNAPI with FP16 + CPU-disabled flags. Pixel 8 primary. */
    NNAPI,

    /** XNNPACK (multithreaded CPU). XCover primary; flagships fallback. */
    XNNPACK,

    /** Plain CPU EP. Last-resort / unit-test-on-desktop path. */
    CPU,
}

/** The EP that ORT actually placed the model on (reported post-init). */
enum class ActualExecutionProvider {
    NNAPI,
    XNNPACK,
    CPU,
    UNKNOWN,
    ;

    companion object {
        /** JNI returns a small int code; decode here to keep the JNI
         *  surface purely primitive. */
        fun fromCode(code: Int): ActualExecutionProvider =
            when (code) {
                1 -> NNAPI
                2 -> XNNPACK
                3 -> CPU
                else -> UNKNOWN
            }
    }
}

/**
 * Recovered pair-pose. [rotation] is row-major 3x3; [translation] is a
 * unit-norm direction vector. Both are length-preserving as a Swift
 * `simd_float3x3` / `SIMD3<Float>` on iOS.
 */
data class PhotospherePose(
    val rotation: FloatArray, // length 9, row-major
    val translation: FloatArray, // length 3
    val numMatches: Int,
    val numInliers: Int,
    val confidence: Float,
) {
    init {
        require(rotation.size == ROTATION_SIZE) { "rotation must have size $ROTATION_SIZE" }
        require(translation.size == TRANSLATION_SIZE) {
            "translation must have size $TRANSLATION_SIZE"
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PhotospherePose) return false
        if (!rotation.contentEquals(other.rotation)) return false
        if (!translation.contentEquals(other.translation)) return false
        if (numMatches != other.numMatches) return false
        if (numInliers != other.numInliers) return false
        return confidence == other.confidence
    }

    override fun hashCode(): Int {
        var result = rotation.contentHashCode()
        result = 31 * result + translation.contentHashCode()
        result = 31 * result + numMatches
        result = 31 * result + numInliers
        result = 31 * result + confidence.hashCode()
        return result
    }

    companion object {
        const val ROTATION_SIZE: Int = 9
        const val TRANSLATION_SIZE: Int = 3
    }
}

/**
 * Per-stage wall-clock timings captured by the JNI bridge during a
 * single [PhotosphereRunner.estimatePoseWithTimings] call.
 *
 * Internal (debug / DemoApp telemetry) surface — not part of the
 * shipped SDK contract. All fields are milliseconds as `Double` to
 * preserve sub-millisecond fractions without forcing callers to do
 * nanosecond arithmetic. Measured with `std::chrono::steady_clock`
 * on the native side; the JNI layer brackets each native call so the
 * numbers include buffer staging but NOT JNI dispatch overhead
 * outside the bracket.
 *
 * Stage semantics mirror the iOS DemoApp counterpart:
 *   - [backboneAMs] / [backboneBMs] — single ORT forward per image.
 *   - [postprocessMs] — both Stage 3 calls (A and B) summed.
 *   - [matchMs] — Stage 5 + 6 (MNN + essential + RANSAC) together;
 *     splitting them further requires a C-ABI split that we chose not
 *     to land for the DemoApp (honours the "do NOT change the C ABI"
 *     guardrail in the DemoApp brief).
 */
data class PhotosphereStageTimings(
    val backboneAMs: Double,
    val backboneBMs: Double,
    val postprocessMs: Double,
    val matchMs: Double,
)

/**
 * Pose + optional timings tuple returned from
 * [PhotosphereRunner.estimatePoseWithTimings]. Kept out of the public
 * [PhotosphereRunner.estimatePose] signature so the shipped library surface
 * stays lean.
 */
data class PhotospherePoseWithTimings(
    val pose: PhotospherePose,
    val timings: PhotosphereStageTimings,
)

/** Single side of a pre-forwarded backbone output triple. Used by tests
 *  that want to drive the C ABI without actually running ORT. */
data class PhotosphereBackboneOutputs(
    val feats: FloatArray,
    val kptlogits: FloatArray,
    val heatmap: FloatArray,
    val scaleX: Float,
    val scaleY: Float,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PhotosphereBackboneOutputs) return false
        if (!feats.contentEquals(other.feats)) return false
        if (!kptlogits.contentEquals(other.kptlogits)) return false
        if (!heatmap.contentEquals(other.heatmap)) return false
        if (scaleX != other.scaleX) return false
        return scaleY == other.scaleY
    }

    override fun hashCode(): Int {
        var result = feats.contentHashCode()
        result = 31 * result + kptlogits.contentHashCode()
        result = 31 * result + heatmap.contentHashCode()
        result = 31 * result + scaleX.hashCode()
        result = 31 * result + scaleY.hashCode()
        return result
    }
}

/** Fixtures that both instrumented and JVM tests can share. */
object PhotosphereFixtures {
    /**
     * 65 degrees horizontal FoV pinhole — the last-resort fallback K
     * (docs/06 § 180-184) used when `LENS_INTRINSIC_CALIBRATION` is
     * null and the bundled profile doesn't cover the device model.
     * Rotation bias up to 5 degrees, translation direction error up
     * to 15 degrees; smoke-test grade only.
     */
    fun pinhole65Degrees(
        width: Int,
        height: Int,
    ): FloatArray {
        val tanHalfFov = 0.6378314f // tan(32.5°)
        val fPx = width.toFloat() / (2.0f * tanHalfFov)
        val cx = width.toFloat() * 0.5f
        val cy = height.toFloat() * 0.5f
        return floatArrayOf(
            fPx,
            0.0f,
            cx,
            0.0f,
            fPx,
            cy,
            0.0f,
            0.0f,
            1.0f,
        )
    }

    /** The iOS-side dummy-intrinsics equivalent — `f = max(W, H)`,
     *  principal point at centre. Useful when tests want the same
     *  numeric profile as the iOS PhotosphereFixtures.dummyIntrinsics() path
     *  (ios/Sources/Photosphere/PhotosphereTypes.swift § PhotosphereFixtures.dummyIntrinsics). */
    fun dummyIntrinsics(
        width: Int,
        height: Int,
    ): FloatArray {
        val f = maxOf(width, height).toFloat()
        val cx = width.toFloat() * 0.5f
        val cy = height.toFloat() * 0.5f
        return floatArrayOf(
            f,
            0.0f,
            cx,
            0.0f,
            f,
            cy,
            0.0f,
            0.0f,
            1.0f,
        )
    }
}
