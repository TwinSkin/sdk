package com.twinskin.photosphere

/**
 * Reference EN copy for the photosphere capture flow.
 *
 * The SDK consumes this as the default; the downstream application that
 * embeds the photosphere_capture AAR owns localisation (Q-UX-6 resolved EN-only —
 * CL-035 § 7). An integrating project retranslates by constructing a
 * new [PhotosphereStrings] and passing it at session-construction
 * time.
 *
 * Strings are verbatim from `docs/tracking/architecture-2026-04-22/17-image-ux-design.md`
 * § 3. Keep that doc and this object in sync; the UX design doc is the
 * canonical source of truth.
 *
 * @property roundBanner Title for each round (1..4). CL-035 § 3 "Phase banners".
 * @property hintFar Hint when the user needs to turn a large angle (>10°).
 *     Callers substitute the numeric delta via [String.format].
 * @property hintClose Hint when within 3-10° of the target arm.
 * @property hintOnTarget Hint when within the 3° capture band.
 * @property hintMarkerOffCentre Hint when the marker drifts out of frame.
 * @property hintPoseUnstable Hint when the live pose is thrashing
 *     (inliers oscillating).
 * @property toastRoundDone Per-round completion toast (1..4).
 * @property errorBaselineTooNarrow Error banner for R-P1 "inliers < 15
 *     sustained 500ms" recovery path.
 * @property errorMarkerLost Error banner for mid-round marker loss.
 * @property errorPhoneMoved Error banner for shutter-time motion blur.
 * @property errorThermal Error banner for R-P2 thermal-throttle abort.
 * @property confirmReshoot Modal copy for the destructive "re-shoot ref"
 *     confirmation dialog.
 */
data class PhotosphereStrings(
    val roundBanner: Map<Int, String>,
    val hintFar: String,
    val hintClose: String,
    val hintOnTarget: String,
    val hintMarkerOffCentre: String,
    val hintPoseUnstable: String,
    val toastRoundDone: Map<Int, String>,
    val errorBaselineTooNarrow: String,
    val errorMarkerLost: String,
    val errorPhoneMoved: String,
    val errorThermal: String,
    val confirmReshoot: String,
) {
    companion object {
        /**
         * Reference EN copy — the strings the operator signed off on
         * 2026-04-22 in CL-035 § 3.
         *
         * Downstream integrators that need a different language build
         * a new [PhotosphereStrings] by re-translating each field.
         */
        val DEFAULT_EN: PhotosphereStrings =
            PhotosphereStrings(
                roundBanner =
                    mapOf(
                        1 to "Round 1 / 4 — Cardinal angles. Turn to 0°, 90°, 180°, 270°.",
                        2 to "Round 2 / 4 — 22.5° diagonals. Aim between the green arms.",
                        3 to "Round 3 / 4 — 45° diagonals. Full diagonals between cardinals.",
                        4 to "Round 4 / 4 — 67.5° fine step. Fill the remaining gaps.",
                    ),
                hintFar = "Turn %d° %s.",
                hintClose = "Almost there — a bit more.",
                hintOnTarget = "Hold steady — capturing…",
                hintMarkerOffCentre = "Keep the marker in frame.",
                hintPoseUnstable = "Hold still, re-acquiring.",
                toastRoundDone =
                    mapOf(
                        1 to "Round 1 complete. Next: rotate 22.5° between the cardinals.",
                        2 to "Round 2 complete. Next: 45° diagonals.",
                        3 to "Round 3 complete. Last round: 67.5°.",
                        4 to "All 16 angles captured. Reviewing…",
                    ),
                errorBaselineTooNarrow = "Move further from the previous view. Step back ~15 cm.",
                errorMarkerLost = "Marker lost — bring it back into view.",
                errorPhoneMoved = "Hold steadier — re-take this angle.",
                errorThermal = "Pose guidance paused — device cooling.",
                confirmReshoot = "Re-shooting the reference resets all 16 angles. Continue?",
            )
    }
}
