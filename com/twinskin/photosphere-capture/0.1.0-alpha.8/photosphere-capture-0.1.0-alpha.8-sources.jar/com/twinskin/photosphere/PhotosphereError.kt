package com.twinskin.photosphere

/**
 * Public error surface for the photosphere_capture Android library.
 *
 * Codes map 1:1 to the C ABI's `xfeat_status` values plus a handful of
 * Kotlin-side codes for things that happen before we reach C (asset
 * loading, ORT session creation). Mirrors iOS's `PhotosphereError.swift` so
 * cross-platform test harnesses can use the same labels.
 *
 * @property code Numeric code crossing the JNI boundary. Negative values
 *     come from the C ABI; positive values are Kotlin-originated.
 * @property messageText Thread-local message from `xfeat_last_error()`
 *     captured at the failure point, or a Kotlin-side description.
 */
sealed class PhotosphereError(
    val code: Int,
    val messageText: String,
) : RuntimeException(messageText) {
    class InvalidConfig(
        msg: String,
    ) : PhotosphereError(CODE_INVALID_CONFIG, msg)

    class AssetMissing(
        msg: String,
    ) : PhotosphereError(CODE_ASSET_MISSING, msg)

    class ModelLoadFailed(
        msg: String,
    ) : PhotosphereError(CODE_MODEL_LOAD_FAILED, msg)

    class ForwardFailed(
        msg: String,
    ) : PhotosphereError(CODE_FORWARD_FAILED, msg)

    class PreprocessFailed(
        msg: String,
    ) : PhotosphereError(CODE_PREPROCESS_FAILED, msg)

    class TooFewKeypoints(
        msg: String,
    ) : PhotosphereError(CODE_TOO_FEW_KEYPOINTS, msg)

    class TooFewMatches(
        msg: String,
    ) : PhotosphereError(CODE_TOO_FEW_MATCHES, msg)

    class DegenerateGeometry(
        msg: String,
    ) : PhotosphereError(CODE_DEGENERATE_GEOMETRY, msg)

    /** C ABI returned `XFEAT_ERR_NOT_IMPLEMENTED` — Stage 3/5/6 lands
     *  in a later milestone per AD-004. */
    class NotImplemented(
        msg: String,
    ) : PhotosphereError(CODE_NOT_IMPLEMENTED, msg)

    /** C ABI returned `XFEAT_ERR_NO_CACHED_REF` — the ref context was
     *  not bound via [PhotosphereRunner.cacheRef] before the caller asked for
     *  a cached-pose match. */
    class NoCachedRef(
        msg: String,
    ) : PhotosphereError(CODE_NO_CACHED_REF, msg)

    /** C ABI returned `XFEAT_ERR_SAME_CTX` — the caller passed the same
     *  runner as both live and ref to [PhotosphereRunner.poseVsCached]; Stage 5
     *  scratch would alias the ref descriptor buffer. Distinct runners
     *  are required. */
    class SameCtx(
        msg: String,
    ) : PhotosphereError(CODE_SAME_CTX, msg)

    class Internal(
        code: Int,
        msg: String,
    ) : PhotosphereError(code, msg)

    companion object {
        // Positive codes — Kotlin side only.
        const val CODE_INVALID_CONFIG: Int = 100
        const val CODE_ASSET_MISSING: Int = 101
        const val CODE_MODEL_LOAD_FAILED: Int = 102
        const val CODE_FORWARD_FAILED: Int = 103
        const val CODE_PREPROCESS_FAILED: Int = 104

        // Negative codes — mirror xfeat_errors.h verbatim.
        const val CODE_INVALID_ARG: Int = -1
        const val CODE_OUT_OF_MEMORY: Int = -2
        const val CODE_NOT_IMPLEMENTED: Int = -3
        const val CODE_TOO_FEW_KEYPOINTS: Int = -4
        const val CODE_TOO_FEW_MATCHES: Int = -5
        const val CODE_DEGENERATE_GEOMETRY: Int = -6
        const val CODE_SHAPE_MISMATCH: Int = -7
        const val CODE_UNSUPPORTED_FMT: Int = -8
        const val CODE_MODEL_CORRUPT: Int = -9

        // between -9 and -32 is intentional so later M6 codes can land
        // without disturbing the cache-ref block.
        const val CODE_NO_CACHED_REF: Int = -32
        const val CODE_SAME_CTX: Int = -33
        const val CODE_INTERNAL: Int = -99

        /** Construct the right subtype from a raw (code, msg) pair —
         *  the JNI layer calls this when a native function fails. */
        @JvmStatic
        fun fromCode(
            code: Int,
            msg: String,
        ): PhotosphereError =
            when (code) {
                CODE_INVALID_CONFIG -> InvalidConfig(msg)
                CODE_ASSET_MISSING -> AssetMissing(msg)
                CODE_MODEL_LOAD_FAILED -> ModelLoadFailed(msg)
                CODE_FORWARD_FAILED -> ForwardFailed(msg)
                CODE_PREPROCESS_FAILED -> PreprocessFailed(msg)
                CODE_NOT_IMPLEMENTED -> NotImplemented(msg)
                CODE_TOO_FEW_KEYPOINTS -> TooFewKeypoints(msg)
                CODE_TOO_FEW_MATCHES -> TooFewMatches(msg)
                CODE_DEGENERATE_GEOMETRY -> DegenerateGeometry(msg)
                CODE_NO_CACHED_REF -> NoCachedRef(msg)
                CODE_SAME_CTX -> SameCtx(msg)
                else -> Internal(code, msg)
            }
    }
}
