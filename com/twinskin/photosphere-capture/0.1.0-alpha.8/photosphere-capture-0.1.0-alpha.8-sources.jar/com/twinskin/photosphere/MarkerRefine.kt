package com.twinskin.photosphere

import java.nio.ByteBuffer

/**
 * Kotlin facade for the marker-refine C ABI
 * (`common/marker_finder/include/marker_api.h`). The C implementation
 * lives in `marker_refine_aruco.cpp` and is linked into
 * `libphotosphere_native.so` via `--whole-archive` so its strong symbol
 * overrides the weak NOT_IMPLEMENTED stub in `marker_finder_core`.
 *
 * No image pre-processing happens in Kotlin — the caller hands us a
 * grayscale byte buffer (Y-plane of a YUV_420_888 analysis frame) and
 * an ROI from the YOLO finder; OpenCV runs ArUco detection with sub-
 * pixel corner refinement inside C++ (same geometry + CLAHE policy as
 * dermatoo's `aruco_detector.cpp`).
 *
 * Ownership: the caller owns the gray buffer and the returned arrays;
 * the C side copies corner floats into a freshly-allocated FloatArray
 * per call.
 */
object MarkerRefine {
    /** Refinement result; null when no ArUco marker was found in the ROI. */
    data class Result(
        /** Sub-pixel corners in full-frame space: tl, tr, br, bl -> xy. */
        val corners: FloatArray,
        val id: Int,
        val confidence: Float,
    ) {
        init {
            require(corners.size == CORNERS_FLOAT_COUNT) {
                "corners must have $CORNERS_FLOAT_COUNT floats (4 corners × 2)"
            }
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is Result) return false
            if (!corners.contentEquals(other.corners)) return false
            if (id != other.id) return false
            return confidence == other.confidence
        }

        override fun hashCode(): Int {
            var h = corners.contentHashCode()
            h = 31 * h + id
            h = 31 * h + confidence.hashCode()
            return h
        }
    }

    /**
     * Run ArUco refine on a ROI of a Y-plane image.
     *
     * @param gray direct [ByteBuffer] holding an 8-bit Y plane, row-
     *     major, tightly packed (or with [rowStride] >= [width]).
     * @param width full-frame pixel width.
     * @param height full-frame pixel height.
     * @param rowStride bytes per row in [gray]; Camera2 readers often
     *     pad rows to 16-byte alignment.
     * @param roiX0 inclusive top-left x of the YOLO ROI.
     * @param roiY0 inclusive top-left y of the YOLO ROI.
     * @param roiX1 exclusive bottom-right x.
     * @param roiY1 exclusive bottom-right y.
     * @return refined marker or null when no decodable marker fits the ROI.
     * @throws PhotosphereError on malformed arguments or when the native
     *     extension is not linked (e.g. OpenCV build failure). The
     *     "ROI had no marker" case returns null — not an exception —
     *     because the caller will try the next frame.
     */
    fun aruco(
        gray: ByteBuffer,
        width: Int,
        height: Int,
        rowStride: Int,
        roiX0: Int,
        roiY0: Int,
        roiX1: Int,
        roiY1: Int,
    ): Result? {
        require(gray.isDirect) { "gray must be a direct ByteBuffer" }
        require(width > 0 && height > 0) { "width and height must be positive" }
        require(rowStride >= width) { "rowStride ($rowStride) must be >= width ($width)" }
        require(roiX1 > roiX0 && roiY1 > roiY0) { "ROI must have positive area" }

        val cornersOut = FloatArray(CORNERS_FLOAT_COUNT)
        val metaOut = FloatArray(META_FLOAT_COUNT)
        val rc =
            nativeMarkerRefineAruco(
                gray,
                width,
                height,
                rowStride,
                roiX0,
                roiY0,
                roiX1,
                roiY1,
                cornersOut,
                metaOut,
            )
        return when (rc) {
            STATUS_OK ->
                Result(
                    corners = cornersOut,
                    id = metaOut[0].toInt(),
                    confidence = metaOut[1],
                )
            STATUS_MARKER_NOT_FOUND -> null
            else -> throw PhotosphereError.fromCode(rc, "marker_refine_aruco rc=$rc")
        }
    }

    init {
        // Shares libphotosphere_native.so with PhotosphereRunner; the loadLibrary
        // call here is a no-op when PhotosphereRunner loaded it first. Soft-fail
        // on the host JVM so unit-test class-init doesn't blow up (matches the
        // pattern in PhotosphereRunner / PhotosphereSession / DwellTracker);
        // the first real JNI call will throw if loading actually failed.
        runCatching { System.loadLibrary("photosphere_native") }
    }

    /** Native returns 0 on OK, XFEAT_ERR_MARKER_NOT_FOUND (-11) for miss. */
    @JvmStatic private external fun nativeMarkerRefineAruco(
        gray: ByteBuffer,
        width: Int,
        height: Int,
        rowStride: Int,
        roiX0: Int,
        roiY0: Int,
        roiX1: Int,
        roiY1: Int,
        cornersOut: FloatArray,
        metaOut: FloatArray,
    ): Int

    const val CORNERS_FLOAT_COUNT: Int = 8
    const val META_FLOAT_COUNT: Int = 2
    private const val STATUS_OK: Int = 0
    private const val STATUS_MARKER_NOT_FOUND: Int = -11
}
