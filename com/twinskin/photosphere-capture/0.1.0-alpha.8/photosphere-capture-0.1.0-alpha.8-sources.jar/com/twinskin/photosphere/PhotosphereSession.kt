package com.twinskin.photosphere

import android.content.Context
import android.util.Log
import androidx.tracing.Trace
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Photosphere capture session: 1 reference frame + 16 orbit views.
 *
 * A [PhotosphereSession] holds two distinct [PhotosphereRunner] instances
 * internally — one for the reference (binds via [PhotosphereRunner.cacheRef]),
 * one for the live-pose loop (calls [PhotosphereRunner.poseVsCached] against
 * the ref). The split is required by the C ABI (`xfeat_match_and_pose_cached`
 * returns `XFEAT_ERR_SAME_CTX` if `live_ctx == ref_ctx`; see
 * `docs/ffi-contract.md` § xfeat_match_and_pose_cached).
 *
 * Auto-shutter (CL-041 § 4): on every successful live-pose update the
 * session decomposes the recovered rotation into `(tilt_mag, tilt_phi)`
 * via [PhotosphereMath.tiltFromRotation], enumerates the uncaptured
 * arms of the current round, picks the one with the smallest great-
 * circle distance, and drives an aiming state machine (`Aiming` →
 * `OnTarget` @ ≤ 3° → `Capturing` after 300 ms dwell → `Captured`). The
 * `OnTarget → Capturing` transition invokes [shutterCallback] — the
 * consumer returns the full-resolution JPEG bytes of the arm — after
 * which the session auto-commits the view. Ref capture remains user-
 * initiated ([captureReference]); only the 16 arms are auto-shuttered.
 *
 * Thread-safety: all public methods are safe to call from any thread;
 * internals serialise on a private `Dispatchers.Default.limitedParallelism(1)`
 * dispatcher. Must be constructed off the main thread — [create] performs
 * ORT session init which does disk I/O (~150 ms on XCover 5).
 *
 * Lifecycle:
 * ```
 *   create(shutterCallback = …) → captureReference
 *                               → N × enqueueLiveFrame     // auto-shutter
 *                               → finalize() → close()
 * ```
 * [close] is idempotent.
 *
 * Thread model mirrors the 2-photo path in [PhotosphereRunner]: the session's
 * dispatcher serialises the native calls; UI observers read [state] on
 * any thread; the CameraX analyser callback calls [enqueueLiveFrame]
 * and returns immediately (the method copies the gray buffer into a
 * session-owned direct ByteBuffer and hands off to the dispatcher).
 *
 * @property config The [PhotosphereConfig] the session was constructed with.
 * @property strings UI copy; defaults to [PhotosphereStrings.DEFAULT_EN].
 *     Integrators substitute their own per-language bundle.
 */
@Suppress("LongParameterList", "LargeClass")
class PhotosphereSession private constructor(
    private val refRunner: PhotosphereRunner,
    private val liveRunner: PhotosphereRunner,
    /**
     * Directory where [finalize] writes the ref (`ref.jpg` by
     * default, `ref.png` when [viewLossless] is `true`),
     * `view_*.{jpg|png}`,
     * and `index.json`. Exposed as a read-only `val` so consumers can drop
     * companion artefacts (e.g. the optional `capture.mp4` from the
     * T-4 video-recording overlay) into the same directory while the
     * session is in flight, before [finalize] runs. Mirrors iOS
     * `PhotosphereSession.sessionDir`.
     */
    val sessionDir: File,
    val config: PhotosphereConfig,
    val strings: PhotosphereStrings,
    private val deviceModel: String,
    private val shutterCallback: (suspend (Int) -> PhotosphereShutterResult?)?,
    private val nowNanos: () -> Long,
    private val onTargetDistanceDeg: Float,
    /**
     * Sensor-frame → display-frame phi rotation (degrees), subtracted
     * from raw `tilt_phi` before the picker and the published cursor
     * angle. Live-camera path passes 90° (landscape analyser, portrait
     * UI); synthetic-replay frames ship pre-rotated and pass 0°.
     */
    private val phiOffsetDeg: Float,
    /**
     * When `true`, views write as PNG (`view_*.png`) and the ref as
     * `ref.png`; when `false` (default), JPEG. The caller pre-encodes
     * in the matching format; the session decides the on-disk
     * extension and the `index.json` field only.
     */
    private val viewLossless: Boolean,
    /**
     * DEBUG-only QA bypass for the tilt gate. When `true`, the
     * `magInWindow` and `phiInWindow` guards in [onPoseTick] are
     * forced on; every other safety check (image quality, MIN_INLIERS,
     * shutter callback) stays live. SDK consumers must never opt in.
     */
    private val qaDisableTiltGate: Boolean,
    /**
     * JPEG compression applied at [finalize] time before writing images
     * to disk. Default [PhotosphereCompressionConfig.Default] (enabled,
     * 700 KB target). Pass [PhotosphereCompressionConfig.Disabled] to
     * write bytes verbatim (original camera quality). PNG views
     * (viewLossless = true) are always passed through unchanged.
     */
    private val compressionConfig: PhotosphereCompressionConfig = PhotosphereCompressionConfig.Default,
) : Closeable {
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val dispatcher = Dispatchers.Default.limitedParallelism(1)

    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + dispatcher)

    // Separate scope so the shutter doesn't contend with the
    // analyser-tick ML dispatcher; SupervisorJob isolates per-arm
    // shutter failures from the parent session scope.
    private val shutterScope: CoroutineScope =
        CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Wall-clock dwell authority. Constructed lazily on first
    // ref-bind so a failure between `create` and `captureReference`
    // doesn't leak the C handle.
    private var dwellTracker: DwellTracker? = null

    // Wall-clock dwell poller. Decouples the shutter trigger from
    // the analyser-tick cadence.
    private var dwellPollerJob: kotlinx.coroutines.Job? = null

    // Latest analyser-tick snapshot the poller reads to decide which
    // arm to fire. Atomic so the poller (on Dispatchers.Default) sees
    // it without going through the session dispatcher.
    private val currentDwellTarget = AtomicReference<DwellTargetSnapshot?>(null)

    // Guard against firing a second shutter while the previous
    // takePicture is still in-flight on the camera-API roundtrip.
    @Volatile private var shutterInFlight: Boolean = false

    // Count of arm captures whose shutterCallback returned null, threw,
    // or produced empty bytes. Surfaced at finalize for an
    // auto-skip-with-notification UX.
    private val failedArmCount = AtomicLong(0L)

    // The live ByteBuffer re-used across every analyser frame. Allocated
    // once per session; R-P3 sustainability requires zero per-frame heap
    // growth on the hot path. Producer writes under `liveBufferLock`.
    private val liveBuffer: ByteBuffer =
        ByteBuffer
            .allocateDirect(config.height * config.width * Float.SIZE_BYTES)
            .order(ByteOrder.nativeOrder())

    // Consumer-owned snapshot. `computeLivePose` copies `liveBuffer` into
    // here under `liveBufferLock`, then hands this buffer to JNI without
    // holding the lock. Decouples the JNI duration from the producer:
    // the analyser thread is parked for ~1 ms (the brief snapshot copy)
    // instead of the full ~50–200 ms inference. Critical for the
    // synthetic-replay path, where the producer (MediaExtractor decode
    // loop) runs as fast as the consumer drains.
    private val liveBufferSnapshot: ByteBuffer =
        ByteBuffer
            .allocateDirect(config.height * config.width * Float.SIZE_BYTES)
            .order(ByteOrder.nativeOrder())

    // Intrinsics scratch — reused to avoid a per-frame `FloatArray(9)`.
    private val liveIntrinsicsScratch: FloatArray = FloatArray(PhotosphereRunner.INTRINSICS_SIZE)

    // Most-recent live frame pending processing. The analyser thread writes;
    // the dispatcher reads. Replaces-in-place means we always pose-estimate
    // the freshest frame (match ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).
    private val pendingFrame = AtomicReference<PendingLiveFrame?>(null)
    private val dispatchMutex = Mutex()
    // Guards `liveBuffer` / `liveIntrinsicsScratch` writes (producer) and
    // the snapshot copy (consumer). Held only for the duration of the
    // in-memory memcpy — never across the JNI call. JVM monitor is fine
    // because no suspension point sits inside any synchronized block.
    private val liveBufferLock = Any()

    // CONFLATED wake-up channel for the live-pose consumer loop. The producer
    // (enqueueLiveFrame) sends Unit on every new analyser frame; the CONFLATED
    // capacity coalesces bursts into one pending signal so the consumer always
    // picks up the freshest pendingFrame. Zero per-frame coroutine allocations
    // in steady state (previously one scope.launch per frame = ~30/sec).
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val liveFrameSignal = Channel<Unit>(Channel.CONFLATED)

    init {
        // Single consumer: wakes on liveFrameSignal, grabs the latest pending
        // frame under dispatchMutex so it serialises with cancel(). The
        // CONFLATED channel guarantees at most one queued wake-up regardless of
        // how many frames arrive while runLivePose is running.
        scope.launch {
            for (_signal in liveFrameSignal) {
                dispatchMutex.withLock {
                    if (closed) return@withLock
                    val frame = pendingFrame.getAndSet(null) ?: return@withLock
                    runLivePose(frame)
                }
            }
        }
    }

    // Counts analyser frames replaced in-place because the dispatcher
    // was busy (session-level STRATEGY_KEEP_ONLY_LATEST). Useful for
    // correlating live-loop starvation with shutter windows in traces.
    private val frameInFlightSkipCount = AtomicLong(0L)

    // Monotonic cookie for the per-arm-cycle async signpost. Unique
    // per (Aiming → Capturing) pair so a parallel arm change can't
    // merge intervals in the trace viewer.
    private val armCycleCookie = AtomicLong(0L)
    private var activeArmCycleCookie: Int = -1
    private var activeArmCycleLabel: String? = null

    // Persisted artefacts — populated as the session progresses; written
    // to disk at finalize().
    private val capturedViews = mutableMapOf<Int, CapturedView>()

    // pose_log.json ships in release; frame_log.jsonl is DEBUG-gated
    // at every call site.
    private var poseLogger: PhotospherePosePerCaptureLogger? = null
    private var refPersisted: RefRecord? = null

    private val stateFlow: MutableStateFlow<PhotosphereState> =
        MutableStateFlow(
            PhotosphereState(
                stage = PhotosphereState.Stage.RefCapture,
                currentRound = 1,
                capturedArms = emptySet(),
                currentPose = null,
                currentAzEstimate = null,
                currentTiltMagDeg = null,
                currentError = null,
            ),
        )

    /** Observable session state. Collect off the main thread for UI updates. */
    val state: StateFlow<PhotosphereState> = stateFlow.asStateFlow()

    @Volatile private var closed: Boolean = false

    @Volatile private var refBound: Boolean = false

    /**
     * Opportunistic-capture toggle. When `true`, the picker selects
     * across every uncaptured arm regardless of the scheduled round;
     * when `false`, the round-restricted picker is primary and the
     * global picker is the exhaustion fallback. Mutate only via
     * [setFreeCaptureMode] so writes serialise on the dispatcher.
     */
    @Volatile private var freeCaptureMode: Boolean = true

    suspend fun setFreeCaptureMode(enabled: Boolean) {
        withContext(dispatcher) {
            freeCaptureMode = enabled
        }
    }

    /**
     * Bind the reference frame.
     *
     * Runs backbone + postprocess on [refBuffer], caches the reference
     * features inside the ref runner, and persists [fullResJPEG] to the
     * session directory. After this returns, [enqueueLiveFrame] may be
     * called against live frames; the state advances to
     * [PhotosphereState.Stage.RoundWaiting] with `round = 1` and
     * the auto-shutter state machine starts observing pose updates.
     *
     * @param refBuffer grayscale float32 buffer, length [PhotosphereConfig.height]
     *     `*` [PhotosphereConfig.width], range `[0, 255]`. Caller retains ownership;
     *     the session copies as needed.
     * @param intrinsics row-major 9-float K for the reference frame.
     * @param fullResJPEG bytes of the full-res ref JPEG. Persisted at
     *     [finalize] (buffered until then so a cancelled session leaves
     *     no partial files).
     * @param refImageWidth pixel width of the encoded ref image as it
     *     will land on disk (CL-075). Used to derive `K_full_res` in
     *     `index.json` — the analyser-space `K` is scaled by
     *     `refImageWidth / config.width` along the x axis. Defaults to
     *     [PhotosphereConfig.width] so synthetic-scene and unit-test callers
     *     that feed analyser-resolution refs see `K_full_res == K`.
     * @param refImageHeight pixel height of the encoded ref image; same
     *     contract as [refImageWidth] but along the y axis (scaled by
     *     `refImageHeight / config.height`). Defaults to
     *     [PhotosphereConfig.height].
     *
     * @throws PhotosphereError.TooFewKeypoints if the backbone returned < 4
     *     keypoints on the ref frame (ABI `XFEAT_ERR_TOO_FEW_MATCHES`
     *     from `xfeat_bind_cached_ref`).
     * @throws PhotosphereError on any other pipeline failure.
     */
    suspend fun captureReference(
        refBuffer: FloatArray,
        intrinsics: FloatArray,
        fullResJPEG: ByteArray,
        refImageWidth: Int = config.width,
        refImageHeight: Int = config.height,
    ) {
        require(refBuffer.size == config.height * config.width) {
            "refBuffer length must equal height*width (= ${config.height * config.width})"
        }
        require(intrinsics.size == PhotosphereRunner.INTRINSICS_SIZE) {
            "intrinsics must have ${PhotosphereRunner.INTRINSICS_SIZE} floats"
        }
        require(refImageWidth > 0 && refImageHeight > 0) {
            "ref image dimensions must be positive (got ${refImageWidth}x$refImageHeight)"
        }
        withContext(dispatcher) {
            check(!closed) { "PhotosphereSession is closed" }
            // The per-capture sidecar logger needs a session dir
            // before any frame lands, so we set up here rather than
            // at finalize. Idempotent.
            setupSessionDirectoryAndLoggerIfNeeded()
            refRunner.cacheRef(refBuffer, intrinsics)
            refBound = true
            refPersisted =
                RefRecord(
                    jpegBytes = fullResJPEG.copyOf(),
                    intrinsics = intrinsics.copyOf(),
                    imageWidth = refImageWidth,
                    imageHeight = refImageHeight,
                )
            updateState { current ->
                current.copy(stage = PhotosphereState.Stage.RoundWaiting(round = 1))
            }
            // Start the dwell tracker only after cacheRef succeeds so
            // a throw from captureReference can't leak the C handle.
            ensureDwellPollerStarted()
            Log.i(
                LOG_TAG,
                "ref bound; session=${sessionDir.name} refImage=${refImageWidth}x$refImageHeight",
            )
        }
    }

    /**
     * Lazily start the dwell tracker + poller. Idempotent. The poller
     * runs on [shutterScope], not the session dispatcher, so its
     * `delay` cannot block analyser-tick ML work.
     */
    private fun ensureDwellPollerStarted() {
        if (dwellTracker != null) return
        val budget = PhotosphereMath.dwellMs.toInt()
        val tracker = DwellTracker(minDwellMs = budget)
        dwellTracker = tracker
        dwellPollerJob =
            shutterScope.launch {
                runDwellPoller(tracker)
            }
        Log.i(LOG_TAG, "dwell poller started budget=${budget}ms")
    }

    /**
     * Poll the dwell tracker on a fixed `delay` cadence and fire the
     * shutter once both the budget has elapsed and the failure-mode
     * guard clears (no FAIL observed in the prior
     * [FAILURE_MODE_GUARD_MS]). Only one shutter in flight at a time;
     * commit work hops to the session dispatcher for serialisation
     * against [capturedViews] / state updates.
     */
    private suspend fun runDwellPoller(tracker: DwellTracker) {
        while (!closed) {
            kotlinx.coroutines.delay(DWELL_POLL_PERIOD_MS)
            if (closed) return
            val target = readyDwellTarget(tracker) ?: continue
            shutterInFlight = true
            try {
                fireShutterForTarget(target)
            } finally {
                shutterInFlight = false
            }
        }
    }

    /**
     * Returns the [DwellTargetSnapshot] when all four gates pass
     * (no in-flight shutter, dwell budget elapsed, failure-mode guard
     * clear, latest snapshot still OnTarget); `null` otherwise.
     */
    private fun readyDwellTarget(tracker: DwellTracker): DwellTargetSnapshot? {
        if (shutterInFlight) return null
        val nowNs = android.os.SystemClock.elapsedRealtimeNanos()
        // Reject if the operator left the OnTarget window in the
        // prior 100 ms — otherwise the wall-clock timer can fire on
        // a stale OnTarget observation while an in-flight analyser
        // tick is about to observe a FAIL_PHI.
        val msSinceFail = tracker.msSinceOffTarget(nowNs)
        val budgetElapsed = tracker.passedAt(nowNs)
        val guardClear = msSinceFail >= FAILURE_MODE_GUARD_MS
        val target = currentDwellTarget.get()
        val ready = budgetElapsed && guardClear && target != null && target.onTarget
        if (!ready) {
            if (budgetElapsed && !guardClear) {
                Log.d(
                    LOG_TAG,
                    "dwell-pass rejected by failure-mode guard ms_since_off=$msSinceFail",
                )
            }
            return null
        }
        return target
    }

    /**
     * Hops to the session dispatcher so the [capturedViews] mutation
     * + state update serialise against analyser-tick access. The
     * dwell tracker is reset BEFORE the shutter callback so the next
     * analyser tick (still-OnTarget mid-shutter) starts a fresh
     * budget on the next arm rather than re-firing on this one.
     */
    private suspend fun fireShutterForTarget(target: DwellTargetSnapshot) {
        withContext(dispatcher) {
            if (closed) return@withContext
            if (capturedViews.containsKey(target.viewIndex)) return@withContext
            val capturingStage =
                PhotosphereState.Stage.Capturing(
                    round = target.round,
                    targetArm = target.arm,
                )
            updateState { it.copy(stage = capturingStage) }
            updateArmCycleTrace(capturingStage)
            dwellTracker?.observeOffTarget(
                android.os.SystemClock.elapsedRealtimeNanos(),
            )
            currentDwellTarget.set(null)
            commitAfterShutter(target.round, target.arm)
        }
    }

    /**
     * Number of arm captures whose shutter callback failed (returned
     * null, threw, or produced empty bytes). Lock-free; safe from any
     * thread.
     */
    fun getFailedArmCount(): Long = failedArmCount.get()

    /**
     * Non-blocking hand-off of an analyser frame. Copies the buffer into
     * a session-owned direct ByteBuffer and returns immediately; pose
     * result surfaces via [state] on the next dispatcher turn.
     *
     * @param grayBuffer grayscale float32 direct ByteBuffer, capacity
     *     `>= height*width*4` bytes.
     * @param intrinsics row-major 9-float K for this live frame.
     * @param timestampNs analyser-provided timestamp, kept for telemetry.
     */
    fun enqueueLiveFrame(
        grayBuffer: ByteBuffer,
        intrinsics: FloatArray,
        timestampNs: Long,
    ) {
        if (closed) return
        if (!refBound) return
        require(intrinsics.size == PhotosphereRunner.INTRINSICS_SIZE) {
            "intrinsics must have ${PhotosphereRunner.INTRINSICS_SIZE} floats"
        }
        val expectedBytes = config.height * config.width * Float.SIZE_BYTES
        require(grayBuffer.isDirect) { "grayBuffer must be a direct ByteBuffer" }
        require(grayBuffer.capacity() >= expectedBytes) {
            "grayBuffer capacity must be >= $expectedBytes bytes"
        }
        // Copy out on the caller's thread — tiny (~1.2 MB) memcpy, keeps
        // the analyser callback non-blocking without retaining the
        // CameraX-owned buffer past return.
        val srcView = grayBuffer.duplicate().order(ByteOrder.nativeOrder())
        srcView.position(0)
        srcView.limit(expectedBytes)
        // Brief JVM monitor while we memcpy ~1.2 MB into `liveBuffer`
        // and the intrinsics into the scratch. Held for milliseconds at
        // most — the consumer takes the SAME lock only to snapshot the
        // buffer (not for the JNI call), so the analyser thread is
        // never parked on inference. This is the critical property for
        // the synthetic-replay path where the producer runs flat-out.
        synchronized(liveBufferLock) {
            liveBuffer.clear()
            liveBuffer.put(srcView)
            liveBuffer.position(0)
            System.arraycopy(intrinsics, 0, liveIntrinsicsScratch, 0, intrinsics.size)
        }
        val replaced = pendingFrame.getAndSet(PendingLiveFrame(timestampNs))
        if (replaced != null) {
            val skipped = frameInFlightSkipCount.incrementAndGet()
            Trace.beginSection(TRACE_FRAME_IN_FLIGHT_SKIP)
            Trace.endSection()
            if (skipped % FRAME_IN_FLIGHT_LOG_EVERY == 0L) {
                Log.d(LOG_TAG, "frame in-flight skip count=$skipped")
            }
        }
        // Wake the single consumer loop. The CONFLATED channel absorbs bursts:
        // if inference is running and N frames arrive, only one signal queues
        // (the consumer picks the latest pendingFrame on wake).
        liveFrameSignal.trySend(Unit)
    }

    /** Total analyser frames replaced in-place since session creation. */
    fun getFrameInFlightSkipCount(): Long = frameInFlightSkipCount.get()

    private suspend fun runLivePose(frame: PendingLiveFrame) {
        if (closed || !refBound) return
        val stage = stateFlow.value.stage
        if (stage is PhotosphereState.Stage.RefCapture) return
        val outcome = computeLivePose()
        applyLiveOutcome(outcome, frame)
        // No recursive drain — the Channel(CONFLATED) consumer loop in init
        // handles the next frame when the signal arrives.
    }

    /**
     * Debug-only synthetic pose injection. Feeds a pre-computed (R, t)
     * into the state machine as if it had emerged from
     * [PhotosphereRunner.poseVsCached]. Three layers of guardrails
     * (BuildConfig.DEBUG check, debug-only JNI symbol, `…ForTest`
     * naming) keep this out of release builds.
     */
    suspend fun enqueueSyntheticPoseForTest(
        arm: Int,
        rotation: FloatArray,
        translation: FloatArray,
    ) {
        check(BuildConfig.DEBUG) {
            "enqueueSyntheticPoseForTest is debug-only; release builds must not call it"
        }
        require(rotation.size == PhotospherePose.ROTATION_SIZE) {
            "rotation must have size ${PhotospherePose.ROTATION_SIZE}"
        }
        require(translation.size == PhotospherePose.TRANSLATION_SIZE) {
            "translation must have size ${PhotospherePose.TRANSLATION_SIZE}"
        }
        val rc = nativeEnqueueSyntheticPoseForTest(arm, rotation, translation)
        require(rc == 0) { "nativeEnqueueSyntheticPoseForTest rc=$rc (arm=$arm)" }
        withContext(dispatcher) {
            if (closed || !refBound) return@withContext
            val stage = stateFlow.value.stage
            val terminal =
                stage is PhotosphereState.Stage.Done ||
                    stage is PhotosphereState.Stage.Aborted ||
                    stage is PhotosphereState.Stage.RefCapture
            if (terminal) return@withContext
            val (tiltMag, tiltPhi) = PhotosphereMath.tiltFromRotation(rotation)
            val pose =
                PhotospherePose(
                    rotation = rotation.copyOf(),
                    translation = translation.copyOf(),
                    numMatches = SYNTHETIC_POSE_SENTINEL_MATCHES,
                    numInliers = SYNTHETIC_POSE_SENTINEL_INLIERS,
                    confidence = 1.0f,
                )
            onPoseTick(pose, tiltMag, tiltPhi, nowNanos())
        }
    }

    /**
     * Emit per-arm-cycle async signpost transitions. Begins an
     * `xfeat-photosphere-arm-cycle` interval on the first Aiming
     * for a given (round, arm) and ends it when the target changes
     * or the session reaches a terminal stage. A session-monotonic
     * cookie keeps a rapid arm change from merging two intervals
     * in the trace viewer.
     */
    private fun updateArmCycleTrace(nextStage: PhotosphereState.Stage) {
        val (nextRound, nextArm) =
            when (nextStage) {
                is PhotosphereState.Stage.Aiming -> nextStage.round to nextStage.targetArm
                is PhotosphereState.Stage.OnTarget -> nextStage.round to nextStage.targetArm
                is PhotosphereState.Stage.Capturing -> nextStage.round to nextStage.targetArm
                else -> null to null
            }
        val nextLabel =
            if (nextRound != null && nextArm != null) {
                "r${nextRound}a$nextArm"
            } else {
                null
            }
        // No change → keep the existing async section open.
        if (nextLabel == activeArmCycleLabel) return
        // Close the prior interval (if any) before opening a new one.
        val prevCookie = activeArmCycleCookie
        if (prevCookie >= 0) {
            Trace.endAsyncSection(TRACE_ARM_CYCLE, prevCookie)
        }
        if (nextLabel != null) {
            val cookie = (armCycleCookie.incrementAndGet() and Int.MAX_VALUE.toLong()).toInt()
            Trace.beginAsyncSection("$TRACE_ARM_CYCLE/$nextLabel", cookie)
            activeArmCycleCookie = cookie
            activeArmCycleLabel = nextLabel
        } else {
            activeArmCycleCookie = -1
            activeArmCycleLabel = null
        }
    }

    /** Runs the native pose-vs-cached call and classifies the result. */
    private var perfPoseFrameCount = 0
    private val perfTimingsMs = DoubleArray(4)

    private suspend fun computeLivePose(): LiveOutcome {
        return try {
            val perfT0 = System.nanoTime()
            // Snapshot `liveBuffer` + intrinsics under `liveBufferLock`
            // (brief, ~1 ms for the 1.2 MB direct→direct memcpy) and
            // hand the snapshot to JNI WITHOUT holding the lock. The
            // producer takes the same monitor only to memcpy the next
            // frame, so the analyser thread is never parked on
            // inference. This decouples the synthetic-replay decode
            // loop from the per-frame inference cost.
            //
            // Torn-read protection: while the consumer copies, the
            // producer cannot enter the synchronized block — so the
            // snapshot is always a complete frame. Once the snapshot
            // is taken, the producer is free to overwrite `liveBuffer`;
            // the JNI call reads `liveBufferSnapshot`, which is
            // consumer-private.
            val intrinsicsSnapshot: FloatArray
            synchronized(liveBufferLock) {
                liveBufferSnapshot.clear()
                liveBuffer.position(0)
                liveBufferSnapshot.put(liveBuffer)
                liveBufferSnapshot.position(0)
                intrinsicsSnapshot = liveIntrinsicsScratch.copyOf()
            }
            val pose = liveRunner.poseVsCachedDirect(
                refRunner, liveBufferSnapshot, intrinsicsSnapshot, perfTimingsMs,
            )
            val perfT1 = System.nanoTime()
            val frameIdx = perfPoseFrameCount++
            if (frameIdx < 2 || frameIdx % 30 == 0) {
                Log.i(
                    "sdk-pose-perf",
                    "frame=$frameIdx native=${(perfT1 - perfT0) / 1_000_000L}ms" +
                        " fwd=${perfTimingsMs[0].toLong()}ms" +
                        " pp=${perfTimingsMs[1].toLong()}ms" +
                        " match=${perfTimingsMs[2].toLong()}ms" +
                        " ep=${liveRunner.actualExecutionProvider}",
                )
            }
            LiveOutcome.Success(pose)
        } catch (e: PhotosphereError.DegenerateGeometry) {
            Log.d(LOG_TAG, "live pose degenerate: ${e.messageText}")
            LiveOutcome.Recoverable(error = null)
        } catch (e: PhotosphereError.TooFewMatches) {
            Log.d(LOG_TAG, "live pose too few matches: ${e.messageText}")
            val err =
                if (e.messageText.contains("inlier", ignoreCase = true)) {
                    PhotosphereSessionError.BaselineTooNarrow(0)
                } else {
                    PhotosphereSessionError.MarkerLost
                }
            LiveOutcome.Recoverable(error = err)
        } catch (e: PhotosphereError) {
            Log.w(LOG_TAG, "live pose error: ${e.messageText}", e)
            LiveOutcome.Fatal
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "live pose threw", t)
            LiveOutcome.Fatal
        }
    }

    private suspend fun applyLiveOutcome(
        outcome: LiveOutcome,
        frame: PendingLiveFrame,
    ) {
        when (outcome) {
            is LiveOutcome.Success -> {
                val pose = outcome.pose
                val (tiltMag, tiltPhi) = PhotosphereMath.tiltFromRotation(pose.rotation)
                onPoseTick(pose, tiltMag, tiltPhi, frame.timestampNs)
            }
            is LiveOutcome.Recoverable -> {
                updateState {
                    it.copy(
                        currentPose = null,
                        currentTiltMagDeg = null,
                        currentError = outcome.error,
                    )
                }
                logFrame(
                    magDeg = null,
                    phiDeg = null,
                    inliers = null,
                    gate = recoverableGateLabel(outcome.error),
                    arm = null,
                )
            }
            is LiveOutcome.Fatal ->
                logFrame(
                    magDeg = null,
                    phiDeg = null,
                    inliers = null,
                    gate = "ERR_INTERNAL",
                    arm = null,
                )
        }
    }

    /**
     * Map a recoverable [PhotosphereSessionError] (or `null` for
     * degenerate geometry) to the cross-platform gate vocabulary
     * consumed by `frame_log.jsonl`.
     */
    private fun recoverableGateLabel(error: PhotosphereSessionError?): String =
        when (error) {
            null -> "ERR_DEGENERATE"
            is PhotosphereSessionError.BaselineTooNarrow -> "ERR_BASELINE"
            is PhotosphereSessionError.MarkerLost -> "ERR_MARKER_LOST"
            is PhotosphereSessionError.ThermalThrottled -> "ERR_THERMAL"
            is PhotosphereSessionError.FullResCaptureFailed -> "ERR_CAPTURE"
            is PhotosphereSessionError.AssetDigestMismatch -> "ERR_DIGEST"
            is PhotosphereSessionError.SessionCancelled -> "ERR_CANCELLED"
        }

    /**
     * State-machine driver. Picks the nearest uncaptured arm; enters
     * OnTarget at `distance ≤ onTargetDistanceDeg`; the wall-clock
     * dwell poller fires the shutter once the dwell budget elapses.
     * No-op for Capturing / RoundComplete / Done / Aborted.
     */
    private suspend fun onPoseTick(
        pose: PhotospherePose,
        tiltMag: Float,
        tiltPhi: Float,
        timestampNs: Long,
    ) {
        val current = stateFlow.value
        val stage = current.stage
        val correctedPhi = applyPhiOffset(tiltPhi, phiOffsetDeg)
        val pick =
            selectTargetArm(
                currentRound = current.currentRound,
                capturedArms = current.capturedArms,
                tiltMag = tiltMag,
                tiltPhi = correctedPhi,
            )
        if (pick == null) {
            handleRoundDone(pose, tiltMag, correctedPhi)
            // No valid picker target: clear the dwell tracker so a
            // stale OnTarget observation from the prior tick cannot
            // fire the poller.
            currentDwellTarget.set(null)
            dwellTracker?.observeOffTarget(nowNanos())
            return
        }
        val rawMagInWindow =
            tiltMag >= PhotosphereMath.tiltMinMagDeg &&
                tiltMag <= PhotosphereMath.tiltMaxMagDeg
        val rawPhiInWindow = pick.distanceDeg <= onTargetDistanceDeg
        val magInWindow = rawMagInWindow || qaDisableTiltGate
        val phiInWindow = rawPhiInWindow || qaDisableTiltGate
        val onTarget = magInWindow && phiInWindow
        val now = nowNanos()
        // Drive the dwell using the picker's own (round, arm), not
        // the scheduled `current.currentRound`: under freeCaptureMode
        // the global picker may return an arm in any round (including
        // bonus 5..8), and committing under the scheduled round
        // resolves the wrong view_index.
        val nextStage =
            PhotosphereMath.nextAimingStage(
                stage = stage,
                round = pick.round,
                targetArm = pick.arm,
                onTarget = onTarget,
                nowNanos = now,
            )
        updateState {
            it.copy(
                stage = nextStage,
                currentPose = pose,
                currentAzEstimate = correctedPhi,
                currentTiltMagDeg = tiltMag,
                currentError = null,
                // Surface the picker's great-circle distance so the
                // screen-edge proximity overlay can fade between
                // transparent / amber / green.
                currentTargetDistanceDeg = pick.distanceDeg,
            )
        }
        emitOnPoseTickFrameLog(
            tiltMag = tiltMag,
            correctedPhi = correctedPhi,
            inliers = pose.numInliers,
            viewIndex = pick.viewIndex,
            onTarget = onTarget,
            magInWindow = magInWindow,
            phiInWindow = phiInWindow,
        )
        updateArmCycleTrace(nextStage)
        feedDwellTracker(pick = pick, onTarget = onTarget, now = now)
    }

    /**
     * Feed the wall-clock dwell tracker and publish the latest
     * analyser-tick observation for the poller. Decoupling the
     * shutter trigger from [onPoseTick] is the load-bearing fix that
     * stops a slow analyser tick from capping per-arm wall-clock at
     * the next-tick boundary.
     */
    private fun feedDwellTracker(
        pick: PhotosphereMath.ArmPick,
        onTarget: Boolean,
        now: Long,
    ) {
        currentDwellTarget.set(
            DwellTargetSnapshot(
                round = pick.round,
                arm = pick.arm,
                viewIndex = pick.viewIndex,
                onTarget = onTarget,
            ),
        )
        val tracker = dwellTracker ?: return
        if (onTarget) {
            tracker.observeOnTarget(now)
        } else {
            tracker.observeOffTarget(now)
        }
    }

    /**
     * Round-done branch of [onPoseTick]: every uncaptured arm has
     * been exhausted (or filtered by the active picker). Surfaces
     * the pose + cursor and emits a `ROUND_DONE` frame log line.
     */
    private fun handleRoundDone(
        pose: PhotospherePose,
        tiltMag: Float,
        correctedPhi: Float,
    ) {
        updateState {
            it.copy(
                currentPose = pose,
                currentAzEstimate = correctedPhi,
                currentTiltMagDeg = tiltMag,
                currentError = null,
                // No picker → no proximity signal; the overlay
                // orchestrator clears on null.
                currentTargetDistanceDeg = null,
            )
        }
        logFrame(
            magDeg = tiltMag,
            phiDeg = correctedPhi,
            inliers = pose.numInliers,
            gate = "ROUND_DONE",
            arm = null,
        )
    }

    /**
     * Emit a per-frame `frame_log.jsonl` line with the cross-platform
     * gate vocabulary (`PASS` / `FAIL_MAG_PHI` / `FAIL_MAG_LOW` /
     * `FAIL_MAG_HIGH` / `FAIL_PHI`).
     */
    @Suppress("LongParameterList")
    private fun emitOnPoseTickFrameLog(
        tiltMag: Float,
        correctedPhi: Float,
        inliers: Int,
        viewIndex: Int,
        onTarget: Boolean,
        magInWindow: Boolean,
        phiInWindow: Boolean,
    ) {
        val gateLabel =
            when {
                onTarget -> "PASS"
                !magInWindow && !phiInWindow -> "FAIL_MAG_PHI"
                !magInWindow && tiltMag < PhotosphereMath.tiltMinMagDeg -> "FAIL_MAG_LOW"
                !magInWindow -> "FAIL_MAG_HIGH"
                else -> "FAIL_PHI"
            }
        logFrame(
            magDeg = tiltMag,
            phiDeg = correctedPhi,
            inliers = inliers,
            gate = gateLabel,
            arm = viewIndex,
        )
    }

    /**
     * Pick the next target arm. When [freeCaptureMode] is true the
     * global picker is primary and the round-restricted picker is
     * defensive; when false, the round-restricted picker is primary
     * with the global picker as the exhaustion fallback so the
     * operator never stalls when the current round runs out of arms.
     */
    private fun selectTargetArm(
        currentRound: Int,
        capturedArms: Set<Int>,
        tiltMag: Float,
        tiltPhi: Float,
    ): PhotosphereMath.ArmPick? {
        val round0 = currentRound - 1
        return if (freeCaptureMode) {
            PhotosphereMath.pickTargetArmGlobal(
                capturedGlobalIndices = capturedArms,
                measuredMagDeg = tiltMag,
                measuredPhiDeg = tiltPhi,
            ) ?: PhotosphereMath.pickTargetArm(
                round0 = round0,
                capturedGlobalIndices = capturedArms,
                measuredMagDeg = tiltMag,
                measuredPhiDeg = tiltPhi,
            )
        } else {
            PhotosphereMath.pickTargetArm(
                round0 = round0,
                capturedGlobalIndices = capturedArms,
                measuredMagDeg = tiltMag,
                measuredPhiDeg = tiltPhi,
            ) ?: PhotosphereMath.pickTargetArmGlobal(
                capturedGlobalIndices = capturedArms,
                measuredMagDeg = tiltMag,
                measuredPhiDeg = tiltPhi,
            )
        }
    }

    /**
     * Invoke [shutterCallback] and commit the returned JPEG as the
     * view for `(round, arm)`. On failure the stage falls back to
     * `Aiming` so the operator can retry the same arm.
     */
    private suspend fun commitAfterShutter(
        round: Int,
        arm: Int,
    ) {
        val cb =
            shutterCallback ?: run {
                Log.w(LOG_TAG, "Capturing entered with no shutterCallback; staying in Capturing")
                return
            }
        Trace.beginSection(TRACE_SHUTTER)
        val result =
            try {
                runCatching { cb.invoke(arm) }
                    .onFailure { Log.w(LOG_TAG, "shutterCallback threw for arm=$arm", it) }
                    .getOrNull()
            } finally {
                Trace.endSection()
            }
        if (result == null || result.bytes.isEmpty()) {
            // Auto-skip-with-notification: arm stays uncaptured, UI
            // re-enters Aiming, counter is surfaced at finalize.
            failedArmCount.incrementAndGet()
            updateState {
                it.copy(
                    stage = PhotosphereState.Stage.Aiming(round = round, targetArm = arm),
                    currentError = PhotosphereSessionError.FullResCaptureFailed(null),
                )
            }
            return
        }
        commitCurrentView(
            targetArm = PhotosphereTargetArm(round = round, arm = arm),
            fullResJPEG = result.bytes,
            sensor = result.sensor,
            captureStartedNs = result.captureStartedNs,
            captureCallReturnedNs = result.captureCallReturnedNs,
        )
    }

    private sealed class LiveOutcome {
        data class Success(
            val pose: PhotospherePose,
        ) : LiveOutcome()

        data class Recoverable(
            val error: PhotosphereSessionError?,
        ) : LiveOutcome()

        data object Fatal : LiveOutcome()
    }

    /**
     * Commit the current arm as `CAPTURED`. Idempotent — calling twice
     * on the same `(round, arm)` is a no-op. Normally driven by the
     * state machine; direct callers are instrumentation tests.
     *
     * @param captureStartedNs monotonic-clock nanoseconds sampled by
     *     the camera adapter immediately before
     *     `ImageCapture.takePicture`. Clock source must match
     *     [captureCallReturnedNs] for per-arm latency math
     *     (boot-relative, same as `SENSOR_TIMESTAMP`).
     * @param captureCallReturnedNs sampled as the FIRST statement of
     *     `OnImageCapturedCallback.onCaptureSuccess`, before any
     *     disk-write step.
     *
     * @throws PhotosphereError.NoCachedRef if the reference was never bound.
     */
    suspend fun commitCurrentView(
        targetArm: PhotosphereTargetArm,
        fullResJPEG: ByteArray,
        sensor: PhotosphereViewSensor? = null,
        captureStartedNs: Long? = null,
        captureCallReturnedNs: Long? = null,
    ) {
        withContext(dispatcher) {
            check(!closed) { "PhotosphereSession is closed" }
            if (!refBound) {
                throw PhotosphereError.NoCachedRef("captureReference must precede commitCurrentView")
            }
            val idx = globalArmIndex(targetArm)
            if (capturedViews.containsKey(idx)) return@withContext
            val pose = stateFlow.value.currentPose
            val armTarget = PhotosphereMath.armTargetFromViewIndex(idx)
            capturedViews[idx] =
                CapturedView(
                    viewIndex = idx,
                    round = targetArm.round,
                    arm = targetArm.arm,
                    azimuthDeg = armTarget.azimuthDeg,
                    elevationDeg = REF_ELEVATION_DEG,
                    isBonus = targetArm.isBonus,
                    jpegBytes = fullResJPEG.copyOf(),
                    pose = pose,
                    sensor = sensor,
                    captureStartedNs = captureStartedNs,
                    captureCallReturnedNs = captureCallReturnedNs,
                    captureEndedNs = null,
                )
            // pose_log.json ships in release (not DEBUG-gated).
            emitPoseLogCommit(idx, targetArm, armTarget, pose)
            val updatedArms = stateFlow.value.capturedArms + idx
            // Done gates on the primary arm count (16); bonus arms
            // are opportunistic and never gate Done.
            val primaryDone = updatedArms.count { it < PhotosphereMath.PRIMARY_ARM_COUNT }
            val allPrimaryDone = primaryDone == PhotosphereMath.PRIMARY_ARM_COUNT

            // Bonus commits do NOT consume the primary scheduling
            // state machine; only primary commits advance the banner.
            val priorRound = stateFlow.value.currentRound
            val nextStage: PhotosphereState.Stage
            val nextRound: Int
            if (targetArm.isBonus) {
                nextStage =
                    if (allPrimaryDone) {
                        PhotosphereState.Stage.Done
                    } else {
                        PhotosphereState.Stage.RoundWaiting(round = priorRound)
                    }
                nextRound = priorRound
            } else {
                val advance = postCommitAdvance(updatedArms, idx, priorRound)
                nextRound = advance.nextRound
                nextStage =
                    when (advance.kind) {
                        AdvanceKind.Done -> PhotosphereState.Stage.Done
                        AdvanceKind.RoundComplete ->
                            PhotosphereState.Stage.RoundComplete(round = priorRound)
                        AdvanceKind.RoundWaiting,
                        AdvanceKind.Aiming,
                        -> PhotosphereState.Stage.RoundWaiting(round = advance.nextRound)
                    }
            }
            updateState {
                it.copy(
                    capturedArms = updatedArms,
                    stage = nextStage,
                    currentRound = nextRound,
                )
            }
            updateArmCycleTrace(nextStage)
            Log.i(
                LOG_TAG,
                "arm captured r=${targetArm.round} a=${targetArm.arm} bonus=${targetArm.isBonus} " +
                    "idx=$idx primary=$primaryDone/${PhotosphereMath.PRIMARY_ARM_COUNT} " +
                    "total=${updatedArms.size}/${PhotosphereMath.TOTAL_ARM_COUNT} " +
                    "bytes=${fullResJPEG.size}",
            )
            scheduleRoundCompleteAutoTransition(nextStage, priorRound, nextRound)
        }
    }

    /**
     * Auto-transition `RoundComplete(priorRound) → RoundWaiting(nextRound)`
     * after the toast dwell so the state machine doesn't stall on the
     * round banner. Idempotent on re-entry: re-checks the stage on
     * resume and bails if it has been overridden.
     */
    private fun scheduleRoundCompleteAutoTransition(
        nextStage: PhotosphereState.Stage,
        priorRound: Int,
        nextRound: Int,
    ) {
        if (nextStage !is PhotosphereState.Stage.RoundComplete) return
        if (nextRound <= priorRound) return
        val completedRound = priorRound
        val targetRound = nextRound
        scope.launch {
            delay(ROUND_COMPLETE_DWELL_MS)
            if (closed) return@launch
            val stage = stateFlow.value.stage
            if (stage !is PhotosphereState.Stage.RoundComplete) return@launch
            if (stage.round != completedRound) return@launch
            updateState {
                it.copy(
                    stage = PhotosphereState.Stage.RoundWaiting(round = targetRound),
                    currentRound = targetRound,
                )
            }
            Log.i(LOG_TAG, "round transition r$completedRound -> r$targetRound (RoundWaiting)")
        }
    }

    /**
     * Wrap `xfeat_post_commit_advance` and map the C ABI's
     * `XFEAT_NEXT_STAGE_*` enum back to [AdvanceKind].
     */
    private fun postCommitAdvance(
        capturedArms: Set<Int>,
        committedViewIndex: Int,
        priorRound: Int,
    ): PostCommit {
        val packed =
            PhotosphereMath.postCommitAdvance(
                capturedViewIndices = capturedArms.toIntArray(),
                committedViewIndex = committedViewIndex,
                priorRound = priorRound,
            ) ?: error("postCommitAdvance returned null (rc=invalid arg?)")
        val kind =
            when (packed[0]) {
                NEXT_STAGE_AIMING -> AdvanceKind.Aiming
                NEXT_STAGE_ROUND_WAITING -> AdvanceKind.RoundWaiting
                NEXT_STAGE_ROUND_COMPLETE -> AdvanceKind.RoundComplete
                NEXT_STAGE_DONE -> AdvanceKind.Done
                else -> error("unknown advance kind ${packed[0]}")
            }
        return PostCommit(kind = kind, nextRound = packed[1], nextArm = packed[2])
    }

    private enum class AdvanceKind { Aiming, RoundWaiting, RoundComplete, Done }

    private data class PostCommit(
        val kind: AdvanceKind,
        val nextRound: Int,
        val nextArm: Int,
    )

    /**
     * Write `index.json` + 17 JPEGs to the session directory. After
     * this returns the session is inert — call [close] to release
     * native handles.
     *
     * @param captureConfig optional operator-knobs block emitted
     *     verbatim under the `capture_config` root key.
     * @param deviceInfo optional root-level `device_info` block;
     *     sibling of `capture_config`, NOT nested inside it.
     * @return the session directory on disk.
     * @throws IllegalStateException if [captureReference] never succeeded.
     */
    suspend fun finalize(
        captureConfig: JSONObject? = null,
        deviceInfo: JSONObject? = null,
        partial: Boolean = false,
    ): File =
        withContext(dispatcher) {
            check(!closed) { "PhotosphereSession is closed" }
            // Production default validates all 16 primary arms are
            // committed; bonus arms never gate finalize. `partial`
            // skips the gate for development flows.
            if (!partial) {
                val primaryCount =
                    capturedViews.keys.count { it < PhotosphereMath.PRIMARY_ARM_COUNT }
                check(primaryCount == PhotosphereMath.PRIMARY_ARM_COUNT) {
                    "finalize called with $primaryCount/" +
                        "${PhotosphereMath.PRIMARY_ARM_COUNT} primary arms (use partial=true to override)"
                }
            }
            val ref = refPersisted ?: error("captureReference never succeeded")
            sessionDir.mkdirs()
            val refFile = File(sessionDir, refFilename(viewLossless))
            writeBytesWithSync(refFile, compressJpegIfNeeded(ref.jpegBytes))
            val views = capturedViews.toSortedMap()
            val viewExt = viewExtension()
            for ((idx, v) in views) {
                val name = "view_%02d_r%da%d.%s".format(Locale.ROOT, idx, v.round, v.arm, viewExt)
                val viewFile = File(sessionDir, name)
                writeBytesWithSync(viewFile, compressJpegIfNeeded(v.jpegBytes))
                // Sample after fd.sync() so capture_ended_ns honestly
                // marks JPEG-fsync-to-disk, not just page-cache write.
                // Same clock source as captureStartedNs so the pair
                // is a real per-arm shutter-to-durable duration.
                v.captureEndedNs = android.os.SystemClock.elapsedRealtimeNanos()
            }
            // Drain the logger before writing index.json so the
            // final appendCommit can't still be in flight on the
            // logger's serial executor when a caller enumerates the
            // bundle directory immediately after finalize returns.
            poseLogger?.flush()
            val json = buildIndexJson(ref, views, captureConfig, deviceInfo)
            writeBytesWithSync(
                File(sessionDir, "index.json"),
                json.toString(JSON_INDENT).toByteArray(Charsets.UTF_8),
            )
            Log.i(
                LOG_TAG,
                "session finalized dir=${sessionDir.absolutePath} views=${views.size} " +
                    "ref=${refFile.name} viewExt=$viewExt",
            )
            sessionDir
        }

    /**
     * Write bytes and force an `fsync` before close: without it a
     * power-cut between `finalize` returning and the kernel flushing
     * dirty pages would leave `index.json` referencing JPEGs whose
     * tail bytes never made it out of the page cache.
     */
    private fun writeBytesWithSync(
        file: File,
        bytes: ByteArray,
    ) {
        FileOutputStream(file).use { fos ->
            fos.write(bytes)
            fos.fd.sync()
        }
    }

    /**
     * Apply JPEG re-compression targeting [PhotosphereCompressionConfig.targetKB].
     *
     * Two-pass bounded approach avoids the 300–1000 ms cost of full binary
     * search while still reliably landing under the target:
     *   Pass 1 — encode at [PhotosphereCompressionConfig.initialQuality] (80).
     *   Pass 2 — if result > target, encode at [PhotosphereCompressionConfig.fallbackQuality] (65).
     *   Pass 3 — if still > target, encode at floor [PhotosphereCompressionConfig.minQuality] and accept.
     *
     * Skipped when [compressionConfig.enabled] is false or when
     * [viewLossless] is true (PNG bytes are passed through unchanged).
     * ~100–150 ms per 12 MP image on Pixel 6.
     */
    private fun compressJpegIfNeeded(bytes: ByteArray): ByteArray {
        if (!compressionConfig.enabled || viewLossless) {
            Log.i(LOG_TAG, "compressJpeg: bypass — enabled=${compressionConfig.enabled} viewLossless=$viewLossless")
            return bytes
        }
        val targetBytes = compressionConfig.targetKB * 1024L
        if (bytes.size <= targetBytes) {
            Log.i(LOG_TAG, "compressJpeg: bypass — ${bytes.size / 1024} KB already ≤ target ${compressionConfig.targetKB} KB")
            return bytes
        }
        val tStartNs = System.nanoTime()
        Log.i(LOG_TAG, "compressJpeg: start input=${bytes.size / 1024} KB target=${compressionConfig.targetKB} KB " +
            "ladder=q${compressionConfig.initialQuality}→q${compressionConfig.fallbackQuality}" +
            "→q$INTERMEDIATE_QUALITY→q${compressionConfig.minQuality}")
        // Quality-only re-encode; sensor resolution is preserved.
        // Prefer ImageDecoder (handles vendor JPEG quirks) with the
        // hardware allocator — mutable would force the software
        // allocator (~4s/decode on Cortex-A55 vs ~500 ms hardware).
        // Fall back to BitmapFactory if ImageDecoder throws.
        val bmp: android.graphics.Bitmap? = try {
            val src = android.graphics.ImageDecoder.createSource(java.nio.ByteBuffer.wrap(bytes))
            android.graphics.ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                Log.i(LOG_TAG, "compressJpeg: ImageDecoder source=${info.size.width}x${info.size.height}")
            }
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "compressJpeg: ImageDecoder failed (${t.javaClass.simpleName}: ${t.message}); falling back to BitmapFactory")
            runCatching {
                android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }.getOrNull()
        }
        if (bmp == null) {
            Log.w(LOG_TAG, "compressJpeg: decode returned null — returning original ${bytes.size / 1024} KB")
            return bytes
        }
        // Decode ONCE and re-encode N times: the prior path
        // re-decoded per quality step (~4s × 4 passes × 32 views
        // ≈ 8 min of post-capture stall on Cortex-A55).
        try {
            fun encode(quality: Int): ByteArray {
                val out = java.io.ByteArrayOutputStream(bytes.size / 2)
                val ok = bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, out)
                val outBytes = out.toByteArray()
                Log.i(LOG_TAG, "compressJpeg: q=$quality compress.ok=$ok size=${outBytes.size / 1024} KB")
                return if (ok) outBytes else bytes
            }
            val pass1 = encode(compressionConfig.initialQuality)
            if (pass1.size <= targetBytes) {
                Log.i(LOG_TAG, "compressJpeg: done at q=${compressionConfig.initialQuality} elapsed=${(System.nanoTime() - tStartNs) / 1_000_000} ms")
                return pass1
            }
            val pass2 = encode(compressionConfig.fallbackQuality)
            if (pass2.size <= targetBytes) {
                Log.i(LOG_TAG, "compressJpeg: done at q=${compressionConfig.fallbackQuality} elapsed=${(System.nanoTime() - tStartNs) / 1_000_000} ms")
                return pass2
            }
            if (compressionConfig.minQuality < INTERMEDIATE_QUALITY) {
                val passMid = encode(INTERMEDIATE_QUALITY)
                if (passMid.size <= targetBytes) {
                    Log.i(LOG_TAG, "compressJpeg: done at q=$INTERMEDIATE_QUALITY elapsed=${(System.nanoTime() - tStartNs) / 1_000_000} ms")
                    return passMid
                }
            }
            val pass3 = encode(compressionConfig.minQuality)
            if (pass3.size > targetBytes) {
                Log.w(LOG_TAG, "compressJpeg: ${bytes.size / 1024} KB → ${pass3.size / 1024} KB " +
                    "still > target ${compressionConfig.targetKB} KB at q=${compressionConfig.minQuality} " +
                    "— accepting floor (quality-only, sensor resolution preserved)")
            }
            Log.i(LOG_TAG, "compressJpeg: done at floor q=${compressionConfig.minQuality} elapsed=${(System.nanoTime() - tStartNs) / 1_000_000} ms")
            return pass3
        } finally {
            bmp.recycle()
        }
    }

    private fun viewExtension(): String = if (viewLossless) "png" else "jpg"

    /**
     * Emit a per-commit entry into `pose_log.json`. The tilt / gcd
     * fields read from the published session state — the same
     * snapshot the dwell gate consumed when it fired the shutter.
     */
    private fun emitPoseLogCommit(
        viewIndex: Int,
        targetArm: PhotosphereTargetArm,
        armTarget: PhotosphereMath.ArmTarget,
        pose: PhotospherePose?,
    ) {
        val logger = poseLogger ?: return
        val jpegName =
            "view_%02d_r%da%d.%s".format(
                Locale.ROOT,
                viewIndex,
                targetArm.round,
                targetArm.arm,
                viewExtension(),
            )
        val snapshot = stateFlow.value
        logger.appendCommit(
            PhotospherePosePerCaptureLogger.CommitArgs(
                slotIndex = viewIndex,
                armRound = targetArm.round,
                armIndex = targetArm.arm,
                targetAzimuthDeg = armTarget.azimuthDeg,
                measuredTiltMagDeg = snapshot.currentTiltMagDeg,
                measuredTiltPhiDeg = snapshot.currentAzEstimate,
                greatCircleDistanceDeg = snapshot.currentTargetDistanceDeg,
                numCheiralityInliers = pose?.numInliers ?: 0,
                jpegFilename = jpegName,
            ),
        )
    }

    /**
     * Append a per-frame entry to `frame_log.jsonl`. DEBUG-only:
     * release builds short-circuit before the arg-prep + dispatch
     * hop.
     */
    private fun logFrame(
        magDeg: Float?,
        phiDeg: Float?,
        inliers: Int?,
        gate: String,
        arm: Int?,
    ) {
        if (!BuildConfig.DEBUG) return
        poseLogger?.appendFrame(
            tiltMag = magDeg,
            tiltPhi = phiDeg,
            inliers = inliers,
            gate = gate,
            arm = arm,
        )
    }

    /**
     * Idempotent session-dir + pose-logger setup so the sidecar logs
     * can be written during capture, not just at finalize.
     */
    private fun setupSessionDirectoryAndLoggerIfNeeded() {
        if (poseLogger != null) return
        sessionDir.mkdirs()
        poseLogger = PhotospherePosePerCaptureLogger(sessionDir = sessionDir)
        Log.i(LOG_TAG, "session dir + pose logger ready at ${sessionDir.absolutePath}")
    }

    /**
     * Abort the session: discard all captured images (neither the
     * ref nor any `view_*.{jpg|png}` is written; if the session
     * directory was created ahead of time by the consumer it is
     * left untouched).
     */
    fun cancel() {
        if (closed) return
        scope.launch {
            dispatchMutex.withLock {
                capturedViews.clear()
                refPersisted = null
                updateState {
                    it.copy(
                        stage =
                            PhotosphereState.Stage.Aborted(
                                PhotosphereSessionError.SessionCancelled,
                            ),
                    )
                }
            }
        }
    }

    override fun close() {
        if (closed) return
        closed = true
        // Close any open per-arm-cycle async signpost so traces don't
        // show a dangling interval at the end of a cancelled session.
        val danglingCookie = activeArmCycleCookie
        if (danglingCookie >= 0) {
            Trace.endAsyncSection(TRACE_ARM_CYCLE, danglingCookie)
            activeArmCycleCookie = -1
            activeArmCycleLabel = null
        }
        // refRunner.close() below tears down ORT + the C ctx anyway, so
        // the previous runBlocking { releaseCachedRef() } was redundant
        // (and stalled the caller — typically the UI thread — for a full
        // session-dispatcher round-trip). Drop it.
        //
        // Release the sidecar logger so its background executor
        // terminates. Idempotent on null.
        runCatching { poseLogger?.close() }
            .onFailure { Log.w(LOG_TAG, "poseLogger close threw", it) }
        poseLogger = null
        // The poller checks closed every iteration so cancel without
        // a join is sufficient; parent-scope cancellation propagates.
        dwellPollerJob?.cancel()
        dwellPollerJob = null
        runCatching { dwellTracker?.close() }
            .onFailure { Log.w(LOG_TAG, "dwellTracker close threw", it) }
        dwellTracker = null
        liveFrameSignal.close()
        shutterScope.cancel()
        // Join the consumer loop before tearing down the runners: the
        // loop may currently be inside runLivePose → liveRunner.poseVsCachedDirect
        // → JNI. liveRunner.close() then deletes the C ctx + ORT session
        // out from under the in-flight native call.
        runBlocking { scope.coroutineContext.job.cancelAndJoin() }
        refRunner.close()
        liveRunner.close()
    }

    private inline fun updateState(block: (PhotosphereState) -> PhotosphereState) {
        val current = stateFlow.value
        val next = block(current)
        if (next !== current) {
            stateFlow.value = next
        }
    }

    /**
     * Derive `K_full_res` from the analyser-space K. Row 0 scales by
     * `imageWidth / config.width`, row 1 by
     * `imageHeight / config.height`, row 2 (homogeneous) is unchanged.
     */
    private fun scaleKToFullRes(ref: RefRecord): FloatArray {
        val sx = ref.imageWidth.toFloat() / config.width.toFloat()
        val sy = ref.imageHeight.toFloat() / config.height.toFloat()
        val k = ref.intrinsics
        return floatArrayOf(
            k[0] * sx,
            k[1] * sx,
            k[2] * sx,
            k[3] * sy,
            k[4] * sy,
            k[5] * sy,
            k[6],
            k[7],
            k[8],
        )
    }

    private fun buildIndexJson(
        ref: RefRecord,
        views: Map<Int, CapturedView>,
        captureConfig: JSONObject? = null,
        deviceInfo: JSONObject? = null,
    ): JSONObject {
        val root = JSONObject()
        // Schema URL at document root so validators don't need
        // out-of-band knowledge of the bundle version.
        root.put("\$schema", SCHEMA_URL)
        root.put("session_id", sessionDir.name)
        root.put("device", deviceModel.ifBlank { "unknown" })
        root.put("captured_at", ISO_8601.format(Date()))
        val refObj = JSONObject()
        refObj.put("frame", refFilename(viewLossless))
        refObj.put("K", JSONArray(ref.intrinsics.map { it.toDouble() }))
        // K is analyser-space; K_full_res is K scaled to the saved-
        // image pixel dimensions. When capture resolution equals
        // analyser resolution, K_full_res == K byte-for-byte.
        refObj.put("K_full_res", JSONArray(scaleKToFullRes(ref).map { it.toDouble() }))
        refObj.put("dist", JSONArray(listOf(0.0, 0.0)))
        root.put("ref", refObj)
        val viewsArr = JSONArray()
        for ((idx, v) in views.toSortedMap()) {
            val obj = JSONObject()
            obj.put("view_index", idx)
            obj.put("round", v.round)
            obj.put("arm_index", v.arm)
            obj.put("azimuth_deg", v.azimuthDeg)
            obj.put("elevation_deg", v.elevationDeg)
            // Always emitted (even when false) so the schema
            // validator doesn't have to special-case absence.
            obj.put("bonus", v.isBonus)
            obj.put(
                "frame",
                "view_%02d_r%da%d.%s".format(Locale.ROOT, idx, v.round, v.arm, viewExtension()),
            )
            v.pose?.let { pose ->
                val pObj = JSONObject()
                pObj.put("R", JSONArray(pose.rotation.map { it.toDouble() }))
                pObj.put("t", JSONArray(pose.translation.map { it.toDouble() }))
                pObj.put("num_inliers", pose.numInliers)
                pObj.put("confidence", pose.confidence.toDouble())
                obj.put("recovered_pose", pObj)
            }
            // Per-view sensor block. Fields are emitted only when the
            // HAL reported non-null so consumers can use simple
            // has(key) probes; the whole sub-object is omitted on
            // replay / headless backends.
            v.sensor?.let { sensor ->
                val sObj = JSONObject()
                sensor.exposureDurationNs?.let { sObj.put("exposure_duration_ns", it) }
                sensor.iso?.let { sObj.put("iso", it) }
                sensor.lensPosition?.let { sObj.put("lens_position", it.toDouble()) }
                sensor.timestampNs?.let { sObj.put("timestamp_ns", it) }
                if (sObj.length() > 0) {
                    obj.put("sensor", sObj)
                }
            }
            // Software-measured wall-clock samples bracketing the
            // camera capture call. Top-level (not under `sensor`)
            // because they are measured around the call, not by the
            // HAL. Omit-when-null so legacy / synthetic-replay
            // callers still produce a valid bundle. Time order:
            // started <= call_returned <= ended.
            v.captureStartedNs?.let { obj.put(VIEW_FIELD_CAPTURE_STARTED_NS, it) }
            v.captureCallReturnedNs?.let {
                obj.put(VIEW_FIELD_CAPTURE_CALL_RETURNED_NS, it)
            }
            v.captureEndedNs?.let { obj.put(VIEW_FIELD_CAPTURE_ENDED_NS, it) }
            viewsArr.put(obj)
        }
        root.put("views", viewsArr)
        // Optional operator-knobs block emitted verbatim.
        if (captureConfig != null) {
            root.put("capture_config", captureConfig)
        }
        // Optional device-info block — sibling of capture_config,
        // not nested inside. Constant per session.
        if (deviceInfo != null) {
            root.put("device_info", deviceInfo)
        }
        return root
    }

    private data class PendingLiveFrame(
        val timestampNs: Long,
    )

    /**
     * Latest analyser-tick observation the dwell poller consumes.
     * Atomic-published from [onPoseTick]; bridges the analyser-tick
     * coroutine and the wall-clock poller running on
     * `Dispatchers.Default`.
     */
    private data class DwellTargetSnapshot(
        val round: Int,
        val arm: Int,
        val viewIndex: Int,
        val onTarget: Boolean,
    )

    private data class RefRecord(
        val jpegBytes: ByteArray,
        val intrinsics: FloatArray,
        // Saved-image (W, H) for K_full_res derivation; equals
        // (config.width, config.height) when capture resolution
        // matches the analyser buffer.
        val imageWidth: Int,
        val imageHeight: Int,
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is RefRecord) return false
            if (!jpegBytes.contentEquals(other.jpegBytes)) return false
            if (!intrinsics.contentEquals(other.intrinsics)) return false
            if (imageWidth != other.imageWidth) return false
            return imageHeight == other.imageHeight
        }

        override fun hashCode(): Int {
            var result = jpegBytes.contentHashCode()
            result = 31 * result + intrinsics.contentHashCode()
            result = 31 * result + imageWidth
            result = 31 * result + imageHeight
            return result
        }
    }

    @Suppress("LongParameterList")
    private data class CapturedView(
        val viewIndex: Int,
        val round: Int,
        val arm: Int,
        val azimuthDeg: Float,
        val elevationDeg: Float,
        val isBonus: Boolean,
        val jpegBytes: ByteArray,
        val pose: PhotospherePose?,
        // No defaults here: a default value triggers a synthetic
        // `(…, DefaultConstructorMarker)` overload that breaks the
        // reflection rig in PhotosphereSessionTest
        // (`declaredConstructors.single()`). Callers pass nulls
        // explicitly via commitCurrentView's param defaults.
        val sensor: PhotosphereViewSensor?,
        var captureStartedNs: Long?,
        var captureCallReturnedNs: Long?,
        var captureEndedNs: Long?,
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is CapturedView) return false
            if (viewIndex != other.viewIndex) return false
            if (round != other.round) return false
            if (arm != other.arm) return false
            if (azimuthDeg != other.azimuthDeg) return false
            if (elevationDeg != other.elevationDeg) return false
            if (isBonus != other.isBonus) return false
            if (!jpegBytes.contentEquals(other.jpegBytes)) return false
            if (pose != other.pose) return false
            if (sensor != other.sensor) return false
            if (captureStartedNs != other.captureStartedNs) return false
            if (captureCallReturnedNs != other.captureCallReturnedNs) return false
            return captureEndedNs == other.captureEndedNs
        }

        override fun hashCode(): Int {
            var result = viewIndex
            result = 31 * result + round
            result = 31 * result + arm
            result = 31 * result + azimuthDeg.hashCode()
            result = 31 * result + elevationDeg.hashCode()
            result = 31 * result + isBonus.hashCode()
            result = 31 * result + jpegBytes.contentHashCode()
            result = 31 * result + (pose?.hashCode() ?: 0)
            result = 31 * result + (sensor?.hashCode() ?: 0)
            result = 31 * result + (captureStartedNs?.hashCode() ?: 0)
            result = 31 * result + (captureCallReturnedNs?.hashCode() ?: 0)
            result = 31 * result + (captureEndedNs?.hashCode() ?: 0)
            return result
        }
    }

    companion object {
        private const val LOG_TAG: String = "xfeat-photosphere"
        private const val JSON_INDENT: Int = 2
        /** Intermediate quality step in [compressJpegIfNeeded] between
         *  the fallback and the floor. */
        private const val INTERMEDIATE_QUALITY = 50

        // Signpost names share a prefix so a single Perfetto filter
        // pulls the photosphere instrumentation without sweeping in
        // xfeat-jni-* / xfeat-ort-* sections.
        private const val TRACE_ARM_CYCLE: String = "xfeat-photosphere-arm-cycle"
        private const val TRACE_SHUTTER: String = "xfeat-photosphere-shutter"
        private const val TRACE_FRAME_IN_FLIGHT_SKIP: String =
            "xfeat-photosphere-frame-in-flight-skip"

        /** Log every Nth skip event so Logcat stays readable on busy sessions. */
        private const val FRAME_IN_FLIGHT_LOG_EVERY: Long = 16L

        /** Wall-clock dwell poller period. Fast enough that the dwell
         *  budget fires within ~1 poll period of expiry, slow enough
         *  that idle CPU stays low. */
        private const val DWELL_POLL_PERIOD_MS: Long = 50L

        /** Failure-mode guard window: reject a dwell-pass trigger
         *  when a FAIL_* observation landed in the prior 100 ms.
         *  Tightening below ~50 ms risks failing on hand jitter;
         *  loosening above ~200 ms can spuriously block valid
         *  triggers when the analyser tick is itself ~600–800 ms. */
        private const val FAILURE_MODE_GUARD_MS: Long = 100L

        internal const val FULL_TURN_DEG: Float = 360f

        /**
         * Rotate `rawPhiDeg` by `offsetDeg` and wrap into `[0, 360)`.
         * The two `% 360` applications guarantee a non-negative
         * result even when `(rawPhi - offset)` is negative (Kotlin
         * `%` is sign-preserving like C).
         */
        @JvmStatic
        internal fun applyPhiOffset(
            rawPhiDeg: Float,
            offsetDeg: Float,
        ): Float = ((rawPhiDeg - offsetDeg) % FULL_TURN_DEG + FULL_TURN_DEG) % FULL_TURN_DEG

        /** Reference filename tracks viewLossless: `ref.png` when
         *  lossless, `ref.jpg` otherwise. Downstream consumers MUST
         *  read `index.json.ref.frame` rather than hard-coding either. */
        fun refFilename(viewLossless: Boolean): String = if (viewLossless) "ref.png" else "ref.jpg"

        // Sentinel match/inlier counts well above the MIN_INLIERS
        // gate so synthetic poses look like healthy recoveries to
        // the state machine and downstream assertions.
        private const val SYNTHETIC_POSE_SENTINEL_MATCHES: Int = 999
        private const val SYNTHETIC_POSE_SENTINEL_INLIERS: Int = 999

        /** Round-banner dwell before auto-advancing to the next round. */
        private const val ROUND_COMPLETE_DWELL_MS: Long = 200L

        /**
         * JNI companion to [enqueueSyntheticPoseForTest]. Compiled
         * only under `-DXFEAT_DEBUG_TEST_HOOKS`; release builds fail
         * to link. Validates R ∈ SO(3) and `arm ∈ 0..15`; returns 0
         * on success.
         */
        @JvmStatic
        private external fun nativeEnqueueSyntheticPoseForTest(
            arm: Int,
            rotation: FloatArray,
            translation: FloatArray,
        ): Int

        init {
            // Soft-fail on the host JVM so unit-test class-init
            // doesn't blow up; the first real JNI call will throw if
            // loading actually failed.
            try {
                System.loadLibrary("photosphere_native")
            } catch (_: UnsatisfiedLinkError) {
            }
        }

        /** Single-ring elevation. */
        private const val REF_ELEVATION_DEG: Float = 20.0f

        // The `$` is escaped here only because Kotlin would otherwise
        // parse it as a template; the literal in JSON is `$schema`.
        private const val SCHEMA_URL: String =
            "https://twinskin.dev/schemas/m7/sample_photospheres.schema.v3.json"

        // Wire-field-name constants for the software-measured per-
        // view wall-clock fields. The SDK module can't import from
        // the demo-app module, so these literals are duplicated here
        // and pinned by a cross-platform parity test.
        internal const val VIEW_FIELD_CAPTURE_STARTED_NS: String = "capture_started_ns"
        internal const val VIEW_FIELD_CAPTURE_CALL_RETURNED_NS: String = "capture_call_returned_ns"
        internal const val VIEW_FIELD_CAPTURE_ENDED_NS: String = "capture_ended_ns"

        // Decode keys for the C-side packed result.
        internal const val NEXT_STAGE_AIMING: Int = 0
        internal const val NEXT_STAGE_ROUND_WAITING: Int = 1
        internal const val NEXT_STAGE_ROUND_COMPLETE: Int = 2
        internal const val NEXT_STAGE_DONE: Int = 3

        private val ISO_8601: SimpleDateFormat =
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.ROOT)

        /**
         * Map `(round, arm)` onto the global `view_index` (0..31).
         * `round` is 1-based; `arm` is 0-based. Backed by the C ABI
         * so the formula stays single-sourced.
         */
        fun globalArmIndex(target: PhotosphereTargetArm): Int {
            val math = PhotosphereMath.armTargetMake(target.round, target.arm)
            return math.viewIndex
        }

        /** Inverse: `view_index → round`. */
        fun armRoundOf(viewIndex: Int): Int {
            val math = PhotosphereMath.armTargetFromViewIndex(viewIndex)
            return math.round
        }

        /**
         * Construct a session. Builds two [PhotosphereRunner]
         * instances because the C ABI requires distinct ref / live
         * contexts. Performs disk I/O; call from a background
         * dispatcher.
         *
         * Important defaults:
         *  - `config`: `topK = 512` is required on Cortex-A55 / XCover
         *    5 because Stage 5 is O(topK²) and the higher default caps
         *    live-loop fps below 1.
         *  - `onTargetDistanceDeg`: synthetic-scene replay raises this
         *    to 8° under the placeholder K fallback (recovered tilt
         *    magnitudes inflate 4–6° and the 3° production threshold
         *    never fires); production must keep the default.
         *  - `phiOffsetDeg`: live-camera path on Android passes 90°
         *    (landscape analyser, portrait UI); synthetic replay
         *    passes 0° (frames already in display frame).
         *  - `qaDisableTiltGate`: DEBUG-only QA bypass; SDK consumers
         *    must never opt in.
         *
         * `shutterCallback` may be `null` for headless tests — the
         * state still advances to `Capturing` but no view commits.
         */
        @Suppress("LongParameterList")
        suspend fun create(
            context: Context,
            config: PhotosphereConfig = PhotosphereConfig(topK = 512),
            strings: PhotosphereStrings = PhotosphereStrings.DEFAULT_EN,
            sessionDir: File? = null,
            shutterCallback: (suspend (Int) -> PhotosphereShutterResult?)? = null,
            nowNanos: () -> Long = { System.nanoTime() },
            onTargetDistanceDeg: Float = PhotosphereMath.ON_TARGET_DISTANCE_DEG,
            viewLossless: Boolean = false,
            phiOffsetDeg: Float = 0f,
            qaDisableTiltGate: Boolean = false,
            compressionConfig: PhotosphereCompressionConfig = PhotosphereCompressionConfig.Default,
        ): PhotosphereSession =
            withContext(Dispatchers.IO) {
                val dir =
                    sessionDir ?: run {
                        val root = File(context.filesDir, "photospheres")
                        root.mkdirs()
                        File(root, newSessionId()).apply { mkdirs() }
                    }
                dir.mkdirs()
                val ref = PhotosphereRunner.create(context, config)
                val live =
                    runCatching { PhotosphereRunner.create(context, config) }
                        .onFailure { ref.close() }
                        .getOrThrow()
                PhotosphereSession(
                    refRunner = ref,
                    liveRunner = live,
                    sessionDir = dir,
                    config = config,
                    strings = strings,
                    deviceModel = android.os.Build.MODEL ?: "unknown",
                    shutterCallback = shutterCallback,
                    nowNanos = nowNanos,
                    onTargetDistanceDeg = onTargetDistanceDeg,
                    phiOffsetDeg = phiOffsetDeg,
                    viewLossless = viewLossless,
                    qaDisableTiltGate = qaDisableTiltGate,
                    compressionConfig = compressionConfig,
                )
            }

        private fun newSessionId(): String {
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(Date())
            val suffix =
                UUID
                    .randomUUID()
                    .toString()
                    .take(ID_SUFFIX_LEN)
                    .replace("-", "")
            return "photosphere-$stamp-$suffix"
        }

        private const val ID_SUFFIX_LEN: Int = 8
    }
}

/** `(round, arm)` tuple. `round` is 1-based; `arm` is 0-based. */
data class PhotosphereTargetArm(
    val round: Int,
    val arm: Int,
) {
    init {
        require(round in 1..PhotosphereMath.MAX_ROUND_COUNT) {
            "round must be in 1..${PhotosphereMath.MAX_ROUND_COUNT}"
        }
        require(arm in 0 until PhotosphereMath.ARMS_PER_ROUND) {
            "arm must be in 0 until ${PhotosphereMath.ARMS_PER_ROUND}"
        }
    }

    /** True for rounds 5..8 (the bonus offset pass). */
    val isBonus: Boolean get() = round > PhotosphereMath.PRIMARY_ROUND_COUNT
}

/**
 * Snapshot of session state published on [PhotosphereSession.state].
 *
 * @property stage current flow stage.
 * @property currentRound 1-based round counter for UI banners.
 * @property capturedArms global `view_index` set of arms that reached
 *     `CAPTURED`. Lock-after-capture: this set never shrinks.
 * @property currentPose most-recent live pose; `null` between refBind
 *     and the first live frame, or if the last live frame failed.
 * @property currentAzEstimate live tilt_phi (the cross-overlay
 *     cursor's polar angle). `null` if pose unavailable.
 * @property currentTiltMagDeg live tilt magnitude (the cursor's
 *     radial distance from the cross centre). `null` until the first
 *     successful live pose, or when the most recent frame failed.
 * @property currentError most-recent non-fatal UX-level error.
 * @property currentTargetDistanceDeg picker great-circle distance to
 *     the selected arm; drives the screen-edge proximity overlay.
 *     `null` when no pick is available.
 */
data class PhotosphereState(
    val stage: Stage,
    val currentRound: Int,
    val capturedArms: Set<Int>,
    val currentPose: PhotospherePose?,
    val currentAzEstimate: Float?,
    val currentTiltMagDeg: Float?,
    val currentError: PhotosphereSessionError?,
    val currentTargetDistanceDeg: Float? = null,
) {
    sealed class Stage {
        data object RefCapture : Stage()

        data class RoundWaiting(
            val round: Int,
        ) : Stage()

        data class Aiming(
            val round: Int,
            val targetArm: Int,
        ) : Stage()

        data class OnTarget(
            val round: Int,
            val targetArm: Int,
            val startNanos: Long,
            val holdMs: Int,
        ) : Stage()

        data class Capturing(
            val round: Int,
            val targetArm: Int,
        ) : Stage()

        data class RoundComplete(
            val round: Int,
        ) : Stage()

        data object Done : Stage()

        data class Aborted(
            val reason: PhotosphereSessionError,
        ) : Stage()
    }
}

/**
 * UX-layer errors surfaced through [PhotosphereState.currentError]
 * and [PhotosphereState.Stage.Aborted]. Distinct from the C-ABI
 * [PhotosphereError] family — a recoverable "marker lost" is a UX
 * state, not a native error.
 */
sealed class PhotosphereSessionError(
    messageText: String,
) : PhotosphereError(CODE_PHOTOSPHERE, messageText) {
    /** Live inlier count sustained below 15. */
    data class BaselineTooNarrow(
        val inliers: Int,
    ) : PhotosphereSessionError("Inliers=$inliers, below 15")

    /** Marker left the analyser frame mid-round. */
    data object MarkerLost : PhotosphereSessionError("Marker lost")

    /** Device thermal-throttled. */
    data object ThermalThrottled : PhotosphereSessionError("Thermal throttle")

    /** Consumer's full-res capture failed. */
    data class FullResCaptureFailed(
        val capturedCause: Throwable?,
    ) : PhotosphereSessionError("Full-res capture failed: ${capturedCause?.message ?: "unknown"}")

    /** Shipped asset digest doesn't match the compiled-in pin. */
    data class AssetDigestMismatch(
        val slot: String,
    ) : PhotosphereSessionError("Asset digest mismatch: $slot")

    /** [PhotosphereSession.cancel] was called. */
    data object SessionCancelled : PhotosphereSessionError("Cancelled")

    companion object {
        private const val CODE_PHOTOSPHERE: Int = 200
    }
}
