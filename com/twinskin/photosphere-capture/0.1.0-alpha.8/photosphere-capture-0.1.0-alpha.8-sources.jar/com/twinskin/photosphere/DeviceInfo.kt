package com.twinskin.photosphere

import android.os.Build

/**
 * Minimal abstraction over [Build.MANUFACTURER] and [Build.MODEL] so the
 * per-device asset dispatch ([pickDefaultAssetPath]) can be
 * JVM-unit-tested without Robolectric. The production code path reads
 * [DeviceInfo.current], which forwards to the real static fields;
 * `src/test/` supplies a small in-memory stub.
 *
 * Kept internal — library consumers have no reason to override the
 * dispatcher's device model. If they need a specific asset they set
 * [PhotosphereConfig.modelAssetPath] explicitly, which bypasses the dispatch.
 */
internal interface DeviceInfo {
    val manufacturer: String
    val model: String

    companion object {
        val current: DeviceInfo =
            object : DeviceInfo {
                override val manufacturer: String = Build.MANUFACTURER ?: ""
                override val model: String = Build.MODEL ?: ""
            }
    }
}

/**
 * Per-device default asset selection (OI-013). Lives as a top-level
 * function rather than on [PhotosphereRunner]'s companion because the
 * companion's `init` block calls `System.loadLibrary("photosphere_native")`,
 * and JVM unit tests can't resolve that shared object. Keeping the
 * dispatch logic outside the companion lets the JVM suite cover it
 * without Robolectric or a shim .so.
 *
 * XCover 5 (Samsung SM-G525F, Cortex-A55) ships fp32 because the A55
 * predates ARMv8.4 SDOT/UDOT; the M5 int8 soak on that board missed
 * the p95 gate and ran hotter than the fp32 reference
 * (VALIDATION.md § M5 XCover int8 soak FAIL). Pixel 8 / Pixel 8 Pro
 * (Tensor G3, Cortex-X3 + A715) have SDOT and get int8 — the int8 soak
 * cleared the 500 ms gate on Pixel 8 (OI-012). Unknown devices get
 * fp32: it's the safe default that passes the 500 ms soak gate on
 * every board tested.
 */
internal fun pickDefaultAssetPath(device: DeviceInfo): String {
    val mfr = device.manufacturer.lowercase()
    val model = device.model
    if (mfr == "samsung" && model == "SM-G525F") {
        return PhotosphereAssets.FP32_480X640
    }
    if (mfr == "google" && model.startsWith("Pixel 8")) {
        return PhotosphereAssets.INT8_480X640
    }
    return PhotosphereAssets.FP32_480X640
}
