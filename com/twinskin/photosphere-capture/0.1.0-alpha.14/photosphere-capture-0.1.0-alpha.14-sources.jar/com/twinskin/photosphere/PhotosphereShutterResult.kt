package com.twinskin.photosphere

/**
 * Per-view sensor metadata captured at shutter time. Emitted under
 * `views[i].sensor` in `index.json`.
 *
 * Fields are independently nullable — some HALs return `null` for
 * individual `CaptureResult` keys even when the wider
 * `TotalCaptureResult` is available. Absent keys are omitted from the
 * JSON (NOT emitted as `null`) so consumers can use `has()` probes.
 *
 * [lensPosition] units differ across platforms: Android reports it in
 * dioptres (0 = infinity), iOS reports a normalised `[0.0, 1.0]`.
 * Consumers must branch on `build.platform`.
 */
data class PhotosphereViewSensor(
    val exposureDurationNs: Long? = null,
    val iso: Int? = null,
    val lensPosition: Float? = null,
    val timestampNs: Long? = null,
)

/**
 * Return type of the session's `shutterCallback`.
 *
 * `sensor` is hardware-sourced; `captureStartedNs` and
 * `captureCallReturnedNs` are software-measured monotonic timestamps
 * (boot-relative `SystemClock.elapsedRealtimeNanos`). Synthetic-replay
 * backends pass `null` for all three.
 *
 * The session emits all three at the top level of each `views[i]`
 * entry (NOT under `sensor`). Together with the session-side
 * `captureEndedNs` they separate per-arm shutter-call latency
 * (`captureCallReturnedNs - captureStartedNs`) from intent-to-durable
 * (`captureEndedNs - captureStartedNs`).
 */
data class PhotosphereShutterResult(
    val bytes: ByteArray,
    val sensor: PhotosphereViewSensor? = null,
    val captureStartedNs: Long? = null,
    val captureCallReturnedNs: Long? = null,
    /**
     * Device telemetry sampled by the capture site right before
     * returning the JPEG bytes — thermal status, process RSS,
     * available memory, low-power mode, battery, session_seconds.
     * Cross-referenced with the validator's TWINSKIN_VALIDATION stamp
     * via `TWINSKIN_TELEMETRY` in `TIFF.Copyright`, and mirrored
     * into `pose_log.json` so XFeat heat-vs-time analyses don't have
     * to walk every JPEG.
     */
    val telemetry: PhotosphereDeviceTelemetry? = null,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PhotosphereShutterResult) return false
        if (!bytes.contentEquals(other.bytes)) return false
        if (sensor != other.sensor) return false
        if (captureStartedNs != other.captureStartedNs) return false
        if (captureCallReturnedNs != other.captureCallReturnedNs) return false
        return telemetry == other.telemetry
    }

    override fun hashCode(): Int {
        var result = bytes.contentHashCode()
        result = 31 * result + (sensor?.hashCode() ?: 0)
        result = 31 * result + (captureStartedNs?.hashCode() ?: 0)
        result = 31 * result + (captureCallReturnedNs?.hashCode() ?: 0)
        result = 31 * result + (telemetry?.hashCode() ?: 0)
        return result
    }
}

/**
 * Platform-agnostic snapshot of device thermal + memory + power state
 * taken at shutter time. All fields are nullable so synthetic / replay
 * paths can omit them, and so a platform that lacks a given probe
 * (e.g. API < 29 on Android has no `getCurrentThermalStatus`) can
 * still emit a partial-but-valid record.
 *
 * Sampled once per captured photo, never from the analyser loop; see
 * `packages/sdk/CLAUDE.md` § "Cross-cutting: device telemetry" for
 * the per-platform cost budget.
 */
data class PhotosphereDeviceTelemetry(
    /**
     * Normalized lowercase string. Android: `none` / `light` /
     * `moderate` / `severe` / `critical` / `emergency` / `shutdown`.
     * iOS: `nominal` / `fair` / `serious` / `critical`. Both platforms
     * emit `unknown` when the OS returns an enum value they don't
     * recognise (forward-compat fallback).
     */
    val thermal: String? = null,
    /** Process resident set size, in mebibytes (1 MiB = 1024 * 1024). */
    val rssMb: Int? = null,
    /**
     * Available-memory headroom in mebibytes. Note: the two platforms
     * report different metrics under this field — iOS uses
     * `os_proc_available_memory` (per-process, before jetsam), Android
     * uses `ActivityManager.MemoryInfo.availMem` (system-wide). Cross-
     * device analyses keyed on `availMb` must keep that asymmetry in
     * mind; see `packages/sdk/CLAUDE.md` § "Cross-cutting: device
     * telemetry" for the rationale.
     */
    val availMb: Int? = null,
    /** Android: `PowerManager.isPowerSaveMode`. */
    val lowPowerMode: Boolean? = null,
    /** 0–100 integer; nil when the battery probe returns no value. */
    val batteryPct: Int? = null,
    /** True iff the device reports it is charging from any source. */
    val charging: Boolean? = null,
    /**
     * Seconds since the capture session was created. Lets an analyst
     * plot thermal/memory vs. capture duration without joining
     * wall-clock timestamps.
     */
    val sessionSeconds: Int? = null,
) {
    /**
     * Render as a TIFF.Copyright EXIF payload. Format mirrors the
     * validator's TIFF.ImageDescription `;key=value` convention. Keys
     * whose value is null emit `n/a`, mirroring the validator's
     * `ref_diag=n/a` fallback. Numeric formatting is locale-free
     * (`Int.toString()` is locale-independent) so the cross-platform
     * payload doesn't diverge on fr-FR / de-DE devices.
     */
    fun exifPayload(): String {
        val thermalStr = thermal ?: "n/a"
        val rssStr = rssMb?.toString() ?: "n/a"
        val availStr = availMb?.toString() ?: "n/a"
        val lpmStr = lowPowerMode?.let { if (it) "1" else "0" } ?: "n/a"
        val battStr = batteryPct?.toString() ?: "n/a"
        val chgStr = charging?.let { if (it) "1" else "0" } ?: "n/a"
        val sessionStr = sessionSeconds?.toString() ?: "n/a"
        return "TWINSKIN_TELEMETRY;thermal=$thermalStr;rss_mb=$rssStr;" +
            "avail_mb=$availStr;low_power=$lpmStr;battery_pct=$battStr;" +
            "charging=$chgStr;session_s=$sessionStr"
    }
}
