package com.twinskin.photosphere

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log

/**
 * Per-photo telemetry sampler. Probes thermal status, process memory,
 * power-save / battery via public APIs only (no `DEVICE_POWER`
 * privileged permission, no signature-level access) so the result is
 * safe to ship in release builds of integrator apps.
 *
 * Sampled once per captured photo, never from the analyser loop; see
 * `packages/sdk/CLAUDE.md` § "Cross-cutting: device telemetry" for
 * the per-platform cost budget and cross-platform invariants.
 */
object PhotosphereDeviceTelemetrySampler {
    /**
     * Sample now. [sessionStartElapsedNs] is a monotonic-clock
     * `SystemClock.elapsedRealtimeNanos` reading captured when the
     * capture session started; pass `null` to omit `session_seconds`.
     */
    fun sample(
        context: Context,
        sessionStartElapsedNs: Long? = null,
    ): PhotosphereDeviceTelemetry {
        val thermal = sampleThermal(context)
        val (rssMb, availMb) = sampleMemory(context)
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val lowPower = powerManager?.isPowerSaveMode
        val (batteryPct, charging) = sampleBattery(context)
        val sessionSeconds = sessionStartElapsedNs?.let {
            val elapsedNs = (SystemClock.elapsedRealtimeNanos() - it).coerceAtLeast(0L)
            (elapsedNs / 1_000_000_000L).toInt()
        }
        return PhotosphereDeviceTelemetry(
            thermal = thermal,
            rssMb = rssMb,
            availMb = availMb,
            lowPowerMode = lowPower,
            batteryPct = batteryPct,
            charging = charging,
            sessionSeconds = sessionSeconds,
        )
    }

    private fun sampleThermal(context: Context): String? {
        // PowerManager.getCurrentThermalStatus is API 29+ (Android 10).
        // photosphere_capture pins minSdk=28; consumers on shared/ may
        // run as low as 24. Older devices: return null (omitted from
        // EXIF as `n/a`).
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            ?: return null
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "none"
            PowerManager.THERMAL_STATUS_LIGHT -> "light"
            PowerManager.THERMAL_STATUS_MODERATE -> "moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "shutdown"
            else -> "unknown"
        }
    }

    /**
     * Returns (process RSS mebibytes, system available mebibytes).
     * RSS uses `Debug.getNativeHeapAllocatedSize` + JVM heap because
     * `Debug.MemoryInfo` (via `ActivityManager.getProcessMemoryInfo`)
     * is rate-limited to once per 300 s on Android 8+ — sampling it
     * per photo would return stale numbers without telling the caller.
     */
    private fun sampleMemory(context: Context): Pair<Int?, Int?> {
        val rssMb = runCatching {
            val nativeHeap = Debug.getNativeHeapAllocatedSize()
            val runtime = Runtime.getRuntime()
            val jvmHeap = runtime.totalMemory() - runtime.freeMemory()
            ((nativeHeap + jvmHeap) / MIB).toInt()
        }.getOrNull()
        val availMb = runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                ?: return@runCatching null
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            (memInfo.availMem / MIB).toInt()
        }.getOrNull()
        return rssMb to availMb
    }

    /**
     * Returns (batteryPct 0-100, isCharging). Uses `BatteryManager`'s
     * `BATTERY_PROPERTY_CAPACITY` on API 21+ (always available since
     * SDK minSdk=24) and the sticky `ACTION_BATTERY_CHANGED` intent
     * for the charging flag. Both probes are stateless / non-blocking
     * — no BroadcastReceiver registered.
     */
    private fun sampleBattery(context: Context): Pair<Int?, Boolean?> {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val pct = runCatching {
            val raw = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            if (raw == null || raw == Integer.MIN_VALUE || raw < 0) null else raw.coerceIn(0, 100)
        }.getOrNull()
        val charging = runCatching {
            // BatteryManager.isCharging is API 23+ but minSdk=24, so safe.
            bm?.isCharging
        }.getOrNull() ?: runCatching {
            // Fallback path for HALs that don't surface isCharging:
            // read the sticky ACTION_BATTERY_CHANGED intent. Some
            // OEM-hardened / Knox-managed contexts throw SecurityException
            // here even with a null receiver; logged so we don't lose
            // the signal during field triage.
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            if (status == -1) null
            else status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        }.onFailure {
            Log.d("PhotosphereDeviceTelemetrySampler", "sticky battery probe: ${it.javaClass.simpleName}")
        }.getOrNull()
        return pct to charging
    }

    private const val MIB: Long = 1024L * 1024L
}
