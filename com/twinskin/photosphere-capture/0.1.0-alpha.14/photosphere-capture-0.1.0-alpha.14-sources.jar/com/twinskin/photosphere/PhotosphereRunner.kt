package com.twinskin.photosphere

import android.content.Context
import androidx.annotation.VisibleForTesting
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Public Android wrapper around the photosphere capture pair-pose pipeline.
 *
 * Layer chain: Kotlin -> JNI (`xfeat_jni.cpp`) -> `xfeat_core` C ABI
 * from `common/xfeat/`. The JNI bridge is a thin translation layer — no
 * algorithms, no loops. Shared logic lives in C per CLAUDE.md § "Golden
 * rule — shared logic lives in C".
 *
 * Thread model mirrors iOS: each instance dispatches native calls on
 * its own serial background dispatcher so callers can safely invoke
 * [estimatePose] from the Camera2 reader thread (or anywhere else)
 * without contending on ORT or the C ctx.
 *
 * Lifecycle:
 *   1. [create] — resolves the asset, builds the ORT session, allocates
 *      the C ctx, picks an execution provider.
 *   2. [estimatePose] — one pipeline call per pair. Suspends on the
 *      serial dispatcher.
 *   3. [close] — tears down ORT + C ctx. Safe to call twice (idempotent).
 */
class PhotosphereRunner private constructor(
    private val nativeHandle: Long,
    val config: PhotosphereConfig,
    val actualExecutionProvider: ActualExecutionProvider,
) : AutoCloseable {
    // Single-worker background dispatcher per runner. Matches the iOS
    // serial queue; required because `PhotosphereRunner.estimatePose` is
    // stateful on the native side and a second concurrent call would
    // clobber ctx-owned scratch buffers.
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val dispatcher = Dispatchers.Default.limitedParallelism(1)

    @Volatile
    private var closed: Boolean = false

    // Package-internal accessors so sibling runners can peek at handle +
    // closed status. Needed by [poseVsCached] to pass the ref runner's
    // native handle down to JNI without widening the public surface;
    // the production C ABI (`xfeat_match_and_pose_cached`) takes two
    // distinct `xfeat_ctx *`.
    internal val nativeHandleInternal: Long get() = nativeHandle
    internal val closedInternal: Boolean get() = closed

    /**
     * Runs the pipeline end-to-end: preprocess + Stage 2 ORT forward +
     * Stages 3-6 via the C ABI.
     *
     * Inputs are preprocessed grayscale float32 buffers in [0, 255]
     * of length `config.height * config.width` — same contract as the
     * iOS [`PhotosphereRunner.estimatePose(grayA:, grayB:, ...)`] path.
     *
     * @throws PhotosphereError on any pipeline-level failure. M3 returns
     *     [PhotosphereError.NotImplemented] from Stage 3/5/6 because
     *     common/xfeat/xfeat_postprocess.c and xfeat_match.c still
     *     return `XFEAT_ERR_NOT_IMPLEMENTED` (same as iOS M2).
     */
    suspend fun estimatePose(
        grayA: FloatArray,
        grayB: FloatArray,
        intrinsicsA: FloatArray,
        intrinsicsB: FloatArray,
    ): PhotospherePose =
        withContext(dispatcher) {
            require(!closed) { "PhotosphereRunner is closed" }
            require(grayA.size == config.height * config.width) {
                "grayA length must equal height*width (= ${config.height * config.width})"
            }
            require(grayB.size == config.height * config.width) {
                "grayB length must equal height*width"
            }
            require(intrinsicsA.size == INTRINSICS_SIZE) { "intrinsicsA must have 9 floats" }
            require(intrinsicsB.size == INTRINSICS_SIZE) { "intrinsicsB must have 9 floats" }

            val grayABuffer = wrapFloatArrayAsDirect(grayA)
            val grayBBuffer = wrapFloatArrayAsDirect(grayB)

            nativeEstimatePose(
                nativeHandle,
                grayABuffer,
                grayBBuffer,
                intrinsicsA,
                intrinsicsB,
            ) ?: throw PhotosphereError.Internal(
                PhotosphereError.CODE_INTERNAL,
                "nativeEstimatePose returned null without setting error",
            )
        }

    /**
     * Debug-only variant of [estimatePose] that also returns per-stage
     * wall-clock timings. Uses the same native path (ORT forward A,
     * ORT forward B, postprocess A+B, match + pose) but fills out an
     * [PhotosphereStageTimings] captured inside JNI with
     * `std::chrono::steady_clock`.
     *
     * Not part of the SDK surface the dermatoo adapter consumes — the
     * DemoApp uses it to render a timings block on the Result screen;
     * the C ABI itself is unchanged (per the DemoApp brief guardrail
     * "Do NOT change the C ABI").
     */
    @VisibleForTesting
    suspend fun estimatePoseWithTimings(
        grayA: FloatArray,
        grayB: FloatArray,
        intrinsicsA: FloatArray,
        intrinsicsB: FloatArray,
    ): PhotospherePoseWithTimings =
        withContext(dispatcher) {
            require(!closed) { "PhotosphereRunner is closed" }
            require(grayA.size == config.height * config.width) {
                "grayA length must equal height*width (= ${config.height * config.width})"
            }
            require(grayB.size == config.height * config.width) {
                "grayB length must equal height*width"
            }
            require(intrinsicsA.size == INTRINSICS_SIZE) { "intrinsicsA must have 9 floats" }
            require(intrinsicsB.size == INTRINSICS_SIZE) { "intrinsicsB must have 9 floats" }

            val grayABuffer = wrapFloatArrayAsDirect(grayA)
            val grayBBuffer = wrapFloatArrayAsDirect(grayB)
            // Native fills 4 doubles: [backboneA, backboneB, postprocess, match].
            val timingsOut = DoubleArray(TIMINGS_SLOTS)
            val pose =
                nativeEstimatePoseWithTimings(
                    nativeHandle,
                    grayABuffer,
                    grayBBuffer,
                    intrinsicsA,
                    intrinsicsB,
                    timingsOut,
                ) ?: throw PhotosphereError.Internal(
                    PhotosphereError.CODE_INTERNAL,
                    "nativeEstimatePoseWithTimings returned null without setting error",
                )
            PhotospherePoseWithTimings(
                pose = pose,
                timings =
                    PhotosphereStageTimings(
                        backboneAMs = timingsOut[0],
                        backboneBMs = timingsOut[1],
                        postprocessMs = timingsOut[2],
                        matchMs = timingsOut[3],
                    ),
            )
        }

    /**
     * Test-only entry point: runs only Stages 3-6 against caller-provided
     * backbone outputs. Matches iOS's `estimatePoseFromBackboneOutputs`
     * path so the FFI-round-trip tests can run without a valid `.ort`
     * asset on disk. M3: still returns [PhotosphereError.NotImplemented] per
     * the stubbed common/xfeat/xfeat_postprocess.c.
     */
    @VisibleForTesting
    suspend fun estimatePoseFromBackboneOutputs(
        sideA: PhotosphereBackboneOutputs,
        sideB: PhotosphereBackboneOutputs,
        intrinsicsA: FloatArray,
        intrinsicsB: FloatArray,
    ): PhotospherePose =
        withContext(dispatcher) {
            require(!closed) { "PhotosphereRunner is closed" }
            nativeEstimatePoseFromOutputs(
                nativeHandle,
                wrapFloatArrayAsDirect(sideA.feats),
                wrapFloatArrayAsDirect(sideA.kptlogits),
                wrapFloatArrayAsDirect(sideA.heatmap),
                sideA.scaleX,
                sideA.scaleY,
                wrapFloatArrayAsDirect(sideB.feats),
                wrapFloatArrayAsDirect(sideB.kptlogits),
                wrapFloatArrayAsDirect(sideB.heatmap),
                sideB.scaleX,
                sideB.scaleY,
                intrinsicsA,
                intrinsicsB,
            ) ?: throw PhotosphereError.Internal(
                PhotosphereError.CODE_INTERNAL,
                "nativeEstimatePoseFromOutputs returned null without setting error",
            )
        }

    /**
     * Bind this runner as the reference for subsequent [poseVsCached] calls.
     *
     * Runs backbone forward + postprocess on [gray], stashing the
     * reference features in this runner's ctx-owned scratch, then
     * installs the (K_ref, dist_ref) binding via
     * `xfeat_bind_cached_ref`. After this call the runner is
     * contractually "acting as a ref" until [releaseCachedRef] is
     * invoked — calling [estimatePose] on the same runner would
     * overwrite the cached features, so don't.
     *
     * State machine:
     * ```
     *   cacheRef(ref, K_ref)      // bind
     *     -> poseVsCached(ref, live₁, K_live₁)  // repeated N times
     *     -> poseVsCached(ref, live₂, K_live₂)
     *     -> ...
     *   releaseCachedRef()        // unbind, free the ref to be re-used
     * ```
     *
     * Distortion is assumed zero (rectified stream). Returns the number
     * of reference keypoints cached; < 4 trips the C ABI's
     * `XFEAT_ERR_TOO_FEW_MATCHES` at bind time per
     * `docs/ffi-contract.md § xfeat_bind_cached_ref`.
     *
     * Thread-safety: serialised on this runner's dispatcher. Safe
     * against concurrent calls on a DIFFERENT runner. Calling cacheRef
     * while another thread runs [poseVsCached] against this runner is
     * UB — follow the state-machine.
     *
     * @throws PhotosphereError.TooFewMatches if the backbone produced < 4 keypoints.
     * @throws PhotosphereError on any other pipeline-level failure.
     */
    suspend fun cacheRef(
        gray: FloatArray,
        intrinsics: FloatArray,
    ): Int =
        withContext(dispatcher) {
            require(!closed) { "PhotosphereRunner is closed" }
            require(gray.size == config.height * config.width) {
                "gray length must equal height*width (= ${config.height * config.width})"
            }
            require(intrinsics.size == INTRINSICS_SIZE) { "intrinsics must have 9 floats" }
            val buf = wrapFloatArrayAsDirect(gray)
            nativeCacheRef(nativeHandle, buf, intrinsics)
        }

    /**
     * Release a binding previously installed by [cacheRef]. No-op if
     * the runner is not currently bound. After this call the runner
     * may be used freely again — [estimatePose] will overwrite the
     * previously-cached features.
     *
     * Thread-safety: serialised on this runner's dispatcher.
     */
    suspend fun releaseCachedRef(): Unit =
        withContext(dispatcher) {
            if (closed) return@withContext
            nativeReleaseCachedRef(nativeHandle)
        }

    /**
     * Live-pose match against the features cached on [refRunner] by a
     * prior [cacheRef] call. Runs backbone forward + postprocess on
     * [gray] using this runner's ctx, then essential-matrix pose recovery
     * via `xfeat_match_and_pose_cached` — the reference descriptors are
     * read in-place from the ref runner's scratch (no copy).
     *
     * [timingsOutMs] is filled with `[backboneMs, postprocessMs, matchMs, 0.0]`
     * when non-null. The trailing slot stays 0 so the shape matches
     * [PhotosphereStageTimings] and callers can reuse the pair-pose visualiser.
     *
     * Preconditions:
     *   - [refRunner] must have been bound via [refRunner.cacheRef] and
     *     not yet released (else `PhotosphereError.NoCachedRef`).
     *   - [refRunner] must be a DIFFERENT instance from this one
     *     (else `PhotosphereError.SameCtx` — aliasing would corrupt Stage 5
     *     scratch).
     *
     * Thread-safety: serialised on this (live) runner's dispatcher. Safe
     * to call concurrently on a different live runner sharing the same
     * [refRunner] — the ref descriptors are read-only once bound.
     *
     * @throws PhotosphereError.NoCachedRef if [refRunner] is not bound.
     * @throws PhotosphereError.SameCtx if [refRunner] aliases this runner.
     * @throws PhotosphereError.TooFewMatches if MNN yielded < 8 matches.
     * @throws PhotosphereError on any other pipeline-level failure.
     */
    suspend fun poseVsCached(
        refRunner: PhotosphereRunner,
        gray: FloatArray,
        intrinsics: FloatArray,
        timingsOutMs: DoubleArray? = null,
    ): PhotospherePose =
        withContext(dispatcher) {
            require(!closed) { "PhotosphereRunner is closed (live)" }
            require(!refRunner.closedInternal) { "PhotosphereRunner is closed (ref)" }
            require(gray.size == config.height * config.width) {
                "gray length must equal height*width (= ${config.height * config.width})"
            }
            require(intrinsics.size == INTRINSICS_SIZE) { "intrinsics must have 9 floats" }
            timingsOutMs?.let {
                require(it.size >= TIMINGS_SLOTS) {
                    "timingsOutMs must have at least $TIMINGS_SLOTS slots"
                }
            }
            val buf = wrapFloatArrayAsDirect(gray)
            nativePoseVsCached(
                nativeHandle,
                refRunner.nativeHandleInternal,
                buf,
                intrinsics,
                timingsOutMs,
            ) ?: throw PhotosphereError.Internal(
                PhotosphereError.CODE_INTERNAL,
                "nativePoseVsCached returned null without setting error",
            )
        }

    /**
     * Zero-copy variant of [poseVsCached] that takes a caller-owned
     * direct [ByteBuffer] instead of a [FloatArray]. The [PhotosphereSession]
     * live loop uses this to avoid the per-frame allocation the
     * FloatArray path does in `wrapFloatArrayAsDirect` — the session
     * owns a single direct buffer reused across every analyser frame
     * (R-P3 sustainability: zero heap growth on the hot path).
     *
     * [grayDirect] must be a direct ByteBuffer with native byte order,
     * capacity `>= height*width*4`, position 0. The underlying memory
     * holds row-major float32 `[0, 255]` luma — same contract as the
     * [FloatArray] overload. Caller retains ownership; the native
     * layer reads the buffer in place via `GetDirectBufferAddress`.
     *
     * Preconditions + thread-safety + error semantics are identical
     * to the public [poseVsCached]; see that method's KDoc.
     *
     * Kept `internal` because the direct-buffer contract is harder to
     * honour correctly than the [FloatArray] overload (silent mis-ordered
     * or non-direct buffers would return garbage poses). Exposing it
     * on the public SDK surface would invite those footguns.
     */
    internal suspend fun poseVsCachedDirect(
        refRunner: PhotosphereRunner,
        grayDirect: ByteBuffer,
        intrinsics: FloatArray,
        timingsOutMs: DoubleArray? = null,
    ): PhotospherePose =
        withContext(dispatcher) {
            require(!closed) { "PhotosphereRunner is closed (live)" }
            require(!refRunner.closedInternal) { "PhotosphereRunner is closed (ref)" }
            require(grayDirect.isDirect) { "grayDirect must be a direct ByteBuffer" }
            require(grayDirect.capacity() >= config.height * config.width * Float.SIZE_BYTES) {
                "grayDirect capacity must be >= height*width*4 bytes"
            }
            require(intrinsics.size == INTRINSICS_SIZE) { "intrinsics must have 9 floats" }
            timingsOutMs?.let {
                require(it.size >= TIMINGS_SLOTS) {
                    "timingsOutMs must have at least $TIMINGS_SLOTS slots"
                }
            }
            nativePoseVsCached(
                nativeHandle,
                refRunner.nativeHandleInternal,
                grayDirect,
                intrinsics,
                timingsOutMs,
            ) ?: throw PhotosphereError.Internal(
                PhotosphereError.CODE_INTERNAL,
                "nativePoseVsCached returned null without setting error",
            )
        }

    /**
     * Snapshot the most recent match's per-frame keypoint + match data
     * (live keypoints, ref keypoints, matched-pair indices, per-match
     * cossim). Must be called synchronously after [poseVsCached] /
     * [poseVsCachedDirect] returns on the SAME runner pair, before the
     * next match call clobbers the underlying C scratch.
     *
     * Returns null if the underlying ctx is closed OR if any per-array
     * JNI allocation failed under memory pressure (the JNI side returns
     * null with a pending OutOfMemoryError that the dispatcher will
     * surface separately).
     */
    fun lastMatchRecords(refRunner: PhotosphereRunner): PhotosphereMatchRecords? {
        if (closed || refRunner.closedInternal) return null
        val raw = nativeGetLastMatchRecords(
            nativeHandle,
            refRunner.nativeHandleInternal,
            config.topK,
        ) ?: return null
        val liveKpts = raw[0] as? FloatArray ?: return null
        val refKpts = raw[1] as? FloatArray ?: return null
        val matchLive = raw[2] as? IntArray ?: return null
        val matchRef = raw[3] as? IntArray ?: return null
        val cossim = raw[4] as? FloatArray ?: return null
        return PhotosphereMatchRecords(
            liveKeypoints = liveKpts,
            refKeypoints = refKpts,
            matchIdxLive = matchLive,
            matchIdxRef = matchRef,
            matchCossim = cossim,
        )
    }

    /**
     * OI-031 Class B-Android — DEBUG-only backbone forward dump hook.
     *
     * Runs ONE ORT backbone forward on [gray] and copies the three
     * output tensors (feats, kptlogits, heatmap) into the caller-
     * supplied direct [ByteBuffer]s. Used exclusively by
     * the upstream `XFeatAndroidDumpTest` (instrumented, androidTest
     * source set in evaluate-xfeat-lighterglue/android/xfeat/) to
     * produce per-case backbone dumps for the iOS ↔ Android
     * pair-diagnostic diff. The androidTest source set is deferred in
     * rimbaud (see SOURCE_VERSION.md § "Excluded from copy").
     *
     * Calls through to the JNI symbol
     * `Java_com_twinskin_photosphere_PhotosphereRunner_nativeBackboneForwardForTest`
     * which is compiled ONLY under `XFEAT_DEBUG_TEST_HOOKS` (see
     * `src/main/cpp/CMakeLists.txt` — debug buildType
     * only). Release builds omit the symbol; calling this method from
     * a release APK throws [UnsatisfiedLinkError] at invocation time.
     * Kotlin callers must guard with [BuildConfig.DEBUG].
     *
     * Buffer contract: [gray] is a direct [ByteBuffer] with native
     * byte order and capacity `>= height*width*4` bytes, holding
     * row-major float32 `[0, 255]` luma (same as the production
     * `poseVsCachedDirect` input). [featsOut], [kptlogitsOut], and
     * [heatmapOut] are direct [ByteBuffer]s with capacity matching
     * the backbone's `(64, 65, 1)` channel layout at 1/8 stride:
     * `64 * (h/8) * (w/8) * 4`, `65 * (h/8) * (w/8) * 4`, and
     * `(h/8) * (w/8) * 4` bytes respectively. Caller retains
     * ownership; this method writes in place via
     * `GetDirectBufferAddress`.
     *
     * @throws PhotosphereError on any invocation-time failure (invalid
     *     handle, missing model, buffer size mismatch, ORT Run
     *     exception).
     */
    @VisibleForTesting
    suspend fun backboneForwardForTest(
        gray: ByteBuffer,
        featsOut: ByteBuffer,
        kptlogitsOut: ByteBuffer,
        heatmapOut: ByteBuffer,
    ): Unit =
        withContext(dispatcher) {
            require(!closed) { "PhotosphereRunner is closed" }
            val hOut = config.height / BACKBONE_STRIDE
            val wOut = config.width / BACKBONE_STRIDE
            val featsBytes = BACKBONE_FEATS_CHANNELS * hOut * wOut * Float.SIZE_BYTES
            val kptBytes = BACKBONE_KPT_CHANNELS * hOut * wOut * Float.SIZE_BYTES
            val heatBytes = hOut * wOut * Float.SIZE_BYTES
            val grayBytes = config.height * config.width * Float.SIZE_BYTES
            require(gray.isDirect) { "gray must be a direct ByteBuffer" }
            require(gray.capacity() >= grayBytes) {
                "gray capacity must be >= height*width*4 bytes"
            }
            require(featsOut.isDirect) { "featsOut must be a direct ByteBuffer" }
            require(featsOut.capacity() >= featsBytes) {
                "featsOut capacity must be >= $featsBytes bytes"
            }
            require(kptlogitsOut.isDirect) { "kptlogitsOut must be a direct ByteBuffer" }
            require(kptlogitsOut.capacity() >= kptBytes) {
                "kptlogitsOut capacity must be >= $kptBytes bytes"
            }
            require(heatmapOut.isDirect) { "heatmapOut must be a direct ByteBuffer" }
            require(heatmapOut.capacity() >= heatBytes) {
                "heatmapOut capacity must be >= $heatBytes bytes"
            }
            val rc =
                nativeBackboneForwardForTest(
                    nativeHandle,
                    gray,
                    featsOut,
                    kptlogitsOut,
                    heatmapOut,
                )
            if (rc != 0) {
                throw PhotosphereError.fromCode(rc, "backboneForwardForTest failed (rc=$rc)")
            }
        }

    /**
     * Rotates + centre-crops + uniform-scales K to match the pipeline
     * input shape. Thin wrapper over `xfeat_adjust_k` in
     * common/xfeat/intrinsics.c so no logic duplicates into Kotlin.
     *
     * @param orientation 0 = up, 1 = right-down (90 CW), 2 = down (180),
     *     3 = left-down (90 CCW). Values match `xfeat_orientation`.
     */
    fun adjustIntrinsics(
        kRaw: FloatArray,
        orientation: Int,
        inW: Int,
        inH: Int,
        targetW: Int,
        targetH: Int,
    ): FloatArray {
        require(kRaw.size == INTRINSICS_SIZE) { "kRaw must have 9 floats" }
        val out = FloatArray(INTRINSICS_SIZE)
        nativeAdjustK(kRaw, orientation, inW, inH, targetW, targetH, out)
        return out
    }

    /**
     * Asset path that this runner's ORT session was built against, after
     * per-device dispatch and any int8 -> fp32 staging-time fallback.
     * Used by the on-device assertion test to confirm the dispatcher
     * picked the expected artifact for the current board.
     */
    fun currentAssetPath(): String? = config.modelAssetPath

    override fun close() {
        // Route teardown through the same single-worker dispatcher that
        // serialises every native call. runBlocking on a serial dispatcher
        // waits for any in-flight estimatePose / poseVsCached / cacheRef
        // to drain before flipping `closed` and deleting the C ctx — without
        // this fence, a coroutine that already passed `require(!closed)`
        // and is mid-flight in native code would dereference a freed
        // xfeat_ctx.
        runBlocking(dispatcher) {
            if (!closed) {
                closed = true
                nativeDestroy(nativeHandle)
            }
        }
    }

    private fun wrapFloatArrayAsDirect(src: FloatArray): ByteBuffer {
        // Direct + native byte order is the zero-copy path — the JNI
        // layer calls GetDirectBufferAddress and reads the backing
        // memory in place.
        val bb =
            ByteBuffer
                .allocateDirect(src.size * Float.SIZE_BYTES)
                .order(ByteOrder.nativeOrder())
        bb.asFloatBuffer().put(src)
        return bb
    }

    companion object {
        const val INTRINSICS_SIZE: Int = 9

        /** Slot count for [estimatePoseWithTimings]: backbone A, backbone
         *  B, postprocess, match — in that order. */
        const val TIMINGS_SLOTS: Int = 4

        /** Backbone downsampling stride (model produces 1/8-resolution
         *  feature maps for a (H, W) input). */
        const val BACKBONE_STRIDE: Int = 8

        /** Feats output channel count: 64 per the photosphere backbone export. */
        const val BACKBONE_FEATS_CHANNELS: Int = 64

        /** Keypoint logits channel count: 65 per the photosphere backbone export
         *  (64 interior positions + 1 dustbin). */
        const val BACKBONE_KPT_CHANNELS: Int = 65

        init {
            System.loadLibrary("photosphere_native")
        }

        /**
         * Primary entry point. Looks up [PhotosphereConfig.modelAssetPath]
         * inside the consuming app's `assets/` tree, stages it to the
         * app's cache dir (ORT's `.ort` loader wants a filesystem path
         * on Android, not an AAsset stream), then constructs the
         * session with a per-device EP preference.
         *
         * @param context any Android context (typically
         *     `applicationContext`) used to reach the `AssetManager`.
         * @param preferred Preferred execution provider. The JNI layer
         *     may fall back if the device rejects the request;
         *     inspect [actualExecutionProvider] on the returned runner
         *     for the EP that was actually used.
         */
        @JvmStatic
        @JvmOverloads
        fun create(
            context: Context,
            config: PhotosphereConfig = PhotosphereConfig(),
            preferred: PreferredExecutionProvider = pickDefaultEp(),
        ): PhotosphereRunner {
            val chosenAssetPath =
                config.modelAssetPath ?: pickDefaultAssetPath(DeviceInfo.current)
            val resolvedAssetPath = resolveAssetPath(context, chosenAssetPath)
            val resolvedConfig = config.copy(modelAssetPath = resolvedAssetPath)
            val stagedFile = stageAsset(context, resolvedAssetPath)
            val result =
                nativeCreate(
                    stagedFile.absolutePath,
                    resolvedConfig.height,
                    resolvedConfig.width,
                    resolvedConfig.topK,
                    resolvedConfig.nmsThresh,
                    resolvedConfig.minCossim,
                    resolvedConfig.minCheiralityInliers,
                    preferred.ordinal,
                )
            // Native returns (handle, actualEpCode); zero handle means
            // an error was set on the native side and thrown already.
            val handle = result[0]
            val actualEp = ActualExecutionProvider.fromCode(result[1].toInt())
            return PhotosphereRunner(handle, resolvedConfig, actualEp)
        }

        /**
         * Confirms the chosen asset actually ships in `assets/`. When
         * the dispatcher picked int8 but the int8 artifact isn't staged
         * (bring-up builds that predate the M4 asset group), falls back
         * to fp32 silently — same belt-and-braces as the pre-OI-013
         * runner. Explicit caller-pinned paths are NEVER rewritten; an
         * arbitrary missing asset surfaces as [PhotosphereError.AssetMissing].
         */
        private fun resolveAssetPath(
            context: Context,
            preferred: String,
        ): String {
            if (assetExists(context, preferred)) {
                return preferred
            }
            if (preferred == PhotosphereAssets.INT8_480X640 &&
                assetExists(context, PhotosphereAssets.FP32_480X640)
            ) {
                return PhotosphereAssets.FP32_480X640
            }
            throw PhotosphereError.AssetMissing(
                "asset '$preferred' not found in assets/ (int8->fp32 fallback applies only to " +
                    "'${PhotosphereAssets.INT8_480X640}')",
            )
        }

        private fun assetExists(
            context: Context,
            assetPath: String,
        ): Boolean =
            try {
                context.assets.open(assetPath).use { true }
            } catch (_: java.io.IOException) {
                false
            }

        /**
         * Build-without-asset constructor. Feeds the native layer a
         * null model path; the ORT session is not constructed and
         * forward paths return [PhotosphereError.ModelLoadFailed]. The C ctx
         * is still created so Stage 3-6 NOT_IMPLEMENTED round-trips
         * can run — same semantic as iOS's "modelURL == nil" branch
         * in PhotosphereBridge.mm.
         */
        @JvmStatic
        @VisibleForTesting
        fun createWithoutModel(config: PhotosphereConfig): PhotosphereRunner {
            val result =
                nativeCreate(
                    null,
                    config.height,
                    config.width,
                    config.topK,
                    config.nmsThresh,
                    config.minCossim,
                    config.minCheiralityInliers,
                    PreferredExecutionProvider.CPU.ordinal,
                )
            return PhotosphereRunner(
                result[0],
                config,
                ActualExecutionProvider.fromCode(result[1].toInt()),
            )
        }

        /**
         * Default execution provider. XNNPACK runs on every ARMv8-A
         * Android device (e.g. Cortex-A55 on Galaxy XCover 5; Cortex-X3
         * on Pixel 8) and has near-zero session-init cost. Callers can
         * opt in to a vendor accelerator path via the `preferred`
         * argument on [create].
         */
        @JvmStatic
        fun pickDefaultEp(): PreferredExecutionProvider = PreferredExecutionProvider.XNNPACK

        private fun stageAsset(
            context: Context,
            assetPath: String,
        ): File {
            val target = File(context.cacheDir, "photosphere/$assetPath")
            if (target.exists() && target.length() > 0) {
                return target
            }
            target.parentFile?.mkdirs()
            try {
                context.assets.open(assetPath).use { input ->
                    FileOutputStream(target).use { output ->
                        input.copyTo(output)
                    }
                }
            } catch (e: java.io.IOException) {
                val err = PhotosphereError.AssetMissing("asset '$assetPath' not found: ${e.message}")
                err.initCause(e)
                throw err
            }
            return target
        }

        /** Native call returns a 2-element long[] { handle, actualEp }. */
        @JvmStatic private external fun nativeCreate(
            modelPath: String?,
            height: Int,
            width: Int,
            topK: Int,
            nmsThresh: Float,
            minCossim: Float,
            minCheiralityInliers: Int,
            preferredEp: Int,
        ): LongArray

        @JvmStatic private external fun nativeDestroy(handle: Long)

        @JvmStatic private external fun nativeEstimatePose(
            handle: Long,
            grayA: ByteBuffer,
            grayB: ByteBuffer,
            intrinsicsA: FloatArray,
            intrinsicsB: FloatArray,
        ): PhotospherePose?

        @JvmStatic private external fun nativeEstimatePoseWithTimings(
            handle: Long,
            grayA: ByteBuffer,
            grayB: ByteBuffer,
            intrinsicsA: FloatArray,
            intrinsicsB: FloatArray,
            timingsOutMs: DoubleArray,
        ): PhotospherePose?

        @JvmStatic private external fun nativeEstimatePoseFromOutputs(
            handle: Long,
            featsA: ByteBuffer,
            kptlogitsA: ByteBuffer,
            heatmapA: ByteBuffer,
            scaleXA: Float,
            scaleYA: Float,
            featsB: ByteBuffer,
            kptlogitsB: ByteBuffer,
            heatmapB: ByteBuffer,
            scaleXB: Float,
            scaleYB: Float,
            intrinsicsA: FloatArray,
            intrinsicsB: FloatArray,
        ): PhotospherePose?

        // calls the production `xfeat_bind_cached_ref` /
        // `xfeat_match_and_pose_cached` / `xfeat_release_cached_ref`.
        @JvmStatic private external fun nativeCacheRef(
            handle: Long,
            gray: ByteBuffer,
            intrinsics: FloatArray,
        ): Int

        @JvmStatic private external fun nativeReleaseCachedRef(handle: Long)

        @JvmStatic private external fun nativePoseVsCached(
            liveHandle: Long,
            refHandle: Long,
            gray: ByteBuffer,
            intrinsics: FloatArray,
            timingsOutMs: DoubleArray?,
        ): PhotospherePose?

        // Returns Object[5]: [0]=FloatArray liveKpts, [1]=FloatArray refKpts,
        // [2]=IntArray matchIdxLive, [3]=IntArray matchIdxRef,
        // [4]=FloatArray matchCossim. Null on invalid handles.
        @JvmStatic private external fun nativeGetLastMatchRecords(
            liveHandle: Long,
            refHandle: Long,
            topK: Int,
        ): Array<Any>?

        @JvmStatic private external fun nativeAdjustK(
            kRaw: FloatArray,
            orientation: Int,
            inW: Int,
            inH: Int,
            targetW: Int,
            targetH: Int,
            kAdjOut: FloatArray,
        )

        // OI-031 Class B-Android — DEBUG-only. Compiled in only when
        // XFEAT_DEBUG_TEST_HOOKS is defined (debug buildType). Callers
        // must guard with BuildConfig.DEBUG; a release caller hits
        // UnsatisfiedLinkError at invocation time.
        @JvmStatic private external fun nativeBackboneForwardForTest(
            handle: Long,
            gray: ByteBuffer,
            featsOut: ByteBuffer,
            kptlogitsOut: ByteBuffer,
            heatmapOut: ByteBuffer,
        ): Int
    }
}
