package com.twinskin.photosphere

import java.io.File

/**
 * Runtime CPU capabilities the photosphere dispatch consults. Kept as an
 * interface so JVM unit tests can supply a stub (via [pickDefaultAssetPath])
 * without Robolectric or a loaded native library.
 *
 * Capability-based on purpose: behaviour selection MUST follow what the
 * hardware / Android API exposes, never `Build.MODEL`. New devices then
 * pick up the right code path the day they ship, without an SDK update.
 */
internal interface DeviceInfo {
    /**
     * True when the CPU advertises ARMv8.4-A SDOT/UDOT (the kernel's
     * `asimddp` HWCAP). The dot-product instructions roughly halve INT8
     * GEMM latency vs. the ARMv8.2 baseline, which is what makes the
     * quantised XFeat backbone fit the per-frame budget; cores without
     * SDOT (e.g. Cortex-A55 in Exynos 850 / Galaxy XCover 5) get the FP32
     * backbone instead.
     */
    val hasArmDotProduct: Boolean

    companion object {
        val current: DeviceInfo =
            object : DeviceInfo {
                override val hasArmDotProduct: Boolean by lazy { probeArmDotProduct() }
            }
    }
}

/**
 * Parses `/proc/cpuinfo` for the kernel-reported `asimddp` HWCAP. World-
 * readable on every Android version that ships ARMv8 (API 21+), and the
 * cheapest available probe — no JNI, no `getauxval` shim. Returns false
 * on any read error so the dispatcher errs on the safe (FP32) side.
 */
private fun probeArmDotProduct(): Boolean =
    runCatching {
        File("/proc/cpuinfo").useLines { parseAsimddpHwcap(it) }
    }.getOrDefault(false)

/**
 * Pure parser for the `Features` line of `/proc/cpuinfo` on aarch64.
 * Returns true if any `Features` line lists `asimddp` as a whole token.
 * Tokenised on space + tab so a partial match like `asimddpx` does not
 * trigger; multi-block /proc/cpuinfo (one block per online CPU) reports
 * the same baseline features on every core on every shipping ARMv8.4-A
 * SoC, so the any-line semantic is safe.
 */
internal fun parseAsimddpHwcap(lines: Sequence<String>): Boolean =
    lines.any { line ->
        line.startsWith("Features") && line.split(' ', '\t').any { it == "asimddp" }
    }

/**
 * Default backbone variant. INT8 when the CPU exposes the ARMv8.4 dot-
 * product instructions (e.g. Cortex-X3 + A715 on Pixel 8); FP32
 * otherwise (e.g. Cortex-A55 on Galaxy XCover 5). Lives as a top-level
 * function rather than on [PhotosphereRunner]'s companion because the
 * companion's `init` block calls `System.loadLibrary("photosphere_native")`,
 * which JVM unit tests can't resolve.
 */
internal fun pickDefaultAssetPath(device: DeviceInfo): String =
    if (device.hasArmDotProduct) {
        PhotosphereAssets.INT8_480X640
    } else {
        PhotosphereAssets.FP32_480X640
    }
