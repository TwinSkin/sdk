package com.twinskin.photosphere

import java.io.Closeable

/**
 * Decouples the OnTarget hold time from the analyser-tick cadence so a
 * slow tick rate doesn't cap per-arm latency: observe calls come from
 * the analyser tick, but [passedAt] is polled on a wall-clock cadence.
 *
 * Thread-safety: every observe / query call and [close] is serialised
 * on the same monitor (`this`). The two paths run on different
 * dispatchers (analyser tick vs the session's shutter scope), so the
 * monitor is what prevents a TOCTOU where [close] frees the native
 * handle between a load and the native call below.
 */
class DwellTracker(
    val minDwellMs: Int,
    val failGuardMs: Int = PhotosphereMath.failGuardMs.toInt(),
) : Closeable {
    // Guarded by `this`. 0 == closed; native ABI no-ops on a zero handle
    // but we don't even take that branch — the monitor turns close() into
    // an ordered fence rather than a sentinel race.
    private var handle: Long = nativeDwellTrackerNewWithFailGuard(minDwellMs, failGuardMs)

    init {
        check(handle != 0L) {
            "xfeat_dwell_tracker_new returned NULL (alloc failure?)"
        }
    }

    /**
     * First call after [observeOffTarget] starts the dwell window.
     * `nowNs` must come from a monotonic clock (use
     * [android.os.SystemClock.elapsedRealtimeNanos]).
     */
    @Synchronized
    fun observeOnTarget(nowNs: Long) {
        if (handle == 0L) return
        nativeDwellTrackerObserveOnTarget(handle, nowNs)
    }

    /** Resets the dwell window so the next [observeOnTarget] starts a fresh budget. */
    @Synchronized
    fun observeOffTarget(nowNs: Long) {
        if (handle == 0L) return
        nativeDwellTrackerObserveOffTarget(handle, nowNs)
    }

    /**
     * Call from a wall-clock poller, NOT from the analyser-tick callback —
     * the whole point of this class is to decouple the two.
     */
    @Synchronized
    fun passedAt(queryNs: Long): Boolean {
        if (handle == 0L) return false
        return nativeDwellTrackerPassedAt(handle, queryNs)
    }

    /**
     * Returns [Long.MAX_VALUE] when no off-target has ever been observed,
     * which the failure-mode guard treats as "no recent FAIL to reject on".
     */
    @Synchronized
    fun msSinceOffTarget(nowNs: Long): Long {
        if (handle == 0L) return Long.MAX_VALUE
        return nativeDwellTrackerMsSinceOffTarget(handle, nowNs)
    }

    @Synchronized
    override fun close() {
        val h = handle
        if (h == 0L) return
        handle = 0L
        nativeDwellTrackerFree(h)
    }

    companion object {
        init {
            // Soft-fail on the host JVM so unit-test class-init doesn't blow up;
            // first real JNI call will throw if loading actually failed.
            try {
                System.loadLibrary("photosphere_native")
            } catch (_: UnsatisfiedLinkError) {
            }
        }

        @JvmStatic
        private external fun nativeDwellTrackerNew(minDwellMs: Int): Long

        @JvmStatic
        private external fun nativeDwellTrackerNewWithFailGuard(
            minDwellMs: Int,
            failGuardMs: Int,
        ): Long

        @JvmStatic
        private external fun nativeDwellTrackerFree(handle: Long)

        @JvmStatic
        private external fun nativeDwellTrackerObserveOnTarget(
            handle: Long,
            nowNs: Long,
        )

        @JvmStatic
        private external fun nativeDwellTrackerObserveOffTarget(
            handle: Long,
            nowNs: Long,
        )

        @JvmStatic
        private external fun nativeDwellTrackerPassedAt(
            handle: Long,
            queryNs: Long,
        ): Boolean

        @JvmStatic
        private external fun nativeDwellTrackerMsSinceOffTarget(
            handle: Long,
            nowNs: Long,
        ): Long
    }
}
