package com.twinskin.photosphere

/**
 * JNI surface for photosphere math primitives. Holds zero algorithmic
 * logic — every method round-trips into C. The bridge marshals
 * fixed-point integers for the arm-target azimuth / tilt-phi outputs;
 * the underlying geometry produces multiples of 0.0625° so the 1e-3
 * deg quantum is exact.
 */
object PhotosphereMath {
    /**
     * Tilt decomposition of a row-major 3x3 rotation.
     *
     * @param rotation length-9 `float` array, row-major (as returned
     *     by `PhotospherePose.rotation`).
     * @return `(tilt_mag_deg, tilt_phi_deg)` with `tilt_mag_deg` in
     *     `[0, 180]` and `tilt_phi_deg` in `[0, 360)`.
     * @throws PhotosphereError on invalid input (propagated from the C ABI).
     */
    fun tiltFromRotation(rotation: FloatArray): Pair<Float, Float> {
        require(rotation.size == ROTATION_SIZE) { "rotation must have size $ROTATION_SIZE" }
        val out = FloatArray(TILT_OUT_SIZE)
        val rc = nativeTiltFromRotation(rotation, out)
        if (rc != 0) {
            throw PhotosphereError.fromCode(rc, "xfeat_tilt_from_rotation rc=$rc")
        }
        return out[0] to out[1]
    }

    /**
     * Great-circle distance between two `(tilt_mag, tilt_phi)` pairs
     * on the unit sphere, in degrees. Thin wrapper over
     * `xfeat_great_circle_distance_deg`.
     */
    fun greatCircleDistanceDeg(
        magADeg: Float,
        phiADeg: Float,
        magBDeg: Float,
        phiBDeg: Float,
    ): Float {
        val d = nativeGreatCircleDistanceDeg(magADeg, phiADeg, magBDeg, phiBDeg)
        // -1f is the JNI sentinel for an internal error from the C ABI;
        // a same-input call short-circuits to 0 inside the C function so
        // we never expect to see -1 in production with valid inputs.
        // Surface as IllegalStateException so a regression in the bridge
        // does not silently propagate a bogus distance.
        check(d >= 0f) { "nativeGreatCircleDistanceDeg returned sentinel error" }
        return d
    }

    /**
     * `round` is 1-based, `1..8` (1..4 primary, 5..8 bonus). Throws
     * [IllegalArgumentException] for out-of-range inputs.
     */
    fun armTargetMake(
        round: Int,
        armIndex: Int,
    ): ArmTarget {
        val packed = nativeArmTargetMake(round, armIndex)
        require(packed != null && packed.size == ARM_TARGET_PACK_SIZE) {
            "armTargetMake invalid (round=$round arm=$armIndex)"
        }
        return ArmTarget.unpack(packed)
    }

    /**
     * Inverse of [armTargetMake] — recover `(round, armIndex, ...)`
     * from a `view_index` in `0..31`.
     */
    fun armTargetFromViewIndex(viewIndex: Int): ArmTarget {
        val packed = nativeArmTargetFromViewIndex(viewIndex)
        require(packed != null && packed.size == ARM_TARGET_PACK_SIZE) {
            "armTargetFromViewIndex invalid (viewIndex=$viewIndex)"
        }
        return ArmTarget.unpack(packed)
    }

    /**
     * Source-compat shim — new code should use
     * [armTargetMake] / [ArmTarget.tiltPhiDeg] directly.
     *
     * `round0` is 0-indexed `0..7` (= round-1).
     */
    fun armTargetPhiDeg(
        round0: Int,
        arm: Int,
    ): Float {
        require(round0 in 0 until MAX_ROUND_COUNT) {
            "round0 must be in 0 until $MAX_ROUND_COUNT"
        }
        require(arm in 0 until ARMS_PER_ROUND) { "arm must be in 0 until $ARMS_PER_ROUND" }
        return armTargetMake(round = round0 + 1, armIndex = arm).tiltPhiDeg
    }

    /**
     * Pick the uncaptured arm closest to the measured tilt within a
     * single round. `round0` is 0-indexed `0..7`. Returns `null` when
     * every arm in the round is already captured.
     *
     * Thin wrapper over `xfeat_arm_pick_nearest` with `round_filter ==
     * round0 + 1`.
     */
    fun pickTargetArm(
        round0: Int,
        capturedGlobalIndices: Set<Int>,
        measuredMagDeg: Float,
        measuredPhiDeg: Float,
    ): ArmPick? =
        pickTargetArmInternal(
            roundFilter = round0 + 1,
            capturedGlobalIndices = capturedGlobalIndices,
            measuredMagDeg = measuredMagDeg,
            measuredPhiDeg = measuredPhiDeg,
        )

    /**
     * Free-capture variant of [pickTargetArm]: search every uncaptured
     * arm across rounds 1..8 (mirrors iOS `nearestUncapturedArmGlobal`).
     */
    fun pickTargetArmGlobal(
        capturedGlobalIndices: Set<Int>,
        measuredMagDeg: Float,
        measuredPhiDeg: Float,
    ): ArmPick? =
        pickTargetArmInternal(
            roundFilter = 0,
            capturedGlobalIndices = capturedGlobalIndices,
            measuredMagDeg = measuredMagDeg,
            measuredPhiDeg = measuredPhiDeg,
        )

    private fun pickTargetArmInternal(
        roundFilter: Int,
        capturedGlobalIndices: Set<Int>,
        measuredMagDeg: Float,
        measuredPhiDeg: Float,
    ): ArmPick? {
        val captured = capturedGlobalIndices.toIntArray()
        val packed =
            nativeArmPickNearest(captured, roundFilter, measuredMagDeg, measuredPhiDeg)
                ?: return null
        require(packed.size == 4) { "nativeArmPickNearest returned malformed array" }
        val target = armTargetFromViewIndex(packed[2])
        val distanceDeg = packed[3] / FIXED_POINT_DEG
        return ArmPick(
            arm = packed[1],
            targetPhiDeg = target.tiltPhiDeg,
            distanceDeg = distanceDeg,
            round = packed[0],
            viewIndex = packed[2],
            isBonus = target.isBonus,
        )
    }

    /** Result of [pickTargetArm] / [pickTargetArmGlobal]. */
    data class ArmPick(
        /** 0-indexed arm within the round. */
        val arm: Int,
        /** Canonical `phi` the arm lives at (degrees). */
        val targetPhiDeg: Float,
        /** Great-circle distance from measured to target (degrees). */
        val distanceDeg: Float,
        /** 1-indexed round (1..8). */
        val round: Int = 0,
        /** Global `view_index` (0..31). */
        val viewIndex: Int = 0,
        /** True for `view_index >= 16` (bonus rounds 5..8). */
        val isBonus: Boolean = false,
    )

    /** Fully resolved arm geometry for `(round, armIndex)`. */
    data class ArmTarget(
        val round: Int,
        val armIndex: Int,
        val viewIndex: Int,
        val azimuthDeg: Float,
        val tiltPhiDeg: Float,
        val isBonus: Boolean,
    ) {
        companion object {
            internal fun unpack(packed: IntArray): ArmTarget =
                ArmTarget(
                    round = packed[0],
                    armIndex = packed[1],
                    viewIndex = packed[2],
                    azimuthDeg = packed[3] / FIXED_POINT_DEG,
                    tiltPhiDeg = packed[4] / FIXED_POINT_DEG,
                    isBonus = packed[5] != 0,
                )
        }
    }

    /**
     * Pure-function state-machine transition for the photosphere
     * aiming stage. Routes through `xfeat_aiming_transition` so iOS
     * and Android share the exact dwell semantics.
     *
     * Terminal stages (`Capturing`, `RoundComplete`, `Done`, `Aborted`)
     * are handled by the Kotlin facade — the C ABI only models the
     * dwell-relevant trio (`AIMING`, `ON_TARGET`, `CAPTURING`); higher-
     * level stages pass through unchanged.
     */
    fun nextAimingStage(
        stage: PhotosphereState.Stage,
        round: Int,
        targetArm: Int,
        onTarget: Boolean,
        nowNanos: Long,
    ): PhotosphereState.Stage {
        // Pass-through stages stay outside the C state machine.
        when (stage) {
            is PhotosphereState.Stage.Capturing,
            is PhotosphereState.Stage.RoundComplete,
            is PhotosphereState.Stage.Done,
            is PhotosphereState.Stage.Aborted,
            -> return stage

            else -> Unit
        }
        // Pack the prior state into the (kind, round, arm, startNs, holdMs)
        // tuple the C ABI consumes. RefCapture / RoundWaiting / Aiming all
        // map to AIMING with start_ns = 0; only OnTarget contributes
        // dwell-state bookkeeping.
        val prevKind: Int
        val prevRound: Int
        val prevTargetArm: Int
        val prevStartNs: Long
        val prevHoldMs: Int
        when (stage) {
            is PhotosphereState.Stage.OnTarget -> {
                prevKind = STAGE_KIND_ON_TARGET
                prevRound = stage.round
                prevTargetArm = stage.targetArm
                prevStartNs = stage.startNanos
                prevHoldMs = stage.holdMs
            }
            else -> {
                prevKind = STAGE_KIND_AIMING
                prevRound = round
                prevTargetArm = targetArm
                prevStartNs = 0L
                prevHoldMs = 0
            }
        }
        val packed =
            nativeAimingTransition(
                prevKind,
                prevRound,
                prevTargetArm,
                prevStartNs,
                prevHoldMs,
                round,
                targetArm,
                onTarget,
                nowNanos,
                dwellMs.toInt(),
            )
        require(packed.size == AIMING_PACK_SIZE) {
            "nativeAimingTransition returned malformed array"
        }
        val nextKind = packed[0].toInt()
        val nextRound = packed[1].toInt()
        val nextArm = packed[2].toInt()
        val nextStartNs = packed[3]
        val nextHoldMs = packed[4].toInt()
        return when (nextKind) {
            STAGE_KIND_ON_TARGET ->
                PhotosphereState.Stage.OnTarget(
                    round = nextRound,
                    targetArm = nextArm,
                    startNanos = nextStartNs,
                    holdMs = nextHoldMs,
                )
            STAGE_KIND_CAPTURING ->
                PhotosphereState.Stage.Capturing(round = nextRound, targetArm = nextArm)
            else ->
                PhotosphereState.Stage.Aiming(round = nextRound, targetArm = nextArm)
        }
    }

    /** Apply a diagonal `(sx, sy, 1)` scale to a row-major 3x3 K. */
    fun scaleKDiagonal(
        kIn: FloatArray,
        sx: Float,
        sy: Float,
    ): FloatArray {
        require(kIn.size == K_SIZE) { "kIn must have $K_SIZE floats" }
        val out =
            nativeScaleKDiagonal(kIn, sx, sy)
                ?: error("nativeScaleKDiagonal returned null (rc=invalid arg?)")
        return out
    }

    /** Build the pinhole fallback K (`fx=w, fy=h, cx=w/2, cy=h/2`). */
    fun pinholeFallbackK(
        width: Int,
        height: Int,
    ): FloatArray {
        val out =
            nativePinholeFallbackK(width, height)
                ?: error("nativePinholeFallbackK returned null")
        return out
    }

    /**
     * Internal Kotlin delegators for the blur-gate native primitives. The
     * native side is `private external`; the JNI symbol-mangling rules
     * append `$xfeat_debug` to `internal external` declarations, so the
     * native lookup needs `private external` to match the unmangled
     * `Java_..._nativeBlurGate*` symbols. The trampolines below keep the
     * Kotlin-visible API package-internal without losing the JNI binding.
     */
    internal fun blurGateNew(): Long = nativeBlurGateNew()

    internal fun blurGateFree(handle: Long) = nativeBlurGateFree(handle)

    internal fun blurGateReset(handle: Long) = nativeBlurGateReset(handle)

    internal fun blurGateAdmit(
        handle: Long,
        sample: Float,
    ): Int = nativeBlurGateAdmit(handle, sample)

    /**
     * Sourced from the shared C constant via JNI so iOS, Android, and
     * the C state machine can't drift.
     */
    val tiltMinMagDeg: Float get() = nativeTiltMinMagDeg()

    /** First-round tilt floor — the establishing "first cross" requires a
     * higher tilt than the steady-state rounds. */
    val tiltMinMagDegFirstRound: Float get() = nativeTiltMinMagDegFirstRound()

    val tiltMaxMagDeg: Float get() = nativeTiltMaxMagDeg()

    val polePhiSuppressMagDeg: Float get() = nativePolePhiSuppressMagDeg()

    val roundCompleteDwellMs: Long get() = nativeRoundCompleteDwellMs().toLong()

    val dwellPollPeriodMs: Long get() = nativeDwellPollPeriodMs().toLong()

    val failGuardMs: Long get() = nativeFailGuardMs().toLong()

    /** Single-ring elevation: every primary arm lives on the 20° latitude. */
    const val TARGET_TILT_MAG_DEG: Float = 20.0f

    /** On-target predicate threshold — distance ≤ this fires dwell. */
    const val ON_TARGET_DISTANCE_DEG: Float = 3.0f

    /**
     * The Android dwell floor is platform-bounded by shutter-call p99
     * and is fundamentally different from the iOS floor
     * (`XFEAT_MIN_DWELL_MS_IOS`); the two constants must NOT be unified.
     */
    val dwellMs: Long get() = nativeMinDwellMsAndroid().toLong()

    /** Analyser input width (`XFEAT_ANALYSER_WIDTH_DEFAULT`).
     *  Must match the exported `.ort` input shape. */
    val analyserWidthDefault: Int get() = nativeAnalyserWidthDefault()

    /** Analyser input height (`XFEAT_ANALYSER_HEIGHT_DEFAULT`).
     *  Must match the exported `.ort` input shape. */
    val analyserHeightDefault: Int get() = nativeAnalyserHeightDefault()

    /** JPEG re-compression target size in KB
     *  (`XFEAT_COMPRESSION_TARGET_KB_DEFAULT`). */
    val compressionTargetKbDefault: Int get() = nativeCompressionTargetKbDefault()

    /** First-pass JPEG quality (0-100). */
    val jpegQualityPass1Default: Int get() = nativeJpegQualityPass1Default()

    /** Second-pass JPEG quality (0-100). */
    val jpegQualityPass2Default: Int get() = nativeJpegQualityPass2Default()

    /** Intermediate-pass JPEG quality (0-100), between Pass2 and Min. */
    val jpegQualityIntermediateDefault: Int get() = nativeJpegQualityIntermediateDefault()

    /** Minimum JPEG quality floor (0-100). */
    val jpegQualityMinDefault: Int get() = nativeJpegQualityMinDefault()

    /** Ref-image JPEG quality (0-100). Maximum quality, no size cap. */
    val jpegQualityRefDefault: Int get() = nativeJpegQualityRefDefault()

    /** Single-ring elevation (degrees) for every photosphere arm. */
    val refElevationDegDefault: Float get() = nativeRefElevationDegDefault()

    /** Number of arms per round (4-way cross). */
    const val ARMS_PER_ROUND: Int = 4

    /** Primary round count (rounds 1..4). */
    const val PRIMARY_ROUND_COUNT: Int = 4

    /** Maximum round count (rounds 1..8 — 4 primary + 4 bonus). */
    const val MAX_ROUND_COUNT: Int = 8

    /** 16 primary (rounds 1..4) + 16 bonus (rounds 5..8). */
    const val TOTAL_ARM_COUNT: Int = 32

    /** Primary arm count (rounds 1..4 × 4 arms). Lock-after-capture
     *  contract gates the `Done` transition on this count, not the
     *  total. */
    const val PRIMARY_ARM_COUNT: Int = 16

    const val BIN_COUNT: Int = 16

    // `by lazy` — the `init { System.loadLibrary }` block lives further
    // down this object; eager initialisation here triggers an
    // UnsatisfiedLinkError on the first `<clinit>` (the property
    // initialiser runs before init blocks declared later).
    val BIN_OF_VIEW_INDEX: List<Int> by lazy {
        List(TOTAL_ARM_COUNT) { idx -> nativeBinOfViewIndex(idx) }
    }

    fun binsCovered(captured: Set<Int>): Int {
        if (captured.isEmpty()) return 0
        val seen = HashSet<Int>(BIN_COUNT)
        for (idx in captured) {
            if (idx in 0 until TOTAL_ARM_COUNT) seen.add(BIN_OF_VIEW_INDEX[idx])
        }
        return seen.size
    }

    /** Legacy source-compat alias. New code should pick
     *  [PRIMARY_ROUND_COUNT] or [MAX_ROUND_COUNT] explicitly. */
    @Deprecated(
        "Use PRIMARY_ROUND_COUNT or MAX_ROUND_COUNT depending on bonus-arm scope",
        ReplaceWith("PRIMARY_ROUND_COUNT"),
    )
    const val ROUND_COUNT: Int = PRIMARY_ROUND_COUNT

    private const val ROTATION_SIZE: Int = 9
    private const val TILT_OUT_SIZE: Int = 2
    private const val K_SIZE: Int = 9
    private const val ARM_TARGET_PACK_SIZE: Int = 6
    private const val AIMING_PACK_SIZE: Int = 5
    private const val FIXED_POINT_DEG: Float = 1000.0f

    // Mirrors xfeat_aiming_stage_kind in xfeat_photosphere.h.
    private const val STAGE_KIND_AIMING: Int = 0
    private const val STAGE_KIND_ON_TARGET: Int = 1
    private const val STAGE_KIND_CAPTURING: Int = 2

    init {
        // Shares libphotosphere_native.so with PhotosphereRunner / MarkerRefine; a
        // no-op when one of them loaded it first, but keeps this object
        // usable standalone. Soft-fails on the host JVM (unit-test
        // classpath) so pure-Kotlin callers fail at first JNI use rather
        // than at object init. The native round-trip lives in
        // androidTest (JNI-anchored).
        try {
            System.loadLibrary("photosphere_native")
        } catch (_: UnsatisfiedLinkError) {
            // Leave JNI unloaded — first native call throws.
        }
    }

    /** Toggle the native core's verbose diagnostic dumps; the
     *  session drives this from verboseFrameLogs. */
    @JvmStatic
    fun setDiagnosticsEnabled(enabled: Boolean) = nativeSetDiagnosticsEnabled(enabled)

    @JvmStatic private external fun nativeSetDiagnosticsEnabled(enabled: Boolean)

    @JvmStatic private external fun nativeTiltFromRotation(
        rotation: FloatArray,
        outMagPhi: FloatArray,
    ): Int

    @JvmStatic private external fun nativeGreatCircleDistanceDeg(
        magADeg: Float,
        phiADeg: Float,
        magBDeg: Float,
        phiBDeg: Float,
    ): Float

    @JvmStatic private external fun nativeArmTargetMake(
        round: Int,
        armIndex: Int,
    ): IntArray?

    @JvmStatic private external fun nativeArmTargetFromViewIndex(viewIndex: Int): IntArray?

    @JvmStatic private external fun nativeBinOfViewIndex(viewIndex: Int): Int

    @JvmStatic private external fun nativeArmPickNearest(
        capturedViewIndices: IntArray,
        roundFilter: Int,
        measuredMagDeg: Float,
        measuredPhiDeg: Float,
    ): IntArray?

    @JvmStatic private external fun nativeAimingTransition(
        prevKind: Int,
        prevRound: Int,
        prevTargetArm: Int,
        prevStartNs: Long,
        prevHoldMs: Int,
        round: Int,
        targetArm: Int,
        onTarget: Boolean,
        nowNs: Long,
        dwellMs: Int,
    ): LongArray

    @JvmStatic private external fun nativeBlurGateNew(): Long

    @JvmStatic private external fun nativeBlurGateFree(handle: Long)

    @JvmStatic private external fun nativeBlurGateReset(handle: Long)

    @JvmStatic private external fun nativeBlurGateAdmit(
        handle: Long,
        sample: Float,
    ): Int

    @JvmStatic private external fun nativeScaleKDiagonal(
        kIn: FloatArray,
        sx: Float,
        sy: Float,
    ): FloatArray?

    @JvmStatic private external fun nativePinholeFallbackK(
        w: Int,
        h: Int,
    ): FloatArray?

    @JvmStatic private external fun nativeTiltMinMagDeg(): Float

    @JvmStatic private external fun nativeTiltMinMagDegFirstRound(): Float

    @JvmStatic private external fun nativeTiltMaxMagDeg(): Float

    @JvmStatic private external fun nativePolePhiSuppressMagDeg(): Float

    @JvmStatic private external fun nativeRoundCompleteDwellMs(): Int

    @JvmStatic private external fun nativeDwellPollPeriodMs(): Int

    @JvmStatic private external fun nativeFailGuardMs(): Int

    @JvmStatic private external fun nativeMinDwellMsAndroid(): Int

    @JvmStatic private external fun nativeAnalyserWidthDefault(): Int

    @JvmStatic private external fun nativeAnalyserHeightDefault(): Int

    @JvmStatic private external fun nativeCompressionTargetKbDefault(): Int

    @JvmStatic private external fun nativeJpegQualityPass1Default(): Int

    @JvmStatic private external fun nativeJpegQualityPass2Default(): Int

    @JvmStatic private external fun nativeJpegQualityIntermediateDefault(): Int

    @JvmStatic private external fun nativeJpegQualityMinDefault(): Int

    @JvmStatic private external fun nativeJpegQualityRefDefault(): Int

    @JvmStatic private external fun nativeRefElevationDegDefault(): Float
}
