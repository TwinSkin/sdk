package com.twinskin.photosphere

import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureResult

/**
 * Camera2 -> K helpers.
 *
 * K source priority (see docs/06 § "K source priority (per-device)"):
 *   Priority 1. Per-frame `LENS_INTRINSIC_CALIBRATION` from
 *     [CaptureResult] when the device advertises the calibration API.
 *   Priority 2. Static `LENS_INTRINSIC_CALIBRATION` from
 *     [CameraCharacteristics].
 *   Priority 3. 65° pinhole fallback. Rotation bias up to 5°,
 *     translation direction error up to 15°; smoke-test grade only.
 *
 * The [resolveK] entry point walks the priority order and returns the
 * first source that yields a usable 3x3.
 */
object Camera2Intrinsics {
    /**
     * Read the K array from a [CaptureResult] if the device exposes
     * per-frame calibration. Returns null when the field is missing.
     */
    fun readPerFrameK(result: CaptureResult): FloatArray? {
        val k = result.get(CaptureResult.LENS_INTRINSIC_CALIBRATION) ?: return null
        return intrinsic5ToK(k)
    }

    /**
     * Read the static K from [CameraCharacteristics] when the device
     * exposes a factory-calibrated K in sensor-active pixel coordinates.
     */
    fun readStaticK(chars: CameraCharacteristics): FloatArray? {
        val k = chars.get(CameraCharacteristics.LENS_INTRINSIC_CALIBRATION) ?: return null
        return intrinsic5ToK(k)
    }

    /**
     * Walk the priority order. The [perFrame] argument is the result of
     * [readPerFrameK] on the most recent frame (may be null). [chars]
     * is passed through so we can look up the static K when the
     * per-frame field is missing but the camera still advertises a
     * calibration. [pipelineW] / [pipelineH] are the photosphere input shape
     * used for the 65° pinhole fallback only.
     *
     * The returned [KResolution] carries the native frame the K is
     * expressed in (`nativeWidth` / `nativeHeight`). This is critical:
     * `xfeat_adjust_k` assumes K is already in `(inW × inH)` coords,
     * and feeding it a sensor-active K with bitmap dims would slide the
     * principal point outside the pipeline frame — the Stage-6
     * cheirality-0 class of bug.
     */
    fun resolveK(
        perFrame: FloatArray?,
        chars: CameraCharacteristics?,
        pipelineW: Int,
        pipelineH: Int,
    ): KResolution {
        val sensorActive = chars?.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
        if (perFrame != null) {
            val nw = sensorActive?.width() ?: pipelineW
            val nh = sensorActive?.height() ?: pipelineH
            return KResolution(perFrame, KSource.PER_FRAME_LENS_INTRINSIC, nw, nh)
        }
        val staticK = chars?.let { readStaticK(it) }
        if (staticK != null) {
            val nw = sensorActive?.width() ?: pipelineW
            val nh = sensorActive?.height() ?: pipelineH
            return KResolution(staticK, KSource.STATIC_LENS_INTRINSIC, nw, nh)
        }
        return KResolution(
            PhotosphereFixtures.pinhole65Degrees(pipelineW, pipelineH),
            KSource.PINHOLE_65DEG_FALLBACK,
            pipelineW,
            pipelineH,
        )
    }

    /** `LENS_INTRINSIC_CALIBRATION` is `[fx, fy, cx, cy, s]`; we drop s
     *  (skew; zero on every phone camera we target) and emit the 3x3. */
    private fun intrinsic5ToK(k: FloatArray): FloatArray {
        require(k.size == INTRINSIC_CALIBRATION_SIZE) {
            "LENS_INTRINSIC_CALIBRATION must have 5 elements"
        }
        return floatArrayOf(
            k[0],
            0.0f,
            k[2],
            0.0f,
            k[1],
            k[3],
            0.0f,
            0.0f,
            1.0f,
        )
    }

    private const val INTRINSIC_CALIBRATION_SIZE = 5
}

/** Where the resolved K ultimately came from — useful for telemetry. */
enum class KSource {
    PER_FRAME_LENS_INTRINSIC,
    STATIC_LENS_INTRINSIC,
    PINHOLE_65DEG_FALLBACK,
}

/**
 * Carries the resolved K plus the native frame the K is expressed in.
 *
 * `xfeat_adjust_k` (common/xfeat/intrinsics.c) trusts that K is already
 * in `(inW × inH)` pixel coords and performs rotate → centre-crop →
 * uniform-scale in that frame. A sensor-active K must be paired with
 * the sensor's active-array dims; the [nativeWidth] / [nativeHeight]
 * pair is the authoritative (inW, inH) to pass into `adjustIntrinsics`.
 */
data class KResolution(
    val kMatrix: FloatArray,
    val source: KSource,
    val nativeWidth: Int,
    val nativeHeight: Int,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is KResolution) return false
        if (!kMatrix.contentEquals(other.kMatrix)) return false
        if (source != other.source) return false
        if (nativeWidth != other.nativeWidth) return false
        return nativeHeight == other.nativeHeight
    }

    override fun hashCode(): Int {
        var result = kMatrix.contentHashCode()
        result = 31 * result + source.hashCode()
        result = 31 * result + nativeWidth
        result = 31 * result + nativeHeight
        return result
    }
}
