package com.twinskin.photosphere

import org.json.JSONObject

/** Lexicographic-keys serializer — keeps Android's `Exif.UserComment`
 *  payload byte-for-byte identical to iOS's
 *  `JSONSerialization(..., options: [.sortedKeys])`. */
internal object SortedJson {
    fun stringify(obj: JSONObject): String = sortObject(obj).toString()

    private fun sortObject(obj: JSONObject): JSONObject {
        val sorted = JSONObject()
        for (key in obj.keys().asSequence().toList().sorted()) {
            val value = obj.opt(key)
            sorted.put(key, if (value is JSONObject) sortObject(value) else value)
        }
        return sorted
    }
}
