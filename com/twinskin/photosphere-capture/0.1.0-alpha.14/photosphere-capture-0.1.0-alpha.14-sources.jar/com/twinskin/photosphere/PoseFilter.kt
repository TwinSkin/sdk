package com.twinskin.photosphere

import java.io.Closeable

/**
 * Kotlin wrapper around the `xfeat_pose_filter_*` C ABI; `enabled = false`
 * is a no-op passthrough so the live-pose path can call observe/query
 * unconditionally.
 */
class PoseFilter(enabled: Boolean) : Closeable {
    // 0 == disabled / closed.
    private var handle: Long = if (enabled) nativePoseFilterNew() else 0L
    private var hasValidObservation: Boolean = false

    // Reused @Synchronized scratch buffers for the JNI query output.
    private val queryFloats = FloatArray(PHOTOSPHERE_POSE_FILTER_QUERY_LENGTH)
    private val queryInts = IntArray(2)

    val isEnabled: Boolean
        get() = handle != 0L

    @Synchronized
    fun observe(pose: PhotospherePose, nowNs: Long) {
        val h = handle
        if (h == 0L) return
        nativePoseFilterObserve(
            h,
            pose.rotation,
            pose.translation[0],
            pose.translation[1],
            pose.translation[2],
            pose.numMatches,
            pose.numInliers,
            pose.confidence,
            nowNs,
        )
        hasValidObservation = true
    }

    @Synchronized
    fun query(): PhotospherePose? {
        val h = handle
        if (h == 0L || !hasValidObservation) return null
        val ok = nativePoseFilterQuery(h, queryFloats, queryInts)
        if (!ok) return null
        val rotation = FloatArray(9)
        System.arraycopy(queryFloats, 0, rotation, 0, 9)
        val translation = floatArrayOf(queryFloats[9], queryFloats[10], queryFloats[11])
        return PhotospherePose(
            rotation = rotation,
            translation = translation,
            numMatches = queryInts[0],
            numInliers = queryInts[1],
            confidence = queryFloats[12],
        )
    }

    @Synchronized
    fun reset() {
        val h = handle
        if (h == 0L) return
        nativePoseFilterReset(h)
        hasValidObservation = false
    }

    @Synchronized
    override fun close() {
        val h = handle
        if (h == 0L) return
        handle = 0L
        nativePoseFilterFree(h)
    }

    companion object {
        const val PHOTOSPHERE_POSE_FILTER_QUERY_LENGTH = 13

        init {
            // Soft-fail mirrors DwellTracker so host-JVM unit tests
            // don't blow up at class init.
            try {
                System.loadLibrary("photosphere_native")
            } catch (_: UnsatisfiedLinkError) {
            }
        }

        @JvmStatic
        private external fun nativePoseFilterNew(): Long

        @JvmStatic
        private external fun nativePoseFilterFree(handle: Long)

        @JvmStatic
        private external fun nativePoseFilterReset(handle: Long)

        @JvmStatic
        private external fun nativePoseFilterObserve(
            handle: Long,
            rotation: FloatArray,
            t0: Float,
            t1: Float,
            t2: Float,
            numMatches: Int,
            numInliers: Int,
            confidence: Float,
            nowNs: Long,
        )

        /** Fills [floatsOut] (length 13) and [intsOut] (length 2); false when no valid observation yet. */
        @JvmStatic
        private external fun nativePoseFilterQuery(
            handle: Long,
            floatsOut: FloatArray,
            intsOut: IntArray,
        ): Boolean
    }
}
