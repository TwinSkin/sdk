package com.twinskin.sdk

import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.SdkCaptureMetadata

/**
 * Metadata required to start a capture. Mirrors iOS `CaptureMetadata`
 * (see `sdk-ios/Sources/CaptureMetadata.swift`).
 *
 * `conditionType` is required — it picks the server-side downstream
 * pipeline (wound vs. other), so there is no safe default.
 *
 * The `custom` JSON field on the underlying [SdkCaptureMetadata] is not
 * exposed here — its `Map<String, JsonElement>` type would force the
 * kotlinx-serialization-json dependency on every consumer. If you need
 * it, build [SdkCaptureMetadata] directly.
 */
public data class CaptureMetadata(
    val userRef: String,
    val subjectRef: String,
    val conditionType: ConditionType,
    val captureGroup: String? = null,
    val bodyLocation: List<String>? = null,
) {
    internal val kotlin: SdkCaptureMetadata
        get() = SdkCaptureMetadata(
            userRef = userRef,
            subjectRef = subjectRef,
            conditionType = conditionType,
            captureGroup = captureGroup,
            bodyLocation = bodyLocation,
        )
}
