package com.twinskin.sdk

import android.app.Application
import com.twinskin.sdk.capture.CaptureObserver
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.view.ViewCaptureSession

/**
 * Public façade for the Android SDK.
 *
 * Mirrors iOS `enum TwinSkin` (see `sdk-ios/Sources/TwinSkinSDK+Swift.swift`).
 * Exposing the entry points as plain methods on a single-source-set object —
 * rather than as Kotlin Multiplatform expect/actual or cross-source-set
 * extensions — keeps the API resolvable from AAR consumers and gives
 * us a stable surface that doesn't leak the underlying KMP module layout.
 */
public object TwinSkin {
    /** Initialize the SDK. Idempotent — a second call is a no-op. */
    public fun initialize(app: Application, configuration: TwinSkinConfiguration) {
        TwinSkinSdk.initialize(app, configuration.kotlin)
    }

    /** Open a new capture session. The server is only contacted when the session is submitted. */
    public fun startCapture(metadata: CaptureMetadata): CaptureSession =
        TwinSkinSdk.startCapture(metadata.kotlin)

    /**
     * Observe captures known to this SDK instance. The returned [CaptureObserver]
     * is read-only; it never drives capture lifecycle.
     */
    public val captures: CaptureObserver get() = TwinSkinSdk.captures

    /**
     * Open a ready-to-use view-capture session. Drive [com.twinskin.sdk.ui.view_capture.ViewCaptureScreenHost]
     * unless you need direct access to the state StateFlow for custom UI.
     */
    public fun viewCapture(source: TwinSkinCaptureSource): ViewCaptureSession =
        TwinSkinSdk.viewCapture(source.kotlin)

    /** `true` when the integrator initialized the SDK with `devMode = true`. */
    public val devMode: Boolean get() = TwinSkinSdk.devMode

    /**
     * Diagnostic surface — see [TwinSkinDebug]. Not part of the stable
     * public API; the schema can change in any minor release.
     */
    public val debug: TwinSkinDebug get() = TwinSkinSdk.debug
}
