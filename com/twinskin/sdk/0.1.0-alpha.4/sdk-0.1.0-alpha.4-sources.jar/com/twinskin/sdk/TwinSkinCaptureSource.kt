package com.twinskin.sdk

import com.twinskin.sdk.view.CaptureSource as KmpCaptureSource

/**
 * Input to [TwinSkin.viewCapture]. Mirrors iOS `TwinSkinCaptureSource`
 * (see `sdk-ios/Sources/CaptureSource.swift`).
 *
 * The URL variants accept an optional async [headersProvider] the SDK
 * invokes just before the HTTP fetch — returned headers are attached
 * to the initial GET only. Every redirect is followed without them so
 * sensitive tokens never reach the redirect target (typically a
 * presigned S3 URL). A throw from the closure surfaces in the viewer
 * as `ViewCaptureError.Credentials` with a Retry affordance.
 */
public sealed class TwinSkinCaptureSource {
    /** A .glb file already on local storage. */
    public data class LocalGlb(val path: String) : TwinSkinCaptureSource()

    /** Direct URL to a .glb file. Downloaded to the SDK cache. */
    public class GlbUrl(
        public val url: String,
        public val headersProvider: suspend () -> Map<String, String> = { emptyMap() },
    ) : TwinSkinCaptureSource()

    /**
     * Capture identifier resolved via PowerSync against Twinskin using the
     * SDK's own session credentials. [subjectRef] is required because the
     * SDK's PowerSync token is subject-scoped; the capture id alone cannot
     * authorize the watch query.
     */
    public data class CaptureId(val id: String, val subjectRef: String) : TwinSkinCaptureSource()

    internal val kotlin: KmpCaptureSource
        get() = when (this) {
            is LocalGlb -> KmpCaptureSource.LocalGlb(path)
            is GlbUrl -> KmpCaptureSource.GlbUrl(url, headersProvider)
            is CaptureId -> KmpCaptureSource.CaptureId(id, subjectRef)
        }
}
