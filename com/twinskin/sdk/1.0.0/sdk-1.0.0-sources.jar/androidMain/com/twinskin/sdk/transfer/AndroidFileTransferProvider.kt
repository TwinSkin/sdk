package com.twinskin.sdk.transfer

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Android implementation of [FileTransferProvider] backed by WorkManager.
 *
 * Each task is enqueued as a [OneTimeWorkRequest] with a unique name equal to the database
 * task [id], so duplicate enqueues are safely rejected. The returned [Flow] observes the
 * work by that unique name and maps [WorkInfo] state and progress fields to [TransferUpdate].
 *
 * ZipEngine is intentionally NOT involved here — the worker only transfers bytes.
 * [TransferManager] handles UNZIPPING once it observes [TransferUpdate.Success].
 *
 * ## Usage
 * ```kotlin
 * // Production
 * val provider = AndroidFileTransferProvider(applicationContext)
 *
 * // Tests — call WorkManagerTestInitHelper.initializeTestWorkManager(context, config)
 * // BEFORE constructing the provider so WorkManager.getInstance() returns the test instance.
 * val provider = AndroidFileTransferProvider(context)  // same; picks up test singleton
 *
 * // Or inject a WorkManager instance directly:
 * val provider = AndroidFileTransferProvider(workManager)
 * ```
 */
class AndroidFileTransferProvider(
    private val workManager: WorkManager,
) : FileTransferProvider {

    /** Convenience constructor for production use. */
    constructor(context: Context) : this(WorkManager.getInstance(context))

    override fun execute(
        id: String,
        url: String,
        path: String,
        type: TransferType,
        headers: Map<String, String>,
    ): Flow<TransferUpdate> {
        // Enqueue the work and immediately start observing it.
        //
        // Uploads use KEEP policy: if WorkManager already has this task RUNNING or ENQUEUED
        // (e.g. it restarted the worker after an app kill while the process was dead), KEEP is
        // a no-op and we simply observe the existing job. If the previous attempt reached a
        // terminal state (SUCCEEDED/FAILED/CANCELLED), KEEP creates fresh work.
        //
        // Note: if the worker completed in the background and wrote COMPLETED to the DB (see
        // UploadWorker), TransferManager.recover() will NOT call execute() for that task at all
        // — it only processes tasks still in ACTIVE state. So by the time execute() is called
        // for a task, the upload is either still in progress or genuinely needs to restart.
        enqueueWork(id, url, path, type, headers)
        return observeWork(id)
    }

    // -----------------------------------------------------------------------
    // Observe → Flow<TransferUpdate>
    // -----------------------------------------------------------------------

    private fun observeWork(id: String): Flow<TransferUpdate> = callbackFlow {
        val job = launch {
            workManager
                .getWorkInfosForUniqueWorkFlow(id)
                .mapNotNull { infos -> infos.firstOrNull() }
                .collect { info ->
                    when (info.state) {
                        WorkInfo.State.RUNNING -> {
                            val percent = info.progress.getInt(WorkerKeys.KEY_PROGRESS, 0)
                            trySend(TransferUpdate.Progress(percent))
                        }
                        WorkInfo.State.SUCCEEDED -> {
                            // Emit a final 100% progress so the UI sees the completion ramp-up.
                            // close() completes the Flow so collect() in runTask terminates.
                            trySend(TransferUpdate.Progress(100))
                            trySend(TransferUpdate.Success)
                            close()
                        }
                        WorkInfo.State.FAILED -> {
                            val msg = info.outputData.getString(WorkerKeys.KEY_ERROR)
                                ?: "Transfer failed"
                            trySend(TransferUpdate.Failure(msg))
                            close()
                        }
                        WorkInfo.State.CANCELLED -> {
                            trySend(TransferUpdate.Failure("Transfer cancelled"))
                            close()
                        }
                        // ENQUEUED / BLOCKED — waiting for constraints (e.g. no network).
                        // Do not emit; TransferManager already set status to ACTIVE before calling
                        // execute(), so the DB row is visible. The Flow will update when work runs.
                        else -> Unit
                    }
                }
        }
        awaitClose { job.cancel() }
    }

    // -----------------------------------------------------------------------
    // Enqueue
    // -----------------------------------------------------------------------

    private fun enqueueWork(id: String, url: String, path: String, type: TransferType, headers: Map<String, String>) {
        val inputData = when (type) {
            // For uploads: `url` is the stable upload key; the UploadWorker resolves a fresh
            // presigned URL on each attempt (via SdkWorkerFactory-injected UrlResolver).
            TransferType.UPLOAD -> workDataOf(
                WorkerKeys.KEY_ID         to id,
                WorkerKeys.KEY_UPLOAD_KEY to url,
                WorkerKeys.KEY_PATH       to path,
            )
            // For downloads: `url` is the actual HTTP URL; DownloadWorker uses it directly.
            TransferType.DOWNLOAD -> workDataOf(
                WorkerKeys.KEY_ID      to id,
                WorkerKeys.KEY_URL     to url,
                WorkerKeys.KEY_PATH    to path,
                WorkerKeys.KEY_HEADERS to if (headers.isEmpty()) null else Json.encodeToString(headers),
            )
        }

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = when (type) {
            TransferType.DOWNLOAD -> OneTimeWorkRequestBuilder<DownloadWorker>()
            TransferType.UPLOAD -> OneTimeWorkRequestBuilder<UploadWorker>()
        }
            .setInputData(inputData)
            .setConstraints(constraints)
            .build()

        // Uploads use KEEP: if WorkManager already restarted the worker after an app kill,
        // REPLACE would cancel it. KEEP preserves RUNNING/ENQUEUED work and only creates new
        // work when the previous attempt reached a terminal state (SUCCEEDED/FAILED/CANCELLED).
        // Downloads use REPLACE so a fresh download always starts from scratch.
        val policy = if (type == TransferType.UPLOAD) ExistingWorkPolicy.KEEP else ExistingWorkPolicy.REPLACE
        workManager.enqueueUniqueWork(
            id,      // unique name = database task ID
            policy,
            request,
        )
    }

}
