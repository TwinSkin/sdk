package com.twinskin.sdk.view

import com.twinskin.sdk.view.CaptureNetworkException
import com.twinskin.sdk.view.CaptureNotFoundException
import io.ktor.client.HttpClient
import io.ktor.client.plugins.onDownload
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsChannel
import io.ktor.http.HttpStatusCode
import io.ktor.http.isSuccess
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.readAvailable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private val client = HttpClient()

actual suspend fun downloadToPath(
    url: String,
    destPath: String,
    onProgress: (bytesRead: Long, total: Long?) -> Unit,
) = withContext(Dispatchers.IO) {
    val dest = File(destPath)
    dest.parentFile?.mkdirs()
    client.prepareGet(url) {
        onDownload { bytesSentTotal, contentLength ->
            onProgress(bytesSentTotal, contentLength)
        }
    }.execute { response ->
        if (response.status == HttpStatusCode.NotFound) {
            throw CaptureNotFoundException("$url returned 404")
        }
        if (!response.status.isSuccess()) {
            throw CaptureNetworkException("$url returned ${response.status.value}")
        }
        val channel: ByteReadChannel = response.bodyAsChannel()
        FileOutputStream(dest).use { out ->
            val buffer = ByteArray(64 * 1024)
            while (!channel.isClosedForRead) {
                val read = channel.readAvailable(buffer, 0, buffer.size)
                if (read > 0) out.write(buffer, 0, read)
            }
        }
    }
}
