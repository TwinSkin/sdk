package com.twinskin.sdk.ui.view_capture.renderer

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.google.android.filament.gltfio.FilamentInstance
import com.twinskin.sdk.view.Asset3D
import io.github.sceneview.Scene
import io.github.sceneview.math.Position
import io.github.sceneview.rememberCameraNode
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberEnvironmentLoader
import io.github.sceneview.rememberMainLightNode
import io.github.sceneview.rememberModelLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Phase 1 Android renderer: SceneView (Filament + gltfio) loaded from a
 * local `.glb` file path.
 *
 * All [com.twinskin.sdk.view.CaptureResolver]s land a local path in
 * [Asset3D.location] by the time this composable runs (HTTP/Zip resolvers
 * download first, Local passes through), so the renderer only needs to
 * handle a file on disk.
 */
@Composable
actual fun Model3DViewer(
    asset: Asset3D,
    ar: Boolean,
    modifier: Modifier,
) {
    if (ar) {
        ArModel3DViewer(asset = asset, modifier = modifier)
        return
    }
    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine)
    val environmentLoader = rememberEnvironmentLoader(engine)

    // GLB parsing runs on Dispatchers.IO — reading and parsing a 10-20 MB
    // file on the composition (main) thread would stutter the transition
    // from Loading → Ready and risk an ANR.
    var modelInstance by remember(asset.location) { mutableStateOf<FilamentInstance?>(null) }
    LaunchedEffect(asset.location, modelLoader) {
        modelInstance = withContext(Dispatchers.IO) {
            val bytes = File(asset.location).readBytes()
            modelLoader.createModelInstance(ByteBuffer.wrap(bytes))
        }
    }

    Scene(
        modifier = modifier,
        engine = engine,
        modelLoader = modelLoader,
        environmentLoader = environmentLoader,
        cameraNode = rememberCameraNode(engine) { position = Position(z = 4f) },
        mainLightNode = rememberMainLightNode(engine),
    ) {
        // `ModelNode` here resolves to SceneScope.ModelNode (a composable
        // that constructs a ModelNode and auto-attaches it to the scene
        // for the lifetime of this composition). Only composed once the
        // background load completes — before that the scene renders empty.
        modelInstance?.let { instance ->
            ModelNode(modelInstance = instance, scaleToUnits = 1f)
        }
    }
}
