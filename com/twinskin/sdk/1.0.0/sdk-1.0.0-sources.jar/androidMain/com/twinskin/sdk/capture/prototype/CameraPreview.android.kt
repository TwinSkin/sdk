package com.twinskin.sdk.capture.prototype

import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner

@Composable
actual fun rememberPrototypeCaptureController(): CaptureController {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val controller = remember(context, lifecycleOwner) {
        AndroidCaptureController(context, lifecycleOwner)
    }
    LaunchedEffect(controller) { controller.bindToLifecycle() }
    DisposableEffect(controller) { onDispose { controller.dispose() } }
    return controller
}

@Composable
actual fun CameraPreview(controller: CaptureController, modifier: Modifier) {
    val android = controller as? AndroidCaptureController
        ?: error("CameraPreview requires AndroidCaptureController on this platform")
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PreviewView(ctx).also { view ->
                view.scaleType = PreviewView.ScaleType.FILL_CENTER
                android.preview.setSurfaceProvider(view.surfaceProvider)
            }
        },
    )
}
