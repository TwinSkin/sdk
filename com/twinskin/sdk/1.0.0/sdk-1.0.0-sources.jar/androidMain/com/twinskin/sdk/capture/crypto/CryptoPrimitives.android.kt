package com.twinskin.sdk.capture.crypto

import java.security.KeyFactory
import java.security.SecureRandom
import java.security.spec.MGF1ParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import javax.crypto.spec.SecretKeySpec

private val random = SecureRandom()

actual fun secureRandomBytes(out: ByteArray) = random.nextBytes(out)

actual fun aes256GcmEncrypt(key: ByteArray, nonce: ByteArray, plaintext: ByteArray): ByteArray {
    require(key.size == 32) { "AES-256 key must be 32 bytes" }
    require(nonce.size == 12) { "GCM nonce must be 12 bytes" }
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
    return cipher.doFinal(plaintext)
}

actual fun rsaOaepSha256Encrypt(publicKeyDer: ByteArray, plaintext: ByteArray): ByteArray {
    val pubKey = KeyFactory.getInstance("RSA")
        .generatePublic(X509EncodedKeySpec(publicKeyDer))
    // Explicit OAEP parameters — AndroidKeyStore's default MGF1 digest is SHA-1 even when
    // the outer digest is SHA-256. Force SHA-256 for MGF1 to match the server.
    val cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
    val oaep = OAEPParameterSpec(
        "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT,
    )
    cipher.init(Cipher.ENCRYPT_MODE, pubKey, oaep)
    return cipher.doFinal(plaintext)
}
