@file:OptIn(ExperimentalMaterial3Api::class)

package com.twinskin.sdk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
actual fun View3DSceneKitScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("View 3D SceneKit") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFFE65100),
                    titleContentColor = Color.White,
                ),
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFFFF3E0)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = Icons.Default.ViewInAr,
                contentDescription = null,
                modifier = Modifier.size(96.dp),
                tint = Color(0xFFE65100),
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "SceneKit",
                style = MaterialTheme.typography.headlineMedium,
                color = Color(0xFFBF360C),
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "SceneKit is not available on Android",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFFE65100),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "This screen uses iOS SceneKit from Kotlin on iOS",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFFF8F00),
            )
        }
    }
}
