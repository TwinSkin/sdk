@file:OptIn(ExperimentalMaterial3Api::class)

package com.twinskin.sdk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun View3DNativeScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("View 3D Native (Android)") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF2E7D32),
                    titleContentColor = Color.White,
                ),
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFE8F5E9)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = Icons.Default.PhoneAndroid,
                contentDescription = null,
                modifier = Modifier.size(96.dp),
                tint = Color(0xFF2E7D32),
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Jetpack Compose",
                style = MaterialTheme.typography.headlineMedium,
                color = Color(0xFF1B5E20),
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "This is a platform-native Android view",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFF388E3C),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Built with Jetpack Compose (not Compose Multiplatform)",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF66BB6A),
            )
        }
    }
}
