package com.twinskin.sdk.capture.prototype

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext

@Composable
actual fun rememberCapturePermissionsState(): CapturePermissionsState {
    val context = LocalContext.current
    val required = remember { arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO) }
    fun check(): Boolean = required.all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }
    var granted by remember { mutableStateOf(check()) }
    var denied by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { result ->
        val allGranted = required.all { result[it] == true }
        granted = allGranted
        denied = !allGranted
    }
    return remember {
        object : CapturePermissionsState {
            override val granted: Boolean get() = granted
            override val denied: Boolean get() = denied
            override fun request() {
                if (check()) { granted = true } else launcher.launch(required)
            }
        }
    }
}
