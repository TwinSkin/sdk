package com.twinskin.sdk.capture.prototype

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.nio.ByteBuffer
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * PROTOTYPE CameraX-backed [CaptureController]. Lives entirely in this package and is
 * deleted wholesale once the production capture code lands.
 */
class AndroidCaptureController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
) : CaptureController {

    private val _state = MutableStateFlow<CaptureControllerState>(CaptureControllerState.Initializing)
    override val state: StateFlow<CaptureControllerState> = _state.asStateFlow()

    internal val preview = Preview.Builder().build()
    private val imageCapture = ImageCapture.Builder()
        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
        .build()
    private val recorder = Recorder.Builder()
        .setQualitySelector(QualitySelector.from(Quality.HD))
        .build()
    private val videoCapture = VideoCapture.withOutput(recorder)

    private var activeRecording: Recording? = null
    private var pendingVideoFile: File? = null
    private var pendingVideoCallback: ((Result<String>) -> Unit)? = null

    suspend fun bindToLifecycle() {
        val provider = ProcessCameraProvider.getInstance(context).awaitCompat()
        provider.unbindAll()
        provider.bindToLifecycle(
            lifecycleOwner,
            CameraSelector.DEFAULT_BACK_CAMERA,
            preview, imageCapture, videoCapture,
        )
        _state.value = CaptureControllerState.Ready
    }

    override suspend fun takePhoto(): ByteArray = suspendCancellableCoroutine { cont ->
        _state.value = CaptureControllerState.CapturingPhoto
        imageCapture.takePicture(
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    try {
                        val buffer: ByteBuffer = image.planes[0].buffer
                        val bytes = ByteArray(buffer.remaining()).also { buffer.get(it) }
                        _state.value = CaptureControllerState.Ready
                        cont.resume(bytes)
                    } finally { image.close() }
                }
                override fun onError(exception: ImageCaptureException) {
                    _state.value = CaptureControllerState.Error(exception.message ?: "photo failed")
                    cont.resumeWithException(exception)
                }
            },
        )
    }

    @SuppressLint("MissingPermission") // caller-checked by CaptureScreen
    override suspend fun startRecording() {
        require(activeRecording == null) { "Recording already in progress" }
        val file = File.createTempFile("sdk-capture-", ".mp4", context.cacheDir)
        pendingVideoFile = file
        val output = FileOutputOptions.Builder(file).build()
        val withAudio = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO,
        ) == PackageManager.PERMISSION_GRANTED

        activeRecording = videoCapture.output
            .prepareRecording(context, output)
            .apply { if (withAudio) withAudioEnabled() }
            .start(ContextCompat.getMainExecutor(context)) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> _state.value = CaptureControllerState.Recording
                    is VideoRecordEvent.Finalize -> {
                        val cb = pendingVideoCallback
                        pendingVideoCallback = null
                        if (event.hasError()) {
                            _state.value = CaptureControllerState.Error("video failed: ${event.error}")
                            pendingVideoFile?.delete()
                            pendingVideoFile = null
                            cb?.invoke(Result.failure(RuntimeException("recorder error ${event.error}")))
                        } else {
                            // Hand ownership of the MP4 path to the caller — the SDK
                            // submit pipeline streams its bytes and deletes it when done.
                            val path = pendingVideoFile?.absolutePath
                                ?: return@start cb?.invoke(Result.failure(IllegalStateException("video file missing"))) ?: Unit
                            pendingVideoFile = null
                            _state.value = CaptureControllerState.Ready
                            cb?.invoke(Result.success(path))
                        }
                    }
                    else -> Unit
                }
            }
    }

    override suspend fun stopRecording(): String = suspendCancellableCoroutine { cont ->
        val rec = activeRecording ?: run {
            cont.resumeWithException(IllegalStateException("No active recording"))
            return@suspendCancellableCoroutine
        }
        pendingVideoCallback = { result -> result.fold(cont::resume, cont::resumeWithException) }
        rec.stop()
        activeRecording = null
    }

    override fun dispose() {
        activeRecording?.close()
        activeRecording = null
        try {
            ProcessCameraProvider.getInstance(context).get().unbindAll()
        } catch (e: Exception) {
            Log.w(TAG, "unbindAll failed on dispose", e)
        }
    }

    private companion object { const val TAG = "AndroidCaptureController" }
}

/** Adapter: [com.google.common.util.concurrent.ListenableFuture] → suspend. */
private suspend fun <T> com.google.common.util.concurrent.ListenableFuture<T>.awaitCompat(): T =
    suspendCancellableCoroutine { cont ->
        addListener({
            try { cont.resume(get()) } catch (e: Exception) { cont.resumeWithException(e) }
        }, Runnable::run)
    }
