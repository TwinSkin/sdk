package com.twinskin.sdk.ui.view_capture.renderer

import android.Manifest
import android.content.pm.PackageManager
import android.view.MotionEvent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.android.filament.gltfio.FilamentInstance
import com.google.ar.core.Anchor
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.Plane
import com.twinskin.sdk.view.Asset3D
import io.github.sceneview.ar.ARScene
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberModelLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Phase 2 (demo) Android AR renderer — tap-to-place on a detected plane.
 *
 * Throwaway. Guarded behind `Model3DViewer(..., ar = true)` so pulling it
 * out later is just a delete.
 */
@Composable
internal fun ArModel3DViewer(asset: Asset3D, modifier: Modifier) {
    val context = LocalContext.current
    var permissionGranted by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> permissionGranted = granted }

    LaunchedEffect(Unit) {
        if (!permissionGranted) launcher.launch(Manifest.permission.CAMERA)
    }

    if (!permissionGranted) {
        ArInfoOverlay(
            modifier = modifier,
            message = "Camera access is required for AR.",
            action = { launcher.launch(Manifest.permission.CAMERA) } to "Grant access",
        )
        return
    }

    val availability = remember(context) { ArCoreApk.getInstance().checkAvailability(context) }
    if (availability.isUnsupported) {
        ArInfoOverlay(
            modifier = modifier,
            message = "AR is not supported on this device.\n" +
                "Go back and use the regular 3D viewer.",
            action = null,
        )
        return
    }

    ArPlacement(asset = asset, modifier = modifier)
}

@Composable
private fun ArPlacement(asset: Asset3D, modifier: Modifier) {
    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine)

    // GLB parsing runs on Dispatchers.IO — reading a 10-20 MB file during
    // composition would stutter the transition into AR.
    var modelInstance by remember(asset.location) { mutableStateOf<FilamentInstance?>(null) }
    LaunchedEffect(asset.location, modelLoader) {
        modelInstance = withContext(Dispatchers.IO) {
            val bytes = File(asset.location).readBytes()
            modelLoader.createModelInstance(ByteBuffer.wrap(bytes))
        }
    }

    var latestFrame by remember { mutableStateOf<Frame?>(null) }
    var placedAnchor by remember { mutableStateOf<Anchor?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        ARScene(
            modifier = Modifier.fillMaxSize(),
            engine = engine,
            modelLoader = modelLoader,
            sessionConfiguration = { _, config ->
                config.lightEstimationMode = Config.LightEstimationMode.ENVIRONMENTAL_HDR
                config.planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
                config.depthMode = Config.DepthMode.DISABLED
            },
            onSessionUpdated = { _, frame -> latestFrame = frame },
            onTouchEvent = { e, _ ->
                if (placedAnchor != null || e.action != MotionEvent.ACTION_UP) {
                    return@ARScene false
                }
                // Ignore taps before the GLB has finished loading — otherwise
                // we'd anchor an empty node and flip `placedAnchor`, permanently
                // locking out future placements.
                if (modelInstance == null) return@ARScene false
                val frame = latestFrame ?: return@ARScene false
                val hit = frame.hitTest(e.x, e.y)
                    .firstOrNull { it.trackable is Plane }
                    ?: return@ARScene false
                placedAnchor = hit.createAnchor()
                true
            },
        ) {
            val anchor = placedAnchor
            val instance = modelInstance
            if (anchor != null && instance != null) {
                AnchorNode(anchor = anchor) {
                    ModelNode(modelInstance = instance, scaleToUnits = 0.3f)
                }
            }
        }

        if (placedAnchor == null) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(24.dp)
                    .clip(RoundedCornerShape(12.dp)),
                color = Color.Black.copy(alpha = 0.65f),
            ) {
                Text(
                    text = "Move your phone slowly to detect a surface, then tap to place.",
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
private fun ArInfoOverlay(
    modifier: Modifier,
    message: String,
    action: Pair<() -> Unit, String>?,
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF1A1F24))
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                message,
                color = Color.White,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
            )
            if (action != null) {
                Spacer(Modifier.height(16.dp))
                Button(onClick = action.first) { Text(action.second) }
            }
        }
    }
}

private val ArCoreApk.Availability.isUnsupported: Boolean
    get() = this == ArCoreApk.Availability.UNSUPPORTED_DEVICE_NOT_CAPABLE
