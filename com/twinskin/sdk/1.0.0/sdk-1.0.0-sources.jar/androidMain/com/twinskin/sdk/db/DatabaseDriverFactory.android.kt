package com.twinskin.sdk.db

import android.content.Context
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.android.AndroidSqliteDriver

actual class DatabaseDriverFactory actual constructor(private val dbName: String) {
    actual fun create(): SqlDriver =
        AndroidSqliteDriver(TwinSkinDatabase.Schema, appContext, if (dbName == ":memory:") null else dbName)

    companion object {
        private lateinit var appContext: Context

        fun init(context: Context) {
            appContext = context.applicationContext
        }

        internal fun appContextOrNull(): Context? = if (::appContext.isInitialized) appContext else null
    }
}
