package com.twinskin.sdk.transfer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.twinskin.sdk.TwinSkinSdk
import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.onUpload
import io.ktor.client.request.put
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.http.ContentType
import io.ktor.http.content.OutgoingContent
import io.ktor.http.contentType
import io.ktor.utils.io.*
import java.io.File
import java.io.IOException

/**
 * WorkManager [CoroutineWorker] that uploads the file at [WorkerKeys.KEY_PATH] to a presigned
 * URL obtained fresh on each attempt by calling the [urlResolver] with [WorkerKeys.KEY_UPLOAD_KEY].
 *
 * ## Why the worker writes directly to the database
 *
 * WorkManager can run this worker in the background **after the app process has been killed**
 * (the system restarts a lightweight process just for the worker via `JobScheduler`). In that
 * scenario, [AndroidFileTransferProvider]'s observe-flow — which normally maps WorkInfo state
 * changes to DB updates — is not running. Without direct DB writes from the worker, the task
 * would stay `ACTIVE` in the database indefinitely, and [TransferManager.recover] would
 * re-enqueue it on the next app launch, restarting the upload from byte 0.
 *
 * By writing `COMPLETED` / `FAILED` directly from [doWork], the DB always reflects the real
 * terminal state regardless of whether the app was open. [recover] then finds no `ACTIVE` tasks
 * for already-finished uploads and does not restart them.
 *
 * Return values:
 * - [Result.success] — upload completed, or server says the file already exists.
 * - [Result.retry]   — transient failure (network error, resolver not available, HTTP 5xx/4xx).
 *                      WorkManager will re-run with exponential back-off + CONNECTED constraint.
 * - [Result.failure] — permanent failure (e.g. source file missing).
 *
 * Promoted to a foreground service via [setForeground] so large uploads survive backgrounding.
 *
 * Uses WorkManager's default ContentProvider auto-init. Dependencies are fetched from
 * [TwinSkinSdk.requireComponent] at [doWork] time — the host must have called
 * [TwinSkinSdk.initialize] before the worker is executed (always true in practice since
 * uploads are enqueued by [TransferManager], which is itself part of the component).
 */
internal class UploadWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val component get() = TwinSkinSdk.requireComponent()
    private val urlResolver get() = component.urlResolver
    private val database get() = component.database
    private val logger get() = component.logger

    // Single HttpClient instance reused across retries within this worker lifecycle.
    // Closed in the finally block of doWork.
    private val client = HttpClient(Android) {
        install(HttpTimeout) {
            requestTimeoutMillis = null   // no overall timeout — file size is unbounded
            socketTimeoutMillis  = 60_000L
        }
    }

    override suspend fun doWork(): Result {
        // The host must call TwinSkinSdk.initialize from Application.onCreate so the SDK
        // is ready when WorkManager wakes this worker in a fresh process. Fail loudly
        // (but without crashing) if the integrator wired it somewhere that doesn't run
        // on process restart — WorkManager would otherwise enter a retry loop.
        if (!TwinSkinSdk.isInitialized) {
            Log.e(
                "TwinSkinSdk",
                "UploadWorker aborted: TwinSkinSdk.initialize(...) was not called. " +
                    "Call it from Application.onCreate() so the SDK is ready on process restart.",
            )
            return Result.failure()
        }
        val id        = inputData.getString(WorkerKeys.KEY_ID)         ?: return Result.failure()
        val uploadKey = inputData.getString(WorkerKeys.KEY_UPLOAD_KEY) ?: return Result.failure()
        val path      = inputData.getString(WorkerKeys.KEY_PATH)       ?: return Result.failure()

        setForeground(buildForegroundInfo("Uploading…", id))

        val file = File(path)
        if (!file.exists()) {
            // Permanent failure — file was deleted. Write FAILED so recover() won't retry.
            val now = System.currentTimeMillis()
            database.transferTaskQueries.updateStatusAndError(
                TransferStatus.FAILED.name,
                "File not found: $path",
                now,
                id,
            )
            return Result.failure(workDataOf(WorkerKeys.KEY_ERROR to "File not found: $path"))
        }

        return try {
            when (val resolved = urlResolver(uploadKey)) {
                is UrlResult.AlreadyExist -> {
                    // Server already has this file — write COMPLETED and treat as success.
                    setProgress(workDataOf(WorkerKeys.KEY_PROGRESS to 100))
                    val now = System.currentTimeMillis()
                    database.transferTaskQueries.updateStatus(TransferStatus.COMPLETED.name, now, id)
                    Result.success()
                }
                is UrlResult.RetryableError -> {
                    // Network unavailable or server not ready.
                    // WorkManager will retry when the CONNECTED constraint is satisfied.
                    // Do NOT write FAILED — the upload is not finished yet.
                    logger.log("UploadWorker[$id] urlResolver returned RetryableError — scheduling WorkManager retry")
                    Result.retry()
                }
                is UrlResult.Url -> {
                    val succeeded = putFile(id, file, resolved.url)
                    if (succeeded) {
                        val now = System.currentTimeMillis()
                        database.transferTaskQueries.updateStatus(TransferStatus.COMPLETED.name, now, id)
                        Result.success()
                    } else {
                        // Transient HTTP / network error — let WorkManager retry.
                        logger.log("UploadWorker[$id] PUT failed — scheduling WorkManager retry")
                        Result.retry()
                    }
                }
            }
        } finally {
            client.close()
        }
    }

    // -----------------------------------------------------------------------
    // HTTP PUT — returns true on 2xx, false on any error (causes retry)
    // -----------------------------------------------------------------------

    private suspend fun putFile(id: String, file: File, url: String): Boolean {
        return try {
            val fileSize = file.length()
            val response: HttpResponse = client.put(url) {
                contentType(ContentType.Application.OctetStream)
                onUpload { bytesSent, totalBytes ->
                    if ((totalBytes ?: 0L) > 0L) {
                        val percent = minOf(99, ((bytesSent * 100L) / totalBytes!!).toInt())
                        setProgress(workDataOf(WorkerKeys.KEY_PROGRESS to percent))
                    }
                }
                // Stream the file without buffering it fully in memory
                setBody(object : OutgoingContent.WriteChannelContent() {
                    override val contentLength: Long      = fileSize
                    override val contentType: ContentType = ContentType.Application.OctetStream

                    override suspend fun writeTo(channel: ByteWriteChannel) {
                        file.inputStream().use { input ->
                            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                            var read = input.read(buffer)
                            while (read != -1) {
                                channel.writeByteArray(buffer.copyOfRange(0, read))
                                read = input.read(buffer)
                            }
                        }
                    }
                })
            }
            if (response.status.value !in 200..299) {
                logger.log("UploadWorker[$id] PUT HTTP ${response.status.value}")
            }
            response.status.value in 200..299
        } catch (e: IOException) {
            logger.log("UploadWorker[$id] PUT transport error", e)
            false
        }
    }

    // -----------------------------------------------------------------------
    // Foreground service notification
    // -----------------------------------------------------------------------

    private fun buildForegroundInfo(contentText: String, taskId: String): ForegroundInfo {
        ensureNotificationChannel()

        val notificationId = WorkerKeys.notificationIdForTask(taskId, TransferType.UPLOAD)

        val notification = NotificationCompat.Builder(applicationContext, WorkerKeys.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("TwinSkin")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .setSilent(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(
                notificationId,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
        } else {
            ForegroundInfo(notificationId, notification)
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                WorkerKeys.NOTIFICATION_CHANNEL_ID,
                WorkerKeys.NOTIFICATION_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW,
            )
            applicationContext
                .getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }
}
