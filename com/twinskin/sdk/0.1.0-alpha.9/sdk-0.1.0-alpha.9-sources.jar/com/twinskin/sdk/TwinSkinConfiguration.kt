package com.twinskin.sdk

import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider

/**
 * Integrator-supplied configuration for [TwinSkin.initialize]. Mirrors
 * iOS `TwinSkinConfiguration` (see `sdk-ios/Sources/TwinSkinConfiguration.swift`).
 *
 * The `.kotlin` conversion is the bridge to the underlying [TwinSkinConfig]
 * — kept internal so consumers stay on the wrapper surface.
 */
public data class TwinSkinConfiguration(
    val publishableKey: String,
    val authorizationProvider: SdkAuthorizationProvider,
    val baseUrl: String = TwinSkinConfig.PROD_BASE_URL,
    val logger: SdkLogger? = null,
    val devMode: Boolean = false,
    val verboseFrameLogs: Boolean = false,
) {
    internal val kotlin: TwinSkinConfig
        get() = TwinSkinConfig(
            publishableKey = publishableKey,
            authorizationProvider = authorizationProvider,
            baseUrl = baseUrl,
            logger = logger,
            devMode = devMode,
            verboseFrameLogs = verboseFrameLogs,
        )
}
