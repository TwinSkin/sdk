package com.twinskin.sdk

import android.app.Application
import android.content.Context
import android.content.Intent
import com.twinskin.sdk.capture.CaptureObserver
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.internal.CaptureResultRelay
import com.twinskin.sdk.internal.SdkCaptureActivity
import com.twinskin.sdk.internal.SdkAccelerometerCaptureActivity
import com.twinskin.sdk.internal.SdkViewCaptureActivity
import com.twinskin.sdk.internal.findActivity

/**
 * Public façade for the Android SDK.
 *
 * Mirrors iOS `enum TwinSkin` (see `sdk-ios/Sources/TwinSkinSDK+Swift.swift`).
 * Exposing the entry points as plain methods on a single-source-set object —
 * rather than as Kotlin Multiplatform expect/actual or cross-source-set
 * extensions — keeps the API resolvable from AAR consumers and gives
 * us a stable surface that doesn't leak the underlying KMP module layout.
 */
public object TwinSkin {
    internal val captureRelay = CaptureResultRelay<CaptureSession>()
    internal val viewCaptureRelay = CaptureResultRelay<Unit>()

    /** Initialize the SDK. Idempotent — a second call is a no-op. */
    public fun initialize(app: Application, configuration: TwinSkinConfiguration) {
        TwinSkinSdk.initialize(app, configuration.kotlin)
    }

    /**
     * Present the SDK's capture UI full-screen and suspend until it finishes.
     * Returns the submitted [CaptureSession], or `null` if the operator
     * cancelled. The server is only contacted when the session is submitted.
     *
     * @param context the host Activity's Context; must be Activity-backed.
     * @throws TwinSkinPresentationException if [context] is not Activity-backed.
     */
    public suspend fun startCapture(context: Context, metadata: CaptureMetadata): CaptureSession? {
        val activity = context.findActivity()
        val (id, deferred) = captureRelay.register()
        return try {
            val activityClass = when (TwinSkinSdk.captureMode) {
                CaptureMode.Photosphere -> SdkCaptureActivity::class.java
                CaptureMode.AccelerometerCapture -> SdkAccelerometerCaptureActivity::class.java
            }
            val intent = Intent(activity, activityClass)
                .putExtra(SdkCaptureActivity.EXTRA_REQUEST_ID, id)
            metadata.fillCaptureIntent(intent)
            activity.startActivity(intent)
            deferred.await()
        } catch (e: Throwable) {
            captureRelay.complete(id, null)
            throw e
        }
    }

    /**
     * Observe captures known to this SDK instance. The returned [CaptureObserver]
     * is read-only; it never drives capture lifecycle.
     */
    public val captures: CaptureObserver get() = TwinSkinSdk.captures

    /**
     * Present the SDK's view-capture UI full-screen and suspend until the
     * operator closes it.
     *
     * @param context the host Activity's Context; must be Activity-backed.
     * @throws TwinSkinPresentationException if [context] is not Activity-backed.
     */
    public suspend fun viewCapture(context: Context, source: TwinSkinCaptureSource) {
        val activity = context.findActivity()
        val (id, deferred) = viewCaptureRelay.register()
        try {
            val intent = Intent(activity, SdkViewCaptureActivity::class.java)
                .putExtra(SdkViewCaptureActivity.EXTRA_REQUEST_ID, id)
            source.fillViewCaptureIntent(intent)
            activity.startActivity(intent)
            deferred.await()
        } catch (e: Throwable) {
            viewCaptureRelay.complete(id, Unit)
            throw e
        }
    }

    /** `true` when the integrator initialized the SDK with `devMode = true`. */
    public val devMode: Boolean get() = TwinSkinSdk.devMode

    public val captureMode: CaptureMode get() = TwinSkinSdk.captureMode

    /**
     * Diagnostic surface — see [TwinSkinDebug]. Not part of the stable
     * public API; the schema can change in any minor release.
     */
    public val debug: TwinSkinDebug get() = TwinSkinSdk.debug
}
