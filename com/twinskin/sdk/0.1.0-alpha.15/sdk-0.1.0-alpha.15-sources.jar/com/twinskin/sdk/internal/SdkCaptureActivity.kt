package com.twinskin.sdk.internal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.twinskin.sdk.TwinSkin
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.ui.CaptureScreen

/**
 * SDK-owned full-screen host for [CaptureScreen]. Launched by
 * `TwinSkin.startCapture`; delivers the result through [TwinSkin.captureRelay].
 */
@OptIn(TwinSkinInternalApi::class)
internal class SdkCaptureActivity : ComponentActivity() {

    private var requestId: Int = -1
    private var delivered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestId = intent.getIntExtra(EXTRA_REQUEST_ID, -1)
        require(requestId != -1) { "SdkCaptureActivity launched without EXTRA_REQUEST_ID" }

        val metadata = SdkCaptureMetadata(
            userRef = requireNotNull(intent.getStringExtra(EXTRA_USER_REF)),
            subjectRef = requireNotNull(intent.getStringExtra(EXTRA_SUBJECT_REF)),
            conditionType = parseCondition(intent.getStringExtra(EXTRA_CONDITION_TYPE)),
            captureGroup = intent.getStringExtra(EXTRA_CAPTURE_GROUP),
            bodyLocation = intent.getStringArrayListExtra(EXTRA_BODY_LOCATION),
        )

        setContent {
            MaterialTheme {
                CaptureScreen(
                    metadata = metadata,
                    onDone = { session ->
                        delivered = true
                        TwinSkin.captureRelay.complete(requestId, session)
                        finish()
                    },
                    onCancel = {
                        delivered = true
                        TwinSkin.captureRelay.complete(requestId, null)
                        finish()
                    },
                )
            }
        }
    }

    override fun onDestroy() {
        if (!delivered && isFinishing) TwinSkin.captureRelay.complete(requestId, null)
        super.onDestroy()
    }

    private fun parseCondition(s: String?): ConditionType = when (s) {
        "wound" -> ConditionType.Wound
        "generic" -> ConditionType.Generic
        else -> error("Unknown conditionType: $s")
    }

    companion object {
        const val EXTRA_REQUEST_ID = "requestId"
        const val EXTRA_USER_REF = "userRef"
        const val EXTRA_SUBJECT_REF = "subjectRef"
        const val EXTRA_CONDITION_TYPE = "conditionType"
        const val EXTRA_CAPTURE_GROUP = "captureGroup"
        const val EXTRA_BODY_LOCATION = "bodyLocation"
    }
}
