package com.twinskin.sdk.internal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.twinskin.sdk.TwinSkin
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.ui.fallback.AccelerometerCaptureScreenHost
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

@OptIn(TwinSkinInternalApi::class, kotlinx.coroutines.DelicateCoroutinesApi::class)
internal class SdkAccelerometerCaptureActivity : ComponentActivity() {

    private var requestId: Int = -1
    private var delivered = false
    private var session: CaptureSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestId = intent.getIntExtra(SdkCaptureActivity.EXTRA_REQUEST_ID, -1)
        require(requestId != -1) {
            "SdkAccelerometerCaptureActivity launched without EXTRA_REQUEST_ID"
        }

        val metadata = SdkCaptureMetadata(
            userRef = requireNotNull(intent.getStringExtra(SdkCaptureActivity.EXTRA_USER_REF)),
            subjectRef = requireNotNull(intent.getStringExtra(SdkCaptureActivity.EXTRA_SUBJECT_REF)),
            conditionType = parseCondition(intent.getStringExtra(SdkCaptureActivity.EXTRA_CONDITION_TYPE)),
            captureGroup = intent.getStringExtra(SdkCaptureActivity.EXTRA_CAPTURE_GROUP),
            bodyLocation = intent.getStringArrayListExtra(SdkCaptureActivity.EXTRA_BODY_LOCATION),
        )

        setContent {
            MaterialTheme {
                AccelerometerCaptureScreenHost(
                    metadata = metadata,
                    onSessionStarted = { session = it },
                    onDone = { s ->
                        delivered = true
                        TwinSkin.captureRelay.complete(requestId, s)
                        finish()
                    },
                    onCancel = {
                        delivered = true
                        TwinSkin.captureRelay.complete(requestId, null)
                        finish()
                    },
                )
            }
        }
    }

    override fun onDestroy() {
        if (!delivered && isFinishing) {
            TwinSkin.captureRelay.complete(requestId, null)
            // Route the upstream `CaptureSession.state = Cancelled`
            // for the process-kill / system-finish path. Fire-and-forget
            // on a GlobalScope because the activity (and its
            // lifecycleScope) are being torn down right now.
            session?.let { s ->
                GlobalScope.launch { runCatching { s.cancel() } }
            }
        }
        super.onDestroy()
    }

    private fun parseCondition(s: String?): ConditionType = when (s) {
        "wound" -> ConditionType.Wound
        "generic" -> ConditionType.Generic
        else -> error("Unknown conditionType: $s")
    }
}
