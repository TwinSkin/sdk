package com.twinskin.sdk.internal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import com.twinskin.sdk.TwinSkin
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.ui.view_capture.ViewCaptureScreenHost
import com.twinskin.sdk.view.CaptureSource

/**
 * SDK-owned full-screen host for [ViewCaptureScreenHost]. Launched by
 * `TwinSkin.viewCapture`; signals completion through [TwinSkin.viewCaptureRelay].
 */
@OptIn(TwinSkinInternalApi::class)
internal class SdkViewCaptureActivity : ComponentActivity() {

    private var requestId: Int = -1
    private var delivered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestId = intent.getIntExtra(EXTRA_REQUEST_ID, -1)
        require(requestId != -1) { "SdkViewCaptureActivity launched without EXTRA_REQUEST_ID" }

        val source = parseSource()

        setContent {
            MaterialTheme {
                ViewCaptureScreenHost(
                    source = source,
                    onClose = {
                        delivered = true
                        TwinSkin.viewCaptureRelay.complete(requestId, Unit)
                        finish()
                    },
                )
            }
        }
    }

    override fun onDestroy() {
        if (!delivered && isFinishing) TwinSkin.viewCaptureRelay.complete(requestId, Unit)
        super.onDestroy()
    }

    private fun parseSource(): CaptureSource = when (val kind = intent.getStringExtra(EXTRA_KIND)) {
        "localGlb" -> CaptureSource.LocalGlb(
            requireNotNull(intent.getStringExtra(EXTRA_PATH)),
        )
        "glbUrl" -> CaptureSource.GlbUrl(
            url = requireNotNull(intent.getStringExtra(EXTRA_URL)),
            headersProvider = parseHeadersProvider(),
        )
        "captureId" -> CaptureSource.CaptureId(
            id = requireNotNull(intent.getStringExtra(EXTRA_ID)),
            subjectRef = requireNotNull(intent.getStringExtra(EXTRA_SUBJECT_REF)),
        )
        else -> error("Unknown CaptureSource kind: $kind")
    }

    private fun parseHeadersProvider(): suspend () -> Map<String, String> {
        val keys = intent.getStringArrayListExtra(EXTRA_HEADER_KEYS) ?: return { emptyMap() }
        val values = intent.getStringArrayListExtra(EXTRA_HEADER_VALUES) ?: return { emptyMap() }
        val headers = buildMap {
            for (i in 0 until minOf(keys.size, values.size)) {
                put(keys[i], values[i])
            }
        }
        return { headers }
    }

    companion object {
        const val EXTRA_REQUEST_ID = "requestId"
        const val EXTRA_KIND = "kind"
        const val EXTRA_PATH = "path"
        const val EXTRA_URL = "url"
        const val EXTRA_ID = "id"
        const val EXTRA_SUBJECT_REF = "subjectRef"
        const val EXTRA_HEADER_KEYS = "headerKeys"
        const val EXTRA_HEADER_VALUES = "headerValues"
    }
}
