package com.twinskin.sdk

import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider

/**
 * Integrator-supplied configuration for [TwinSkin.initialize]. Mirrors
 * iOS `TwinSkinConfiguration` (see `sdk-ios/Sources/TwinSkinConfiguration.swift`).
 *
 * The `.kotlin` conversion is the bridge to the underlying [TwinSkinConfig]
 * — kept internal so consumers stay on the wrapper surface.
 */
public data class TwinSkinConfiguration @TwinSkinInternalApi constructor(
    val publishableKey: String,
    val authorizationProvider: SdkAuthorizationProvider,
    val baseUrl: String = TwinSkinConfig.PROD_BASE_URL,
    val logger: SdkLogger? = null,
    val logLevel: SdkLogLevel? = null,
    val devMode: Boolean = false,
    val verboseFrameLogs: Boolean = false,
    val captureMode: CaptureMode = CaptureMode.AccelerometerCapture,
    /**
     * Locale override for the SDK's built-in UI. `null` (default) uses the
     * device locale; a language tag such as `"fr"` pins the language. Falls back
     * to English for locales the SDK doesn't ship yet.
     */
    val locale: String? = null,
    /**
     * **Dev/test only.** Provider for extra `debug_padding.bin` bytes
     * appended to the encrypted bundle before upload — see
     * [TwinSkinConfig.debugBundlePaddingBytesProvider]. Honoured only when
     * [devMode] is `true`; `null` (default) injects nothing.
     */
    @property:TwinSkinInternalApi
    val debugBundlePaddingBytesProvider: (() -> Long)? = null,
) {
    @OptIn(TwinSkinInternalApi::class)
    public constructor(
        publishableKey: String,
        authorizationProvider: SdkAuthorizationProvider,
        baseUrl: String = TwinSkinConfig.PROD_BASE_URL,
        logger: SdkLogger? = null,
        logLevel: SdkLogLevel? = null,
        devMode: Boolean = false,
        verboseFrameLogs: Boolean = false,
        captureMode: CaptureMode = CaptureMode.AccelerometerCapture,
        locale: String? = null,
    ) : this(
        publishableKey = publishableKey,
        authorizationProvider = authorizationProvider,
        baseUrl = baseUrl,
        logger = logger,
        logLevel = logLevel,
        devMode = devMode,
        verboseFrameLogs = verboseFrameLogs,
        captureMode = captureMode,
        locale = locale,
        debugBundlePaddingBytesProvider = null,
    )

    @OptIn(TwinSkinInternalApi::class)
    internal val kotlin: TwinSkinConfig
        get() = TwinSkinConfig(
            publishableKey = publishableKey,
            authorizationProvider = authorizationProvider,
            baseUrl = baseUrl,
            logger = logger,
            logLevel = logLevel,
            devMode = devMode,
            verboseFrameLogs = verboseFrameLogs,
            captureMode = captureMode,
            locale = locale,
            debugBundlePaddingBytesProvider = debugBundlePaddingBytesProvider,
        )
}
