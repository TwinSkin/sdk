package com.twinskin.sdk

import android.content.Intent
import com.twinskin.sdk.capture.Analysis
import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.internal.SdkAccelerometerCaptureActivity
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive

/**
 * Metadata required to start a capture. Mirrors iOS `CaptureMetadata`
 * (see `sdk-ios/Sources/CaptureMetadata.swift`).
 *
 * `analysis` is required — it picks the server-side pipeline, and whether
 * the server outlines the capture, so there is no safe default.
 *
 * `custom` is a flat `Map<String, String>`, lifted to the underlying
 * [SdkCaptureMetadata]'s `Map<String, JsonElement>`. For nested JSON,
 * build [SdkCaptureMetadata] directly.
 */
public data class CaptureMetadata(
    val userRef: String,
    val subjectRef: String,
    val analysis: Analysis,
    /**
     * A condition type supplied out of band, sent instead of [analysis]; the
     * server outlines it. Unknown to the server is a 400.
     */
    val conditionTypeRaw: String? = null,
    val captureGroup: String? = null,
    val bodyLocation: List<String>? = null,
    val custom: Map<String, String>? = null,
) {
    @Deprecated(
        "Pass an Analysis. A ConditionType maps to it with an automatic outline, " +
            "except Generic.",
    )
    // Positional order is the 0.2.1 constructor's, which integrators call
    // positionally; conditionTypeRaw came later and goes last.
    public constructor(
        userRef: String,
        subjectRef: String,
        conditionType: ConditionType,
        captureGroup: String? = null,
        bodyLocation: List<String>? = null,
        custom: Map<String, String>? = null,
        conditionTypeRaw: String? = null,
    ) : this(
        userRef = userRef,
        subjectRef = subjectRef,
        analysis = when (conditionType) {
            ConditionType.Wound -> Analysis.Wound()
            ConditionType.Scar -> Analysis.Scar()
            ConditionType.Generic -> Analysis.Generic
        },
        conditionTypeRaw = conditionTypeRaw,
        captureGroup = captureGroup,
        bodyLocation = bodyLocation,
        custom = custom,
    )

    internal val kotlin: SdkCaptureMetadata
        get() = SdkCaptureMetadata(
            userRef = userRef,
            subjectRef = subjectRef,
            analysis = analysis,
            conditionTypeRaw = conditionTypeRaw,
            captureGroup = captureGroup,
            bodyLocation = bodyLocation,
            custom = custom?.toJsonElementMap(),
        )
}

internal fun Map<String, String>.toJsonElementMap(): Map<String, JsonElement> =
    mapValues { JsonPrimitive(it.value) }

/** Writes the extras [SdkAccelerometerCaptureActivity] reads back to reconstruct this metadata. */
internal fun CaptureMetadata.fillCaptureIntent(intent: Intent) {
    intent.putExtra(SdkAccelerometerCaptureActivity.EXTRA_USER_REF, userRef)
    intent.putExtra(SdkAccelerometerCaptureActivity.EXTRA_SUBJECT_REF, subjectRef)
    val (analysisType, autoOutline) = when (analysis) {
        is Analysis.Wound -> "wound" to analysis.autoOutline
        is Analysis.Scar -> "scar" to analysis.autoOutline
        Analysis.Generic -> "generic" to false
    }
    intent.putExtra(SdkAccelerometerCaptureActivity.EXTRA_ANALYSIS_TYPE, analysisType)
    intent.putExtra(SdkAccelerometerCaptureActivity.EXTRA_AUTO_OUTLINE, autoOutline)
    conditionTypeRaw?.let {
        intent.putExtra(SdkAccelerometerCaptureActivity.EXTRA_CONDITION_TYPE_RAW, it)
    }
    captureGroup?.let { intent.putExtra(SdkAccelerometerCaptureActivity.EXTRA_CAPTURE_GROUP, it) }
    bodyLocation?.let {
        intent.putStringArrayListExtra(SdkAccelerometerCaptureActivity.EXTRA_BODY_LOCATION, ArrayList(it))
    }
    custom?.let {
        intent.putStringArrayListExtra(SdkAccelerometerCaptureActivity.EXTRA_CUSTOM_KEYS, ArrayList(it.keys))
        intent.putStringArrayListExtra(SdkAccelerometerCaptureActivity.EXTRA_CUSTOM_VALUES, ArrayList(it.values))
    }
}
