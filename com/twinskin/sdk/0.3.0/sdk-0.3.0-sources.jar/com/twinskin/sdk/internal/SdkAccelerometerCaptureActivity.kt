package com.twinskin.sdk.internal

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.core.view.WindowCompat
import com.twinskin.sdk.TwinSkin
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.Analysis
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.toJsonElementMap
import com.twinskin.sdk.ui.fallback.AccelerometerCaptureScreenHost
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement

@OptIn(TwinSkinInternalApi::class, kotlinx.coroutines.DelicateCoroutinesApi::class)
internal class SdkAccelerometerCaptureActivity : ComponentActivity() {

    private var requestId: Int = -1
    private var delivered = false
    private var session: CaptureSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Edge-to-edge so Compose receives the cutout insets the top bar consumes;
        // without it the bar drew under the Pixel 6 punch-hole.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // Force the system nav bar dark with light glyphs instead of inheriting the
        // host app's light nav bar, to match the dark capture chrome.
        @Suppress("DEPRECATION")
        window.navigationBarColor = Color.parseColor("#FF05080A")
        WindowCompat.getInsetsController(window, window.decorView)
            .isAppearanceLightNavigationBars = false
        requestId = intent.getIntExtra(EXTRA_REQUEST_ID, -1)
        require(requestId != -1) {
            "SdkAccelerometerCaptureActivity launched without EXTRA_REQUEST_ID"
        }

        val metadata = SdkCaptureMetadata(
            userRef = requireNotNull(intent.getStringExtra(EXTRA_USER_REF)),
            subjectRef = requireNotNull(intent.getStringExtra(EXTRA_SUBJECT_REF)),
            analysis = analysisFromIntent(intent),
            conditionTypeRaw = intent.getStringExtra(EXTRA_CONDITION_TYPE_RAW),
            captureGroup = intent.getStringExtra(EXTRA_CAPTURE_GROUP),
            bodyLocation = intent.getStringArrayListExtra(EXTRA_BODY_LOCATION),
            custom = customFromIntent(intent),
        )

        setContent {
            MaterialTheme {
                AccelerometerCaptureScreenHost(
                    metadata = metadata,
                    onSessionStarted = { session = it },
                    onDone = { s ->
                        delivered = true
                        TwinSkin.captureRelay.complete(requestId, s)
                        finish()
                    },
                    onCancel = {
                        delivered = true
                        TwinSkin.captureRelay.complete(requestId, null)
                        finish()
                    },
                )
            }
        }
    }

    override fun onDestroy() {
        if (!delivered && isFinishing) {
            TwinSkin.captureRelay.complete(requestId, null)
            // Route the upstream `CaptureSession.state = Cancelled`
            // for the process-kill / system-finish path. Fire-and-forget
            // on a GlobalScope because the activity (and its
            // lifecycleScope) are being torn down right now.
            session?.let { s ->
                GlobalScope.launch { runCatching { s.cancel() } }
            }
        }
        super.onDestroy()
    }

    private fun analysisFromIntent(intent: Intent): Analysis {
        val autoOutline = intent.getBooleanExtra(EXTRA_AUTO_OUTLINE, true)
        return when (val type = intent.getStringExtra(EXTRA_ANALYSIS_TYPE)) {
            "wound" -> Analysis.Wound(autoOutline)
            "scar" -> Analysis.Scar(autoOutline)
            "generic" -> Analysis.Generic
            else -> error("Unknown analysis type: $type")
        }
    }

    companion object {
        const val EXTRA_REQUEST_ID = "requestId"
        const val EXTRA_USER_REF = "userRef"
        const val EXTRA_SUBJECT_REF = "subjectRef"
        const val EXTRA_ANALYSIS_TYPE = "analysisType"
        const val EXTRA_AUTO_OUTLINE = "autoOutline"
        const val EXTRA_CONDITION_TYPE_RAW = "conditionTypeRaw"
        const val EXTRA_CAPTURE_GROUP = "captureGroup"
        const val EXTRA_BODY_LOCATION = "bodyLocation"
        const val EXTRA_CUSTOM_KEYS = "customKeys"
        const val EXTRA_CUSTOM_VALUES = "customValues"

        /** Reads the parallel key/value arrays written by `fillCaptureIntent`. */
        internal fun customFromIntent(intent: Intent): Map<String, JsonElement>? {
            val keys = intent.getStringArrayListExtra(EXTRA_CUSTOM_KEYS) ?: return null
            val values = intent.getStringArrayListExtra(EXTRA_CUSTOM_VALUES) ?: return null
            return keys.zip(values).toMap().toJsonElementMap()
        }
    }
}
