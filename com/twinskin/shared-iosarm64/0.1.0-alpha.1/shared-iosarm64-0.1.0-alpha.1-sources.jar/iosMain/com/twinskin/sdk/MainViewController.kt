package com.twinskin.sdk

import androidx.compose.ui.window.ComposeUIViewController
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.ui.CaptureScreen
import com.twinskin.sdk.ui.EditOutlineScreen
import com.twinskin.sdk.ui.View3DScreen
import com.twinskin.sdk.ui.View3DSceneKitScreen
import com.twinskin.sdk.ui.view_capture.ViewCaptureScreenHost
import com.twinskin.sdk.view.CaptureSource
import com.twinskin.sdk.view.ViewCaptureOptions

fun CaptureViewController(metadata: SdkCaptureMetadata) = ComposeUIViewController {
    CaptureScreen(metadata = metadata)
}
fun EditOutlineViewController() = ComposeUIViewController { EditOutlineScreen() }
fun View3DViewController() = ComposeUIViewController { View3DScreen() }
fun View3DSceneKitViewController() = ComposeUIViewController { View3DSceneKitScreen() }

fun ViewCaptureViewController(
    source: CaptureSource,
    options: ViewCaptureOptions = ViewCaptureOptions(),
    onClose: () -> Unit = {},
) = ComposeUIViewController {
    ViewCaptureScreenHost(source = source, options = options, onClose = onClose)
}
