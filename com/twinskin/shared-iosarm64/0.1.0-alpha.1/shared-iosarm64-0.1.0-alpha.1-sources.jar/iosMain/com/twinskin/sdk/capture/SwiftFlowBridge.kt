package com.twinskin.sdk.capture

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

/**
 * Glue used by the Swift `TwinSkinCaptureObserver` wrapper. Kotlin's
 * cold `Flow` doesn't bridge cleanly to Swift on its own (no `for await`,
 * no `.value`), so we offer a callback-based subscription that the Swift
 * side wraps into an `AsyncStream`.
 *
 * Not part of the public Kotlin API — Android callers use the original
 * `Flow` directly via `collectAsState`.
 */

/** Cancellation handle returned to Swift. */
class FlowSubscription internal constructor(private val job: Job) {
    fun cancel() {
        job.cancel()
    }
}

/**
 * Long-lived scope used to drive every Swift-side subscription. Uses
 * `Dispatchers.Main` so callbacks land on the main thread — SwiftUI
 * requires `AsyncStream.yield` from the main actor when the consumer is
 * `@MainActor`.
 */
private val swiftBridgeScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

fun CaptureObserver.observePendingUploadsFromSwift(
    onEach: (List<PendingUpload>) -> Unit,
): FlowSubscription =
    observePendingUploads().subscribeFromSwift(onEach)

fun CaptureObserver.observeSubjectFromSwift(
    subjectRef: String,
    onEach: (List<CaptureEntry>) -> Unit,
): FlowSubscription =
    observeSubject(subjectRef).subscribeFromSwift(onEach)

private fun <T> Flow<T>.subscribeFromSwift(onEach: (T) -> Unit): FlowSubscription {
    val job = swiftBridgeScope.launch {
        collect { onEach(it) }
    }
    return FlowSubscription(job)
}
