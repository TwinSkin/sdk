@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.twinskin.sdk.capture.io

import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.autoreleasepool
import kotlinx.cinterop.convert
import kotlinx.cinterop.usePinned
import platform.Foundation.NSData
import platform.Foundation.NSFileHandle
import platform.Foundation.NSFileManager
import platform.Foundation.dataWithBytesNoCopy
import platform.Foundation.closeFile
import platform.Foundation.fileHandleForWritingAtPath
import platform.Foundation.seekToFileOffset
import platform.Foundation.writeData

internal actual class RandomAccessByteSink actual constructor(path: String) {

    private val handle: NSFileHandle
    private var appendPos: Long = 0L
    private var closed = false

    init {
        // createFileAtPath truncates if the file already exists — matches the Android
        // `setLength(0)` behavior so callers don't have to worry about stale bytes.
        NSFileManager.defaultManager.createFileAtPath(path, contents = null, attributes = null)
        handle = NSFileHandle.fileHandleForWritingAtPath(path)
            ?: error("Failed to open for writing: $path")
    }

    actual fun write(src: ByteArray, off: Int, len: Int) {
        if (len == 0) return
        handle.seekToFileOffset(appendPos.toULong())
        writeSlice(src, off, len)
        appendPos += len
    }

    actual fun writeAt(pos: Long, src: ByteArray, off: Int, len: Int) {
        if (len == 0) return
        handle.seekToFileOffset(pos.toULong())
        writeSlice(src, off, len)
    }

    actual fun close() {
        if (closed) return
        closed = true
        handle.closeFile()
    }

    private fun writeSlice(src: ByteArray, off: Int, len: Int) {
        // autoreleasepool bounds NSData accumulation — writes are called in a tight
        // streaming loop and the outer pool only drains at thread-top, which would
        // otherwise grow unboundedly for multi-GiB videos.
        autoreleasepool {
            src.usePinned { pinned ->
                // dataWithBytesNoCopy avoids a buffer copy; the pin holds the bytes alive for
                // the duration of writeData. freeWhenDone=false — Kotlin owns the array.
                val data = NSData.dataWithBytesNoCopy(
                    bytes = pinned.addressOf(off),
                    length = len.convert(),
                    freeWhenDone = false,
                )
                handle.writeData(data)
            }
        }
    }
}
