@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.capture.prototype

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.cinterop.ExperimentalForeignApi
import platform.AVFoundation.AVAuthorizationStatusAuthorized
import platform.AVFoundation.AVAuthorizationStatusDenied
import platform.AVFoundation.AVAuthorizationStatusNotDetermined
import platform.AVFoundation.AVAuthorizationStatusRestricted
import platform.AVFoundation.AVCaptureDevice
import platform.AVFoundation.AVMediaTypeAudio
import platform.AVFoundation.AVMediaTypeVideo
import platform.AVFoundation.authorizationStatusForMediaType
import platform.AVFoundation.requestAccessForMediaType
import platform.Foundation.NSOperationQueue

@Composable
actual fun rememberCapturePermissionsState(): CapturePermissionsState {
    val video = AVMediaTypeVideo!!
    val audio = AVMediaTypeAudio!!
    fun status(media: String) = AVCaptureDevice.authorizationStatusForMediaType(media)
    fun allGranted() =
        status(video) == AVAuthorizationStatusAuthorized &&
            status(audio) == AVAuthorizationStatusAuthorized
    fun anyDenied() = listOf(video, audio).any {
        val s = status(it)
        s == AVAuthorizationStatusDenied || s == AVAuthorizationStatusRestricted
    }

    var grantedState by remember { mutableStateOf(allGranted()) }
    var deniedState by remember { mutableStateOf(anyDenied()) }

    return remember {
        object : CapturePermissionsState {
            override val granted: Boolean get() = grantedState
            override val denied: Boolean get() = deniedState
            override fun request() {
                if (allGranted()) { grantedState = true; deniedState = false; return }
                AVCaptureDevice.requestAccessForMediaType(video) { videoOk ->
                    AVCaptureDevice.requestAccessForMediaType(audio) { audioOk ->
                        NSOperationQueue.mainQueue.addOperationWithBlock {
                            grantedState = videoOk && audioOk
                            deniedState = !(videoOk && audioOk)
                        }
                    }
                }
            }
        }
    }
}
