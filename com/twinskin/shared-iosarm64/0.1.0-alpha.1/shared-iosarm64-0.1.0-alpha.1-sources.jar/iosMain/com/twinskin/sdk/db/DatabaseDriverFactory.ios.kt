package com.twinskin.sdk.db

import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.driver.native.NativeSqliteDriver
import app.cash.sqldelight.driver.native.inMemoryDriver

actual class DatabaseDriverFactory actual constructor(private val dbName: String) {
    actual fun create(): SqlDriver = when (dbName) {
        ":memory:" -> inMemoryDriver(TwinSkinDatabase.Schema)
        else -> NativeSqliteDriver(TwinSkinDatabase.Schema, dbName)
    }
}
