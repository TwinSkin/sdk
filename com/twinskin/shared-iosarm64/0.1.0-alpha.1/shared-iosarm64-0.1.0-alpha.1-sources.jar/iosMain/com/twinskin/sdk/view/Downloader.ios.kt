@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.view

import io.ktor.client.HttpClient
import io.ktor.client.plugins.onDownload
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsChannel
import io.ktor.http.HttpStatusCode
import io.ktor.http.isSuccess
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.readAvailable
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.usePinned
import platform.Foundation.NSData
import platform.Foundation.NSFileHandle
import platform.Foundation.NSFileManager
import platform.Foundation.NSURL
import platform.Foundation.dataWithBytes
import platform.Foundation.fileHandleForWritingAtPath
import platform.Foundation.writeData

private val client = HttpClient()

actual suspend fun downloadToPath(
    url: String,
    destPath: String,
    onProgress: (bytesRead: Long, total: Long?) -> Unit,
) {
    // No `withContext(Dispatchers.IO)` here, unlike the Android actual:
    // - `Dispatchers.IO` is `internal` in kotlinx-coroutines' Native build, so
    //   we can't reach it from iosMain.
    // - ktor's Darwin engine performs HTTP I/O on `NSURLSession`'s private
    //   serial queue, not on our coroutine dispatcher.
    // - The only work that lands on the caller's dispatcher is the
    //   `NSFileHandle.writeData` call per chunk, which is a fast buffered
    //   kernel syscall (~microseconds for 64 KB).
    // Net: wrapping here would add synchronization cost without measurable
    // latency benefit on Native. Reassess if profiling shows Default-pool
    // starvation under concurrent downloads.
    val fm = NSFileManager.defaultManager
    val parent = NSURL.fileURLWithPath(destPath).URLByDeletingLastPathComponent
    if (parent != null) {
        fm.createDirectoryAtURL(parent, true, null, null)
    }
    if (fm.fileExistsAtPath(destPath)) fm.removeItemAtPath(destPath, null)
    fm.createFileAtPath(destPath, null, null)

    // Stream chunks straight to an NSFileHandle rather than buffering the
    // whole body — avoids OOM on 10-20+ MB wound captures.
    val handle = NSFileHandle.fileHandleForWritingAtPath(destPath)
        ?: error("Failed to open $destPath for writing")

    client.prepareGet(url) {
        onDownload { bytesSentTotal, contentLength ->
            onProgress(bytesSentTotal, contentLength)
        }
    }.execute { response ->
        if (response.status == HttpStatusCode.NotFound) {
            throw CaptureNotFoundException("$url returned 404")
        }
        if (!response.status.isSuccess()) {
            throw CaptureNetworkException("$url returned ${response.status.value}")
        }
        val channel: ByteReadChannel = response.bodyAsChannel()
        val buffer = ByteArray(64 * 1024)
        while (!channel.isClosedForRead) {
            val read = channel.readAvailable(buffer, 0, buffer.size)
            if (read > 0) {
                val data = buffer.usePinned { pinned ->
                    NSData.dataWithBytes(pinned.addressOf(0), read.toULong())
                }
                handle.writeData(data)
            }
        }
    }
    // NSFileHandle closes the underlying fd on dealloc; `handle` goes out of
    // scope here and is released, flushing and closing the file. Explicit
    // `closeFile()` is deprecated on iOS 13+ and the modern replacement
    // (`closeAndReturnError:`) isn't worth the cinterop dance for a one-shot.
}
