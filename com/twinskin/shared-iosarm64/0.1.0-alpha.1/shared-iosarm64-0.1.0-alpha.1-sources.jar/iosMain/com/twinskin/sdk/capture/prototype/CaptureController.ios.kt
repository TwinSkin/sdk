@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.twinskin.sdk.capture.prototype

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.interop.UIKitView
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.CValue
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.alloc
import kotlinx.cinterop.convert
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.useContents
import kotlinx.cinterop.usePinned
import kotlinx.cinterop.value
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import platform.AVFoundation.AVCaptureConnection
import platform.AVFoundation.AVCaptureDevice
import platform.AVFoundation.AVCaptureDeviceInput
import platform.AVFoundation.AVCaptureDevicePositionBack
import platform.AVFoundation.AVCaptureFileOutput
import platform.AVFoundation.AVCaptureFileOutputRecordingDelegateProtocol
import platform.AVFoundation.AVCaptureMovieFileOutput
import platform.AVFoundation.AVCapturePhoto
import platform.AVFoundation.AVCapturePhotoCaptureDelegateProtocol
import platform.AVFoundation.AVCapturePhotoOutput
import platform.AVFoundation.AVCapturePhotoSettings
import platform.AVFoundation.AVCaptureSession
import platform.AVFoundation.AVCaptureSessionPresetHigh
import platform.AVFoundation.AVCaptureVideoPreviewLayer
import platform.AVFoundation.AVLayerVideoGravityResizeAspectFill
import platform.AVFoundation.AVMediaTypeAudio
import platform.AVFoundation.AVMediaTypeVideo
import platform.AVFoundation.fileDataRepresentation
import platform.AVFoundation.position
import platform.CoreGraphics.CGRect
import platform.Foundation.NSError
import platform.Foundation.NSFileManager
import platform.Foundation.NSURL
import platform.Foundation.NSUUID
import platform.Foundation.NSData
import platform.Foundation.NSTemporaryDirectory
import platform.UIKit.UIView
import platform.darwin.NSObject
import platform.darwin.dispatch_async
import platform.darwin.dispatch_get_global_queue
import platform.darwin.DISPATCH_QUEUE_PRIORITY_DEFAULT
import platform.posix.memcpy
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * PROTOTYPE AVFoundation-backed [CaptureController]. Lives in this package and is deleted
 * wholesale once the production capture code lands.
 */
class IosCaptureController : CaptureController {

    private val _state = MutableStateFlow<CaptureControllerState>(CaptureControllerState.Initializing)
    override val state: StateFlow<CaptureControllerState> = _state.asStateFlow()

    internal val session = AVCaptureSession()
    private val photoOutput = AVCapturePhotoOutput()
    private val movieOutput = AVCaptureMovieFileOutput()
    internal val previewLayer: AVCaptureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session = session).apply {
        videoGravity = AVLayerVideoGravityResizeAspectFill
    }

    private val photoDelegate = PhotoDelegate(this)
    private val movieDelegate = MovieDelegate(this)

    private var videoFileUrl: NSURL? = null

    internal var pendingPhoto: CancellableContinuation<ByteArray>? = null
    internal var pendingStart: CancellableContinuation<Unit>? = null
    internal var pendingStop: CancellableContinuation<String>? = null

    fun start() {
        configureSession()
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT.convert(), 0u)) {
            session.startRunning()
            _state.value = CaptureControllerState.Ready
        }
    }

    private fun configureSession() {
        session.beginConfiguration()
        session.sessionPreset = AVCaptureSessionPresetHigh

        val videoDevice = AVCaptureDevice.devicesWithMediaType(AVMediaTypeVideo)
            .filterIsInstance<AVCaptureDevice>()
            .firstOrNull { it.position == AVCaptureDevicePositionBack }
            ?: AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)

        if (videoDevice != null) {
            memScoped {
                val errPtr = alloc<kotlinx.cinterop.ObjCObjectVar<NSError?>>()
                val input = AVCaptureDeviceInput.deviceInputWithDevice(videoDevice, errPtr.ptr)
                if (input != null && session.canAddInput(input)) session.addInput(input)
            }
        }
        val audioDevice = AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeAudio)
        if (audioDevice != null) {
            memScoped {
                val errPtr = alloc<kotlinx.cinterop.ObjCObjectVar<NSError?>>()
                val audioInput = AVCaptureDeviceInput.deviceInputWithDevice(audioDevice, errPtr.ptr)
                if (audioInput != null && session.canAddInput(audioInput)) session.addInput(audioInput)
            }
        }
        if (session.canAddOutput(photoOutput)) session.addOutput(photoOutput)
        if (session.canAddOutput(movieOutput)) session.addOutput(movieOutput)
        session.commitConfiguration()
    }

    override suspend fun takePhoto(): ByteArray = suspendCancellableCoroutine { cont ->
        check(pendingPhoto == null) { "Photo already in progress" }
        pendingPhoto = cont
        _state.value = CaptureControllerState.CapturingPhoto
        val settings = AVCapturePhotoSettings.photoSettings()
        photoOutput.capturePhotoWithSettings(settings, photoDelegate)
    }

    override suspend fun startRecording(): Unit = suspendCancellableCoroutine { cont ->
        check(pendingStart == null && !movieOutput.isRecording()) { "Recording already in progress" }
        val path = NSTemporaryDirectory() + "sdk-capture-" + NSUUID().UUIDString() + ".mov"
        val url = NSURL.fileURLWithPath(path)
        videoFileUrl = url
        pendingStart = cont
        movieOutput.startRecordingToOutputFileURL(url, movieDelegate)
    }

    override suspend fun stopRecording(): String = suspendCancellableCoroutine { cont ->
        if (!movieOutput.isRecording()) {
            cont.resumeWithException(IllegalStateException("No active recording"))
            return@suspendCancellableCoroutine
        }
        check(pendingStop == null) { "Stop already requested" }
        pendingStop = cont
        movieOutput.stopRecording()
    }

    override fun dispose() {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT.convert(), 0u)) {
            if (session.isRunning()) session.stopRunning()
        }
    }

    internal fun onPhotoReady(data: NSData) {
        val cont = pendingPhoto; pendingPhoto = null
        _state.value = CaptureControllerState.Ready
        cont?.resume(data.toByteArray())
    }

    internal fun onPhotoError(message: String) {
        val cont = pendingPhoto; pendingPhoto = null
        _state.value = CaptureControllerState.Error(message)
        cont?.resumeWithException(RuntimeException(message))
    }

    internal fun onRecordingStarted() {
        val cont = pendingStart; pendingStart = null
        _state.value = CaptureControllerState.Recording
        cont?.resume(Unit)
    }

    internal fun onRecordingFinished(url: NSURL, error: NSError?) {
        val cont = pendingStop; pendingStop = null
        if (error != null) {
            // Ownership was about to transfer to the SDK submit pipeline; since we're
            // failing here instead, delete the temp file ourselves so NSTemporaryDirectory
            // doesn't accumulate .mov files across failed captures.
            NSFileManager.defaultManager.removeItemAtURL(url, error = null)
            _state.value = CaptureControllerState.Error(error.localizedDescription)
            cont?.resumeWithException(RuntimeException(error.localizedDescription))
            return
        }
        val path = url.path
        if (path == null) {
            NSFileManager.defaultManager.removeItemAtURL(url, error = null)
            _state.value = CaptureControllerState.Error("video URL has no path")
            cont?.resumeWithException(RuntimeException("video URL has no path"))
            return
        }
        _state.value = CaptureControllerState.Ready
        cont?.resume(path)
    }
}

private class PhotoDelegate(private val controller: IosCaptureController) :
    NSObject(), AVCapturePhotoCaptureDelegateProtocol {
    override fun captureOutput(
        output: AVCapturePhotoOutput,
        didFinishProcessingPhoto: AVCapturePhoto,
        error: NSError?,
    ) {
        if (error != null) {
            controller.onPhotoError(error.localizedDescription)
            return
        }
        val data = didFinishProcessingPhoto.fileDataRepresentation()
        if (data == null) controller.onPhotoError("no photo data")
        else controller.onPhotoReady(data)
    }
}

private class MovieDelegate(private val controller: IosCaptureController) :
    NSObject(), AVCaptureFileOutputRecordingDelegateProtocol {
    override fun captureOutput(
        output: AVCaptureFileOutput,
        didStartRecordingToOutputFileAtURL: NSURL,
        fromConnections: List<*>,
    ) {
        controller.onRecordingStarted()
    }

    override fun captureOutput(
        output: AVCaptureFileOutput,
        didFinishRecordingToOutputFileAtURL: NSURL,
        fromConnections: List<*>,
        error: NSError?,
    ) {
        controller.onRecordingFinished(didFinishRecordingToOutputFileAtURL, error)
    }
}

private fun NSData.toByteArray(): ByteArray {
    val len = length.toInt()
    if (len == 0) return ByteArray(0)
    val out = ByteArray(len)
    out.usePinned { pinned -> memcpy(pinned.addressOf(0), bytes, length) }
    return out
}

@Composable
actual fun rememberPrototypeCaptureController(): CaptureController {
    val controller = remember { IosCaptureController() }
    LaunchedEffect(controller) { controller.start() }
    DisposableEffect(controller) { onDispose { controller.dispose() } }
    return controller
}

@Composable
actual fun CameraPreview(controller: CaptureController, modifier: Modifier) {
    val ios = controller as? IosCaptureController
        ?: error("CameraPreview requires IosCaptureController on this platform")
    UIKitView(
        factory = {
            val view = UIView()
            view.layer.addSublayer(ios.previewLayer)
            view
        },
        modifier = modifier,
        onResize = { _, rect: CValue<CGRect> ->
            ios.previewLayer.setFrame(rect)
        },
    )
}
