@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.transfer

import com.twinskin.sdk.db.TransferTaskQueries
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ObjCObjectVar
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.value
import kotlinx.coroutines.channels.SendChannel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flow
import platform.Foundation.NSError
import platform.Foundation.NSFileManager
import platform.Foundation.NSMutableURLRequest
import platform.Foundation.NSOperationQueue
import platform.Foundation.NSURL
import platform.Foundation.setValue
import platform.Foundation.setHTTPMethod
import platform.Foundation.NSURLSession
import platform.Foundation.NSURLSessionConfiguration
import platform.Foundation.NSURLSessionDownloadDelegateProtocol
import platform.Foundation.NSURLSessionDownloadTask
import platform.Foundation.NSURLSessionTask
import platform.darwin.NSObject
import kotlin.math.min

// ---------------------------------------------------------------------------
// Internal state per active task
// ---------------------------------------------------------------------------

internal data class TaskState(
    val channel: SendChannel<TransferUpdate>,
    val localPath: String,
    val type: TransferType,
)

// ---------------------------------------------------------------------------
// NativeSessionDelegate — bridges NSURLSession callbacks into Flows
// ---------------------------------------------------------------------------

internal class NativeSessionDelegate(
    /**
     * When provided, orphaned delegate callbacks (received after app relaunch, when no live
     * [TaskState] channel exists for the task) write the final status directly to the database.
     * This mirrors the Android [UploadWorker] → DB pattern for iOS background sessions.
     */
    private val queries: TransferTaskQueries? = null,
) : NSObject(), NSURLSessionDownloadDelegateProtocol {

    private val lock = platform.Foundation.NSLock()
    private val taskStates = mutableMapOf<String, TaskState>()

    /** Callback wired by BackgroundTransferHandler to forward the iOS completion handler. */
    var onBackgroundEventsFinished: ((String) -> Unit)? = null

    internal fun registerState(id: String, state: TaskState) {
        lock.lock()
        taskStates[id] = state
        lock.unlock()
    }

    internal fun unregisterState(id: String) {
        lock.lock()
        taskStates.remove(id)
        lock.unlock()
    }

    private fun getState(id: String): TaskState? {
        lock.lock()
        val s = taskStates[id]
        lock.unlock()
        return s
    }

    private fun now(): Long = currentTimeMillis()

    // -----------------------------------------------------------------------
    // Download progress — URLSession:downloadTask:didWriteData:...
    // -----------------------------------------------------------------------

    override fun URLSession(
        session: NSURLSession,
        downloadTask: NSURLSessionDownloadTask,
        didWriteData: Long,
        totalBytesWritten: Long,
        totalBytesExpectedToWrite: Long,
    ) {
        val id = downloadTask.taskDescription ?: return
        val percent = if (totalBytesExpectedToWrite > 0L)
            ((totalBytesWritten * 100L) / totalBytesExpectedToWrite).toInt()
        else 0
        getState(id)?.channel?.trySend(TransferUpdate.Progress(percent))
    }

    // -----------------------------------------------------------------------
    // Download completion — URLSession:downloadTask:didFinishDownloadingToURL:
    // Task 4.1: atomic overwrite move to final destination
    // -----------------------------------------------------------------------

    override fun URLSession(
        session: NSURLSession,
        downloadTask: NSURLSessionDownloadTask,
        didFinishDownloadingToURL: NSURL,
    ) {
        val id = downloadTask.taskDescription ?: return
        val state = getState(id) ?: run {
            // Orphaned: app relaunched while download was in-flight. No live channel exists.
            // Move the downloaded temp file to its final destination and update the DB directly.
            val task = queries?.selectById(id)?.executeAsOneOrNull() ?: return
            val destPath = task.localPath
            val destUrl = NSURL.fileURLWithPath(destPath)
            val fm = NSFileManager.defaultManager
            memScoped {
                if (fm.fileExistsAtPath(destPath)) {
                    val rmErr = alloc<ObjCObjectVar<NSError?>>()
                    fm.removeItemAtPath(destPath, error = rmErr.ptr)
                }
                val mvErr = alloc<ObjCObjectVar<NSError?>>()
                val moved = fm.moveItemAtURL(
                    srcURL = didFinishDownloadingToURL,
                    toURL = destUrl,
                    error = mvErr.ptr,
                )
                if (moved) {
                    queries?.updateStatus(TransferStatus.COMPLETED.name, now(), id)
                } else {
                    val msg = mvErr.value?.localizedDescription ?: "File move failed (orphaned)"
                    queries?.updateStatusAndError(TransferStatus.FAILED.name, msg, now(), id)
                }
            }
            return
        }

        val destPath = state.localPath
        val destUrl = NSURL.fileURLWithPath(destPath)
        val fm = NSFileManager.defaultManager

        memScoped {
            // Remove existing file at destination for idempotent overwrite
            if (fm.fileExistsAtPath(destPath)) {
                val rmErr = alloc<ObjCObjectVar<NSError?>>()
                fm.removeItemAtPath(destPath, error = rmErr.ptr)
            }

            val mvErr = alloc<ObjCObjectVar<NSError?>>()
            val moved = fm.moveItemAtURL(
                srcURL = didFinishDownloadingToURL,
                toURL = destUrl,
                error = mvErr.ptr,
            )

            if (moved) {
                state.channel.trySend(TransferUpdate.Success)
            } else {
                val msg = mvErr.value?.localizedDescription ?: "File move failed"
                state.channel.trySend(TransferUpdate.Failure(msg))
            }
        }

        state.channel.close()
        unregisterState(id)
    }

    // -----------------------------------------------------------------------
    // Task completion / error — URLSession:task:didCompleteWithError:
    // Handles: all errors (download + upload) + upload success (nil error)
    // -----------------------------------------------------------------------

    override fun URLSession(
        session: NSURLSession,
        task: NSURLSessionTask,
        didCompleteWithError: NSError?,
    ) {
        val id = task.taskDescription ?: return
        val state = getState(id) ?: run {
            // Orphaned: app relaunched while a transfer was in-flight. No live channel exists.
            // For downloads: state was already removed in didFinishDownloadingToURL, so getState
            // returns null legitimately — nothing more to do.
            // For uploads: nil error = success, non-nil error = failure. Write directly to DB.
            if (queries != null) {
                val taskRow = queries.selectById(id).executeAsOneOrNull()
                when {
                    taskRow?.type == TransferType.UPLOAD.name -> {
                        if (didCompleteWithError != null) {
                            queries.updateStatusAndError(
                                TransferStatus.FAILED.name,
                                didCompleteWithError.localizedDescription,
                                now(),
                                id,
                            )
                        } else {
                            queries.updateStatus(TransferStatus.COMPLETED.name, now(), id)
                        }
                    }
                    // For downloads: didFinishDownloadingToURL already moved the file and removed
                    // the state. If we get here for a download it means the task errored before
                    // completing (e.g. network failure). Write FAILED so the task doesn't stay
                    // ACTIVE indefinitely after app relaunch.
                    taskRow?.type == TransferType.DOWNLOAD.name && didCompleteWithError != null -> {
                        queries.updateStatusAndError(
                            TransferStatus.FAILED.name,
                            didCompleteWithError.localizedDescription,
                            now(),
                            id,
                        )
                    }
                }
            }
            return
        }

        if (didCompleteWithError != null) {
            state.channel.trySend(TransferUpdate.Failure(didCompleteWithError.localizedDescription))
            state.channel.close()
            unregisterState(id)
        } else if (state.type == TransferType.UPLOAD) {
            // Uploads have no didFinishDownloadingToURL; nil error here means success.
            state.channel.trySend(TransferUpdate.Success)
            state.channel.close()
            unregisterState(id)
        }
    }

    // -----------------------------------------------------------------------
    // Upload progress — URLSession:task:didSendBodyData:totalBytesSent:...
    // -----------------------------------------------------------------------

    override fun URLSession(
        session: NSURLSession,
        task: NSURLSessionTask,
        didSendBodyData: Long,
        totalBytesSent: Long,
        totalBytesExpectedToSend: Long,
    ) {
        val id = task.taskDescription ?: return
        val percent = if (totalBytesExpectedToSend > 0L)
            ((totalBytesSent * 100L) / totalBytesExpectedToSend).toInt()
        else 0
        getState(id)?.channel?.trySend(TransferUpdate.Progress(percent))
    }

    // -----------------------------------------------------------------------
    // Background session finished delivering events — call stored iOS handler
    // -----------------------------------------------------------------------

    override fun URLSessionDidFinishEventsForBackgroundURLSession(session: NSURLSession) {
        val identifier = session.configuration.identifier ?: return
        onBackgroundEventsFinished?.invoke(identifier)
    }
}

// ---------------------------------------------------------------------------
// NativeFileTransferProvider — public entry point for the iOS platform
// ---------------------------------------------------------------------------

/**
 * iOS implementation of [FileTransferProvider] backed by a background [NSURLSession].
 *
 * For **downloads**, the `url` parameter is the direct HTTP URL and headers are applied to the
 * request. For **uploads**, the `url` parameter is the stable server-side upload key; the provider
 * calls [urlResolver] on each attempt to obtain a fresh presigned URL. This design ensures a
 * non-expired URL is used even after the app is relaunched via a BGProcessingTask.
 *
 * Create a single instance per app and register it with [BackgroundTransferHandler]:
 * ```
 * val provider = NativeFileTransferProvider(
 *     sessionIdentifier = "${bundleId}.sdk.transfers",
 *     urlResolver       = myResolver,
 *     backgroundScheduler = IosBackgroundScheduler(),
 * )
 * BackgroundTransferHandler.configure(provider)
 * val manager = TransferManager(database, provider, zipEngine, scope)
 * ```
 *
 * ## Testability
 * Inject [sessionConfigurationFactory] to swap the background session for an ephemeral one
 * in simulator tests — ephemeral sessions are fully in-process and can reach a localhost
 * test server:
 * ```
 * val provider = NativeFileTransferProvider(
 *     sessionIdentifier       = "test",
 *     urlResolver             = { UrlResult.Url(testServerUrl) },
 *     backgroundScheduler     = FakeBackgroundScheduler(),
 *     sessionConfigurationFactory = { _ -> NSURLSessionConfiguration.ephemeralSessionConfiguration() },
 * )
 * ```
 */
class NativeFileTransferProvider(
    private val sessionIdentifier: String,
    /**
     * Resolves a stable upload key to a presigned URL (or [UrlResult.AlreadyExist] /
     * [UrlResult.RetryableError]).  Called on every upload attempt so the URL is always fresh.
     */
    private val urlResolver: UrlResolver,
    /** Schedules a BGProcessingTask wakeup when an upload hits [UrlResult.RetryableError]. */
    private val backgroundScheduler: BackgroundScheduler,
    /** Initial delay between upload retry attempts (ms). Default 5 s; set to 0 in tests. */
    private val retryDelayMs: Long = 5_000L,
    /**
     * Maximum number of retry iterations in the upload resolver → PUT loop before failing
     * permanently. Default 20 (~35 min with exponential backoff capped at 5 min).
     */
    private val maxRetries: Int = DEFAULT_MAX_RETRIES,
    /**
     * Factory that produces the [NSURLSessionConfiguration] for the session.
     *
     * Default: background configuration with the given [sessionIdentifier], required for
     * transfers that continue after the app is suspended.
     *
     * Override in tests with [NSURLSessionConfiguration.ephemeralSessionConfiguration] so
     * that requests are handled in-process and can reach a localhost HTTP server.
     */
    private val sessionConfigurationFactory: (String) -> NSURLSessionConfiguration = { id ->
        NSURLSessionConfiguration
            .backgroundSessionConfigurationWithIdentifier(id)
            .also {
                it.discretionary = false
                it.sessionSendsLaunchEvents = true
            }
    },
    /**
     * When provided, orphaned background-session callbacks (no live coroutine channel for the
     * task) write the final status directly to the database — the same pattern as Android's
     * [UploadWorker]. Pass [TwinSkinDatabase.transferTaskQueries] here for production use.
     */
    internal val transferQueries: TransferTaskQueries? = null,
) : FileTransferProvider {

    internal val delegate = NativeSessionDelegate(queries = transferQueries)

    /**
     * The NSURLSession. Created lazily so that calling [reconnect] during app relaunch
     * (before any explicit transfer) still triggers iOS to replay pending callbacks.
     */
    private val session: NSURLSession by lazy {
        NSURLSession.sessionWithConfiguration(
            configuration = sessionConfigurationFactory(sessionIdentifier),
            delegate = delegate,
            delegateQueue = null, // nil → iOS uses an internal serial queue
        )
    }

    /**
     * Triggers lazy session creation so iOS can replay pending background task callbacks.
     * Called by [BackgroundTransferHandler.handleBackgroundEvents].
     */
    internal fun reconnect() {
        session.configuration // accessing the lazy property is enough
    }

    override fun execute(
        id: String,
        url: String,
        path: String,
        type: TransferType,
        headers: Map<String, String>,
    ): Flow<TransferUpdate> = when (type) {
        TransferType.UPLOAD   -> executeUploadWithRetry(id, uploadKey = url, path = path, headers = headers)
        TransferType.DOWNLOAD -> executeDownload(id, url = url, path = path, headers = headers)
    }

    // -----------------------------------------------------------------------
    // Upload: resolver → PUT loop with exponential backoff
    // -----------------------------------------------------------------------

    /**
     * Runs the full resolver → PUT loop, retrying on [UrlResult.RetryableError] or PUT failure
     * with exponential backoff. The loop continues until [UrlResult.AlreadyExist], a successful
     * PUT, or [maxRetries] is exhausted.
     *
     * Each PUT attempt is a separate [NSURLSession] task created by [singleUploadAttemptFlow].
     *
     * Backoff: starts at [retryDelayMs], doubles each iteration, capped at [MAX_RETRY_DELAY_MS].
     */
    private fun executeUploadWithRetry(
        id: String,
        uploadKey: String,
        path: String,
        headers: Map<String, String>,
    ): Flow<TransferUpdate> = flow {
        var attempt = 0
        var currentDelay = retryDelayMs

        while (attempt < maxRetries) {
            when (val result = urlResolver(uploadKey)) {
                is UrlResult.AlreadyExist -> {
                    backgroundScheduler.cancelUploadRetry(id)
                    emit(TransferUpdate.Progress(100))
                    emit(TransferUpdate.Success)
                    return@flow
                }
                is UrlResult.RetryableError -> {
                    attempt++
                    if (attempt >= maxRetries) {
                        backgroundScheduler.cancelUploadRetry(id)
                        emit(TransferUpdate.Failure(
                            "Upload failed after $maxRetries attempts: URL resolver returned RetryableError"
                        ))
                        return@flow
                    }
                    backgroundScheduler.scheduleUploadRetry(id)
                    delay(currentDelay)
                    currentDelay = min(currentDelay * 2, MAX_RETRY_DELAY_MS)
                }
                is UrlResult.Url -> {
                    var putSucceeded = false
                    var terminalFailure: String? = null
                    singleUploadAttemptFlow(id, result.url, path, headers).collect { update ->
                        when (update) {
                            is TransferUpdate.Progress -> emit(update)
                            is TransferUpdate.Success  -> putSucceeded = true
                            is TransferUpdate.Failure  -> {
                                // File-not-found is a terminal error — retrying will never help.
                                // Other HTTP/network errors are transient and worth retrying.
                                if (update.error.startsWith("File not found")) {
                                    terminalFailure = update.error
                                }
                                // else: PUT failed transiently; loop back to resolver
                            }
                        }
                    }
                    if (terminalFailure != null) {
                        emit(TransferUpdate.Failure(terminalFailure!!))
                        return@flow
                    }
                    if (putSucceeded) {
                        backgroundScheduler.cancelUploadRetry(id)
                        emit(TransferUpdate.Success)
                        return@flow
                    }
                    // PUT failed transiently — re-resolve to get a fresh URL on next iteration
                    attempt++
                    if (attempt >= maxRetries) {
                        backgroundScheduler.cancelUploadRetry(id)
                        emit(TransferUpdate.Failure(
                            "Upload failed after $maxRetries attempts: HTTP PUT failed"
                        ))
                        return@flow
                    }
                    delay(currentDelay)
                    currentDelay = min(currentDelay * 2, MAX_RETRY_DELAY_MS)
                }
            }
        }
    }

    /**
     * Performs a single HTTP PUT of [path] to [resolvedUrl] via NSURLSession.
     * The returned flow completes when the task finishes (success or error).
     */
    private fun singleUploadAttemptFlow(
        id: String,
        resolvedUrl: String,
        path: String,
        headers: Map<String, String>,
    ): Flow<TransferUpdate> = callbackFlow {
        val fileExists = platform.Foundation.NSFileManager.defaultManager.fileExistsAtPath(path)

        // Guard: uploadTaskWithRequest(fromFile:) throws NSInvalidArgumentException if the
        // file is missing (e.g. tmp files cleaned up after force-kill). NSExceptions are not
        // catchable by Kotlin try/catch, so we must check before calling the ObjC API.
        if (!fileExists) {
            trySend(TransferUpdate.Failure("File not found: $path"))
            close()
            awaitClose { /* state was never registered */ }
            return@callbackFlow
        }

        delegate.registerState(id, TaskState(channel, path, TransferType.UPLOAD))

        val nsUrl = NSURL.URLWithString(resolvedUrl)
        if (nsUrl == null) {
            trySend(TransferUpdate.Failure("Invalid URL: $resolvedUrl"))
            close()
        } else {
            val request = NSMutableURLRequest.requestWithURL(nsUrl)
            request.setHTTPMethod("PUT")
            headers.forEach { (key, value) ->
                request.setValue(value, forHTTPHeaderField = key)
            }
            val task = session.uploadTaskWithRequest(
                request  = request,
                fromFile = NSURL.fileURLWithPath(path),
            )
            task.taskDescription = id
            task.resume()
        }

        awaitClose { delegate.unregisterState(id) }
    }

    // -----------------------------------------------------------------------
    // Download
    // -----------------------------------------------------------------------

    private fun executeDownload(
        id: String,
        url: String,
        path: String,
        headers: Map<String, String>,
    ): Flow<TransferUpdate> = callbackFlow {
        delegate.registerState(id, TaskState(channel, path, TransferType.DOWNLOAD))

        val nsUrl = NSURL.URLWithString(url)
        if (nsUrl == null) {
            trySend(TransferUpdate.Failure("Invalid URL: $url"))
            close()
        } else {
            val request = NSMutableURLRequest.requestWithURL(nsUrl)
            headers.forEach { (key, value) ->
                request.setValue(value, forHTTPHeaderField = key)
            }
            val task = session.downloadTaskWithRequest(request)
            task.taskDescription = id
            task.resume()
        }

        awaitClose { delegate.unregisterState(id) }
    }

    companion object {
        /** Maximum delay between retries (5 minutes). */
        internal const val MAX_RETRY_DELAY_MS = 5 * 60 * 1000L
        /** Default max retry attempts. ~35 min total with exponential backoff capped at 5 min. */
        internal const val DEFAULT_MAX_RETRIES = 20
    }
}
