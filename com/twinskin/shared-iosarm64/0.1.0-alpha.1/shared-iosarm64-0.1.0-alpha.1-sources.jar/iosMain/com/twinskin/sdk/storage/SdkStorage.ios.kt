@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.storage

import com.twinskin.sdk.SdkLogger
import kotlinx.cinterop.ExperimentalForeignApi
import platform.Foundation.NSApplicationSupportDirectory
import platform.Foundation.NSCachesDirectory
import platform.Foundation.NSDate
import platform.Foundation.NSFileManager
import platform.Foundation.NSFileModificationDate
import platform.Foundation.NSSearchPathForDirectoriesInDomains
import platform.Foundation.NSUserDomainMask
import platform.Foundation.timeIntervalSince1970

/**
 * iOS [SdkStorage]. Evictable state lives under `$NSCachesDirectory/twinskin/`
 * so iCloud backup skips it and the OS can reclaim space under pressure.
 *
 * [Purpose.Databases] points at `$NSApplicationSupportDirectory/databases/` —
 * the directory PowerSync's `appleDefaultDatabasePath` hardcodes. Callers
 * filter by filename to avoid touching unrelated DBs.
 */
internal class IosSdkStorage : SdkStorage {
    private val fm = NSFileManager.defaultManager

    private val twinskinCacheRoot: String by lazy {
        val cachesDirs = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, true)
        val caches = cachesDirs.firstOrNull() as? String
            ?: error("iOS Caches dir unexpectedly empty — NSSearchPathForDirectoriesInDomains returned no entries")
        val root = "$caches/twinskin"
        ensureDirExists(root)
        root
    }

    // Databases dir is owned by the SQLite/PowerSync layer — we never create it,
    // only enumerate for sweep/wipe.
    private val databasesDir: String by lazy {
        val supportDirs = NSSearchPathForDirectoriesInDomains(
            NSApplicationSupportDirectory,
            NSUserDomainMask,
            true,
        )
        val support = supportDirs.firstOrNull() as? String
            ?: error("iOS Application Support dir unexpectedly empty")
        "$support/databases"
    }

    override fun dir(purpose: Purpose): String = when (purpose) {
        Purpose.Databases -> databasesDir
        else -> subdir(purpose.subdirName)
    }

    override fun sweep(
        purpose: Purpose,
        olderThanMs: Long,
        logger: SdkLogger,
        filter: (name: String) -> Boolean,
    ) {
        val cutoffSec = NSDate().timeIntervalSince1970 - (olderThanMs / 1000.0)
        forEachEntry(purpose, logger) { name, fullPath ->
            if (!filter(name)) return@forEachEntry
            val modSec = fileModTimeSeconds(fullPath) ?: return@forEachEntry
            if (modSec < cutoffSec) removeAt(fullPath, logger)
        }
    }

    override fun wipe(
        purpose: Purpose,
        logger: SdkLogger,
        filter: (name: String) -> Boolean,
    ) {
        forEachEntry(purpose, logger) { name, fullPath ->
            if (filter(name)) removeAt(fullPath, logger)
        }
    }

    private fun subdir(name: String): String {
        val path = "$twinskinCacheRoot/$name"
        ensureDirExists(path)
        return path
    }

    private fun ensureDirExists(path: String) {
        runCatching {
            if (!fm.fileExistsAtPath(path)) {
                fm.createDirectoryAtPath(path, withIntermediateDirectories = true, attributes = null, error = null)
            }
        }
    }

    private inline fun forEachEntry(
        purpose: Purpose,
        logger: SdkLogger,
        block: (name: String, fullPath: String) -> Unit,
    ) {
        runCatching {
            val root = dir(purpose)
            if (!fm.fileExistsAtPath(root)) return
            val entries = fm.contentsOfDirectoryAtPath(root, error = null) ?: return
            for (entry in entries) {
                val name = entry as? String ?: continue
                block(name, "$root/$name")
            }
        }.onFailure { logger.log("SdkStorage: failed to enumerate ${purpose.name}", it) }
    }

    private fun fileModTimeSeconds(path: String): Double? {
        val attrs = fm.attributesOfItemAtPath(path, error = null) ?: return null
        val modDate = attrs[NSFileModificationDate] as? NSDate ?: return null
        return modDate.timeIntervalSince1970
    }

    private fun removeAt(path: String, logger: SdkLogger) {
        // removeItemAtPath:error: returns BOOL on failure, not a thrown
        // NSError — runCatching alone would swallow the false return.
        runCatching {
            if (!fm.removeItemAtPath(path, error = null)) {
                logger.log("SdkStorage: removeItemAtPath returned false for $path")
            }
        }.onFailure { logger.log("SdkStorage: failed to delete $path", it) }
    }
}
