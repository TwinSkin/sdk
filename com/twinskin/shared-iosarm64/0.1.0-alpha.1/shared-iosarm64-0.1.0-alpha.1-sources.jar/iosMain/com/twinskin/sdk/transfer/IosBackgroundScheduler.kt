@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.transfer

import kotlinx.cinterop.ExperimentalForeignApi
import platform.BackgroundTasks.BGProcessingTaskRequest
import platform.BackgroundTasks.BGTaskScheduler

/**
 * iOS implementation of [BackgroundScheduler] backed by [BGTaskScheduler].
 *
 * When an upload hits [UrlResult.RetryableError] (typically no network), this scheduler
 * submits a [BGProcessingTaskRequest] with [requiresNetworkConnectivity = true]. iOS will
 * wake the app in the background when a connection becomes available, allowing
 * [TransferManager] to retry the URL-resolver → PUT loop.
 *
 * ## Setup required in the host app
 *
 * 1. **Info.plist** — declare the permitted task identifier:
 *    ```xml
 *    <key>BGTaskSchedulerPermittedIdentifiers</key>
 *    <array>
 *        <string>com.twinskin.sdk.upload-retry</string>
 *    </array>
 *    ```
 *
 * 2. **AppDelegate** — register the handler before `applicationDidFinishLaunching` returns:
 *    ```swift
 *    BGTaskScheduler.sharedScheduler.register(
 *        forTaskWithIdentifier: IosBackgroundScheduler.taskIdentifier,
 *        using: nil
 *    ) { task in
 *        BackgroundTransferHandler.shared.handleUploadRetryTask(task: task as! BGProcessingTask)
 *    }
 *    ```
 *
 * Submissions are idempotent — if a request for the same identifier is already pending,
 * the OS silently replaces it, so calling [scheduleUploadRetry] multiple times is safe.
 */
class IosBackgroundScheduler : BackgroundScheduler {

    companion object {
        /** Must match the identifier declared in Info.plist. */
        const val taskIdentifier = "com.twinskin.sdk.upload-retry"
    }

    override fun scheduleUploadRetry(taskId: String) {
        val request = BGProcessingTaskRequest(identifier = taskIdentifier)
        request.requiresNetworkConnectivity = true
        request.requiresExternalPower = false
        // Error is intentionally ignored — if BGTask can't be submitted (e.g. not declared
        // in Info.plist) the retry loop will still work when the app is in foreground.
        BGTaskScheduler.sharedScheduler.submitTaskRequest(request, error = null)
    }

    override fun cancelUploadRetry(taskId: String) {
        BGTaskScheduler.sharedScheduler.cancelTaskRequestWithIdentifier(taskIdentifier)
    }
}
