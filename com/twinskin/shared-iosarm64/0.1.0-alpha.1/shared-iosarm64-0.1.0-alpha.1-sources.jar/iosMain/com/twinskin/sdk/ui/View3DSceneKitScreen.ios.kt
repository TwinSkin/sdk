@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalForeignApi::class)

package com.twinskin.sdk.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.interop.UIKitView
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import platform.CoreGraphics.CGRectMake
import platform.SceneKit.*
import platform.UIKit.UIColor
import kotlin.math.PI

@Composable
actual fun View3DSceneKitScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("View 3D SceneKit (iOS)") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0066E6),
                    titleContentColor = Color.White,
                ),
            )
        }
    ) { padding ->
        UIKitView(
            factory = { createSceneKitView() },
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        )
    }
}

private fun createSceneKitView(): SCNView {
    val scene = SCNScene()

    // Geometry: a rounded box
    val box = SCNBox.boxWithWidth(width = 1.0, height = 1.0, length = 1.0, chamferRadius = 0.1)
    val material = SCNMaterial()
    material.diffuse.contents = UIColor.blueColor
    box.materials = listOf(material)
    val boxNode = SCNNode.nodeWithGeometry(box)
    scene.rootNode.addChildNode(boxNode)

    // Rotation animation
    val rotation = SCNAction.rotateByX(0.0, y = 2 * PI, z = 0.0, duration = 4.0)
    boxNode.runAction(SCNAction.repeatActionForever(rotation))

    // Camera
    val cameraNode = SCNNode()
    cameraNode.camera = SCNCamera()
    cameraNode.setPosition(SCNVector3Make(0.0f, 0.0f, 5.0f))
    scene.rootNode.addChildNode(cameraNode)

    // Light
    val lightNode = SCNNode()
    lightNode.light = SCNLight()
    lightNode.light?.type = SCNLightTypeOmni
    lightNode.setPosition(SCNVector3Make(2.0f, 2.0f, 5.0f))
    scene.rootNode.addChildNode(lightNode)

    // SCNView
    val scnView = SCNView(frame = CGRectMake(0.0, 0.0, 0.0, 0.0))
    scnView.scene = scene
    scnView.allowsCameraControl = true
    scnView.autoenablesDefaultLighting = true
    scnView.backgroundColor = UIColor.whiteColor

    return scnView
}
