@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.twinskin.sdk.capture.crypto

import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.alloc
import kotlinx.cinterop.convert
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.readBytes
import kotlinx.cinterop.reinterpret
import kotlinx.cinterop.usePinned
import kotlinx.cinterop.value
import platform.CoreFoundation.CFDataCreate
import platform.CoreFoundation.CFDataGetBytePtr
import platform.CoreFoundation.CFDataGetLength
import platform.CoreFoundation.CFDataRef
import platform.CoreFoundation.CFDictionaryAddValue
import platform.CoreFoundation.CFDictionaryCreateMutable
import platform.CoreFoundation.CFErrorRefVar
import platform.CoreFoundation.CFRelease
import platform.CoreFoundation.kCFAllocatorDefault
import platform.CoreFoundation.kCFTypeDictionaryKeyCallBacks
import platform.CoreFoundation.kCFTypeDictionaryValueCallBacks
import platform.Security.SecKeyCreateEncryptedData
import platform.Security.SecKeyCreateWithData
import platform.Security.SecRandomCopyBytes
import platform.Security.kSecAttrKeyClass
import platform.Security.kSecAttrKeyClassPublic
import platform.Security.kSecAttrKeyType
import platform.Security.kSecAttrKeyTypeRSA
import platform.Security.kSecKeyAlgorithmRSAEncryptionOAEPSHA256
import platform.Security.kSecRandomDefault

actual fun secureRandomBytes(out: ByteArray) {
    if (out.isEmpty()) return
    out.usePinned { pinned ->
        val rc = SecRandomCopyBytes(kSecRandomDefault, out.size.convert(), pinned.addressOf(0))
        check(rc == 0) { "SecRandomCopyBytes failed: $rc" }
    }
}

// iOS public SDK no longer exposes CommonCrypto GCM (moved to Swift-only CryptoKit),
// so we use the pure-Kotlin AES-256-GCM implementation. Verified against NIST vectors
// in SoftwareAesGcmTest.
actual fun aes256GcmEncrypt(key: ByteArray, nonce: ByteArray, plaintext: ByteArray): ByteArray =
    SoftwareAesGcm.encrypt(key, nonce, plaintext)

actual fun rsaOaepSha256Encrypt(publicKeyDer: ByteArray, plaintext: ByteArray): ByteArray = memScoped {
    // SecKeyCreateWithData wants the bare PKCS#1 RSAPublicKey, not the SubjectPublicKeyInfo
    // (X.509) wrapper that JVM KeyFactory emits. Strip the wrapper so both platforms
    // accept the same input format.
    val pkcs1 = stripSpkiToPkcs1(publicKeyDer)

    val keyData = pkcs1.usePinned { pinned ->
        CFDataCreate(kCFAllocatorDefault, pinned.addressOf(0).reinterpret(), pkcs1.size.convert())
    } ?: error("CFDataCreate failed for public key")
    try {
        val attrs = CFDictionaryCreateMutable(
            kCFAllocatorDefault,
            2.convert(),
            kCFTypeDictionaryKeyCallBacks.ptr,
            kCFTypeDictionaryValueCallBacks.ptr,
        ) ?: error("CFDictionaryCreateMutable failed")
        CFDictionaryAddValue(attrs, kSecAttrKeyType, kSecAttrKeyTypeRSA)
        CFDictionaryAddValue(attrs, kSecAttrKeyClass, kSecAttrKeyClassPublic)
        try {
            val err = alloc<CFErrorRefVar>()
            val secKey = SecKeyCreateWithData(keyData, attrs, err.ptr)
                ?: error("SecKeyCreateWithData failed")
            try {
                val ptData: CFDataRef = plaintext.usePinned { pinned ->
                    CFDataCreate(
                        kCFAllocatorDefault,
                        pinned.addressOf(0).reinterpret(),
                        plaintext.size.convert(),
                    )
                } ?: error("CFDataCreate failed for plaintext")
                try {
                    val ct: CFDataRef = SecKeyCreateEncryptedData(
                        secKey,
                        kSecKeyAlgorithmRSAEncryptionOAEPSHA256,
                        ptData,
                        err.ptr,
                    ) ?: error("SecKeyCreateEncryptedData failed")
                    try {
                        val len = CFDataGetLength(ct).toInt()
                        val bytePtr = CFDataGetBytePtr(ct) ?: error("CFDataGetBytePtr null")
                        return@memScoped bytePtr.readBytes(len)
                    } finally { CFRelease(ct) }
                } finally { CFRelease(ptData) }
            } finally { CFRelease(secKey) }
        } finally { CFRelease(attrs) }
    } finally { CFRelease(keyData) }
}

/**
 * Strip the SubjectPublicKeyInfo (X.509) wrapper and return the PKCS#1 RSAPublicKey inside.
 *
 * SPKI:
 *   SEQUENCE {
 *     SEQUENCE { OID rsaEncryption, NULL }
 *     BIT STRING (00 || <PKCS1 RSAPublicKey>)
 *   }
 */
private fun stripSpkiToPkcs1(spki: ByteArray): ByteArray {
    val p = DerCursor(spki)
    p.expect(0x30); p.readLength()                         // outer SEQUENCE
    p.expect(0x30); val algLen = p.readLength()            // AlgorithmIdentifier
    p.skip(algLen)
    p.expect(0x03); val bitStrLen = p.readLength()         // BIT STRING
    val unusedBits = spki[p.offset].toInt() and 0xff
    require(unusedBits == 0) { "Unexpected unused bits in SPKI bit string: $unusedBits" }
    return spki.copyOfRange(p.offset + 1, p.offset + bitStrLen)
}

private class DerCursor(val data: ByteArray, var offset: Int = 0) {
    fun expect(tag: Int) {
        val b = data[offset].toInt() and 0xff
        require(b == tag) { "Expected DER tag 0x${tag.toString(16)}, got 0x${b.toString(16)}" }
        offset++
    }
    fun readLength(): Int {
        val first = data[offset].toInt() and 0xff
        offset++
        if (first and 0x80 == 0) return first
        val n = first and 0x7f
        var len = 0
        repeat(n) { len = (len shl 8) or (data[offset++].toInt() and 0xff) }
        return len
    }
    fun skip(n: Int) { offset += n }
}
