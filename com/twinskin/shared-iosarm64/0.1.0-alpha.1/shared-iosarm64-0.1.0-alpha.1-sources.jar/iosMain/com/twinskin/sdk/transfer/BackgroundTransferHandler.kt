@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.transfer

import kotlinx.cinterop.ExperimentalForeignApi
import platform.Foundation.NSLock

/**
 * Singleton bridge between iOS background URL session lifecycle events and the SDK.
 *
 * ## Setup (call once at app startup, before any transfers)
 * ```kotlin
 * val provider = NativeFileTransferProvider("${bundleId}.sdk.transfers")
 * BackgroundTransferHandler.configure(provider)
 * ```
 *
 * ## AppDelegate hook (Swift)
 * ```swift
 * func application(
 *     _ application: UIApplication,
 *     handleEventsForBackgroundURLSession identifier: String,
 *     completionHandler: @escaping () -> Void
 * ) {
 *     BackgroundTransferHandler.shared.handleBackgroundEvents(
 *         identifier: identifier,
 *         completionHandler: completionHandler
 *     )
 * }
 * ```
 *
 * iOS will terminate the app if the completion handler is not called promptly after all
 * background session delegate callbacks have been delivered. The handler is stored here and
 * called automatically by [NativeSessionDelegate.URLSessionDidFinishEventsForBackgroundURLSession].
 */
object BackgroundTransferHandler {

    private var provider: NativeFileTransferProvider? = null
    private val completionHandlers = mutableMapOf<String, () -> Unit>()
    private val lock = NSLock()

    /**
     * Callback invoked when iOS wakes the app via a BGProcessingTask to retry pending uploads.
     * Set this to call [TransferManager.recoverPendingUploads] so the manager re-runs the
     * resolver → PUT loop for any PENDING upload tasks.
     *
     * ## Swift wiring example (AppDelegate)
     * ```swift
     * BackgroundTransferHandler.shared.onUploadRetryRequested = {
     *     Task { await self.transferManager.recoverPendingUploads() }
     * }
     * ```
     */
    var onUploadRetryRequested: (() -> Unit)? = null

    /**
     * Wire the [provider] into this handler so that [handleBackgroundEvents] can reconnect
     * the session and so that the stored iOS completion handlers are called at the right time.
     *
     * Must be called before the app finishes launching.
     */
    fun configure(provider: NativeFileTransferProvider) {
        this.provider = provider
        provider.delegate.onBackgroundEventsFinished = { identifier ->
            // Fired by URLSessionDidFinishEventsForBackgroundURLSession — safe to call handler.
            val handler: (() -> Unit)?
            lock.lock()
            handler = completionHandlers.remove(identifier)
            lock.unlock()
            handler?.invoke()
        }
    }

    /**
     * Initialises the background [NSURLSession] immediately at app launch so that iOS can
     * begin replaying any pending delegate callbacks as soon as possible.
     *
     * Call this in `application(_:didFinishLaunchingWithOptions:)` **after** [configure]:
     * ```swift
     * BackgroundTransferHandler.shared.configure(provider: provider)
     * BackgroundTransferHandler.shared.reconnectOnLaunch()
     * ```
     *
     * This is a no-op if the session was already created. The [handleBackgroundEvents] path
     * still calls [NativeFileTransferProvider.reconnect] when iOS delivers background events
     * while the app was suspended, but calling this early ensures the session is always
     * attached before the first user interaction.
     */
    fun reconnectOnLaunch() {
        provider?.reconnect()
    }

    /**
     * Called from the AppDelegate to hand off a background session event.
     *
     * Stores the [completionHandler] and re-attaches the [NSURLSession] with the matching
     * identifier so its delegate receives all queued callbacks. The stored handler is invoked
     * automatically once [URLSessionDidFinishEventsForBackgroundURLSession] fires.
     *
     * @param identifier  The session identifier forwarded by iOS (must match the identifier
     *                    used when constructing [NativeFileTransferProvider]).
     * @param completionHandler  The system-provided completion handler that must be called
     *                           after all delegate callbacks have been processed.
     */
    fun handleBackgroundEvents(identifier: String, completionHandler: () -> Unit) {
        lock.lock()
        completionHandlers[identifier] = completionHandler
        lock.unlock()
        // Re-attaching the session triggers iOS to replay any pending delegate callbacks.
        provider?.reconnect()
    }

    /**
     * Called from the AppDelegate's BGProcessingTask handler when iOS wakes the app to
     * retry pending uploads. Invokes [onUploadRetryRequested] so the host can re-trigger
     * [TransferManager.recoverPendingUploads].
     *
     * The BGTask must be marked complete by the host after the retry is initiated:
     * ```swift
     * BGTaskScheduler.shared.register(
     *     forTaskWithIdentifier: IosBackgroundScheduler.taskIdentifier, using: nil
     * ) { task in
     *     BackgroundTransferHandler.shared.handleUploadRetryTask()
     *     task.setTaskCompleted(success: true)
     * }
     * ```
     */
    fun handleUploadRetryTask() {
        onUploadRetryRequested?.invoke()
    }
}
