@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.twinskin.sdk.capture.io

import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.autoreleasepool
import kotlinx.cinterop.convert
import kotlinx.cinterop.usePinned
import platform.Foundation.NSData
import platform.Foundation.NSFileHandle
import platform.Foundation.NSFileManager
import platform.Foundation.closeFile
import platform.Foundation.fileHandleForReadingAtPath
import platform.Foundation.readDataOfLength
import platform.posix.memcpy

internal actual fun fileSize(path: String): Long {
    val attrs = NSFileManager.defaultManager.attributesOfItemAtPath(path, error = null)
        ?: error("file not found: $path")
    val size = attrs["NSFileSize"] ?: error("no NSFileSize attribute on $path")
    return (size as platform.Foundation.NSNumber).longLongValue
}

internal actual fun readFileStreaming(path: String, sink: ByteSink) {
    val handle = NSFileHandle.fileHandleForReadingAtPath(path)
        ?: error("file not found: $path")
    try {
        val buf = ByteArray(8 * 1024)
        while (true) {
            // Per-iteration autoreleasepool drains the NSData returned by readDataOfLength;
            // without it, reading a multi-GiB video would accumulate thousands of NSData
            // instances until the outer pool drains.
            val n = autoreleasepool {
                val data: NSData = handle.readDataOfLength(buf.size.convert())
                val n = data.length.toInt()
                if (n > 0) {
                    buf.usePinned { pinned ->
                        memcpy(pinned.addressOf(0), data.bytes, n.convert())
                    }
                }
                n
            }
            if (n == 0) break
            sink.write(buf, 0, n)
        }
    } finally {
        handle.closeFile()
    }
}

internal actual fun deleteFileQuietly(path: String) {
    NSFileManager.defaultManager.removeItemAtPath(path, error = null)
}
