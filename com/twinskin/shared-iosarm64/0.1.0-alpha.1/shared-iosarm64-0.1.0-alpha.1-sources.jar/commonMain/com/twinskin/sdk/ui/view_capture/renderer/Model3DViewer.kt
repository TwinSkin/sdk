package com.twinskin.sdk.ui.view_capture.renderer

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.twinskin.sdk.view.Asset3D

/**
 * Platform-native surface rendering a 3D [asset].
 *
 * Phase 0: both Android and iOS actuals embed a WebView loading Google's
 * `<model-viewer>` web component. The WebView is an acknowledged stop-gap —
 * Phase 1 swaps in SceneView (Android) and SceneKit (iOS), Phase 2 adds
 * RealityKit for AR on iOS and SceneView AR on Android.
 *
 * Callers depend only on this signature; replacing the renderer does not
 * affect the [com.twinskin.sdk.view.ViewCaptureSession] or the Compose screen.
 */
@Composable
expect fun Model3DViewer(
    asset: Asset3D,
    ar: Boolean,
    modifier: Modifier,
)
