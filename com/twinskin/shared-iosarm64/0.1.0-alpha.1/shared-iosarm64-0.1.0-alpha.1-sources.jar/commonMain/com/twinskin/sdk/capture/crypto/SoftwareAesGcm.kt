package com.twinskin.sdk.capture.crypto

/**
 * Pure-Kotlin AES-256-GCM — encrypt only. Used by the iOS actual of [aes256GcmEncrypt]
 * because modern iOS SDKs no longer expose the CommonCrypto GCM entry points publicly
 * (GCM moved to CryptoKit, which is Swift-only).
 *
 * Verified against NIST SP 800-38D test vector J.6.6 in `SoftwareAesGcmTest`. Do not
 * modify without re-running the vectors.
 *
 * Note: the T-table AES implementation below is not constant-time and is theoretically
 * vulnerable to cache-timing side-channels. Acceptable here because each bundle uses a
 * freshly-generated ephemeral key that never leaves the device. TODO: migrate to
 * CryptoKit via cinterop when bandwidth allows for a fully constant-time primitive.
 */
internal object SoftwareAesGcm {

    /**
     * One-shot convenience wrapper. Returns `ciphertext || tag(16)`.
     * Kept because callers with small payloads (e.g. the envelope-key RSA step) prefer
     * the single-call form. For large payloads that would otherwise buffer the whole
     * plaintext in memory (video bundles), use [encryptStream] directly.
     */
    fun encrypt(key: ByteArray, nonce: ByteArray, plaintext: ByteArray): ByteArray {
        val enc = encryptStream(key, nonce)
        val ct = ByteArray(plaintext.size)
        if (plaintext.isNotEmpty()) enc.update(plaintext, 0, plaintext.size, ct, 0)
        val tag = enc.doFinal()
        return ct + tag
    }

    /**
     * Start a streaming AES-256-GCM encryption. Feed plaintext via [AesGcmEncryptor.update]
     * (caller owns the dst buffer — each call writes exactly `len` ciphertext bytes), then
     * call [AesGcmEncryptor.doFinal] once to obtain the 16-byte authentication tag.
     *
     * The encryptor buffers at most 15 bytes internally (the partial GHASH block tail);
     * it never holds the full plaintext or ciphertext.
     */
    fun encryptStream(key: ByteArray, nonce: ByteArray): AesGcmEncryptor {
        require(key.size == 32) { "AES-256 key must be 32 bytes" }
        require(nonce.size == 12) { "GCM nonce must be 12 bytes" }
        return AesGcmEncryptor(Aes256.expandKey(key), nonce)
    }

    internal fun inc32(block: ByteArray) {
        var c = 1
        for (i in 15 downTo 12) {
            val v = (block[i].toInt() and 0xff) + c
            block[i] = (v and 0xff).toByte()
            c = v ushr 8
            if (c == 0) break
        }
    }

    internal fun putLongBE(dst: ByteArray, off: Int, v: Long) {
        for (i in 0 until 8) dst[off + i] = ((v ushr (56 - i * 8)) and 0xff).toByte()
    }

    // Multiplies x (in place) by y in GF(2^128) using the standard polynomial
    // x^128 + x^7 + x^2 + x + 1 (reduction constant 0xE1 on the top byte).
    internal fun gf128Multiply(x: ByteArray, y: ByteArray) {
        val z = ByteArray(16)
        val v = y.copyOf()
        for (i in 0 until 128) {
            val xBit = ((x[i ushr 3].toInt() ushr (7 - (i and 7))) and 1) != 0
            if (xBit) for (k in 0 until 16) z[k] = (z[k].toInt() xor v[k].toInt()).toByte()
            val lsb = (v[15].toInt() and 1) != 0
            // Shift v right by 1 bit.
            for (k in 15 downTo 1) {
                val hi = (v[k - 1].toInt() and 1) shl 7
                v[k] = (((v[k].toInt() and 0xff) ushr 1) or hi).toByte()
            }
            v[0] = ((v[0].toInt() and 0xff) ushr 1).toByte()
            if (lsb) v[0] = (v[0].toInt() xor 0xe1).toByte()
        }
        z.copyInto(x)
    }
}

/**
 * Streaming AES-256-GCM encryptor. Create via [SoftwareAesGcm.encryptStream], feed
 * plaintext through [update] in any chunk size, then call [doFinal] once for the tag.
 *
 * Holds only a fixed-size working set (round keys + H + J0 + 16-byte GHASH tail). The
 * plaintext and ciphertext never live fully in memory — the caller supplies dst buffers
 * per chunk.
 */
internal class AesGcmEncryptor internal constructor(
    private val rk: IntArray,
    nonce: ByteArray,
) {
    // H = E_K(0^128), used as GHASH multiplier.
    private val h: ByteArray = ByteArray(16).also { Aes256.encryptBlock(rk, it, 0, it, 0) }

    // J0 = IV || 0x00000001 for 96-bit IVs. Retained to compute E_K(J0) in doFinal.
    private val j0: ByteArray = ByteArray(16).also {
        nonce.copyInto(it, 0)
        it[15] = 1
    }

    // CTR counter starts at inc32(J0).
    private val counter: ByteArray = j0.copyOf().also { SoftwareAesGcm.inc32(it) }

    // Current keystream block and position within it (16 = exhausted, needs refill).
    private val keystream: ByteArray = ByteArray(16)
    private var ksPos: Int = 16

    // GHASH running state and pending-block buffer (at most 15 bytes).
    private val s: ByteArray = ByteArray(16)
    private val ghashBuf: ByteArray = ByteArray(16)
    private var ghashBufLen: Int = 0

    private var totalCtBytes: Long = 0L
    private var finished: Boolean = false

    /**
     * Encrypt [len] bytes from [src] starting at [srcOff], writing ciphertext into [dst]
     * at [dstOff]. `src` and `dst` may alias (same array + same offsets) for in-place use.
     */
    fun update(src: ByteArray, srcOff: Int, len: Int, dst: ByteArray, dstOff: Int) {
        check(!finished) { "AesGcmEncryptor already finalized" }
        var remaining = len
        var sOff = srcOff
        var dOff = dstOff
        while (remaining > 0) {
            if (ksPos == 16) {
                Aes256.encryptBlock(rk, counter, 0, keystream, 0)
                SoftwareAesGcm.inc32(counter)
                ksPos = 0
            }
            val n = minOf(16 - ksPos, remaining)
            for (k in 0 until n) {
                val ct = (src[sOff + k].toInt() xor keystream[ksPos + k].toInt()).toByte()
                dst[dOff + k] = ct
                ghashBuf[ghashBufLen++] = ct
                if (ghashBufLen == 16) {
                    for (i in 0 until 16) s[i] = (s[i].toInt() xor ghashBuf[i].toInt()).toByte()
                    SoftwareAesGcm.gf128Multiply(s, h)
                    ghashBufLen = 0
                }
            }
            ksPos += n
            sOff += n
            dOff += n
            remaining -= n
            totalCtBytes += n
        }
    }

    /** Finalize and return the 16-byte authentication tag. May be called only once. */
    fun doFinal(): ByteArray {
        check(!finished) { "AesGcmEncryptor already finalized" }
        finished = true

        // Absorb the final partial block (zero-padded on the right).
        if (ghashBufLen > 0) {
            for (i in 0 until ghashBufLen) s[i] = (s[i].toInt() xor ghashBuf[i].toInt()).toByte()
            SoftwareAesGcm.gf128Multiply(s, h)
            ghashBufLen = 0
        }

        // Length block: u64be(|AAD|*8) || u64be(|C|*8). AAD is always empty here.
        val lenBlock = ByteArray(16)
        SoftwareAesGcm.putLongBE(lenBlock, 0, 0L)
        SoftwareAesGcm.putLongBE(lenBlock, 8, totalCtBytes * 8L)
        for (i in 0 until 16) s[i] = (s[i].toInt() xor lenBlock[i].toInt()).toByte()
        SoftwareAesGcm.gf128Multiply(s, h)

        val ej0 = ByteArray(16)
        Aes256.encryptBlock(rk, j0, 0, ej0, 0)
        val tag = ByteArray(16)
        for (k in 0 until 16) tag[k] = (ej0[k].toInt() xor s[k].toInt()).toByte()
        return tag
    }
}

/** Pure-Kotlin AES-256 block cipher (encrypt only). */
internal object Aes256 {
    private const val NB = 4
    private const val NR = 14           // rounds for AES-256
    private const val KEY_WORDS = 8     // 256-bit key = 8 × 32-bit words

    fun expandKey(key: ByteArray): IntArray {
        require(key.size == 32)
        val w = IntArray(NB * (NR + 1))
        for (i in 0 until KEY_WORDS) {
            w[i] = ((key[4*i].toInt() and 0xff) shl 24) or
                   ((key[4*i+1].toInt() and 0xff) shl 16) or
                   ((key[4*i+2].toInt() and 0xff) shl 8)  or
                    (key[4*i+3].toInt() and 0xff)
        }
        for (i in KEY_WORDS until w.size) {
            var t = w[i - 1]
            if (i % KEY_WORDS == 0) t = subWord(rotWord(t)) xor (RCON[i / KEY_WORDS] shl 24)
            else if (i % KEY_WORDS == 4) t = subWord(t)
            w[i] = w[i - KEY_WORDS] xor t
        }
        return w
    }

    fun encryptBlock(rk: IntArray, input: ByteArray, inOff: Int, output: ByteArray, outOff: Int) {
        var s0 = getInt(input, inOff)     xor rk[0]
        var s1 = getInt(input, inOff + 4) xor rk[1]
        var s2 = getInt(input, inOff + 8) xor rk[2]
        var s3 = getInt(input, inOff + 12) xor rk[3]

        for (round in 1 until NR) {
            val t0 = SBOX_T0[(s0 ushr 24) and 0xff] xor SBOX_T1[(s1 ushr 16) and 0xff] xor
                     SBOX_T2[(s2 ushr 8)  and 0xff] xor SBOX_T3[s3 and 0xff] xor rk[round*4]
            val t1 = SBOX_T0[(s1 ushr 24) and 0xff] xor SBOX_T1[(s2 ushr 16) and 0xff] xor
                     SBOX_T2[(s3 ushr 8)  and 0xff] xor SBOX_T3[s0 and 0xff] xor rk[round*4+1]
            val t2 = SBOX_T0[(s2 ushr 24) and 0xff] xor SBOX_T1[(s3 ushr 16) and 0xff] xor
                     SBOX_T2[(s0 ushr 8)  and 0xff] xor SBOX_T3[s1 and 0xff] xor rk[round*4+2]
            val t3 = SBOX_T0[(s3 ushr 24) and 0xff] xor SBOX_T1[(s0 ushr 16) and 0xff] xor
                     SBOX_T2[(s1 ushr 8)  and 0xff] xor SBOX_T3[s2 and 0xff] xor rk[round*4+3]
            s0 = t0; s1 = t1; s2 = t2; s3 = t3
        }
        // Final round (no MixColumns) uses the plain S-box.
        val r = NR * 4
        val y0 = ((SBOX[(s0 ushr 24) and 0xff] shl 24) or
                  (SBOX[(s1 ushr 16) and 0xff] shl 16) or
                  (SBOX[(s2 ushr 8)  and 0xff] shl 8)  or
                   SBOX[s3 and 0xff]) xor rk[r]
        val y1 = ((SBOX[(s1 ushr 24) and 0xff] shl 24) or
                  (SBOX[(s2 ushr 16) and 0xff] shl 16) or
                  (SBOX[(s3 ushr 8)  and 0xff] shl 8)  or
                   SBOX[s0 and 0xff]) xor rk[r+1]
        val y2 = ((SBOX[(s2 ushr 24) and 0xff] shl 24) or
                  (SBOX[(s3 ushr 16) and 0xff] shl 16) or
                  (SBOX[(s0 ushr 8)  and 0xff] shl 8)  or
                   SBOX[s1 and 0xff]) xor rk[r+2]
        val y3 = ((SBOX[(s3 ushr 24) and 0xff] shl 24) or
                  (SBOX[(s0 ushr 16) and 0xff] shl 16) or
                  (SBOX[(s1 ushr 8)  and 0xff] shl 8)  or
                   SBOX[s2 and 0xff]) xor rk[r+3]
        putInt(output, outOff, y0)
        putInt(output, outOff + 4, y1)
        putInt(output, outOff + 8, y2)
        putInt(output, outOff + 12, y3)
    }

    private fun getInt(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xff) shl 24) or
        ((b[o+1].toInt() and 0xff) shl 16) or
        ((b[o+2].toInt() and 0xff) shl 8)  or
         (b[o+3].toInt() and 0xff)

    private fun putInt(b: ByteArray, o: Int, v: Int) {
        b[o]   = (v ushr 24).toByte()
        b[o+1] = (v ushr 16).toByte()
        b[o+2] = (v ushr 8).toByte()
        b[o+3] = v.toByte()
    }

    private fun rotWord(w: Int): Int = (w shl 8) or (w ushr 24)
    private fun subWord(w: Int): Int =
        (SBOX[(w ushr 24) and 0xff] shl 24) or
        (SBOX[(w ushr 16) and 0xff] shl 16) or
        (SBOX[(w ushr 8)  and 0xff] shl 8)  or
         SBOX[w and 0xff]

    // AES S-box.
    private val SBOX: IntArray = intArrayOf(
        0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
        0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
        0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
        0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
        0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
        0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
        0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
        0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
        0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
        0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
        0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
        0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
        0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
        0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
        0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
        0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16,
    )

    // Round constants (only the first few are needed for AES-256).
    private val RCON = intArrayOf(0, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40)

    // T-tables derived from S-box and MixColumns (standard AES fast path).
    private val SBOX_T0 = IntArray(256)
    private val SBOX_T1 = IntArray(256)
    private val SBOX_T2 = IntArray(256)
    private val SBOX_T3 = IntArray(256)

    init {
        for (i in 0 until 256) {
            val s = SBOX[i]
            val s2 = xtime(s)
            val s3 = s2 xor s
            SBOX_T0[i] = (s2 shl 24) or (s shl 16) or (s shl 8) or s3
            SBOX_T1[i] = (s3 shl 24) or (s2 shl 16) or (s shl 8) or s
            SBOX_T2[i] = (s shl 24) or (s3 shl 16) or (s2 shl 8) or s
            SBOX_T3[i] = (s shl 24) or (s shl 16) or (s3 shl 8) or s2
        }
    }

    private fun xtime(b: Int): Int {
        val shifted = (b shl 1) and 0xff
        return if ((b and 0x80) != 0) shifted xor 0x1b else shifted
    }
}
