package com.twinskin.sdk.transfer

interface ZipEngine {
    suspend fun unzip(source: String, target: String): Result<Unit>
    suspend fun cleanup(path: String): Result<Unit>
}
