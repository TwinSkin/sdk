package com.twinskin.sdk.capture

import com.twinskin.sdk.capture.crypto.SoftwareAesGcm
import com.twinskin.sdk.capture.crypto.rsaOaepSha256Encrypt
import com.twinskin.sdk.capture.crypto.secureRandomBytes
import com.twinskin.sdk.capture.io.ByteSink
import com.twinskin.sdk.capture.io.RandomAccessByteSink

/**
 * Encrypts a capture bundle (zip-store archive) using the hybrid scheme documented in
 * `capture_bundle_encryption_guide.md`:
 *
 *   - fresh AES-256 key + 12-byte nonce encrypt the bundle with AES-GCM
 *   - the AES key is encrypted with RSA-OAEP-SHA-256 using the env public key
 *   - output layout: u16be(keyLen) ‖ encKey ‖ nonce(12) ‖ tag(16) ‖ ciphertext
 *
 * The server's private key decrypts with the matching scheme.
 */
open class BundleEncryptor(private val publicKeyDer: ByteArray) {

    /**
     * Open a sink that streams AES-GCM ciphertext to [outputPath] in the canonical
     * bundle layout. The header (encrypted key + nonce + 16-byte tag placeholder) is
     * written immediately; plaintext chunks fed into the returned [BundleEncryptingSink]
     * are encrypted block-at-a-time and appended as ciphertext; on [BundleEncryptingSink.close]
     * the real auth tag is patched into its reserved offset.
     *
     * At no point does the plaintext or the full ciphertext live in memory — only a
     * scratch buffer sized to the largest individual write.
     */
    open fun openEncryptingSink(outputPath: String): BundleEncryptingSink {
        val aesKey = ByteArray(32).also { secureRandomBytes(it) }
        val nonce = ByteArray(12).also { secureRandomBytes(it) }
        val encryptedKey = rsaOaepSha256Encrypt(publicKeyDer, aesKey)
        require(encryptedKey.size in 1..0xffff) { "encrypted key length out of range" }

        val sink = RandomAccessByteSink(outputPath)
        val headerSize = 2 + encryptedKey.size + 12 + 16
        val header = ByteArray(headerSize) // last 16 bytes stay zero as the tag placeholder
        var o = 0
        header[o++] = ((encryptedKey.size ushr 8) and 0xff).toByte()
        header[o++] = (encryptedKey.size and 0xff).toByte()
        encryptedKey.copyInto(header, o); o += encryptedKey.size
        nonce.copyInto(header, o)
        sink.write(header, 0, headerSize)

        val tagOffset = (2 + encryptedKey.size + 12).toLong()
        return BundleEncryptingSink(sink, SoftwareAesGcm.encryptStream(aesKey, nonce), tagOffset)
    }
}

/**
 * Streaming ciphertext sink returned by [BundleEncryptor.openEncryptingSink]. Caller
 * feeds plaintext via [write] in any chunk size, then calls [close] exactly once to
 * finalize the tag and flush the file.
 */
class BundleEncryptingSink internal constructor(
    private val sink: RandomAccessByteSink,
    private val encryptor: com.twinskin.sdk.capture.crypto.AesGcmEncryptor,
    private val tagOffset: Long,
) : ByteSink {

    private var scratch: ByteArray = ByteArray(8 * 1024)
    private var closed = false

    override fun write(src: ByteArray, off: Int, len: Int) {
        check(!closed) { "BundleEncryptingSink already closed" }
        if (len == 0) return
        if (scratch.size < len) scratch = ByteArray(len)
        encryptor.update(src, off, len, scratch, 0)
        sink.write(scratch, 0, len)
    }

    fun close() {
        if (closed) return
        closed = true
        try {
            val tag = encryptor.doFinal()
            sink.writeAt(tagOffset, tag, 0, 16)
        } finally {
            sink.close()
        }
    }
}
