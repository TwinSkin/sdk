package com.twinskin.sdk.capture.prototype

import androidx.compose.runtime.Composable
import kotlinx.coroutines.flow.StateFlow

/**
 * PROTOTYPE camera controller.
 *
 * This whole `prototype/` package is deliberately isolated so the final production camera
 * code can replace it wholesale. The rest of the SDK (notably [com.twinskin.sdk.capture.CaptureApi]
 * and the capture Compose flow) depends only on this interface — swapping implementations
 * is a file-level delete + new impl, no call-site changes required.
 */
interface CaptureController {
    val state: StateFlow<CaptureControllerState>

    /** Capture a still photo. Suspends until the JPEG bytes are available. */
    suspend fun takePhoto(): ByteArray

    /**
     * Start recording a video clip. Returns when the recording has actually started so
     * the UI can begin its 10-second countdown in sync with the underlying capture.
     */
    suspend fun startRecording()

    /**
     * Stop recording and return the filesystem path of the captured MP4. The caller
     * owns the file — it is the SDK's responsibility to delete it once the capture
     * bundle has been encrypted and persisted.
     */
    suspend fun stopRecording(): String

    /** Release all camera resources. Safe to call multiple times. */
    fun dispose()
}

sealed class CaptureControllerState {
    data object Initializing : CaptureControllerState()
    data object Ready : CaptureControllerState()
    data object CapturingPhoto : CaptureControllerState()
    data object Recording : CaptureControllerState()
    data class Error(val message: String) : CaptureControllerState()
}

/**
 * Platform-provided Compose entry point for the camera preview + controller.
 *
 * The preview surface fills the supplied modifier and is wired to the returned [CaptureController].
 * When the enclosing composition leaves, the controller is disposed automatically.
 */
@Composable
expect fun rememberPrototypeCaptureController(): CaptureController

/** Platform preview surface for [CaptureController]. */
@Composable
expect fun CameraPreview(
    controller: CaptureController,
    modifier: androidx.compose.ui.Modifier,
)
