package com.twinskin.sdk.ui.view_capture

/** Callbacks [ViewCaptureScreen] invokes. One object so subviews can take only what they need. */
data class ViewCaptureActions(
    val onClose: () -> Unit = {},
    val onRetry: () -> Unit = {},
    val onToggleAr: (() -> Unit)? = null,
)
