package com.twinskin.sdk

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform
