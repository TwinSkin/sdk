package com.twinskin.sdk.db

import app.cash.sqldelight.db.SqlDriver

expect class DatabaseDriverFactory(dbName: String) {
    fun create(): SqlDriver
}
