package com.twinskin.sdk.ui.view_capture.subview

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.view.LoadProgress

/** Pure function of [progress]. Previewable; snapshot one per LoadProgress variant. */
@Composable
fun ViewCaptureLoadingView(progress: LoadProgress) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        when (progress) {
            LoadProgress.Indeterminate -> {
                CircularProgressIndicator()
                Spacer(Modifier.height(16.dp))
                Text("Loading…", style = MaterialTheme.typography.bodyMedium)
            }
            is LoadProgress.Downloading -> {
                val total = progress.total
                if (total != null && total > 0) {
                    val fraction = (progress.bytesRead.toFloat() / total.toFloat())
                        .coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { fraction },
                        modifier = Modifier.width(240.dp),
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Downloading… ${(fraction * 100).toInt()}%",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.width(240.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Downloading… ${progress.bytesRead / 1024} KB",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            is LoadProgress.Unzipping -> {
                LinearProgressIndicator(
                    progress = { progress.fraction.coerceIn(0f, 1f) },
                    modifier = Modifier.width(240.dp),
                )
                Spacer(Modifier.height(12.dp))
                Text("Unzipping…", style = MaterialTheme.typography.bodyMedium)
            }
            LoadProgress.ResolvingMetadata -> {
                CircularProgressIndicator()
                Spacer(Modifier.height(16.dp))
                Text("Resolving capture…", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
