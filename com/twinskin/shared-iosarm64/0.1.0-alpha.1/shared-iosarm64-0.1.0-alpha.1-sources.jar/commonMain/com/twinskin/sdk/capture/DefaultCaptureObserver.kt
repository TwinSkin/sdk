package com.twinskin.sdk.capture

import com.twinskin.sdk.transfer.currentTimeMillis
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

/**
 * Default [CaptureObserver] implementation. Reads local state from
 * [SdkCaptureStore]; layers server state on top via [ServerCaptureSource]
 * when a caller opts into `observeSubject`.
 *
 * [serverAckGraceMs] bounds the `Uploaded → Analyzing` flicker
 * substitution — see [mergeEntries] for the full rationale. A local
 * `Uploaded` row whose `updatedAtEpochMs` is older than this window
 * reverts to the truthful `Uploaded` state, so a dropped server-side
 * event doesn't leave the UI pinned on `Analyzing` forever.
 */
internal class DefaultCaptureObserver(
    private val store: SdkCaptureStore,
    private val serverSource: ServerCaptureSource,
    private val clock: () -> Long = ::currentTimeMillis,
    private val serverAckGraceMs: Long = DEFAULT_SERVER_ACK_GRACE_MS,
) : CaptureObserver {

    override fun observePendingUploads(): Flow<List<PendingUpload>> =
        store.observeAll().map { rows -> rows.map { it.toPendingUpload() } }

    override fun observeSubject(subjectRef: String): Flow<List<CaptureEntry>> =
        combine(
            store.observeAll().map { rows ->
                rows.filter { it.request.subjectRef == subjectRef }
            },
            serverSource.observeSubject(subjectRef),
        ) { localRows, serverEntries ->
            mergeEntries(localRows, serverEntries, clock(), serverAckGraceMs)
        }

    companion object {
        /** 60s — covers a healthy S3 → SNS → webhook → DB insert round-trip with plenty of slack. */
        const val DEFAULT_SERVER_ACK_GRACE_MS: Long = 60_000L
    }
}

/**
 * Merge the per-subject local and server sides into a single
 * [CaptureEntry] list.
 *
 *  - Server row present for a capture id → emit the server entry. The
 *    server is authoritative once it knows about the capture.
 *  - Local-only row with state [CaptureState.Uploaded] and
 *    `updatedAtEpochMs` within `serverAckGraceMs` of [nowEpochMs] →
 *    substitute [CaptureState.Analyzing]. The upload succeeded but the
 *    server's first `sdk_captures` row hasn't arrived yet (1–2s window
 *    after S3 → SNS → webhook → DB insert); displaying "Uploaded" and
 *    then flipping to "Analyzing" looks like a bug.
 *  - Local-only row with state [CaptureState.Uploaded] past the grace
 *    window → emit the truthful `Uploaded`. "Uploaded" is honest: the
 *    upload genuinely succeeded; the server just hasn't ack'd (dropped
 *    SNS event, server outage, etc.). Better than lying with a
 *    permanent `Analyzing`.
 *  - Local-only row otherwise → emit the local state as-is.
 *
 * The result is sorted by `updatedAtEpochMs` descending so UIs can
 * render newest-first without further work.
 */
internal fun mergeEntries(
    localRows: List<SdkCaptureUploadRecord>,
    serverEntries: List<CaptureEntry>,
    nowEpochMs: Long,
    serverAckGraceMs: Long,
): List<CaptureEntry> {
    val byId = LinkedHashMap<String, CaptureEntry>(localRows.size + serverEntries.size)
    for (local in localRows) {
        val withinGrace = (nowEpochMs - local.updatedAtEpochMs) <= serverAckGraceMs
        byId[local.captureId] = local.toCaptureEntry(flickerSubstitute = withinGrace)
    }
    for (server in serverEntries) {
        byId[server.captureId] = server
    }
    return byId.values.sortedByDescending { it.updatedAtEpochMs }
}

/**
 * Map a persisted [SdkCaptureUploadStatus] to the coarse public [CaptureState].
 *
 * Progress is deliberately not reconstructed from the row — the store only
 * tracks discrete status transitions. Live byte-level progress for in-flight
 * uploads comes from the `CaptureSession.state` flow backed by the
 * `TransferManager` observer; subscribers to [CaptureObserver.observePendingUploads]
 * get `Uploading(progressPercent = null)` for any row sitting in the
 * `UPLOADING` status.
 */
private fun SdkCaptureUploadRecord.toPendingUpload(): PendingUpload =
    PendingUpload(
        captureId = captureId,
        subjectRef = request.subjectRef,
        state = toCaptureState(),
        updatedAtEpochMs = updatedAtEpochMs,
    )

/**
 * Merge-path mapping. Differs from [toPendingUpload] only in that
 * [flickerSubstitute] upgrades a local `Uploaded` to `Analyzing` —
 * never the other way around.
 */
internal fun SdkCaptureUploadRecord.toCaptureEntry(
    flickerSubstitute: Boolean,
): CaptureEntry {
    val raw = toCaptureState()
    val effective = if (flickerSubstitute && raw is CaptureState.Uploaded) {
        CaptureState.Analyzing
    } else {
        raw
    }
    return CaptureEntry(
        captureId = captureId,
        subjectRef = request.subjectRef,
        state = effective,
        updatedAtEpochMs = updatedAtEpochMs,
    )
}

private fun SdkCaptureUploadRecord.toCaptureState(): CaptureState = when (status) {
    SdkCaptureUploadStatus.PENDING_UPLOAD,
    SdkCaptureUploadStatus.UPLOADING -> CaptureState.Uploading(progressPercent = null)
    SdkCaptureUploadStatus.COMPLETED -> CaptureState.Uploaded
    SdkCaptureUploadStatus.FAILED -> CaptureState.Failed(
        stage = FailureStage.Upload,
        message = null,
    )
    SdkCaptureUploadStatus.CANCELLED -> CaptureState.Cancelled
}
