package com.twinskin.sdk.ui.view_capture.subview

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Renders capture metadata as a generic key/value list.
 *
 * Phase 0: [metadata] is a plain [Map]. When PowerSync lands and we know the
 * typed shape of measurements / notes / subject, this panel will grow
 * purpose-built subviews ([SubjectHeader], [MeasurementsList], [NotesList]);
 * until then, the generic list keeps the contract honest.
 */
@Composable
fun MetadataPanel(
    metadata: Map<String, String>,
    modifier: Modifier = Modifier,
) {
    if (metadata.isEmpty()) return
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Capture details", style = MaterialTheme.typography.titleSmall)
            HorizontalDivider()
            metadata.entries.forEach { (key, value) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        key,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(value, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
