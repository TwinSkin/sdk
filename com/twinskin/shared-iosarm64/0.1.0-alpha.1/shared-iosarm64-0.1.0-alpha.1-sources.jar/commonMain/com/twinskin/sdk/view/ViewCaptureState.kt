package com.twinskin.sdk.view

/** Top-level UI state. Pure data; produced by [ViewCaptureSession]. */
sealed class ViewCaptureState {
    data class Loading(val progress: LoadProgress) : ViewCaptureState()
    data class Error(val error: ViewCaptureError) : ViewCaptureState()
    data class Ready(
        val asset: Asset3D,
        val metadata: Map<String, String> = emptyMap(),
        /** True while a reactive resolver (e.g. PowerSync) is still emitting updates. */
        val isStreaming: Boolean = false,
    ) : ViewCaptureState()
}

sealed class LoadProgress {
    object Indeterminate : LoadProgress()
    data class Downloading(val bytesRead: Long, val total: Long?) : LoadProgress()
    data class Unzipping(val fraction: Float) : LoadProgress()
    object ResolvingMetadata : LoadProgress()
}

sealed class ViewCaptureError {
    object Network : ViewCaptureError()
    object NotFound : ViewCaptureError()
    data class InvalidAsset(val reason: String) : ViewCaptureError()
    data class Unknown(val cause: Throwable) : ViewCaptureError()
}
