package com.twinskin.sdk.view

import kotlinx.coroutines.flow.Flow

/**
 * Turns a [CaptureSource] into a stream of [ResolverEvent]s.
 *
 * - One-shot resolvers (local/url/zip) emit a few [ResolverEvent.Progress]
 *   events and then a terminal [ResolverEvent.Resolved], and complete.
 * - Reactive resolvers (PowerSync, later) stay open and keep emitting
 *   [ResolverEvent.Resolved] whenever underlying data changes.
 */
interface CaptureResolver {
    fun resolve(): Flow<ResolverEvent>
}

sealed class ResolverEvent {
    data class Progress(val progress: LoadProgress) : ResolverEvent()
    data class Resolved(val capture: ResolvedCapture) : ResolverEvent()
}
