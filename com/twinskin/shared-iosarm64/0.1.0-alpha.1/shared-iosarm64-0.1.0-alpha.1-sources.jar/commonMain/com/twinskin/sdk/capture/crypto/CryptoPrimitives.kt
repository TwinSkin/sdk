package com.twinskin.sdk.capture.crypto

/** Platform-provided cryptographic primitives used by the capture bundle pipeline. */

/** Fills [out] with cryptographically secure random bytes. */
expect fun secureRandomBytes(out: ByteArray)

/**
 * AES-256-GCM encrypt. [key] must be 32 bytes, [nonce] 12 bytes. Returns ciphertext followed
 * by the 16-byte authentication tag (standard JCE/CryptoKit layout).
 */
expect fun aes256GcmEncrypt(key: ByteArray, nonce: ByteArray, plaintext: ByteArray): ByteArray

/**
 * RSA-OAEP with SHA-256 (MGF1-SHA-256) encrypt.
 *
 * [publicKeyDer] is the SubjectPublicKeyInfo DER encoding (X.509 — what a PEM block
 * labelled `PUBLIC KEY` decodes to).
 */
expect fun rsaOaepSha256Encrypt(publicKeyDer: ByteArray, plaintext: ByteArray): ByteArray
