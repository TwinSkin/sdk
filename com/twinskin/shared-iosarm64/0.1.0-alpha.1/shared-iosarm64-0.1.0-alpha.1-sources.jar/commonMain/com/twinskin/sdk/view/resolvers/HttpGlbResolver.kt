@file:OptIn(kotlin.uuid.ExperimentalUuidApi::class)

package com.twinskin.sdk.view.resolvers

import com.twinskin.sdk.view.Asset3D
import com.twinskin.sdk.view.Asset3DFormat
import com.twinskin.sdk.view.CaptureResolver
import com.twinskin.sdk.view.LoadProgress
import com.twinskin.sdk.view.ResolvedCapture
import com.twinskin.sdk.view.ResolverEvent
import com.twinskin.sdk.view.downloadToPath
import kotlin.uuid.Uuid
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow

/**
 * Downloads a GLB from [url] into [cacheDir] and emits the local path when done.
 *
 * Progress is reported via [ResolverEvent.Progress]; the terminal event carries the
 * resolved [Asset3D].
 *
 * ## Cache semantics
 *
 * Each resolver instance picks a random UUID-based file name in [cacheDir] so
 * concurrent resolvers (and resolvers whose source URLs would otherwise
 * collapse to the same name, e.g. two presigned URLs that both end in no
 * `.glb` suffix) never race on the same file. This means [cacheDir] behaves
 * as a per-session workspace, not a cross-session cache — downloads aren't
 * deduped across viewCapture calls. Good enough for current usage; if we
 * later want true caching, switch the name to a content hash of the URL
 * and add a hit check before downloading.
 */
class HttpGlbResolver(
    private val url: String,
    private val cacheDir: String,
    private val fileName: String = "${Uuid.random()}.glb",
) : CaptureResolver {

    override fun resolve(): Flow<ResolverEvent> = channelFlow {
        val destPath = "$cacheDir/$fileName"
        send(ResolverEvent.Progress(LoadProgress.Downloading(bytesRead = 0, total = null)))
        downloadToPath(url, destPath) { bytesRead, total ->
            trySend(ResolverEvent.Progress(LoadProgress.Downloading(bytesRead, total)))
        }
        send(
            ResolverEvent.Resolved(
                ResolvedCapture(
                    model = Asset3D(location = destPath, format = Asset3DFormat.GLB),
                ),
            ),
        )
    }
}
