package com.twinskin.sdk.sdk_client

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement

/**
 * Thin Ktor-backed client for the SDK server's session-token API.
 * Hand-written (rather than generated from `openapi_public.json`)
 * because the SDK's auth flow — dynamic session bearer + static
 * publishable-key header, plus 401-driven refresh — is awkward to
 * express through the Kotlin OpenAPI generator.
 *
 * [baseUrl] and [publishableKey] are the static bits; [auth] supplies
 * the dynamic session bearer token on every call so a 401-driven retry
 * picks up a refreshed token transparently.
 *
 * **When you add a new method here**, also add a case to the Dart
 * cross-SDK integration test at
 * `packages/server/integration_test/api/sdk/sdk_client_jvm_test.dart`
 * (+ the matching subcommand in `SdkClientCli.kt`). That test
 * exercises this client against the real running server and is how we
 * catch wire-format drift.
 */
class SdkServerClient(
    private val baseUrl: String,
    private val publishableKey: String,
    private val auth: SdkAuthorizationProvider,
    httpClient: HttpClient? = null,
) {
    private val ownsClient = httpClient == null
    private val client = httpClient ?: HttpClient {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    suspend fun startCapture(request: SdkStartCaptureRequest): SdkStartCaptureResponse {
        // The session-token payload is subject-scoped, so the provider
        // is asked per-request. Callers (e.g. the capture pipeline)
        // already have a subject for every upload; pulling it off the
        // request is the least invasive wiring.
        val tokens = parseSessionTokenPayload(
            auth.fetchSessionToken(request.subjectRef),
        )
        val response = client.post("${baseUrl.trimEnd('/')}/upload/start-capture") {
            header(HttpHeaders.Authorization, "Bearer ${tokens.token}")
            header("X-Publishable-Key", publishableKey)
            contentType(ContentType.Application.Json)
            setBody(request)
        }
        if (!response.status.isSuccess()) {
            throw SdkServerException(response.status.value, response.bodyAsText())
        }
        return response.body()
    }

    fun close() {
        if (ownsClient) client.close()
    }
}

class SdkServerException(val statusCode: Int, val responseBody: String) :
    RuntimeException("SDK server returned $statusCode: $responseBody")

@Serializable
data class SdkStartCaptureRequest(
    @SerialName("user_ref") val userRef: String,
    @SerialName("subject_ref") val subjectRef: String,
    @SerialName("capture_id") val captureId: String? = null,
    @SerialName("condition_type") val conditionType: String? = null,
    @SerialName("capture_group") val captureGroup: String? = null,
    @SerialName("body_location") val bodyLocation: List<String>? = null,
    val custom: Map<String, JsonElement>? = null,
)

@Serializable
data class SdkStartCaptureResponse(
    @SerialName("capture_id") val captureId: String,
    val status: SdkCaptureStatus,
    /**
     * Present iff [status] is [SdkCaptureStatus.QUEUED]. Past queued the
     * server has already accepted a bundle for this id and the SDK must
     * stop uploading — see `StartCaptureResponse` docs on the server.
     */
    @SerialName("upload_url") val uploadUrl: String? = null,
)

@Serializable
enum class SdkCaptureStatus {
    @SerialName("queued") QUEUED,
    @SerialName("in_progress") IN_PROGRESS,
    @SerialName("completed") COMPLETED,
    @SerialName("failed") FAILED,
}
