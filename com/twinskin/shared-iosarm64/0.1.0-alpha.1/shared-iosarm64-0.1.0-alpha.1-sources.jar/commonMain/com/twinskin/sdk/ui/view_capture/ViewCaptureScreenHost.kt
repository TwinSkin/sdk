package com.twinskin.sdk.ui.view_capture

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.view.CaptureSource
import com.twinskin.sdk.view.ViewCaptureOptions
import com.twinskin.sdk.view.ViewCaptureSession

/**
 * Stateful wrapper: spins up a [ViewCaptureSession] for [source], collects its
 * state, and feeds the stateless [ViewCaptureScreen]. Tearing down the
 * composable closes the session.
 *
 * Demo apps call this directly via a platform entry point
 * ([com.twinskin.sdk.ViewCaptureViewController] on iOS, the public
 * [TwinSkinSdk.viewCapture] wiring on Android).
 */
@Composable
fun ViewCaptureScreenHost(
    source: CaptureSource,
    options: ViewCaptureOptions = ViewCaptureOptions(),
    onClose: () -> Unit = {},
) {
    var retryKey by remember { mutableIntStateOf(0) }
    var ar by remember { mutableStateOf(options.ar) }

    val session = remember(source, retryKey) {
        TwinSkinSdk.viewCapture(source)
    }
    DisposableEffect(session) {
        onDispose { session.close() }
    }

    val state by session.state.collectAsState()

    ViewCaptureScreen(
        state = state,
        actions = ViewCaptureActions(
            onClose = onClose,
            onRetry = { retryKey++ },
            onToggleAr = { ar = !ar },
        ),
        ar = ar,
    )
}
