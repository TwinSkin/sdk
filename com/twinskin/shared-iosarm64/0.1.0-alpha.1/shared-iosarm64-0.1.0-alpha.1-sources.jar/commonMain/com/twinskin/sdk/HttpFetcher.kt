package com.twinskin.sdk

import io.ktor.client.*
import io.ktor.client.request.*
import io.ktor.client.statement.*

class HttpFetcher {
    private val client = HttpClient()

    suspend fun fetch(url: String): String = client.get(url).bodyAsText()
}
