package com.twinskin.sdk.capture

import com.powersync.connectors.PowerSyncBackendConnector
import com.powersync.connectors.PowerSyncCredentials
import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.sdk_client.MintSessionTokenResponse
import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider
import com.twinskin.sdk.sdk_client.parseSessionTokenPayload
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.retryWhen
import kotlinx.coroutines.flow.shareIn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.min
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

/**
 * Server-state side of the subject-scoped capture observer.
 *
 * Opens (and shares) a PowerSync connection per `subjectRef`. First
 * collection of `observeSubject(X)` lazily creates the client; a
 * second collector on the same subject hooks into the same shared
 * flow; five seconds after the last collector cancels, the client is
 * closed. Different subjects get different clients (the PS JWT's
 * `sub` claim encodes the subject — one client, one subject).
 *
 * Connection errors mid-stream (dropped network, expired-then-rejected
 * token, transient PowerSync failure) trigger a reconnect with
 * capped-exponential backoff — the shared flow stays live and
 * collectors keep their subscription. Each retry is logged through the
 * SDK's [SdkLogger] so integrators who opt into logging can see it.
 *
 * See [CaptureObserver.observeSubject] for the public contract.
 */
internal class ServerCaptureSource(
    private val scope: CoroutineScope,
    private val authProvider: SdkAuthorizationProvider,
    private val powerSyncFactory: PowerSyncClientFactory,
    private val logger: SdkLogger? = null,
    private val idleTimeout: Duration = 5.seconds,
    private val retryInitialDelay: Duration = 1.seconds,
    private val retryMaxDelay: Duration = 30.seconds,
) {
    // Short-lived guard around [shared]. Individual first-subscribes for
    // different subjects do their work on per-subject [CompletableDeferred]s
    // outside this mutex, so a slow auth-provider call on subject A never
    // blocks a first-subscribe on subject B.
    private val mapMutex = Mutex()
    private val shared: MutableMap<String, CompletableDeferred<Flow<List<CaptureEntry>>>> =
        mutableMapOf()

    fun observeSubject(subjectRef: String): Flow<List<CaptureEntry>> = flow {
        val upstream = getOrBuildShared(subjectRef)
        emitAll(upstream)
    }

    /**
     * Resolves (or installs) the subject's shared flow. Concurrent
     * first-subscribers on the same subject find the same
     * [CompletableDeferred] and await one auth fetch. Concurrent
     * first-subscribers on *different* subjects install different
     * Deferreds and run in parallel.
     */
    private suspend fun getOrBuildShared(subjectRef: String): Flow<List<CaptureEntry>> {
        val (deferred, isOwner) = mapMutex.withLock {
            val existing = shared[subjectRef]
            if (existing != null) {
                existing to false
            } else {
                val fresh = CompletableDeferred<Flow<List<CaptureEntry>>>()
                shared[subjectRef] = fresh
                fresh to true
            }
        }
        if (isOwner) {
            try {
                val initial = fetchCredentialsOrThrow(subjectRef)
                val built = buildSharedFlow(subjectRef, initial, deferred)
                deferred.complete(built)
            } catch (t: Throwable) {
                mapMutex.withLock {
                    if (shared[subjectRef] === deferred) shared.remove(subjectRef)
                }
                deferred.completeExceptionally(t)
                throw t
            }
        }
        return deferred.await()
    }

    private fun buildSharedFlow(
        subjectRef: String,
        initial: MintSessionTokenResponse,
        owner: CompletableDeferred<Flow<List<CaptureEntry>>>,
    ): Flow<List<CaptureEntry>> {
        // Seeded credentials are consumed by the very first open attempt
        // only — any retry fetches fresh, since the seeded token may
        // have expired while we were waiting to reconnect. A nullable
        // var is sufficient: retries are sequential inside retryWhen.
        var seed: MintSessionTokenResponse? = initial
        val cold = flow {
            val connector = SdkSessionConnector(subjectRef, authProvider, seed)
            seed = null
            val client = powerSyncFactory.open(subjectRef, connector)
            try {
                emitAll(client.watchCaptures(subjectRef))
            } finally {
                runCatching { client.close() }
            }
        }.retryWhen { cause, attempt ->
            if (cause is CancellationException) {
                false
            } else {
                logger?.log(
                    "PowerSync feed for '$subjectRef' errored (attempt ${attempt + 1}); " +
                        "reconnecting after backoff.",
                    cause,
                )
                delay(backoffDelay(attempt.toInt()).inWholeMilliseconds)
                true
            }
        }.onCompletion {
            // Drop the cached handle so the next subscriber builds a fresh
            // SharedFlow rather than reusing one that has already terminated.
            // Identity-check first: WhileSubscribed can restart the upstream
            // on the same SharedFlow if a collector arrives during the stop
            // timeout, in which case the map already points at a live entry
            // (possibly even a different Deferred from a later rebuild) that
            // we must not evict.
            mapMutex.withLock {
                if (shared[subjectRef] === owner) shared.remove(subjectRef)
            }
        }
        return cold.shareIn(
            scope = scope,
            started = SharingStarted.WhileSubscribed(
                stopTimeoutMillis = idleTimeout.inWholeMilliseconds,
                replayExpirationMillis = 0,
            ),
            replay = 1,
        )
    }

    private fun backoffDelay(attempt: Int): Duration {
        // 1s, 2s, 4s, 8s, 16s, 30s (cap). Capped-exponential — aggressive
        // enough that a transient network blip reconnects in seconds, slow
        // enough that a hard outage doesn't hammer the server.
        val doubledMs = retryInitialDelay.inWholeMilliseconds shl min(attempt, 20)
        val cappedMs = min(doubledMs, retryMaxDelay.inWholeMilliseconds)
        return cappedMs.milliseconds
    }

    private suspend fun fetchCredentialsOrThrow(subjectRef: String): MintSessionTokenResponse {
        val payload = authProvider.fetchSessionToken(subjectRef)
        val parsed = parseSessionTokenPayload(payload)
        if (parsed.powerSyncUrl == null) {
            throw IllegalStateException(
                "powersync_url missing from session-token response — the " +
                    "server env is not set up to serve SDK PowerSync traffic, " +
                    "so observeSubject cannot open a connection.",
            )
        }
        return parsed
    }
}

/**
 * PowerSync connection handle opened by [ServerCaptureSource]. Platform
 * impls wrap a real [com.powersync.PowerSyncDatabase]; tests use a
 * fake. Only the two methods [ServerCaptureSource] needs are exposed.
 */
internal interface PowerSyncClient {
    /**
     * Subject-scoped watch over `sdk_captures`. The returned flow
     * re-emits whenever PowerSync syncs a change (row inserted,
     * updated, or removed from the subscription).
     */
    fun watchCaptures(subjectRef: String): Flow<List<CaptureEntry>>

    suspend fun close()
}

/**
 * Factory that opens a [PowerSyncClient] bound to a particular
 * subject. Split out so unit tests can inject a fake without standing
 * up a real PowerSync instance.
 */
internal fun interface PowerSyncClientFactory {
    suspend fun open(subjectRef: String, connector: PowerSyncBackendConnector): PowerSyncClient
}

/**
 * [PowerSyncBackendConnector] impl that delegates credential fetches
 * to the integrator's [SdkAuthorizationProvider]. The initial payload
 * (already fetched by [ServerCaptureSource] to validate PS fields)
 * seeds the first [fetchCredentials] call so we don't hit the
 * integrator backend twice on connect. PowerSync then caches the
 * returned credentials internally and only re-asks near token expiry.
 *
 * `uploadData` is a no-op — the SDK only reads the sync stream.
 */
private class SdkSessionConnector(
    private val subjectRef: String,
    private val authProvider: SdkAuthorizationProvider,
    initial: MintSessionTokenResponse?,
) : PowerSyncBackendConnector() {
    private var seeded: MintSessionTokenResponse? = initial

    override suspend fun fetchCredentials(): PowerSyncCredentials {
        val response = seeded?.also { seeded = null } ?: fetchFresh()
        return PowerSyncCredentials(
            endpoint = response.powerSyncUrl!!,
            token = response.token,
            userId = null,
        )
    }

    private suspend fun fetchFresh(): MintSessionTokenResponse {
        val payload = authProvider.fetchSessionToken(subjectRef)
        val parsed = parseSessionTokenPayload(payload)
        if (parsed.powerSyncUrl == null) {
            throw IllegalStateException(
                "powersync_url disappeared from a subsequent " +
                    "session-token response for subject '$subjectRef'. " +
                    "The server deployment must always return " +
                    "powersync_url once the first response did.",
            )
        }
        return parsed
    }

    override suspend fun uploadData(database: com.powersync.PowerSyncDatabase) {
        // No-op — the SDK is a read-only consumer of `sdk_captures`.
    }
}

/**
 * One row of the server-state watch. Field names mirror the sync-rule
 * columns in `packages/server/powersync/sync_rules.yaml`. Only the
 * fields the SDK currently translates into [CaptureState] are parsed;
 * adding more is cheap when a future feature needs them.
 */
internal data class ServerCaptureRow(
    val id: String,
    val subjectRef: String,
    val status: String,
    val errorReason: String?,
    val lastAdvancedAtEpochMs: Long,
) {
    fun toCaptureEntry(logger: SdkLogger? = null): CaptureEntry = CaptureEntry(
        captureId = id,
        subjectRef = subjectRef,
        state = statusToState(status, errorReason, logger),
        updatedAtEpochMs = lastAdvancedAtEpochMs,
    )
}

/**
 * Map a row of `sdk_captures.status` (Postgres enum
 * `sdk_capture_status`: queued | in_progress | completed | failed) to
 * the SDK's coarse public [CaptureState]. The DB enum has no
 * `cancelled` — cancellation is a local-only concept surfaced by the
 * on-device observer.
 *
 * An unknown status string is treated as [CaptureState.Analyzing]
 * (optimistic — the SDK is almost certainly behind the server, which
 * has added a new intermediate status). The event is logged so a
 * watchful integrator sees the drift before it bites. Defaulting to
 * `Failed` here would falsely alarm users every time the server ships
 * a new transient state — never worth the blast radius.
 */
internal fun statusToState(
    status: String,
    errorReason: String?,
    logger: SdkLogger? = null,
): CaptureState =
    when (status) {
        "queued", "in_progress" -> CaptureState.Analyzing
        "completed" -> CaptureState.Succeeded
        "failed" -> CaptureState.Failed(
            stage = FailureStage.Server,
            message = errorReason,
        )
        else -> {
            logger?.log(
                "Unknown sdk_captures.status '$status' — treating as Analyzing. " +
                    "SDK may be behind server.",
            )
            CaptureState.Analyzing
        }
    }

/**
 * Watch query used by concrete [PowerSyncClient] impls that wrap a
 * real `PowerSyncDatabase`. Exposed so platform-specific wiring
 * doesn't duplicate the SQL string and can share a mapper that turns
 * cursor rows into [ServerCaptureRow] → [CaptureEntry].
 */
internal fun watchSdkCapturesSql(): String =
    "SELECT id, subject_ref, status, error_reason, last_advanced_at " +
        "FROM ${SdkCapturePowerSyncSchema.TABLE_NAME} " +
        "ORDER BY last_advanced_at DESC"
