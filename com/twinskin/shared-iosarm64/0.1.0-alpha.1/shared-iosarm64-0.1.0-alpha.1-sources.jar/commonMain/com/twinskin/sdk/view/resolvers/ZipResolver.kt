package com.twinskin.sdk.view.resolvers

import com.twinskin.sdk.transfer.ZipEngine
import com.twinskin.sdk.view.Asset3D
import com.twinskin.sdk.view.Asset3DFormat
import com.twinskin.sdk.view.CaptureResolver
import com.twinskin.sdk.view.LoadProgress
import com.twinskin.sdk.view.ResolvedCapture
import com.twinskin.sdk.view.ResolverEvent
import com.twinskin.sdk.view.downloadToPath
import com.twinskin.sdk.view.listGlbFiles
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow

/**
 * Downloads a zip from [url] into [cacheDir], asks [zipEngine] to extract it
 * alongside, and resolves to the first .glb found in the extracted tree.
 */
class ZipResolver(
    private val url: String,
    private val cacheDir: String,
    private val zipEngine: ZipEngine,
    private val bundleId: String = url.hashCode().toString(),
) : CaptureResolver {

    override fun resolve(): Flow<ResolverEvent> = channelFlow {
        val zipPath = "$cacheDir/bundle-$bundleId.zip"
        val extractDir = "$cacheDir/bundle-$bundleId"

        zipEngine.cleanup(extractDir).getOrThrow()

        send(ResolverEvent.Progress(LoadProgress.Downloading(bytesRead = 0, total = null)))
        downloadToPath(url, zipPath) { bytesRead, total ->
            trySend(ResolverEvent.Progress(LoadProgress.Downloading(bytesRead, total)))
        }

        send(ResolverEvent.Progress(LoadProgress.Unzipping(fraction = 0f)))
        zipEngine.unzip(zipPath, extractDir).getOrThrow()

        val glbPath = listGlbFiles(extractDir).firstOrNull()
            ?: error("No .glb found in archive (extracted to $extractDir).")

        send(
            ResolverEvent.Resolved(
                ResolvedCapture(
                    model = Asset3D(location = glbPath, format = Asset3DFormat.GLB),
                ),
            ),
        )
    }
}
