@file:OptIn(ExperimentalMaterial3Api::class)

package com.twinskin.sdk.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.CaptureState
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.capture.prototype.CameraPreview
import com.twinskin.sdk.capture.prototype.CaptureControllerState
import com.twinskin.sdk.capture.prototype.rememberCapturePermissionsState
import com.twinskin.sdk.capture.prototype.rememberPrototypeCaptureController
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val VIDEO_DURATION_MS = 3_000L

private sealed class FlowStep {
    data object AwaitingShutter : FlowStep()
    data object TakingPhoto : FlowStep()
    data object Recording : FlowStep()
    data object Submitting : FlowStep()
    data class Submitted(val session: CaptureSession) : FlowStep()
}

/**
 * PROTOTYPE capture screen. Drives the full flow:
 * permissions → preview → photo → 10s video → [TwinSkinSdk.startCapture] → observe upload.
 *
 * The camera bits live in [com.twinskin.sdk.capture.prototype] and will be swapped out
 * wholesale; this screen only depends on the stable public [TwinSkinSdk] surface + that
 * prototype package.
 */
@Composable
fun CaptureScreen(
    metadata: SdkCaptureMetadata? = null,
    onDone: () -> Unit = {},
    onCancel: () -> Unit = {},
    startSession: (SdkCaptureMetadata) -> CaptureSession = { TwinSkinSdk.startCapture(it) },
) {
    if (metadata == null) {
        NotWiredPlaceholder()
        return
    }
    val permissions = rememberCapturePermissionsState()

    LaunchedEffect(Unit) { if (!permissions.granted) permissions.request() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Capture") },
                navigationIcon = {
                    TextButton(onClick = onCancel) { Text("Cancel") }
                },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                permissions.denied -> PermissionDeniedView(
                    onRetry = permissions::request,
                    onCancel = onCancel,
                )
                !permissions.granted -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                else -> CaptureFlow(metadata, onDone, onCancel, startSession)
            }
        }
    }
}

@Composable
private fun NotWiredPlaceholder() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            "CaptureScreen needs SdkCaptureMetadata — host app has not wired one up yet.",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(24.dp),
        )
    }
}

@Composable
private fun PermissionDeniedView(onRetry: () -> Unit, onCancel: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            "Camera and microphone access are required to capture a wound.",
            style = MaterialTheme.typography.bodyLarge,
        )
        Spacer(Modifier.height(16.dp))
        Row {
            OutlinedButton(onClick = onCancel) { Text("Cancel") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = onRetry) { Text("Grant access") }
        }
    }
}

@Composable
private fun CaptureFlow(
    metadata: SdkCaptureMetadata,
    onDone: () -> Unit,
    onCancel: () -> Unit,
    startSession: (SdkCaptureMetadata) -> CaptureSession,
) {
    val controller = rememberPrototypeCaptureController()
    val controllerState by controller.state.collectAsState()
    val scope = rememberCoroutineScope()

    var step by remember { mutableStateOf<FlowStep>(FlowStep.AwaitingShutter) }
    var remainingMs by remember { mutableStateOf(VIDEO_DURATION_MS) }
    var photoBytes by remember { mutableStateOf<ByteArray?>(null) }
    var errorText by remember { mutableStateOf<String?>(null) }

    // 10s video timer + auto-stop. Keyed on the Recording step only (not remainingMs) so
    // the countdown doesn't restart itself each tick. The post-countdown submit work
    // runs in `scope` rather than inside this LaunchedEffect: if we mutated `step`
    // here, the key change would cancel our own coroutine mid-stopRecording with a
    // LeftCompositionCancellationException and surface it as an error banner.
    LaunchedEffect(step) {
        if (step !== FlowStep.Recording) return@LaunchedEffect
        remainingMs = VIDEO_DURATION_MS
        while (remainingMs > 0 && step === FlowStep.Recording) {
            delay(100)
            remainingMs = (remainingMs - 100).coerceAtLeast(0)
        }
        if (step !== FlowStep.Recording) return@LaunchedEffect
        val photo = photoBytes ?: run {
            errorText = "internal: missing photo"
            step = FlowStep.AwaitingShutter
            return@LaunchedEffect
        }
        scope.launch {
            step = FlowStep.Submitting
            try {
                val videoPath = controller.stopRecording()
                val session = startSession(metadata)
                session.submit(photo, videoPath)
                step = FlowStep.Submitted(session)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                errorText = e.message ?: "capture failed"
                step = FlowStep.AwaitingShutter
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        CameraPreview(controller = controller, modifier = Modifier.fillMaxSize())

        // Top-right countdown chip while recording.
        if (step === FlowStep.Recording) {
            Surface(
                modifier = Modifier.align(Alignment.TopEnd).padding(16.dp),
                color = Color.Red.copy(alpha = 0.85f),
                shape = MaterialTheme.shapes.small,
            ) {
                Text(
                    "REC ${(remainingMs / 1000).toInt() + 1}s",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                )
            }
        }

        when (val s = step) {
            is FlowStep.AwaitingShutter, FlowStep.TakingPhoto -> {
                ShutterButton(
                    enabled = controllerState is CaptureControllerState.Ready && s is FlowStep.AwaitingShutter,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 32.dp),
                    onClick = {
                        scope.launch {
                            step = FlowStep.TakingPhoto
                            try {
                                val photo = controller.takePhoto()
                                photoBytes = photo
                                controller.startRecording()
                                step = FlowStep.Recording
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                errorText = e.message ?: "photo failed"
                                step = FlowStep.AwaitingShutter
                            }
                        }
                    },
                )
            }
            FlowStep.Recording -> Unit // countdown chip only
            FlowStep.Submitting -> UploadOverlay("Preparing bundle…", null)
            is FlowStep.Submitted -> SubmittedStatus(s.session, onDone)
        }

        val ctrlErr = (controllerState as? CaptureControllerState.Error)?.message
        val banner = errorText ?: ctrlErr
        if (banner != null) {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                modifier = Modifier.align(Alignment.TopCenter).padding(16.dp),
            ) {
                Text(
                    banner,
                    modifier = Modifier.padding(12.dp),
                    color = MaterialTheme.colorScheme.onErrorContainer,
                )
            }
        }
    }
}

@Composable
private fun SubmittedStatus(session: CaptureSession, onDone: () -> Unit) {
    val state by session.state.collectAsState()
    // Dismiss the capture UI once the upload has reached the server. Server-side
    // analysis (if observed at all by the integrator) happens in the background;
    // the capture overlay does not block on it.
    LaunchedEffect(state) {
        if (state is CaptureState.Uploaded || state is CaptureState.Succeeded) onDone()
    }
    val (label, progress) = when (val s = state) {
        is CaptureState.Idle -> "Starting…" to null
        is CaptureState.Uploading -> {
            val pct = s.progressPercent
            if (pct == null) "Preparing…" to null
            else "Uploading… $pct%" to (pct / 100f)
        }
        is CaptureState.Uploaded -> "Done" to 1f
        is CaptureState.Analyzing -> "Analyzing…" to null
        is CaptureState.Succeeded -> "Done" to 1f
        is CaptureState.Cancelled -> "Cancelled" to null
        is CaptureState.Failed -> "Failed: ${s.message ?: s.stage.name}" to null
    }
    UploadOverlay(label, progress)
}

@Composable
private fun UploadOverlay(label: String, progress: Float?) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (progress != null) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.width(240.dp))
            } else {
                CircularProgressIndicator()
            }
            Spacer(Modifier.height(12.dp))
            Text(label, color = Color.White)
        }
    }
}

@Composable
private fun ShutterButton(enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(if (enabled) Color.White else Color.White.copy(alpha = 0.4f)),
        contentAlignment = Alignment.Center,
    ) {
        Button(
            onClick = onClick,
            enabled = enabled,
            shape = CircleShape,
            modifier = Modifier.size(60.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
        ) { }
    }
}
