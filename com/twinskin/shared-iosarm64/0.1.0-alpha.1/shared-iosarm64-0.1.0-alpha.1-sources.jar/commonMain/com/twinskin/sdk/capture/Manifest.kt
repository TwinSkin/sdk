package com.twinskin.sdk.capture

/**
 * Canonical filenames for the two media entries inside a capture zip.
 *
 * The shape of the accompanying `manifest.json` is defined by
 * [CaptureManifest], which is generated from the Pydantic
 * `SdkCaptureManifest` in
 * `packages/capture_pipeline/src/capture_pipeline/models.py` via
 * `packages/server/tool/generate_external_data_models.dart`.
 */
object CaptureBundleEntries {
    const val IMAGE = "photo.jpg"
    const val VIDEO = "video.mp4"
}
