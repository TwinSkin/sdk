package com.twinskin.sdk.view

/**
 * Marker exceptions a [CaptureResolver] can throw so [ViewCaptureSession]
 * maps them to the corresponding [ViewCaptureError] variant. Any other
 * throwable becomes [ViewCaptureError.Unknown].
 *
 * Resolvers are free to keep throwing plain exceptions (e.g. a ktor
 * `ResponseException`) — the classifier falls through to Unknown in that
 * case. These types just let a resolver be explicit when it knows more.
 */
class CaptureNetworkException(
    message: String? = null,
    cause: Throwable? = null,
) : RuntimeException(message, cause)

class CaptureNotFoundException(
    message: String? = null,
) : RuntimeException(message)

class CaptureInvalidAssetException(
    val reason: String,
) : RuntimeException(reason)
