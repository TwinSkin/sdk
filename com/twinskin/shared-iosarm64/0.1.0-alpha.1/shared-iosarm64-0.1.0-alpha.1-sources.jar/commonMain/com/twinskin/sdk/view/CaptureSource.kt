package com.twinskin.sdk.view

/**
 * Input to [com.twinskin.sdk.TwinSkinSdk.viewCapture]. Each variant resolves
 * to the same [ResolvedCapture] shape so the UI is source-agnostic.
 */
sealed class CaptureSource {
    /** A .glb file already on local storage. Path is a filesystem path. */
    data class LocalGlb(val path: String) : CaptureSource()

    /** Direct URL to a .glb file. Downloaded to the SDK cache. */
    data class GlbUrl(val url: String) : CaptureSource()

    /** URL to a .zip bundle containing a .glb (and, later, sidecar data). */
    data class ZipUrl(val url: String) : CaptureSource()

    /** Capture identifier — resolved via PowerSync (not yet implemented). */
    data class CaptureId(val id: String) : CaptureSource()
}

/** Options that tune the viewer without changing the source contract. */
data class ViewCaptureOptions(
    /** Render in AR mode when the underlying renderer supports it (Phase 2). */
    val ar: Boolean = false,
)
