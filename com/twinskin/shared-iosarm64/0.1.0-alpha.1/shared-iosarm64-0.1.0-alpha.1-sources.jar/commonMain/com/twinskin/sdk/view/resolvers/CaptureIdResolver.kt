package com.twinskin.sdk.view.resolvers

import com.twinskin.sdk.view.CaptureResolver
import com.twinskin.sdk.view.ResolverEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * STUB. The final implementation will subscribe to a PowerSync watch query on the
 * capture row (+ related measurements/notes/attachments rows), emit
 * [ResolverEvent.Progress] while the GLB attachment is downloading, then emit
 * [ResolverEvent.Resolved] for the initial snapshot — and keep emitting on every
 * subsequent DB change so the UI updates in real time.
 *
 * Left intentionally unimplemented so the call site, public API, and UI wiring can
 * be designed around the reactive contract before the PowerSync dependency lands.
 */
class CaptureIdResolver(
    @Suppress("unused") private val captureId: String,
) : CaptureResolver {
    override fun resolve(): Flow<ResolverEvent> = flow {
        throw NotImplementedError(
            "viewCapture(CaptureId) will be backed by a PowerSync watch query; " +
                "not yet wired up. See plan for details.",
        )
    }
}
