package com.twinskin.sdk.db

import kotlin.Long
import kotlin.String

public data class TransferTask(
  public val id: String,
  public val url: String,
  public val localPath: String,
  public val type: String,
  public val status: String,
  public val progress: Long,
  public val errorMessage: String?,
  public val unzip: Long,
  public val headers: String?,
  public val createdAt: Long,
  public val updatedAt: Long,
)
