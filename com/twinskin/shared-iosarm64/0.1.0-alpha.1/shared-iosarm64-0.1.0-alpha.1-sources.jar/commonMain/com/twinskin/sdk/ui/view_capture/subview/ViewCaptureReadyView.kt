package com.twinskin.sdk.ui.view_capture.subview

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.ui.view_capture.renderer.Model3DViewer
import com.twinskin.sdk.view.ViewCaptureState

/**
 * Composes the 3D viewer + metadata panel + streaming indicator.
 *
 * Layout is intentionally trivial: 3D on top (takes remaining space), metadata
 * panel below (self-sizing, bounded). When a real design lands, add responsive
 * rules here — not in subviews.
 */
@Composable
fun ViewCaptureReadyView(
    ready: ViewCaptureState.Ready,
    ar: Boolean,
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.TopEnd,
        ) {
            Model3DViewer(
                asset = ready.asset,
                ar = ar,
                modifier = Modifier.fillMaxSize(),
            )
            StreamingIndicator(
                isStreaming = ready.isStreaming,
                modifier = Modifier.padding(12.dp),
            )
        }
        if (ready.metadata.isNotEmpty()) {
            MetadataPanel(
                metadata = ready.metadata,
                modifier = Modifier.heightIn(max = 240.dp),
            )
        }
    }
}
