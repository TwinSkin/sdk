package com.twinskin.sdk.capture.io

/**
 * Random-access file sink. Opens [path] for writing (truncating any existing content),
 * appends via [write], and can patch earlier bytes via [writeAt] — used by the bundle
 * encryptor to patch the 16-byte AES-GCM tag into the middle of an already-streamed
 * encrypted file once the plaintext has been fully consumed.
 *
 * Non-thread-safe; the whole streaming pipeline runs on a single coroutine.
 */
internal expect class RandomAccessByteSink(path: String) {

    /** Append [len] bytes from [src] starting at [off]. */
    fun write(src: ByteArray, off: Int, len: Int)

    /** Overwrite [len] bytes at absolute file offset [pos] with [src]+[off]. */
    fun writeAt(pos: Long, src: ByteArray, off: Int, len: Int)

    /** Flush and close the underlying handle. Safe to call more than once. */
    fun close()
}
