package com.twinskin.sdk.view

/**
 * Platform-provided: stream an HTTP(S) resource to [destPath], invoking
 * [onProgress] as bytes arrive. Throws on network or IO failure.
 *
 * Kept as an expect/actual (and not delegated to [com.twinskin.sdk.transfer.TransferManager])
 * because the TransferManager is a persistent, queued, resumable upload/download
 * engine — heavier machinery than the view-capture flow needs. `viewCapture` downloads
 * are ephemeral: when the screen goes away, the download can be cancelled and the file
 * discarded.
 */
expect suspend fun downloadToPath(
    url: String,
    destPath: String,
    onProgress: (bytesRead: Long, total: Long?) -> Unit,
)
