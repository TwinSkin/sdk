package com.twinskin.sdk.capture

import com.twinskin.sdk.capture.crypto.secureRandomBytes
import com.twinskin.sdk.capture.io.deleteFileQuietly
import com.twinskin.sdk.capture.io.fileSize
import com.twinskin.sdk.capture.io.readFileStreaming
import com.twinskin.sdk.transfer.TransferManager
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.currentTimeMillis
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Orchestrates the capture pipeline: build zip → encrypt → persist → hand off to
 * [TransferManager].
 *
 * ## Persistence + idempotent URL refresh
 *
 * Once a bundle is on disk, a row is written to [SdkCaptureStore] carrying every
 * field needed to re-call `POST /api/sdk/upload/start-capture`. The server endpoint
 * is idempotent on a client-supplied `capture_id`, so the `UrlResolver` passed to
 * the [TransferManager] can always obtain a fresh presigned PUT URL without the SDK
 * having to track expiry itself.
 *
 * The store row is deliberately written *after* encryption (data minimization:
 * nothing is persisted until the bundle exists on disk) and deleted only on
 * terminal success — recovery sweeps read `PENDING_UPLOAD` rows on startup to
 * re-enqueue interrupted uploads.
 */
class CaptureApi(
    private val transferManager: TransferManager,
    private val encryptor: BundleEncryptor,
    private val store: SdkCaptureStore,
    private val sdkVersion: String,
    private val encryptedBundlePath: (captureId: String) -> String,
    private val scope: CoroutineScope,
    private val clock: () -> Long = ::currentTimeMillis,
    private val idGenerator: () -> String = ::randomCaptureId,
) {
    private val sessions = mutableMapOf<String, SessionEntry>()

    private class SessionEntry(
        val session: CaptureSession,
        var mirrorJob: Job? = null,
        var transferTaskId: String? = null,
    )

    /**
     * Start a new capture session. The server is not called until [CaptureSession.submit]
     * hands the bundle off to the transfer manager — keeping cancelled-before-submit
     * flows free of orphan server rows.
     */
    fun startCapture(metadata: SdkCaptureMetadata): CaptureSession {
        val session = CaptureSession(
            id = idGenerator(),
            metadata = metadata,
            api = this,
        )
        sessions[session.id] = SessionEntry(session)
        return session
    }

    /**
     * Bundle the captured media into an encrypted archive on disk, then hand it off to
     * the transfer manager. The full pipeline runs with a fixed-size memory footprint:
     * the video file is read twice (once to compute its CRC, once to stream through
     * the zip + AES-GCM encryptor), but neither the plaintext nor the ciphertext ever
     * lives in memory in full.
     */
    internal suspend fun submit(session: CaptureSession, photo: ByteArray, videoPath: String) {
        check(session.currentState is CaptureState.Idle) {
            "Session ${session.id} already submitted (state=${session.currentState})"
        }
        // The bundle/encrypt pipeline does blocking file I/O + AES-GCM work; move off
        // whatever dispatcher the caller used (often the main thread, since submit is
        // typically invoked from a Compose click handler) so the UI stays responsive.
        withContext(Dispatchers.Default) {
            submitBlocking(session, photo, videoPath)
        }
    }

    private suspend fun submitBlocking(session: CaptureSession, photo: ByteArray, videoPath: String) {
        // The prototype CaptureController hands video-file ownership to us on
        // stopRecording(); delete it once we're done with either outcome so the
        // cache dir doesn't accumulate one MP4 per capture.
        // Similarly, if we crash before store.insert the encrypted bundle is
        // orphaned on disk (no row points to it, so recovery won't find it).
        var encryptedPath: String? = null
        var persisted = false
        try {
            // Bundle + encrypt are internal pipeline steps; hide them behind the
            // public "uploading" phase with no meaningful progress fraction yet.
            session.setState(CaptureState.Uploading(progressPercent = null))
            val manifest = CaptureManifest(
                captureId = session.id,
                sdkVersion = sdkVersion,
                captureTimestamp = epochMillisToIso8601(clock()),
                imageFilename = CaptureBundleEntries.IMAGE,
                videoFilename = CaptureBundleEntries.VIDEO,
            )
            val manifestBytes = Json.encodeToString(manifest).encodeToByteArray()

            // Pre-read the video file once to compute CRC + size; the ZIP spec requires
            // both in the Local File Header before the entry data, and we can't hold
            // a video-sized buffer to compute CRC while also streaming it through.
            val videoSize = fileSize(videoPath)
            val videoCrc = run {
                val c = Crc32Streaming()
                readFileStreaming(videoPath) { src, off, len -> c.update(src, off, len) }
                c.value
            }

            // Still covered by the single `Uploading(null)` state set above — bundle
            // and encrypt are indistinguishable from the integrator's point of view.
            val path = encryptedBundlePath(session.id).also { encryptedPath = it }
            val bundleSink = encryptor.openEncryptingSink(path)
            try {
                val zip = ZipStoreSink(bundleSink)
                zip.addEntry("manifest.json", manifestBytes.size.toLong(), zipCrc32(manifestBytes)) { s ->
                    s.write(manifestBytes, 0, manifestBytes.size)
                }
                zip.addEntry(manifest.imageFilename, photo.size.toLong(), zipCrc32(photo)) { s ->
                    s.write(photo, 0, photo.size)
                }
                zip.addEntry(manifest.videoFilename, videoSize, videoCrc) { s ->
                    readFileStreaming(videoPath, s)
                }
                zip.finish()
            } finally {
                bundleSink.close()
            }

            // Persist before handing off so an app kill between store.insert and
            // transferManager.upload is still recoverable (the sweep finds a row
            // with no transferTaskId and re-enqueues).
            store.insert(
                captureId = session.id,
                request = session.metadata.toRequest(session.id),
                encryptedPath = path,
            )
            persisted = true

            val transferId = transferManager.upload(path, session.id)
            store.updateTransferTaskId(session.id, transferId)
            store.updateStatus(session.id, SdkCaptureUploadStatus.UPLOADING)

            sessions[session.id]?.transferTaskId = transferId
            session.setState(CaptureState.Uploading(progressPercent = 0))
            mirrorTransferInto(session, transferId)
        } catch (e: Exception) {
            session.setState(
                CaptureState.Failed(
                    stage = FailureStage.Upload,
                    message = e.message ?: e::class.simpleName ?: "unknown",
                )
            )
            throw e
        } finally {
            deleteFileQuietly(videoPath)
            if (!persisted) encryptedPath?.let { deleteFileQuietly(it) }
        }
    }

    internal suspend fun cancel(session: CaptureSession) {
        val entry = sessions[session.id] ?: return
        entry.mirrorJob?.cancel()
        entry.transferTaskId?.let { transferManager.cancelTask(it) }
        session.setState(CaptureState.Cancelled)
        store.findById(session.id)?.let {
            store.updateStatus(session.id, SdkCaptureUploadStatus.CANCELLED)
        }
        sessions.remove(session.id)
    }

    /**
     * Sweep-based recovery for captures interrupted by an app kill.
     *
     * - Rows with a [SdkCaptureUploadRecord.transferTaskId]: the TransferManager
     *   owns the resumption path (call [TransferManager.launchRecovery] on startup).
     * - Rows without one: the app died between `store.insert` and
     *   `transferManager.upload`; re-enqueue here using the persisted path.
     *
     * Safe to call repeatedly.
     */
    suspend fun recover() {
        for (record in store.findPendingUploads()) {
            if (record.transferTaskId != null) continue
            val transferId = transferManager.upload(record.encryptedPath, record.captureId)
            store.updateTransferTaskId(record.captureId, transferId)
            store.updateStatus(record.captureId, SdkCaptureUploadStatus.UPLOADING)
        }
    }

    /**
     * Fire-and-forget recovery called from `TwinSkinSdk.initialize`. Heals the
     * [SdkCaptureStore] table first (orphan captures missing a TransferTask row,
     * see [recover]), then kicks [TransferManager.launchRecovery] to reset any
     * ACTIVE uploads and retry PENDING ones. Ordering matters: step 1 restores
     * the invariant "every pending capture has a TransferTask" so step 2 sees
     * a consistent view.
     */
    fun launchRecoveryAll() {
        scope.launch {
            recover()
            transferManager.launchRecovery()
        }
    }

    private fun mirrorTransferInto(session: CaptureSession, transferTaskId: String) {
        val entry = sessions[session.id] ?: return
        entry.mirrorJob = transferManager.observeTask(transferTaskId)
            .onEach { task ->
                if (task == null) return@onEach
                when (TransferStatus.valueOf(task.status)) {
                    TransferStatus.PENDING,
                    TransferStatus.ACTIVE,
                    TransferStatus.UNZIPPING ->
                        session.setState(CaptureState.Uploading(task.progress.toInt()))
                    TransferStatus.COMPLETED -> {
                        session.setState(CaptureState.Uploaded)
                        store.updateStatus(session.id, SdkCaptureUploadStatus.COMPLETED)
                        finish(session.id)
                    }
                    TransferStatus.CANCELLED -> {
                        session.setState(CaptureState.Cancelled)
                        store.updateStatus(session.id, SdkCaptureUploadStatus.CANCELLED)
                        finish(session.id)
                    }
                    TransferStatus.FAILED -> {
                        session.setState(
                            CaptureState.Failed(
                                stage = FailureStage.Upload,
                                message = task.errorMessage ?: "upload failed",
                            )
                        )
                        store.updateStatus(session.id, SdkCaptureUploadStatus.FAILED)
                        finish(session.id)
                    }
                }
            }
            .launchIn(scope)
    }

    private fun finish(sessionId: String) {
        sessions.remove(sessionId)?.mirrorJob?.cancel()
    }
}

private fun randomCaptureId(): String {
    val bytes = ByteArray(12).also { secureRandomBytes(it) }
    return "tsc_" + bytes.joinToString("") { it.toUByte().toString(16).padStart(2, '0') }
}
