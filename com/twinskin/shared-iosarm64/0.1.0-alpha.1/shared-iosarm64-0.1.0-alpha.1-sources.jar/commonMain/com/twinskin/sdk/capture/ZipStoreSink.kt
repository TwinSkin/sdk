package com.twinskin.sdk.capture

import com.twinskin.sdk.capture.io.ByteSink

/**
 * Streaming ZIP writer (STORE method only). Writes a standards-compliant archive —
 * Local File Headers, per-entry file data, Central Directory, EOCD — through a
 * [ByteSink] one chunk at a time. Neither the per-entry payload nor the archive as
 * a whole is ever held in memory.
 *
 * ## Why CRC is required up-front
 *
 * The ZIP spec supports a "data descriptor" mode (general purpose flag bit 3) that
 * would let us stream entries whose CRC we don't yet know. But OpenJDK's
 * `ZipInputStream` refuses data descriptors on STORE entries (`only DEFLATED
 * entries can have EXT descriptor`), which would break our own JVM tests and
 * anything else using that reader. So callers compute each entry's CRC up-front
 * — for a file, that means reading it once streaming, then writing it once
 * streaming again. Two sequential passes, still zero memory footprint.
 *
 * Not ZIP64 — individual entries and the archive total are capped at 4 GiB. Capture
 * bundles are well under that; larger payloads must be split upstream.
 */
internal class ZipStoreSink(private val out: ByteSink) {

    private data class CdEntry(
        val name: ByteArray,
        val crc: UInt,
        val size: Long,
        val localHeaderOffset: Long,
    )

    private val entries = mutableListOf<CdEntry>()
    private var pos: Long = 0L
    private var finished: Boolean = false

    /**
     * Write a single entry. [producer] must write exactly [size] bytes to the sink it
     * receives; [crc] must be the CRC-32 of those same bytes. Both are validated while
     * streaming — a mismatch aborts with [IllegalStateException].
     */
    fun addEntry(name: String, size: Long, crc: UInt, producer: (ByteSink) -> Unit) {
        check(!finished) { "addEntry after finish()" }
        require(size in 0..0xffffffffL) { "entry size > 4 GiB not supported (no ZIP64)" }
        val nameBytes = name.encodeToByteArray()
        val offset = pos
        writeLocalFileHeader(nameBytes, crc, size)

        val crcStream = Crc32Streaming()
        var observed = 0L
        producer(ByteSink { src, off, len ->
            crcStream.update(src, off, len)
            observed += len
            out.write(src, off, len)
        })
        check(observed == size) {
            "ZipStoreSink: entry '$name' declared $size bytes but producer wrote $observed"
        }
        val actualCrc = crcStream.value
        check(actualCrc == crc) {
            "ZipStoreSink: entry '$name' declared CRC ${crc.toString(16)} but content hashes to ${actualCrc.toString(16)}"
        }
        pos += observed
        entries += CdEntry(nameBytes, crc, size, offset)
    }

    /** Write the Central Directory + EOCD and close the archive. Idempotent. */
    fun finish() {
        if (finished) return
        finished = true
        val cdStart = pos
        for (e in entries) writeCentralDirEntry(e)
        val cdEnd = pos
        writeEndOfCentralDir(cdStart, cdEnd - cdStart)
    }

    // -----------------------------------------------------------------------
    // ZIP record writers — all advance [pos].
    // -----------------------------------------------------------------------

    private fun writeLocalFileHeader(nameBytes: ByteArray, crc: UInt, size: Long) {
        val h = ByteArray(30)
        putU32(h,  0, 0x04034b50)          // LFH signature
        putU16(h,  4, 20)                  // version needed to extract
        putU16(h,  6, 0)                   // general purpose flags
        putU16(h,  8, 0)                   // method = STORE
        putU16(h, 10, 0)                   // mod time
        putU16(h, 12, 0x21)                // mod date (1980-01-01)
        putU32(h, 14, crc.toInt())
        putU32(h, 18, size.toInt())        // compressed size
        putU32(h, 22, size.toInt())        // uncompressed size
        putU16(h, 26, nameBytes.size)
        putU16(h, 28, 0)                   // extra field length
        writeBytes(h)
        writeBytes(nameBytes)
    }

    private fun writeCentralDirEntry(e: CdEntry) {
        val h = ByteArray(46)
        putU32(h,  0, 0x02014b50)
        putU16(h,  4, 20)
        putU16(h,  6, 20)
        putU16(h,  8, 0)
        putU16(h, 10, 0)
        putU16(h, 12, 0)
        putU16(h, 14, 0x21)
        putU32(h, 16, e.crc.toInt())
        putU32(h, 20, e.size.toInt())
        putU32(h, 24, e.size.toInt())
        putU16(h, 28, e.name.size)
        putU16(h, 30, 0)
        putU16(h, 32, 0)
        putU16(h, 34, 0)
        putU16(h, 36, 0)
        putU32(h, 38, 0)
        putU32(h, 42, e.localHeaderOffset.toInt())
        writeBytes(h)
        writeBytes(e.name)
    }

    private fun writeEndOfCentralDir(cdStart: Long, cdSize: Long) {
        val h = ByteArray(22)
        putU32(h,  0, 0x06054b50)
        putU16(h,  4, 0)
        putU16(h,  6, 0)
        putU16(h,  8, entries.size)
        putU16(h, 10, entries.size)
        putU32(h, 12, cdSize.toInt())
        putU32(h, 16, cdStart.toInt())
        putU16(h, 20, 0)
        writeBytes(h)
    }

    private fun writeBytes(b: ByteArray) {
        out.write(b, 0, b.size)
        pos += b.size
    }

    private fun putU16(b: ByteArray, o: Int, v: Int) {
        b[o]     = (v and 0xff).toByte()
        b[o + 1] = ((v ushr 8) and 0xff).toByte()
    }

    private fun putU32(b: ByteArray, o: Int, v: Int) {
        b[o]     = (v and 0xff).toByte()
        b[o + 1] = ((v ushr 8) and 0xff).toByte()
        b[o + 2] = ((v ushr 16) and 0xff).toByte()
        b[o + 3] = ((v ushr 24) and 0xff).toByte()
    }
}

/**
 * Streaming CRC-32 helper. Identical polynomial to `java.util.zip.CRC32`. Feed bytes
 * in any chunk size; read [value] at the end. Holds no buffer.
 */
internal class Crc32Streaming {
    private var c: Int = 0xffffffff.toInt()

    fun update(src: ByteArray, off: Int, len: Int) {
        var x = c
        val end = off + len
        var i = off
        while (i < end) {
            x = CRC32_TABLE[(x xor src[i].toInt()) and 0xff] xor (x ushr 8)
            i++
        }
        c = x
    }

    val value: UInt get() = (c xor 0xffffffff.toInt()).toUInt()
}

/** Convenience one-shot. For files, feed chunks into a [Crc32Streaming] instead. */
internal fun zipCrc32(data: ByteArray): UInt {
    val s = Crc32Streaming()
    s.update(data, 0, data.size)
    return s.value
}

private val CRC32_TABLE: IntArray = IntArray(256).also { table ->
    for (i in 0 until 256) {
        var c = i
        repeat(8) { c = if (c and 1 == 1) 0xedb88320.toInt() xor (c ushr 1) else c ushr 1 }
        table[i] = c
    }
}
