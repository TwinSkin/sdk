package com.twinskin.sdk

/**
 * Diagnostic sink for the SDK. Defaults to [None] so production integrator
 * apps stay quiet; demo hosts (and any integrator that wants to see what's
 * happening) pass [Println] or their own [SdkLogger] via [TwinSkinConfig.logger].
 *
 * The SDK only emits at swallow points where a transient failure would
 * otherwise be invisible — token-mint errors, start-capture errors, worker
 * retries — so enabling this never becomes noisy on a healthy system.
 */
fun interface SdkLogger {
    fun log(message: String, cause: Throwable?)

    fun log(message: String) = log(message, null)

    companion object {
        val None: SdkLogger = SdkLogger { _, _ -> }

        val Println: SdkLogger = SdkLogger { message, cause ->
            val suffix = cause?.let { " (${it::class.simpleName}: ${it.message})" }.orEmpty()
            println("[TwinSkin] $message$suffix")
        }
    }
}
