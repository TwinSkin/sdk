package com.twinskin.sdk.ui

import androidx.compose.runtime.Composable

@Composable
expect fun View3DSceneKitScreen()
