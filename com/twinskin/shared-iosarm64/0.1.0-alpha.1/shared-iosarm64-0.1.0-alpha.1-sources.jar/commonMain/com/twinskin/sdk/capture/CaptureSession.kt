package com.twinskin.sdk.capture

import com.twinskin.sdk.sdk_client.SdkStartCaptureRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.JsonElement

/**
 * Customer-supplied metadata required to start a capture on the server.
 * Mirrors the fields of `POST /api/sdk/upload/start-capture`.
 */
data class SdkCaptureMetadata(
    val userRef: String,
    val subjectRef: String,
    val conditionType: String? = null,
    val captureGroup: String? = null,
    val bodyLocation: List<String>? = null,
    val custom: Map<String, JsonElement>? = null,
) {
    internal fun toRequest(captureId: String): SdkStartCaptureRequest =
        SdkStartCaptureRequest(
            userRef = userRef,
            subjectRef = subjectRef,
            captureId = captureId,
            conditionType = conditionType,
            captureGroup = captureGroup,
            bodyLocation = bodyLocation,
            custom = custom,
        )
}

/**
 * Represents one in-flight capture. Returned by [CaptureApi.startCapture].
 *
 * Observe [state] to follow the full lifecycle, or call [submit] / [cancel] to drive it.
 * Submit is one-shot: a session that has already transitioned past [CaptureState.Idle]
 * rejects further submissions.
 */
class CaptureSession internal constructor(
    val id: String,
    val metadata: SdkCaptureMetadata,
    private val api: CaptureApi,
) {
    private val _state = MutableStateFlow<CaptureState>(CaptureState.Idle)
    val state: StateFlow<CaptureState> = _state.asStateFlow()

    /**
     * Bundle and encrypt the captured media, then hand the encrypted archive to the
     * transfer manager. Returns when the bundle has been handed off (session enters
     * [CaptureState.Uploading]); the upload itself continues asynchronously — observe
     * [state] to await [CaptureState.Uploaded] (local terminal) or
     * [CaptureState.Succeeded] (server-confirmed, only when the capture is also
     * observed via a server-aware API).
     */
    suspend fun submit(photo: ByteArray, videoPath: String) = api.submit(this, photo, videoPath)

    /** Cancel this session. Cancels the transfer if already handed off. */
    suspend fun cancel() = api.cancel(this)

    internal fun setState(new: CaptureState) { _state.value = new }
    internal val currentState: CaptureState get() = _state.value
}
