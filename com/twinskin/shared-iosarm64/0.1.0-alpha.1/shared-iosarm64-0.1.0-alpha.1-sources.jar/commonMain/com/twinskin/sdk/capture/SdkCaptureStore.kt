package com.twinskin.sdk.capture

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.sdk_client.SdkStartCaptureRequest
import com.twinskin.sdk.transfer.currentTimeMillis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/**
 * Durable record written when a capture's encrypted bundle has been
 * materialized on disk and is ready to hand off to the transfer manager.
 *
 * Stores everything needed to re-call `POST /upload/start-capture` (the
 * server's idempotent entry point) so we can mint a fresh presigned PUT
 * URL whenever the TransferManager's URL resolver is asked to refresh
 * one.
 */
data class SdkCaptureUploadRecord(
    val captureId: String,
    val request: SdkStartCaptureRequest,
    val encryptedPath: String,
    val status: SdkCaptureUploadStatus,
    val transferTaskId: String?,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
)

enum class SdkCaptureUploadStatus {
    /** Bundle is on disk, server call + upload pending or in flight. */
    PENDING_UPLOAD,
    /** TransferManager has an active task for the upload. */
    UPLOADING,
    /** Upload succeeded — row can be garbage-collected. */
    COMPLETED,
    /** Terminal failure from the server or an unrecoverable upload error. */
    FAILED,
    /** Host cancelled before upload completed. */
    CANCELLED,
}

/**
 * Thin typed wrapper over the SQLDelight `SdkCaptureUpload` queries.
 */
class SdkCaptureStore(
    private val database: TwinSkinDatabase,
    private val clock: () -> Long = ::currentTimeMillis,
    private val json: Json = Json,
) {
    private val queries get() = database.sdkCaptureUploadQueries

    fun insert(
        captureId: String,
        request: SdkStartCaptureRequest,
        encryptedPath: String,
    ): SdkCaptureUploadRecord {
        val now = clock()
        queries.insert(
            captureId = captureId,
            userRef = request.userRef,
            subjectRef = request.subjectRef,
            conditionType = request.conditionType,
            captureGroup = request.captureGroup,
            bodyLocationJson = request.bodyLocation?.let { json.encodeToString(it) },
            customJson = request.custom?.let { json.encodeToString(JsonObject(it)) },
            encryptedPath = encryptedPath,
            status = SdkCaptureUploadStatus.PENDING_UPLOAD.name,
            transferTaskId = null,
            createdAt = now,
            updatedAt = now,
        )
        return SdkCaptureUploadRecord(
            captureId = captureId,
            request = request,
            encryptedPath = encryptedPath,
            status = SdkCaptureUploadStatus.PENDING_UPLOAD,
            transferTaskId = null,
            createdAtEpochMs = now,
            updatedAtEpochMs = now,
        )
    }

    fun findById(captureId: String): SdkCaptureUploadRecord? =
        queries.selectById(captureId).executeAsOneOrNull()?.toRecord()

    fun findPendingUploads(): List<SdkCaptureUploadRecord> =
        queries.selectByStatus(SdkCaptureUploadStatus.PENDING_UPLOAD.name)
            .executeAsList()
            .map { it.toRecord() }

    /**
     * Observe every row in the upload table, sorted by creation time (newest first).
     * Re-emits whenever any row is inserted, updated, or deleted — backed by
     * SQLDelight's query-change listener. Cheap enough to subscribe at app launch.
     */
    fun observeAll(): Flow<List<SdkCaptureUploadRecord>> =
        queries.selectAll()
            .asFlow()
            .mapToList(Dispatchers.Default)
            .map { rows -> rows.map { it.toRecord() } }

    fun updateStatus(captureId: String, status: SdkCaptureUploadStatus) {
        queries.updateStatus(status.name, clock(), captureId)
    }

    fun updateTransferTaskId(captureId: String, transferTaskId: String?) {
        queries.updateTransferTaskId(transferTaskId, clock(), captureId)
    }

    fun deleteById(captureId: String) {
        queries.deleteById(captureId)
    }

    private fun com.twinskin.sdk.db.SdkCaptureUpload.toRecord(): SdkCaptureUploadRecord {
        val bodyLocation = bodyLocationJson?.let {
            json.decodeFromString<List<String>>(it)
        }
        val custom = customJson?.let {
            json.decodeFromString<Map<String, JsonElement>>(it)
        }
        return SdkCaptureUploadRecord(
            captureId = captureId,
            request = SdkStartCaptureRequest(
                userRef = userRef,
                subjectRef = subjectRef,
                captureId = captureId,
                conditionType = conditionType,
                captureGroup = captureGroup,
                bodyLocation = bodyLocation,
                custom = custom,
            ),
            encryptedPath = encryptedPath,
            status = SdkCaptureUploadStatus.valueOf(status),
            transferTaskId = transferTaskId,
            createdAtEpochMs = createdAt,
            updatedAtEpochMs = updatedAt,
        )
    }
}
