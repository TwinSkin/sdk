package com.twinskin.sdk

import com.twinskin.sdk.capture.CaptureObserver
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.view.CaptureSource
// ViewCaptureOptions is only referenced from a KDoc link below; imported so
// the reference resolves when generating docs.
import com.twinskin.sdk.view.ViewCaptureOptions
import com.twinskin.sdk.view.ViewCaptureSession
import com.twinskin.sdk.view.resolvers.CaptureIdResolver
import com.twinskin.sdk.view.resolvers.HttpGlbResolver
import com.twinskin.sdk.view.resolvers.LocalGlbResolver
import com.twinskin.sdk.view.resolvers.ZipResolver
import kotlin.concurrent.Volatile

/**
 * Public façade for the TwinSkin SDK. Host apps only touch two entry
 * points:
 *
 * - `initialize(...)` — called once from the application entry point
 *   (Android: `fun TwinSkinSdk.initialize(app, config)` from androidMain;
 *   iOS: `fun TwinSkinSdk.initialize(config)` from iosMain).
 * - [startCapture] — open a fresh capture session; the `CaptureScreen`
 *   composable drives it.
 *
 * Everything inside the SDK is wired via constructor-injected components
 * (see [TwinSkinSdkComponent]). This object is only the final façade so
 * integrators don't have to assemble the graph themselves.
 */
object TwinSkinSdk {
    @Volatile
    private var component: TwinSkinSdkComponent? = null

    /** Open a new capture session. The server is only contacted when the session is submitted. */
    fun startCapture(metadata: SdkCaptureMetadata): CaptureSession =
        requireComponent().captureApi.startCapture(metadata)

    /**
     * Observe captures known to this SDK instance. The returned [CaptureObserver]
     * is a read-only view; it never drives capture lifecycle. See
     * [CaptureObserver.observePendingUploads] for the canonical use case
     * (background upload progress UI).
     */
    val captures: CaptureObserver
        get() = requireComponent().captureObserver

    /**
     * View a previously-captured 3D model. Returns a [ViewCaptureSession] whose
     * `state` StateFlow the host Compose screen observes. Close the session
     * when the screen is torn down.
     *
     * Rendering-time tweaks like AR mode live on [ViewCaptureOptions] and are
     * consumed by the UI host ([com.twinskin.sdk.ui.view_capture.ViewCaptureScreenHost]) —
     * they intentionally don't flow into the session, which is the pure data pipeline.
     */
    fun viewCapture(source: CaptureSource): ViewCaptureSession {
        val component = requireComponent()
        val resolver = when (source) {
            is CaptureSource.LocalGlb -> LocalGlbResolver(source.path)
            is CaptureSource.GlbUrl -> HttpGlbResolver(
                url = source.url,
                cacheDir = component.storage.dir(Purpose.ViewCapture),
            )
            is CaptureSource.ZipUrl -> ZipResolver(
                url = source.url,
                cacheDir = component.storage.dir(Purpose.ViewCapture),
                zipEngine = component.zipEngine,
            )
            is CaptureSource.CaptureId -> CaptureIdResolver(source.id)
        }
        return ViewCaptureSession(resolver)
    }

    /**
     * Idempotent: a second call is a no-op so hosts that (for example) wire
     * initialization from both an `Application` and a splash screen don't have
     * to guard it themselves. Any [TwinSkinSdkComponent] built for the second
     * call is discarded.
     */
    internal fun install(built: TwinSkinSdkComponent): Boolean {
        if (component != null) return false
        component = built
        return true
    }

    internal val isInitialized: Boolean get() = component != null

    internal fun requireComponent(): TwinSkinSdkComponent =
        component ?: error("TwinSkinSdk.initialize(...) must be called before using the SDK.")

    /** For tests only — clears the installed component so the next `initialize` succeeds. */
    internal fun resetForTests() {
        component = null
    }
}

/**
 * Integrator-supplied configuration. [baseUrl] defaults to the production
 * server; demo / local-dev hosts pass an override.
 */
data class TwinSkinConfig(
    val publishableKey: String,
    val authorizationProvider: SdkAuthorizationProvider,
    val baseUrl: String = PROD_BASE_URL,
    val logger: SdkLogger? = null,
) {
    companion object {
        const val PROD_BASE_URL: String = "https://prod.dermatoo.com/api/sdk"
    }
}
