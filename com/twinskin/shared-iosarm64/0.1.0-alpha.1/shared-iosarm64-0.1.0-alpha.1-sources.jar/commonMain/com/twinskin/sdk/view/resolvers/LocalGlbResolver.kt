package com.twinskin.sdk.view.resolvers

import com.twinskin.sdk.view.Asset3D
import com.twinskin.sdk.view.Asset3DFormat
import com.twinskin.sdk.view.CaptureResolver
import com.twinskin.sdk.view.ResolvedCapture
import com.twinskin.sdk.view.ResolverEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/** One-shot resolver for a .glb file already on local storage. */
class LocalGlbResolver(private val path: String) : CaptureResolver {
    override fun resolve(): Flow<ResolverEvent> = flow {
        emit(
            ResolverEvent.Resolved(
                ResolvedCapture(
                    model = Asset3D(location = path, format = Asset3DFormat.GLB),
                ),
            ),
        )
    }
}
