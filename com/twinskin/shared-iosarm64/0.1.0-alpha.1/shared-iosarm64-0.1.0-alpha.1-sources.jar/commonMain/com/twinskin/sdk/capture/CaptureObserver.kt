package com.twinskin.sdk.capture

import kotlinx.coroutines.flow.Flow

/**
 * Observe captures known to this SDK instance.
 *
 * Obtained from `TwinSkinSdk.captures`. The observer never owns the capture
 * lifecycle — it's a read-only view. All methods return cold Flows; work only
 * happens while a collector is active.
 *
 * Two entry points, two levels of opt-in:
 *
 *  - [observePendingUploads] is the cheap one: local-only state, no
 *    authentication, no network. Safe to subscribe at app launch.
 *  - [observeSubject] merges local state with server-side analysis
 *    state via a subject-scoped PowerSync connection opened lazily on
 *    first collection. It's the opt-in for server-side observation.
 */
interface CaptureObserver {
    /**
     * Captures currently being uploaded from this device. Emits a row while its
     * upload is in flight and briefly after it reaches a terminal state, so a
     * progress UI can animate out. Use this to drive a background-upload
     * indicator paired with [CaptureApi.startCapture] calls.
     *
     * Device-scoped (any subject). No authentication, no network — free to
     * subscribe at app launch. Never opens a PowerSync connection.
     */
    fun observePendingUploads(): Flow<List<PendingUpload>>

    /**
     * Subject-scoped feed of every capture for [subjectRef] known to either
     * side: on-device rows from the local store and server rows streamed over
     * PowerSync. Server state wins on conflicts; local-only rows surface with
     * their on-device [CaptureState]. Rows in a post-upload limbo (local says
     * `Uploaded`, server hasn't yet created the row) are smoothed to
     * [CaptureState.Analyzing] so UIs don't flicker between "upload done" and
     * "server working".
     *
     * Calling this method is the opt-in for server-side observation: a
     * PowerSync client is created on first collection, shared across
     * collectors of the same subject, and closed ~5s after the last collector
     * cancels. Different subjects = different clients.
     *
     * Throws on first collection if the integrator's [SdkAuthorizationProvider]
     * returns a payload without `powersync_url` — that's a server deployment
     * misconfig, not a silent opt-out.
     */
    fun observeSubject(subjectRef: String): Flow<List<CaptureEntry>>
}

/**
 * Snapshot of a single capture's local upload state, as seen by
 * [CaptureObserver.observePendingUploads]. Only local-state variants of
 * [CaptureState] appear here: [CaptureState.Uploading], [CaptureState.Uploaded],
 * [CaptureState.Failed] (with [FailureStage.Upload]), or [CaptureState.Cancelled].
 */
data class PendingUpload(
    val captureId: String,
    val subjectRef: String,
    val state: CaptureState,
    val updatedAtEpochMs: Long,
)

/**
 * Snapshot of a single capture's merged (local + server) state, as seen by
 * [CaptureObserver.observeSubject]. Every [CaptureState] variant is reachable
 * here; server-only variants like [CaptureState.Analyzing] / [CaptureState.Succeeded]
 * or [CaptureState.Failed] with [FailureStage.Server] flow through this type
 * exclusively.
 */
data class CaptureEntry(
    val captureId: String,
    val subjectRef: String,
    val state: CaptureState,
    val updatedAtEpochMs: Long,
)
