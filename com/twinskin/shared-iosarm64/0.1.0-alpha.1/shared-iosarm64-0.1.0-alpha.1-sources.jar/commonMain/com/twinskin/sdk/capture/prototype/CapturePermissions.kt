package com.twinskin.sdk.capture.prototype

import androidx.compose.runtime.Composable

/**
 * Minimal permission gate for the prototype capture flow (CAMERA + microphone).
 *
 * [granted] reflects the current OS state; [request] triggers a one-shot user prompt.
 * Lives in `prototype/` alongside the rest of the temporary camera code — the final
 * production flow will have its own permission strategy.
 */
interface CapturePermissionsState {
    val granted: Boolean
    val denied: Boolean
    fun request()
}

@Composable
expect fun rememberCapturePermissionsState(): CapturePermissionsState
