package com.twinskin.sdk.view

/** A 3D asset resolved to a location the renderer can load. */
data class Asset3D(
    /** Filesystem path OR http(s) URL — renderer decides based on scheme. */
    val location: String,
    val format: Asset3DFormat,
)

enum class Asset3DFormat { GLB, USDZ }

/**
 * What a [CaptureResolver] produces. The resolver streams updates, so any
 * nullable field means "not known yet" rather than "not present".
 *
 * [metadata] is intentionally an opaque key/value map in Phase 0 — the shape
 * firms up when PowerSync lands and we know which typed fields we actually
 * carry (measurements, notes, subject, etc.).
 */
data class ResolvedCapture(
    val model: Asset3D?,
    val metadata: Map<String, String> = emptyMap(),
)
