package com.twinskin.sdk.storage

import com.twinskin.sdk.SdkLogger

/**
 * Chokepoint for every file the SDK writes to disk. Every component that
 * needs a directory goes through [dir]; retention and wipe flows go
 * through [sweep] / [wipe]. No SDK code should ever hit `cacheDir`,
 * `NSTemporaryDirectory`, etc. directly — if you add a new on-disk
 * artefact, add a [Purpose] for it here.
 */
internal interface SdkStorage {
    /**
     * Absolute path to the directory for [purpose]. The directory is
     * created on first access for purposes the SDK writes to. For
     * [Purpose.Databases] the returned path is whatever the platform's
     * SQLite layer chose (PowerSync hardcodes it) — callers must only
     * read it via [sweep]/[wipe], never write new files into it.
     */
    fun dir(purpose: Purpose): String

    /**
     * Delete every file under `dir(purpose)` whose name passes [filter]
     * and whose last-modified time is older than [olderThanMs] from
     * now. Every file op is wrapped in `runCatching`; failures go to
     * [logger]. Never throws.
     */
    fun sweep(
        purpose: Purpose,
        olderThanMs: Long,
        logger: SdkLogger,
        filter: (name: String) -> Boolean = { true },
    )

    /**
     * Delete every file under `dir(purpose)` whose name passes [filter],
     * regardless of age. Same error-handling contract as [sweep].
     */
    fun wipe(
        purpose: Purpose,
        logger: SdkLogger,
        filter: (name: String) -> Boolean = { true },
    )
}

/**
 * [subdirName] is the leaf directory under each platform's `twinskin/` root
 * that owns this purpose's files. Unused for [Databases], whose location is
 * dictated by the SQLite/PowerSync layer.
 */
internal enum class Purpose(val subdirName: String) {
    /** Encrypted capture bundles staged for upload (`sdk-capture-*.bin`). Evictable. */
    EncryptedBundles("bundles"),

    /** View-capture downloads (`<uuid>.glb`, `bundle-<id>.zip`, `bundle-<id>/`). Evictable. */
    ViewCapture("view-capture"),

    /**
     * Directory where the SQLite/PowerSync layer puts its files. The SDK does
     * not write here directly — [sweep] and [wipe] are used with a filename
     * filter (e.g. the `twinskin_sdk_captures_` prefix) so only SDK-owned
     * databases are touched.
     */
    Databases(subdirName = ""),
}
