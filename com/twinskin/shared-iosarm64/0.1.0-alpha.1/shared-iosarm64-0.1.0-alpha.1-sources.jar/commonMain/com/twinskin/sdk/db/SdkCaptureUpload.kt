package com.twinskin.sdk.db

import kotlin.Long
import kotlin.String

public data class SdkCaptureUpload(
  public val captureId: String,
  public val userRef: String,
  public val subjectRef: String,
  public val conditionType: String?,
  public val captureGroup: String?,
  public val bodyLocationJson: String?,
  public val customJson: String?,
  public val encryptedPath: String,
  public val status: String,
  public val transferTaskId: String?,
  public val createdAt: Long,
  public val updatedAt: Long,
)
