package com.twinskin.sdk.transfer

/**
 * Converts between absolute file system paths and storage-safe paths persisted in the database.
 *
 * ## Why this exists
 *
 * On iOS, the app container path changes between launches — the UUID segment in
 * `/var/mobile/Containers/Data/Application/[UUID]/...` is reassigned on reinstall,
 * restore from backup, and sometimes on app update. Storing absolute paths in the DB
 * would silently break all persisted transfers after such an event.
 *
 * The iOS implementation strips the container prefix on write ([toStorage]) and prepends
 * the current container root on read ([fromStorage]), following the same pattern used by
 * the AWS S3 Transfer Utility.
 *
 * On Android and JVM, paths are stable and the implementation is a no-op pass-through.
 *
 * ## Usage
 *
 * [TransferManager] calls [toStorage] when inserting a path into the database and
 * [fromStorage] when reading a path back — both for internal use (passing to the
 * platform provider, zip engine) and for the public observe/query API. This makes the
 * conversion completely transparent to consumers.
 */
interface PathResolver {
    /** Convert an absolute path to a storage-safe form for the database. */
    fun toStorage(absolutePath: String): String

    /** Convert a storage-safe path back to an absolute filesystem path. */
    fun fromStorage(storagePath: String): String
}

/**
 * Identity [PathResolver] — no conversion. Used on Android and JVM where app
 * container paths are stable across launches.
 */
object IdentityPathResolver : PathResolver {
    override fun toStorage(absolutePath: String): String = absolutePath
    override fun fromStorage(storagePath: String): String = storagePath
}
