package com.twinskin.sdk

import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider

/**
 * Integrator-supplied configuration for [TwinSkin.initialize]. Mirrors
 * iOS `TwinSkinConfiguration` (see `sdk-ios/Sources/TwinSkinConfiguration.swift`).
 *
 * The `.kotlin` conversion is the bridge to the underlying [TwinSkinConfig]
 * — kept internal so consumers stay on the wrapper surface.
 */
public data class TwinSkinConfiguration(
    val publishableKey: String,
    val authorizationProvider: SdkAuthorizationProvider,
    val baseUrl: String = TwinSkinConfig.PROD_BASE_URL,
    val logger: SdkLogger? = null,
    val logLevel: SdkLogLevel? = null,
    val devMode: Boolean = false,
    val verboseFrameLogs: Boolean = false,
    val captureMode: CaptureMode = CaptureMode.AccelerometerCapture,
    /**
     * **Dev/test only.** Provider for extra `debug_padding.bin` bytes
     * appended to the encrypted bundle before upload — see
     * [TwinSkinConfig.debugBundlePaddingBytesProvider]. Honoured only when
     * [devMode] is `true`; `null` (default) injects nothing.
     */
    @property:TwinSkinInternalApi
    val debugBundlePaddingBytesProvider: (() -> Long)? = null,
) {
    @OptIn(TwinSkinInternalApi::class)
    internal val kotlin: TwinSkinConfig
        get() = TwinSkinConfig(
            publishableKey = publishableKey,
            authorizationProvider = authorizationProvider,
            baseUrl = baseUrl,
            logger = logger,
            logLevel = logLevel,
            devMode = devMode,
            verboseFrameLogs = verboseFrameLogs,
            captureMode = captureMode,
            debugBundlePaddingBytesProvider = debugBundlePaddingBytesProvider,
        )
}
