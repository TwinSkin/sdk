package com.twinskin.sdk

/** Result of [TwinSkin.editAnnotation]. */
public sealed class EditAnnotationOutcome {
    /** Submitted, creating measurement [revision]. */
    public data class Submitted(val revision: Long) : EditAnnotationOutcome()

    /** Dismissed without submitting. */
    public object Cancelled : EditAnnotationOutcome()
}
