package com.twinskin.sdk.internal

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import com.twinskin.sdk.TwinSkinPresentationException

/**
 * Unwraps [this] to the hosting [Activity]. SDK capture UI is presented
 * as an Activity, so a non-Activity-backed Context cannot host it.
 */
internal fun Context.findActivity(): Activity {
    var ctx: Context = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    throw TwinSkinPresentationException(
        "startCapture/viewCapture requires an Activity-backed Context",
    )
}
