package com.twinskin.sdk

import android.content.Intent
import com.twinskin.sdk.internal.SdkViewCaptureActivity
import com.twinskin.sdk.view.CaptureSource as KmpCaptureSource

/**
 * Input to [TwinSkin.viewCapture]. Mirrors iOS `TwinSkinCaptureSource`
 * (see `sdk-ios/Sources/CaptureSource.swift`).
 *
 * The URL variants accept an optional async [headersProvider] the SDK
 * invokes just before the HTTP fetch — returned headers are attached
 * to the initial GET only. Every redirect is followed without them so
 * sensitive tokens never reach the redirect target (typically a
 * presigned S3 URL). A throw from the closure surfaces in the viewer
 * as `ViewCaptureError.Credentials` with a Retry affordance.
 */
public sealed class TwinSkinCaptureSource {
    /** A .glb file already on local storage. */
    public data class LocalGlb(val path: String) : TwinSkinCaptureSource()

    /** Direct URL to a .glb file. Downloaded to the SDK cache. */
    public class GlbUrl(
        public val url: String,
        public val headersProvider: suspend () -> Map<String, String> = { emptyMap() },
    ) : TwinSkinCaptureSource()

    /**
     * Capture identifier resolved via PowerSync against Twinskin using the
     * SDK's own session credentials. [subjectRef] is required because the
     * SDK's PowerSync token is subject-scoped; the capture id alone cannot
     * authorize the watch query.
     */
    public data class CaptureId(val id: String, val subjectRef: String) : TwinSkinCaptureSource()

    internal val kotlin: KmpCaptureSource
        get() = when (this) {
            is LocalGlb -> KmpCaptureSource.LocalGlb(path)
            is GlbUrl -> KmpCaptureSource.GlbUrl(url, headersProvider)
            is CaptureId -> KmpCaptureSource.CaptureId(id, subjectRef)
        }
}

/**
 * Writes the extras [SdkViewCaptureActivity] reads back to reconstruct this
 * source. The async [GlbUrl.headersProvider] cannot cross the intent
 * boundary; it is resolved eagerly here and the resulting headers shipped
 * as parallel key/value lists.
 */
internal suspend fun TwinSkinCaptureSource.fillViewCaptureIntent(intent: Intent) {
    when (val source = this) {
        is TwinSkinCaptureSource.LocalGlb -> {
            intent.putExtra(SdkViewCaptureActivity.EXTRA_KIND, "localGlb")
            intent.putExtra(SdkViewCaptureActivity.EXTRA_PATH, source.path)
        }
        is TwinSkinCaptureSource.GlbUrl -> {
            intent.putExtra(SdkViewCaptureActivity.EXTRA_KIND, "glbUrl")
            intent.putExtra(SdkViewCaptureActivity.EXTRA_URL, source.url)
            val headers: Map<String, String> = source.headersProvider()
            val keys = ArrayList<String>(headers.size)
            val values = ArrayList<String>(headers.size)
            for (entry in headers) {
                keys.add(entry.key)
                values.add(entry.value)
            }
            intent.putStringArrayListExtra(SdkViewCaptureActivity.EXTRA_HEADER_KEYS, keys)
            intent.putStringArrayListExtra(SdkViewCaptureActivity.EXTRA_HEADER_VALUES, values)
        }
        is TwinSkinCaptureSource.CaptureId -> {
            intent.putExtra(SdkViewCaptureActivity.EXTRA_KIND, "captureId")
            intent.putExtra(SdkViewCaptureActivity.EXTRA_ID, source.id)
            intent.putExtra(SdkViewCaptureActivity.EXTRA_SUBJECT_REF, source.subjectRef)
        }
    }
}
