package com.twinskin.sdk.internal

import kotlinx.coroutines.CompletableDeferred
import java.util.concurrent.atomic.AtomicInteger

/**
 * Bridges an SDK-owned Activity's result back to the coroutine that
 * launched it. Both sides are in-process; the request id is the only
 * thing that crosses the intent boundary.
 */
internal class CaptureResultRelay<T> {
    private val nextId = AtomicInteger(0)
    private val pending = mutableMapOf<Int, CompletableDeferred<T?>>()

    fun register(): Pair<Int, CompletableDeferred<T?>> {
        val id = nextId.getAndIncrement()
        val deferred = CompletableDeferred<T?>()
        synchronized(pending) { pending[id] = deferred }
        return id to deferred
    }

    /** Resolves the deferred for [id]. No-op if unknown or already done. */
    fun complete(id: Int, value: T?) {
        val deferred = synchronized(pending) { pending.remove(id) } ?: return
        deferred.complete(value)
    }
}
