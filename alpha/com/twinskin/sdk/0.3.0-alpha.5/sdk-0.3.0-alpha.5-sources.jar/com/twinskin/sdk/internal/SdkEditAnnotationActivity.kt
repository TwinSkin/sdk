package com.twinskin.sdk.internal

import android.graphics.Color
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.twinskin.sdk.EditAnnotationOutcome
import com.twinskin.sdk.TwinSkin
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.ui.edit_annotation.EditAnnotationResult
import com.twinskin.sdk.ui.edit_annotation.EditAnnotationScreenHost

/**
 * SDK-owned full-screen host for [EditAnnotationScreenHost]. Launched by
 * `TwinSkin.editAnnotation`; signals completion through
 * [TwinSkin.editAnnotationRelay].
 */
@OptIn(TwinSkinInternalApi::class)
internal class SdkEditAnnotationActivity : ComponentActivity() {

    private var requestId: Int = -1
    private var delivered = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestId = intent.getIntExtra(EXTRA_REQUEST_ID, -1)
        require(requestId != -1) { "SdkEditAnnotationActivity launched without EXTRA_REQUEST_ID" }
        val captureId = requireNotNull(intent.getStringExtra(EXTRA_CAPTURE_ID)) {
            "SdkEditAnnotationActivity launched without EXTRA_CAPTURE_ID"
        }
        val subjectRef = requireNotNull(intent.getStringExtra(EXTRA_SUBJECT_REF)) {
            "SdkEditAnnotationActivity launched without EXTRA_SUBJECT_REF"
        }

        // Restored after a background process death: the system recreates
        // this activity before the host app re-runs TwinSkin.initialize
        // (guaranteed for Flutter hosts, whose init is Dart-driven).
        // Composing would crash on requireComponent(); the awaiting
        // caller died with the old process, so just close.
        if (!TwinSkinSdk.isInitialized) {
            delivered = true
            finish()
            return
        }

        // The editor is a light, edge-to-edge surface that applies its own
        // insets, so draw behind the bars but keep them visible with dark icons.
        // Clearing the legacy fullscreen flag a host (e.g. Flutter) may have set
        // restores the status-bar strip to inset below.
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_DEFAULT
            show(WindowInsetsCompat.Type.systemBars())
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }

        setContent {
            MaterialTheme {
                EditAnnotationScreenHost(
                    captureId = captureId,
                    subjectRef = subjectRef,
                    onResult = { result -> deliver(result.toOutcome()) },
                )
            }
        }
    }

    private fun deliver(outcome: EditAnnotationOutcome) {
        delivered = true
        TwinSkin.editAnnotationRelay.complete(requestId, outcome)
        finish()
    }

    override fun onDestroy() {
        if (!delivered && isFinishing) {
            TwinSkin.editAnnotationRelay.complete(requestId, EditAnnotationOutcome.Cancelled)
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_REQUEST_ID = "requestId"
        const val EXTRA_CAPTURE_ID = "captureId"
        const val EXTRA_SUBJECT_REF = "subjectRef"
    }
}

@OptIn(TwinSkinInternalApi::class)
private fun EditAnnotationResult.toOutcome(): EditAnnotationOutcome = when (this) {
    is EditAnnotationResult.Submitted -> EditAnnotationOutcome.Submitted(revision)
    EditAnnotationResult.Cancelled -> EditAnnotationOutcome.Cancelled
}
