package com.twinskin.sdk

import android.content.Intent
import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.internal.SdkCaptureActivity
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive

/**
 * Metadata required to start a capture. Mirrors iOS `CaptureMetadata`
 * (see `sdk-ios/Sources/CaptureMetadata.swift`).
 *
 * `conditionType` is required — it picks the server-side downstream
 * pipeline (wound vs. other), so there is no safe default.
 *
 * `custom` is a flat `Map<String, String>`, lifted to the underlying
 * [SdkCaptureMetadata]'s `Map<String, JsonElement>`. For nested JSON,
 * build [SdkCaptureMetadata] directly.
 */
public data class CaptureMetadata(
    val userRef: String,
    val subjectRef: String,
    val conditionType: ConditionType,
    val captureGroup: String? = null,
    val bodyLocation: List<String>? = null,
    val custom: Map<String, String>? = null,
) {
    internal val kotlin: SdkCaptureMetadata
        get() = SdkCaptureMetadata(
            userRef = userRef,
            subjectRef = subjectRef,
            conditionType = conditionType,
            captureGroup = captureGroup,
            bodyLocation = bodyLocation,
            custom = custom?.toJsonElementMap(),
        )
}

internal fun Map<String, String>.toJsonElementMap(): Map<String, JsonElement> =
    mapValues { JsonPrimitive(it.value) }

/** Writes the extras [SdkCaptureActivity] reads back to reconstruct this metadata. */
internal fun CaptureMetadata.fillCaptureIntent(intent: Intent) {
    intent.putExtra(SdkCaptureActivity.EXTRA_USER_REF, userRef)
    intent.putExtra(SdkCaptureActivity.EXTRA_SUBJECT_REF, subjectRef)
    intent.putExtra(
        SdkCaptureActivity.EXTRA_CONDITION_TYPE,
        when (conditionType) {
            ConditionType.Wound -> "wound"
            ConditionType.Generic -> "generic"
        },
    )
    captureGroup?.let { intent.putExtra(SdkCaptureActivity.EXTRA_CAPTURE_GROUP, it) }
    bodyLocation?.let {
        intent.putStringArrayListExtra(SdkCaptureActivity.EXTRA_BODY_LOCATION, ArrayList(it))
    }
    custom?.let {
        intent.putStringArrayListExtra(SdkCaptureActivity.EXTRA_CUSTOM_KEYS, ArrayList(it.keys))
        intent.putStringArrayListExtra(SdkCaptureActivity.EXTRA_CUSTOM_VALUES, ArrayList(it.values))
    }
}
