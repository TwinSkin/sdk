package com.twinskin.sdk

/**
 * Thrown by `TwinSkin.startCapture` / `viewCapture` when the SDK cannot
 * present UI — e.g. no Activity is in the foreground.
 */
public class TwinSkinPresentationException internal constructor(
    message: String,
) : Exception(message)
