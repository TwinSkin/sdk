@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk

import android.app.Application
import com.twinskin.sdk.capture.AndroidPowerSyncClientFactory
import com.twinskin.sdk.capture.BundleEncryptor
import com.twinskin.sdk.capture.BundleReleaseConfirmer
import com.twinskin.sdk.capture.CaptureApi
import com.twinskin.sdk.capture.UIReplayContinuationOutbox
import com.twinskin.sdk.capture.DefaultCaptureObserver
import com.twinskin.sdk.capture.SdkCaptureStore
import com.twinskin.sdk.capture.ServerCaptureSource
import com.twinskin.sdk.capture.bundleSizeIn
import com.twinskin.sdk.capture.captureEncryptionPublicKeyDer
import com.twinskin.sdk.capture.cleanupStaleSdkCaptureDbs
import com.twinskin.sdk.capture.observeAndPruneBundles
import com.twinskin.sdk.capture.sweepLeftoverBundles
import com.twinskin.sdk.capture.STALE_SDK_CAPTURE_DB_WINDOW_MS
import com.twinskin.sdk.capture.systemDevicePlatformInfo
import com.twinskin.sdk.db.DatabaseDriverFactory
import com.twinskin.sdk.db.TwinSkinDatabaseHolder
import com.twinskin.sdk.sdk_client.MutableSdkAuthorizationProvider
import com.twinskin.sdk.sdk_client.SdkServerClient
import com.twinskin.sdk.sdk_client.sdkCaptureUrlResolver
import com.twinskin.sdk.storage.AndroidSdkStorage
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.transfer.AndroidFileTransferProvider
import com.twinskin.sdk.transfer.AndroidZipEngine
import com.twinskin.sdk.transfer.TransferManager
import com.twinskin.sdk.view.STALE_VIEW_CAPTURE_WINDOW_MS
import com.twinskin.sdk.view.cleanupStaleViewCaptureFiles
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Android entry point. Call exactly once from [Application.onCreate].
 *
 * WorkManager uses its default ContentProvider auto-initializer; the SDK's workers
 * (`UploadWorker`, `DownloadWorker`) fetch their dependencies from [TwinSkinSdk] at
 * `doWork` time, so no custom [androidx.work.WorkerFactory] registration is needed
 * and the host app is free to configure WorkManager however it wants.
 */
public fun TwinSkinSdk.initialize(app: Application, config: TwinSkinConfig) {
    if (reconcileRepeatInitialize(config) != null) return
    DatabaseDriverFactory.init(app)
    val database = TwinSkinDatabaseHolder.acquire(DatabaseDriverFactory("twinskin_transfers.db"))
    val store = SdkCaptureStore(database)
    // SupervisorJob so a failing child (e.g. a crashed recovery sweep) doesn't
    // cancel the whole scope and silently brick subsequent captures.
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val logger = config.effectiveLogger
    val authProvider = MutableSdkAuthorizationProvider(config.authorizationProvider)
    val serverClient = SdkServerClient(
        baseUrl = config.baseUrl,
        publishableKey = config.publishableKey,
        auth = authProvider,
        logger = logger,
    )
    com.twinskin.sdk.transfer.UploadDiagnostics(database).publishIn(scope, serverClient)
    val resolver = sdkCaptureUrlResolver(store, serverClient, logger)

    val zipEngine = AndroidZipEngine()
    val transferManager = TransferManager(
        database = database,
        provider = AndroidFileTransferProvider(app),
        zipEngine = zipEngine,
        scope = scope,
    )
    val storage = AndroidSdkStorage(app)

    val uiReplayContinuations = UIReplayContinuationOutbox(
        directory = { storage.dir(Purpose.UIReplayContinuations) },
        encryptor = BundleEncryptor(captureEncryptionPublicKeyDer()),
        store = store,
        transfers = transferManager,
        client = serverClient,
        database = database,
        logger = logger,
    )

    val captureApi = CaptureApi(
        transferManager = transferManager,
        encryptor = BundleEncryptor(captureEncryptionPublicKeyDer()),
        store = store,
        sdkVersion = "android",
        devicePlatformInfo = systemDevicePlatformInfo(),
        encryptedBundlePath = { captureId ->
            "${storage.dir(Purpose.EncryptedBundles)}/sdk-capture-$captureId.bin"
        },
        workingDirForSession = { captureId ->
            "${storage.dir(Purpose.CaptureWorking)}/$captureId"
        },
        scope = scope,
        serverClient = serverClient,
        devMode = config.devMode,
        demoCacheDir = { storage.dir(Purpose.DemoCache) },
        captureMode = config.effectiveCaptureMode,
        debugBundlePaddingBytes = config.effectiveDebugBundlePaddingBytes,
        logger = logger,
        uiReplayContinuations = uiReplayContinuations,
    )

    val serverCaptureSource = ServerCaptureSource(
        scope = scope,
        baseUrl = config.baseUrl,
        authProvider = authProvider,
        powerSyncFactory = AndroidPowerSyncClientFactory(app, scope, logger),
        logger = logger,
    )

    // Row-less bundles are leftovers only while no capture can be writing one,
    // which stops being true once the component is installed.
    sweepLeftoverBundles(storage, database, logger)

    val installed = install(
        TwinSkinSdkComponent(
            captureApi = captureApi,
            transferManager = transferManager,
            serverClient = serverClient,
            store = store,
            database = database,
            urlResolver = resolver,
            zipEngine = zipEngine,
            storage = storage,
            captureObserver = DefaultCaptureObserver(store, serverCaptureSource),
            logger = logger,
            devMode = config.devMode,
            verboseFrameLogs = config.verboseFrameLogs,
            captureMode = config.effectiveCaptureMode,
            locale = config.locale,
            authProvider = authProvider,
        ),
    )
    if (!installed) {
        // Lost a concurrent first-initialize race: another thread's component
        // won the CAS while this one was building. Apply this call's config to
        // the winner instead of silently dropping it, and discard this build
        // without running its side effects.
        scope.cancel()
        reconcileRepeatInitialize(config)
        return
    }

    logger.info(
        "TwinSkin SDK initialized: baseUrl=${config.baseUrl}, " +
            "captureMode=${config.effectiveCaptureMode}, devMode=${config.devMode}, " +
            "logLevel=${config.effectiveLogLevel}, verboseFrameLogs=${config.verboseFrameLogs}",
    )

    // Heal orphan captures (SdkCaptureUpload rows without a TransferTask — app
    // died between store.insert and transferManager.upload) then re-kick ACTIVE/
    // PENDING transfers from a previous process.
    captureApi.launchRecoveryAll()
    scope.launch { uiReplayContinuations.run() }

    scope.launch(Dispatchers.IO) {
        cleanupStaleSdkCaptureDbs(storage, STALE_SDK_CAPTURE_DB_WINDOW_MS, logger)
    }
    scope.launch(Dispatchers.IO) {
        cleanupStaleViewCaptureFiles(storage, STALE_VIEW_CAPTURE_WINDOW_MS, logger)
    }
    scope.launch(Dispatchers.IO) {
        observeAndPruneBundles(storage, transferManager, store, logger)
    }
    scope.launch(Dispatchers.IO) {
        BundleReleaseConfirmer(store, serverClient, transferManager, bundleSizeIn(storage), logger).run()
    }
}
