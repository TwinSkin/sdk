package com.twinskin.sdk.capture

/**
 * Lifecycle of a single capture, from creation through server-side analysis.
 *
 * The happy path is `Idle → Uploading → Uploaded → Analyzing → Succeeded`, with `Cancelled`
 * and `Failed` as terminal sinks reachable from any live state. Bundle-packing and encryption
 * are implementation details collapsed into [Uploading]; the SDK intentionally does not
 * surface them to integrators.
 *
 * Post-[Uploaded] variants ([Analyzing], [Succeeded], [Failed] with [FailureStage.Server])
 * only ever emit when a capture is observed via server-aware APIs — i.e. a
 * [CaptureObserver.observeSubject] collector that successfully opened a PowerSync
 * connection. A pure [CaptureObserver.observePendingUploads] subscriber sees [Uploaded]
 * as terminal.
 */
public sealed class CaptureState {
    /** Session created; still awaiting [CaptureSession.submit]. */
    public data object Idle : CaptureState()

    /**
     * The capture is being prepared on-device and uploaded to the server. Covers
     * bundle-packing, encryption, and the network transfer. [progressPercent] mirrors
     * the byte-level upload progress once the transfer is running; it is `null` while
     * the bundle is still being packed/encrypted (no meaningful fraction to report).
     */
    public data class Uploading(val progressPercent: Int?) : CaptureState()

    /** Upload completed successfully; the bundle is on the server. */
    public data object Uploaded : CaptureState()

    /**
     * Server has picked up the bundle and is running its analysis pipeline
     * (decrypt → construct → preview). Step-level breakdowns are intentionally
     * not exposed — integrators only see "server is working on it".
     */
    public data object Analyzing : CaptureState()

    /** Server pipeline finished and the capture's results are ready to view. */
    public data object Succeeded : CaptureState()

    /**
     * Terminal failure. [stage] distinguishes an on-device upload failure from a
     * server-side pipeline failure so the integrator can choose the right retry /
     * support path. [message] is the best available diagnostic.
     */
    public data class Failed(val stage: FailureStage, val message: String?) : CaptureState()

    /** Cancelled by the host. Any in-flight transfer is cancelled too. */
    public data object Cancelled : CaptureState()
}

/**
 * Coarse failure origin. Kept deliberately small — pipeline internals
 * (decrypt / construct / preview) are not exposed to integrators.
 */
public enum class FailureStage {
    /** Failure during on-device bundling, encryption, or upload. */
    Upload,

    /** Failure during server-side analysis. */
    Server,
}
