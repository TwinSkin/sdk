// GENERATED CODE — DO NOT EDIT BY HAND
// Source: lib/src/sdk_apis/upload/api.dart
// Regenerate: fvm dart run tool/generate_kotlin_sdk_client.dart

package com.twinskin.sdk.sdk_client

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonClassDiscriminator
import kotlinx.serialization.json.JsonElement

internal class SdkUploadClient(
    private val client: HttpClient,
    private val basePath: String,
) {
    /**
     * Starts a capture and returns a short-lived upload URL the SDK uses to
     * upload the capture bundle. Processing and results are delivered
     * asynchronously via the `capture.updated` webhook and the status endpoint.
     * 
     * Send exactly one of `analysis` and `condition_type`. `condition_type` is
     * the older form: the server derives the analysis from it, outlining every
     * condition but `generic`.
     * 
     * With `upload_layout`, the bundle goes up as a multipart upload of the
     * parts it declares. The answer then carries an upload session, whatever
     * the capture's status, and never an upload URL. The layout is stored at
     * the first call that sends one; a later call must send the same.
     */
    suspend fun startCapture(request: StartCaptureRequest): StartCaptureResponse =
        client.post("$basePath/upload/start-capture") {
            contentType(ContentType.Application.Json)
            setBody(request)
        }.body()

    /**
     * Answers whether the SDK may delete its local copy of the capture
     * bundle. The device keeps the encrypted bundle until this returns
     * `released: true`, so a lost or corrupted upload can still be retried
     * from the phone. Released once the bundle is in S3, its size matches,
     * and the decrypt step has read it. Read-only and idempotent.
     * 
     * `POST /upload/confirm-bundle`
     */
    suspend fun confirmBundle(request: ConfirmBundleRequest): ConfirmBundleResponse =
        client.post("$basePath/upload/confirm-bundle") {
            contentType(ContentType.Application.Json)
            setBody(request)
        }.body()

    /**
     * Stores a bounded client upload event separately from the sealed capture bundle.
     */
    suspend fun recordUploadDiagnostic(request: RecordUploadDiagnosticRequest): Boolean =
        client.post("$basePath/upload/record-upload-diagnostic") {
            contentType(ContentType.Application.Json)
            setBody(request)
        }.body()

    suspend fun requestUiReplayContinuationUpload(request: RequestUiReplayContinuationUploadRequest): UiReplayContinuationUploadResponse =
        client.post("$basePath/upload/request-ui-replay-continuation-upload") {
            contentType(ContentType.Application.Json)
            setBody(request)
        }.body()

    suspend fun confirmUiReplayContinuation(request: ConfirmUiReplayContinuationRequest): Boolean =
        client.post("$basePath/upload/confirm-ui-replay-continuation") {
            contentType(ContentType.Application.Json)
            setBody(request)
        }.body()

    /**
     * Submits an annotation (region polygons on the reference image) for a
     * capture and starts a new measurement revision.
     * 
     * `POST /upload/submit-annotation`
     * 
     * `annotation` is discriminated by `type` (`wound` | `generic`) and must
     * match the capture's `condition_type`, else the call is rejected. Each
     * call allocates a fresh revision and supersedes any still-measuring one;
     * a `capture.updated` webhook fires when the result is ready.
     */
    suspend fun submitAnnotation(request: SubmitAnnotationRequest): SubmitAnnotationResponse =
        client.post("$basePath/upload/submit-annotation") {
            contentType(ContentType.Application.Json)
            setBody(request)
        }.body()
}

@Serializable
internal data class StartCaptureRequest(
    @SerialName("user_ref") val userRef: String,
    @SerialName("subject_ref") val subjectRef: String,
    @SerialName("condition_type") val conditionType: String? = null,
    @SerialName("analysis") val analysis: SdkAnalysis? = null,
    @SerialName("capture_id") val captureId: String? = null,
    @SerialName("capture_group") val captureGroup: String? = null,
    @SerialName("body_location") val bodyLocation: List<String>? = null,
    @SerialName("custom") val custom: Map<String, JsonElement>? = null,
    @SerialName("device_info") val deviceInfo: DeviceInfo? = null,
    @SerialName("upload_layout") val uploadLayout: SdkUploadLayout? = null
)

@Serializable
internal data class ConfirmBundleRequest(
    @SerialName("user_ref") val userRef: String,
    @SerialName("subject_ref") val subjectRef: String,
    @SerialName("capture_id") val captureId: String,
    @SerialName("bundle_size_bytes") val bundleSizeBytes: Long
)

@Serializable
internal data class RecordUploadDiagnosticRequest(
    @SerialName("user_ref") val userRef: String,
    @SerialName("subject_ref") val subjectRef: String,
    @SerialName("capture_id") val captureId: String,
    @SerialName("event_json") val eventJson: String
)

@Serializable
internal data class RequestUiReplayContinuationUploadRequest(
    @SerialName("user_ref") val userRef: String,
    @SerialName("subject_ref") val subjectRef: String,
    @SerialName("capture_id") val captureId: String,
    @SerialName("trace_id") val traceId: String,
    @SerialName("cipher_sha_256") val cipherSha256: String,
    @SerialName("bundle_size_bytes") val bundleSizeBytes: Long
)

@Serializable
internal data class ConfirmUiReplayContinuationRequest(
    @SerialName("user_ref") val userRef: String,
    @SerialName("subject_ref") val subjectRef: String,
    @SerialName("capture_id") val captureId: String,
    @SerialName("trace_id") val traceId: String,
    @SerialName("cipher_sha_256") val cipherSha256: String,
    @SerialName("bundle_size_bytes") val bundleSizeBytes: Long
)

@Serializable
internal data class SubmitAnnotationRequest(
    @SerialName("capture_id") val captureId: String,
    @SerialName("annotation") val annotation: SdkAnnotation
)

/**
 * Response from `startCapture`.
 * 
 * Idempotent when the client supplies its own `capture_id`: a repeat call
 * returns the capture's current status. Without an upload layout in the
 * request, [uploadUrl] is present only while the capture is `queued`. With
 * one, [uploadSession] is always present and [uploadUrl] never is.
 */
@Serializable
internal data class StartCaptureResponse(
    /**
     * Unique capture identifier. Format: `tsc_<id>`.
     */
    @SerialName("capture_id") val captureId: String,
    /**
     * Current status of the capture.
     */
    @SerialName("status") val status: SdkCaptureStatus,
    /**
     * Short-lived upload URL for the capture bundle (HTTP PUT). Present only
     * when [status] is `queued` and the request carried no upload layout;
     * null once a bundle has been received.
     */
    @SerialName("upload_url") val uploadUrl: String? = null,
    /**
     * Expiry of [uploadUrl]. Present when [uploadUrl] is.
     */
    @SerialName("upload_url_expires_at") val uploadUrlExpiresAt: String? = null,
    /**
     * The credential for this capture's upload session. Present when the
     * request carried an upload layout, whatever the capture's status.
     */
    @SerialName("upload_session") val uploadSession: SdkUploadSession? = null
)

/**
 * How the pipeline processes a capture: which condition it is, and the
 * parameters that condition's pipeline takes. Discriminated by `type`, whose
 * values are the `condition_type` values the SDK publishes.
 */
@Serializable
@JsonClassDiscriminator("type")
internal sealed class SdkAnalysis

/**
 * A wound: outlined with its tissues.
 */
@Serializable
@SerialName("wound")
internal data class SdkWoundAnalysis(
    /**
     * Whether the server proposes the outline. When false, the outline is
     * submitted later with `submitAnnotation`.
     */
    @SerialName("auto_outline") val autoOutline: Boolean
) : SdkAnalysis()

/**
 * A scar: outlined as regions, without tissues.
 */
@Serializable
@SerialName("scar")
internal data class SdkScarAnalysis(
    /**
     * Whether the server proposes the outline. When false, the outline is
     * submitted later with `submitAnnotation`.
     */
    @SerialName("auto_outline") val autoOutline: Boolean
) : SdkAnalysis()

/**
 * Anything without a model: the 3D model, and regions submitted later with
 * `submitAnnotation`.
 */
@Serializable
@SerialName("generic")
internal data object SdkGenericAnalysis : SdkAnalysis()

/**
 * Device metadata collected by the mobile SDK. All fields optional so
 * older SDK builds keep working.
 */
@Serializable
internal data class DeviceInfo(
    /**
     * `"android"` or `"ios"`.
     */
    @SerialName("os") val os: String? = null,
    /**
     * OS version, e.g. `"14.2"`.
     */
    @SerialName("os_version") val osVersion: String? = null,
    /**
     * e.g. `"Google"`, `"Apple"`, `"Samsung"`.
     */
    @SerialName("device_manufacturer") val deviceManufacturer: String? = null,
    /**
     * Platform model identifier, e.g. `"Pixel 6a"`, `"iPhone15,3"`.
     */
    @SerialName("device_model") val deviceModel: String? = null,
    /**
     * SDK version, e.g. `"1.4.2"`.
     */
    @SerialName("sdk_version") val sdkVersion: String? = null,
    /**
     * Integrator app version, e.g. `"3.7.1"`.
     */
    @SerialName("app_version") val appVersion: String? = null,
    /**
     * Integrator app bundle id / package name, e.g. `"com.acme.skinapp"`.
     */
    @SerialName("app_bundle_id") val appBundleId: String? = null,
    /**
     * BCP 47 language tag, e.g. `"en-US"`.
     */
    @SerialName("locale") val locale: String? = null
)

/**
 * How the SDK sealed a capture's bundle: the parts of one S3 multipart
 * upload. Every part but the last holds [partSizeBytes] bytes; the last one
 * holds the rest.
 */
@Serializable
internal data class SdkUploadLayout(
    /**
     * Size of the whole bundle, in bytes.
     */
    @SerialName("bundle_size_bytes") val bundleSizeBytes: Long,
    /**
     * Size of every part but the last, in bytes.
     */
    @SerialName("part_size_bytes") val partSizeBytes: Long
)

/**
 * Response of `POST /upload/confirm-bundle`.
 */
@Serializable
internal data class ConfirmBundleResponse(
    /**
     * The capture the answer is about. Format: `tsc_<id>`.
     */
    @SerialName("capture_id") val captureId: String,
    /**
     * True once the server holds an intact copy of the bundle and the SDK
     * may delete the one on the device.
     */
    @SerialName("released") val released: Boolean,
    /**
     * Why the device must keep its bundle, when [released] is false. One of
     * the `BundleHoldReason` values. New values may be added; an unknown one
     * means "keep".
     */
    @SerialName("hold_reason") val holdReason: String? = null
)

@Serializable
internal data class UiReplayContinuationUploadResponse(
    @SerialName("received") val received: Boolean,
    @SerialName("upload_url") val uploadUrl: String? = null,
    @SerialName("upload_url_expires_at") val uploadUrlExpiresAt: String? = null
)

/**
 * Response from `submitAnnotation`.
 */
@Serializable
internal data class SubmitAnnotationResponse(
    /**
     * 1-based, monotonically increasing per capture.
     */
    @SerialName("revision") val revision: Long
)

@Serializable
@JsonClassDiscriminator("type")
public sealed class SdkAnnotation

@Serializable
@SerialName("generic")
public data class GenericAnnotation(
    @SerialName("regions") val regions: List<GenericRegion>
) : SdkAnnotation()

@Serializable
@SerialName("wound")
public data class WoundAnnotation(
    @SerialName("regions") val regions: List<WoundRegion>
) : SdkAnnotation()

@Serializable
internal enum class SdkCaptureStatus {
    @SerialName("queued") Queued,
    @SerialName("in_progress") InProgress,
    @SerialName("completed") Completed,
    @SerialName("failed") Failed;
}

/**
 * A credential for one capture's upload. It authenticates the
 * `upload-session` endpoints for that capture, and nothing else.
 */
@Serializable
internal data class SdkUploadSession(
    /**
     * Sent as `Authorization: Bearer <credential>`, with the
     * `X-Publishable-Key` header.
     */
    @SerialName("credential") val credential: String,
    /**
     * Seconds until [credential] expires. A duration rather than a time, so a
     * device whose clock is wrong still knows when to ask for a new one.
     */
    @SerialName("expires_in_seconds") val expiresInSeconds: Long
)

@Serializable
public data class GenericRegion(
    @SerialName("points") val points: List<Point2D>
)

@Serializable
public data class WoundRegion(
    @SerialName("contour") val contour: List<Point2D>,
    @SerialName("tissues") val tissues: List<TissueRegion>
)

@Serializable
public data class Point2D(
    @SerialName("x") val x: Double,
    @SerialName("y") val y: Double
)

@Serializable
public data class TissueRegion(
    @SerialName("tissue_type") val tissueType: String,
    @SerialName("contour") val contour: List<Point2D>
)
