package com.twinskin.sdk.geometry

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.PathSegment
import kotlin.math.absoluteValue

/**
 * Converts a closed polygon (vertex list) to a Compose [Path]. Walks
 * the vertices in order, closing the path at the end.
 *
 * Empty/degenerate input returns an empty [Path].
 */
internal fun polygonToPath(poly: List<Offset>): Path {
    val path = Path()
    if (poly.isEmpty()) return path
    path.moveTo(poly[0].x, poly[0].y)
    for (i in 1 until poly.size) {
        path.lineTo(poly[i].x, poly[i].y)
    }
    path.close()
    return path
}

/**
 * Splits [path] into one polygon per sub-path by walking the verb
 * stream via [Path.iterator].
 *
 *  - `Move` finalises the in-flight sub-path and starts a new one.
 *  - `Line`/`Quadratic`/`Conic`/`Cubic` append their end point. Curves,
 *    if present, are linearised end-only. For boolean-op results
 *    between polygons both Android and Skia emit lines, so this is the
 *    common case; downstream callers re-densify so any coarseness
 *    introduced by a stray curve is absorbed.
 *  - `Close`/`Done` finalise the in-flight sub-path.
 *
 * Sub-paths with fewer than 3 distinct vertices are dropped — they're
 * artifacts of degenerate booleans, not real polygons.
 *
 * Returned sub-paths may or may not carry a trailing duplicate of the
 * first vertex depending on which `Path` backend emitted the verb
 * stream (Android's native `Path` and Skia's `SkPath` differ here).
 * Consumers should treat each list as logically closed and not rely on
 * a specific length — area, point-in-polygon, and the boolean
 * primitives are all robust to a duplicated final vertex.
 */
internal fun pathToPolygons(path: Path): List<List<Offset>> {
    val out = mutableListOf<List<Offset>>()
    var current: MutableList<Offset>? = null

    fun finalise() {
        val c = current
        if (c != null && c.size >= 3) out += c.toList()
        current = null
    }

    fun appendEnd(seg: PathSegment, xIdx: Int, yIdx: Int) {
        val end = Offset(seg.points[xIdx], seg.points[yIdx])
        val start = Offset(seg.points[0], seg.points[1])
        val c = current ?: mutableListOf<Offset>().also { it.add(start); current = it }
        c.appendUnique(end)
    }

    for (seg in path.iterator()) {
        when (seg.type) {
            PathSegment.Type.Move -> {
                finalise()
                current = mutableListOf(Offset(seg.points[0], seg.points[1]))
            }
            PathSegment.Type.Line -> appendEnd(seg, 2, 3)
            PathSegment.Type.Quadratic -> appendEnd(seg, 4, 5)
            PathSegment.Type.Conic -> appendEnd(seg, 4, 5)
            PathSegment.Type.Cubic -> appendEnd(seg, 6, 7)
            PathSegment.Type.Close, PathSegment.Type.Done -> finalise()
        }
    }
    finalise()
    return out
}

private fun MutableList<Offset>.appendUnique(p: Offset) {
    if (isEmpty() || (last() - p).getDistanceSquared() > 1e-6f) add(p)
}

/**
 * Boolean intersect — `a ∩ b`. Returns `null` when the backend's
 * `Path.op` bails (pathological inputs — self-intersection, NaN, etc.);
 * callers must treat that as a failure rather than an empty path.
 */
internal fun intersect(a: Path, b: Path): Path? = booleanOp(a, b, PathOperation.Intersect)

/** Boolean union — `a ∪ b`. `null` on backend failure. */
internal fun union(a: Path, b: Path): Path? = booleanOp(a, b, PathOperation.Union)

/** Boolean difference — `a \ b`. `null` on backend failure. */
internal fun difference(a: Path, b: Path): Path? = booleanOp(a, b, PathOperation.Difference)

private fun booleanOp(a: Path, b: Path, op: PathOperation): Path? {
    val result = Path()
    return if (result.op(a, b, op)) result else null
}

/**
 * Net area of [path] accounting for polygon-with-hole topology.
 * Sub-paths classified by [classifyRings]: outer areas are added,
 * hole areas subtracted. Falls back to 0 when floating noise
 * produces a tiny negative.
 */
internal fun pathArea(path: Path): Float {
    val polys = pathToPolygons(path)
    if (polys.isEmpty()) return 0f
    val holes = classifyRings(polys)
    var area = 0f
    for (i in polys.indices) {
        val absArea = signedArea(polys[i]).absoluteValue
        area += if (holes[i]) -absArea else absArea
    }
    return area.coerceAtLeast(0f)
}

/**
 * Classifies each ring of a multi-sub-path boolean-op result as a hole
 * (`true`) or a filled outer ring (`false`), by containment-depth
 * parity: a ring nested inside an even number of other rings is an
 * outer (fillable) ring, odd means hole. `Path.op` encodes
 * polygon-with-holes as sibling sub-paths and orientation isn't a
 * stable contract across backends, so containment is the only reliable
 * signal.
 *
 * Containment of ring `i` in ring `j` is decided by a majority vote of
 * up to five evenly-sampled vertices of `i` tested against `j` — NOT
 * the centroid. A ring's vertices always lie on the ring itself, so
 * for the disjoint rings booleans emit they sit strictly inside or
 * outside any other ring; a centroid, by contrast, needn't lie inside
 * its own (concave) ring and lands inside a sibling hole whenever the
 * user's tissues sit at the wound's center — the failure mode this
 * replaces. The vote absorbs the occasional vertex falling exactly on
 * a coincident boundary (tissue drawn up against the wound contour),
 * where ray-casting is undefined.
 */
internal fun classifyRings(polys: List<List<Offset>>): List<Boolean> {
    val boxes = polys.map { bbox(it) }
    return polys.indices.map { i ->
        var depth = 0
        for (j in polys.indices) {
            if (j == i) continue
            if (!bboxStrictlyContains(boxes[j], boxes[i])) continue
            if (ringInsideRing(polys[i], polys[j])) depth++
        }
        depth % 2 == 1
    }
}

private fun ringInsideRing(inner: List<Offset>, outer: List<Offset>): Boolean {
    val samples = minOf(5, inner.size)
    if (samples == 0) return false
    var inside = 0
    for (k in 0 until samples) {
        val v = inner[k * inner.size / samples]
        if (pointInPolygon(v, outer)) inside++
    }
    return inside * 2 > samples
}

/**
 * True when any two non-adjacent edges of the closed polygon [poly]
 * properly cross. Proper crossings only — a vertex merely touching
 * another edge doesn't count, so densified near-collinear outlines
 * (and duplicated closing vertices) don't false-positive. O(n²).
 */
internal fun hasSelfIntersection(poly: List<Offset>): Boolean {
    val n = poly.size
    if (n < 4) return false
    for (i in 0 until n) {
        val a = poly[i]
        val b = poly[(i + 1) % n]
        for (j in i + 2 until n) {
            // The wrap pair (0, n-1) is adjacent — shares poly[0].
            if (i == 0 && j == n - 1) continue
            if (segmentsProperlyCross(a, b, poly[j], poly[(j + 1) % n])) return true
        }
    }
    return false
}

private fun segmentsProperlyCross(a: Offset, b: Offset, c: Offset, d: Offset): Boolean {
    val d1 = orient(c, d, a)
    val d2 = orient(c, d, b)
    val d3 = orient(a, b, c)
    val d4 = orient(a, b, d)
    return ((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) &&
        ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))
}

private fun orient(a: Offset, b: Offset, c: Offset): Double =
    (b.x - a.x).toDouble() * (c.y - a.y).toDouble() -
        (b.y - a.y).toDouble() * (c.x - a.x).toDouble()

/**
 * Normalizes a self-intersecting (bow-tie) polygon into a simple one.
 * Fast path: returns [poly] itself (same instance — callers identity-
 * check to skip follow-up work) when no non-adjacent edges cross.
 * Repair: self-union under nonZero fill splits the ring at its
 * crossings; the largest non-hole ring by |area| is kept. Any
 * null/empty from the boolean backend returns the original [poly] —
 * a backend bail must never lose user geometry.
 */
internal fun repairSelfIntersecting(poly: List<Offset>): List<Offset> {
    if (!hasSelfIntersection(poly)) return poly
    val unioned = union(polygonToPath(poly), polygonToPath(poly)) ?: return poly
    val rings = pathToPolygons(unioned)
    if (rings.isEmpty()) return poly
    val holes = classifyRings(rings)
    var best: List<Offset>? = null
    var bestArea = 0f
    for (i in rings.indices) {
        if (holes[i]) continue
        val area = signedArea(rings[i]).absoluteValue
        if (area > bestArea) {
            bestArea = area
            best = rings[i]
        }
    }
    return best ?: poly
}

private fun bboxStrictlyContains(outer: androidx.compose.ui.geometry.Rect, inner: androidx.compose.ui.geometry.Rect): Boolean {
    if (outer.left > inner.left) return false
    if (outer.top > inner.top) return false
    if (outer.right < inner.right) return false
    if (outer.bottom < inner.bottom) return false
    // At least one dimension must be strictly larger so equal-bbox
    // polygons (e.g. duplicates) aren't mutually classified as holes.
    return outer.left < inner.left ||
        outer.top < inner.top ||
        outer.right > inner.right ||
        outer.bottom > inner.bottom
}
