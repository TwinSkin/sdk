package com.twinskin.sdk.capture

import com.twinskin.sdk.sdk_client.SdkAnalysis
import com.twinskin.sdk.sdk_client.SdkGenericAnalysis
import com.twinskin.sdk.sdk_client.SdkScarAnalysis
import com.twinskin.sdk.sdk_client.SdkStartCaptureRequest
import com.twinskin.sdk.sdk_client.SdkWoundAnalysis

/**
 * How the server processes a capture: which condition it is, and the
 * parameters that condition's pipeline takes.
 *
 * Every capture uploads and gets its 3D model. Where the outline comes from
 * depends on the analysis: the server proposes it when [Wound.autoOutline]
 * or [Scar.autoOutline] is true; otherwise it is drawn later, with
 * `TwinSkin.editAnnotation`, by whoever has access to the capture.
 */
public sealed class Analysis {
    /** A wound: outlined with its tissues. */
    public data class Wound(val autoOutline: Boolean = true) : Analysis()

    /** A scar: outlined as regions, without tissues. */
    public data class Scar(val autoOutline: Boolean = true) : Analysis()

    /** Anything without a model: the 3D model, and regions drawn later. */
    public data object Generic : Analysis()
}

internal val Analysis.conditionType: ConditionType
    get() = when (this) {
        is Analysis.Wound -> ConditionType.Wound
        is Analysis.Scar -> ConditionType.Scar
        Analysis.Generic -> ConditionType.Generic
    }

internal fun Analysis.toWire(): SdkAnalysis = when (this) {
    is Analysis.Wound -> SdkWoundAnalysis(autoOutline = autoOutline)
    is Analysis.Scar -> SdkScarAnalysis(autoOutline = autoOutline)
    Analysis.Generic -> SdkGenericAnalysis
}

/** The analysis a capture started with only a [ConditionType] gets. */
internal val ConditionType.analysis: Analysis
    get() = when (this) {
        ConditionType.Wound -> Analysis.Wound()
        ConditionType.Scar -> Analysis.Scar()
        ConditionType.Generic -> Analysis.Generic
    }

/** The condition a start-capture request names, by its analysis or its condition type. */
internal val SdkStartCaptureRequest.conditionTypeOrNull: ConditionType?
    get() = when (analysis) {
        is SdkWoundAnalysis -> ConditionType.Wound
        is SdkScarAnalysis -> ConditionType.Scar
        SdkGenericAnalysis -> ConditionType.Generic
        null -> parseConditionTypeOrNull(conditionType)
    }
