@file:OptIn(TwinSkinInternalApi::class)

package com.twinskin.sdk.capture

import com.twinskin.sdk.CaptureMode
import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.debug
import com.twinskin.sdk.info
import com.twinskin.sdk.warn
import com.twinskin.sdk.capture.crypto.secureRandomBytes
import com.twinskin.sdk.capture.fallback.VideoCaptureResult
import com.twinskin.sdk.capture.fallback.VideoMetaData
import com.twinskin.sdk.capture.fallback.VideoMetaDataJson
import com.twinskin.sdk.capture.io.ByteSink
import com.twinskin.sdk.capture.io.deleteDirQuietly
import com.twinskin.sdk.capture.io.deleteFileQuietly
import com.twinskin.sdk.capture.io.ensureDir
import com.twinskin.sdk.capture.io.fileExists
import com.twinskin.sdk.capture.io.fileSize
import com.twinskin.sdk.capture.io.readFileStreaming
import com.twinskin.sdk.capture.io.writeBytes
import com.twinskin.sdk.devcapture.DemoCaptureException
import com.twinskin.sdk.devcapture.DemoCaptureRepository
import com.twinskin.sdk.devcapture.DemoDownload
import com.twinskin.sdk.sdk_client.SdkDeviceInfo
import com.twinskin.sdk.sdk_client.SdkServerClient
import com.twinskin.sdk.transfer.TransferManager
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.currentTimeMillis
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive

/** Tar entry name for the dev/test upload-padding blob; never referenced by the manifest. */
private const val DEBUG_PADDING_ENTRY = "debug_padding.bin"

private const val PADDING_CHUNK_BYTES = 256 * 1024

/**
 * Orchestrates the capture pipeline: build tar → encrypt → persist → hand off to
 * [TransferManager].
 *
 * ## Persistence + idempotent URL refresh
 *
 * Once a bundle is on disk, a row is written to [SdkCaptureStore] carrying every
 * field needed to re-call `POST /api/sdk/upload/start-capture`. The server endpoint
 * is idempotent on a client-supplied `capture_id`, so the `UrlResolver` passed to
 * the [TransferManager] can always obtain a fresh presigned PUT URL without the SDK
 * having to track expiry itself.
 *
 * The store row is deliberately written *after* encryption (data minimization:
 * nothing is persisted until the bundle exists on disk) and deleted only on
 * terminal success — recovery sweeps read `PENDING_UPLOAD` rows on startup to
 * re-enqueue interrupted uploads.
 */
internal class CaptureApi(
    private val transferManager: TransferManager,
    private val encryptor: BundleEncryptor,
    private val store: SdkCaptureStore,
    private val sdkVersion: String,
    private val devicePlatformInfo: DevicePlatformInfo,
    private val encryptedBundlePath: (captureId: String) -> String,
    private val workingDirForSession: (captureId: String) -> String,
    private val scope: CoroutineScope,
    /**
     * Optional — only required by the devMode demo-capture entry points.
     * Tests that don't exercise demo flows can leave this null.
     */
    private val serverClient: SdkServerClient? = null,
    private val devMode: Boolean = false,
    /**
     * Absolute path to the persistent demo-capture cache root. Only
     * consulted by the devMode demo-capture entry points; required iff
     * [devMode] is `true` and the caller invokes [submitDemoCapture] /
     * [listDemoCaptures]. Tests that don't exercise demo flows can
     * leave this null.
     */
    private val demoCacheDir: (() -> String)? = null,
    private val clock: () -> Long = ::currentTimeMillis,
    private val idGenerator: () -> String = ::randomCaptureId,
    /**
     * The [CaptureMode] this SDK instance was initialized with — the
     * default `sessionMode` for [startCapture] calls that carry no
     * per-capture override.
     */
    private val captureMode: CaptureMode = CaptureMode.AccelerometerCapture,
    /**
     * Dev/test seam: bytes of padding to append as a trailing
     * `debug_padding.bin` tar entry, gated on [devMode]. Read once per submit.
     * `{ 0 }` in production — see [com.twinskin.sdk.TwinSkinConfig.debugBundlePaddingBytesProvider].
     */
    private val debugBundlePaddingBytes: () -> Long = { 0L },
    private val logger: SdkLogger = SdkLogger.None,
    private val uiReplayContinuations: UIReplayContinuationOutbox? = null,
) {
    private val sessions = mutableMapOf<String, SessionEntry>()

    internal suspend fun submitUIReplayContinuation(session: CaptureSession, traceId: String, directoryPath: String): String =
        withContext(Dispatchers.Default) {
            (uiReplayContinuations ?: error("Interface replay continuation transport is unavailable"))
                .submit(session, traceId, directoryPath)
        }

    private val deviceInfoSnapshot: SdkDeviceInfo by lazy {
        SdkDeviceInfo(
            os = devicePlatformInfo.os,
            osVersion = devicePlatformInfo.osVersion,
            deviceManufacturer = devicePlatformInfo.deviceManufacturer,
            deviceModel = devicePlatformInfo.deviceModel,
            sdkVersion = sdkVersion,
            appVersion = devicePlatformInfo.appVersion,
            appBundleId = devicePlatformInfo.appBundleId,
            locale = devicePlatformInfo.locale,
        )
    }

    private class SessionEntry(
        val session: CaptureSession,
        var mirrorJob: Job? = null,
        var transferTaskId: String? = null,
    )

    /**
     * Write [totalBytes] into [sink] from a single reused buffer, so the
     * footprint stays fixed regardless of the padding size.
     */
    private fun writePadding(sink: ByteSink, totalBytes: Long) {
        val buf = ByteArray(PADDING_CHUNK_BYTES)
        secureRandomBytes(buf)
        var remaining = totalBytes
        while (remaining > 0L) {
            val n = minOf(remaining, buf.size.toLong()).toInt()
            sink.write(buf, 0, n)
            remaining -= n
        }
    }

    /**
     * Start a new capture session. The server is not called until [CaptureSession.submit]
     * hands the bundle off to the transfer manager — keeping cancelled-before-submit
     * flows free of orphan server rows.
     *
     * The per-session [CaptureSession.workingDir] is created eagerly here so the
     * native capture flow can start writing into it immediately.
     */
    fun startCapture(
        metadata: SdkCaptureMetadata,
        sessionMode: CaptureMode = captureMode,
    ): CaptureSession {
        val id = idGenerator()
        val workingDir = workingDirForSession(id)
        ensureDir(workingDir)
        val session = CaptureSession(
            id = id,
            metadata = metadata,
            captureMode = sessionMode,
            workingDir = workingDir,
            api = this,
        )
        sessions[session.id] = SessionEntry(session)
        logger.debug(
            "capture[$id] started: subjectRef=${metadata.subjectRef}, " +
                "${metadata.wireDescription}, captureMode=$sessionMode",
        )
        return session
    }

    /**
     * Bundle the captured media into an encrypted archive on disk, then hand it off to
     * the transfer manager. The full pipeline runs with a fixed-size memory footprint
     * and a single pass over each media file — bytes flow straight from disk through
     * the tar writer + chunked AES-GCM encryptor.
     *
     * [result.photoPath] and every path in [result.framePaths] must be inside
     * [CaptureSession.workingDir]; the SDK rejects paths outside that directory with
     * [IllegalArgumentException].
     */
    internal suspend fun submit(
        session: CaptureSession,
        result: CaptureResult,
        allowModeMismatch: Boolean = false,
        customOverride: Map<String, JsonElement>? = null,
    ) {
        check(session.currentState is CaptureState.Idle) {
            "Session ${session.id} already submitted (state=${session.currentState})"
        }
        requirePathInside(session.workingDir, result.photoPath, "photoPath")
        require(result.framePaths.isNotEmpty()) { "framePaths must not be empty" }
        for ((idx, framePath) in result.framePaths.withIndex()) {
            requirePathInside(session.workingDir, framePath, "framePaths[$idx]")
        }
        // The bundle/encrypt pipeline does blocking file I/O + AES-GCM work; move off
        // whatever dispatcher the caller used (often the main thread, since submit is
        // typically invoked from a Compose click handler) so the UI stays responsive.
        withContext(Dispatchers.Default) {
            submitBlocking(
                session,
                PhotosphereSubmitInput(result),
                allowModeMismatch,
                customOverride,
            )
        }
    }

    /**
     * Face-capture submit. Reuses [CaptureResult] (reference still + pose frames)
     * and produces a bundle whose layout is byte-identical to the photosphere
     * still bundle — one `ref_image.jpg`, the pose frames as `image_frames`, no
     * video — differing only in `manifest.capture_mode = "face_capture"`. Face
     * Capture ships on iOS only.
     *
     * [result.photoPath] and every path in [result.framePaths] must live inside
     * [CaptureSession.workingDir]; paths outside that directory are rejected with
     * [IllegalArgumentException].
     */
    internal suspend fun submitFace(
        session: CaptureSession,
        result: CaptureResult,
        allowModeMismatch: Boolean = false,
        customOverride: Map<String, JsonElement>? = null,
    ) {
        check(session.currentState is CaptureState.Idle ||
            (session.currentState is CaptureState.Failed && store.findById(session.id) == null)) {
            "Session ${session.id} already submitted (state=${session.currentState})"
        }
        requirePathInside(session.workingDir, result.photoPath, "photoPath")
        require(result.framePaths.isNotEmpty()) { "framePaths must not be empty" }
        for ((idx, framePath) in result.framePaths.withIndex()) {
            requirePathInside(session.workingDir, framePath, "framePaths[$idx]")
        }
        withContext(Dispatchers.Default) {
            submitBlocking(
                session,
                FaceCaptureSubmitInput(result),
                allowModeMismatch,
                customOverride,
            )
        }
    }

    /**
     * Accelerometer-capture submit overload. Builds a `capture_mode = accelerometer_capture`
     * bundle: one still photo (the Phase-1 shot), one orbit video, and a
     * `video_metadata.json` sidecar carrying the
     * [com.twinskin.sdk.capture.fallback.AccelerometerDriver] log.
     * `image_frames` is empty on this path.
     *
     * Both `result.photoPath` and `result.videoPath` must live inside
     * [CaptureSession.workingDir]; paths outside that directory are
     * rejected with [IllegalArgumentException].
     */
    internal suspend fun submit(
        session: CaptureSession,
        result: VideoCaptureResult,
        allowModeMismatch: Boolean = false,
        customOverride: Map<String, JsonElement>? = null,
    ) {
        check(session.currentState is CaptureState.Idle) {
            "Session ${session.id} already submitted (state=${session.currentState})"
        }
        requirePathInside(session.workingDir, result.photoPath, "photoPath")
        requirePathInside(session.workingDir, result.videoPath, "videoPath")
        withContext(Dispatchers.Default) {
            submitBlocking(
                session,
                AccelerometerCaptureSubmitInput(result),
                allowModeMismatch,
                customOverride,
            )
        }
    }

    /**
     * Photo-series submit: no capture screen, so it opens its own session.
     * Packs the host's stills, a copy of the frontal one as the reference, and
     * their `photo_series.json` into a `capture_mode = photo_series` bundle,
     * and hands it to the transfer manager. Returns once the bundle is on disk;
     * the stills are read, never moved or deleted.
     *
     * Throws [IllegalArgumentException], before any session exists, for a
     * series the server would refuse: no frontal still, two stills with one
     * pose and burst rank, a file that is missing. A still that is not a JPEG
     * fails the session as it is packed.
     */
    internal suspend fun submitStills(
        metadata: SdkCaptureMetadata,
        series: PhotoSeries,
    ): CaptureSession {
        requireSubmittable(series)
        // A photo series is analysed, never outlined.
        val generic = if (metadata.analysis != Analysis.Generic || metadata.conditionTypeRaw != null) {
            logger.warn("photo series: ${metadata.wireDescription} coerced to Generic")
            metadata.copy(analysis = Analysis.Generic, conditionTypeRaw = null)
        } else {
            metadata
        }
        val session = startCapture(generic, sessionMode = CaptureMode.PhotoSeries)
        val stills = series.stills.map { BundleFile(path = it.path, name = it.bundleName) }
        val sidecar = PhotoSeriesSidecar(
            stills = series.stills.map { still ->
                PhotoSeriesStill(
                    file = still.bundleName,
                    pose = still.pose,
                    burstRank = still.burstRank.toLong(),
                    deviceSharpness = still.sharpness,
                    fillLight = still.fillLight?.wireValue,
                    deviceCheck = still.deviceCheck,
                )
            },
            ipdMm = series.ipdMm,
        )
        withContext(Dispatchers.Default) {
            try {
                writeBytes(
                    "${session.workingDir.trimEnd('/')}/${CaptureBundleEntries.PHOTO_SERIES}",
                    SidecarJson.encodeToString(sidecar).encodeToByteArray(),
                )
            } catch (e: Exception) {
                fail(session, e.message ?: e::class.simpleName ?: "unknown")
                throw e
            }
            submitBlocking(
                session,
                PhotoSeriesSubmitInput(
                    stills = stills,
                    reference = series.stills
                        .filter { it.pose == PhotoSeriesPose.Frontal }
                        .minBy { it.burstRank }
                        .path,
                ),
            )
        }
        return session
    }

    private fun requireSubmittable(series: PhotoSeries) {
        require(series.stills.any { it.pose == PhotoSeriesPose.Frontal }) {
            "a photo series needs a frontal still"
        }
        val repeated = series.stills.groupingBy { it.bundleName }.eachCount().filterValues { it > 1 }
        require(repeated.isEmpty()) { "two stills share a pose and a burst rank: ${repeated.keys}" }
        for (still in series.stills) {
            require(still.burstRank >= 0) { "${still.path}: burstRank is negative" }
            require(still.sharpness?.isFinite() != false) { "${still.path}: sharpness is not finite" }
            require(fileExists(still.path)) { "${still.path} does not exist" }
        }
        require(series.ipdMm?.let { it.isFinite() && it > 0 } != false) {
            "ipdMm must be a positive distance, got ${series.ipdMm}"
        }
    }

    private suspend fun submitBlocking(
        session: CaptureSession,
        input: SubmitInput,
        allowModeMismatch: Boolean = false,
        customOverride: Map<String, JsonElement>? = null,
    ) {
        // The submit-input variant and the session's mode MUST match — a mismatch is an integrator bug.
        val effectiveCaptureMode = input.captureMode
        require(allowModeMismatch || effectiveCaptureMode == session.captureMode) {
            "submit input type ${input::class.simpleName} does not match " +
                "session.captureMode=${session.captureMode} (input " +
                "implies $effectiveCaptureMode); fix the capture-screen " +
                "code path so the two stay in lockstep"
        }
        // The native capture flow has placed photo + frames inside session.workingDir;
        // we delete the whole directory in the `finally` regardless of outcome.
        // If we crash before store.insert the encrypted bundle is orphaned on disk
        // (no row points to it, so recovery won't find it) — clean it up too.
        var encryptedPath: String? = null
        var persisted = false
        try {
            session.setState(CaptureState.Uploading(progressPercent = null))

            val workingDir = session.workingDir.trimEnd('/')
            val photoPath = input.photoPath

            // Frame filename basenames inside the bundle archive mirror the
            // platform-written file basename so HEIC sources stay HEIC inside
            // the encrypted bundle (the server-side decrypt lambda
            // normalises every frame to JPEG before downstream consumers).
            val frameFilenames: List<String> = when (input) {
                is PhotosphereSubmitInput -> input.result.framePaths.map { path ->
                    path.substringAfterLast('/').substringAfterLast('\\')
                }
                is FaceCaptureSubmitInput -> input.result.framePaths.map { path ->
                    path.substringAfterLast('/').substringAfterLast('\\')
                }
                is AccelerometerCaptureSubmitInput -> emptyList()
                is PhotoSeriesSubmitInput -> input.stills.map { it.name }
            }

            // The native capture flow drops a small number of non-image
            // companions inside `session.workingDir` next to the JPEGs:
            // `pose_log.json` (always, per-photo telemetry log) and the
            // verbose-only `frame_log.jsonl` + `reference_keypoints.json`
            // (present when `verboseFrameLogs=true`). Enumerate the
            // known names rather than scanning the directory so a stray
            // file can never sneak into the encrypted bundle.
            val hasVoiceFeedback = hasReadyVoiceFeedback(workingDir, session.id)
            if (!hasVoiceFeedback && fileExists("$workingDir/${CaptureBundleEntries.VOICE_FEEDBACK}")) {
                logger.warn("capture[${session.id}] skipped voice feedback with an invalid completion receipt")
            }
            val sidecarBasenames = CaptureBundleEntries.KNOWN_SIDECARS
                .filter { name ->
                    if (name == CaptureBundleEntries.VOICE_FEEDBACK) hasVoiceFeedback
                    else fileExists("$workingDir/$name")
                }

            // AccelerometerCapture: write `video_metadata.json` into workingDir
            // BEFORE building the manifest so the byte-identical sidecar
            // is ready when the tar packing pass starts. Photosphere
            // bundles skip this entirely.
            val videoFilename: String?
            val videoMetadataFilename: String?
            when (input) {
                is PhotosphereSubmitInput -> {
                    videoFilename = null
                    videoMetadataFilename = null
                }
                is FaceCaptureSubmitInput, is PhotoSeriesSubmitInput -> {
                    videoFilename = null
                    videoMetadataFilename = null
                }
                is AccelerometerCaptureSubmitInput -> {
                    val v = input.result
                    videoFilename = v.videoPath
                        .substringAfterLast('/')
                        .substringAfterLast('\\')
                    videoMetadataFilename = CaptureBundleEntries.VIDEO_METADATA_FILENAME
                    val metadataBytes = VideoMetaDataJson.encodeToBytes(v.videoMetadata)
                    writeBytes("$workingDir/$videoMetadataFilename", metadataBytes)
                }
            }

            // The reference ships under its REAL basename for every capture
            // screen (ref_image.jpg photosphere, photo.jpg accelerometer,
            // reference.heic face): a forced rename lied about HEIC content and
            // tripped the decrypt's filename-keyed JPEG passthrough into
            // handing raw HEIC to cv2 consumers. A photo series' reference is
            // one of its stills, which the bundle already names.
            val imageFilename = when (input) {
                is PhotoSeriesSubmitInput -> CaptureBundleEntries.PHOTO_SERIES_REFERENCE
                else -> photoPath.substringAfterLast('/').substringAfterLast('\\')
            }
            val manifest = CaptureManifest(
                captureId = session.id,
                sdkVersion = sdkVersion,
                captureTimestamp = epochMillisToIso8601(clock()),
                imageFilename = imageFilename,
                imageFrames = frameFilenames.map { SdkFrameEntry(filename = it) },
                captureMode = effectiveCaptureMode.toWireValue(),
                videoFilename = videoFilename,
                videoMetadataFilename = videoMetadataFilename,
                markerVersion = input.markerVersion,
                sidecars = sidecarBasenames,
                referenceLuminance = input.referenceLuminance,
            )
            val manifestBytes = ManifestJson.encodeToString(manifest).encodeToByteArray()

            val photoSize = fileSize(photoPath)

            val framePaths: List<String> = when (input) {
                is PhotosphereSubmitInput -> input.result.framePaths
                is FaceCaptureSubmitInput -> input.result.framePaths
                is AccelerometerCaptureSubmitInput -> emptyList()
                is PhotoSeriesSubmitInput -> input.stills.map { it.path }
            }
            val frameSizes = framePaths.map { fileSize(it) }
            val sidecarPaths = sidecarBasenames.map { name -> "$workingDir/$name" }
            val sidecarSizes = sidecarPaths.map { fileSize(it) }
            // Video sidecar + binary live next to the photo on the
            // accelerometer-capture path. Resolve sizes once so the tar
            // streaming pass doesn't re-stat.
            val videoPath: String? = (input as? AccelerometerCaptureSubmitInput)?.result?.videoPath
            val videoSize: Long? = videoPath?.let { fileSize(it) }
            val videoMetadataPath: String? = videoMetadataFilename?.let {
                "$workingDir/$it"
            }
            val videoMetadataSize: Long? = videoMetadataPath?.let { fileSize(it) }

            val path = encryptedBundlePath(session.id).also { encryptedPath = it }
            val bundleSink = encryptor.openEncryptingSink(path)
            try {
                val tar = TarStoreSink(bundleSink)
                tar.addEntry("manifest.json", manifestBytes.size.toLong()) { s ->
                    s.write(manifestBytes, 0, manifestBytes.size)
                }
                // A photo series' stills are stored as sent and measured as
                // JPEG, so the server refuses any other format: refuse it
                // here, before the upload.
                val requireJpeg = input is PhotoSeriesSubmitInput
                tar.addEntry(manifest.imageFilename, photoSize) { s ->
                    streamFile(photoPath, s, requireJpeg)
                }
                for ((i, framePath) in framePaths.withIndex()) {
                    tar.addEntry(frameFilenames[i], frameSizes[i]) { s ->
                        streamFile(framePath, s, requireJpeg)
                    }
                }
                // AccelerometerCapture: video bytes ride straight from disk
                // through the tar writer (one streaming read, no
                // in-memory copy). The bundle envelope's chunked
                // AES-256-GCM handles the encryption uniformly — no
                // per-file extra wrap.
                if (videoFilename != null && videoPath != null && videoSize != null) {
                    tar.addEntry(videoFilename, videoSize) { s ->
                        readFileStreaming(videoPath, s)
                    }
                }
                if (videoMetadataFilename != null &&
                    videoMetadataPath != null &&
                    videoMetadataSize != null
                ) {
                    tar.addEntry(videoMetadataFilename, videoMetadataSize) { s ->
                        readFileStreaming(videoMetadataPath, s)
                    }
                }
                for ((i, sidecarPath) in sidecarPaths.withIndex()) {
                    tar.addEntry(sidecarBasenames[i], sidecarSizes[i]) { s ->
                        readFileStreaming(sidecarPath, s)
                    }
                }
                if (devMode) {
                    val padBytes = debugBundlePaddingBytes().coerceAtLeast(0L)
                    if (padBytes > 0L) {
                        logger.info(
                            "capture[${session.id}] devMode: injecting $padBytes " +
                                "bytes of upload-test padding ($DEBUG_PADDING_ENTRY)",
                        )
                        tar.addEntry(DEBUG_PADDING_ENTRY, padBytes) { s ->
                            writePadding(s, padBytes)
                        }
                    }
                }
                tar.finish()
            } finally {
                bundleSink.close()
            }

            val requestMetadata = (if (customOverride == null) {
                session.metadata
            } else {
                session.metadata.mergeCustom(customOverride)
            }).withVoiceFeedback(hasVoiceFeedback)
            store.insert(
                captureId = session.id,
                request = requestMetadata.toRequest(session.id, deviceInfoSnapshot),
                encryptedPath = path,
                captureMode = effectiveCaptureMode,
            )
            persisted = true

            val transferId = transferManager.upload(path, session.id)
            store.updateTransferTaskId(session.id, transferId)
            // No store.updateStatus here — SdkCaptureUploadStatus is derived from
            // the linked TransferTask row, which TransferManager writes to.
            logger.info(
                "capture[${session.id}] enqueued for upload: " +
                    "bundleBytes=${fileSize(path)}, transferId=$transferId",
            )

            val entry = sessions[session.id]
            entry?.transferTaskId = transferId
            session.setState(CaptureState.Uploading(progressPercent = 0))
            mirrorTransferInto(session, transferId)
        } catch (e: Exception) {
            if (persisted && input is FaceCaptureSubmitInput) {
                session.setState(CaptureState.Uploading(progressPercent = 0))
                logger.warn("capture[${session.id}] transfer handoff failed; retrying durable bundle", e)
                try {
                    recover()
                } catch (recoveryError: Exception) {
                    logger.warn("capture[${session.id}] immediate recovery failed; startup recovery will retry", recoveryError)
                }
                store.findById(session.id)?.transferTaskId?.let { transferId ->
                    sessions[session.id]?.transferTaskId = transferId
                    mirrorTransferInto(session, transferId)
                }
                return
            }
            session.setState(
                CaptureState.Failed(
                    stage = FailureStage.Upload,
                    message = e.message ?: e::class.simpleName ?: "unknown",
                )
            )
            throw e
        } finally {
            // Face-capture stills remain available after a pre-persistence failure
            // so the native summary can retry the same session.
            val keepWorkingDir = !persisted && input is FaceCaptureSubmitInput
            if (!keepWorkingDir) deleteDirQuietly(session.workingDir)
            if (!persisted) encryptedPath?.let { deleteFileQuietly(it) }
        }
    }

    /**
     * devMode-only: list the server's demo catalog. The UI uses this
     * to render a picker when more than one entry exists; the
     * convenience [submitDemoCapture] path that auto-picks the first
     * entry is still available for callers that don't need a picker.
     */
    internal suspend fun listDemoCaptures(
        session: CaptureSession,
    ): List<DemoCaptureSummary> {
        val repo = demoRepoFor(session)
        return repo.listCatalog().map {
            DemoCaptureSummary(id = it.id, name = it.name)
        }
    }

    internal suspend fun submitDemoCapture(
        session: CaptureSession,
        entryId: String?,
        onProgress: (downloaded: Int, total: Int) -> Unit,
    ) {
        val repo = demoRepoFor(session)
        val catalog = repo.listCatalog()
        if (catalog.isEmpty()) {
            throw DemoCaptureException("No demo captures available on the server")
        }
        val entry = if (entryId == null) {
            catalog.first()
        } else {
            catalog.firstOrNull { it.id == entryId }
                ?: throw DemoCaptureException("Unknown demo capture id: $entryId")
        }
        val download = repo.download(
            entry = entry,
            intoDir = session.workingDir,
            onProgress = onProgress,
        )
        val titleOverride = mapOf<String, JsonElement>("title" to JsonPrimitive(entry.name))
        when (download) {
            is DemoDownload.Video -> {
                // Real accelerometer-capture submit. The demo has no IMU,
                // so video_metadata.json is an empty VideoMetaData() — the
                // server only needs the file present; reconstruction
                // frame-selects from the video. allowModeMismatch covers a
                // dev build toggled to photosphere mode submitting a video
                // demo.
                submit(
                    session,
                    VideoCaptureResult(
                        photoPath = download.photoPath,
                        videoPath = download.videoPath,
                        videoMetadata = VideoMetaData(),
                        markerVersion = download.markerVersion,
                    ),
                    allowModeMismatch = true,
                    customOverride = titleOverride,
                )
            }
            is DemoDownload.Photosphere -> {
                // Image demos are photosphere-shaped; submit as photosphere
                // even when the SDK is configured for accelerometer mode.
                submit(
                    session,
                    download.result,
                    allowModeMismatch = true,
                    customOverride = titleOverride,
                )
            }
        }
    }

    private fun demoRepoFor(session: CaptureSession): DemoCaptureRepository {
        check(devMode) {
            "demo-capture APIs require TwinSkinConfig.devMode = true"
        }
        val client = serverClient
            ?: error("demo-capture APIs require a serverClient on CaptureApi")
        val cacheDirProvider = demoCacheDir
            ?: error("demo-capture APIs require a demoCacheDir on CaptureApi")
        return DemoCaptureRepository(
            httpClient = client.client,
            baseUrl = client.baseUrl,
            publishableKey = client.publishableKey,
            auth = client.auth,
            subjectRef = session.metadata.subjectRef,
            cacheRoot = cacheDirProvider(),
        )
    }

    internal suspend fun cancel(session: CaptureSession) {
        val entry = sessions[session.id] ?: return
        entry.mirrorJob?.cancel()
        val transferId = entry.transferTaskId
        if (transferId != null) {
            // The TransferTask flip to CANCELLED surfaces as
            // SdkCaptureUploadStatus.CANCELLED via the derived join.
            transferManager.cancelTask(transferId)
        } else {
            // Cancel ran before a TransferTask was enqueued (either before
            // submit() touched the store, or in the narrow window between
            // store.insert and store.updateTransferTaskId). Drop any orphan
            // SdkCaptureUpload row so recover() doesn't re-enqueue it.
            store.deleteById(session.id)
        }
        session.setState(CaptureState.Cancelled)
        deleteDirQuietly(session.workingDir)
        sessions.remove(session.id)
    }

    /**
     * Surface a non-recoverable capture-side failure to integrators without going
     * through [submit]. Used by the native capture flow when it can't produce a
     * usable result. Clears [CaptureSession.workingDir] and removes the session.
     */
    internal suspend fun fail(session: CaptureSession, reason: String) {
        val entry = sessions[session.id] ?: return
        entry.mirrorJob?.cancel()
        session.setState(CaptureState.Failed(stage = FailureStage.Upload, message = reason))
        deleteDirQuietly(session.workingDir)
        sessions.remove(session.id)
    }

    /**
     * Sweep-based recovery for captures interrupted by an app kill.
     *
     * Heals orphan rows — `SdkCaptureUpload` rows with `transferTaskId IS NULL`,
     * meaning the app died between `store.insert` and `transferManager.upload`.
     * These get re-enqueued from the persisted bundle path. Rows that already
     * have a `transferTaskId` are owned by [TransferManager.launchRecovery],
     * which resumes them via the TransferTask state machine — no separate
     * status fixup is needed here, because [SdkCaptureUploadStatus] is derived
     * from the joined `TransferTask.status`.
     *
     * Safe to call repeatedly.
     */
    suspend fun recover() {
        for (record in store.findOrphans()) {
            val transferId = transferManager.upload(record.encryptedPath, record.captureId)
            store.updateTransferTaskId(record.captureId, transferId)
        }
    }

    /**
     * Fire-and-forget recovery called from `TwinSkinSdk.initialize`. Heals the
     * [SdkCaptureStore] table first (orphan captures missing a TransferTask row,
     * see [recover]), then kicks [TransferManager.launchRecovery] to reset any
     * ACTIVE uploads and retry PENDING ones. Ordering matters: step 1 restores
     * the invariant "every pending capture has a TransferTask" so step 2 sees
     * a consistent view.
     */
    fun launchRecoveryAll() {
        scope.launch {
            recover()
            transferManager.launchRecovery()
        }
    }

    /**
     * Mirror the [TransferTask] state into the in-memory [CaptureSession.state]
     * so the foreground UI (snackbars, capture screen) sees byte-level progress
     * and terminal transitions. Lives only for the life of the [CaptureSession]
     * — `observePendingUploads` does not depend on this; it reads
     * [SdkCaptureUploadStatus] derived from the same TransferTask row, which
     * keeps working even if this mirror was never attached (e.g. after a
     * process kill, on the next launch).
     */
    private fun mirrorTransferInto(
        session: CaptureSession,
        transferTaskId: String,
    ) {
        val entry = sessions[session.id] ?: return
        entry.mirrorJob = transferManager.observeTask(transferTaskId)
            .onEach { task ->
                if (task == null) return@onEach
                when (TransferStatus.valueOf(task.status)) {
                    TransferStatus.PENDING,
                    TransferStatus.ACTIVE,
                    TransferStatus.UNZIPPING -> {
                        session.setState(CaptureState.Uploading(task.progress.toInt()))
                    }
                    TransferStatus.COMPLETED -> {
                        session.setState(CaptureState.Uploaded)
                        finish(session.id)
                    }
                    TransferStatus.CANCELLED -> {
                        session.setState(CaptureState.Cancelled)
                        finish(session.id)
                    }
                    TransferStatus.FAILED -> {
                        session.setState(
                            CaptureState.Failed(
                                stage = FailureStage.Upload,
                                message = task.errorMessage ?: "upload failed",
                            )
                        )
                        finish(session.id)
                    }
                }
            }
            .launchIn(scope)
    }

    private fun finish(sessionId: String) {
        sessions.remove(sessionId)?.mirrorJob?.cancel()
    }
}

// `encodeDefaults = true` keeps byte-identity with web_app json_serializable output;
// pinned by ManifestByteIdentityTest.
private val ManifestJson: Json = Json { encodeDefaults = true }

// A field left out reads as null to the Lambda, so nulls are left out.
private val SidecarJson: Json = Json {
    encodeDefaults = true
    explicitNulls = false
}

private val JPEG_START = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte())

private fun streamFile(path: String, sink: ByteSink, requireJpeg: Boolean) {
    if (!requireJpeg) {
        readFileStreaming(path, sink)
        return
    }
    var checked = 0
    readFileStreaming(path) { src, off, len ->
        var i = 0
        while (checked < JPEG_START.size && i < len) {
            require(src[off + i] == JPEG_START[checked]) { "$path is not a JPEG" }
            checked++
            i++
        }
        sink.write(src, off, len)
    }
    require(checked == JPEG_START.size) { "$path is not a JPEG" }
}

/** The still's name in the bundle and in `photo_series.json`. */
private val PhotoSeries.Still.bundleName: String
    get() = "${pose.wireValue}_$burstRank.jpg"

private fun requirePathInside(dir: String, path: String, paramName: String) {
    val normalizedDir = dir.trimEnd('/')
    require(path.startsWith("$normalizedDir/")) {
        "$paramName must live inside session.workingDir ($normalizedDir), got: $path"
    }
}

private fun randomCaptureId(): String {
    val bytes = ByteArray(12).also { secureRandomBytes(it) }
    return "tsc_" + bytes.joinToString("") { it.toUByte().toString(16).padStart(2, '0') }
}

private sealed interface SubmitInput {
    val photoPath: String
    val markerVersion: String?
    val referenceLuminance: SdkReferenceLuminance?
    val captureMode: CaptureMode
}

private data class PhotosphereSubmitInput(val result: CaptureResult) : SubmitInput {
    override val photoPath: String get() = result.photoPath
    override val markerVersion: String? get() = result.markerVersion
    override val referenceLuminance: SdkReferenceLuminance?
        get() = result.referenceLuminance
    override val captureMode: CaptureMode get() = CaptureMode.Photosphere
}

private data class FaceCaptureSubmitInput(val result: CaptureResult) : SubmitInput {
    override val photoPath: String get() = result.photoPath
    override val markerVersion: String? get() = result.markerVersion
    override val referenceLuminance: SdkReferenceLuminance?
        get() = result.referenceLuminance
    override val captureMode: CaptureMode get() = CaptureMode.FaceCapture
}

/** A file packed from where it is, under [name]. */
private data class BundleFile(val path: String, val name: String)

/**
 * The host's stills, read in place: unlike a capture screen's output they
 * are not in the session's working directory, which only holds the sidecar.
 * [reference] is the frontal still's path, packed again as the reference.
 */
private data class PhotoSeriesSubmitInput(
    val stills: List<BundleFile>,
    val reference: String,
) : SubmitInput {
    override val photoPath: String get() = reference
    override val markerVersion: String? get() = null
    override val referenceLuminance: SdkReferenceLuminance? get() = null
    override val captureMode: CaptureMode get() = CaptureMode.PhotoSeries
}

private data class AccelerometerCaptureSubmitInput(val result: VideoCaptureResult) : SubmitInput {
    override val photoPath: String get() = result.photoPath
    override val markerVersion: String? get() = result.markerVersion
    // Forwarded verbatim into the manifest as a value only — the manifest shape
    // is unchanged from the marker-less path, so parity holds.
    override val referenceLuminance: SdkReferenceLuminance? get() = result.referenceLuminance
    override val captureMode: CaptureMode get() = CaptureMode.AccelerometerCapture
}
