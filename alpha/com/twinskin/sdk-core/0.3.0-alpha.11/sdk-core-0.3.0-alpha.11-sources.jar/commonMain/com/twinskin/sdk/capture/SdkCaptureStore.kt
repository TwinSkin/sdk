package com.twinskin.sdk.capture

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import com.twinskin.sdk.CaptureMode
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.sdk_client.SdkAnalysis
import com.twinskin.sdk.sdk_client.SdkDeviceInfo
import com.twinskin.sdk.sdk_client.SdkStartCaptureRequest
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.currentTimeMillis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

private const val WOUND_CONDITION_WIRE_VALUE: String = "wound"

/**
 * Durable record written when a capture's encrypted bundle has been
 * materialized on disk and is ready to hand off to the transfer manager.
 *
 * Stores everything needed to re-call `POST /upload/start-capture` (the
 * server's idempotent entry point) so we can mint a fresh presigned PUT
 * URL whenever the TransferManager's URL resolver is asked to refresh
 * one.
 *
 * [status] is **derived** from the linked [TransferTask] row at read
 * time — there is no status column on this table. See [SdkCaptureStore]
 * for the mapping.
 */
internal data class SdkCaptureUploadRecord(
    val captureId: String,
    val request: SdkStartCaptureRequest,
    val encryptedPath: String,
    val status: SdkCaptureUploadStatus,
    val transferTaskId: String?,
    /**
     * Byte-level upload progress 0..100 from the joined [TransferTask.progress]
     * column, or null when no TransferTask row exists yet (PENDING_UPLOAD).
     * Updated by [TransferManager] in response to per-attempt
     * [TransferUpdate.Progress] callbacks from the platform provider.
     */
    val transferProgressPercent: Int?,
    /**
     * Which capture pipeline produced this bundle. Legacy rows written
     * before [CaptureMode] was persisted default to
     * [CaptureMode.Photosphere] — every pre-CaptureMode upload was
     * photosphere.
     */
    val captureMode: CaptureMode,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long,
    /**
     * When the server answered that it holds an intact copy of the bundle
     * (`POST /upload/confirm-bundle`), or null while the device must keep it.
     */
    val serverReleasedAtEpochMs: Long? = null,
)

/**
 * Public-facing capture upload status. Derived from the [TransferTask]
 * row joined on [SdkCaptureUploadRecord.transferTaskId]; the SDK does
 * not store this value. See [SdkCaptureStore.deriveStatus] for the rule.
 */
internal enum class SdkCaptureUploadStatus {
    /** Bundle is on disk; no [TransferTask] row exists yet (transferTaskId IS NULL). */
    PENDING_UPLOAD,
    /** TransferTask is in PENDING / ACTIVE / UNZIPPING. */
    UPLOADING,
    /** TransferTask is COMPLETED — or has been deleted by clearCompleted. */
    COMPLETED,
    /** TransferTask is FAILED. */
    FAILED,
    /** TransferTask is CANCELLED. */
    CANCELLED,
}

/**
 * Thin typed wrapper over the SQLDelight `SdkCaptureUpload` queries.
 *
 * Reads join with `TransferTask` to derive the public
 * [SdkCaptureUploadStatus]. The store has no `updateStatus` API — status
 * is owned by the TransferManager (which writes [TransferStatus]) and
 * surfaced here read-only.
 */
internal class SdkCaptureStore(
    private val database: TwinSkinDatabase,
    private val clock: () -> Long = ::currentTimeMillis,
    private val json: Json = Json,
) {
    private val captureQueries get() = database.sdkCaptureUploadQueries
    private val transferQueries get() = database.transferTaskQueries

    fun insert(
        captureId: String,
        request: SdkStartCaptureRequest,
        encryptedPath: String,
        captureMode: CaptureMode = CaptureMode.Photosphere,
    ): SdkCaptureUploadRecord {
        val now = clock()
        captureQueries.insert(
            captureId = captureId,
            userRef = request.userRef,
            subjectRef = request.subjectRef,
            conditionType = request.conditionType,
            analysisJson = request.analysis?.let { json.encodeToString(SdkAnalysis.serializer(), it) },
            captureGroup = request.captureGroup,
            bodyLocationJson = request.bodyLocation?.let { json.encodeToString(it) },
            customJson = request.custom?.let { json.encodeToString(JsonObject(it)) },
            deviceInfoJson = request.deviceInfo?.let { json.encodeToString(it) },
            encryptedPath = encryptedPath,
            transferTaskId = null,
            captureMode = captureMode.toWireValue(),
            createdAt = now,
            updatedAt = now,
        )
        return SdkCaptureUploadRecord(
            captureId = captureId,
            request = request,
            encryptedPath = encryptedPath,
            status = SdkCaptureUploadStatus.PENDING_UPLOAD,
            transferTaskId = null,
            transferProgressPercent = null,
            captureMode = captureMode,
            createdAtEpochMs = now,
            updatedAtEpochMs = now,
        )
    }

    fun findById(captureId: String): SdkCaptureUploadRecord? {
        val upload = captureQueries.selectById(captureId).executeAsOneOrNull() ?: return null
        val transfer = upload.transferTaskId?.let { id ->
            transferQueries.selectById(id).executeAsOneOrNull()
        }
        return upload.toRecord(transferStatus = transfer?.status, transferProgress = transfer?.progress)
    }

    /**
     * Captures whose `transferTaskId IS NULL` — the app died between
     * `insert` and `transferManager.upload`. Recovery re-enqueues these.
     */
    fun findOrphans(): List<SdkCaptureUploadRecord> =
        captureQueries.selectOrphans().executeAsList()
            .map { it.toRecord(transferStatus = null, transferProgress = null) }

    /**
     * Uploads that finished on this device — a COMPLETED task, or a task row
     * `clearCompleted` has removed — and that the server has not released.
     * [BundleReleaseConfirmer] asks the server about these.
     */
    fun findAwaitingServerRelease(): List<SdkCaptureUploadRecord> =
        unreleasedRecords().filter { it.status == SdkCaptureUploadStatus.COMPLETED }

    /**
     * Bundle paths no sweep may delete: every unreleased capture except a
     * cancelled one, whose CANCELLED task is the evidence that condemns it.
     */
    fun retainedBundlePaths(): List<String> =
        unreleasedRecords()
            .filter { it.status != SdkCaptureUploadStatus.CANCELLED }
            .map { it.encryptedPath }

    fun markServerReleased(captureId: String) {
        val now = clock()
        captureQueries.updateServerReleasedAt(now, now, captureId)
    }

    private fun unreleasedRecords(): List<SdkCaptureUploadRecord> =
        captureQueries.selectUnreleased().executeAsList().map { upload ->
            val transfer = upload.transferTaskId?.let { id ->
                transferQueries.selectById(id).executeAsOneOrNull()
            }
            upload.toRecord(transferStatus = transfer?.status, transferProgress = transfer?.progress)
        }

    /**
     * Observe every row in the upload table joined with its
     * [TransferTask], sorted by creation time (newest first). Re-emits
     * whenever any row in either table is inserted, updated, or deleted.
     * The join happens in Kotlin; subscribing to both SQLDelight queries
     * (rather than a SQL JOIN) keeps the schema queries trivially
     * verifiable and lets each table's change-notifications drive
     * re-derivation independently.
     */
    fun observeAll(): Flow<List<SdkCaptureUploadRecord>> =
        combine(
            captureQueries.selectAll().asFlow().mapToList(Dispatchers.Default),
            transferQueries.selectAll().asFlow().mapToList(Dispatchers.Default),
        ) { uploads, transfers ->
            val transfersById = transfers.associateBy { it.id }
            uploads.map { upload ->
                val transfer = transfersById[upload.transferTaskId]
                upload.toRecord(
                    transferStatus = transfer?.status,
                    transferProgress = transfer?.progress,
                )
            }
        }

    fun updateTransferTaskId(captureId: String, transferTaskId: String?) {
        captureQueries.updateTransferTaskId(transferTaskId, clock(), captureId)
    }

    fun deleteById(captureId: String) {
        captureQueries.deleteById(captureId)
    }

    private fun com.twinskin.sdk.db.SdkCaptureUpload.toRecord(
        transferStatus: String?,
        transferProgress: Long?,
    ): SdkCaptureUploadRecord {
        val bodyLocation = bodyLocationJson?.let {
            json.decodeFromString<List<String>>(it)
        }
        val custom = customJson?.let {
            json.decodeFromString<Map<String, JsonElement>>(it)
        }
        val deviceInfo = deviceInfoJson?.let {
            json.decodeFromString<SdkDeviceInfo>(it)
        }
        val analysis = analysisJson?.let {
            json.decodeFromString(SdkAnalysis.serializer(), it)
        }
        return SdkCaptureUploadRecord(
            captureId = captureId,
            request = SdkStartCaptureRequest(
                userRef = userRef,
                subjectRef = subjectRef,
                captureId = captureId,
                // Legacy rows written before the column existed default to
                // "wound", the value every demo host supplied back then.
                conditionType = conditionType
                    ?: if (analysis == null) WOUND_CONDITION_WIRE_VALUE else null,
                analysis = analysis,
                captureGroup = captureGroup,
                bodyLocation = bodyLocation,
                custom = custom,
                deviceInfo = deviceInfo,
            ),
            encryptedPath = encryptedPath,
            status = deriveStatus(transferTaskId, transferStatus),
            transferTaskId = transferTaskId,
            transferProgressPercent = transferProgress?.toInt(),
            captureMode = CaptureMode.fromWireValue(captureMode),
            createdAtEpochMs = createdAt,
            updatedAtEpochMs = updatedAt,
            serverReleasedAtEpochMs = serverReleasedAt,
        )
    }

    companion object {
        /**
         * Map (transferTaskId, joined TransferTask.status) to the public
         * [SdkCaptureUploadStatus]. Single source of truth for the
         * derivation; tests and observers go through here.
         *
         *  - `transferTaskId == null` → `PENDING_UPLOAD` (capture row exists,
         *    no transfer was ever enqueued).
         *  - `transferTaskId` set, but the TransferTask row is gone (e.g.
         *    `clearCompleted` ran) → `COMPLETED`. The row only ever gets
         *    deleted from a terminal state, and treating it as COMPLETED
         *    drops it from `observePendingUploads` — the closest behavior
         *    to "success silently went away".
         *  - Otherwise the TransferStatus name maps directly.
         */
        fun deriveStatus(
            transferTaskId: String?,
            transferStatus: String?,
        ): SdkCaptureUploadStatus {
            if (transferTaskId == null) return SdkCaptureUploadStatus.PENDING_UPLOAD
            if (transferStatus == null) return SdkCaptureUploadStatus.COMPLETED
            return when (TransferStatus.valueOf(transferStatus)) {
                TransferStatus.PENDING,
                TransferStatus.ACTIVE,
                TransferStatus.UNZIPPING -> SdkCaptureUploadStatus.UPLOADING
                TransferStatus.COMPLETED -> SdkCaptureUploadStatus.COMPLETED
                TransferStatus.FAILED -> SdkCaptureUploadStatus.FAILED
                TransferStatus.CANCELLED -> SdkCaptureUploadStatus.CANCELLED
            }
        }
    }
}
