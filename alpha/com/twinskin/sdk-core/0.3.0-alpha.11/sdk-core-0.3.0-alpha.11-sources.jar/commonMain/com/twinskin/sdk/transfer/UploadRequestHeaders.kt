package com.twinskin.sdk.transfer

import com.twinskin.sdk.capture.UIReplayUploadKey
import io.ktor.client.request.HttpRequestBuilder
import io.ktor.http.HttpHeaders
import kotlin.io.encoding.Base64

internal fun uploadRequestHeaders(uploadKey: String): Map<String, String> {
    val replay = UIReplayUploadKey.parse(uploadKey) ?: return emptyMap()
    val digest = replay.cipherSha256.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    return mapOf(
        "Content-Length" to replay.size.toString(),
        "x-amz-checksum-sha256" to Base64.encode(digest),
    )
}

internal fun HttpRequestBuilder.applyUploadRequestHeaders(requestHeaders: Map<String, String>) {
    // The body owns Content-Length; replay metadata must not override its actual size.
    requestHeaders.forEach { (key, value) ->
        if (!key.equals(HttpHeaders.ContentLength, ignoreCase = true)) headers.append(key, value)
    }
}
