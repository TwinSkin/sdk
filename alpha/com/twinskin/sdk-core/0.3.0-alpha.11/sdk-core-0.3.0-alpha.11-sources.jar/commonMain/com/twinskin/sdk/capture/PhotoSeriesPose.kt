// GENERATED CODE — DO NOT EDIT BY HAND
// Source: lib/src/capture_processing/skin_analysis_models.dart
// Regenerate: fvm dart run tool/generate_kotlin_sdk_client.dart

package com.twinskin.sdk.capture

import com.twinskin.sdk.TwinSkinInternalApi
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@TwinSkinInternalApi
@Serializable
public enum class PhotoSeriesPose {
    @SerialName("frontal") Frontal,
    @SerialName("upper") Upper,
    @SerialName("right") Right,
    @SerialName("left") Left,
    @SerialName("lower") Lower,
    @SerialName("frontal_fill") FrontalFill;
}
