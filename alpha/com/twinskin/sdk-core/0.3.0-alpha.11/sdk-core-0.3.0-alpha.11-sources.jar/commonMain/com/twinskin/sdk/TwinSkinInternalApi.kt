package com.twinskin.sdk

/**
 * Marks a TwinSkin SDK declaration as internal-but-publicly-visible.
 *
 * Symbols carrying this annotation are reachable from outside the SDK
 * because TwinSkin's own modules use them — `:demo-shared`, the demo
 * apps, the Flutter plugin's native glue — but are NOT a stable
 * integrator contract: capabilities that are not published, and
 * diagnostics. Their signatures, semantics, or existence may change in
 * any release without a deprecation cycle.
 *
 * Integrators should not opt in. If you find yourself needing one of
 * these symbols in production code, file an issue so we can curate
 * the right stable shape.
 */
@RequiresOptIn(
    level = RequiresOptIn.Level.ERROR,
    message = "This is an internal TwinSkin SDK API, used only by TwinSkin's own " +
        "modules. It is not a stable integrator contract — use the documented " +
        "TwinSkin.* surface instead.",
)
@Retention(AnnotationRetention.BINARY)
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.FUNCTION,
    AnnotationTarget.PROPERTY,
    AnnotationTarget.TYPEALIAS,
    AnnotationTarget.CONSTRUCTOR,
)
public annotation class TwinSkinInternalApi
