package com.twinskin.sdk.ui.annotation_editor.delineation.dashboard

import androidx.compose.ui.graphics.Path
import com.twinskin.sdk.geometry.classifyRings
import com.twinskin.sdk.geometry.difference
import com.twinskin.sdk.geometry.pathArea
import com.twinskin.sdk.geometry.pathToPolygons
import com.twinskin.sdk.geometry.polygonToPath
import com.twinskin.sdk.geometry.signedArea
import com.twinskin.sdk.geometry.union
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.reDensify
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Tissue
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound
import kotlin.math.absoluteValue

/**
 * "Last tissue auto-fill" — the dashboard offers this as a shortcut
 * when only one tissue type is left unresolved. Assigns the wound
 * area not already covered by any existing tissue (of any type) to
 * [type], yielding the wound with the new fill polygons appended
 * to its [Wound.tissues] list. Returns the wound unchanged when no
 * fillable space remains (existing tissues already tile the wound).
 *
 * **Min-area filter.** Fill polygons whose absolute area is below
 * [minTissueArea] are discarded — the boolean-difference backend
 * yields sub-pixel slivers along clamped boundaries that aren't
 * worth materialising as separate tissues.
 *
 * Yielded polygons are re-densified to the canonical `[2, 10]`
 * image-px vertex spacing the reshape engine assumes.
 */
internal fun autoFillRemainingTissue(
    wound: Wound,
    type: TissueType,
    minTissueArea: Float,
): Wound {
    if (wound.outline.size < 3) return wound
    val remainingPath = remainingPath(wound) ?: return wound
    // Skia's Path.op encodes a polygon-with-hole as multiple sub-paths
    // (outer ring + inner ring per hole). Keep the fillable outer rings
    // (even containment depth — includes islands enclosed by existing
    // tissue) and drop the hole rings that match an existing tissue's
    // footprint. classifyRings is containment-depth based: a centroid
    // heuristic here used to misclassify the wound's own outer ring as
    // a hole whenever the user's tissues sat at the wound center
    // (outer-ring centroid inside a hole ring → fill silently no-oped).
    val polys = pathToPolygons(remainingPath)
    val holes = classifyRings(polys)
    val outers = polys.filterIndexed { i, _ -> !holes[i] }
    val newTissues = outers
        .filter { signedArea(it).absoluteValue >= minTissueArea }
        .map { Tissue(type = type, outline = reDensify(it)) }
    if (newTissues.isEmpty()) return wound
    return Wound(
        outline = wound.outline,
        // Prepend so the auto-fill renders under the user's existing
        // tissues; otherwise the outer-ring fill would visually cover
        // them since Tissue carries no hole geometry.
        tissues = newTissues + wound.tissues,
    )
}

/**
 * Auto-fills [type] across EVERY wound, repeating until the untyped remainder
 * is within [tolerance] of the total wound area (default 1%) or a pass makes
 * no further progress.
 *
 * A single pass of [autoFillRemainingTissue] can miss some wounds: the Skia
 * boolean `difference` backend occasionally yields no usable polygon (or only
 * sub-[minTissueArea] slivers) for a given wound on one pass, so with many
 * wounds the remainder can stall well above 0% (observed: 5 wounds → only 3
 * filled, ~18% left). Re-running picks up the wounds a prior pass skipped;
 * the no-progress guard stops once the only thing left is genuinely
 * unfillable slivers, so the loop always terminates.
 */
internal fun autoFillAllWounds(
    wounds: List<Wound>,
    type: TissueType,
    minTissueArea: Float,
    // Half a display percent: the dashboard's full-coverage snap
    // folds a sub-1 % remainder into the typed shares, so the fill
    // must stop strictly below that threshold or a "filled" wound
    // could still surface a phantom Untyped row.
    tolerance: Float = 0.005f,
    maxPasses: Int = 8,
): List<Wound> {
    val totalArea = wounds.sumOf { signedArea(it.outline).absoluteValue.toDouble() }.toFloat()
    if (totalArea <= 0f) return wounds
    var current = wounds
    var prevRemaining = Float.MAX_VALUE
    repeat(maxPasses) {
        val remaining = remainingFillableArea(current)
        if (remaining / totalArea <= tolerance) return current
        // No-progress guard: a pass that didn't shrink the remainder (within a
        // tiny epsilon) means the rest is unfillable slivers — stop.
        if (remaining >= prevRemaining - minTissueArea) return current
        prevRemaining = remaining
        current = current.map { wound ->
            autoFillRemainingTissue(wound = wound, type = type, minTissueArea = minTissueArea)
        }
    }
    return current
}

/**
 * Total image-px² area of the union of every wound's outline that
 * isn't already covered by some tissue. The dispatcher consults
 * this before showing the auto-fill prompt: when the remainder
 * falls below the same `minTissueArea` floor the per-wound fill
 * uses, the dialog would lead to a no-op fill (or a 0% Drawn
 * card) and is suppressed.
 */
internal fun remainingFillableArea(wounds: List<Wound>): Float {
    var total = 0f
    for (wound in wounds) {
        val remainingPath = remainingPath(wound) ?: continue
        // pathArea is hole-aware: enclosed tissue footprints subtract
        // from the remainder instead of inflating it.
        total += pathArea(remainingPath)
    }
    return total
}

private fun remainingPath(wound: Wound): Path? {
    if (wound.outline.size < 3) return null
    val woundPath = polygonToPath(wound.outline)
    val existingPaths = wound.tissues
        .filter { it.outline.size >= 3 }
        .map { polygonToPath(it.outline) }
    if (existingPaths.isEmpty()) return woundPath

    // Preferred path: one difference against the union of every
    // tissue. Any op failing (Skia bails on pathological input)
    // poisons the union to null and routes to the fallback below —
    // the old code silently kept a partial union, so the fill could
    // overlap the dropped tissue without anyone noticing.
    val existingUnion = existingPaths.fold<Path, Path?>(Path()) { acc, p ->
        acc?.let { union(it, p) }
    }
    val viaUnion = existingUnion?.let { difference(woundPath, it) }
    if (viaUnion != null) return viaUnion

    // Fallback: subtract tissue by tissue, skipping only the
    // individual op that fails. A fill overlapping one skipped
    // tissue (rendered underneath, counted by the smallest-first
    // percentage pass) beats the silent no-op fill the user reads
    // as "auto-fill didn't draw".
    var remaining = woundPath
    for (p in existingPaths) {
        remaining = difference(remaining, p) ?: remaining
    }
    return remaining
}
