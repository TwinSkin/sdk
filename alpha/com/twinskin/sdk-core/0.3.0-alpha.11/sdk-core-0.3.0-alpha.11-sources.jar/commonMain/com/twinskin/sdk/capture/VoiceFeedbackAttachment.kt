package com.twinskin.sdk.capture

import com.twinskin.sdk.capture.crypto.sha256File
import com.twinskin.sdk.capture.io.fileExists
import com.twinskin.sdk.capture.io.fileSize
import com.twinskin.sdk.capture.io.readBytes
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive

internal const val VOICE_FEEDBACK_READY = "voice_feedback.ready.json"
internal const val HAS_VOICE_FEEDBACK = "has_voice_feedback"

@Serializable
private data class VoiceFeedbackReceipt(
    val schemaVersion: Int,
    val captureId: String,
    val segmentCount: Int,
    val archiveByteCount: Long,
    val archiveSHA256: String,
)

/** The recorder publishes this receipt only after validating clips and finalizing its ZIP. */
internal fun hasReadyVoiceFeedback(workingDir: String, captureId: String): Boolean {
    val receiptPath = "$workingDir/$VOICE_FEEDBACK_READY"
    val archivePath = "$workingDir/${CaptureBundleEntries.VOICE_FEEDBACK}"
    return try {
        if (!fileExists(receiptPath) || !fileExists(archivePath)) return false
        if (fileSize(receiptPath) !in 1L..4096L) return false
        val receipt = Json.decodeFromString<VoiceFeedbackReceipt>(readBytes(receiptPath).decodeToString())
        if (receipt.schemaVersion != 1 || receipt.captureId != captureId ||
            receipt.segmentCount !in 1..20 || receipt.archiveByteCount <= 0 ||
            fileSize(archivePath) != receipt.archiveByteCount ||
            !receipt.archiveSHA256.matches(Regex("[0-9a-f]{64}"))) return false
        val digest = sha256File(archivePath).joinToString("") {
            (it.toInt() and 0xff).toString(16).padStart(2, '0')
        }
        digest == receipt.archiveSHA256
    } catch (_: Exception) {
        false
    }
}

internal fun SdkCaptureMetadata.withVoiceFeedback(hasAttachment: Boolean): SdkCaptureMetadata {
    val existing = custom ?: emptyMap()
    val updated = existing - HAS_VOICE_FEEDBACK
    return copy(custom = if (hasAttachment) {
        updated + (HAS_VOICE_FEEDBACK to JsonPrimitive(true))
    } else if (custom == null) {
        null
    } else {
        updated
    })
}
