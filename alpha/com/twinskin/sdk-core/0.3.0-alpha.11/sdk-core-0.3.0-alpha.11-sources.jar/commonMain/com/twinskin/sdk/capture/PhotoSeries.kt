@file:OptIn(TwinSkinInternalApi::class)

package com.twinskin.sdk.capture

import com.twinskin.sdk.TwinSkinInternalApi
import kotlinx.serialization.json.JsonElement

/**
 * A series of posed stills the host app took, for the skin analysis. Submitted
 * with [com.twinskin.sdk.TwinSkinSdk.submitStills], which reads the files while
 * it packs the bundle and leaves them where they are.
 *
 * The series needs a [PhotoSeriesPose.Frontal] still: it is the one analysed.
 * [ipdMm] is the distance between the pupils when the device measured it; the
 * analysis assumes one otherwise.
 */
@TwinSkinInternalApi
public data class PhotoSeries(
    val stills: List<Still>,
    val ipdMm: Double? = null,
) {
    /**
     * One still of the series. A pose may have several, one per frame of its
     * burst, and the analysis chooses among them.
     */
    @TwinSkinInternalApi
    public data class Still(
        /** Absolute path of a JPEG file. Its bytes are uploaded as they are. */
        val path: String,
        val pose: PhotoSeriesPose,
        /** The frame's rank in its pose's burst: 0 is the device's best. */
        val burstRank: Int = 0,
        /** The device's own sharpness score, which ranked the burst. */
        val sharpness: Double? = null,
        val fillLight: FillLight? = null,
        /** The device's own pre-shutter verdict on this still, recorded as it is. */
        val deviceCheck: Map<String, JsonElement>? = null,
    )

    /**
     * The light the phone added to a still. Colour depends on the light, so
     * series taken under different ones may not compare. A still without one
     * was lit by the room alone.
     */
    @TwinSkinInternalApi
    public enum class FillLight {
        Torch,

        /** The screen, at the brightness the user had. */
        Screen,

        /** The screen, driven to full brightness. */
        BoostedScreen,
    }
}

/** The pose's name in `photo_series.json`, from its generated serial name. */
internal val PhotoSeriesPose.wireValue: String
    get() = PhotoSeriesPose.serializer().descriptor.getElementName(ordinal)

/** The fill light's name in `photo_series.json`. */
internal val PhotoSeries.FillLight.wireValue: String
    get() = when (this) {
        PhotoSeries.FillLight.Torch -> "torch"
        PhotoSeries.FillLight.Screen -> "screen"
        PhotoSeries.FillLight.BoostedScreen -> "boosted_screen"
    }
