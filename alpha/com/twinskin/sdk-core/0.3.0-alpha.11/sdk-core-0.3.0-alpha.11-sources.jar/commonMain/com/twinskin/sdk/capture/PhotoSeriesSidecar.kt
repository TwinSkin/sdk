// GENERATED CODE — DO NOT EDIT BY HAND
// Source: lib/src/capture_processing/skin_analysis_models.dart
// Regenerate: fvm dart run tool/generate_kotlin_sdk_client.dart

@file:OptIn(TwinSkinInternalApi::class)

package com.twinskin.sdk.capture

import com.twinskin.sdk.TwinSkinInternalApi
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

@Serializable
internal data class PhotoSeriesSidecar(
    @SerialName("stills") val stills: List<PhotoSeriesStill>,
    @SerialName("ipd_mm") val ipdMm: Double? = null
)

@Serializable
internal data class PhotoSeriesStill(
    @SerialName("file") val file: String,
    @SerialName("pose") val pose: PhotoSeriesPose,
    @SerialName("burst_rank") val burstRank: Long = 0,
    @SerialName("device_sharpness") val deviceSharpness: Double? = null,
    @SerialName("fill_light") val fillLight: String? = null,
    @SerialName("device_check") val deviceCheck: Map<String, JsonElement>? = null
)
