package com.twinskin.sdk.capture

import com.twinskin.sdk.TwinSkinInternalApi
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

/**
 * A [PhotoSeries.Still] from the names `photo_series.json` uses for its pose and
 * fill light, for the Flutter plugin: its Kotlin and Swift glue both read the
 * Dart values through this one table. [burstRank] is a [Long] because a Dart
 * `int` crosses the channel as one.
 *
 * Throws [IllegalArgumentException] for a pose or a fill light the SDK does not
 * know, a burst rank beyond an [Int], or a [deviceCheckJson] that is not a JSON
 * object.
 *
 * A bridging artifact, like [parseJsonElement]: not a stable integrator surface.
 */
@TwinSkinInternalApi
@Throws(IllegalArgumentException::class)
public fun photoSeriesStill(
    path: String,
    pose: String,
    burstRank: Long,
    sharpness: Double?,
    fillLight: String?,
    deviceCheckJson: String?,
): PhotoSeries.Still {
    require(burstRank in Int.MIN_VALUE..Int.MAX_VALUE) { "$path: burstRank $burstRank is out of range" }
    return PhotoSeries.Still(
        path = path,
        pose = requireNotNull(PhotoSeriesPose.entries.firstOrNull { it.wireValue == pose }) {
            "$path: unknown pose $pose"
        },
        burstRank = burstRank.toInt(),
        sharpness = sharpness,
        fillLight = fillLight?.let { name ->
            requireNotNull(PhotoSeries.FillLight.entries.firstOrNull { it.wireValue == name }) {
                "$path: unknown fill light $name"
            }
        },
        deviceCheck = deviceCheckJson?.let {
            requireNotNull(Json.parseToJsonElement(it) as? JsonObject) {
                "$path: deviceCheck is not a JSON object"
            }
        },
    )
}
