@file:OptIn(TwinSkinInternalApi::class)

package com.twinskin.sdk.capture

import com.powersync.connectors.PowerSyncBackendConnector
import com.powersync.connectors.PowerSyncCredentials
import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider
import com.twinskin.sdk.view.Model3DViewMetadata
import com.twinskin.sdk.view.Vector3
import com.twinskin.sdk.warn
import com.twinskin.sdk.sdk_client.fetchAndParseSessionToken
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.retryWhen
import kotlinx.coroutines.flow.shareIn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import kotlin.math.min
import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

/**
 * Server-state side of the subject-scoped capture observer.
 *
 * Opens (and shares) a PowerSync connection per `subjectRef`. First
 * collection of `observeSubject(X)` lazily creates the client; a
 * second collector on the same subject hooks into the same shared
 * flow; five seconds after the last collector cancels, the client is
 * closed. Different subjects get different clients (the PS JWT's
 * `sub` claim encodes the subject — one client, one subject).
 *
 * Connection errors mid-stream (dropped network, expired-then-rejected
 * token, transient PowerSync failure) trigger a reconnect with
 * capped-exponential backoff — the shared flow stays live and
 * collectors keep their subscription. Each retry is logged through the
 * SDK's [SdkLogger] so integrators who opt into logging can see it.
 *
 * See [CaptureObserver.observeSubject] for the public contract.
 */
internal class ServerCaptureSource(
    private val scope: CoroutineScope,
    private val baseUrl: String,
    private val authProvider: SdkAuthorizationProvider,
    private val powerSyncFactory: PowerSyncClientFactory,
    private val logger: SdkLogger? = null,
    private val idleTimeout: Duration = 5.seconds,
    private val retryInitialDelay: Duration = 1.seconds,
    private val retryMaxDelay: Duration = 30.seconds,
) {
    // Short-lived guard around [shared]. Individual first-subscribes for
    // different subjects do their work on per-subject [CompletableDeferred]s
    // outside this mutex, so a slow auth-provider call on subject A never
    // blocks a first-subscribe on subject B.
    private val mapMutex = Mutex()
    private val shared: MutableMap<String, CompletableDeferred<Flow<List<CaptureEntry>>>> =
        mutableMapOf()

    fun observeSubject(subjectRef: String): Flow<List<CaptureEntry>> = flow {
        val upstream = getOrBuildShared(subjectRef)
        emitAll(upstream)
    }

    /**
     * Resolves (or installs) the subject's shared flow. Concurrent
     * first-subscribers on the same subject find the same
     * [CompletableDeferred] and share a single connection. Concurrent
     * first-subscribers on *different* subjects install different
     * Deferreds and run in parallel.
     *
     * The first auth fetch happens lazily inside the cold flow so a
     * transient backend hiccup is retried by [retryWhen] with the same
     * capped-exponential backoff used for in-stream PowerSync errors —
     * never surfaced to the consumer, never crashes the host process.
     */
    private suspend fun getOrBuildShared(subjectRef: String): Flow<List<CaptureEntry>> {
        val (deferred, isOwner) = mapMutex.withLock {
            val existing = shared[subjectRef]
            if (existing != null) {
                existing to false
            } else {
                val fresh = CompletableDeferred<Flow<List<CaptureEntry>>>()
                shared[subjectRef] = fresh
                fresh to true
            }
        }
        if (isOwner) {
            deferred.complete(buildSharedFlow(subjectRef, deferred))
        }
        return deferred.await()
    }

    private fun buildSharedFlow(
        subjectRef: String,
        owner: CompletableDeferred<Flow<List<CaptureEntry>>>,
    ): Flow<List<CaptureEntry>> {
        // One connector per shared flow. PowerSync calls
        // [SdkSessionConnector.fetchCredentials] on first connect and
        // again near token expiry; both go through the integrator's
        // auth provider via the same path.
        val connector = SdkSessionConnector(subjectRef, baseUrl, authProvider, logger)

        // Opened lazily inside the cold flow so `open()` failures still
        // surface to [retryWhen]. Once an open succeeds the instance is
        // latched — watch-stream errors reuse the same client rather than
        // reopening the underlying `PowerSyncDatabase`, which would race
        // with the prior `close()` on the same sqlite file. Written and
        // read only from the single coroutine driving the shared flow.
        var openedClient: PowerSyncClient? = null

        val cold = flow {
            val client = openedClient
                ?: powerSyncFactory.open(subjectRef, connector)
                    .also { openedClient = it }
            emitAll(client.watchCaptures(subjectRef))
        }.retryWhen { cause, attempt ->
            if (cause is CancellationException) {
                false
            } else {
                logger?.warn(
                    "PowerSync feed for '$subjectRef' errored (attempt ${attempt + 1}); " +
                        "reconnecting after backoff.",
                    cause,
                )
                delay(backoffDelay(attempt.toInt()).inWholeMilliseconds)
                true
            }
        }.onStart {
            // Instant takeover: seed an empty server state so the upstream
            // combine(local, server) fires with local rows immediately instead
            // of staying silent for the seconds PowerSync needs to connect +
            // first-sync. After retryWhen so it fires once per subscription,
            // not per reconnect; shareIn(replay=1) replays the last real value
            // to late joiners, so the empty only shows on a cold start.
            emit(emptyList())
        }.onCompletion {
            // Close the PowerSync client and drop the map entry in a
            // non-cancellable block: `client.close()` is suspending, and
            // under a cancelled parent it would otherwise abort mid-flight
            // and leave the sqlite file handle open. That produced the
            // "Another PowerSync client is already connected to this
            // database" warning when the next `getOrBuildShared` for the
            // same subject tried to open again. The map cleanup runs
            // *after* close so a new subscriber cannot race onto a fresh
            // open while the previous file is still held.
            //
            // Identity-check the map entry: `WhileSubscribed` can restart
            // the upstream on the same SharedFlow if a collector arrives
            // during the stop timeout, and a later rebuild may have
            // installed a different Deferred we must not evict.
            withContext(NonCancellable) {
                val client = openedClient
                openedClient = null
                if (client != null) {
                    runCatching { client.close() }
                }
                mapMutex.withLock {
                    if (shared[subjectRef] === owner) shared.remove(subjectRef)
                }
            }
        }
        return cold.shareIn(
            scope = scope,
            started = SharingStarted.WhileSubscribed(
                stopTimeoutMillis = idleTimeout.inWholeMilliseconds,
                replayExpirationMillis = 0,
            ),
            replay = 1,
        )
    }

    private fun backoffDelay(attempt: Int): Duration {
        // 1s, 2s, 4s, 8s, 16s, 30s (cap). Capped-exponential — aggressive
        // enough that a transient network blip reconnects in seconds, slow
        // enough that a hard outage doesn't hammer the server.
        val doubledMs = retryInitialDelay.inWholeMilliseconds shl min(attempt, 20)
        val cappedMs = min(doubledMs, retryMaxDelay.inWholeMilliseconds)
        return cappedMs.milliseconds
    }
}

/**
 * PowerSync connection handle opened by [ServerCaptureSource]. Platform
 * impls wrap a real [com.powersync.PowerSyncDatabase]; tests use a
 * fake. Only the two methods [ServerCaptureSource] needs are exposed.
 */
internal interface PowerSyncClient {
    /**
     * Subject-scoped watch over `sdk_captures`. The returned flow
     * re-emits whenever PowerSync syncs a change (row inserted,
     * updated, or removed from the subscription).
     */
    fun watchCaptures(subjectRef: String): Flow<List<CaptureEntry>>

    suspend fun close()
}

/**
 * Factory that opens a [PowerSyncClient] bound to a particular
 * subject. Split out so unit tests can inject a fake without standing
 * up a real PowerSync instance.
 */
internal fun interface PowerSyncClientFactory {
    suspend fun open(subjectRef: String, connector: PowerSyncBackendConnector): PowerSyncClient
}

/**
 * [PowerSyncBackendConnector] impl that delegates credential fetches
 * to the integrator's [SdkAuthorizationProvider]. PowerSync calls
 * [fetchCredentials] on first connect and again near token expiry;
 * both go through the same path. Failures (network blip, integrator
 * backend hiccup) propagate to the cold flow's [retryWhen] in
 * [ServerCaptureSource], which logs via [SdkLogger] and reconnects
 * with capped-exponential backoff.
 *
 * The PowerSync endpoint is `<baseUrl>/powersync` — PowerSync is
 * reverse-proxied at that root path in every env (Traefik
 * `stripprefix=/powersync` in prod, the equivalent `router.mount` in
 * `bin/server_local.dart`). [TwinSkinConfig.baseUrl] is the API server's
 * scheme+host(+port) root; the SDK appends the API and PowerSync prefixes
 * itself. This avoids the trap where the server's view of its LAN-
 * reachable identity (e.g. `xaviers-mac-studio-342.local`) doesn't match
 * what the device was built to reach (e.g. an IP, when mDNS resolution is
 * unavailable on non-Pixel Android).
 *
 * `uploadData` is a no-op — the SDK only reads the sync stream.
 */
internal class SdkSessionConnector(
    private val subjectRef: String,
    baseUrl: String,
    private val authProvider: SdkAuthorizationProvider,
    private val logger: SdkLogger?,
) : PowerSyncBackendConnector() {

    private val endpoint: String = "${baseUrl.trimEnd('/')}/powersync"
    private val credentialMutex = Mutex()
    private var credentialFailures = 0

    override suspend fun fetchCredentials(): PowerSyncCredentials = credentialMutex.withLock {
        try {
            val parsed = authProvider.fetchAndParseSessionToken(subjectRef, logger)
            credentialFailures = 0
            PowerSyncCredentials(endpoint = endpoint, token = parsed.token, userId = null)
        } catch (error: CancellationException) {
            throw error
        } catch (error: Exception) {
            // PowerSync can retry credentials without restarting the outer watch flow.
            val waitMs = min(30_000L, 1_000L shl min(credentialFailures, 5))
            credentialFailures = min(credentialFailures + 1, 5)
            delay(waitMs)
            throw error
        }
    }

    override suspend fun uploadData(database: com.powersync.PowerSyncDatabase) {
        // No-op — the SDK is a read-only consumer of `sdk_captures`.
    }
}

/**
 * One row of the server-state watch. Field names mirror the sync-rule
 * columns in `packages/server/powersync/sync_rules.yaml`. Only the
 * fields the SDK currently translates into [CaptureState] are parsed;
 * adding more is cheap when a future feature needs them.
 */
internal data class ServerCaptureRow(
    val id: String,
    val subjectRef: String,
    val status: String,
    val errorReason: String?,
    val lastAdvancedAtEpochMs: Long,
    val referenceImageKey: String?,
    val resultPreview3dGlbKey: String?,
    /** Raw JSON text from `sdk_captures.latest_annotation` — the server's authoritative current annotation; null when none submitted yet. */
    val annotationJson: String?,
    /** Raw JSON text from `sdk_measurements.result` at `latest_measurement_revision`; null when no measure has succeeded yet. */
    val resultJson: String?,
    /** True iff a measure step for a newer revision is queued or in flight. SQL-derived in the watch query. */
    val isMeasurementCalculating: Boolean,
    /** Raw JSON text from `sdk_captures.custom` — the host's free-form per-capture metadata; null when none / column absent. */
    val customJson: String? = null,
    /** Host-supplied capture group from `sdk_captures.capture_group`; null when ungrouped. */
    val captureGroup: String? = null,
    /** Capture condition type from `sdk_captures.condition_type`; null when the column is absent (legacy / unsynced rows). */
    val conditionType: ConditionType? = null,
    /** Raw JSON text from `sdk_captures.result_preview_3d_marker_view`; null until marker localization succeeds (or never, for captures without a visual 3D model). */
    val markerViewJson: String? = null,
    /** `sdk_captures.captured_at`; null until the server has decrypted the bundle. */
    val capturedAtEpochMs: Long? = null,
) {
    fun toCaptureEntry(logger: SdkLogger? = null): CaptureEntry = CaptureEntry(
        captureId = id,
        subjectRef = subjectRef,
        state = statusToState(status, errorReason, logger),
        updatedAtEpochMs = lastAdvancedAtEpochMs,
        referenceImageKey = referenceImageKey,
        resultPreview3dGlbKey = resultPreview3dGlbKey,
        latestAnnotation = parseAnnotationOrNull(annotationJson, logger),
        latestMeasurement = parseMeasurementOrNull(resultJson, logger),
        isMeasurementCalculating = isMeasurementCalculating,
        custom = parseCustomJsonOrNull(customJson, logger),
        captureGroup = captureGroup,
        conditionType = conditionType,
        markerView = parseMarkerViewOrNull(markerViewJson, logger),
        capturedAtEpochMs = capturedAtEpochMs,
    )
}

/** Wire-string → [ConditionType]; null/unknown maps to null (no crash on legacy rows). */
internal fun parseConditionTypeOrNull(wire: String?): ConditionType? = when (wire) {
    "wound" -> ConditionType.Wound
    "generic" -> ConditionType.Generic
    "scar" -> ConditionType.Scar
    else -> null
}

private val sdkJson: Json = Json { ignoreUnknownKeys = true }

/**
 * Coerce a JSON value to a plain string for [CaptureEntry.custom]: a string
 * primitive unwraps to its content, anything else falls back to its JSON text.
 * `custom` is flat `Map<String, String>` at the facade, so the fallback only
 * guards a server row holding richer JSON.
 */
internal fun jsonElementToCustomString(element: JsonElement): String =
    (element as? JsonPrimitive)?.takeIf { it.isString }?.content ?: element.toString()

/** [Map] of `JsonElement` values (local request `custom`) → flat string map; null/empty → null. */
internal fun customFromJsonElements(map: Map<String, JsonElement>?): Map<String, String>? =
    map?.takeIf { it.isNotEmpty() }?.mapValues { (_, v) -> jsonElementToCustomString(v) }

/** Parse `sdk_captures.custom` JSON text → flat string map; null/blank/invalid/empty → null. */
internal fun parseCustomJsonOrNull(raw: String?, logger: SdkLogger?): Map<String, String>? {
    if (raw.isNullOrBlank()) return null
    return try {
        customFromJsonElements(sdkJson.parseToJsonElement(raw).jsonObject)
    } catch (t: Throwable) {
        logger?.warn("Failed to parse sdk_captures.custom: $raw", t)
        null
    }
}

private fun parseAnnotationOrNull(raw: String?, logger: SdkLogger?): SdkAnnotation? {
    if (raw.isNullOrBlank()) return null
    return try {
        sdkJson.decodeFromString(SdkAnnotation.serializer(), raw)
    } catch (t: Throwable) {
        logger?.warn("Failed to parse sdk_measurements.annotation: $raw", t)
        null
    }
}

private fun parseMeasurementOrNull(raw: String?, logger: SdkLogger?): SdkMeasurement? {
    if (raw.isNullOrBlank()) return null
    return try {
        sdkJson.decodeFromString(SdkMeasurement.serializer(), raw)
    } catch (t: Throwable) {
        logger?.warn("Failed to parse sdk_measurements.result: $raw", t)
        null
    }
}

@Serializable
private data class MarkerViewWire(
    @SerialName("marker_center") val markerCenter: Vector3Wire,
    @SerialName("fov_y_deg") val fovYDeg: Double,
    @SerialName("fov_x_deg") val fovXDeg: Double? = null,
    @SerialName("camera_distance") val cameraDistance: Double,
)

@Serializable
private data class Vector3Wire(val x: Double, val y: Double, val z: Double)

internal fun parseMarkerViewOrNull(raw: String?, logger: SdkLogger?): Model3DViewMetadata? {
    if (raw.isNullOrBlank()) return null
    return try {
        val wire = sdkJson.decodeFromString(MarkerViewWire.serializer(), raw)
        Model3DViewMetadata(
            markerCenter = Vector3(
                wire.markerCenter.x.toFloat(),
                wire.markerCenter.y.toFloat(),
                wire.markerCenter.z.toFloat(),
            ),
            fovYDeg = wire.fovYDeg.toFloat(),
            fovXDeg = wire.fovXDeg?.toFloat(),
            cameraDistance = wire.cameraDistance.toFloat(),
        )
    } catch (t: Throwable) {
        logger?.warn("Failed to parse sdk_captures.result_preview_3d_marker_view: $raw", t)
        null
    }
}

/**
 * Map a row of `sdk_captures.status` (Postgres enum
 * `sdk_capture_status`: queued | in_progress | completed | failed) to
 * the SDK's coarse public [CaptureState]. The DB enum has no
 * `cancelled` — cancellation is a local-only concept surfaced by the
 * on-device observer.
 *
 * An unknown status string is treated as [CaptureState.Analyzing]
 * (optimistic — the SDK is almost certainly behind the server, which
 * has added a new intermediate status). The event is logged so a
 * watchful integrator sees the drift before it bites. Defaulting to
 * `Failed` here would falsely alarm users every time the server ships
 * a new transient state — never worth the blast radius.
 */
internal fun statusToState(
    status: String,
    errorReason: String?,
    logger: SdkLogger? = null,
): CaptureState =
    when (status) {
        "queued", "in_progress" -> CaptureState.Analyzing
        "completed" -> CaptureState.Succeeded
        "failed" -> CaptureState.Failed(
            stage = FailureStage.Server,
            message = errorReason,
        )
        else -> {
            logger?.warn(
                "Unknown sdk_captures.status '$status' — treating as Analyzing. " +
                    "SDK may be behind server.",
            )
            CaptureState.Analyzing
        }
    }

/**
 * Watch query used by concrete [PowerSyncClient] impls that wrap a
 * real `PowerSyncDatabase`. Exposed so platform-specific wiring
 * doesn't duplicate the SQL string and can share a mapper that turns
 * cursor rows into [ServerCaptureRow] → [CaptureEntry].
 *
 * Annotation comes from `sdk_captures.latest_annotation` (the parent
 * row's authoritative current value); result comes from the joined
 * `sdk_measurements` row at the latest successfully-measured revision.
 * `is_measurement_calculating` is an EXISTS check for a pending
 * (queued/in_progress) measurement at a revision newer than the
 * current pointer — true precisely when the user-visible measurement
 * is older than the displayed annotation.
 *
 * This projection is pinned against in-memory SQLite by
 * `WatchSdkCapturesSqlTest` (jvmTest); the server-side state it reads
 * is exercised end-to-end in
 * `packages/server/test/sdk/sdk_pipeline_test.dart`.
 */
internal fun watchSdkCapturesSql(): String =
    "SELECT c.id, c.subject_ref, c.status, c.error_reason, c.last_advanced_at, " +
        "c.result_reference_image_key, c.result_preview_3d_glb_key, " +
        "c.latest_annotation AS annotation, " +
        "m.result AS result, " +
        "EXISTS(" +
        "  SELECT 1 " +
        "  FROM ${SdkCapturePowerSyncSchema.SDK_MEASUREMENTS_TABLE} pm " +
        "  WHERE pm.capture_id = c.id " +
        "    AND pm.status IN ('queued', 'in_progress') " +
        "    AND (c.latest_measurement_revision IS NULL " +
        "         OR pm.revision > c.latest_measurement_revision)" +
        ") AS is_measurement_calculating, " +
        "c.condition_type AS condition_type, " +
        "c.result_preview_3d_marker_view AS marker_view, " +
        "c.custom AS custom, " +
        "c.capture_group AS capture_group, " +
        "c.captured_at AS captured_at " +
        "FROM ${SdkCapturePowerSyncSchema.SDK_CAPTURES_TABLE} c " +
        "LEFT JOIN ${SdkCapturePowerSyncSchema.SDK_MEASUREMENTS_TABLE} m " +
        "  ON m.capture_id = c.id AND m.revision = c.latest_measurement_revision " +
        "ORDER BY c.last_advanced_at DESC"
