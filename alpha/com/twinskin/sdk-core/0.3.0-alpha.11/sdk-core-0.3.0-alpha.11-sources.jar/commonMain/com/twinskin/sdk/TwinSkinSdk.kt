@file:OptIn(TwinSkinInternalApi::class)

package com.twinskin.sdk

import com.twinskin.sdk.capture.CaptureEntry
import com.twinskin.sdk.capture.CaptureObserver
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.PendingUpload
import com.twinskin.sdk.capture.PhotoSeries
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider
import com.twinskin.sdk.sdk_client.fetchAndParseSessionToken
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.view.CaptureSource
import com.twinskin.sdk.view.ViewCaptureSession
import com.twinskin.sdk.view.resolvers.CaptureIdResolver
import com.twinskin.sdk.view.resolvers.HttpGlbResolver
import com.twinskin.sdk.view.resolvers.LocalGlbResolver
import kotlin.concurrent.Volatile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow

/**
 * Public façade for the TwinSkin SDK. Host apps only touch two entry
 * points:
 *
 * - `initialize(...)` — called once from the application entry point
 *   (Android: `fun TwinSkinSdk.initialize(app, config)` from androidMain;
 *   iOS: `fun TwinSkinSdk.initialize(config)` from iosMain).
 * - [startCapture] — open a fresh capture session, defaulting to the
 *   init-time [CaptureMode] or overriding it per capture; the mode's
 *   capture screen drives it.
 *
 * Everything inside the SDK is wired via constructor-injected components
 * (see [TwinSkinSdkComponent]). This object is only the final façade so
 * integrators don't have to assemble the graph themselves.
 */
public object TwinSkinSdk {
    /**
     * The installed wiring graph, or `null` before [initialize]. A
     * [MutableStateFlow] rather than a plain `@Volatile var` so the
     * observation surface ([captures]) can *await* init reactively
     * instead of throwing — see [DeferredCaptureObserver]. Reads that
     * genuinely require an initialized SDK still go through
     * [requireComponent], which throws as before.
     */
    private val componentState = MutableStateFlow<TwinSkinSdkComponent?>(null)

    private val component: TwinSkinSdkComponent?
        get() = componentState.value

    @Volatile
    private var localeOverride: LocaleOverride? = null

    /** Open a new capture session. The server is only contacted when the session is submitted. */
    public fun startCapture(metadata: SdkCaptureMetadata): CaptureSession =
        requireComponent().captureApi.startCapture(metadata)

    /**
     * [startCapture] with a per-capture [CaptureMode] override. `null` falls
     * back to the init-time mode; the override goes through
     * [resolveCaptureMode].
     */
    public fun startCapture(
        metadata: SdkCaptureMetadata,
        captureMode: CaptureMode?,
    ): CaptureSession =
        requireComponent().captureApi.startCapture(
            metadata,
            sessionMode = resolveCaptureMode(captureMode),
        )

    /**
     * Submit a photo series the host app took, for the skin analysis: no capture
     * screen is involved. Packs the stills into an encrypted bundle and hands it
     * to the background upload, as a capture screen's submit does, and returns
     * the capture's session once the bundle is on disk. Follow the upload on
     * the session, or through [captures].
     *
     * The capture runs as [com.twinskin.sdk.capture.Analysis.Generic]: a photo
     * series is never outlined. The stills are read, never moved or deleted.
     *
     * Throws [IllegalArgumentException] for a series the server would refuse;
     * see [PhotoSeries].
     */
    @TwinSkinInternalApi
    @Throws(CancellationException::class, Exception::class)
    public suspend fun submitStills(
        metadata: SdkCaptureMetadata,
        series: PhotoSeries,
    ): CaptureSession = requireComponent().captureApi.submitStills(metadata, series)

    /**
     * The mode a [startCapture] call with [requested] would run — the runtime
     * twin of [TwinSkinConfig.effectiveCaptureMode]: [requested], falling back
     * to the init-time mode on `null`.
     */
    public fun resolveCaptureMode(requested: CaptureMode?): CaptureMode =
        resolveCaptureMode(initMode = requireComponent().captureMode, requested = requested)

    /**
     * Observe captures known to this SDK instance. The returned [CaptureObserver]
     * is a read-only view; it never drives capture lifecycle. See
     * [CaptureObserver.observePendingUploads] for the canonical use case
     * (background upload progress UI).
     *
     * Safe to read and collect before [initialize]: the returned observer is a
     * cold facade whose flows suspend until the SDK is initialized, then begin
     * emitting. This is what lets an integrator wire observation at app launch
     * (or navigate to a subject-scoped screen) without ordering it after init —
     * matching the SDK's lazy-init contract. Before this facade existed, reading
     * `captures` before init threw, which on iOS crossed the Kotlin/Native →
     * Swift boundary from a non-`@Throws` getter and aborted the host process.
     */
    public val captures: CaptureObserver
        get() = DeferredCaptureObserver

    /**
     * [CaptureObserver] facade that defers to the installed
     * [TwinSkinSdkComponent.captureObserver] once init lands. Each returned
     * flow is cold: on collection it awaits the first non-null component
     * ([awaitComponent]) and then streams the real observer's flow verbatim.
     * A collector started before init simply parks until the component is
     * installed; if the SDK is never initialized (e.g. an integrator whose
     * server config never arrives) the flow stays open and silent rather than
     * throwing.
     */
    private object DeferredCaptureObserver : CaptureObserver {
        override fun observePendingUploads(): Flow<List<PendingUpload>> =
            flow { emitAll(awaitComponent().captureObserver.observePendingUploads()) }

        override fun observeSubject(subjectRef: String): Flow<List<CaptureEntry>> =
            flow { emitAll(awaitComponent().captureObserver.observeSubject(subjectRef)) }

        override fun observeCapture(captureId: String, subjectRef: String): Flow<CaptureEntry?> =
            flow { emitAll(awaitComponent().captureObserver.observeCapture(captureId, subjectRef)) }
    }

    private suspend fun awaitComponent(): TwinSkinSdkComponent =
        componentState.filterNotNull().first()

    /**
     * `true` when [TwinSkinConfig.devMode] was set on init. Read by the
     * built-in capture screens to decide whether to surface the
     * "Use demo capture" affordance.
     */
    public val devMode: Boolean
        get() = requireComponent().devMode

    /**
     * `true` when [TwinSkinConfig.verboseFrameLogs] was set on init.
     * Read by the photosphere capture screens to decide whether to
     * write the on-device diagnostic sidecars — see the field on
     * [TwinSkinConfig] for the full list + storage footprint.
     */
    public val verboseFrameLogs: Boolean
        get() = requireComponent().verboseFrameLogs

    public val captureMode: CaptureMode
        get() = requireComponent().captureMode

    /**
     * The pinned locale, or `null` for "follow the device". A [setLocale] call
     * wins over the init-time [TwinSkinConfig.locale] — including
     * `setLocale(null)`, which selects the device locale, not the config one.
     * The string layer reads this via [com.twinskin.sdk.i18n.sdkLocale] and
     * falls back to the device locale when it is `null`. Non-throwing so string
     * resolution stays safe outside an initialized SDK.
     */
    internal val configuredLocale: String?
        get() = resolveConfiguredLocale(localeOverride, component?.locale)

    /**
     * Set the SDK UI locale at runtime, for any built-in SDK screen (capture +
     * annotation editor) opened *after* this call — screens already on-screen
     * keep their resolved locale until reopened. Pass a language tag such as
     * `"fr"`, or `null` to follow the device locale; either value replaces the
     * init-time [TwinSkinConfig.locale]. Thread-safe and safe to call before
     * `initialize(...)`. See `packages/sdk/docs/translations.md`.
     */
    public fun setLocale(locale: String?) {
        localeOverride = LocaleOverride(locale)
    }

    /** Diagnostic surface — see [TwinSkinDebug]. */
    @TwinSkinInternalApi
    public val debug: TwinSkinDebug
        get() = TwinSkinDebug(requireComponent())

    /**
     * View a previously-captured 3D model. Returns a [ViewCaptureSession] whose
     * `state` StateFlow the host Compose screen observes. Close the session
     * when the screen is torn down.
     */
    public fun viewCapture(source: CaptureSource): ViewCaptureSession {
        val component = requireComponent()
        val resolver = when (source) {
            is CaptureSource.LocalGlb -> LocalGlbResolver(source.path)
            is CaptureSource.GlbUrl -> HttpGlbResolver(
                url = source.url,
                cacheDir = component.storage.dir(Purpose.ViewCapture),
                headersProvider = source.headersProvider,
                logger = component.logger,
            )
            is CaptureSource.CaptureId -> {
                val serverClient = component.serverClient
                CaptureIdResolver(
                    captureId = source.id,
                    subjectRef = source.subjectRef,
                    captureObserver = component.captureObserver,
                    assetUrlBuilder = { s3Key ->
                        // The /asset redirect endpoint is session-token authenticated.
                        // The 302 target is a presigned S3 URL that expects no auth —
                        // headers are stripped on redirect by `downloadToPath`.
                        val tokens = serverClient.auth.fetchAndParseSessionToken(
                            source.subjectRef,
                            component.logger,
                        )
                        val url = "${serverClient.apiBaseUrl}/asset?key=$s3Key"
                        val headers = mapOf(
                            io.ktor.http.HttpHeaders.Authorization to "Bearer ${tokens.token}",
                            "X-Publishable-Key" to serverClient.publishableKey,
                        )
                        url to headers
                    },
                    cacheDir = component.storage.dir(com.twinskin.sdk.storage.Purpose.ViewCapture),
                    downloadAsset = { url, destPath, headers ->
                        com.twinskin.sdk.view.downloadToPath(
                            url = url,
                            destPath = destPath,
                            headers = headers,
                            onProgress = { _, _ -> },
                        )
                    },
                    logger = component.logger,
                )
            }
        }
        return ViewCaptureSession(resolver, logger = component.logger)
    }

    /**
     * Idempotent: a second call is a no-op so hosts that (for example) wire
     * initialization from both an `Application` and a splash screen don't have
     * to guard it themselves. Any [TwinSkinSdkComponent] built for the second
     * call is discarded. Config changes on a repeat `initialize` are handled
     * before this point by [reconcileRepeatInitialize].
     */
    internal fun install(built: TwinSkinSdkComponent): Boolean =
        componentState.compareAndSet(null, built)

    /**
     * Reconciles a repeat `initialize` call against the installed component.
     * Returns `null` when the SDK is not initialized yet — the caller proceeds
     * with a fresh install. Otherwise applies what can change on a live
     * component — the publishable key (read per request by [SdkServerClient])
     * and the authorization provider (rebound through the component's
     * delegating wrapper) — logs any change that would need a rebuild, and
     * returns the decision so the caller skips the rebuild.
     *
     * The in-place key swap is load-bearing: hosts wire `initialize` to a
     * synced config stream, and the first emission can be a stale local value
     * that a later sync corrects (or the key can rotate server-side).
     * First-call-wins semantics would pin the dead key for the whole process —
     * every session-authed HTTP call 403s while the PowerSync feed (JWT-only)
     * keeps working, which presents as broken uploads/assets with a healthy
     * capture list.
     */
    internal fun reconcileRepeatInitialize(config: TwinSkinConfig): RepeatInitReconciliation? {
        val existing = component ?: return null
        val decision = decideRepeatInitialize(
            existingPublishableKey = existing.serverClient.publishableKey,
            existingBaseUrl = existing.serverClient.baseUrl,
            existingDevMode = existing.devMode,
            existingCaptureMode = existing.captureMode,
            existingLocale = existing.locale,
            config = config,
        )
        // Providers are host closures and not comparable, so a repeat call
        // always rebinds — the documented contract. Load-bearing for Flutter
        // add-to-app: the old closure dies with its engine, and only the
        // repeat initialize carries a live one.
        existing.authProvider?.rebind(config.authorizationProvider)
        decision.publishableKeyChangedTo?.let { newKey ->
            existing.serverClient.updatePublishableKey(newKey)
            existing.logger.warn(
                "TwinSkin SDK re-initialized with a changed publishable key; updated in place.",
            )
        }
        if (decision.rejectedChanges.isNotEmpty()) {
            existing.logger.error(
                "TwinSkin SDK is already initialized; changing " +
                    decision.rejectedChanges.joinToString(", ") +
                    " requires an app restart — keeping the existing configuration.",
            )
        }
        return decision
    }

    /**
     * Whether [initialize] has run in this process. SDK-owned Android
     * activities consult this on create: after a background process
     * death the system restores them before the host app re-initializes
     * the SDK, and composing against a missing component would crash.
     */
    public val isInitialized: Boolean get() = component != null

    internal fun requireComponent(): TwinSkinSdkComponent =
        component ?: error("TwinSkinSdk.initialize(...) must be called before using the SDK.")

    /** For tests only — clears the installed component so the next `initialize` succeeds. */
    internal fun resetForTests() {
        componentState.value = null
        localeOverride = null
    }
}

/**
 * A [TwinSkinSdk.setLocale] call, boxed so "never called" (no box) is
 * distinguishable from "called with `null`" (box holding null = device
 * locale).
 */
internal class LocaleOverride(val value: String?)

internal fun resolveConfiguredLocale(
    override: LocaleOverride?,
    configLocale: String?,
): String? = if (override != null) override.value else configLocale

/**
 * Pure decision behind [TwinSkinSdk.resolveCaptureMode]. Photosphere is
 * retired: both presenters show the accelerometer screen for it, whose
 * video-shaped submit would fail the session's mode-match guard unless the
 * session is stamped AccelerometerCapture too.
 */
internal fun resolveCaptureMode(
    initMode: CaptureMode,
    requested: CaptureMode?,
): CaptureMode = when (val mode = requested ?: initMode) {
    CaptureMode.Photosphere -> CaptureMode.AccelerometerCapture
    else -> mode
}

/**
 * Outcome of a repeat `initialize`: what was applied to the live component
 * vs what would need an app restart.
 */
internal data class RepeatInitReconciliation(
    val publishableKeyChangedTo: String?,
    val rejectedChanges: List<String>,
)

/**
 * Pure decision behind [TwinSkinSdk.reconcileRepeatInitialize]: compares a
 * repeat-`initialize` config against the installed component's effective
 * values. The publishable key is the only field a live component can adopt;
 * everything else is baked into already-constructed collaborators and is
 * reported as rejected. `logger`/`logLevel` changes are deliberately ignored
 * (diagnostics wiring, not behavior).
 */
internal fun decideRepeatInitialize(
    existingPublishableKey: String,
    existingBaseUrl: String,
    existingDevMode: Boolean,
    existingCaptureMode: CaptureMode,
    existingLocale: String?,
    config: TwinSkinConfig,
): RepeatInitReconciliation = RepeatInitReconciliation(
    publishableKeyChangedTo = config.publishableKey
        .takeIf { it != existingPublishableKey },
    rejectedChanges = buildList {
        // The SDK is slash-insensitive on baseUrl (apiBaseUrl trims), so an
        // equivalent URL differing only by a trailing slash is not a change.
        if (config.baseUrl.trimEnd('/') != existingBaseUrl.trimEnd('/')) add("baseUrl")
        if (config.devMode != existingDevMode) add("devMode")
        if (config.effectiveCaptureMode != existingCaptureMode) add("captureMode")
        if (config.locale != existingLocale) add("locale")
    },
)

/**
 * Integrator-supplied configuration. [baseUrl] is the Twinskin API server's
 * scheme+host(+port) root — e.g. `https://prod.dermatoo.com` — and defaults
 * to production; demo / local-dev hosts pass an override. The SDK appends
 * `/api/sdk` for API calls and `/powersync` for the realtime stream itself,
 * so integrators only configure the host once.
 */
public data class TwinSkinConfig @TwinSkinInternalApi constructor(
    val publishableKey: String,
    val authorizationProvider: SdkAuthorizationProvider,
    val baseUrl: String = PROD_BASE_URL,
    /** `null` → [SdkLogger.Console]; pass [SdkLogger.None] to silence. */
    val logger: SdkLogger? = null,
    /** Minimum level reaching [logger]; `null` → [effectiveLogLevel]. */
    val logLevel: SdkLogLevel? = null,
    /**
     * When true, the camera screen surfaces a "Use demo capture" button that
     * downloads a server-served capture and submits it through the normal
     * upload pipeline. Intended for QA / demo / integrator-test builds; leave
     * `false` in production.
     */
    val devMode: Boolean = false,
    /**
     * Umbrella opt-in for the SDK's on-device diagnostic sidecars:
     * `frame_log.jsonl`, `pose_log.json`, `reference_keypoints.json`,
     * and the per-Nth analyser-frame grayscale JPEGs under
     * `live_frames/`. None of these ever ride the encrypted upload
     * bundle (the tar packer whitelists `view_NN_rXaY.jpg` only), but
     * when `true` they accumulate ~25–120 MB per capture in the app
     * sandbox. Default `false` so a Release build is silent on disk;
     * integrators flip it on for field-issue triage.
     */
    val verboseFrameLogs: Boolean = false,
    /**
     * Which capture pipeline `startCapture` launches when the call carries
     * no per-capture override. Default
     * [CaptureMode.AccelerometerCapture] (the Capture V2 fallback —
     * accelerometer + video — pipeline); [CaptureMode.Photosphere] opts
     * into the marker-validated photosphere screen. The mode resolved for
     * each session is stamped on its persisted capture row so the upload
     * pipeline can pick the matching bundle layout long after the
     * originating session has ended.
     */
    val captureMode: CaptureMode = CaptureMode.AccelerometerCapture,
    /**
     * Integrator locale override for the SDK's built-in UI (capture screens and
     * annotation editor). `null` (default) uses the device locale. A language
     * tag such as `"fr"`; the SDK falls back to English for any locale it does
     * not ship yet. See `packages/sdk/docs/translations.md`.
     */
    val locale: String? = null,
    /**
     * **Dev/test only.** When [devMode] is `true` and this provider returns a
     * positive byte count, the capture pipeline appends an extra
     * `debug_padding.bin` entry of that size to the encrypted bundle before
     * upload — a way to exercise large-bundle upload resilience without
     * producing a real capture that big. The entry is deliberately kept out
     * of the manifest so only the upload path carries it. Invoked once per
     * submit. `null` (default) and non-dev builds inject nothing.
     */
    @property:TwinSkinInternalApi
    val debugBundlePaddingBytesProvider: (() -> Long)? = null,
) {
    public constructor(
        publishableKey: String,
        authorizationProvider: SdkAuthorizationProvider,
        baseUrl: String = PROD_BASE_URL,
        logger: SdkLogger? = null,
        logLevel: SdkLogLevel? = null,
        devMode: Boolean = false,
        verboseFrameLogs: Boolean = false,
        captureMode: CaptureMode = CaptureMode.AccelerometerCapture,
        locale: String? = null,
    ) : this(
        publishableKey = publishableKey,
        authorizationProvider = authorizationProvider,
        baseUrl = baseUrl,
        logger = logger,
        logLevel = logLevel,
        devMode = devMode,
        verboseFrameLogs = verboseFrameLogs,
        captureMode = captureMode,
        locale = locale,
        debugBundlePaddingBytesProvider = null,
    )

    /**
     * The init-time default mode actually installed. Per-capture overrides
     * resolve the same way via [TwinSkinSdk.resolveCaptureMode].
     */
    internal val effectiveCaptureMode: CaptureMode
        get() = resolveCaptureMode(initMode = captureMode, requested = null)

    /**
     * Resolved padding-byte source for the capture pipeline. Inert (always
     * `0`) unless [devMode] is set and a provider was supplied, so the
     * injection is unreachable in a production build regardless of the
     * field value. Negative provider results are clamped to `0`.
     */
    internal val effectiveDebugBundlePaddingBytes: () -> Long
        @OptIn(TwinSkinInternalApi::class)
        get() {
            val provider = debugBundlePaddingBytesProvider
            return if (devMode && provider != null) {
                { provider().coerceAtLeast(0L) }
            } else {
                { 0L }
            }
        }

    /** Explicit [logLevel], else [SdkLogLevel.Debug] in dev / [SdkLogLevel.Warning] in prod. */
    internal val effectiveLogLevel: SdkLogLevel
        get() = logLevel ?: if (devMode) SdkLogLevel.Debug else SdkLogLevel.Warning

    internal val effectiveLogger: SdkLogger
        get() = LevelFilteringLogger(effectiveLogLevel, logger ?: SdkLogger.Console)

    public companion object {
        public const val PROD_BASE_URL: String = "https://prod.dermatoo.com"
    }
}
