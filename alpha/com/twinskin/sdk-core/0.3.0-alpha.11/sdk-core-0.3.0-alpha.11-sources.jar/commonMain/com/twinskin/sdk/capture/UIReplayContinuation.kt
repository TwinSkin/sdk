package com.twinskin.sdk.capture

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.crypto.sha256
import com.twinskin.sdk.capture.crypto.sha256File
import com.twinskin.sdk.capture.io.canonicalPath
import com.twinskin.sdk.capture.io.deleteFileQuietly
import com.twinskin.sdk.capture.io.ensureDir
import com.twinskin.sdk.capture.io.fileSize
import com.twinskin.sdk.capture.io.listDir
import com.twinskin.sdk.capture.io.readBytes
import com.twinskin.sdk.capture.io.readFileStreaming
import com.twinskin.sdk.capture.io.renameFile
import com.twinskin.sdk.sdk_client.ConfirmUiReplayContinuationRequest
import com.twinskin.sdk.sdk_client.SdkServerClient
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.transfer.TransferManager
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.currentTimeMillis
import com.twinskin.sdk.warn
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.random.Random
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

internal const val UI_REPLAY_MAXIMUM_BYTES: Long = 72L * 1024 * 1024
internal const val UI_REPLAY_OUTBOX_MAXIMUM_BYTES: Long = 256L * 1024 * 1024
internal const val UI_REPLAY_UPLOAD_PREFIX: String = "ui-replay:"
private val manifestJson = Json { encodeDefaults = true }
private val CAPTURE_ID = Regex("tsc_[A-Za-z0-9]{16,32}")
private val TRACE_ID = Regex("[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}")
private val DIGEST = Regex("[a-f0-9]{64}")
private val ASSET = Regex("(image-[A-Fa-f0-9-]{36}\\.png|recovery-[A-Fa-f0-9-]{36}\\.jpg|selection-[A-Fa-f0-9-]{36}\\.json)")

internal data class UIReplayUploadKey(val captureId: String, val traceId: String, val cipherSha256: String, val size: Long) {
    val wire: String get() = "$UI_REPLAY_UPLOAD_PREFIX$captureId:$traceId:$cipherSha256:$size"

    companion object {
        fun parse(value: String): UIReplayUploadKey? {
            val parts = value.split(':')
            if (parts.size != 5 || parts[0] != "ui-replay") return null
            val size = parts[4].toLongOrNull() ?: return null
            if (!CAPTURE_ID.matches(parts[1]) || !TRACE_ID.matches(parts[2]) || !DIGEST.matches(parts[3]) ||
                size !in 1..UI_REPLAY_MAXIMUM_BYTES) return null
            return UIReplayUploadKey(parts[1], parts[2], parts[3], size)
        }
    }
}

@Serializable
internal data class UIReplayContinuationFile(val name: String, val sizeBytes: Long, val sha256: String)

@Serializable
internal data class UIReplayContinuationManifest(
    val schemaVersion: Int = 1,
    val kind: String = "full_snapshot_continuation",
    val captureID: String,
    val traceID: String,
    val files: List<UIReplayContinuationFile>,
    val sourceStatus: JsonObject,
)

internal class UIReplayContinuationOutbox(
    private val directory: () -> String,
    private val encryptor: BundleEncryptor,
    private val store: SdkCaptureStore,
    private val transfers: TransferManager,
    private val client: SdkServerClient,
    private val database: TwinSkinDatabase,
    private val logger: SdkLogger = SdkLogger.None,
    private val clock: () -> Long = ::currentTimeMillis,
) {
    private val mutex = admissionMutex

    private companion object { val admissionMutex = Mutex() }

    suspend fun submit(session: CaptureSession, traceId: String, source: String): String = mutex.withLock {
        require(CAPTURE_ID.matches(session.id) && TRACE_ID.matches(traceId.lowercase())) { "Invalid replay identity" }
        val parent = store.findById(session.id) ?: error("Capture must be submitted before its replay continuation")
        require(parent.request.userRef == session.metadata.userRef && parent.request.subjectRef == session.metadata.subjectRef) {
            "Replay parent scope differs"
        }
        require(source.startsWith('/')) { "Replay source must be an absolute directory" }
        val root = canonicalPath(source)
        val names = listDir(root).filter { it != "delivery-state.json" }.sorted()
        require(names.size in 2..130 && "events.jsonl" in names && "status.json" in names) { "Invalid replay files" }
        val started = clock()
        var total = 0L
        val files = names.map { name ->
            require(name == "events.jsonl" || name == "status.json" || ASSET.matches(name)) { "Unsupported replay asset" }
            val path = "$root/$name"
            require(canonicalPath(path) == path) { "Replay assets must be direct regular files" }
            val size = fileSize(path)
            val limit = when (name) {
                "events.jsonl" -> 32L * 1024 * 1024
                "status.json" -> 64L * 1024
                else -> 32L * 1024 * 1024
            }
            require(size in 0..limit && (name != "status.json" || size > 0)) { "Replay file budget exceeded" }
            total += size
            require(total <= 65L * 1024 * 1024 && clock() - started <= 120_000) { "Replay snapshot budget exceeded" }
            val hash = sha256File(path).hex()
            require(clock() - started <= 120_000) { "Replay staging time budget exceeded" }
            UIReplayContinuationFile(name, size, hash)
        }
        val status = Json.parseToJsonElement(readBytes("$root/status.json").decodeToString()).jsonObject
        require(status["traceID"]?.jsonPrimitive?.contentOrNull?.lowercase() == traceId.lowercase() &&
            status["schemaVersion"]?.jsonPrimitive?.contentOrNull == "2" &&
            status["checkpointKind"]?.jsonPrimitive?.contentOrNull == "final") { "Replay must be a matching final snapshot" }
        val manifest = UIReplayContinuationManifest(captureID = session.id, traceID = traceId,
            files = files, sourceStatus = status)
        val manifestBytes = manifestJson.encodeToString(manifest).encodeToByteArray()
        val snapshotHash = sha256(manifestBytes).hex()
        val outbox = directory().also(::ensureDir)
        val prefix = "${session.id}.${traceId.lowercase()}.$snapshotHash."
        val existing = listDir(outbox).firstOrNull { it.startsWith(prefix) && it.endsWith(".bin") }
        if (existing != null) return@withLock enqueue(outbox, existing)
        removeOrphanPartials(outbox)
        val staged = listDir(outbox)
        require(staged.size < 32) { "Replay outbox entry budget exceeded; retained uploads need confirmation" }
        val reserved = total + manifestBytes.size + names.size * 1024L + 4096
        val occupied = staged.sumOf { fileSize("$outbox/$it") }
        require(occupied + reserved <= UI_REPLAY_OUTBOX_MAXIMUM_BYTES) { "Replay outbox byte budget exceeded" }
        val temporary = "$outbox/$prefix${clock()}-${Random.nextLong().toULong().toString(16)}.partial"
        try {
            val sink = encryptor.openEncryptingSink(temporary)
            try {
                val tar = TarStoreSink(sink)
                tar.addEntry("ui_replay_continuation.json", manifestBytes.size.toLong()) { it.write(manifestBytes, 0, manifestBytes.size) }
                for (file in files) {
                    require(clock() - started <= 120_000) { "Replay staging time budget exceeded" }
                    tar.addEntry(file.name, file.sizeBytes) { target ->
                        readFileStreaming("$root/${file.name}") { bytes, offset, count ->
                            require(clock() - started <= 120_000) { "Replay staging time budget exceeded" }
                            target.write(bytes, offset, count)
                        }
                    }
                    require(sha256File("$root/${file.name}").hex() == file.sha256) { "Replay snapshot changed during staging" }
                }
                tar.finish()
            } finally { sink.close() }
            require(fileSize(temporary) <= UI_REPLAY_MAXIMUM_BYTES && clock() - started <= 120_000) {
                "Encrypted replay size or time budget exceeded"
            }
            val hash = sha256File(temporary).hex()
            require(clock() - started <= 120_000) { "Replay staging time budget exceeded" }
            val name = "$prefix$hash.bin"
            renameFile(temporary, "$outbox/$name")
            enqueue(outbox, name)
        } catch (error: Throwable) {
            deleteFileQuietly(temporary)
            throw error
        }
    }

    private suspend fun enqueue(root: String, name: String): String {
        val key = keyFor(root, name) ?: error("Invalid staged replay filename")
        val existing = database.transferTaskQueries.selectAll().executeAsList()
            .filter { it.url == key.wire }.maxByOrNull { it.updatedAt }
        if (existing != null) {
            when (existing.status) {
                TransferStatus.FAILED.name -> { transfers.retryTask(existing.id); return existing.id }
                TransferStatus.CANCELLED.name -> return existing.id
                TransferStatus.COMPLETED.name -> transfers.deleteTask(existing.id)
                else -> return transfers.upload("$root/$name", key.wire)
            }
        }
        return transfers.upload("$root/$name", key.wire)
    }

    private fun keyFor(root: String, name: String): UIReplayUploadKey? {
        val parts = name.split('.')
        if (parts.size != 5 || parts[4] != "bin" || !DIGEST.matches(parts[2])) return null
        val size = fileSize("$root/$name")
        return UIReplayUploadKey.parse("$UI_REPLAY_UPLOAD_PREFIX${parts[0]}:${parts[1]}:${parts[3]}:$size")
    }

    suspend fun recoverAndConfirmOnce(): Int = mutex.withLock {
        val root = directory().also(::ensureDir)
        removeOrphanPartials(root)
        var pending = 0
        for (name in listDir(root).take(32).sorted()) {
            if (!name.endsWith(".bin")) continue
            val key = keyFor(root, name) ?: continue
            val parent = store.findById(key.captureId)
            if (parent == null) { pending++; continue }
            try {
                val received = client.confirmUiReplayContinuation(ConfirmUiReplayContinuationRequest(
                    parent.request.userRef, parent.request.subjectRef, key.captureId, key.traceId, key.cipherSha256, key.size))
                if (received) {
                    val tasks = database.transferTaskQueries.selectAll().executeAsList().filter { it.url == key.wire }
                    if (tasks.any { it.status !in setOf(TransferStatus.COMPLETED.name, TransferStatus.FAILED.name,
                            TransferStatus.CANCELLED.name) }) { pending++; continue }
                    deleteFileQuietly("$root/$name")
                    for (task in tasks) transfers.deleteTask(task.id)
                    continue
                }
                enqueue(root, name)
                pending++
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                pending++
                logger.warn("Replay continuation retained; confirmation deferred", error)
            }
        }
        pending
    }

    private fun removeOrphanPartials(root: String) {
        for (name in listDir(root).take(32)) {
            val parts = name.split('.')
            if (parts.size == 5 && CAPTURE_ID.matches(parts[0]) && TRACE_ID.matches(parts[1]) &&
                DIGEST.matches(parts[2]) && Regex("[0-9]+-[a-f0-9]+").matches(parts[3]) && parts[4] == "partial") {
                deleteFileQuietly("$root/$name")
                logger.warn("Incomplete replay staging discarded; source snapshot remains retained")
            }
        }
    }

    suspend fun run(): Nothing {
        var backoff = 30_000L
        while (true) {
            try {
                backoff = if (recoverAndConfirmOnce() == 0) 30_000L else (backoff * 2).coerceAtMost(15 * 60_000L)
            } catch (error: CancellationException) { throw error }
            catch (error: Exception) {
                logger.warn("Replay continuation outbox deferred", error)
                backoff = (backoff * 2).coerceAtMost(15 * 60_000L)
            }
            delay(backoff)
        }
    }
}

internal fun ByteArray.hex(): String = joinToString("") { (it.toInt() and 255).toString(16).padStart(2, '0') }
