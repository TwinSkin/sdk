package com.twinskin.sdk.sdk_client

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.SdkCaptureStore
import com.twinskin.sdk.capture.UIReplayUploadKey
import com.twinskin.sdk.capture.iso8601ToEpochMillis
import com.twinskin.sdk.transfer.UrlResolver
import com.twinskin.sdk.transfer.UrlResult
import com.twinskin.sdk.transfer.currentTimeMillis
import com.twinskin.sdk.warn
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

internal fun uiReplayContinuationUrlResolver(
    store: SdkCaptureStore,
    client: SdkServerClient,
    logger: SdkLogger = SdkLogger.None,
    clock: () -> Long = ::currentTimeMillis,
): UrlResolver {
    val mutex = Mutex()
    val deferred = mutableMapOf<String, Pair<Long, Long>>()
    return resolver@{ uploadKey ->
        val key = UIReplayUploadKey.parse(uploadKey) ?: return@resolver UrlResult.RetryableError
        if (mutex.withLock { (deferred[uploadKey]?.first ?: 0) > clock() }) return@resolver UrlResult.RetryableError
        val parent = store.findById(key.captureId) ?: return@resolver UrlResult.RetryableError
        try {
            val response = client.requestUiReplayContinuationUpload(RequestUiReplayContinuationUploadRequest(
                parent.request.userRef, parent.request.subjectRef, key.captureId, key.traceId, key.cipherSha256, key.size))
            mutex.withLock { deferred.remove(uploadKey) }
            when {
                response.received -> UrlResult.AlreadyExist
                response.uploadUrl != null -> UrlResult.Url(response.uploadUrl,
                    response.uploadUrlExpiresAt?.let(::iso8601ToEpochMillis))
                else -> UrlResult.RetryableError
            }
        } catch (error: CancellationException) { throw error }
        catch (error: Exception) {
            mutex.withLock {
                val backoff = ((deferred[uploadKey]?.second ?: 15_000) * 2).coerceAtMost(15 * 60_000)
                if (deferred.size < 32 || uploadKey in deferred) deferred[uploadKey] = (clock() + backoff) to backoff
            }
            logger.warn("Replay continuation URL deferred; encrypted file retained", error)
            UrlResult.RetryableError
        }
    }
}
