@file:OptIn(ExperimentalMaterial3Api::class, com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui

import android.app.Activity
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.os.SystemClock
import android.util.Log
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.twinskin.photosphere.MarkerValidator
import com.twinskin.photosphere.PhotosphereState
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.DemoCaptureSummary
import com.twinskin.sdk.capture.PhotosphereCaptureDriver
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.capture.SdkReferenceLuminance
import com.twinskin.sdk.ui.capture.CameraSessionController
import com.twinskin.sdk.ui.capture.CameraSessionState
import com.twinskin.sdk.ui.capture.CaptureViewCopy
import com.twinskin.sdk.ui.capture.LIVE_MARKER_RECENT_HINT_MS
import com.twinskin.sdk.ui.capture.i18n.ProvideSdkCaptureStrings
import com.twinskin.sdk.ui.capture.PhotosphereExposureMode
import com.twinskin.sdk.ui.capture.PhotosphereFocusMode
import com.twinskin.sdk.ui.capture.PhotosphereFocusPolicy
import com.twinskin.sdk.ui.capture.REF_READY_DISPLAY_MS
import com.twinskin.sdk.ui.capture.RefMarkerWarning
import com.twinskin.sdk.ui.capture.RefMarkerWarningCard
import com.twinskin.sdk.ui.capture.RefRecommendation
import com.twinskin.sdk.ui.capture.RefShutterMessageOverlay
import com.twinskin.sdk.ui.capture.RefVerdictCard
import com.twinskin.sdk.ui.capture.RefVerdictChoice
import com.twinskin.sdk.ui.capture.BOTTOM_CHROME_PADDING_DP
import com.twinskin.sdk.ui.capture.RimbaudReplayFrameSource
import com.twinskin.sdk.ui.capture.XFeatPhotosphereOverlay
import com.twinskin.sdk.ui.capture.isInDemoOrSubmitFlow
import com.twinskin.sdk.ui.capture.isMarkerRecent
import com.twinskin.sdk.ui.capture.isRefShutterCapturing
import com.twinskin.sdk.ui.capture.shouldShowTutorial
import com.twinskin.sdk.ui.capture.tutorialReopenEnabled
import com.twinskin.sdk.ui.annotation_editor.toImageBitmap
import com.twinskin.sdk.ui.capture.rememberCapturePermissionsState
import com.twinskin.sdk.ui.photosphere_tutorial.PhotosphereTutorialOverlay
import com.twinskin.sdk.ui.photosphere_tutorial.PhotosphereTutorialPrefs
import com.twinskin.sdk.ui.post_submit.PostSubmitFlow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Native Android capture screen, backed by CameraX + XFeat
 *
 * STABLE:
 *   - The seam to the SDK upstream — `startSession`, `session.workingDir`,
 *     `session.submit(CaptureResult(...))`, `session.cancel()`, `session.fail(reason)`.
 *   - The public `(metadata, onDone, onCancel, startSession)` parameter shape
 *     is a hard gate — do not change.
 *
 * `CaptureProgressOverlay` (Round X / 4 + linear progress bar) with the
 * XFeat DemoApp's full per-arm capture UX:
 *   - 4-arm cross overlay (R1-R4 × 4 arms = 16 primary slots) anchored
 *     to screen centre; current-round arms highlighted; ghost-dashed
 *     prior rounds; green when committed, amber for the active target;
 *     orange live-cursor dot at `currentAzEstimate` whose radial offset
 *     scales with `currentTiltMagDeg / 20°`.
 *   - Progress legend below: R1 cardinals / R2 22.5° / R3 45° / R4 67.5°
 *     each with `●●○○ 2 / 4`-style bullets. Coverage `+N` chip surfaces
 *     when any bonus arm (idx ≥ 16) is committed.
 *   - Banner copy adapts to `PhotosphereState.Stage`.
 * Driven by [PhotosphereCaptureDriver.state]
 *     as a passthrough of the upstream session's StateFlow. Coarse
 *     `RoundEvent` subscription is retained for AllRoundsDone /
 *     Aborted side-effects (focus unlock, finalize, marker reset).
 *
 * The screen exposes an explicit "Capture
 * reference" button with first-tap gating. The earlier auto-fire-on-first-frame
 * path (driver grabs R0 the moment the LiveFrameTap delivers a frame) is replaced
 * with an operator-gated invocation: the button's `onClick` flips a
 * boolean that opens the gate the next live frame can pass through.
 */
@TwinSkinInternalApi
@Composable
public fun CaptureScreen(
    metadata: SdkCaptureMetadata? = null,
    onDone: (CaptureSession) -> Unit = {},
    onCancel: () -> Unit = {},
    startSession: (SdkCaptureMetadata) -> CaptureSession = { TwinSkinSdk.startCapture(it) },
    // the screen skips CameraX bind + camera-permission gating and
    // feeds the capture pipeline from a bundled MP4 trajectory (decoded
    // via [com.twinskin.sdk.ui.capture.RimbaudReplayFrameSource]).
    // Lets integrators exercise the full capture → finalize → upload
    // pipeline without a camera (CI, smoke tests, mocked QA). Spec:
    // `docs/tracking/cl103-rimbaud-synthetic-replay-spec-2026-05-08.md`.
    replaySource: CaptureReplaySource? = null,
) {
    if (metadata == null) {
        NotWiredPlaceholder()
        return
    }

    val orientationContext = LocalContext.current
    DisposableEffect(Unit) {
        val activity = orientationContext.findActivity()
        val previous = activity?.requestedOrientation
        if (activity != null) {
            activity.requestedOrientation =
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            Log.w(
                "CaptureScreen",
                "host context is not an Activity; skipping portrait lock",
            )
        }
        onDispose {
            if (activity != null && previous != null) {
                activity.requestedOrientation = previous
            }
        }
    }

    // Operator request 2026-05-08: keep the screen on at full brightness
    // for the entire duration of the capture screen. Without this, an
    // inactive-screen timeout mid-sweep pauses the camera analyser and
    // aborts the dwell counter; full brightness ensures the operator
    // can see the cross-bar and arm-progress chrome under indoor
    // lighting. Both knobs revert on dispose so the rest of the host
    // app keeps the system default.
    val keepScreenOnView = LocalView.current
    val brightnessActivity = LocalContext.current.findActivity()
    DisposableEffect(keepScreenOnView, brightnessActivity) {
        val window = brightnessActivity?.window
        val previousKeepOn = keepScreenOnView.keepScreenOn
        val previousBrightness = window?.attributes?.screenBrightness
        keepScreenOnView.keepScreenOn = true
        window?.let {
            val params = it.attributes
            params.screenBrightness = 1f
            it.attributes = params
        }
        onDispose {
            keepScreenOnView.keepScreenOn = previousKeepOn
            window?.let {
                val params = it.attributes
                params.screenBrightness = previousBrightness
                    ?: android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                it.attributes = params
            }
        }
    }

    val permissions = rememberCapturePermissionsState()
    // MP4; no camera permission is needed. Skip the request entirely
    // so the operator does not hit a permission prompt for a feature
    // that does not touch the camera.
    LaunchedEffect(Unit) {
        if (replaySource == null && !permissions.granted) permissions.request()
    }

    val scope = rememberCoroutineScope()
    val session = remember(metadata) { startSession(metadata) }

    val cancelSession: () -> Unit = {
        scope.launch {
            try { session.cancel() } finally { onCancel() }
        }
    }

    ProvideSdkCaptureStrings {
        when {
            replaySource != null -> CaptureFlow(
                session = session,
                onDone = onDone,
                onCancel = cancelSession,
                replaySource = replaySource,
            )
            permissions.denied -> Box(
                Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                PermissionDeniedView(
                    permanentlyDenied = permissions.permanentlyDenied,
                    onRetry = permissions.request,
                    onOpenSettings = permissions.openAppSettings,
                    onCancel = cancelSession,
                )
            }
            !permissions.granted -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            else -> CaptureFlow(session, onDone, onCancel = cancelSession)
        }
    }
}

@Composable
private fun NotWiredPlaceholder() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            "CaptureScreen needs SdkCaptureMetadata — host app has not wired one up yet.",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(24.dp),
        )
    }
}

@Composable
internal fun PermissionDeniedView(
    permanentlyDenied: Boolean,
    onRetry: () -> Unit,
    onOpenSettings: () -> Unit,
    onCancel: () -> Unit,
) {
    val message = if (permanentlyDenied) {
        "Camera access is required to capture. Enable it in app settings."
    } else {
        "Camera access is required to capture."
    }
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(message, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(16.dp))
        Row {
            OutlinedButton(onClick = onCancel) { Text("Cancel") }
            Spacer(Modifier.width(8.dp))
            if (permanentlyDenied) {
                Button(onClick = onOpenSettings) { Text("Open settings") }
            } else {
                Button(onClick = onRetry) { Text("Grant access") }
            }
        }
    }
}

/**
 * Demo-only `useDemoCapture` overlay state. The XFeat overlay reads
 * everything else off [PhotosphereCaptureDriver.state]; this enum is
 * only required for the developer "Use demo capture" button which
 * downloads a server-side bundle and so doesn't pass through the live
 * driver state machine.
 */
private sealed class DemoStep {
    data class Downloading(val downloaded: Int, val total: Int) : DemoStep()
    data object Submitting : DemoStep()
}

@Composable
private fun CaptureFlow(
    session: CaptureSession,
    onDone: (CaptureSession) -> Unit,
    onCancel: () -> Unit,
    // when non-null, [CaptureFlow] runs in synthetic-replay
    // mode: skip CameraX bind, pre-open `refGateOpen`, instantiate a
    // [RimbaudReplayFrameSource] tied to the integrator-supplied scene
    // directory, and feed its uint8 + float32 outputs to the existing
    // [CameraSessionController.attachMarkerFocusController] +
    // [PhotosphereCaptureDriver.LiveFrameTap] seams.
    replaySource: CaptureReplaySource? = null,
) {
    val scope = rememberCoroutineScope()
    var submitted by remember { mutableStateOf(false) }

    if (submitted) {
        PostSubmitFlow(
            session = session,
            onDone = { onDone(session) },
            onCancel = onCancel,
        )
        return
    }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val controller = remember(context, lifecycleOwner, session.workingDir) {
        CameraSessionController(context, lifecycleOwner, session.workingDir)
    }
    // focus controller. The controller drives the AF/AE POI override:
    // when its state is `Locked`, the first RoundWaiting branch reads
    // `lastObservedMarker` and hands the centroid to
    // `controller.lockFocusAndExposure(...)`. When unlocked /
    // searching / reacquiring, the lock falls back to analyser-centre.
    val markerFocus = remember(controller) {
        com.twinskin.sdk.ui.capture.MarkerFocusController()
    }
    LaunchedEffect(controller) {
        controller.attachMarkerFocusController(markerFocus)
        // permission, no preview). Driver bootstrap below is gated on
        // [replaySource] non-null instead of the controller's Ready
        // state, so skipping the camera bind keeps the screen clean
        // (no AndroidView preview surface, no CameraX lifecycle).
        if (replaySource == null) {
            controller.bindToLifecycle()
        }
    }
    DisposableEffect(controller) {
        onDispose {
            controller.unlockLensAndExposureForPhotosphere()
            controller.dispose()
        }
    }

    val controllerState by controller.state.collectAsState()

    val devMode = TwinSkinSdk.devMode

    // camera controller is `Ready`. The driver loads the ORT backbone
    // twice (ref + live ctx) and binds the dwell tracker; failures
    // surface as a banner and the operator can cancel.
    var driver by remember { mutableStateOf<PhotosphereCaptureDriver?>(null) }
    var bootstrapError by remember { mutableStateOf<String?>(null) }
    var liveFrameTap by remember {
        mutableStateOf<PhotosphereCaptureDriver.LiveFrameTap?>(null)
    }
    // Operator-gated reference
    // capture. An earlier path auto-fired `captureReference`
    // on the first live frame (driver-built `LiveFrameTap`'s
    // refBeginIfNeeded race); this flag flips the gate from CLOSED
    // to OPEN when the operator taps "Capture reference". Until
    // OPEN, every live frame is dropped at the camera-side wrapper
    // tap below. Once OPEN, the underlying driver-built tap takes
    // over and the first arriving frame fires
    // `driver.captureReference(...)` as designed
    // (single-shot guarded by the actor-isolated refBeginIfNeeded).
    // AtomicBoolean rather than mutableStateOf so the camera
    // analyser thread (which is *not* the Compose recomposition
    // thread) reads the latest value without a snapshot read.
    val refGateOpen = remember { AtomicBoolean(false) }
    // Tutorial overlay drives `pausedForTutorial` to drain the analyser
    // input while it's visible (CameraX has no preview-disable parallel
    // to AVCapture, so the black scrim covers the preview by overdraw).
    val pausedForTutorial = remember { AtomicBoolean(false) }
    var tutorialRefJpegBytes by remember { mutableStateOf<ByteArray?>(null) }
    // Reference-luminance verdict gate. A non-null [refVerdict] shows
    // the modal card; [refVerdictDecision] is the channel the card's
    // buttons complete to resume the suspended refJpegProvider.
    var refVerdict by remember { mutableStateOf<MarkerValidator.RefLuminance?>(null) }
    var refVerdictDecision by remember {
        mutableStateOf<CompletableDeferred<RefVerdictChoice>?>(null)
    }
    var torchOn by remember { mutableStateOf(false) }
    // Luminance verdict of the accepted reference, carried onto the
    // bundle manifest at submit. Outlives the verdict loop so it is
    // still live when `AllRoundsDone` finalizes the bundle.
    var acceptedRefLuminance by remember {
        mutableStateOf<SdkReferenceLuminance?>(null)
    }
    // Non-null while the operator must manually re-tap "Capture
    // reference" after a torch retake — the button completes it to
    // resume the suspended refJpegProvider.
    var refRetakeGate by remember {
        mutableStateOf<CompletableDeferred<Unit>?>(null)
    }
    // Non-null while the marker-missing warning card is showing on
    // top of the preview. The card's "Retake" button completes the
    // deferred to dismiss the card, then refRetakeGate parks the
    // refJpegProvider until the operator re-taps "Retake reference".
    var refMarkerWarning by remember {
        mutableStateOf<RefMarkerWarning?>(null)
    }
    var refMarkerWarningAck by remember {
        mutableStateOf<CompletableDeferred<Unit>?>(null)
    }
    var refReadyAtMs by remember { mutableStateOf<Long?>(null) }
    var tutorialDismissed by remember { mutableStateOf(false) }
    var tutorialReopenRequested by remember { mutableStateOf(false) }
    // so the DisposableEffect tear-down can stop it. Distinct from the
    // outer [replaySource] composable param (which is the integrator-
    // supplied scene metadata).
    var replayFrameSource by remember { mutableStateOf<RimbaudReplayFrameSource?>(null) }
    // Defect-2 fix (operator brief 2026-05-08) — separate
    // Dispatchers.Default scope for the replay path's
    // [PhotosphereCaptureDriver.buildLiveFrameTap] tapHostScope. See
    // the "Default dispatcher" comment in the replay LaunchedEffect
    // below for the starvation-avoidance rationale. Cancelled in the
    // DisposableEffect alongside the replay engine.
    val replayDriverScope = remember {
        kotlinx.coroutines.CoroutineScope(
            kotlinx.coroutines.SupervisorJob() + Dispatchers.Default,
        )
    }
    // [replayDriverScope] for the LIVE camera path. The earlier port
    // passed `tapHostScope = this` (the LaunchedEffect coroutine
    // scope) which inherits AndroidUiDispatcher.Main, so every
    // analyser tick re-dispatched the LiveFrameTap body — including
    // the ~1.2 MB synchronized memcpy in
    // PhotosphereSession.enqueueLiveFrame and the per-frame
    // refCaptureMutex acquire — onto Main. On Pixel 6 the X1 cores
    // make the analyser thread fast enough that Main is constantly
    // queue-stuffed with these jobs while it's also painting the
    // photosphere overlay (cross / legend / banner) at 60 fps, which
    // hitches both UI and pose updates. The XFeat DemoApp's
    // CameraFrameSource.attachAnalyser calls
    // `session.enqueueLiveFrame(...)` synchronously from the
    // analyser thread (off-Main); mirror that posture here by
    // dispatching to a Default-pool scope. See
    // docs/tracking/cl103-live-camera-perf-analysis-2026-05-08.md
    // §D1 for the full code-trace and rationale.
    val liveDriverScope = remember {
        kotlinx.coroutines.CoroutineScope(
            kotlinx.coroutines.SupervisorJob() + Dispatchers.Default,
        )
    }
    LaunchedEffect(controller, session.workingDir, replaySource) {
        if (driver != null) return@LaunchedEffect
        // Replay path: bypass the camera-Ready wait entirely. The
        // driver is heavy to instantiate (ORT load); we want it up
        // ASAP so the replay engine can begin feeding frames as soon
        // as the operator picked a scene.
        if (replaySource != null) {
            try {
                // Stage + construct the replay engine first so its
                // `latestRefJpeg()` accessor is reachable from the
                // driver's `refJpegProvider` closure below. The engine
                // does not start decoding until `source.start(...)` is
                // called further down.
                val sceneDir = replaySource.sceneDir
                if (!sceneDir.isDirectory) {
                    Log.w(
                        "CaptureScreen",
                        "synthetic replay scene dir is not a directory: ${sceneDir.absolutePath}",
                    )
                }
                val source = RimbaudReplayFrameSource(
                    sceneDir = sceneDir,
                    workingDir = File(session.workingDir),
                )
                replayFrameSource = source

                val drv = PhotosphereCaptureDriver.create(
                    context = context,
                    workingDir = File(session.workingDir),
                    // an 8° on-target threshold to match the working
                    // XFeat DemoApp at
                    // `evaluate-xfeat-lighterglue/.../MainActivity.kt:1082-1104`
                    // (`REPLAY_ON_TARGET_DEG = 8f`). Placeholder-K
                    // scenes ship with recovered tilt magnitudes that
                    // drift 4-6° vs. the 20° target ring, so the 3°
                    // production threshold never fires on these
                    // replay frames and the per-arm dwell window
                    // never closes. Live-camera path keeps the 3°
                    // production default (no `onTargetDistanceDeg`
                    // arg there).
                    onTargetDistanceDeg = REPLAY_ON_TARGET_DEG,
                    verboseFrameLogs = TwinSkinSdk.verboseFrameLogs,
                )
                // Step 2.5 (2026-05-08) — return latest decoded MP4
                // frame's JPEG bytes (was null, which the C ABI treats
                // as a failed arm, breaking per-view bundles).
                drv.setShutterCallback { _ -> source.latestFrameJpeg() }
                val driverTap = drv.buildLiveFrameTap(
                    tapHostScope = replayDriverScope,
                    refJpegProvider = {
                        // Spin-wait for the replay engine's first
                        // decoded JPEG. Pre-opened gate + bounded poll.
                        var bytes = source.latestRefJpeg()
                        var attempts = 0
                        while (bytes == null && attempts < REF_JPEG_POLL_MAX) {
                            kotlinx.coroutines.delay(REF_JPEG_POLL_DELAY_MS)
                            bytes = source.latestRefJpeg()
                            attempts += 1
                        }
                        if (bytes == null) {
                            Log.w(
                                "CaptureScreen",
                                "replay refJpegProvider gave up after " +
                                    "${REF_JPEG_POLL_MAX * REF_JPEG_POLL_DELAY_MS} ms",
                            )
                        } else {
                            tutorialRefJpegBytes = bytes
                        }
                        bytes
                    },
                )
                refGateOpen.set(true)
                val gatedTap = PhotosphereCaptureDriver.LiveFrameTap {
                    grayBuffer, intrinsics, timestampNs ->
                    if (!refGateOpen.get()) return@LiveFrameTap
                    if (pausedForTutorial.get()) return@LiveFrameTap
                    driverTap.onFrame(grayBuffer, intrinsics, timestampNs)
                }
                liveFrameTap = gatedTap
                controller.attachLiveFrameTap(gatedTap)
                driver = drv

                source.start(
                    markerSink = { gray, w, h, rowStride ->
                        markerFocus.ingestFrame(
                            gray = gray,
                            width = w,
                            height = h,
                            rowStride = rowStride,
                        )
                    },
                    liveTap = gatedTap,
                    logSink = { },
                    // the session reaches terminal stage.
                    isSessionTerminal = {
                        val stage = drv.state.value.stage
                        stage is PhotosphereState.Stage.Done ||
                            stage is PhotosphereState.Stage.Aborted
                    },
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                bootstrapError = "XFeat init failed: ${e.message ?: e::class.simpleName ?: "unknown"}"
            }
            return@LaunchedEffect
        }
        // Live path: wait for the camera to be ready before
        // instantiating the driver.
        controller.state.collect { st ->
            if (st is CameraSessionState.Ready && driver == null) {
                try {
                    val drv = PhotosphereCaptureDriver.create(
                        context = context,
                        workingDir = File(session.workingDir),
                        phiOffsetDeg = LIVE_CAMERA_PHI_OFFSET_DEG,
                        verboseFrameLogs = TwinSkinSdk.verboseFrameLogs,
                    )

                    // Per-arm validator gates captured JPEGs against the
                    // ref-frame anchor (distance band + blur floor) and
                    // stamps TWINSKIN_VALIDATION EXIF before the bundle
                    // sees them.
                    controller.attachCaptureValidator()
                    // Telemetry provider returns the sample the validator
                    // just stamped onto the JPEG's TIFF.Copyright EXIF,
                    // so the same physical reading lands in pose_log.json
                    // — no second probe, no skew between sinks.
                    drv.setShutterTelemetryProvider { controller.lastShutterTelemetry }
                    // CameraSessionController.captureJpegBytes (off-Main
                    // OnImageCapturedCallback) instead of takePhoto +
                    // readBytes; saves 50-120 ms/arm × 16 arms/sweep.
                    drv.setShutterCallback { viewIndex ->
                        try {
                            val raw = controller.captureJpegBytes(label = "view_$viewIndex")
                            val validated = controller.validateAndStampJpegBytes(
                                jpeg = raw,
                                isReference = false,
                            )
                            if (validated.accepted) {
                                validated.stampedBytes
                            } else {
                                Log.i(
                                    "CaptureScreen",
                                    "view_$viewIndex rejected:" +
                                        " verdict=${validated.verdict}" +
                                        " diag=${validated.diagPx}" +
                                        " blur=${validated.blurVariance}",
                                )
                                null
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            Log.w(
                                "CaptureScreen",
                                "shutter callback failed: ${e.message}",
                                e,
                            )
                            null
                        }
                    }

                    val driverTap = drv.buildLiveFrameTap(
                        // [liveDriverScope] declaration above for
                        // rationale. The prior `tapHostScope = this`
                        // (Main-immediate via LaunchedEffect) put the
                        // 1.2 MB synchronized memcpy in
                        // PhotosphereSession.enqueueLiveFrame and the
                        // refCaptureMutex acquire on Main; this scope
                        // is Default-pool so the analyser-side work
                        // stays off Main. Cancelled in the same
                        // DisposableEffect that owns `replayDriverScope`.
                        tapHostScope = liveDriverScope,
                        refJpegProvider = {
                            try {
                                // The driver calls this once; the shutter
                                // is looped internally until the operator
                                // accepts the reference, so the driver's
                                // single-shot ref guard is untouched.
                                var acceptedBytes: ByteArray? = null
                                // Mean luma of the first (pre-torch) shot,
                                // stamped as orig_mean_y on torch retakes.
                                var originalMeanY: Float? = null
                                var acceptedLum: MarkerValidator.RefLuminance? = null
                                while (acceptedBytes == null) {
                                    val rawBytes =
                                        File(controller.takePhoto()).readBytes()
                                    val validated =
                                        controller.validateAndStampJpegBytes(
                                            jpeg = rawBytes,
                                            isReference = true,
                                            originalMeanLuma = originalMeanY,
                                        )
                                    val lum = validated.refLuminance
                                    if (originalMeanY == null) {
                                        originalMeanY = lum?.meanLuma
                                    }
                                    val rec = lum?.recommendation?.toCommon()
                                    // The card is shown ONLY for a
                                    // low-light reference, where the torch
                                    // can help; any other verdict is
                                    // accepted with no overlay.
                                    val lowLight = rec?.isLowLight == true
                                    if (lum != null && lowLight) {
                                        // Torch on by default for a low-light
                                        // reference, then surface the card.
                                        controller.setTorchEnabled(true)
                                        torchOn = controller.isTorchEnabled()
                                        val deferred =
                                            CompletableDeferred<RefVerdictChoice>()
                                        refVerdict = lum
                                        refVerdictDecision = deferred
                                        val choice = deferred.await()
                                        refVerdict = null
                                        refVerdictDecision = null
                                        if (choice == RefVerdictChoice.Retake) {
                                            // Wait for a fresh manual
                                            // "Capture reference" tap before
                                            // the loop re-shutters.
                                            val gate = CompletableDeferred<Unit>()
                                            refRetakeGate = gate
                                            gate.await()
                                            refRetakeGate = null
                                            continue
                                        }
                                    }
                                    // The validator overwrites refDiagPx /
                                    // refBlur / markerVersion on every
                                    // isReference=true call, so a retake
                                    // re-anchors the gate's state without
                                    // an explicit cleanup pass.
                                    if (controller.lastReferenceMarkerVersion() == null) {
                                        val recent = isMarkerRecent(
                                            nowMs = SystemClock.elapsedRealtime(),
                                            seenAtMs = controller.lastLiveMarkerSeenAtMs(),
                                        )
                                        val ack = CompletableDeferred<Unit>()
                                        refMarkerWarning = if (recent) {
                                            RefMarkerWarning.seenRecently
                                        } else {
                                            RefMarkerWarning.neverSeen
                                        }
                                        refMarkerWarningAck = ack
                                        ack.await()
                                        refMarkerWarning = null
                                        refMarkerWarningAck = null
                                        val gate = CompletableDeferred<Unit>()
                                        refRetakeGate = gate
                                        gate.await()
                                        refRetakeGate = null
                                        continue
                                    }
                                    if (validated.verdict ==
                                        MarkerValidator.CaptureVerdict.MARKER_CLIPPED
                                    ) {
                                        val ack = CompletableDeferred<Unit>()
                                        refMarkerWarning = RefMarkerWarning.markerClipped
                                        refMarkerWarningAck = ack
                                        ack.await()
                                        refMarkerWarning = null
                                        refMarkerWarningAck = null
                                        val gate = CompletableDeferred<Unit>()
                                        refRetakeGate = gate
                                        gate.await()
                                        refRetakeGate = null
                                        continue
                                    }
                                    acceptedBytes = validated.stampedBytes
                                    acceptedLum = lum
                                }
                                // Camera2 AF_MODE_OFF + AE_LOCK + AWB_LOCK
                                // override SYNCHRONOUSLY here, after the
                                // verdict loop so AE converges on the
                                // final torch state, and before the ref
                                // bytes reach the driver. See
                                // docs/tracking/cl103-focus-lock-timing-diff-2026-05-10.md
                                // for why the lock must not be deferred.
                                val obs = markerFocus.lastObservedMarker
                                val markerPoi = obs?.let {
                                    android.graphics.PointF(it.centroidX, it.centroidY)
                                }
                                val decision =
                                    PhotosphereFocusPolicy.refShutterLockDecision(markerPoi)
                                controller.lockLensAndExposureForPhotosphere(
                                    poiX = decision.pointOfInterest?.x,
                                    poiY = decision.pointOfInterest?.y,
                                )
                                // Torch is read post-loop so it reflects
                                // the operator's final decision on the card.
                                acceptedRefLuminance = acceptedLum
                                    ?.toSdkReferenceLuminance(
                                        torch = controller.isTorchEnabled(),
                                    )
                                tutorialRefJpegBytes = acceptedBytes
                                acceptedBytes
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                Log.w(
                                    "CaptureScreen",
                                    "captureReference fullres failed: ${e.message}",
                                    e,
                                )
                                null
                            }
                        },
                    )
                    // driver-built tap with an operator gate. While
                    // `refGateOpen` is false (pre-button-tap) every
                    // analyser frame is silently dropped — neither
                    // `captureReference` nor `enqueueLiveFrame` are
                    // invoked, so the dwell tracker stays asleep and
                    // the session sits in `RefCapture`. Once the
                    // operator taps "Capture reference" the gate
                    // flips OPEN; from that moment forward frames
                    // pass straight through to the driver-built tap,
                    // which runs its own `refBeginIfNeeded` guard
                    // for the single-shot ref capture path.
                    // AtomicBoolean for thread-safety since the
                    // analyser callback fires off a dedicated
                    // CameraX executor.
                    val gatedTap = PhotosphereCaptureDriver.LiveFrameTap {
                        grayBuffer, intrinsics, timestampNs ->
                        if (!refGateOpen.get()) return@LiveFrameTap
                        if (pausedForTutorial.get()) return@LiveFrameTap
                        driverTap.onFrame(grayBuffer, intrinsics, timestampNs)
                    }
                    liveFrameTap = gatedTap
                    controller.attachLiveFrameTap(gatedTap)
                    driver = drv
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    bootstrapError = "XFeat init failed: ${e.message ?: e::class.simpleName ?: "unknown"}"
                }
            }
        }
    }
    DisposableEffect(driver) {
        // entry. The delegated `var driver` would otherwise be captured by
        // REFERENCE in `onDispose`, so the first null→drv transition (which
        // disposes the previous null-keyed effect) would read the NEW value
        // and call `cancel()` on the freshly-built driver, immediately
        // aborting the session. Snapshotting captures the PRIOR key value:
        // first dispose is a no-op; only screen-exit with `current = drv`
        // triggers `drv.cancel()`.
        //
        // tap-detach (`controller.attachLiveFrameTap(null)` +
        // first null→drv transition disposed the null-keyed effect and
        // cleared the tap that the LaunchedEffect had JUST installed
        // (~28 ms earlier). Symptom on Pixel 6: every analyser frame
        // observes `liveFrameTap == null`, so `gatedTap.onFrame` never
        // fires, `captureReference` is never invoked, and the operator's
        // "Capture reference" tap silently drops on the floor with no
        // visible feedback. Gate the tap-detach on `current != null`
        // (same posture as `current?.cancel()` above): only the real
        // screen-exit dispose (where the snapshot captured `drv`) tears
        // down the tap.
        val current = driver
        onDispose {
            if (current != null) {
                current.cancel()
                // Detach the tap from the controller so any in-flight
                // analyser callback drops the frame instead of forwarding
                // it to the cancelled driver. Belt-and-suspenders with
                // CameraSessionController.dispose's own tap clear.
                controller.attachLiveFrameTap(null)
                liveFrameTap = null
                replayFrameSource?.stop()
                replayFrameSource = null
                // Defect-2 fix — cancel the replay tap-host scope so
                // any in-flight ref-capture / enqueue coroutines
                // unwind cleanly with the driver.
                replayDriverScope.cancel()
                // the live-camera tap-host scope.
                liveDriverScope.cancel()
            }
        }
    }

    var demoStep by remember { mutableStateOf<DemoStep?>(null) }
    var submitting by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var demoPickerOptions by remember { mutableStateOf<List<DemoCaptureSummary>?>(null) }
    // `refGateOpen`. Set true on the "Capture reference" button tap;
    // hides the button on the next recomposition. The actor-side
    // gate is still the source of truth for the live-frame tap (it
    // runs on the camera analyser thread); this flag is for UI
    // visibility only.
    var refButtonTapped by remember { mutableStateOf(false) }

    // Dev-only auto-open of the demo picker; keep in sync with the
    // "Use demo capture" button's onClick below.
    LaunchedEffect(devMode) {
        if (devMode && CaptureDemoLaunch.autoOpenPicker) {
            CaptureDemoLaunch.autoOpenPicker = false
            val catalog = try {
                session.listDemoCaptures()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                errorText = e.message ?: "Demo capture failed"
                return@LaunchedEffect
            }
            if (catalog.isNotEmpty()) demoPickerOptions = catalog
        }
    }

    // milestone side-effects (focus lock at first RoundWaiting,
    // unlock + finalize at AllRoundsDone, abort handling). The
    // overlay itself reads off `driver.state` for the per-arm tile
    // grid + live cursor — see [XFeatPhotosphereOverlay].
    LaunchedEffect(driver) {
        val drv = driver ?: return@LaunchedEffect
        var focusLocked = false
        drv.events.collect { ev ->
            when (ev) {
                is PhotosphereCaptureDriver.RoundEvent.RoundWaiting -> {
                    if (!focusLocked) {
                        // Camera2 hard lens-lock
                        // is now installed inline with ref capture
                        // inside refJpegProvider, BEFORE any live frame
                        // is enqueued. This branch only flips the
                        // focusLocked guard and detaches the marker
                        // focus controller post-lock.
                        focusLocked = true
                        refReadyAtMs = SystemClock.elapsedRealtime()
                        // OI-067 / D2 — detach the marker-focus controller
                        // now that focus is locked. ArUco runs every 5th
                        // analyser frame (~6 Hz, 5-10 ms/call) on the same
                        // single thread that feeds XFeat inference; running
                        // it for all 16 arms burns ~50-60 ms/sec of
                        // analyser-thread budget. We no longer need marker
                        // detection during the sweep — re-attach at
                        // AllRoundsDone / Aborted so the next session finds
                        // the controller live.
                        controller.attachMarkerFocusController(null)
                    }
                }
                is PhotosphereCaptureDriver.RoundEvent.Capturing,
                is PhotosphereCaptureDriver.RoundEvent.RoundComplete,
                -> Unit // Per-arm UI handled by overlay reading state.
                is PhotosphereCaptureDriver.RoundEvent.AllRoundsDone -> {
                    val obs = markerFocus.lastObservedMarker
                    val markerPoi = obs?.let {
                        android.graphics.PointF(it.centroidX, it.centroidY)
                    }
                    val decision = PhotosphereFocusPolicy.decide(
                        stage = PhotosphereState.Stage.Done,
                        markerPoi = markerPoi,
                    )
                    if (decision.focusMode == PhotosphereFocusMode.ContinuousAutoFocus) {
                        controller.unlockLensAndExposureForPhotosphere()
                    }
                    controller.attachMarkerFocusController(markerFocus)
                    markerFocus.reset()
                    focusLocked = false
                    submitting = true
                    // Submit overlay covers the preview; free CameraX so
                    // the JPEG-compress fan-out has heap headroom.
                    controller.dispose()
                    try {
                        val result = drv.finalize().copy(
                            referenceLuminance = acceptedRefLuminance,
                            markerVersion = controller.lastReferenceMarkerVersion(),
                        )
                        session.submit(result)
                        submitted = true
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // Camera is already disposed; keep the overlay up
                        // so the dead preview stays hidden — the operator
                        // can only Cancel from the top-bar action now.
                        errorText = e.message ?: "submit failed"
                    }
                }
                is PhotosphereCaptureDriver.RoundEvent.Aborted -> {
                    val obs = markerFocus.lastObservedMarker
                    val markerPoi = obs?.let {
                        android.graphics.PointF(it.centroidX, it.centroidY)
                    }
                    val decision = PhotosphereFocusPolicy.decide(
                        stage = drv.state.value.stage,
                        markerPoi = markerPoi,
                    )
                    if (decision.focusMode == PhotosphereFocusMode.ContinuousAutoFocus) {
                        controller.unlockLensAndExposureForPhotosphere()
                    }
                    controller.attachMarkerFocusController(markerFocus)
                    markerFocus.reset()
                    focusLocked = false
                    errorText = "Capture aborted: ${ev.reason}"
                }
            }
        }
    }

    // per-arm overlay. Null until the driver has been instantiated +
    // its first state snapshot has propagated.
    val driverState: PhotosphereState? = driver?.state?.collectAsState()?.value

    val tutorialContext = context
    // Seed from SharedPreferences; subsequent toggles update this
    // state synchronously via `onDontShowAgainChanged`.
    var dontShowAgainState by remember(tutorialContext) {
        mutableStateOf(PhotosphereTutorialPrefs.dontShowAgain(tutorialContext))
    }
    val shouldShowTutorial = shouldShowTutorial(
        hasReferenceImage = tutorialRefJpegBytes != null,
        tutorialDismissed = tutorialDismissed,
        dontShowAgain = dontShowAgainState,
        tutorialReopenRequested = tutorialReopenRequested,
    )
    val tutorialReopenEnabled = tutorialReopenEnabled(
        hasReferenceImage = tutorialRefJpegBytes != null,
        isTutorialShowing = shouldShowTutorial,
        hasAnyCapturedArms = driverState?.capturedArms?.isNotEmpty() ?: false,
    )

    // Free the ref JPEG (and its decoded ImageBitmap) once the
    // operator commits any arm; the tutorial is unreachable from then
    // on, so keeping ~3–5 MB + the RGBA bitmap resident is waste.
    val firstArmCommitted = driverState?.capturedArms?.isNotEmpty() == true
    LaunchedEffect(firstArmCommitted) {
        if (firstArmCommitted) {
            tutorialRefJpegBytes = null
        }
    }

    // Top-level Box so the overlay covers status bar + TopAppBar
    // (parity with iOS `.ignoresSafeArea()`); rendering inside the
    // Scaffold content lambda would inherit its inset padding.
    Box(Modifier.fillMaxSize()) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (replaySource != null) "Capture (replay)" else "Capture") },
                navigationIcon = {
                    TextButton(onClick = onCancel) { Text("Cancel") }
                },
                actions = {
                    if (tutorialReopenEnabled) {
                        TextButton(onClick = {
                            tutorialReopenRequested = true
                            tutorialDismissed = false
                        }) {
                            Text("?")
                        }
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (replaySource != null) {
                val replayBitmap = replayFrameSource?.replayFrameFlow?.collectAsState()?.value
                Box(
                    modifier = Modifier.fillMaxSize().background(Color.Black),
                    contentAlignment = Alignment.Center,
                ) {
                    if (replayBitmap != null) {
                        Image(
                            bitmap = replayBitmap.asImageBitmap(),
                            contentDescription = "replay frame",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                    } else if (driverState == null) {
                        Text("Loading replay scene…", color = Color.White)
                    }
                }
            } else {
                CameraPreview(
                    controller = controller,
                    modifier = Modifier.fillMaxSize(),
                )
                if (devMode) {
                    com.twinskin.sdk.ui.capture.MarkerDebugOverlay(
                        markerFocus = markerFocus,
                        controller = controller,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }

            if (replaySource == null &&
                driverState == null &&
                demoStep == null &&
                !submitting &&
                bootstrapError == null &&
                controllerState !is CameraSessionState.Error
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.55f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color.White)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Preparing camera…",
                            color = Color.White,
                            style = MaterialTheme.typography.bodyLarge,
                        )
                    }
                }
            }

            if (driverState != null && demoStep == null && !submitting) {
                XFeatPhotosphereOverlay(state = driverState)
            }

            // Processing window: between tap and either a card
            // appearing or the sweep starting.
            val capturing = isRefShutterCapturing(
                refButtonTapped = refButtonTapped,
                refRetakeGatePending = refRetakeGate != null,
                refVerdictPending = refVerdict != null,
                refMarkerWarningPending = refMarkerWarning != null,
                isRefCaptureStage = driverState?.stage is PhotosphereState.Stage.RefCapture,
            )

            // Sole writer of [refReadyAtMs] is the RoundWaiting handler.
            LaunchedEffect(refReadyAtMs) {
                val at = refReadyAtMs ?: return@LaunchedEffect
                delay(REF_READY_DISPLAY_MS)
                if (refReadyAtMs == at) refReadyAtMs = null
            }

            if (replaySource == null
                && driverState != null
                && driverState.stage is PhotosphereState.Stage.RefCapture
                && demoStep == null
                && !submitting
                && refVerdict == null
                && refMarkerWarning == null
                && !capturing
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .padding(bottom = BOTTOM_CHROME_PADDING_DP.dp + 80.dp)
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Button(
                        onClick = {
                            refButtonTapped = true
                            val gate = refRetakeGate
                            if (gate != null) {
                                // Drop the gate UI-side immediately so the
                                // "Do not move" overlay fires on the same
                                // recomposition rather than on the
                                // coroutine's resume.
                                refRetakeGate = null
                                gate.complete(Unit)
                            } else {
                                refGateOpen.set(true)
                            }
                        },
                    ) {
                        Text("Capture reference")
                    }
                }
            }

            if (capturing) {
                RefShutterMessageOverlay(
                    text = CaptureViewCopy.doNotMove,
                    color = Color(0xFF1A1A1A),
                )
            } else if (refReadyAtMs != null) {
                RefShutterMessageOverlay(
                    text = CaptureViewCopy.ready,
                    color = Color(0xFF2EB872),
                )
            }

            // Reference-luminance verdict card. Modal over the
            // preview; the operator's choice resumes refJpegProvider.
            val activeVerdict = refVerdict
            val activeVerdictDecision = refVerdictDecision
            if (activeVerdict != null && activeVerdictDecision != null) {
                RefVerdictCard(
                    luminance = activeVerdict,
                    hasTorchUnit = controller.hasTorchUnit(),
                    torchOn = torchOn,
                    onTorchChange = { enabled ->
                        controller.setTorchEnabled(enabled)
                        torchOn = controller.isTorchEnabled()
                    },
                    onChoice = { choice -> activeVerdictDecision.complete(choice) },
                )
            }

            val activeMarkerWarning = refMarkerWarning
            val activeMarkerWarningAck = refMarkerWarningAck
            if (activeMarkerWarning != null && activeMarkerWarningAck != null) {
                RefMarkerWarningCard(
                    warning = activeMarkerWarning,
                    onRetake = { activeMarkerWarningAck.complete(Unit) },
                )
            }

            // devMode-only demo-capture shortcut. Kept visible for the whole
            // capture (not just the sub-second pre-driver window) so the
            // bypass is actually reachable — by a developer and by the e2e
            // test. `demoStep`/`submitting` still hide it once a demo
            // capture is under way.
            if (devMode && !isInDemoOrSubmitFlow(
                    demoFlowActive = demoStep != null,
                    submitting = submitting,
                )
            ) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp),
                    color = Color.Black.copy(alpha = 0.6f),
                    shape = MaterialTheme.shapes.small,
                ) {
                    TextButton(
                        onClick = {
                            scope.launch {
                                val catalog = try {
                                    session.listDemoCaptures()
                                } catch (e: CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    errorText = e.message ?: "Demo capture failed"
                                    return@launch
                                }
                                when {
                                    catalog.isEmpty() -> {
                                        errorText = "No demo captures available on the server"
                                    }
                                    catalog.size == 1 -> {
                                        useDemoCapture(
                                            session = session,
                                            entryId = catalog.single().id,
                                            onStateChange = { demoStep = it },
                                            onSubmitted = { submitted = true },
                                            onError = { errorText = it },
                                        )
                                    }
                                    else -> {
                                        demoPickerOptions = catalog
                                    }
                                }
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    ) {
                        Text("Use demo capture", color = Color.White)
                    }
                }
            }

            when (val ds = demoStep) {
                is DemoStep.Downloading -> DemoDownloadOverlay(downloaded = ds.downloaded, total = ds.total)
                DemoStep.Submitting -> UploadOverlay("Preparing bundle…", null)
                null -> {
                    if (submitting) {
                        UploadOverlay(
                            errorText ?: "Preparing bundle…",
                            null,
                            showSpinner = errorText == null,
                        )
                    }
                }
            }

            val ctrlErr = (controllerState as? CameraSessionState.Error)?.message
            val banner = errorText ?: bootstrapError ?: ctrlErr
            if (banner != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.align(Alignment.TopCenter).padding(16.dp),
                ) {
                    Text(
                        banner,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                }
            }
        }

        demoPickerOptions?.let { options ->
            DemoCapturePickerDialog(
                options = options,
                onDismiss = { demoPickerOptions = null },
                onPick = { chosen ->
                    demoPickerOptions = null
                    scope.launch {
                        useDemoCapture(
                            session = session,
                            entryId = chosen.id,
                            onStateChange = { demoStep = it },
                            onSubmitted = { submitted = true },
                            onError = { errorText = it },
                        )
                    }
                },
            )
        }
    }

    val tutorialBytes = tutorialRefJpegBytes
    if (shouldShowTutorial && tutorialBytes != null) {
        val refImage = remember(tutorialBytes) {
            tutorialBytes.toImageBitmap()
        }
        PhotosphereTutorialOverlay(
            refImage = refImage,
            seenAtLeastOnce = PhotosphereTutorialPrefs
                .seenAtLeastOnce(tutorialContext),
            dontShowAgainInitial = dontShowAgainState,
            onPauseChanged = { paused ->
                pausedForTutorial.set(paused)
            },
            onDontShowAgainChanged = { value ->
                dontShowAgainState = value
                PhotosphereTutorialPrefs
                    .setDontShowAgain(tutorialContext, value)
            },
            onDismiss = {
                PhotosphereTutorialPrefs.markSeen(tutorialContext)
                tutorialDismissed = true
                tutorialReopenRequested = false
            },
        )
    }
    }
}

/**
 * Dev-only one-shot flag: the demo host sets it (adb `--ez demopicker true`) so
 * the next [CaptureScreen] auto-opens the demo picker; cleared on use.
 */
@TwinSkinInternalApi
public object CaptureDemoLaunch {
    public var autoOpenPicker: Boolean = false
}

@Composable
private fun DemoCapturePickerDialog(
    options: List<DemoCaptureSummary>,
    onDismiss: () -> Unit,
    onPick: (DemoCaptureSummary) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pick a demo capture") },
        text = {
            Column {
                for (option in options) {
                    TextButton(
                        onClick = { onPick(option) },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            option.name,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
private fun DemoDownloadOverlay(downloaded: Int, total: Int) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "Downloading demo capture…",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { (downloaded.toFloat() / total.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.width(240.dp),
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "$downloaded / $total",
                color = Color.White,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

private suspend fun useDemoCapture(
    session: CaptureSession,
    entryId: String,
    onStateChange: (DemoStep?) -> Unit,
    onSubmitted: () -> Unit,
    onError: (String) -> Unit,
) {
    try {
        onStateChange(DemoStep.Downloading(downloaded = 0, total = 1))
        session.submitDemoCapture(entryId = entryId) { d, t ->
            onStateChange(DemoStep.Downloading(downloaded = d, total = t))
        }
        onStateChange(DemoStep.Submitting)
        onSubmitted()
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        onError(e.message ?: "Demo capture failed")
        onStateChange(null)
    }
}

@Composable
private fun CameraPreview(
    controller: CameraSessionController,
    modifier: Modifier,
) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PreviewView(ctx).also { view ->
                // PERFORMANCE (SurfaceView) explicitly. CameraX 1.4+
                // defaults to PERFORMANCE, but a future version
                // flipping the default would silently regress to
                // COMPATIBLE (TextureView), which on Camera2-LIMITED
                // HALs (XCover5, A21s) routes ImageCapture through
                // CameraX's GL surface processor and adds 1-3× per-arm
                // wall-clock. The XFeat DemoApp pins this explicitly
                // (`PhotosphereCaptureScreen.kt:170`) for the same
                // reason — match that posture.
                view.implementationMode = PreviewView.ImplementationMode.PERFORMANCE
                view.scaleType = PreviewView.ScaleType.FILL_CENTER
                controller.preview.setSurfaceProvider(view.surfaceProvider)
                controller.attachPreviewView(view)
            }
        },
    )
}

@Composable
private fun UploadOverlay(label: String, progress: Float?, showSpinner: Boolean = true) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (showSpinner) {
                if (progress != null) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.width(240.dp))
                } else {
                    CircularProgressIndicator()
                }
                Spacer(Modifier.height(12.dp))
            }
            Text(label, color = Color.White)
        }
    }
}

private tailrec fun android.content.Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Defect-2 / replay refJpegProvider — bounded poll for the replay
 *  engine's first decoded frame. ~2 s upper bound (40 × 50 ms) —
 *  generous enough to absorb codec startup on slower devices, short
 *  enough to surface a missing-scene error before the operator gives
 *  up. */
private const val REF_JPEG_POLL_DELAY_MS: Long = 50L
private const val REF_JPEG_POLL_MAX: Int = 40

/**
 * synthetic-replay path. Mirrors the working XFeat DemoApp at
 * `evaluate-xfeat-lighterglue/.../MainActivity.kt:1784`
 * (`REPLAY_ON_TARGET_DEG = 8f`). Placeholder-K scenes ship with
 * recovered tilt magnitudes that drift 4-6° vs. the 20° target ring,
 * so the 3° production threshold (`PhotosphereMath
 * .ON_TARGET_DISTANCE_DEG`) never fires on replay and the per-arm
 * dwell window never closes. Live-camera path keeps the production
 * default — only the replay branch passes this through to
 * [PhotosphereCaptureDriver.create].
 */
private const val REPLAY_ON_TARGET_DEG: Float = 8f

/**
 * OI-066 fix (2026-05-08) — sensor→display phi rotation applied on the
 * live-camera path. CameraX's `ImageAnalysis` ships 640×480 landscape
 * YUV regardless of display orientation while the capture UI is
 * portrait-locked, so the recovered `tilt_phi` is 90° offset from the
 * on-screen cross frame. Without this offset, the bar cursor drifts
 * 90° from the operator's actual orientation (tilting "up" lights the
 * "left" bar, etc). Mirrors XFeat DemoApp
 * `LIVE_CAMERA_PHI_OFFSET_DEG` at
 * `evaluate-xfeat-lighterglue/.../MainActivity.kt:1796` and iOS
 * `phiOffsetDeg = 90` at `PhotosphereCaptureView.swift:838-845`.
 * Replay path uses `0f` (frames already in display frame).
 */
private const val LIVE_CAMERA_PHI_OFFSET_DEG: Float = 90f

/** Maps the native luminance verdict onto the manifest shape. */
private fun MarkerValidator.RefLuminance.toSdkReferenceLuminance(
    torch: Boolean,
): SdkReferenceLuminance =
    SdkReferenceLuminance(
        meanY = meanLuma.toDouble(),
        darkShare = darkPixelShare.toDouble(),
        brightShare = brightPixelShare.toDouble(),
        recommendation = recommendation.toCommon().manifestCode,
        torch = torch,
    )

/** Adapter from the photosphere_capture native enum to the
 *  cross-platform [RefRecommendation] used for wire serialisation. */
private fun MarkerValidator.RefRecommendation.toCommon(): RefRecommendation =
    when (this) {
        MarkerValidator.RefRecommendation.OK -> RefRecommendation.ok
        MarkerValidator.RefRecommendation.RETAKE_FOR_FOCUS ->
            RefRecommendation.retakeForFocus
        MarkerValidator.RefRecommendation.RECOMMEND_TORCH ->
            RefRecommendation.recommendTorch
        MarkerValidator.RefRecommendation.RETAKE_WITH_TORCH ->
            RefRecommendation.retakeWithTorch
        MarkerValidator.RefRecommendation.ADVISORY_HIGHLIGHTS_CLIPPED ->
            RefRecommendation.advisoryHighlightsClipped
    }
