@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.transfer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.twinskin.sdk.TwinSkinSdk
import io.ktor.client.HttpClient
import io.ktor.client.engine.android.Android
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsChannel
import io.ktor.http.HttpHeaders
import io.ktor.utils.io.jvm.javaio.toInputStream
import kotlinx.serialization.json.Json
import java.io.File

/**
 * WorkManager [CoroutineWorker] that downloads a file from [WorkerKeys.KEY_URL] and
 * writes it to [WorkerKeys.KEY_PATH], streaming through a `.tmp` file and renaming
 * atomically on success.
 *
 * Promoted to a foreground service via [setForeground] so large downloads survive
 * app backgrounding without being killed by the system.
 *
 * ZipEngine is NOT called here — unzipping is handled by [TransferManager] after it
 * observes [TransferUpdate.Success] from the Flow, keeping workers single-responsibility.
 *
 * ## Why the worker writes directly to the database
 *
 * WorkManager can run this worker in the background **after the app process has been killed**.
 * In that scenario, [AndroidFileTransferProvider]'s observe-flow is not running. Without
 * direct DB writes from the worker, the task would stay `ACTIVE` in the database
 * indefinitely, and [TransferManager.recover] would re-download from byte 0 on next
 * app launch.
 *
 * By writing `COMPLETED` / `FAILED` directly from [doWork], the DB always reflects the real
 * terminal state regardless of whether the app was open.
 *
 * Uses WorkManager's default ContentProvider auto-init. The database is fetched from
 * [TwinSkinSdk.requireComponent] at [doWork] time.
 */
internal class DownloadWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    private val database get() = TwinSkinSdk.requireComponent().database

    override suspend fun doWork(): Result {
        // See UploadWorker for why this guard is here.
        if (!TwinSkinSdk.isInitialized) {
            Log.e(
                "TwinSkinSdk",
                "DownloadWorker aborted: TwinSkinSdk.initialize(...) was not called. " +
                    "Call it from Application.onCreate() so the SDK is ready on process restart.",
            )
            return Result.failure()
        }
        val id = inputData.getString(WorkerKeys.KEY_ID) ?: return Result.failure()
        val url = inputData.getString(WorkerKeys.KEY_URL) ?: return Result.failure()
        val destPath = inputData.getString(WorkerKeys.KEY_PATH) ?: return Result.failure()
        val headers: Map<String, String> = inputData.getString(WorkerKeys.KEY_HEADERS)
            ?.let { Json.decodeFromString(it) }
            ?: emptyMap()

        setForeground(buildForegroundInfo("Downloading…", id))

        val tmpFile = File("$destPath.tmp")
        val destFile = File(destPath)

        val client = HttpClient(Android) {
            install(HttpTimeout) {
                // No request timeout — large files can take a while
                requestTimeoutMillis = null
                socketTimeoutMillis = 60_000L
            }
        }

        return try {
            val response: HttpResponse = client.get(url) {
                headers.forEach { (key, value) -> header(key, value) }
            }
            if (response.status.value !in 200..299) {
                throw Exception("HTTP ${response.status.value}")
            }
            val contentLength = response.headers[HttpHeaders.ContentLength]?.toLong() ?: -1L

            // Stream response body to .tmp — avoids loading 10MB+ into memory
            response.bodyAsChannel().toInputStream().use { input ->
                tmpFile.parentFile?.mkdirs()
                tmpFile.outputStream().buffered().use { output ->
                    var bytesReceived = 0L
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE) // 8 KiB
                    var read = input.read(buffer)
                    while (read != -1) {
                        output.write(buffer, 0, read)
                        bytesReceived += read
                        if (contentLength > 0L) {
                            // Cap at 99 — 100 is emitted only after the atomic rename succeeds
                            val percent = minOf(99, ((bytesReceived * 100L) / contentLength).toInt())
                            setProgress(workDataOf(WorkerKeys.KEY_PROGRESS to percent))
                        }
                        read = input.read(buffer)
                    }
                }
            }

            // Atomic move: remove existing destination, rename .tmp → final path
            if (destFile.exists()) destFile.delete()
            if (!tmpFile.renameTo(destFile)) {
                // renameTo can fail cross-filesystem (e.g. tmp on cache, dest on files/)
                tmpFile.copyTo(destFile, overwrite = true)
                tmpFile.delete()
            }

            setProgress(workDataOf(WorkerKeys.KEY_PROGRESS to 100))
            // Write COMPLETED directly so the DB reflects the real state even when
            // the app was killed and the observe-flow is not running.
            val now = System.currentTimeMillis()
            database.transferTaskQueries.updateStatus(TransferStatus.COMPLETED.name, now, id)
            Result.success()
        } catch (e: Exception) {
            tmpFile.delete()
            // Write FAILED directly to the DB for the same reason as COMPLETED above.
            val now = System.currentTimeMillis()
            val errorMsg = e.message ?: "Download failed"
            database.transferTaskQueries.updateStatusAndError(TransferStatus.FAILED.name, errorMsg, now, id)
            Result.failure(workDataOf(WorkerKeys.KEY_ERROR to errorMsg))
        } finally {
            client.close()
        }
    }

    // -----------------------------------------------------------------------
    // Foreground service notification
    // -----------------------------------------------------------------------

    private fun buildForegroundInfo(contentText: String, taskId: String): ForegroundInfo {
        ensureNotificationChannel()

        val notificationId = WorkerKeys.notificationIdForTask(taskId, TransferType.DOWNLOAD)

        val notification = NotificationCompat.Builder(applicationContext, WorkerKeys.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("TwinSkin")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setSilent(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(
                notificationId,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
        } else {
            ForegroundInfo(notificationId, notification)
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                WorkerKeys.NOTIFICATION_CHANNEL_ID,
                WorkerKeys.NOTIFICATION_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW,
            )
            applicationContext
                .getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }
}
