// GENERATED CODE — DO NOT EDIT BY HAND
// Source: packages/sdk/tool/translations/data/sdk_translations.json
// Regenerate: fvm dart run tool/generate_sdk_translations.dart

package com.twinskin.sdk.ui.annotation_editor.generic.i18n

import com.twinskin.sdk.i18n.resolveLocale

internal interface SdkGenericStrings {
    val introTitle: String
    val introDescription: String
    val warningBanner: String
    val resumeBanner: String
    val resumeButton: String
    val startFreshButton: String
    val continueButton: String
    val helpContentDescription: String
    val backContentDescription: String
    val backButton: String
    val cancelButton: String
    val drawingTitle: String
    val undoButton: String
    val redoButton: String
    val deleteButton: String
    val validateButton: String
    val tooFarFromOpenStroke: String
    val abandonDialogTitle: String
    val abandonDialogBody: String
    val leaveButton: String
    val stayButton: String
    val saveFailedSnackbar: String
    val retryAction: String
    val canvasContentDescription: String
    val magnifierContentDescription: String
}

internal object EnGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Trace annotation"
    override val introDescription: String = "Draw the contours of the area(s) of interest."
    override val warningBanner: String = "Your work is only saved at final validation. Avoid leaving the app before then."
    override val resumeBanner: String = "This image already has annotations. Continue editing them, or start fresh?"
    override val resumeButton: String = "Resume"
    override val startFreshButton: String = "Start fresh"
    override val continueButton: String = "Continue"
    override val helpContentDescription: String = "Help"
    override val backContentDescription: String = "Back"
    override val backButton: String = "Back"
    override val cancelButton: String = "Cancel"
    override val drawingTitle: String = "Annotation"
    override val undoButton: String = "Undo"
    override val redoButton: String = "Redo"
    override val deleteButton: String = "Delete"
    override val validateButton: String = "Validate"
    override val tooFarFromOpenStroke: String = "Touch back closer to your line to continue it."
    override val abandonDialogTitle: String = "Leave the editor?"
    override val abandonDialogBody: String = "Your work is only saved at final validation. Leaving now discards every polygon you've drawn so far."
    override val leaveButton: String = "Leave"
    override val stayButton: String = "Stay"
    override val saveFailedSnackbar: String = "Save failed."
    override val retryAction: String = "Retry"
    override val canvasContentDescription: String = "Annotation canvas. Two fingers to zoom and pan."
    override val magnifierContentDescription: String = "Magnifier showing a 2x zoom of the area around your finger."
}

internal object FrGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Annotation par tracé"
    override val introDescription: String = "Dessinez les contours de la ou des zones d'intérêt."
    override val warningBanner: String = "Votre travail n'est enregistré qu'à la validation finale. Évitez de quitter l'application avant cela."
    override val resumeBanner: String = "Cette image comporte déjà des annotations. Continuer à les modifier ou repartir de zéro ?"
    override val resumeButton: String = "Reprendre"
    override val startFreshButton: String = "Repartir de zéro"
    override val continueButton: String = "Continuer"
    override val helpContentDescription: String = "Aide"
    override val backContentDescription: String = "Retour"
    override val backButton: String = "Retour"
    override val cancelButton: String = "Annuler"
    override val drawingTitle: String = "Annotation"
    override val undoButton: String = "Annuler"
    override val redoButton: String = "Rétablir"
    override val deleteButton: String = "Supprimer"
    override val validateButton: String = "Valider"
    override val tooFarFromOpenStroke: String = "Touchez plus près de votre ligne pour la continuer."
    override val abandonDialogTitle: String = "Quitter l'éditeur ?"
    override val abandonDialogBody: String = "Votre travail n'est enregistré qu'à la validation finale. Quitter maintenant supprime tous les polygones dessinés jusqu'ici."
    override val leaveButton: String = "Quitter"
    override val stayButton: String = "Rester"
    override val saveFailedSnackbar: String = "Échec de l'enregistrement."
    override val retryAction: String = "Réessayer"
    override val canvasContentDescription: String = "Zone d'annotation. Deux doigts pour zoomer et déplacer."
    override val magnifierContentDescription: String = "Loupe affichant un zoom 2x de la zone autour de votre doigt."
}

internal object DeGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Konturannotation"
    override val introDescription: String = "Zeichnen Sie die Konturen der interessierenden Bereiche."
    override val warningBanner: String = "Ihre Arbeit wird erst bei der endgültigen Validierung gespeichert. Verlassen Sie die App vorher nicht."
    override val resumeBanner: String = "Dieses Bild enthält bereits Anmerkungen. Bearbeitung fortsetzen oder neu beginnen?"
    override val resumeButton: String = "Fortsetzen"
    override val startFreshButton: String = "Neu beginnen"
    override val continueButton: String = "Weiter"
    override val helpContentDescription: String = "Hilfe"
    override val backContentDescription: String = "Zurück"
    override val backButton: String = "Zurück"
    override val cancelButton: String = "Abbrechen"
    override val drawingTitle: String = "Anmerkung"
    override val undoButton: String = "Rückgängig"
    override val redoButton: String = "Wiederholen"
    override val deleteButton: String = "Löschen"
    override val validateButton: String = "Bestätigen"
    override val tooFarFromOpenStroke: String = "Berühren Sie den Bildschirm näher an Ihrer Linie, um sie fortzusetzen."
    override val abandonDialogTitle: String = "Editor verlassen?"
    override val abandonDialogBody: String = "Ihre Arbeit wird erst bei der endgültigen Bestätigung gespeichert. Wenn Sie jetzt verlassen, gehen alle bisher gezeichneten Polygone verloren."
    override val leaveButton: String = "Verlassen"
    override val stayButton: String = "Bleiben"
    override val saveFailedSnackbar: String = "Speichern fehlgeschlagen."
    override val retryAction: String = "Wiederholen"
    override val canvasContentDescription: String = "Anmerkungsbereich. Zwei Finger zum Zoomen und Verschieben."
    override val magnifierContentDescription: String = "Lupe mit 2-facher Vergrößerung des Bereichs um Ihren Finger."
}

internal object EsGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Anotación de trazado"
    override val introDescription: String = "Dibuja los contornos de la(s) zona(s) de interés."
    override val warningBanner: String = "Tu trabajo solo se guarda al validar de forma definitiva. Evita salir de la aplicación antes de eso."
    override val resumeBanner: String = "Esta imagen ya tiene anotaciones. ¿Continuar editándolas o empezar de nuevo?"
    override val resumeButton: String = "Reanudar"
    override val startFreshButton: String = "Empezar de nuevo"
    override val continueButton: String = "Continuar"
    override val helpContentDescription: String = "Ayuda"
    override val backContentDescription: String = "Atrás"
    override val backButton: String = "Atrás"
    override val cancelButton: String = "Cancelar"
    override val drawingTitle: String = "Anotación"
    override val undoButton: String = "Deshacer"
    override val redoButton: String = "Rehacer"
    override val deleteButton: String = "Eliminar"
    override val validateButton: String = "Validar"
    override val tooFarFromOpenStroke: String = "Toque más cerca de su línea para continuarla."
    override val abandonDialogTitle: String = "¿Salir del editor?"
    override val abandonDialogBody: String = "Su trabajo solo se guarda en la validación final. Salir ahora descarta todos los polígonos dibujados hasta el momento."
    override val leaveButton: String = "Salir"
    override val stayButton: String = "Permanecer"
    override val saveFailedSnackbar: String = "Error al guardar."
    override val retryAction: String = "Reintentar"
    override val canvasContentDescription: String = "Lienzo de anotación. Use dos dedos para acercar y desplazar."
    override val magnifierContentDescription: String = "Lupa que muestra un zoom de 2x del área alrededor de su dedo."
}

internal object CsGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Anotace obrysu"
    override val introDescription: String = "Nakreslete obrysy sledované oblasti (oblastí)."
    override val warningBanner: String = "Vaše práce se uloží až při konečném potvrzení. Neopouštějte aplikaci předtím."
    override val resumeBanner: String = "Tento obrázek již obsahuje anotace. Pokračovat v jejich úpravě, nebo začít znovu?"
    override val resumeButton: String = "Pokračovat"
    override val startFreshButton: String = "Začít znovu"
    override val continueButton: String = "Pokračovat"
    override val helpContentDescription: String = "Nápověda"
    override val backContentDescription: String = "Zpět"
    override val backButton: String = "Zpět"
    override val cancelButton: String = "Zrušit"
    override val drawingTitle: String = "Anotace"
    override val undoButton: String = "Zpět"
    override val redoButton: String = "Znovu"
    override val deleteButton: String = "Smazat"
    override val validateButton: String = "Ověřit"
    override val tooFarFromOpenStroke: String = "Dotkněte se blíže k čáře, abyste v ní mohli pokračovat."
    override val abandonDialogTitle: String = "Opustit editor?"
    override val abandonDialogBody: String = "Vaše práce se ukládá až při konečném ověření. Ukončením nyní zrušíte všechny dosud nakreslené polygony."
    override val leaveButton: String = "Opustit"
    override val stayButton: String = "Zůstat"
    override val saveFailedSnackbar: String = "Uložení se nezdařilo."
    override val retryAction: String = "Zkusit znovu"
    override val canvasContentDescription: String = "Plátno pro anotace. Dvěma prsty přibližte a posouvejte."
    override val magnifierContentDescription: String = "Lupa zobrazující 2x zvětšení oblasti kolem vašeho prstu."
}

internal object SlGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Anotacija obrisa"
    override val introDescription: String = "Narišite obrise območja (območij) zanimanja."
    override val warningBanner: String = "Vaše delo se shrani šele ob končni potrditvi. Ne zapustite aplikacije pred tem."
    override val resumeBanner: String = "Ta slika že vsebuje pripombe. Želite nadaljevati z urejanjem ali začeti znova?"
    override val resumeButton: String = "Nadaljuj"
    override val startFreshButton: String = "Začni znova"
    override val continueButton: String = "Nadaljuj"
    override val helpContentDescription: String = "Pomoč"
    override val backContentDescription: String = "Nazaj"
    override val backButton: String = "Nazaj"
    override val cancelButton: String = "Prekliči"
    override val drawingTitle: String = "Pripomba"
    override val undoButton: String = "Razveljavi"
    override val redoButton: String = "Ponovi"
    override val deleteButton: String = "Izbriši"
    override val validateButton: String = "Potrdi"
    override val tooFarFromOpenStroke: String = "Dotaknite se bližje svoji črti, da jo nadaljujete."
    override val abandonDialogTitle: String = "Zapustite urejevalnik?"
    override val abandonDialogBody: String = "Vaše delo se shrani šele ob končni potrditvi. Če zdaj zapustite, boste zavrgli vse doslej narisane poligone."
    override val leaveButton: String = "Zapusti"
    override val stayButton: String = "Ostani"
    override val saveFailedSnackbar: String = "Shranjevanje ni uspelo."
    override val retryAction: String = "Poskusi znova"
    override val canvasContentDescription: String = "Platno za pripombe. Uporabite dva prsta za povečavo in premikanje."
    override val magnifierContentDescription: String = "Povečevalo, ki prikazuje 2-kratno povečavo območja okoli vašega prsta."
}

internal object SkGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Anotácia obrysu"
    override val introDescription: String = "Nakreslite obrysy sledovanej oblasti (oblastí)."
    override val warningBanner: String = "Vaša práca sa uloží až pri konečnom potvrdení. Neopúšťajte aplikáciu predtým."
    override val resumeBanner: String = "Tento obrázok už obsahuje anotácie. Chcete pokračovať v ich úprave, alebo začať odznova?"
    override val resumeButton: String = "Pokračovať"
    override val startFreshButton: String = "Začať odznova"
    override val continueButton: String = "Pokračovať"
    override val helpContentDescription: String = "Pomoc"
    override val backContentDescription: String = "Späť"
    override val backButton: String = "Späť"
    override val cancelButton: String = "Zrušiť"
    override val drawingTitle: String = "Anotácia"
    override val undoButton: String = "Späť"
    override val redoButton: String = "Znova"
    override val deleteButton: String = "Odstrániť"
    override val validateButton: String = "Overiť"
    override val tooFarFromOpenStroke: String = "Dotknite sa bližšie k čiare, aby ste v nej mohli pokračovať."
    override val abandonDialogTitle: String = "Opustiť editor?"
    override val abandonDialogBody: String = "Vaša práca sa uloží až pri konečnom overení. Ak teraz odídete, zahodíte všetky doteraz nakreslené polygóny."
    override val leaveButton: String = "Odísť"
    override val stayButton: String = "Zostať"
    override val saveFailedSnackbar: String = "Uloženie zlyhalo."
    override val retryAction: String = "Skúsiť znova"
    override val canvasContentDescription: String = "Plátno na anotácie. Dvoma prstami priblížite a posúvate."
    override val magnifierContentDescription: String = "Lupa zobrazujúca 2x priblíženie oblasti okolo vášho prsta."
}

internal object FilGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Trace annotation"
    override val introDescription: String = "Iguhit ang mga balangkas ng lugar(mga lugar) na pinag-iinteresan."
    override val warningBanner: String = "Ang iyong trabaho ay mase-save lamang sa huling validation. Iwasang umalis sa app bago iyon."
    override val resumeBanner: String = "May mga anotasyon na ang larawang ito. Ipagpatuloy ang pag-edit ng mga ito, o magsimula ulit?"
    override val resumeButton: String = "Ipagpatuloy"
    override val startFreshButton: String = "Magsimula ulit"
    override val continueButton: String = "Magpatuloy"
    override val helpContentDescription: String = "Tulong"
    override val backContentDescription: String = "Bumalik"
    override val backButton: String = "Bumalik"
    override val cancelButton: String = "Kanselahin"
    override val drawingTitle: String = "Anotasyon"
    override val undoButton: String = "I-undo"
    override val redoButton: String = "Gawing muli"
    override val deleteButton: String = "Tanggalin"
    override val validateButton: String = "I-validate"
    override val tooFarFromOpenStroke: String = "Hipuin nang mas malapit sa iyong linya upang ipagpatuloy ito."
    override val abandonDialogTitle: String = "Umalis sa editor?"
    override val abandonDialogBody: String = "Ang iyong trabaho ay naise-save lang sa huling validation. Ang pag-alis ngayon ay magtatapon sa lahat ng polygon na naiguhit mo."
    override val leaveButton: String = "Umalis"
    override val stayButton: String = "Manatili"
    override val saveFailedSnackbar: String = "Nabigo ang pag-save."
    override val retryAction: String = "Subukan muli"
    override val canvasContentDescription: String = "Canvas ng anotasyon. Gumamit ng dalawang daliri para mag-zoom at mag-pan."
    override val magnifierContentDescription: String = "Magnifier na nagpapakita ng 2x zoom sa lugar sa paligid ng iyong daliri."
}

internal object NlGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Annotatie door omlijning"
    override val introDescription: String = "Teken de contouren van het gebied of de gebieden van interesse."
    override val warningBanner: String = "Uw werk wordt alleen opgeslagen bij de definitieve validatie. Verlaat de app niet voordien."
    override val resumeBanner: String = "Deze afbeelding heeft al annotaties. Doorgaan met bewerken of opnieuw beginnen?"
    override val resumeButton: String = "Hervatten"
    override val startFreshButton: String = "Opnieuw beginnen"
    override val continueButton: String = "Doorgaan"
    override val helpContentDescription: String = "Help"
    override val backContentDescription: String = "Terug"
    override val backButton: String = "Terug"
    override val cancelButton: String = "Annuleren"
    override val drawingTitle: String = "Annotatie"
    override val undoButton: String = "Ongedaan maken"
    override val redoButton: String = "Opnieuw"
    override val deleteButton: String = "Verwijderen"
    override val validateButton: String = "Bevestigen"
    override val tooFarFromOpenStroke: String = "Raak het scherm dichter bij uw lijn aan om deze voort te zetten."
    override val abandonDialogTitle: String = "Editor verlaten?"
    override val abandonDialogBody: String = "Uw werk wordt pas opgeslagen bij de definitieve validatie. Als u nu vertrekt, gaan alle tot nu toe getekende polygonen verloren."
    override val leaveButton: String = "Verlaten"
    override val stayButton: String = "Blijven"
    override val saveFailedSnackbar: String = "Opslaan mislukt."
    override val retryAction: String = "Opnieuw proberen"
    override val canvasContentDescription: String = "Annotatiegebied. Twee vingers om te zoomen en te verslepen."
    override val magnifierContentDescription: String = "Vergrootglas met een 2x-zoom van het gebied rond uw vinger."
}

internal object NbGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Konturannotasjon"
    override val introDescription: String = "Tegn konturene til område(ne) av interesse."
    override val warningBanner: String = "Arbeidet ditt lagres først ved endelig validering. Unngå å forlate appen før det."
    override val resumeBanner: String = "Dette bildet har allerede annoteringer. Fortsett å redigere dem, eller start på nytt?"
    override val resumeButton: String = "Fortsett"
    override val startFreshButton: String = "Start på nytt"
    override val continueButton: String = "Fortsett"
    override val helpContentDescription: String = "Hjelp"
    override val backContentDescription: String = "Tilbake"
    override val backButton: String = "Tilbake"
    override val cancelButton: String = "Avbryt"
    override val drawingTitle: String = "Annotering"
    override val undoButton: String = "Angre"
    override val redoButton: String = "Gjør om"
    override val deleteButton: String = "Slett"
    override val validateButton: String = "Valider"
    override val tooFarFromOpenStroke: String = "Ta på skjermen nærmere linjen for å fortsette den."
    override val abandonDialogTitle: String = "Forlate redigeringsverktøyet?"
    override val abandonDialogBody: String = "Arbeidet ditt lagres først ved endelig validering. Hvis du forlater nå, forkastes alle polygoner du har tegnet så langt."
    override val leaveButton: String = "Forlat"
    override val stayButton: String = "Bli"
    override val saveFailedSnackbar: String = "Lagring mislyktes."
    override val retryAction: String = "Prøv igjen"
    override val canvasContentDescription: String = "Lerret for merknader. Bruk to fingre for å zoome og panorere."
    override val magnifierContentDescription: String = "Forstørrelsesglass som viser 2x forstørrelse av området rundt fingeren din."
}

internal object ItGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Annotazione del tracciato"
    override val introDescription: String = "Disegna i contorni dell'area/delle aree di interesse."
    override val warningBanner: String = "Il lavoro viene salvato solo alla convalida finale. Evita di uscire dall'app prima di allora."
    override val resumeBanner: String = "Questa immagine contiene già delle annotazioni. Continuare a modificarle o ricominciare da capo?"
    override val resumeButton: String = "Riprendi"
    override val startFreshButton: String = "Ricomincia"
    override val continueButton: String = "Continua"
    override val helpContentDescription: String = "Aiuto"
    override val backContentDescription: String = "Indietro"
    override val backButton: String = "Indietro"
    override val cancelButton: String = "Annulla"
    override val drawingTitle: String = "Annotazione"
    override val undoButton: String = "Annulla"
    override val redoButton: String = "Ripeti"
    override val deleteButton: String = "Elimina"
    override val validateButton: String = "Convalida"
    override val tooFarFromOpenStroke: String = "Tocca più vicino alla linea per continuarla."
    override val abandonDialogTitle: String = "Uscire dall'editor?"
    override val abandonDialogBody: String = "Il lavoro viene salvato solo alla convalida finale. Uscire ora comporta la perdita di tutti i poligoni disegnati finora."
    override val leaveButton: String = "Esci"
    override val stayButton: String = "Resta"
    override val saveFailedSnackbar: String = "Salvataggio non riuscito."
    override val retryAction: String = "Riprova"
    override val canvasContentDescription: String = "Tela di annotazione. Usa due dita per zoomare e scorrere."
    override val magnifierContentDescription: String = "Lente d'ingrandimento che mostra uno zoom 2x dell'area intorno al dito."
}

internal object JaGenericStrings : SdkGenericStrings {
    override val introTitle: String = "トレース注釈"
    override val introDescription: String = "対象領域の輪郭を描いてください。"
    override val warningBanner: String = "作業内容は最終検証時にのみ保存されます。それまではアプリを離れないでください。"
    override val resumeBanner: String = "この画像には既に注釈があります。編集を続けますか、それとも最初からやり直しますか？"
    override val resumeButton: String = "再開"
    override val startFreshButton: String = "最初からやり直す"
    override val continueButton: String = "続ける"
    override val helpContentDescription: String = "ヘルプ"
    override val backContentDescription: String = "戻る"
    override val backButton: String = "戻る"
    override val cancelButton: String = "キャンセル"
    override val drawingTitle: String = "注釈"
    override val undoButton: String = "元に戻す"
    override val redoButton: String = "やり直す"
    override val deleteButton: String = "削除"
    override val validateButton: String = "検証"
    override val tooFarFromOpenStroke: String = "線を続けるには、より近い位置に触れてください。"
    override val abandonDialogTitle: String = "エディタを終了しますか?"
    override val abandonDialogBody: String = "作業は最終検証時にのみ保存されます。今離れると、これまでに描画したすべてのポリゴンが破棄されます。"
    override val leaveButton: String = "離れる"
    override val stayButton: String = "とどまる"
    override val saveFailedSnackbar: String = "保存に失敗しました。"
    override val retryAction: String = "再試行"
    override val canvasContentDescription: String = "注釈キャンバス。2本の指でズームとパンができます。"
    override val magnifierContentDescription: String = "指の周囲の領域を2倍に拡大表示する拡大鏡です。"
}

internal object KoGenericStrings : SdkGenericStrings {
    override val introTitle: String = "윤곽 주석"
    override val introDescription: String = "관심 영역의 윤곽선을 그리십시오."
    override val warningBanner: String = "작업 내용은 최종 검증 시에만 저장됩니다. 그 전에 앱을 벗어나지 마십시오."
    override val resumeBanner: String = "이 이미지에는 이미 주석이 있습니다. 계속 편집하시겠습니까, 아니면 새로 시작하시겠습니까?"
    override val resumeButton: String = "재개"
    override val startFreshButton: String = "새로 시작"
    override val continueButton: String = "계속"
    override val helpContentDescription: String = "도움말"
    override val backContentDescription: String = "뒤로"
    override val backButton: String = "뒤로"
    override val cancelButton: String = "취소"
    override val drawingTitle: String = "주석"
    override val undoButton: String = "실행 취소"
    override val redoButton: String = "다시 실행"
    override val deleteButton: String = "삭제"
    override val validateButton: String = "확인"
    override val tooFarFromOpenStroke: String = "선을 계속하려면 더 가까운 곳을 터치하십시오."
    override val abandonDialogTitle: String = "편집기를 나가시겠습니까?"
    override val abandonDialogBody: String = "작업 내용은 최종 확인 시에만 저장됩니다. 지금 나가면 지금까지 그린 모든 다각형이 삭제됩니다."
    override val leaveButton: String = "나가기"
    override val stayButton: String = "계속하기"
    override val saveFailedSnackbar: String = "저장에 실패했습니다."
    override val retryAction: String = "다시 시도"
    override val canvasContentDescription: String = "주석 캔버스입니다. 두 손가락으로 확대/축소 및 이동할 수 있습니다."
    override val magnifierContentDescription: String = "손가락 주변 영역을 2배 확대하여 보여주는 돋보기입니다."
}

internal object PtGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Anotação de traçado"
    override val introDescription: String = "Desenhe os contornos da(s) área(s) de interesse."
    override val warningBanner: String = "O seu trabalho só é guardado na validação final. Evite sair da aplicação antes disso."
    override val resumeBanner: String = "Esta imagem já tem anotações. Continuar a editá-las ou começar de novo?"
    override val resumeButton: String = "Retomar"
    override val startFreshButton: String = "Começar de novo"
    override val continueButton: String = "Continuar"
    override val helpContentDescription: String = "Ajuda"
    override val backContentDescription: String = "Voltar"
    override val backButton: String = "Voltar"
    override val cancelButton: String = "Cancelar"
    override val drawingTitle: String = "Anotação"
    override val undoButton: String = "Anular"
    override val redoButton: String = "Refazer"
    override val deleteButton: String = "Eliminar"
    override val validateButton: String = "Validar"
    override val tooFarFromOpenStroke: String = "Toque mais perto da linha para a continuar."
    override val abandonDialogTitle: String = "Sair do editor?"
    override val abandonDialogBody: String = "O seu trabalho só é guardado na validação final. Sair agora descarta todos os polígonos desenhados até agora."
    override val leaveButton: String = "Sair"
    override val stayButton: String = "Ficar"
    override val saveFailedSnackbar: String = "Falha ao guardar."
    override val retryAction: String = "Tentar novamente"
    override val canvasContentDescription: String = "Tela de anotação. Use dois dedos para ampliar e mover."
    override val magnifierContentDescription: String = "Lupa que mostra uma ampliação de 2x da área à volta do seu dedo."
}

internal object PtBrGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Anotação de traçado"
    override val introDescription: String = "Desenhe os contornos da(s) área(s) de interesse."
    override val warningBanner: String = "Seu trabalho só é salvo na validação final. Evite sair do aplicativo antes disso."
    override val resumeBanner: String = "Esta imagem já tem anotações. Continuar editando ou começar do zero?"
    override val resumeButton: String = "Retomar"
    override val startFreshButton: String = "Começar do zero"
    override val continueButton: String = "Continuar"
    override val helpContentDescription: String = "Ajuda"
    override val backContentDescription: String = "Voltar"
    override val backButton: String = "Voltar"
    override val cancelButton: String = "Cancelar"
    override val drawingTitle: String = "Anotação"
    override val undoButton: String = "Desfazer"
    override val redoButton: String = "Refazer"
    override val deleteButton: String = "Excluir"
    override val validateButton: String = "Validar"
    override val tooFarFromOpenStroke: String = "Toque mais perto da linha para continuá-la."
    override val abandonDialogTitle: String = "Sair do editor?"
    override val abandonDialogBody: String = "Seu trabalho só é salvo na validação final. Sair agora descarta todos os polígonos desenhados até o momento."
    override val leaveButton: String = "Sair"
    override val stayButton: String = "Ficar"
    override val saveFailedSnackbar: String = "Falha ao salvar."
    override val retryAction: String = "Tentar novamente"
    override val canvasContentDescription: String = "Tela de anotação. Use dois dedos para dar zoom e mover."
    override val magnifierContentDescription: String = "Lupa que mostra uma ampliação de 2x da área ao redor do seu dedo."
}

internal object ViGenericStrings : SdkGenericStrings {
    override val introTitle: String = "Chú thích đường vẽ"
    override val introDescription: String = "Vẽ đường viền của (các) vùng quan tâm."
    override val warningBanner: String = "Công việc của bạn chỉ được lưu khi xác nhận cuối cùng. Tránh rời khỏi ứng dụng trước đó."
    override val resumeBanner: String = "Hình ảnh này đã có chú thích. Tiếp tục chỉnh sửa hay bắt đầu lại?"
    override val resumeButton: String = "Tiếp tục"
    override val startFreshButton: String = "Bắt đầu lại"
    override val continueButton: String = "Tiếp tục"
    override val helpContentDescription: String = "Trợ giúp"
    override val backContentDescription: String = "Quay lại"
    override val backButton: String = "Quay lại"
    override val cancelButton: String = "Hủy"
    override val drawingTitle: String = "Chú thích"
    override val undoButton: String = "Hoàn tác"
    override val redoButton: String = "Làm lại"
    override val deleteButton: String = "Xóa"
    override val validateButton: String = "Xác nhận"
    override val tooFarFromOpenStroke: String = "Chạm gần đường vẽ hơn để tiếp tục."
    override val abandonDialogTitle: String = "Rời khỏi trình chỉnh sửa?"
    override val abandonDialogBody: String = "Công việc của bạn chỉ được lưu khi xác nhận cuối cùng. Rời đi bây giờ sẽ hủy tất cả các đa giác đã vẽ."
    override val leaveButton: String = "Rời đi"
    override val stayButton: String = "Ở lại"
    override val saveFailedSnackbar: String = "Lưu không thành công."
    override val retryAction: String = "Thử lại"
    override val canvasContentDescription: String = "Vùng chú thích. Dùng hai ngón tay để phóng to và di chuyển."
    override val magnifierContentDescription: String = "Kính lúp hiển thị mức phóng đại 2x của khu vực quanh ngón tay."
}

internal object ZhGenericStrings : SdkGenericStrings {
    override val introTitle: String = "轮廓标注"
    override val introDescription: String = "请绘制关注区域的轮廓。"
    override val warningBanner: String = "您的操作仅在最终确认时才会保存。请勿在此之前离开应用程序。"
    override val resumeBanner: String = "此图像已有标注。是继续编辑，还是重新开始？"
    override val resumeButton: String = "继续"
    override val startFreshButton: String = "重新开始"
    override val continueButton: String = "继续"
    override val helpContentDescription: String = "帮助"
    override val backContentDescription: String = "返回"
    override val backButton: String = "返回"
    override val cancelButton: String = "取消"
    override val drawingTitle: String = "标注"
    override val undoButton: String = "撤销"
    override val redoButton: String = "重做"
    override val deleteButton: String = "删除"
    override val validateButton: String = "验证"
    override val tooFarFromOpenStroke: String = "请靠近线条触摸以继续绘制。"
    override val abandonDialogTitle: String = "要离开编辑器吗？"
    override val abandonDialogBody: String = "只有在最终验证时才会保存您的操作。现在离开将丢弃目前绘制的所有多边形。"
    override val leaveButton: String = "离开"
    override val stayButton: String = "留在此处"
    override val saveFailedSnackbar: String = "保存失败。"
    override val retryAction: String = "重试"
    override val canvasContentDescription: String = "标注画布。使用两指进行缩放和平移。"
    override val magnifierContentDescription: String = "放大镜显示手指周围区域的2倍放大效果。"
}

internal object ZhHantGenericStrings : SdkGenericStrings {
    override val introTitle: String = "輪廓標註"
    override val introDescription: String = "請繪製關注區域的輪廓。"
    override val warningBanner: String = "您的操作僅在最終確認時才會儲存。請勿在此之前離開應用程式。"
    override val resumeBanner: String = "此圖像已有標註。要繼續編輯，還是重新開始？"
    override val resumeButton: String = "繼續"
    override val startFreshButton: String = "重新開始"
    override val continueButton: String = "繼續"
    override val helpContentDescription: String = "說明"
    override val backContentDescription: String = "返回"
    override val backButton: String = "返回"
    override val cancelButton: String = "取消"
    override val drawingTitle: String = "標註"
    override val undoButton: String = "復原"
    override val redoButton: String = "重做"
    override val deleteButton: String = "刪除"
    override val validateButton: String = "驗證"
    override val tooFarFromOpenStroke: String = "請靠近線條觸碰以繼續繪製。"
    override val abandonDialogTitle: String = "要離開編輯器嗎？"
    override val abandonDialogBody: String = "只有在最終驗證時才會儲存您的操作。現在離開將捨棄目前繪製的所有多邊形。"
    override val leaveButton: String = "離開"
    override val stayButton: String = "留在此處"
    override val saveFailedSnackbar: String = "儲存失敗。"
    override val retryAction: String = "重試"
    override val canvasContentDescription: String = "標註畫布。使用兩指進行縮放與平移。"
    override val magnifierContentDescription: String = "放大鏡顯示手指周圍區域的2倍放大效果。"
}

internal fun genericStringsFor(locale: String): SdkGenericStrings =
    resolveLocale(locale, EnGenericStrings) {
        when (it) {
            "fr" -> FrGenericStrings
            "de" -> DeGenericStrings
            "es" -> EsGenericStrings
            "cs" -> CsGenericStrings
            "sl" -> SlGenericStrings
            "sk" -> SkGenericStrings
            "fil" -> FilGenericStrings
            "nl" -> NlGenericStrings
            "nb" -> NbGenericStrings
            "it" -> ItGenericStrings
            "ja" -> JaGenericStrings
            "ko" -> KoGenericStrings
            "pt" -> PtGenericStrings
            "pt-br" -> PtBrGenericStrings
            "vi" -> ViGenericStrings
            "zh" -> ZhGenericStrings
            "zh-hant" -> ZhHantGenericStrings
            else -> null
        }
    }
