package com.twinskin.sdk

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Which capture pipeline a capture session runs. The
 * [TwinSkinConfig] / [TwinSkinConfiguration] init-time mode is the default;
 * `startCapture` takes an optional per-capture override, resolved through
 * [TwinSkinSdk.resolveCaptureMode] (production always runs
 * [AccelerometerCapture]).
 *
 * Wire format mirrors the value persisted to [SdkCaptureUpload.captureMode]
 * and stamped on each capture row so the upload pipeline can pick the
 * matching bundle layout long after the originating session has ended.
 */
@Serializable
public enum class CaptureMode {
    @SerialName("photosphere") Photosphere,
    @SerialName("accelerometer_capture") AccelerometerCapture,
    @SerialName("face_capture") FaceCapture,
    ;

    internal fun toWireValue(): String = when (this) {
        Photosphere -> "photosphere"
        AccelerometerCapture -> "accelerometer_capture"
        FaceCapture -> "face_capture"
    }

    public companion object {
        internal fun fromWireValue(value: String?): CaptureMode = when (value) {
            // Legacy rows written before [CaptureMode] was persisted default to
            // photosphere — the only pipeline shipped at the time.
            null, "photosphere" -> Photosphere
            "accelerometer_capture" -> AccelerometerCapture
            "face_capture" -> FaceCapture
            // Server-only catch-all for captures not produced by an SDK
            // pipeline (e.g. re-homed pre-SDK captures). Never an on-device
            // capture mode; maps to photosphere silently.
            "other" -> Photosphere
            // A stale local row carrying a mode this binary doesn't know (e.g.
            // written by a newer SDK) must not crash init; fall back to
            // photosphere, matching the Swift + Flutter/Android parse policy.
            else -> {
                SdkLogger.Console.warn(
                    "Unknown captureMode wire value: $value; defaulting to photosphere",
                )
                Photosphere
            }
        }
    }
}
