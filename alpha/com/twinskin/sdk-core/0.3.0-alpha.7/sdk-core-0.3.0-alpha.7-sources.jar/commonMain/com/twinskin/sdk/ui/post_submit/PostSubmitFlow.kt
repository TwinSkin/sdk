@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.post_submit

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.CaptureMode
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.CaptureState
import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.error
import com.twinskin.sdk.ui.annotation_editor.generic.GenericAnnotationEditor
import com.twinskin.sdk.ui.annotation_editor.WoundAnnotationEditor
import com.twinskin.sdk.ui.annotation_editor.loadImageFromPath
import com.twinskin.sdk.ui.capture.i18n.LocalCaptureStrings
import com.twinskin.sdk.ui.capture.i18n.ProvideSdkCaptureStrings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Drives a capture session from `submit()` to the integrator's `onDone`,
 * routing on [ConditionType]:
 *   - [ConditionType.Wound] → dismisses immediately. Upload continues async via
 *     `TransferManager`; the embedder observes progress through
 *     `TwinSkinSdk.captures.observePendingUploads`.
 *   - [ConditionType.Generic] → observes [CaptureSession.state] and renders the
 *     polygon editor ([CaptureState.AwaitingAnnotation]), a 500 ms confirmation
 *     ([CaptureState.AnnotationSubmitted]), or a retry banner
 *     ([CaptureState.AnnotationSubmitFailed]); any pre-AwaitingAnnotation
 *     state shows a "Preparing…" overlay.
 *
 * Used directly by Android's CaptureScreen and embedded on iOS via
 * `PostSubmitFlowViewController`. Centralising the routing here keeps the
 * platform camera screens condition-type-agnostic — they only need to flip a
 * `submitted` flag after `session.submit(...)` returns.
 */
@TwinSkinInternalApi
@Composable
public fun PostSubmitFlow(
    session: CaptureSession,
    onDone: () -> Unit,
    onCancel: () -> Unit,
) {
    // Face sessions are Generic by coercion but never enter the annotation
    // flow — without this bail-out they'd spin on PreparingOverlay forever.
    if (session.metadata.conditionType == ConditionType.Wound ||
        session.captureMode == CaptureMode.FaceCapture
    ) {
        LaunchedEffect(Unit) { onDone() }
        return
    }

    val state by session.state.collectAsState()
    val scope = rememberCoroutineScope()

    ProvideSdkCaptureStrings {
        when (val s = state) {
            is CaptureState.AwaitingAnnotation -> AnnotationEditorView(
                session = session,
                photoPath = s.photoPath,
                scope = scope,
                onCancel = onCancel,
            )
            is CaptureState.AnnotationSubmitted -> {
                LaunchedEffect(Unit) {
                    delay(500)
                    onDone()
                }
                SubmittedOverlay()
            }
            is CaptureState.AnnotationSubmitFailed ->
                AnnotationSubmitErrorBanner(error = s.error, onRetry = s.retry)
            else -> PreparingOverlay()
        }
    }
}

@Composable
private fun AnnotationEditorView(
    session: CaptureSession,
    photoPath: String,
    scope: CoroutineScope,
    onCancel: () -> Unit,
) {
    var image by remember(photoPath) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(photoPath) {
        image = withContext(Dispatchers.Default) { loadImageFromPath(photoPath) }
    }
    val loaded = image
    if (loaded == null) {
        PreparingOverlay()
        return
    }
    val submit: (SdkAnnotation) -> Unit = { annotation ->
        scope.launch {
            try {
                session.submitAnnotation(annotation)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Re-emerges as CaptureState.AnnotationSubmitFailed.
            }
        }
    }
    when (session.metadata.conditionType) {
        ConditionType.Generic -> {
            GenericAnnotationEditor(
                image = loaded,
                onDone = { annotation -> submit(annotation) },
                onCancel = onCancel,
            )
        }
        // Unreachable today — gated upstream by CaptureApi.submit().
        ConditionType.Wound -> {
            WoundAnnotationEditor(
                image = loaded,
                onDone = { annotation -> submit(annotation) },
                onCancel = onCancel,
            )
        }
    }
}

@Composable
private fun PreparingOverlay() {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator()
            Spacer(Modifier.height(12.dp))
            Text(LocalCaptureStrings.current.preparing, color = Color.White)
        }
    }
}

@Composable
private fun SubmittedOverlay() {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        Text(LocalCaptureStrings.current.annotationSubmitted, color = Color.White)
    }
}

@Composable
private fun AnnotationSubmitErrorBanner(error: Throwable, onRetry: () -> Unit) {
    LaunchedEffect(error) {
        TwinSkinSdk.requireComponent().logger.error("Annotation submit failed", error)
    }
    Column(
        modifier = Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            "Annotation submit failed: ${error.message ?: error::class.simpleName ?: "unknown"}",
            style = MaterialTheme.typography.bodyLarge,
            color = Color.White,
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onRetry) { Text(LocalCaptureStrings.current.errorRetry) }
    }
}
