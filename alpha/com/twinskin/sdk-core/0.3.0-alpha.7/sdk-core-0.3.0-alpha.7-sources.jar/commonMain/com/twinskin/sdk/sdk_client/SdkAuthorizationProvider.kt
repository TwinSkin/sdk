package com.twinskin.sdk.sdk_client

import kotlin.concurrent.Volatile

/**
 * Asks the integrator's backend for a fresh session-token payload for
 * a given subject. A typical implementation:
 *
 *  1. Authenticates / authorizes the caller against the integrator's
 *     own session.
 *  2. Calls Twinskin's `POST /api/sdk/sessions/token` endpoint with
 *     the integrator's private key and the supplied [subjectRef].
 *  3. Returns the response body verbatim.
 *
 * The SDK parses the response internally — integrators treat it as an
 * opaque payload. The subject is passed per-call because the minted
 * token is subject-scoped (upload authorization checks the subject
 * claim), so an SDK asking about a new subject necessarily needs a
 * new call.
 *
 * The publishable key lives in `TwinSkinConfig`, not here; it can change
 * at runtime — a repeat `TwinSkin.initialize` adopts a corrected or
 * rotated key in place (see `TwinSkinSdk.reconcileRepeatInitialize`), so
 * never cache it at construction.
 *
 * Implementations should be cheap and safe to call from any coroutine
 * context — the SDK invokes this lazily on every request so a 401-
 * driven retry picks up a refreshed response.
 *
 * Throwing, or returning a blank/unparseable payload, is logged at error
 * level (see `fetchAndParseSessionToken`).
 */
public fun interface SdkAuthorizationProvider {
    public suspend fun fetchSessionToken(subjectRef: String): String
}

/**
 * Stable delegating provider installed at `initialize`: every consumer
 * (HTTP auth interceptor, PowerSync connector) holds THIS instance for the
 * process lifetime, while a repeat `initialize` swaps the delegate via
 * [rebind] so the freshly supplied provider takes effect everywhere —
 * including already-open PowerSync connections, whose connector re-fetches
 * through the wrapper. Without the indirection the first call's provider
 * closure is pinned; Flutter hosts rebuild the closure per engine, so the
 * pinned one dies with its engine (dead channel / NPE on every token
 * fetch after an add-to-app engine recreate).
 */
internal class MutableSdkAuthorizationProvider(
    delegate: SdkAuthorizationProvider,
) : SdkAuthorizationProvider {
    @Volatile
    private var delegate: SdkAuthorizationProvider = delegate

    override suspend fun fetchSessionToken(subjectRef: String): String =
        delegate.fetchSessionToken(subjectRef)

    fun rebind(provider: SdkAuthorizationProvider) {
        delegate = provider
    }
}

/**
 * Demo/testing provider that always returns the same payload
 * regardless of [subjectRef]. Real host apps plug in a provider that
 * calls their own backend.
 */
internal class ConstantSessionTokenProvider(
    private val payload: String,
) : SdkAuthorizationProvider {
    override suspend fun fetchSessionToken(subjectRef: String): String = payload
}
