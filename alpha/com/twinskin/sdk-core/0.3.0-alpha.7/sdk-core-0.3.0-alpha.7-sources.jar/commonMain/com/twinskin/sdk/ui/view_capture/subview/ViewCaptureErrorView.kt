@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.error
import com.twinskin.sdk.i18n.sdkLocale
import com.twinskin.sdk.ui.capture.i18n.captureStringsFor
import com.twinskin.sdk.ui.theme.TwinSkinColors
import com.twinskin.sdk.view.ViewCaptureError

/**
 * Dark-stage error screen (prototype `ViewerErrorScreen`): a soft-coral
 * warning disc, white title + muted body, and a cyan Retry CTA for the
 * recoverable cases. "Close viewer" lives in the floating top bar (the
 * stateless [ViewCaptureActions.onClose]), so it isn't duplicated here —
 * this view only owns the retry affordance per [onRetry].
 */
@TwinSkinInternalApi
@Composable
public fun ViewCaptureErrorView(
    error: ViewCaptureError,
    onRetry: () -> Unit,
) {
    val strings = remember { captureStringsFor(sdkLocale()) }
    val icon: ImageVector
    val title: String
    val message: String
    val retryable: Boolean
    when (error) {
        ViewCaptureError.Network -> {
            icon = Icons.Default.CloudOff
            title = strings.viewerErrorNetworkTitle
            message = strings.viewerErrorNetworkBody
            retryable = true
        }
        ViewCaptureError.NotFound -> {
            icon = Icons.Default.SearchOff
            title = strings.viewerErrorNotFoundTitle
            message = strings.viewerErrorNotFoundBody
            // Retryable: NotFound can be transient — the capture row may simply
            // not have synced yet (resolver grace window elapsed on a slow
            // connection), so a retry after sync often succeeds.
            retryable = true
        }
        is ViewCaptureError.Credentials -> {
            icon = Icons.Default.Lock
            title = strings.viewerErrorCredentialsTitle
            message = strings.viewerErrorCredentialsBody
            retryable = true
        }
        is ViewCaptureError.InvalidAsset -> {
            icon = Icons.Default.ErrorOutline
            title = strings.viewerErrorInvalidAssetTitle
            message = strings.viewerErrorInvalidAssetBody
            retryable = false
        }
        is ViewCaptureError.Unknown -> {
            icon = Icons.Default.ErrorOutline
            title = strings.viewerErrorUnknownTitle
            message = strings.viewerErrorUnknownBody
            retryable = true
        }
    }
    LaunchedEffect(error) {
        val (detail, cause) = when (error) {
            is ViewCaptureError.Credentials -> "Credentials" to error.cause
            is ViewCaptureError.Unknown -> "Unknown" to error.cause
            is ViewCaptureError.InvalidAsset -> "InvalidAsset(${error.reason})" to null
            ViewCaptureError.Network -> "Network" to null
            ViewCaptureError.NotFound -> "NotFound" to null
        }
        TwinSkinSdk.requireComponent().logger.error("ViewCapture error: $detail", cause)
    }

    ViewerStageBackground(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 36.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier
                    .size(82.dp)
                    .clip(CircleShape)
                    .background(TwinSkinColors.ErrorSoft.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = TwinSkinColors.ErrorSoft,
                    modifier = Modifier.size(38.dp),
                )
            }
            Spacer(Modifier.height(24.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = message,
                color = Color.White.copy(alpha = 0.62f),
                fontSize = 14.5.sp,
                textAlign = TextAlign.Center,
            )
            if (retryable) {
                Spacer(Modifier.height(28.dp))
                ViewerErrorRetryButton(onRetry)
            }
        }
    }
}

@Composable
private fun ViewerErrorRetryButton(onRetry: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
            .background(TwinSkinColors.Cyan)
            .clickable(onClick = onRetry)
            .padding(vertical = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = remember { captureStringsFor(sdkLocale()) }.viewerRetryAction.uppercase(),
            color = TwinSkinColors.OnCyan,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}
