package com.twinskin.sdk.transfer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/**
 * Android implementation of [ZipEngine] using [java.util.zip.ZipInputStream].
 *
 * Extracts a zip archive at [source] into [target] directory, preserving relative paths.
 * [cleanup] deletes [target] recursively if it exists, so unzip always starts fresh.
 */
internal class AndroidZipEngine : ZipEngine {

    override suspend fun unzip(source: String, target: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val targetDir = File(target)
                targetDir.mkdirs()

                ZipInputStream(File(source).inputStream().buffered()).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val outputFile = File(targetDir, entry.name)

                        // Guard against zip-slip: ensure the resolved path is strictly
                        // within targetDir. The separator suffix prevents a directory
                        // named "/data/target" from matching "/data/target2/evil.txt".
                        val canonicalTarget = targetDir.canonicalPath + File.separator
                        val canonicalOutput = outputFile.canonicalPath
                        require(canonicalOutput.startsWith(canonicalTarget) || canonicalOutput == targetDir.canonicalPath) {
                            "Zip entry attempts to write outside target directory: ${entry.name}"
                        }

                        if (entry.isDirectory) {
                            outputFile.mkdirs()
                        } else {
                            outputFile.parentFile?.mkdirs()
                            FileOutputStream(outputFile).buffered().use { out ->
                                zis.copyTo(out)
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
        }

    override suspend fun cleanup(path: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(path)
                if (dir.exists()) {
                    dir.deleteRecursively()
                }
            }
        }
}
