package com.twinskin.sdk.capture

import java.time.Instant
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

internal actual fun epochMillisToIso8601(epochMillis: Long): String =
    DateTimeFormatter.ISO_INSTANT
        .format(Instant.ofEpochMilli(epochMillis).truncatedTo(ChronoUnit.SECONDS))

internal actual fun iso8601ToEpochMillis(iso: String): Long? =
    runCatching { Instant.parse(iso).toEpochMilli() }
        .recoverCatching { OffsetDateTime.parse(iso).toInstant().toEpochMilli() }
        .getOrNull()
