package com.twinskin.sdk.capture

import android.content.Context
import com.powersync.DatabaseDriverFactory
import com.powersync.PowerSyncDatabase
import com.powersync.connectors.PowerSyncBackendConnector
import com.twinskin.sdk.SdkLogger
import kotlinx.coroutines.CoroutineScope

/**
 * Android-side [PowerSyncClientFactory]. Every `open` mints a fresh
 * [PowerSyncDatabase] — [ServerCaptureSource] shares it across
 * collectors via the `shareIn` cache, and closes it once the idle
 * timeout fires.
 *
 * The per-subject dbFilename separates on-disk state per subject so
 * two simultaneous `observeSubject(X)` / `observeSubject(Y)` calls
 * can't race on the same SQLite file.
 */
internal class AndroidPowerSyncClientFactory(
    private val context: Context,
    private val scope: CoroutineScope,
    private val logger: SdkLogger? = null,
) : PowerSyncClientFactory {
    override suspend fun open(
        subjectRef: String,
        connector: PowerSyncBackendConnector,
    ): PowerSyncClient {
        val database = PowerSyncDatabase(
            factory = DatabaseDriverFactory(context.applicationContext),
            schema = SdkCapturePowerSyncSchema.schema,
            dbFilename = sdkCapturesDbFilename(subjectRef),
        )
        return RealPowerSyncClient(database, connector, scope, logger)
    }
}
