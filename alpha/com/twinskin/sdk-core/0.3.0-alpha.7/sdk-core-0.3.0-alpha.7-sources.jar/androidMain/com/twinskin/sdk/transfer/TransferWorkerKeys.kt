package com.twinskin.sdk.transfer

internal object WorkerKeys {
    const val KEY_ID = "transfer_id"
    const val KEY_URL = "transfer_url"
    /** Stable server-side upload key passed to the [UrlResolver]. Uploads only. */
    const val KEY_UPLOAD_KEY = "transfer_upload_key"
    const val KEY_PATH = "transfer_path"
    const val KEY_PROGRESS = "transfer_progress"
    const val KEY_ERROR = "transfer_error"
    /** JSON-encoded `Map<String, String>` of extra HTTP headers. Absent means no extra headers. */
    const val KEY_HEADERS = "transfer_headers"

    const val NOTIFICATION_CHANNEL_ID = "com.twinskin.sdk.transfers"
    const val NOTIFICATION_CHANNEL_NAME = "File Transfers"

    /**
     * Derives a stable notification ID from a task ID and transfer type.
     *
     * Each concurrent transfer gets its own notification instead of overwriting a shared one.
     * Deterministic: the same task always produces the same ID, so progress updates replace
     * the existing notification rather than creating a new one.
     *
     * Android notification IDs are plain `Int` — negative values are valid. We XOR with a
     * type-specific salt so an upload and a download for the same task ID don't collide.
     *
     * Hash collisions between different task IDs are theoretically possible but vanishingly
     * unlikely given our 16-byte random hex IDs. The worst case is two notifications
     * overwriting each other — no data loss, just a cosmetic glitch.
     */
    fun notificationIdForTask(taskId: String, type: TransferType): Int {
        val salt = if (type == TransferType.UPLOAD) 0x55_50 else 0x44_4C // 'UP' vs 'DL'
        return taskId.hashCode() xor salt
    }
}
