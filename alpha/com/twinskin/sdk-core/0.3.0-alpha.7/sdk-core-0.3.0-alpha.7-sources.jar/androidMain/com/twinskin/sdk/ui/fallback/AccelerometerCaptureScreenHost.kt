@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.fallback

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.twinskin.sdk.CaptureMode
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.capture.fallback.VideoCaptureResult
import com.twinskin.sdk.capture.fallback.createAccelerometerDriver
import com.twinskin.sdk.capture.fallback.createAccelerometerVideoRecorder
import com.twinskin.sdk.ui.capture.i18n.ProvideSdkCaptureStrings
import com.twinskin.sdk.ui.capture.rememberCapturePermissionsState
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.SdkReferenceLuminance
import com.twinskin.sdk.ui.capture.RefRecommendation
import com.twinskin.photosphere.MarkerRefine
import com.twinskin.photosphere.MarkerValidator
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@TwinSkinInternalApi
@Composable
public fun AccelerometerCaptureScreenHost(
    metadata: SdkCaptureMetadata?,
    onDone: (CaptureSession) -> Unit,
    onCancel: () -> Unit,
    onSessionStarted: (CaptureSession) -> Unit = {},
    startSession: (SdkCaptureMetadata) -> CaptureSession = {
        TwinSkinSdk.startCapture(it, CaptureMode.AccelerometerCapture)
    },
) {
    if (metadata == null) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black))
        return
    }

    // The runtime CAMERA prompt is never auto-fired: a rationale pre-prompt is
    // shown first. The ON_RESUME re-check inside [rememberCapturePermissionsState]
    // flips `granted` when the operator returns from Settings — no re-tap needed.
    val permissions = rememberCapturePermissionsState()
    if (!permissions.granted) {
        // `permanentlyDenied` is only meaningful once the OS prompt has fired
        // at least once; before that the rationale is the pre-prompt.
        ProvideSdkCaptureStrings {
            when (capturePermissionPhase(
                granted = permissions.granted,
                permanentlyDenied = permissions.permanentlyDenied,
            )) {
                CapturePermissionPhase.Blocked -> CapturePermissionBlocked(
                    onOpenSettings = permissions.openAppSettings,
                    onCancel = onCancel,
                )
                else -> CapturePermissionRationale(
                    onAllow = permissions.request,
                    onCancel = onCancel,
                )
            }
        }
        return
    }

    val orientationContext = LocalContext.current
    DisposableEffect(Unit) {
        val activity = orientationContext.findActivity()
        val previous = activity?.requestedOrientation
        if (activity != null) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
        onDispose {
            if (activity != null && previous != null) {
                activity.requestedOrientation = previous
            }
        }
    }

    val keepScreenOnView = LocalView.current
    val brightnessActivity = LocalContext.current.findActivity()
    DisposableEffect(keepScreenOnView, brightnessActivity) {
        val window = brightnessActivity?.window
        val previousKeepOn = keepScreenOnView.keepScreenOn
        val previousBrightness = window?.attributes?.screenBrightness
        keepScreenOnView.keepScreenOn = true
        window?.let {
            val params = it.attributes
            params.screenBrightness = 1f
            it.attributes = params
        }
        onDispose {
            keepScreenOnView.keepScreenOn = previousKeepOn
            window?.let {
                val params = it.attributes
                params.screenBrightness = previousBrightness
                    ?: android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                it.attributes = params
            }
        }
    }

    val scope = rememberCoroutineScope()
    val session = remember(metadata) { startSession(metadata).also(onSessionStarted) }

    val recorderContext = LocalContext.current
    val recorderLifecycleOwner = LocalLifecycleOwner.current

    // The PreviewView is created once and remembered across recomposition
    // so its surface lives long enough for CameraX to bind into it. The
    // surface provider is handed to the recorder via the factory so the
    // recorder's bindToLifecycle() can attach Preview alongside
    // VideoCapture. Without an attached Preview, some devices never
    // stream frames → recorder.stop() times out at finalization (#538).
    val previewView = remember(recorderContext) {
        PreviewView(recorderContext).apply {
            // PERFORMANCE = SurfaceView, lower latency and more
            // device-compatible. COMPATIBLE (TextureView) has been
            // observed to leave the surface blank on some Samsung
            // devices (A21S, Xcover 5) where the Camera2 backend
            // doesn't feed frames into the TextureView path. The
            // photosphere capture screen uses the same default.
            implementationMode = PreviewView.ImplementationMode.PERFORMANCE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }

    val recorder = remember(session, previewView) {
        createAccelerometerVideoRecorder(
            recorderContext,
            recorderLifecycleOwner,
            previewSurfaceProvider = previewView.surfaceProvider,
        )
    }

    val torchControl = remember(recorder) { CameraXTorchControl() }

    val preferences = remember(recorderContext) { sdkUserPreferences(recorderContext) }

    val controller = remember(session, recorder) {
        AccelerometerCaptureController(
            scope = scope,
            recorder = recorder,
            driver = createAccelerometerDriver(),
            takeStillPhoto = {
                recorder.takeStillPhoto(
                    "${session.workingDir.trimEnd('/')}/photo.jpg"
                )
            },
            videoOutputPath = {
                "${session.workingDir.trimEnd('/')}/video.mp4"
            },
            onResult = { result -> deliverResult(session, result, onDone) },
            onError = { /* surfaced by Error state in the screen */ },
            lowLightProbe = { stillPath ->
                stillReadsLowLight(stillPath, torch = torchControl.isTorchEnabled())
            },
            markerProbe = { stillPath -> probeMarker(stillPath) },
        )
    }

    LaunchedEffect(controller) { controller.markCameraReady() }

    val cancelSession: () -> Unit = {
        scope.launch {
            try { session.cancel() } finally { onCancel() }
        }
    }
    BackHandler { cancelSession() }

    // Bind torch after `markCameraReady` runs — `LaunchedEffect`s
    // with the same key execute in source order, so this lands after
    // the bind in line 220 and reads a non-null `recorder.camera`.
    // `isAvailable()` is checked by the screen before painting the
    // flash slot, so a still-null camera just hides the button.
    LaunchedEffect(controller) { torchControl.bind(recorder.camera) }

    AccelerometerCaptureScreen(
        controller = controller,
        onCancel = cancelSession,
        torchControl = torchControl,
        userPreferences = preferences,
        cameraPreview = {
            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize(),
            )
        },
        coachImages = rememberCoachImages(recorderContext),
        demoSession = session,
        onDemoSubmitted = { onDone(session) },
    )
}

/**
 * Host-supplied coach imagery. The SDK ships these assets in
 * `:android-sdk/src/main/assets`, which merges into the consuming app's asset
 * namespace, so partner apps get the imagery for free. Both wound coach slots
 * use the same illustration; the marker-not-detected card uses the distinct
 * `calibration_marker.png` (the printed pattern the operator lays by the wound).
 * A decode failure leaves the slot null, falling back to the card's white box.
 */
@Composable
private fun rememberCoachImages(context: Context): CaptureCoachImages {
    val wound: Painter? = remember(context) { decodeAsset(context, COACH_WOUND_ASSET) }
    val marker: Painter? = remember(context) { decodeAsset(context, COACH_MARKER_ASSET) }
    return remember(wound, marker) {
        CaptureCoachImages(woundLive = wound, woundMarker = wound, markerReference = marker)
    }
}

private fun decodeAsset(context: Context, name: String): Painter? = try {
    context.assets.open(name).use {
        BitmapPainter(BitmapFactory.decodeStream(it).asImageBitmap())
    }
} catch (_: Throwable) {
    null
}

private const val COACH_WOUND_ASSET = "wound_b_2.jpg"
private const val COACH_MARKER_ASSET = "calibration_marker.png"

private suspend fun deliverResult(
    session: CaptureSession,
    result: VideoCaptureResult,
    onDone: (CaptureSession) -> Unit,
) {
    session.submit(result)
    onDone(session)
}

/**
 * Decodes the still once and produces both outputs off the UI thread:
 *
 * - The presentation-only low-light boolean (coarse-grid Rec.601 mean luma
 *   through the shared [LowLightProbe] threshold).
 * - The manifest's `reference_luminance` block via the shared native
 *   `xfeat_ref_luminance_eval`.
 *
 * `blurOk = true`: the accelerometer path has no per-frame blur verdict, so the
 * torch ladder is told the frame is sharp. Any failure reads as "not low-light,
 * no block" so a probe error never traps the operator nor fabricates a value.
 */
private suspend fun stillReadsLowLight(stillPath: String, torch: Boolean): LowLightProbeResult =
    withContext(Dispatchers.Default) {
        try {
            val opts = BitmapFactory.Options().apply { inSampleSize = 8 }
            val bmp = BitmapFactory.decodeFile(stillPath, opts)
                ?: return@withContext LowLightProbeResult.NotLowLight
            try {
                val w = bmp.width
                val h = bmp.height
                if (w == 0 || h == 0) return@withContext LowLightProbeResult.NotLowLight
                // Sample on a coarse grid — full per-pixel reads aren't needed
                // for a mean-luma gate and keep the probe cheap on low-end SKUs.
                val stepX = (w / 32).coerceAtLeast(1)
                val stepY = (h / 32).coerceAtLeast(1)
                var sum = 0.0
                var n = 0
                var y = 0
                while (y < h) {
                    var x = 0
                    while (x < w) {
                        val p = bmp.getPixel(x, y)
                        val r = (p shr 16) and 0xFF
                        val g = (p shr 8) and 0xFF
                        val b = p and 0xFF
                        sum += 0.299 * r + 0.587 * g + 0.114 * b
                        n++
                        x += stepX
                    }
                    y += stepY
                }
                val lowLight = n != 0 && LowLightProbe.isLowLight(sum / n)
                val luminance = evalRefLuminance(bmp, w, h, torch)
                LowLightProbeResult(lowLight = lowLight, referenceLuminance = luminance)
            } finally {
                bmp.recycle()
            }
        } catch (_: Throwable) {
            LowLightProbeResult.NotLowLight
        }
    }

/**
 * Run the shared native reference-luminance eval on [bmp]. Packs the bitmap into
 * a PACKED RGBA direct [ByteBuffer] (rowStride = width*4, the
 * [MarkerValidator.evalRefLuminance] contract). Null on any native-side failure
 * so a probe error never fabricates a block.
 */
private fun evalRefLuminance(
    bmp: android.graphics.Bitmap,
    width: Int,
    height: Int,
    torch: Boolean,
): SdkReferenceLuminance? = try {
    val pixels = IntArray(width * height)
    bmp.getPixels(pixels, 0, width, 0, 0, width, height)
    val rgba = ByteBuffer.allocateDirect(width * height * 4).order(ByteOrder.nativeOrder())
    for (p in pixels) {
        rgba.put(((p shr 16) and 0xFF).toByte()) // R
        rgba.put(((p shr 8) and 0xFF).toByte())  // G
        rgba.put((p and 0xFF).toByte())          // B
        rgba.put(0xFF.toByte())                  // A (ignored by the eval)
    }
    rgba.rewind()
    val lum = MarkerValidator.evalRefLuminance(
        rgba = rgba,
        width = width,
        height = height,
        rowStride = width * 4,
        // No per-frame blur verdict on this path; the boolean card owns the
        // dark-frame UX, so the torch ladder is told the frame is sharp.
        blurOk = true,
    )
    SdkReferenceLuminance(
        meanY = lum.meanLuma.toDouble(),
        darkShare = lum.darkPixelShare.toDouble(),
        brightShare = lum.brightPixelShare.toDouble(),
        recommendation = lum.recommendation.toCommon().manifestCode,
        torch = torch,
    )
} catch (_: Throwable) {
    null
}

/** Adapter from the photosphere_capture native enum to the cross-platform
 *  [RefRecommendation] used for wire serialisation. Mirrors the photosphere
 *  path's private `toCommon()` in `CaptureScreen.kt`. */
private fun MarkerValidator.RefRecommendation.toCommon(): RefRecommendation =
    when (this) {
        MarkerValidator.RefRecommendation.OK -> RefRecommendation.ok
        MarkerValidator.RefRecommendation.RETAKE_FOR_FOCUS -> RefRecommendation.retakeForFocus
        MarkerValidator.RefRecommendation.RECOMMEND_TORCH -> RefRecommendation.recommendTorch
        MarkerValidator.RefRecommendation.RETAKE_WITH_TORCH -> RefRecommendation.retakeWithTorch
        MarkerValidator.RefRecommendation.ADVISORY_HIGHLIGHTS_CLIPPED ->
            RefRecommendation.advisoryHighlightsClipped
    }

/**
 * Marker probe + version derivation, run off the UI thread. Decodes the still to
 * a grayscale Y-plane and runs the shared photosphere ArUco refiner. Mirrors the
 * photosphere `CameraSessionController` mapping: a decode whose `id ==
 * EXPECTED_ARUCO_MARKER_ID` reports [MarkerProbeResult.Expected] (version
 * `"v3"`), any other / no decode reports [MarkerProbeResult.Absent], and any
 * failure reads as [MarkerProbeResult.Detected] so a probe error never raises a
 * false warning nor stamps an unverified version.
 */
private suspend fun probeMarker(stillPath: String): MarkerProbeResult =
    withContext(Dispatchers.Default) {
        try {
            // Cap the long side so a full-res still doesn't blow up the per-pixel
            // gray copy or the ArUco pass on low-end SKUs; inSampleSize is the
            // cheapest decoder-side downscale.
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(stillPath, bounds)
            val longSide = maxOf(bounds.outWidth, bounds.outHeight)
            if (longSide <= 0) return@withContext MarkerProbeResult.Detected
            var sample = 1
            while (longSide / (sample * 2) >= MARKER_DECODE_MAX_LONG_SIDE) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = BitmapFactory.decodeFile(stillPath, opts)
                ?: return@withContext MarkerProbeResult.Detected
            try {
                val w = bmp.width
                val h = bmp.height
                if (w <= 0 || h <= 0) return@withContext MarkerProbeResult.Detected
                val pixels = IntArray(w * h)
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                val gray = ByteBuffer.allocateDirect(w * h).order(ByteOrder.nativeOrder())
                for (p in pixels) {
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    val luma = (r * 77 + g * 150 + b * 29) shr 8
                    gray.put(luma.toByte())
                }
                gray.rewind()
                val refined = MarkerRefine.aruco(
                    gray = gray,
                    width = w,
                    height = h,
                    rowStride = w,
                    roiX0 = 0,
                    roiY0 = 0,
                    roiX1 = w,
                    roiY1 = h,
                )
                when {
                    refined == null -> MarkerProbeResult.Absent
                    refined.id == EXPECTED_ARUCO_MARKER_ID -> MarkerProbeResult.Expected
                    else -> MarkerProbeResult.Absent
                }
            } finally {
                bmp.recycle()
            }
        } catch (_: Throwable) {
            MarkerProbeResult.Detected
        }
    }

private const val MARKER_DECODE_MAX_LONG_SIDE = 1280

// Mirrors the photosphere `CameraSessionController.EXPECTED_ARUCO_MARKER_ID`
// (16). Kept in lock-step: a marker decoding to this id maps to version "v3".
private const val EXPECTED_ARUCO_MARKER_ID: Int = 16

private fun android.content.Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}
