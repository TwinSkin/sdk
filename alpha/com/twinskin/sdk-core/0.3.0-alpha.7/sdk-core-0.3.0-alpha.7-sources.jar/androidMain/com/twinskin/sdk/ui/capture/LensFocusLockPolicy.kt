package com.twinskin.sdk.ui.capture

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.util.Log

/**
 * per-HAL policy for the photosphere lens-lock posture used
 * by [CameraSessionController.lockLensAndExposureForPhotosphere].
 *
 * Background — see
 * `evaluate-xfeat-lighterglue/docs/tracking/cl103-pixel6-focus-lock-fix-2026-05-08.md`
 * and the predecessor architect finding
 * `android-focus-lock-broken-2026-04-30.md` § "XCover 5 HAL caveat".
 *
 * The CL-079 fix wrote `CONTROL_AF_MODE_OFF + AE_LOCK + AWB_LOCK` via
 * Camera2Interop on every device. That works on the LIMITED-HAL
 * Samsung XCover 5 (`SM-G525F`) and A21s (`SM-A217F`) — both pin the
 * lens at whatever position the prior `FocusMeteringAction` converged
 * to and hold it for the duration of the override. It does NOT work on
 * the FULL-HAL Pixel 6 (`oriole`) — the Tensor camera HAL drives the
 * lens to the hyperfocal default the moment `AF_MODE_OFF` engages,
 * effectively ignoring whatever the prior continuous-AF kernel had
 * converged. Operator-visible: the photosphere preview goes blurry the
 * instant the reference shutter fires, and stays blurry through every
 * arm of the sweep.
 *
 * Strategy chosen here:
 *
 *  - **FULL / LEVEL_3** AND `LENS_INFO_FOCUS_DISTANCE_CALIBRATION` is
 *    `APPROXIMATE` or `CALIBRATED`: emit
 *    `AF_MODE_OFF + LENS_FOCUS_DISTANCE = (post-settle CaptureResult
 *    diopter value) + AE_LOCK + AWB_LOCK`. Pinning the focus distance
 *    explicitly defeats the FULL-HAL's "drive lens to hyperfocal when
 *    AF is OFF" default. The Pixel 6 / Pixel 8 path.
 *  - **Everything else** (LIMITED, LEGACY, EXTERNAL, null, or any HAL
 *    that reports `UNCALIBRATED`): emit `AF_MODE_OFF + AE_LOCK +
 *    AWB_LOCK` exactly as CL-079 does today. The XCover 5 + A21s path.
 *
 * Pure decision-side ([decideStrategy]) is unit-tested against the
 * CameraCharacteristics constants. The Android-edge query
 * ([queryBackCameraLensCalibration]) reads
 * `LENS_INFO_FOCUS_DISTANCE_CALIBRATION` for the first back-facing
 * camera, mirroring the layout of [Camera2HardwareLevel].
 *
 * Ported verbatim from
 * `evaluate-xfeat-lighterglue/android/app/src/main/kotlin/ai/twinskin/xfeat/demoapp/LensFocusLockPolicy.kt`
 * with package + logging-tag adjustments. The current SDK
 * implementation defers the
 * [Strategy.AF_MODE_OFF_PIN_DISTANCE] branch (the analyser-side
 * Camera2Interop session capture callback that publishes the converged
 * diopter is not yet wired in rimbaud); the policy still resolves
 * `PIN_DISTANCE` so the on-device lock site can see the intended
 * strategy and fall back transparently — see the architect plan
 * `evaluate-xfeat-lighterglue/docs/tracking/cl103-sdk-android-perf-plan-2026-05-10.md`
 * § 2 question 3.
 */
internal object LensFocusLockPolicy {
    private const val TAG = "sdk-cl103-lock-policy"

    /**
     * Lock-strategy choice. Encoded as a sealed enum so the call-site
     * in [CameraSessionController.lockLensAndExposureForPhotosphere]
     * can exhaustively branch and the tests can pin the wiring.
     */
    internal enum class Strategy {
        /**
         * Legacy CL-079 path: write `AF_MODE_OFF + AE_LOCK + AWB_LOCK`
         * and trust the HAL to hold the lens at the position the prior
         * `FocusMeteringAction` converged to. Verified working on
         * XCover 5 and A21s.
         */
        AF_MODE_OFF_ONLY,

        /**
         * = converged + AE_LOCK + AWB_LOCK`. Caller is responsible for
         * sourcing the converged diopter value from a post-settle
         * `CaptureResult.LENS_FOCUS_DISTANCE` snapshot. Used on FULL /
         * LEVEL_3 HALs whose `LENS_INFO_FOCUS_DISTANCE_CALIBRATION` is
         * not `UNCALIBRATED`.
         */
        AF_MODE_OFF_PIN_DISTANCE,
    }

    /**
     * Pure policy: returns the strategy to use given the queried HAL
     * level and the queried `LENS_INFO_FOCUS_DISTANCE_CALIBRATION`.
     * Both inputs are nullable to mirror the `CameraCharacteristics.get`
     * surface — a null on either falls through to the conservative
     * legacy strategy.
     */
    fun decideStrategy(
        hardwareLevel: Int?,
        focusDistanceCalibration: Int?,
    ): Strategy {
        if (focusDistanceCalibration == null) return Strategy.AF_MODE_OFF_ONLY
        if (focusDistanceCalibration ==
            CameraCharacteristics.LENS_INFO_FOCUS_DISTANCE_CALIBRATION_UNCALIBRATED
        ) {
            return Strategy.AF_MODE_OFF_ONLY
        }
        return when (hardwareLevel) {
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL,
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3,
            -> Strategy.AF_MODE_OFF_PIN_DISTANCE
            else -> Strategy.AF_MODE_OFF_ONLY
        }
    }

    /**
     * Android-edge query: reads
     * `LENS_INFO_FOCUS_DISTANCE_CALIBRATION` for the first back-facing
     * camera the system reports. Returns `null` when the system has no
     * `CameraManager`, no back camera, the lookup throws, or the HAL
     * does not report the key (some LIMITED HALs leave it unset).
     */
    fun queryBackCameraLensCalibration(context: Context): Int? =
        runCatching {
            val manager =
                context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                    ?: return@runCatching null
            val cameraId = firstBackCameraId(manager) ?: return@runCatching null
            val chars = manager.getCameraCharacteristics(cameraId)
            chars.get(CameraCharacteristics.LENS_INFO_FOCUS_DISTANCE_CALIBRATION)
        }.onFailure { Log.w(TAG, "lens calibration query failed", it) }
            .getOrNull()

    /**
     * Human-readable label for [Log] sites. Mirrors the
     * [Camera2HardwareLevel.describe] helper so logcat sweeps for
     * "CALIBRATED" / "APPROXIMATE" / "UNCALIBRATED" land here.
     */
    fun describeCalibration(level: Int?): String =
        when (level) {
            CameraCharacteristics.LENS_INFO_FOCUS_DISTANCE_CALIBRATION_UNCALIBRATED -> "UNCALIBRATED"
            CameraCharacteristics.LENS_INFO_FOCUS_DISTANCE_CALIBRATION_APPROXIMATE -> "APPROXIMATE"
            CameraCharacteristics.LENS_INFO_FOCUS_DISTANCE_CALIBRATION_CALIBRATED -> "CALIBRATED"
            null -> "UNKNOWN"
            else -> "UNKNOWN($level)"
        }

    private fun firstBackCameraId(manager: CameraManager): String? {
        for (id in manager.cameraIdList) {
            val c = manager.getCameraCharacteristics(id)
            if (c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK) {
                return id
            }
        }
        return manager.cameraIdList.firstOrNull()
    }
}
