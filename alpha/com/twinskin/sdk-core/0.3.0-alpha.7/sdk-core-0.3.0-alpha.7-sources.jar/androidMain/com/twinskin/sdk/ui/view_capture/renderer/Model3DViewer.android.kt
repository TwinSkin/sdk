@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.renderer

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import com.google.android.filament.Camera
import com.google.android.filament.gltfio.FilamentInstance
import com.twinskin.sdk.view.Asset3D
import com.twinskin.sdk.view.Vector3
import io.github.sceneview.SceneView
import io.github.sceneview.SurfaceType
import io.github.sceneview.math.Position
import io.github.sceneview.rememberCameraManipulator
import io.github.sceneview.rememberCameraNode
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberEnvironmentLoader
import io.github.sceneview.rememberMainLightNode
import io.github.sceneview.rememberModelLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

private const val NEAR_PLANE = 0.001f
private const val FAR_PLANE = 100f

/**
 * Android renderer: SceneView (Filament + gltfio) loaded from a local
 * `.glb` file path.
 *
 * All [com.twinskin.sdk.view.CaptureResolver]s land a local path in
 * [Asset3D.location] by the time this composable runs (HTTP/Zip resolvers
 * download first, Local passes through), so the renderer only needs to
 * handle a file on disk.
 *
 * ### Why we don't use `rememberModelInstance`
 *
 * SceneView's [io.github.sceneview.rememberModelInstance] takes a
 * `String` location and parses it as a URI. For our absolute file
 * paths it falls into a code path that wraps the actual load in
 * `runCatching { … }.getOrNull()` and silently returns `null` on any
 * failure — concretely, the load returned null even with a `file://`
 * prefix, with no error surfaced. We instead drive the load by hand:
 * read bytes off the main thread, then call
 * `modelLoader.createModelInstance(buffer)` on the engine thread. The
 * library's `createModel(buffer, ...)` underneath adds the model to
 * `modelLoader.models`, so when this composable disposes and
 * `modelLoader.destroy()` cascades, the asset and instance are
 * cleaned up.
 *
 * ### Why `SurfaceType.TextureSurface`
 *
 * The default [SurfaceType.Surface] is a SurfaceView. After a Compose
 * mount/unmount/remount cycle inside the same Activity (e.g., user
 * opens the viewer, closes it, opens it again), the SurfaceView's
 * surface stops invalidating until something forces a redraw — a
 * touch event, a layout change. The model is rendered and interactive
 * the whole time; just not pushed to the screen. TextureView
 * (`TextureSurface`) refreshes inline on every frame and doesn't have
 * that quirk. We pay slightly worse GPU performance and lose the
 * ability to render Compose UI behind the scene, both irrelevant for
 * this viewer.
 */
@Composable
public actual fun Model3DViewer(
    asset: Asset3D,
    modifier: Modifier,
) {
    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine)
    val environmentLoader = rememberEnvironmentLoader(engine)

    var modelInstance by remember(asset.location) { mutableStateOf<FilamentInstance?>(null) }
    LaunchedEffect(asset.location, modelLoader) {
        val bytes = withContext(Dispatchers.IO) { File(asset.location).readBytes() }
        modelInstance = modelLoader.createModelInstance(ByteBuffer.wrap(bytes))
    }

    val viewMetadata = asset.viewMetadata

    var viewportSize by remember { mutableStateOf(IntSize.Zero) }

    // With marker metadata the mesh is kept METRIC (scaleToUnits = null), exactly
    // as iOS keeps it un-normalised, and SceneView's autoCenter is disabled below
    // (it would re-centre the bbox on the origin and discard the metric frame). To
    // look straight down -Z while keeping the marker off-axis (matching the 2D
    // ContentScale.Fit view), translate the mesh so the reference camera's
    // optical-axis point (0,0,markerCenter.z) lands on the origin, and place the
    // camera on +Z at the same depth. The marker then sits off-centre at the focal
    // plane just like the 2D view. Without metadata we fall back to landing the
    // unit-scaled bbox centre on origin (legacy framing).
    val pivotPosition = remember(modelInstance, viewMetadata) {
        if (viewMetadata != null) {
            val t = Camera3DFraming.pivotTranslation(viewMetadata, Vector3(0f, 0f, 0f), 1f)
            Position(t.x, t.y, t.z)
        } else {
            modelInstance?.let { instance ->
                val box = instance.asset.boundingBox
                val center = box.center
                val halfExtent = box.halfExtent
                val maxExtent = maxOf(halfExtent[0], halfExtent[1], halfExtent[2]) * 2f
                val unitScale = if (maxExtent > 0f) 1f / maxExtent else 1f
                val t = Camera3DFraming.pivotTranslation(
                    null,
                    Vector3(center[0], center[1], center[2]),
                    unitScale,
                )
                Position(t.x, t.y, t.z)
            } ?: Position(0f)
        }
    }

    val cameraPosition = remember(viewMetadata) {
        val pos = Camera3DFraming.cameraPosition(viewMetadata, fallbackDistance = 4f)
        Position(pos.x, pos.y, pos.z)
    }

    val cameraNode = rememberCameraNode(engine) { position = cameraPosition }

    // SceneView's orbit manipulator drives the camera from its OWN orbitHome /
    // target, ignoring cameraNode.position — its defaults (home (0,0,1), target
    // (0,0,-4)) would re-frame the scene. Pin the home to the reference-camera
    // position and the target to the world origin so the initial view looks
    // straight down -Z (the baked reference pose) with the marker off-axis. The
    // target must stay the optical-axis origin, NOT the marker: SceneView's
    // manipulator aims the camera AT its target on the initial frame, so targeting
    // the off-axis marker would re-centre it and break the contain framing. (iOS
    // can target the true marker because SceneKit doesn't force look-at on the
    // initial frame.) Free orbit then pivots around the origin (the optical-axis
    // point at the marker depth). No-metadata path leaves the target null,
    // mirroring SceneView's own default manipulator.
    val cameraManipulator = rememberCameraManipulator(
        orbitHomePosition = cameraPosition,
        targetPosition = if (viewMetadata != null) Position(0f) else null,
    )

    // SceneView's CameraNode re-derives its projection from `focalLength`
    // (Filament setLensProjection against a 24 mm sensor HEIGHT) on every viewport
    // update — and again per frame from the resize callback — which clobbers any
    // one-shot setProjection. So set the contain FoV projection directly (bypassing
    // focalLength, like iOS's SCNCamera.fieldOfView/projectionDirection) and
    // re-assert it every frame in onFrame, after SceneView's own update has run.
    fun applyContainProjection() {
        val meta = viewMetadata ?: return
        val viewport = cameraNode.viewport
        val aspect = when {
            viewport != null && viewport.height > 0 ->
                viewport.width.toFloat() / viewport.height.toFloat()
            viewportSize.height > 0 ->
                viewportSize.width.toFloat() / viewportSize.height.toFloat()
            else -> 1f
        }
        val constraint = Camera3DFraming.fovConstraint(
            fovYDeg = meta.fovYDeg,
            fovXDeg = meta.fovXDeg,
            viewportAspect = aspect,
        )
        val direction = when (constraint.axis) {
            FovAxis.HORIZONTAL -> Camera.Fov.HORIZONTAL
            FovAxis.VERTICAL -> Camera.Fov.VERTICAL
        }
        cameraNode.setProjection(
            constraint.fovDeg.toDouble(),
            NEAR_PLANE,
            FAR_PLANE,
            direction,
            aspect.toDouble(),
        )
    }

    SceneView(
        modifier = modifier.onSizeChanged { viewportSize = it },
        surfaceType = SurfaceType.TextureSurface,
        engine = engine,
        modelLoader = modelLoader,
        environmentLoader = environmentLoader,
        autoCenterContent = viewMetadata == null,
        autoFitContent = false,
        cameraNode = cameraNode,
        cameraManipulator = cameraManipulator,
        mainLightNode = rememberMainLightNode(engine),
        onFrame = { applyContainProjection() },
    ) {
        modelInstance?.let { instance ->
            ModelNode(
                modelInstance = instance,
                scaleToUnits = if (viewMetadata != null) null else 1f,
                position = pivotPosition,
            )
        }
    }
}
