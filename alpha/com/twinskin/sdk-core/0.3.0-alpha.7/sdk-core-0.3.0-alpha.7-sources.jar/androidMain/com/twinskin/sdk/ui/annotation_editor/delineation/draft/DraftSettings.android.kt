package com.twinskin.sdk.ui.annotation_editor.delineation.draft

import android.content.Context
import com.russhwolf.settings.Settings
import com.russhwolf.settings.SharedPreferencesSettings
import com.twinskin.sdk.db.DatabaseDriverFactory

internal actual fun provideDraftSettings(): Settings {
    val context = DatabaseDriverFactory.appContextOrNull()
        ?: error(
            "TwinSkin.initialize must be called before opening the delineation " +
                "draft store (Android Context not yet wired).",
        )
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    return SharedPreferencesSettings(prefs)
}

private const val PREFS_NAME = "twinskin_delineation_drafts"
