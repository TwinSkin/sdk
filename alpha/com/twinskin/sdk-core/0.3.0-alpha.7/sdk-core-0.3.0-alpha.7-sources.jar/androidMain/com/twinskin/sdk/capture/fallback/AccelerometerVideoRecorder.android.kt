package com.twinskin.sdk.capture.fallback

import android.annotation.SuppressLint
import android.content.Context
import android.view.Surface
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.CameraState
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import com.google.common.util.concurrent.ListenableFuture
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine

public class CameraXAccelerometerVideoRecorder(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val cameraSelector: CameraSelector = CameraSelector.DEFAULT_BACK_CAMERA,
    private val previewSurfaceProvider: Preview.SurfaceProvider? = null,
) : VideoRecorder {

    private val stateMachine = AccelerometerVideoRecorderStateMachine(
        partialFileCleanup = { path -> File(path).delete() },
    )

    private val activeRecording = AtomicReference<Recording?>(null)
    private val activeFile = AtomicReference<File?>(null)
    private val stopLatch = AtomicReference<CountDownLatch?>(null)
    private val finalizeError = AtomicReference<Throwable?>(null)
    private val cameraXRecorder = AtomicReference<Recorder?>(null)
    private val videoCaptureUseCase = AtomicReference<VideoCapture<Recorder>?>(null)
    private val cameraXProvider = AtomicReference<ProcessCameraProvider?>(null)
    private val imageCaptureUseCase = AtomicReference<ImageCapture?>(null)
    private val boundCamera = AtomicReference<Camera?>(null)
    public val camera: Camera? get() = boundCamera.get()

    private val recorderExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "twinskin-fallback-video-recorder").apply { isDaemon = true }
    }

    private val _cameraReady = MutableStateFlow(false)
    override val cameraReady: StateFlow<Boolean> = _cameraReady.asStateFlow()
    private val cameraStateObserver = AtomicReference<Observer<CameraState>?>(null)
    private val cameraStateLiveData = AtomicReference<LiveData<CameraState>?>(null)

    @SuppressLint("MissingPermission")
    override fun prepare() {
        // Idempotent — re-binding the lifecycle would tear the
        // already-running preview down and back up.
        if (cameraXProvider.get() != null) return

        val recorder = Recorder.Builder()
            .setQualitySelector(QualitySelector.from(Quality.HIGHEST))
            .setExecutor(recorderExecutor)
            .build()

        val videoCapture = VideoCapture.Builder(recorder)
            .setTargetRotation(Surface.ROTATION_0)
            .build()

        // ImageCapture for the Phase-1 still photo. Pinned to
        // MINIMIZE_LATENCY: the JPEG fires while the operator is still
        // holding the shutter; a long ZSL roundtrip would visibly stall
        // the UI before recording starts.
        val imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setTargetRotation(Surface.ROTATION_0)
            .build()

        val providerFuture: ListenableFuture<ProcessCameraProvider> =
            ProcessCameraProvider.getInstance(context)
        val provider = try {
            providerFuture.get(10, TimeUnit.SECONDS)
        } catch (t: Throwable) {
            throw IllegalStateException("CameraX provider unavailable", t)
        }

        provider.unbindAll()
        // Bind Preview alongside VideoCapture + ImageCapture when the
        // host provided a surface. CameraX needs at least one viewable
        // use case to actually allocate the camera and stream frames on
        // some devices; without a Preview the VideoCapture may sit in a
        // "starting" state forever, never firing Start/Finalize events
        // → recorder.stop() times out (#538).
        val preview = previewSurfaceProvider?.let { surfaceProvider ->
            Preview.Builder()
                .setTargetRotation(Surface.ROTATION_0)
                .build()
                .also { it.setSurfaceProvider(surfaceProvider) }
        }
        val bound = if (preview != null) {
            provider.bindToLifecycle(
                lifecycleOwner, cameraSelector, preview, videoCapture, imageCapture,
            )
        } else {
            provider.bindToLifecycle(
                lifecycleOwner, cameraSelector, videoCapture, imageCapture,
            )
        }

        cameraXRecorder.set(recorder)
        videoCaptureUseCase.set(videoCapture)
        imageCaptureUseCase.set(imageCapture)
        cameraXProvider.set(provider)
        boundCamera.set(bound)

        // Cold-camera race (#541-4 / #541-5): `bindToLifecycle` returns
        // synchronously but the HAL open + `VideoCapture` stream-state
        // transition take ~600 ms on a Pixel 6, longer on low-end
        // devices (Samsung A21S). Flip `cameraReady` to true only once
        // CameraState reaches OPEN; the controller suspends on this
        // flow before flipping the screen to ReadyForPhoto. Observer
        // registration is posted to the main thread (LiveData requires
        // it); prepare() itself returns immediately so the host's
        // Compose recomposition can wire the PreviewView surface.
        observeCameraOpen(bound)
    }

    private fun observeCameraOpen(camera: Camera) {
        val main = ContextCompat.getMainExecutor(context)
        val liveData = camera.cameraInfo.cameraState
        val observer = object : Observer<CameraState> {
            override fun onChanged(value: CameraState) {
                if (value.type == CameraState.Type.OPEN) {
                    _cameraReady.value = true
                    liveData.removeObserver(this)
                    cameraStateObserver.compareAndSet(this, null)
                    cameraStateLiveData.compareAndSet(liveData, null)
                }
            }
        }
        cameraStateObserver.set(observer)
        cameraStateLiveData.set(liveData)
        main.execute { liveData.observe(lifecycleOwner, observer) }
    }

    public suspend fun takeStillPhoto(outputPath: String): String =
        suspendCancellableCoroutine { cont ->
            val imageCapture = imageCaptureUseCase.get()
                ?: return@suspendCancellableCoroutine cont.resumeWithException(
                    IllegalStateException(
                        "AccelerometerVideoRecorder.takeStillPhoto(): prepare() not called"
                    )
                )
            val target = File(outputPath)
            if (target.exists() && !target.delete()) {
                return@suspendCancellableCoroutine cont.resumeWithException(
                    IllegalStateException("Cannot remove pre-existing photo at $outputPath")
                )
            }
            val options = ImageCapture.OutputFileOptions.Builder(target).build()
            imageCapture.takePicture(
                options,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(out: ImageCapture.OutputFileResults) {
                        cont.resume(outputPath)
                    }
                    override fun onError(exc: ImageCaptureException) {
                        cont.resumeWithException(exc)
                    }
                },
            )
        }

    @SuppressLint("MissingPermission")
    override fun start(outputPath: String) {
        stateMachine.requestStart()

        // Lazy-prepare in case the host didn't call `prepare()` first
        // (e.g., an integrator-built UI that bypasses
        // AccelerometerCaptureController.markCameraReady).
        if (cameraXProvider.get() == null) {
            try {
                prepare()
            } catch (t: Throwable) {
                stateMachine.markErrored()
                throw t
            }
        }

        val recorder = cameraXRecorder.get()
            ?: error("CameraX recorder missing after prepare()")

        val targetFile = File(outputPath).also { activeFile.set(it) }
        stateMachine.trackPartialFile(outputPath)
        // Defensive: if a stale file from a crashed prior session
        // lives at the same path, CameraX will append rather than
        // overwrite cleanly. Remove first.
        if (targetFile.exists() && !targetFile.delete()) {
            stateMachine.markErrored()
            throw IllegalStateException("Cannot remove pre-existing video file at $outputPath")
        }

        val outputOptions = FileOutputOptions.Builder(targetFile).build()
        // Audio muted by absence: not calling withAudioEnabled() is what
        // wires the no-microphone contract the AC #5 test pins.
        val pendingRecording = recorder.prepareRecording(context, outputOptions)

        val latch = CountDownLatch(1).also { stopLatch.set(it) }
        val recording = pendingRecording.start(
            ContextCompat.getMainExecutor(context),
        ) { event ->
            when (event) {
                is VideoRecordEvent.Finalize -> {
                    if (event.hasError()) {
                        finalizeError.set(event.cause ?: IllegalStateException(
                            "VideoRecordEvent.Finalize error ${event.error}"))
                        stateMachine.markErrored()
                    } else {
                        // CameraX can finalise without an error while
                        // the output MP4 is missing or 0-byte — cold-
                        // camera race (#541-4) where frames never
                        // reached the encoder before stop. Surface a
                        // clear error instead of letting submit()
                        // bottom out on "file not found".
                        val out = activeFile.get()
                        if (out == null || !out.exists() || out.length() == 0L) {
                            finalizeError.set(IllegalStateException(
                                "Video output file missing or empty after Finalize " +
                                "(cold-camera race?): exists=${out?.exists()} " +
                                "size=${out?.length()} path=${out?.absolutePath}"
                            ))
                            stateMachine.markErrored()
                        } else {
                            stateMachine.markStopped()
                        }
                    }
                    latch.countDown()
                }
                // Start / Status events fire but the controller only
                // needs to know about the finalisation outcome.
                else -> Unit
            }
        }
        activeRecording.set(recording)
    }

    override fun stop(): String {
        val action = stateMachine.requestStop()
        check(action == AccelerometerVideoRecorderAction.NativeStop)

        // Snapshot the path BEFORE the latch wait. A concurrent cancel()
        // (e.g. the host screen's DisposableEffect.onDispose firing
        // during the up-to-15s finalisation window) nulls activeFile,
        // so reading it at the end of stop() races (#541).
        val outputPath = activeFile.get()?.absolutePath
            ?: error("AccelerometerVideoRecorder.stop(): output path lost")

        val recording = activeRecording.getAndSet(null)
            ?: error("AccelerometerVideoRecorder.stop(): no active recording")
        recording.stop()

        // Unbind every CameraX use case off the provider immediately after
        // calling stop(). With Preview bound, the camera source keeps
        // producing frames → VideoCapture's encoder never receives a frame
        // past stopTimeUs → CameraX hits its internal STOP_TIMEOUT_MS (30s)
        // before forcing signalCodecStop. Releasing the use cases on the
        // main thread flips the source to non-streaming, the encoder drains
        // its queue, and Finalize fires within ~200 ms (Pixel 6 verified).
        // We unbind on the main executor because ProcessCameraProvider's
        // API is documented as main-thread-only.
        val mainExecutor = ContextCompat.getMainExecutor(context)
        mainExecutor.execute {
            try { cameraXProvider.get()?.unbindAll() } catch (_: Throwable) {}
        }

        val latch = stopLatch.getAndSet(null)
            ?: error("AccelerometerVideoRecorder.stop(): no stop latch")
        val finalized = latch.await(30, TimeUnit.SECONDS)
        if (!finalized) {
            stateMachine.markErrored()
            throw IllegalStateException("VideoRecorder.stop() timed out waiting for finalisation")
        }
        finalizeError.get()?.let { err ->
            throw IllegalStateException("VideoRecorder finalisation failed", err)
        }
        return outputPath
    }

    override fun cancel() {
        // Detach the camera-state observer first so a cancel during
        // a cold open does not leave the LiveData callback firing
        // against a torn-down recorder. Idempotent — repeat cancels
        // see a null observer and skip.
        val observer = cameraStateObserver.getAndSet(null)
        val liveData = cameraStateLiveData.getAndSet(null)
        if (observer != null && liveData != null) {
            ContextCompat.getMainExecutor(context).execute {
                try { liveData.removeObserver(observer) } catch (_: Throwable) {}
            }
        }
        when (stateMachine.requestCancel()) {
            AccelerometerVideoRecorderAction.None -> Unit
            AccelerometerVideoRecorderAction.NativeAbort -> {
                // recording.stop() finalises with success on CameraX
                // 1.6 — there is no separate "abort" call. The
                // partial-file delete is routed via the state machine's
                // `partialFileCleanup` seam so the disk-touch is
                // testable on `:shared:jvmTest`.
                try { activeRecording.getAndSet(null)?.stop() } catch (_: Throwable) {}
                // Drain the latch off the caller's thread: cancel() is
                // invoked from DisposableEffect.onDispose on Main, and
                // blocking up to 2s there hits the ANR window (#3665).
                val pendingLatch = stopLatch.getAndSet(null)
                if (pendingLatch != null) {
                    recorderExecutor.execute {
                        try { pendingLatch.await(2, TimeUnit.SECONDS) } catch (_: Throwable) {}
                    }
                }
                activeFile.set(null)
            }
            // Unreachable per the state machine's outputs from cancel.
            else -> Unit
        }
    }
}

public actual fun createVideoRecorder(): VideoRecorder = NotImplementedVideoRecorder()

private class NotImplementedVideoRecorder : VideoRecorder {
    override fun start(outputPath: String): Unit =
        throw NotImplementedError(VIDEO_RECORDER_NOT_IMPLEMENTED_MESSAGE)
    override fun stop(): String =
        throw NotImplementedError(VIDEO_RECORDER_NOT_IMPLEMENTED_MESSAGE)
    override fun cancel() {
    }
}

public fun createAccelerometerVideoRecorder(
    context: Context,
    lifecycleOwner: LifecycleOwner,
    previewSurfaceProvider: Preview.SurfaceProvider? = null,
): CameraXAccelerometerVideoRecorder = CameraXAccelerometerVideoRecorder(
    context, lifecycleOwner, previewSurfaceProvider = previewSurfaceProvider,
)
