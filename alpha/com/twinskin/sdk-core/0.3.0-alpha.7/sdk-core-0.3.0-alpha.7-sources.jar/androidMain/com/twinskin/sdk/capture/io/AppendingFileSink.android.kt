package com.twinskin.sdk.capture.io

import java.io.File
import java.io.FileOutputStream

internal actual open class AppendingFileSink actual constructor(path: String) {
    private val out: FileOutputStream
    private var closed = false

    init {
        val file = File(path)
        file.parentFile?.mkdirs()
        out = FileOutputStream(file, false)
    }

    actual open fun write(src: ByteArray, off: Int, len: Int) {
        if (len == 0) return
        out.write(src, off, len)
    }

    actual open fun close() {
        if (closed) return
        closed = true
        out.close()
    }
}
