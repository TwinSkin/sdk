@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.transfer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.twinskin.sdk.SdkLogLevel
import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.db.DatabaseDriverFactory
import com.twinskin.sdk.db.TwinSkinDatabaseHolder
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.onUpload
import io.ktor.client.request.put
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.content.OutgoingContent
import io.ktor.http.contentType
import io.ktor.utils.io.*
import java.io.File
import java.io.IOException

/**
 * WorkManager [CoroutineWorker] that uploads the file recorded on the matching
 * `TransferTask` row to its presigned PUT URL.
 *
 * ## Init-optional
 *
 * Most attempts only need the database, the cached presigned URL on the row, and
 * the network — none of which require [TwinSkinSdk.initialize] to have been called
 * in the current process. The worker opens the database via
 * [TwinSkinDatabaseHolder.acquire] (process-singleton, init-free) and delegates
 * the decision logic to [UploadAttemptRunner]. The runner only reaches for the
 * SDK component (and therefore [TwinSkinSdk.requireComponent]) when the cached
 * URL is missing/expired AND a refresh is possible. When the SDK isn't
 * initialized, that branch returns [WorkerOutcome.Retry] so WorkManager preserves
 * the row and re-runs the worker later (typically the next time the host app
 * brings the SDK up).
 *
 * ## Why the worker writes directly to the database
 *
 * WorkManager can run this worker in the background **after the app process has been killed**
 * (the system restarts a lightweight process just for the worker via `JobScheduler`). In that
 * scenario, [AndroidFileTransferProvider]'s observe-flow — which normally maps WorkInfo state
 * changes to DB updates — is not running. Without direct DB writes from the worker, the task
 * would stay `ACTIVE` in the database indefinitely, and [TransferManager.recover] would
 * re-enqueue it on the next app launch, restarting the upload from byte 0.
 *
 * By writing `COMPLETED` / `FAILED` directly (via [CachedUrlUploader] /
 * [UploadAttemptRunner]) the DB always reflects the real terminal state regardless of
 * whether the app was open. [recover] then finds no `ACTIVE` tasks for already-finished
 * uploads and does not restart them.
 *
 * Return values:
 * - [Result.success] — upload completed, or server says the file already exists.
 * - [Result.retry]   — transient failure (network, expired URL with no refresh available,
 *                      resolver returning RetryableError, HTTP 5xx/transport error).
 * - [Result.failure] — permanent failure (source file missing, non-403 4xx).
 *
 * Promoted to a foreground service via [setForeground] so large uploads survive backgrounding.
 */
internal class UploadWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

    // Single HttpClient instance reused across retries within this worker lifecycle.
    // Closed in the finally block of doWork.
    private val client = HttpClient(OkHttp) {
        install(HttpTimeout) {
            requestTimeoutMillis = null   // no overall timeout — file size is unbounded
            socketTimeoutMillis  = 60_000L
        }
    }

    override suspend fun doWork(): Result {
        val id        = inputData.getString(WorkerKeys.KEY_ID)         ?: return Result.failure()
        val uploadKey = inputData.getString(WorkerKeys.KEY_UPLOAD_KEY) ?: return Result.failure()

        setForeground(buildForegroundInfo("Uploading…", id))

        val database = TwinSkinDatabaseHolder.acquire(DatabaseDriverFactory("twinskin_transfers.db"))
        val component = if (TwinSkinSdk.isInitialized) TwinSkinSdk.requireComponent() else null
        // When the SDK isn't initialized in this process, the configured logger
        // is unavailable — fall back to logcat instead of swallowing every event.
        // Without this, the init-optional path is invisible to field triage.
        val logger = component?.logger ?: LogcatSdkLogger
        Log.i("TwinSkin", "UploadWorker[$id] start (sdkInitialized=${component != null})")

        val cached = CachedUrlUploader(
            database = database,
            httpPut = ::ktorPut,
            clock = { System.currentTimeMillis() },
            logger = logger,
        )
        val refresh: (suspend (String, String) -> UrlResult)? = component?.let { c ->
            { _, key -> c.urlResolver(key) }
        }

        val runner = UploadAttemptRunner(
            database = database,
            cachedUploader = cached,
            refresh = refresh,
            clock = { System.currentTimeMillis() },
            logger = logger,
        )

        return try {
            val outcome = runner.run(id, uploadKey) { sent, total ->
                if (total > 0) {
                    setProgress(
                        workDataOf(WorkerKeys.KEY_PROGRESS to minOf(99, ((sent * 100L) / total).toInt()))
                    )
                }
            }
            Log.i("TwinSkin", "UploadWorker[$id] outcome=$outcome")
            when (outcome) {
                WorkerOutcome.Success -> Result.success()
                is WorkerOutcome.Failure -> Result.failure(workDataOf(WorkerKeys.KEY_ERROR to outcome.reason))
                WorkerOutcome.Retry -> Result.retry()
            }
        } finally {
            client.close()
        }
    }

    private object LogcatSdkLogger : SdkLogger {
        override fun log(level: SdkLogLevel, message: String, cause: Throwable?) {
            when (level) {
                SdkLogLevel.Debug ->
                    if (cause != null) Log.d("TwinSkin", message, cause) else Log.d("TwinSkin", message)
                SdkLogLevel.Info ->
                    if (cause != null) Log.i("TwinSkin", message, cause) else Log.i("TwinSkin", message)
                SdkLogLevel.Warning ->
                    if (cause != null) Log.w("TwinSkin", message, cause) else Log.w("TwinSkin", message)
                SdkLogLevel.Error ->
                    if (cause != null) Log.e("TwinSkin", message, cause) else Log.e("TwinSkin", message)
            }
        }
    }

    // -----------------------------------------------------------------------
    // HTTP PUT — maps response to [HttpPutResult] for [CachedUrlUploader]
    // -----------------------------------------------------------------------

    private suspend fun ktorPut(
        url: String,
        localPath: String,
        onProgress: suspend (Long, Long) -> Unit,
    ): HttpPutResult {
        val file = File(localPath)
        return try {
            val fileSize = file.length()
            val response = client.put(url) {
                contentType(ContentType.Application.OctetStream)
                onUpload { sent, total -> if ((total ?: 0L) > 0L) onProgress(sent, total!!) }
                setBody(object : OutgoingContent.WriteChannelContent() {
                    override val contentLength: Long = fileSize
                    override val contentType: ContentType = ContentType.Application.OctetStream
                    override suspend fun writeTo(channel: ByteWriteChannel) {
                        file.inputStream().use { input ->
                            val buf = ByteArray(DEFAULT_BUFFER_SIZE)
                            var n = input.read(buf)
                            while (n != -1) {
                                channel.writeByteArray(buf.copyOfRange(0, n))
                                n = input.read(buf)
                            }
                        }
                    }
                })
            }
            when {
                response.status.value in 200..299 -> HttpPutResult.Success
                response.status.value == 403 -> HttpPutResult.UrlExpired
                response.status.value in 400..499 -> HttpPutResult.ClientError(response.status.value)
                else -> HttpPutResult.TransientError
            }
        } catch (_: IOException) {
            HttpPutResult.TransientError
        }
    }

    // -----------------------------------------------------------------------
    // Foreground service notification
    // -----------------------------------------------------------------------

    private fun buildForegroundInfo(contentText: String, taskId: String): ForegroundInfo {
        ensureNotificationChannel()

        val notificationId = WorkerKeys.notificationIdForTask(taskId, TransferType.UPLOAD)

        val notification = NotificationCompat.Builder(applicationContext, WorkerKeys.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("TwinSkin")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .setSilent(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(
                notificationId,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
        } else {
            ForegroundInfo(notificationId, notification)
        }
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                WorkerKeys.NOTIFICATION_CHANNEL_ID,
                WorkerKeys.NOTIFICATION_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW,
            )
            applicationContext
                .getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }
}
