package com.twinskin.sdk.capture.fallback

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.twinskin.sdk.db.DatabaseDriverFactory
import com.twinskin.sdk.ui.fallback.GuidanceSnapshot
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** [stop] MUST be called by the lifecycle owner — SensorManager leaks listeners on config changes. */
internal class AndroidAccelerometerDriver(
    private val sensorManager: SensorManager,
    override val angleThreshold: Double,
) : AccelerometerDriver {
    private val accumulator = AccelerometerSampleAccumulator(angleThreshold)

    override val guidance: StateFlow<GuidanceSnapshot> = accumulator.guidance.asStateFlow()

    private val accListener = listenerFor(accumulator::acceptAccelerometer)
    private val userAccListener = listenerFor(accumulator::acceptUserAccelerometer)
    private val gyroListener = listenerFor(accumulator::acceptGyroscope)
    private val magnetoListener = listenerFor(accumulator::acceptMagnetometer)

    private var started: Boolean = false

    override fun start(): StateFlow<Pie> {
        if (started) return accumulator.pie.readOnly()
        started = true
        registerIfAvailable(Sensor.TYPE_ACCELEROMETER, accListener)
        registerIfAvailable(Sensor.TYPE_LINEAR_ACCELERATION, userAccListener)
        registerIfAvailable(Sensor.TYPE_GYROSCOPE, gyroListener)
        registerIfAvailable(Sensor.TYPE_MAGNETIC_FIELD, magnetoListener)
        return accumulator.pie.readOnly()
    }

    override fun stop(): VideoMetaData {
        if (started) {
            sensorManager.unregisterListener(accListener)
            sensorManager.unregisterListener(userAccListener)
            sensorManager.unregisterListener(gyroListener)
            sensorManager.unregisterListener(magnetoListener)
            started = false
        }
        return accumulator.snapshotMetadata()
    }

    private fun registerIfAvailable(sensorType: Int, listener: SensorEventListener) {
        val sensor = sensorManager.getDefaultSensor(sensorType) ?: return
        sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_FASTEST)
    }

    private fun listenerFor(
        onSample: (AccelerometerData) -> Unit,
    ): SensorEventListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            onSample(
                AccelerometerData(
                    // event.timestamp is nanoseconds-since-boot; the
                    // web_app's `event.timestamp.millisecondsSinceEpoch`
                    // is wall-clock epoch-millis. We use wall-clock
                    // here for the SAME reason the web_app does — the
                    // downstream pipeline correlates by wall-clock.
                    timestampMilliseconds = System.currentTimeMillis(),
                    x = event.values[0].toDouble(),
                    y = event.values[1].toDouble(),
                    z = event.values[2].toDouble(),
                ),
            )
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
    }
}

public actual fun createAccelerometerDriver(
    angleThreshold: Double,
): AccelerometerDriver {
    val ctx = DatabaseDriverFactory.appContextOrNull()
        ?: error("createAccelerometerDriver requires TwinSkinSdk.initialize to have run first")
    val sensorManager = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    return AndroidAccelerometerDriver(sensorManager, angleThreshold)
}
