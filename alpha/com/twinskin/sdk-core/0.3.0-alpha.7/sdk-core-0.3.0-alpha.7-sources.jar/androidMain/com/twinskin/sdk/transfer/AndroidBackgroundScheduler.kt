package com.twinskin.sdk.transfer

/**
 * Android implementation of [BackgroundScheduler].
 *
 * No-op: WorkManager already handles offline resilience automatically.
 * Each [UploadWorker] is enqueued with a [NetworkType.CONNECTED] constraint, so it
 * will not run until a network connection is available, and WorkManager will restart
 * it after process death or network restoration without any extra scheduling.
 */
internal class AndroidBackgroundScheduler : BackgroundScheduler {
    override fun scheduleUploadRetry(taskId: String) = Unit
    override fun cancelUploadRetry(taskId: String) = Unit
}
