package com.twinskin.sdk.view

import java.io.File

internal actual fun listGlbFiles(dir: String): List<String> {
    val root = File(dir)
    if (!root.exists()) return emptyList()
    return root.walkTopDown()
        .filter { it.isFile && it.extension.equals("glb", ignoreCase = true) }
        .map { it.absolutePath }
        .toList()
}
