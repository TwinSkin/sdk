package com.twinskin.sdk.ui.annotation_editor.polygon.orientation

import android.app.Activity
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext

@Composable
internal actual fun LockOrientationDuringSession() {
    val context = LocalContext.current
    DisposableEffect(Unit) {
        OrientationLockCounter.enter()
        val activity = context.findActivity()
        val previous = activity?.requestedOrientation
        if (activity != null) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
        } else {
            // WoundAnnotationEditor is normally hosted by a real
            // Activity. If a future integrator hosts it inside a
            // non-Activity Context (e.g. a service or a custom
            // ComposeView outside the Activity hierarchy), we
            // silently skip the lock — the editor still works, the
            // orientation just isn't frozen. Visible in logcat for
            // debugging.
            Log.w(
                "WoundAnnotationEditor",
                "host context is not an Activity; skipping orientation lock",
            )
        }
        onDispose {
            if (activity != null && previous != null) {
                activity.requestedOrientation = previous
            }
            OrientationLockCounter.exit()
        }
    }
}

private tailrec fun android.content.Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
