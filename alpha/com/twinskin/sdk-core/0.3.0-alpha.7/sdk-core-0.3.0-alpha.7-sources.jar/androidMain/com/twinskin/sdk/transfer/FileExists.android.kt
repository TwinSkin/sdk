package com.twinskin.sdk.transfer

internal actual fun fileExists(path: String): Boolean = java.io.File(path).exists()
