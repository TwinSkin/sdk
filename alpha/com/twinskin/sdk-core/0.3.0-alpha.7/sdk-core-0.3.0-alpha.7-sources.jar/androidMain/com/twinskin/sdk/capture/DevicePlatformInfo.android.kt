package com.twinskin.sdk.capture

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.twinskin.sdk.db.DatabaseDriverFactory
import java.util.Locale

/**
 * Android implementation of [systemDevicePlatformInfo].
 *
 * Contracts pinned at the actual:
 * - [DevicePlatformInfo.os] is the lowercase string `"android"` (matches
 *   the iOS actual's `"ios"` — the server treats this field as a closed
 *   set and is case-sensitive).
 * - [DevicePlatformInfo.locale] is a BCP-47 language tag (e.g.
 *   `"en-US"`), produced by [Locale.toLanguageTag]. The iOS actual must
 *   normalize `NSLocale.localeIdentifier` (which uses underscores like
 *   `en_US`) into the same shape.
 *
 * The application [Context] is reached through [DatabaseDriverFactory]'s
 * existing accessor, which is populated as the very first thing in
 * `TwinSkinSdk.initialize`. If this function is somehow called before
 * SDK init, the context-derived fields ([DevicePlatformInfo.appVersion],
 * [DevicePlatformInfo.appBundleId]) fall back to `null` rather than
 * throwing — keeping `systemDevicePlatformInfo` safe to invoke from
 * anywhere.
 */
internal actual fun systemDevicePlatformInfo(): DevicePlatformInfo {
    val context = DatabaseDriverFactory.appContextOrNull()
    return DevicePlatformInfo(
        os = "android",
        osVersion = Build.VERSION.RELEASE,
        deviceManufacturer = Build.MANUFACTURER,
        deviceModel = Build.MODEL,
        appVersion = context?.let { appVersionFromContext(it) },
        appBundleId = context?.packageName,
        locale = Locale.getDefault().toLanguageTag(),
    )
}

private fun appVersionFromContext(context: Context): String? {
    return try {
        @Suppress("DEPRECATION")
        context.packageManager
            .getPackageInfo(context.packageName, 0)
            .versionName
    } catch (_: PackageManager.NameNotFoundException) {
        null
    }
}
