package com.twinskin.sdk.ui.capture

import android.os.SystemClock
import android.util.Log
import com.twinskin.photosphere.MarkerRefine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.nio.ByteBuffer

/**
 * machine ported from `evaluate-xfeat-lighterglue/android/app/src/
 * main/kotlin/ai/twinskin/xfeat/demoapp/MarkerFocusController.kt`.
 * Re-scoped (operator decision 2026-05-07): YOLO is bypassed entirely
 * — `cv::aruco::ArucoDetector` runs directly on the full Y-plane via
 * the [MarkerRefine.aruco] JNI wrapper around `marker_refine_aruco`.
 * The DICT_4X4_50 dictionary is selected by `class_id=0` per
 * `marker_refine_aruco.cpp::dictionary_for_class`.
 *
 * State machine (matches sibling demo + iOS port):
 *
 *     SEARCHING    --(ArUco decode)-->     LOCKED
 *     SEARCHING    --(no decode)-->        SEARCHING
 *     LOCKED       --(marker lost > 3 s)-->REACQUIRING
 *     REACQUIRING  --(ArUco decode)-->     LOCKED
 *     REACQUIRING  --(timeout 10 s)-->     SEARCHING
 *
 * REFINING is retained in the sealed hierarchy for future
 * architectural symmetry with the YOLO→ArUco waterfall (kept under a
 * one-line gate seam in the demo) but is unreachable on the live
 * preview path today — same rationale as the upstream demo file's
 * header doc.
 *
 * Why pixel-space centroid: CameraX's `FocusMeteringAction` accepts a
 * [androidx.camera.core.MeteringPoint] built from a
 * [androidx.camera.core.SurfaceOrientedMeteringPointFactory] in the
 * analyser-frame's pixel coords. The caller (CameraSessionController)
 * builds the metering point directly from the centroid; this
 * controller stays UI-coord-agnostic.
 *
 * Thread-safety: `ingestFrame` is called serially from the CameraX
 * analyser executor (single-threaded). State reads (e.g.
 * `lastObservedMarker`) are safe from any thread because
 * [MutableStateFlow] is thread-safe for value swaps.
 */
internal class MarkerFocusController(
    private val cadence: Int = 1,
    private val lockTimeoutMs: Long = 3_000L,
    private val reacquireTimeoutMs: Long = 10_000L,
    private val nowMs: () -> Long = { SystemClock.elapsedRealtime() },
) {
    sealed class State {
        data object Searching : State()
        data object Refining : State()
        data class Locked(val marker: ObservedMarker) : State()
        data object Reacquiring : State()
    }

    /**
     * Snapshot of a successfully-refined marker.
     *
     * @property centroidX centroid x in analyser-frame pixel coords.
     * @property centroidY centroid y in analyser-frame pixel coords.
     * @property cornersXY tl, tr, br, bl xy interleaved (8 floats).
     * @property markerId ArUco dictionary id.
     * @property frameWidth analyser-frame width at detection time.
     * @property frameHeight analyser-frame height at detection time.
     */
    data class ObservedMarker(
        val centroidX: Float,
        val centroidY: Float,
        val cornersXY: FloatArray,
        val markerId: Int,
        val frameWidth: Int,
        val frameHeight: Int,
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is ObservedMarker) return false
            return centroidX == other.centroidX &&
                centroidY == other.centroidY &&
                cornersXY.contentEquals(other.cornersXY) &&
                markerId == other.markerId &&
                frameWidth == other.frameWidth &&
                frameHeight == other.frameHeight
        }

        override fun hashCode(): Int {
            var h = centroidX.hashCode()
            h = 31 * h + centroidY.hashCode()
            h = 31 * h + cornersXY.contentHashCode()
            h = 31 * h + markerId
            h = 31 * h + frameWidth
            h = 31 * h + frameHeight
            return h
        }
    }

    private val stateFlow: MutableStateFlow<State> = MutableStateFlow(State.Searching)
    val state: StateFlow<State> = stateFlow.asStateFlow()

    private var frameCounter: Int = 0
    private var lastMarkerDetectionTimeMs: Long = 0L
    private var stateEnteredAtMs: Long = nowMs()

    /**
     * Latest observed marker, or `null` when not currently `Locked`.
     * Stable across cadence-skipped frames: the locked-state's
     * associated value is the most recent successful detection.
     */
    val lastObservedMarker: ObservedMarker?
        get() = (stateFlow.value as? State.Locked)?.marker

    /**
     * Called by the camera-frame analyser with a direct grayscale
     * Y-plane buffer. The buffer is read synchronously (the
     * `marker_refine_aruco` JNI call copies the ROI patch internally
     * before returning); callers are free to recycle the buffer
     * after this method returns.
     *
     * @param gray direct [ByteBuffer] holding the 8-bit Y plane.
     * @param width frame pixel width.
     * @param height frame pixel height.
     * @param rowStride bytes per row in [gray]; must be `>= width`.
     */
    fun ingestFrame(
        gray: ByteBuffer,
        width: Int,
        height: Int,
        rowStride: Int,
    ) {
        frameCounter += 1
        if (frameCounter % cadence.coerceAtLeast(1) != 0) return

        val now = nowMs()
        val refined = try {
            MarkerRefine.aruco(
                gray = gray,
                width = width,
                height = height,
                rowStride = rowStride,
                roiX0 = 0,
                roiY0 = 0,
                roiX1 = width,
                roiY1 = height,
            )
        } catch (e: Exception) {
            Log.w(TAG, "MarkerRefine.aruco failed: ${e.message}", e)
            null
        }

        if (refined != null) {
            val obs = ObservedMarker(
                centroidX = centroid(refined.corners, axis = 0),
                centroidY = centroid(refined.corners, axis = 1),
                cornersXY = refined.corners.copyOf(),
                markerId = refined.id,
                frameWidth = width,
                frameHeight = height,
            )
            lastMarkerDetectionTimeMs = now
            transition(State.Locked(obs))
        } else {
            when (val current = stateFlow.value) {
                is State.Locked ->
                    if (now - lastMarkerDetectionTimeMs > lockTimeoutMs) {
                        transition(State.Reacquiring)
                    }
                is State.Reacquiring ->
                    if (now - stateEnteredAtMs >= reacquireTimeoutMs) {
                        transition(State.Searching)
                    }
                State.Searching, State.Refining -> Unit
            }
        }
    }

    /**
     * Reset to SEARCHING. Called by [com.twinskin.sdk.ui.CaptureScreen]
     * on session terminal events (`AllRoundsDone`, `Aborted`, cancel)
     * so a re-entry into capture starts with a clean state.
     */
    fun reset() {
        frameCounter = 0
        lastMarkerDetectionTimeMs = 0L
        transition(State.Searching)
    }

    private fun transition(newState: State) {
        stateEnteredAtMs = nowMs()
        stateFlow.value = newState
    }

    private fun centroid(cornersXY: FloatArray, axis: Int): Float {
        // tl, tr, br, bl interleaved → 4 corners. axis=0 → x, axis=1 → y.
        var sum = 0.0f
        var i = axis
        while (i < cornersXY.size) {
            sum += cornersXY[i]
            i += 2
        }
        return sum / 4.0f
    }

    private companion object {
        const val TAG = "MarkerFocusController"
    }
}
