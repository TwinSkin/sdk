package com.twinskin.sdk.ui.fallback

import android.content.Context
import android.content.SharedPreferences

/**
 * `SharedPreferences`-backed Android actual.
 *
 * Preferences-file name is the SDK-namespaced
 * `com.twinskin.sdk.preferences` so it doesn't collide with the host
 * application's own prefs file. `commit()` (synchronous) over
 * `apply()` so a follow-up read in the same frame sees the write —
 * the SDK never writes more than a handful of keys per session, so
 * the disk-touch cost is negligible.
 */
public class SharedPreferencesSdkUserPreferences(
    context: Context,
) : SdkUserPreferences {

    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME, Context.MODE_PRIVATE,
    )

    override var tutorialDontShowAgain: Boolean
        get() = prefs.getBoolean(KEY_TUTORIAL_DONT_SHOW_AGAIN, false)
        set(value) {
            prefs.edit().putBoolean(KEY_TUTORIAL_DONT_SHOW_AGAIN, value).commit()
        }

    override var coachmarkDismissed: Boolean
        get() = prefs.getBoolean(KEY_COACHMARK_DISMISSED, false)
        set(value) {
            prefs.edit().putBoolean(KEY_COACHMARK_DISMISSED, value).commit()
        }

    public companion object {
        public const val PREFS_NAME: String = "com.twinskin.sdk.preferences"
        public const val KEY_TUTORIAL_DONT_SHOW_AGAIN: String = "tutorialDontShowAgain"
        public const val KEY_COACHMARK_DISMISSED: String = "coachmarkDismissed"
    }
}

public actual fun defaultSdkUserPreferences(): SdkUserPreferences =
    error(
        "defaultSdkUserPreferences() requires a Context on Android. " +
            "Construct SharedPreferencesSdkUserPreferences(context) explicitly " +
            "from your AccelerometerCaptureScreenHost (the host already has access to LocalContext)."
    )

/**
 * Context-aware factory wired by the Android
 * [com.twinskin.sdk.ui.fallback.AccelerometerCaptureScreenHost].
 */
public fun sdkUserPreferences(context: Context): SdkUserPreferences =
    SharedPreferencesSdkUserPreferences(context)
