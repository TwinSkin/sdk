package com.twinskin.sdk.view

import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal actual suspend fun readImageBytes(path: String): ByteArray =
    withContext(Dispatchers.IO) { File(path).readBytes() }
