package com.twinskin.sdk.capture.io

import java.io.File

internal actual fun fileSize(path: String): Long {
    val f = File(path)
    require(f.exists()) { "file not found: $path" }
    return f.length()
}

internal actual fun readFileStreaming(path: String, sink: ByteSink) {
    File(path).inputStream().use { input ->
        val buf = ByteArray(8 * 1024)
        while (true) {
            val n = input.read(buf)
            if (n <= 0) break
            sink.write(buf, 0, n)
        }
    }
}

internal actual fun deleteFileQuietly(path: String) {
    runCatching { File(path).delete() }
}

internal actual fun ensureDir(path: String) {
    File(path).mkdirs()
}

internal actual fun deleteDirQuietly(path: String) {
    runCatching { File(path).deleteRecursively() }
}

internal actual fun writeBytes(path: String, bytes: ByteArray) {
    File(path).writeBytes(bytes)
}

internal actual fun fileExists(path: String): Boolean = File(path).exists()

internal actual fun readBytes(path: String): ByteArray = File(path).readBytes()

internal actual fun listDir(path: String): List<String> {
    val f = File(path)
    require(f.isDirectory) { "not a directory: $path" }
    return f.list()?.toList() ?: emptyList()
}

internal actual fun renameFile(from: String, to: String) {
    java.nio.file.Files.move(
        java.nio.file.Paths.get(from),
        java.nio.file.Paths.get(to),
        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
        java.nio.file.StandardCopyOption.ATOMIC_MOVE,
    )
}
