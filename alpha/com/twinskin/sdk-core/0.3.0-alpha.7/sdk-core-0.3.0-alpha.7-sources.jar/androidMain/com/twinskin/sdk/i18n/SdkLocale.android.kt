package com.twinskin.sdk.i18n

import java.util.Locale

internal actual fun deviceLocale(): String =
    Locale.getDefault().language.takeIf { it.isNotEmpty() } ?: "en"
