package com.twinskin.sdk.ui.photosphere_tutorial

import android.content.Context

/** Android host's persistence for the tutorial overlay. */
internal object PhotosphereTutorialPrefs {
    private const val PREFS_NAME = "com.twinskin.sdk.tutorial.photosphere.v1"
    private const val KEY_SEEN = "seen_at_least_once"
    private const val KEY_DONT_SHOW_AGAIN = "dont_show_again"

    fun seenAtLeastOnce(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SEEN, false)

    fun dontShowAgain(context: Context): Boolean =
        prefs(context).getBoolean(KEY_DONT_SHOW_AGAIN, false)

    fun markSeen(context: Context) {
        prefs(context).edit().putBoolean(KEY_SEEN, true).apply()
    }

    fun setDontShowAgain(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_DONT_SHOW_AGAIN, value).apply()
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
}
