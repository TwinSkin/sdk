package com.twinskin.sdk.ui.annotation_editor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayInputStream
import java.io.FileInputStream

/**
 * `BitmapFactory.decodeFile` ignores EXIF orientation, so we read it
 * separately and apply the matching rotation/flip. The capture
 * pipeline saves photos in the sensor's native landscape buffer
 * with `Orientation=6` (rotate 90° CW) on portrait-locked phones —
 * without this pass the editor renders the photo sideways.
 */
public actual fun loadImageFromPath(path: String): ImageBitmap {
    val bitmap = BitmapFactory.decodeFile(path)
        ?: error("BitmapFactory.decodeFile returned null for $path")
    val orientation = FileInputStream(path).use {
        ExifInterface(it).getAttributeInt(
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.ORIENTATION_NORMAL,
        )
    }
    return applyExifOrientation(bitmap, orientation).asImageBitmap()
}

/**
 * EXIF-aware like [loadImageFromPath]: Skia (iOS/JVM) applies EXIF
 * orientation inside `Image.makeFromEncoded`, so without this pass
 * Android would edit the unrotated sensor buffer and submit
 * annotation coordinates incompatible with the other platforms.
 */
public actual fun ByteArray.toImageBitmap(): ImageBitmap {
    val bitmap = BitmapFactory.decodeByteArray(this, 0, size)
        ?: error("BitmapFactory.decodeByteArray failed to decode image bytes")
    val orientation = ByteArrayInputStream(this).use {
        ExifInterface(it).getAttributeInt(
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.ORIENTATION_NORMAL,
        )
    }
    return applyExifOrientation(bitmap, orientation).asImageBitmap()
}

private fun applyExifOrientation(source: Bitmap, orientation: Int): Bitmap {
    val matrix = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_NORMAL,
        ExifInterface.ORIENTATION_UNDEFINED -> return source
        ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
        ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
        ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
        ExifInterface.ORIENTATION_TRANSPOSE -> {
            matrix.postRotate(90f); matrix.postScale(-1f, 1f)
        }
        ExifInterface.ORIENTATION_TRANSVERSE -> {
            matrix.postRotate(270f); matrix.postScale(-1f, 1f)
        }
        else -> return source
    }
    val rotated = Bitmap.createBitmap(
        source, 0, 0, source.width, source.height, matrix, true,
    )
    if (rotated !== source) source.recycle()
    return rotated
}
