package com.twinskin.sdk.ui.capture

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/**
 * Camera permission gate for the Android capture flow. Native to this
 * platform — the SDK no longer carries a shared permissions abstraction.
 *
 * Motion is intentionally absent: Android doesn't runtime-gate the raw IMU streams the driver reads,
 * and BODY_SENSORS / ACTIVITY_RECOGNITION (heart-rate/step APIs) are deliberately not declared.
 */
internal class CapturePermissionsState internal constructor(
    val granted: Boolean,
    val denied: Boolean,
    val permanentlyDenied: Boolean,
    val request: () -> Unit,
    val openAppSettings: () -> Unit,
)

@Composable
internal fun rememberCapturePermissionsState(): CapturePermissionsState {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val blocking = listOf(Manifest.permission.CAMERA)
    val optional = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        listOf(Manifest.permission.POST_NOTIFICATIONS)
    } else {
        emptyList()
    }
    val toRequest = blocking + optional

    fun checkBlocking(): Boolean = blocking.all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

    var granted by remember { mutableStateOf(checkBlocking()) }
    // Tick every time the runtime-prompt callback fires. Drives recomposition
    // even when neither `granted` nor a hypothetical `asked` flag has actually
    // changed value — e.g. a second denial, where shouldShowRequestPermissionRationale
    // flips false but the boolean grant result is identical to the first.
    var requestTick by remember { mutableStateOf(0) }

    // Re-check on resume so a grant made from system Settings flips the state
    // without requiring the user to tap the in-app button again.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) granted = checkBlocking()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { result ->
        granted = blocking.all { result[it] == true }
        requestTick++
    }

    val activity = remember(context) { context.findActivity() }
    val asked = requestTick > 0
    // shouldShowRequestPermissionRationale returns false both *before* the first
    // request and *after* a permanent denial — the `asked` guard disambiguates.
    val permanentlyDenied = asked && !granted && activity != null &&
        blocking.none { ActivityCompat.shouldShowRequestPermissionRationale(activity, it) }

    return CapturePermissionsState(
        granted = granted,
        denied = asked && !granted,
        permanentlyDenied = permanentlyDenied,
        request = { launcher.launch(toRequest.toTypedArray()) },
        openAppSettings = {
            val intent = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", context.packageName, null),
            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
        },
    )
}

private fun Context.findActivity(): Activity? {
    var ctx: Context = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}
