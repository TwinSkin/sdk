package com.twinskin.sdk.ui.capture

import android.graphics.PointF
import androidx.camera.view.transform.CoordinateTransform
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Dev-mode overlay: draws the live-detected ArUco quad over the
 *  preview via CameraX CoordinateTransform. Analyser corners are
 *  scaled into cropRect-local then rotated by rotationDegrees before
 *  mapPoint, matching the rotated-crop space the analyser
 *  OutputTransform lives in (rotation + crop flags both true). */
@Composable
internal fun MarkerDebugOverlay(
    markerFocus: MarkerFocusController?,
    controller: CameraSessionController?,
    modifier: Modifier = Modifier,
) {
    if (markerFocus == null) return
    val state by markerFocus.state.collectAsState()
    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val obs = (state as? MarkerFocusController.State.Locked)?.marker ?: return@Canvas
            if (obs.cornersXY.size != 8) return@Canvas
            if (obs.frameWidth <= 0 || obs.frameHeight <= 0) return@Canvas

            val analyserInfo = controller?.attachedAnalyserSurface ?: return@Canvas
            val previewView = controller.attachedPreviewView ?: return@Canvas
            val previewT = previewView.outputTransform ?: return@Canvas
            val transform = CoordinateTransform(analyserInfo.outputTransform, previewT)

            // Analyser → cropRect-local is a pure scale: CameraX's
            // cropRect is the same 4:3 region the analyser hands us,
            // so no offset is needed.
            val sx = analyserInfo.cropRectWidth.toFloat() / obs.frameWidth.toFloat()
            val sy = analyserInfo.cropRectHeight.toFloat() / obs.frameHeight.toFloat()

            val mapped = (0 until 4).map { i ->
                val ax = obs.cornersXY[i * 2 + 0]
                val ay = obs.cornersXY[i * 2 + 1]
                val cropX = ax * sx
                val cropY = ay * sy
                val (rotX, rotY) = rotateInCropRect(
                    cropX, cropY,
                    cropW = analyserInfo.cropRectWidth.toFloat(),
                    cropH = analyserInfo.cropRectHeight.toFloat(),
                    rotationDegrees = analyserInfo.rotationDegrees,
                )
                val pt = PointF(rotX, rotY)
                transform.mapPoint(pt)
                Offset(pt.x, pt.y)
            }
            val path = Path().apply {
                moveTo(mapped[0].x, mapped[0].y)
                for (i in 1 until 4) lineTo(mapped[i].x, mapped[i].y)
                close()
            }
            drawPath(path, color = Color.Green, style = Stroke(width = 4f))
            for (p in mapped) {
                drawCircle(color = Color.Green, radius = 6f, center = p)
            }
        }
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 96.dp, start = 12.dp),
            horizontalArrangement = Arrangement.Start,
        ) {
            Text(
                text = "ArUco: ${stateLabel(state)}",
                color = Color.White,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Start,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                style = MaterialTheme.typography.labelSmall,
            )
        }
    }
}

private fun stateLabel(state: MarkerFocusController.State): String = when (state) {
    is MarkerFocusController.State.Searching -> "searching"
    is MarkerFocusController.State.Refining -> "refining"
    is MarkerFocusController.State.Locked -> "locked id=${state.marker.markerId}"
    is MarkerFocusController.State.Reacquiring -> "reacquiring"
}

/** Rotate a point in a cropRect's local coord space by [rotationDegrees].
 *  Mirrors what CameraX's TransformUtils.getRotatedCropRect does to the
 *  cropRect dimensions, so a point at (x, y) in the unrotated rect ends
 *  up at the correct location in the rotated rect. */
internal fun rotateInCropRect(
    x: Float,
    y: Float,
    cropW: Float,
    cropH: Float,
    rotationDegrees: Int,
): Pair<Float, Float> = when ((rotationDegrees % 360 + 360) % 360) {
    0 -> x to y
    90 -> (cropH - y) to x
    180 -> (cropW - x) to (cropH - y)
    270 -> y to (cropW - x)
    else -> x to y
}
