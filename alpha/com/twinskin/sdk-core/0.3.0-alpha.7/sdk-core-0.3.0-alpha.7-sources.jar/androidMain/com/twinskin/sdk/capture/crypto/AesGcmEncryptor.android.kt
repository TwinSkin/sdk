package com.twinskin.sdk.capture.crypto

import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

internal actual class AesGcmEncryptor actual constructor(
    key: ByteArray,
    baseNonce: ByteArray,
) {
    init {
        require(key.size == 32) { "AES-256 key must be 32 bytes" }
        require(baseNonce.size == 12) { "GCM base nonce must be 12 bytes" }
    }

    private val secretKey = SecretKeySpec(key, "AES")
    private val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    private val nonce = baseNonce.copyOf()
    private var counter: Int = 0

    actual fun encryptChunk(plaintext: ByteArray, off: Int, len: Int): EncryptedChunk {
        nonce[8] = ((counter ushr 24) and 0xff).toByte()
        nonce[9] = ((counter ushr 16) and 0xff).toByte()
        nonce[10] = ((counter ushr 8) and 0xff).toByte()
        nonce[11] = (counter and 0xff).toByte()
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(128, nonce))
        val sealed = cipher.doFinal(plaintext, off, len)
        counter++
        val ct = sealed.copyOfRange(0, sealed.size - 16)
        val tag = sealed.copyOfRange(sealed.size - 16, sealed.size)
        return EncryptedChunk(ciphertext = ct, tag = tag)
    }
}
