package com.twinskin.sdk.ui.capture

import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.util.Log
import com.twinskin.sdk.capture.PhotosphereCaptureDriver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileWriter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicReference

/**
 * Decodes an MP4 trajectory frame-by-frame via `MediaExtractor` +
 * software `MediaCodec`, resamples each frame's Y-plane to 640×480, and
 * fires TWO buffer outputs per tick:
 *
 *  - **uint8 contiguous 640×480** → fed to
 *    [MarkerFocusController.ingestFrame] every Nth frame
 *    ([MARKER_CADENCE]) so the marker-focus state machine wakes up at
 *    the same cadence as the live path.
 *  - **float32-encoded 640×480** (limit = 1,228,800 B) → fed to
 *    [PhotosphereCaptureDriver.LiveFrameTap.onFrame] every frame.
 *
 * Lives in the `com.twinskin.sdk.ui.capture` package so it can take a
 * direct dependency on `internal` types.
 *
 * Source MP4 lives at `<sceneDir>/trajectory.mp4`. Optional
 * `<sceneDir>/index.json` overrides intrinsics + fps; absent → bundled
 * defaults (520/520, 320/240, 30 fps).
 *
 * Per-frame perf logging — DEBUG-only — is emitted via [logSink]: a
 * single batched `Log.i` per frame and the same line mirrored to
 * `frame_log.jsonl` under `session.workingDir` so logcat truncation
 * does not lose the timeline.
 *
 * The engine decodes as fast as `MediaCodec` + per-frame consumer
 * cost allow.
 */
internal class RimbaudReplayFrameSource(
    private val sceneDir: File,
    private val workingDir: File,
    private val ioScope: CoroutineScope =
        CoroutineScope(SupervisorJob() + Dispatchers.IO),
) {
    private val trajectoryFile: File = File(sceneDir, "trajectory.mp4")
    private val indexJsonFile: File = File(sceneDir, "index.json")

    private var driverJob: Job? = null
    private var intrinsics: FloatArray =
        floatArrayOf(
            DEFAULT_FX, 0f, DEFAULT_CX,
            0f, DEFAULT_FY, DEFAULT_CY,
            0f, 0f, 1f,
        )
    private var fps: Int = DEFAULT_FPS

    /**
     * Preview surface for decoded frames. Without it the analyser /
     * marker fan-out would consume frames but the host Compose
     * surface would have nothing to render and the operator would
     * see a black backdrop. Each decoded frame is published here as
     * a grayscale 640×480 [Bitmap]; the host collects the StateFlow
     * and renders it via [androidx.compose.foundation.Image].
     */
    private val frameFlow: MutableStateFlow<Bitmap?> = MutableStateFlow(null)
    val replayFrameFlow: StateFlow<Bitmap?> = frameFlow.asStateFlow()

    /**
     * Cached reference JPEG for the replay session. The driver's
     * `captureReference` requires a non-null `fullResJPEG: ByteArray`;
     * snapshotting frame 0 of the MP4 produces the trajectory origin
     * (typically off-axis, marker poorly framed), so XFeat
     * descriptors extracted from it fail to match downstream live
     * frames, producing 0 cheirality inliers and pose-degenerate
     * failures. The scene generator ships an engineered `ref.jpg` at
     * `<sceneDir>/ref.jpg` (deliberately chosen for marker
     * visibility) which we load eagerly in [start]. If the file is
     * missing we leave the cache null and log a warning; the driver
     * bails on ref-capture rather than silently regressing to the
     * frame-0 path.
     */
    private val refJpegFile: File = File(sceneDir, "ref.jpg")
    private val latestRefJpegRef: AtomicReference<ByteArray?> = AtomicReference(null)
    fun latestRefJpeg(): ByteArray? = latestRefJpegRef.get()

    /**
     * Per-arm shutter JPEG cache. Each decoded MP4 frame is
     * snapshotted as JPEG (q=92) here on the decode-loop thread; the
     * shutter callback reads it via [latestFrameJpeg]. Pre-encoding
     * (rather than holding the Bitmap and encoding on shutter)
     * because the shutter callback runs from the photosphere session
     * actor and keeping it allocation-free is safer.
     *
     * Each arm gets the latest decoded frame, not the staged
     * `ref.jpg`, so the archived `view_NN_rXaY.jpg` files are
     * distinct frames. Reusing `ref.jpg` for every arm would write
     * 16 identical view JPEGs and break downstream consumers.
     */
    private val latestFrameJpegRef: AtomicReference<ByteArray?> = AtomicReference(null)
    fun latestFrameJpeg(): ByteArray? = latestFrameJpegRef.get()

    /**
     * Reusable scratch buffer for the source Y-plane bulk read,
     * sized lazily on the first frame to `srcW * srcH` (or
     * `srcStride * srcH` when stride padding is present). Grown via
     * [ensureYPlaneScratch] if the codec hands us a larger frame
     * mid-stream (rare — MediaCodec output dimensions are stable
     * for a given track). One allocation per replay session in the
     * common path; lets the resamplers bulk-read once and then index
     * a primitive `ByteArray` instead of paying per-pixel direct-
     * buffer reads.
     */
    private var yPlaneScratch: ByteArray = ByteArray(0)

    private fun ensureYPlaneScratch(size: Int): ByteArray {
        if (yPlaneScratch.size < size) {
            yPlaneScratch = ByteArray(size)
        }
        return yPlaneScratch
    }

    /**
     * Begin the decode loop. Idempotent: returns early when the driver
     * job is already alive. The caller owns lifecycle teardown via
     * [stop] (called from a Compose `DisposableEffect.onDispose`).
     */
    fun start(
        markerSink: MarkerSink,
        liveTap: PhotosphereCaptureDriver.LiveFrameTap,
        logSink: PerfLogSink,
        isSessionTerminal: () -> Boolean = { false },
    ) {
        val existing = driverJob
        if (existing != null && existing.isActive) {
            Log.i(LOG_TAG, "replay driver already running; ignoring duplicate start()")
            return
        }
        loadIndexJson()
        loadRefJpegEagerly()
        driverJob =
            ioScope.launch {
                runDecoder(markerSink, liveTap, logSink, isSessionTerminal)
            }
    }

    /**
     * Load `<sceneDir>/ref.jpg` into [latestRefJpegRef] before the
     * decoder coroutine spins up; the scene catalogue stages the
     * file on first launch. On failure the cache stays null and the
     * driver surfaces a "replay refJpegProvider gave up" error.
     * Better than silently regressing to frame-0 capture which
     * produces pose-degenerate sessions with no arm commits.
     */
    private fun loadRefJpegEagerly() {
        if (!refJpegFile.isFile) {
            Log.w(
                LOG_TAG,
                "ref.jpg missing at ${refJpegFile.absolutePath} — " +
                    "synthetic-replay ref capture will fail. " +
                    "Expected SyntheticSceneCatalogue.stageScene to write it.",
            )
            return
        }
        val bytes =
            runCatching { refJpegFile.readBytes() }
                .onFailure {
                    Log.w(LOG_TAG, "ref.jpg read failed at ${refJpegFile.absolutePath}", it)
                }
                .getOrNull()
        if (bytes != null && bytes.isNotEmpty()) {
            latestRefJpegRef.set(bytes)
            Log.i(LOG_TAG, "replay ref.jpg loaded: ${bytes.size}B from ${refJpegFile.absolutePath}")
        }
    }

    fun stop() {
        driverJob?.cancel()
        driverJob = null
    }

    private fun loadIndexJson() {
        if (!indexJsonFile.exists()) {
            Log.i(LOG_TAG, "no index.json at ${indexJsonFile.absolutePath}; using defaults")
            return
        }
        try {
            val parsed = JSONObject(indexJsonFile.readText(Charsets.UTF_8))
            val k = parsed.optJSONObject("K_analyser")
            val fx = k?.optDouble("fx", DEFAULT_FX.toDouble())?.toFloat() ?: DEFAULT_FX
            val fy = k?.optDouble("fy", DEFAULT_FY.toDouble())?.toFloat() ?: DEFAULT_FY
            val cx = k?.optDouble("cx", DEFAULT_CX.toDouble())?.toFloat() ?: DEFAULT_CX
            val cy = k?.optDouble("cy", DEFAULT_CY.toDouble())?.toFloat() ?: DEFAULT_CY
            intrinsics =
                floatArrayOf(
                    fx, 0f, cx,
                    0f, fy, cy,
                    0f, 0f, 1f,
                )
            fps = parsed.optInt("fps", DEFAULT_FPS)
            Log.i(
                LOG_TAG,
                "replay intrinsics fx=$fx fy=$fy cx=$cx cy=$cy fps=$fps " +
                    "scene=${sceneDir.absolutePath}",
            )
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "index.json parse failed; using defaults", t)
        }
    }

    private fun runDecoder(
        markerSink: MarkerSink,
        liveTap: PhotosphereCaptureDriver.LiveFrameTap,
        logSink: PerfLogSink,
        isSessionTerminal: () -> Boolean,
    ) {
        // Loop the trajectory until the session reaches a terminal
        // stage (queried via [isSessionTerminal]) or
        // [MAX_REPLAY_PASSES] is hit: the 1020-frame trajectory
        // occasionally exhausts before the picker has dwelled on
        // every uncaptured arm, and a single-pass exit leaves the
        // bundle incomplete on slower devices. Each pass uses a
        // fresh `MediaExtractor` + `MediaCodec` (cheaper to recreate
        // than to flush/seek the codec, and avoids post-EOS reuse
        // quirks).
        val frameLog: FileWriter? =
            try {
                workingDir.mkdirs()
                FileWriter(File(workingDir, FRAME_LOG_FILENAME), /* append = */ true)
            } catch (t: Throwable) {
                Log.w(LOG_TAG, "frame_log.jsonl open failed", t)
                null
            }
        try {
            var totalDelivered = 0
            var pass = 0
            while (!isSessionTerminal() && pass < MAX_REPLAY_PASSES) {
                pass += 1
                Log.i(
                    LOG_TAG,
                    "replay pass $pass start (max=$MAX_REPLAY_PASSES " +
                        "totalDelivered=$totalDelivered)",
                )
                val delivered = runSinglePass(markerSink, liveTap, logSink, frameLog)
                totalDelivered += delivered
                val terminal = isSessionTerminal()
                Log.i(
                    LOG_TAG,
                    "replay pass $pass end (terminal=$terminal " +
                        "delivered=$delivered totalDelivered=$totalDelivered)",
                )
                if (Thread.currentThread().isInterrupted) break
            }
            val terminal = isSessionTerminal()
            if (!terminal && pass >= MAX_REPLAY_PASSES) {
                Log.w(
                    LOG_TAG,
                    "replay loop hit safety cap ($MAX_REPLAY_PASSES passes) " +
                        "without reaching terminal stage",
                )
            }
            Log.i(
                LOG_TAG,
                "replay driver exited; terminal=$terminal " +
                    "delivered=$totalDelivered passes=$pass/$MAX_REPLAY_PASSES",
            )
        } finally {
            try {
                frameLog?.flush()
                frameLog?.close()
            } catch (t: Throwable) {
                Log.w(LOG_TAG, "frame_log.jsonl close failed", t)
            }
        }
    }

    private fun runSinglePass(
        markerSink: MarkerSink,
        liveTap: PhotosphereCaptureDriver.LiveFrameTap,
        logSink: PerfLogSink,
        frameLog: FileWriter?,
    ): Int {
        if (!trajectoryFile.isFile) {
            Log.w(LOG_TAG, "trajectory.mp4 not found at ${trajectoryFile.absolutePath}")
            return 0
        }
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        var delivered = 0
        try {
            extractor.setDataSource(trajectoryFile.absolutePath)
            val trackIndex = selectVideoTrack(extractor)
            if (trackIndex < 0) {
                Log.w(LOG_TAG, "no video track in ${trajectoryFile.absolutePath}")
                return 0
            }
            extractor.selectTrack(trackIndex)
            val format = extractor.getTrackFormat(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return 0
            format.setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible,
            )
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()
            delivered = decodeLoop(markerSink, liveTap, logSink, frameLog, extractor, codec)
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "replay decoder threw", t)
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
        return delivered
    }

    @Suppress("LongMethod", "CyclomaticComplexMethod", "NestedBlockDepth")
    private fun decodeLoop(
        markerSink: MarkerSink,
        liveTap: PhotosphereCaptureDriver.LiveFrameTap,
        logSink: PerfLogSink,
        frameLog: FileWriter?,
        extractor: MediaExtractor,
        codec: MediaCodec,
    ): Int {
        val bufferInfo = MediaCodec.BufferInfo()
        val frameIntervalNanos = 1_000_000_000L / fps.coerceAtLeast(1)
        // Reusable output buffers — allocated once, the consumers read
        // synchronously inside the same thread (live tap and marker
        // sink are both serial).
        val uint8Buf =
            ByteBuffer
                .allocateDirect(XFEAT_W * XFEAT_H)
                .order(ByteOrder.nativeOrder())
        val float32Buf =
            ByteBuffer
                .allocateDirect(XFEAT_W * XFEAT_H * Float.SIZE_BYTES)
                .order(ByteOrder.nativeOrder())
        // Primitive FloatArray staging (~10-20× over per-pixel
        // DirectFloatBuffer.put because ART vectorises primitive
        // stores; per-pixel direct-buffer puts go through bounds-check
        // + position-increment per element).
        val floatStage = FloatArray(XFEAT_W * XFEAT_H)
        // Primitive ByteArray staging for the uint8 marker path.
        // Replaces per-pixel `ByteBuffer.put(byte)` (~250 ms/frame on
        // slow SoCs) with a single bulk `out.put(byteStage)` at end
        // of the resample kernel.
        val byteStage = ByteArray(XFEAT_W * XFEAT_H)

        var sawInputEOS = false
        var sawOutputEOS = false
        var firstFrameWallNanos = 0L
        var firstFramePtsUs = 0L
        var frameIndex = 0

        while (!sawOutputEOS && !Thread.currentThread().isInterrupted) {
            if (!sawInputEOS) {
                val inIndex = codec.dequeueInputBuffer(DEQUEUE_TIMEOUT_US)
                if (inIndex >= 0) {
                    val inBuf = codec.getInputBuffer(inIndex)!!
                    val sampleSize = extractor.readSampleData(inBuf, 0)
                    if (sampleSize < 0) {
                        codec.queueInputBuffer(
                            inIndex, 0, 0, 0,
                            MediaCodec.BUFFER_FLAG_END_OF_STREAM,
                        )
                        sawInputEOS = true
                    } else {
                        val pts = extractor.sampleTime
                        codec.queueInputBuffer(inIndex, 0, sampleSize, pts, 0)
                        extractor.advance()
                    }
                }
            }
            val outIndex = codec.dequeueOutputBuffer(bufferInfo, DEQUEUE_TIMEOUT_US)
            if (outIndex >= 0) {
                val image = codec.getOutputImage(outIndex)
                if (image != null) {
                    if (firstFrameWallNanos == 0L) {
                        firstFrameWallNanos = System.nanoTime()
                        firstFramePtsUs = bufferInfo.presentationTimeUs
                    }
                    val tFrameStartNs = System.nanoTime()
                    pushFrame(
                        image = image,
                        frameIndex = frameIndex,
                        markerSink = markerSink,
                        liveTap = liveTap,
                        logSink = logSink,
                        frameLog = frameLog,
                        uint8Buf = uint8Buf,
                        float32Buf = float32Buf,
                        floatStage = floatStage,
                        byteStage = byteStage,
                        tFrameStartNs = tFrameStartNs,
                    )
                    image.close()
                    paceToPts(
                        bufferInfo.presentationTimeUs,
                        firstFramePtsUs,
                        firstFrameWallNanos,
                        frameIndex,
                        frameIntervalNanos,
                    )
                    frameIndex += 1
                }
                codec.releaseOutputBuffer(outIndex, false)
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    sawOutputEOS = true
                }
            }
        }
        Log.i(LOG_TAG, "replay decode complete; delivered=$frameIndex")
        return frameIndex
    }

    @Suppress("LongParameterList")
    private fun pushFrame(
        image: android.media.Image,
        frameIndex: Int,
        markerSink: MarkerSink,
        liveTap: PhotosphereCaptureDriver.LiveFrameTap,
        logSink: PerfLogSink,
        frameLog: FileWriter?,
        uint8Buf: ByteBuffer,
        float32Buf: ByteBuffer,
        floatStage: FloatArray,
        byteStage: ByteArray,
        tFrameStartNs: Long,
    ) {
        val srcW = image.width
        val srcH = image.height
        val planeY = image.planes[0]
        val rowStride = planeY.rowStride
        val pixelStride = planeY.pixelStride
        val src = planeY.buffer

        // Stage 1 — copy / resample the Y-plane into the contiguous
        // 640×480 uint8 buffer. Fast path: source is already 640×480
        // → row copy. Otherwise nearest-neighbour resample into a
        // primitive ByteArray staging area + a single bulk
        // `out.put(byteStage)`; NN (not bilinear) because the prior
        // bilinear + per-pixel put kernel cost ~250 ms/frame on slow
        // SoCs.
        val tCopyStartNs = System.nanoTime()
        uint8Buf.clear()
        if (srcW == XFEAT_W && srcH == XFEAT_H) {
            fillByteViewExact(src, rowStride, pixelStride, uint8Buf)
        } else {
            fillByteViewResampled(
                src = src,
                srcW = srcW,
                srcH = srcH,
                rowStride = rowStride,
                pixelStride = pixelStride,
                out = uint8Buf,
                byteStage = byteStage,
            )
        }
        uint8Buf.position(0)
        uint8Buf.limit(XFEAT_W * XFEAT_H)
        val tCopyEndNs = System.nanoTime()

        // Build a colour ARGB bitmap from the full YUV420 image and
        // publish it for the Compose preview surface so the operator
        // sees the scene the 3D pipeline reconstructs. The dwell
        // tracker still consumes the grayscale Y-only `uint8Buf`;
        // colour is purely cosmetic.
        val previewBitmap = colorBitmapFromYuv420(image, srcW, srcH)
        frameFlow.value = previewBitmap

        // Encode the latest decoded frame into JPEG (q=92) for the
        // per-arm shutter callback. Synchronous on the decode-loop
        // thread (Dispatchers.IO) because replay budgets are non-
        // real-time and the shutter callback must be allocation-free
        // on the photosphere session actor.
        val frameJpeg =
            runCatching { bitmapToJpeg(previewBitmap) }
                .onFailure { Log.w(LOG_TAG, "frame JPEG encode failed at frame=$frameIndex", it) }
                .getOrNull()
        if (frameJpeg != null && frameJpeg.isNotEmpty()) {
            latestFrameJpegRef.set(frameJpeg)
        }

        // Stage 2 — convert the uint8 buffer to float32 via the
        // primitive-FloatArray + bulk-transfer staging idiom. Reads
        // from the primitive `byteStage` rather than per-pixel
        // `ByteBuffer.get`, which on direct buffers is ~5-10× slower
        // than primitive-array access. In the resample path
        // `byteStage` is already populated by `fillByteViewResampled`;
        // in the exact path we drain `uint8Buf` into `byteStage`
        // once via a bulk `get`. The float32 buffer is independent of
        // uint8Buf so both downstream consumers hold their own
        // positions.
        val tConvStartNs = System.nanoTime()
        run {
            val n = XFEAT_W * XFEAT_H
            if (srcW == XFEAT_W && srcH == XFEAT_H) {
                val view = uint8Buf.duplicate()
                view.order(ByteOrder.nativeOrder())
                view.position(0)
                view.get(byteStage, 0, n)
            }
            for (i in 0 until n) {
                floatStage[i] = (byteStage[i].toInt() and 0xFF).toFloat()
            }
            float32Buf.position(0)
            float32Buf.asFloatBuffer().put(floatStage)
            float32Buf.position(0)
            float32Buf.limit(n * Float.SIZE_BYTES)
        }
        val tConvEndNs = System.nanoTime()

        // Stage 3 — fan out to MarkerFocus (every Nth frame) +
        // LiveFrameTap (every frame). Order matches live path:
        // marker first, then tap.
        val tFanoutStartNs = System.nanoTime()
        if (frameIndex % MARKER_CADENCE == 0) {
            try {
                markerSink.onMarkerFrame(
                    gray = uint8Buf,
                    width = XFEAT_W,
                    height = XFEAT_H,
                    rowStride = XFEAT_W,
                )
            } catch (t: Throwable) {
                Log.w(LOG_TAG, "marker sink threw", t)
            }
            // Reset positions for the live-tap consumer.
            uint8Buf.position(0)
            uint8Buf.limit(XFEAT_W * XFEAT_H)
        }
        try {
            liveTap.onFrame(float32Buf, intrinsics, System.nanoTime())
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "liveTap.onFrame threw", t)
        }
        val tFanoutEndNs = System.nanoTime()

        // Single batched perf line per frame. Stage timings in ms
        // with one decimal; logcat-parseable with `awk -F'[= ]'
        // '{print $4}'` and `frame_log.jsonl` gives the truncation-
        // proof mirror.
        val copyMs = nsToMs(tCopyEndNs - tCopyStartNs)
        val convMs = nsToMs(tConvEndNs - tConvStartNs)
        val fanoutMs = nsToMs(tFanoutEndNs - tFanoutStartNs)
        val totalMs = nsToMs(tFanoutEndNs - tFrameStartNs)
        val line =
            "phase=copy:$copyMs,conv:$convMs,fanout:$fanoutMs,total:$totalMs frame=$frameIndex"
        Log.i(PERF_TAG, line)
        try {
            logSink.onPerfLine(line)
        } catch (t: Throwable) {
            Log.w(LOG_TAG, "logSink threw", t)
        }
        if (frameLog != null) {
            try {
                val json =
                    JSONObject().apply {
                        put("frame", frameIndex)
                        put("copy_ms", copyMs)
                        put("conv_ms", convMs)
                        put("fanout_ms", fanoutMs)
                        put("total_ms", totalMs)
                        put("source", "synthetic_replay")
                    }
                frameLog.write(json.toString())
                frameLog.write("\n")
                frameLog.flush()
            } catch (t: Throwable) {
                Log.w(LOG_TAG, "frame_log.jsonl write failed", t)
            }
        }
    }

    private fun fillByteViewExact(
        src: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        out: ByteBuffer,
    ) {
        val view = src.duplicate()
        view.order(ByteOrder.nativeOrder())
        if (pixelStride == 1) {
            // Fast path: row-aligned uint8 copy (rowStride may exceed
            // width on some codecs — read one row at a time).
            val rowBuf = ByteArray(XFEAT_W)
            for (y in 0 until XFEAT_H) {
                view.position(y * rowStride)
                view.get(rowBuf, 0, XFEAT_W)
                out.put(rowBuf, 0, XFEAT_W)
            }
        } else {
            for (y in 0 until XFEAT_H) {
                val rowStart = y * rowStride
                for (x in 0 until XFEAT_W) {
                    out.put(view.get(rowStart + x * pixelStride))
                }
            }
        }
    }

    /**
     * Nearest-neighbour resampler into a primitive `ByteArray`
     * staging area + a single bulk `out.put(byteStage)` at end.
     * NN (not bilinear) because the prior bilinear + per-pixel
     * `ByteBuffer.put(byte)` kernel cost ~250 ms median per frame on
     * slow SoCs; primitive-array access is ~5-10× faster than
     * per-pixel direct-buffer writes on this hardware.
     *
     * Center-crop to the largest 4:3 box centred on source bounds
     * the NN sampling range so a portrait/wider source isn't
     * aspect-warped to 4:3. Row reads honour `rowStride` so padded
     * codec output stays correct.
     */
    @Suppress("LongMethod", "LongParameterList")
    private fun fillByteViewResampled(
        src: ByteBuffer,
        srcW: Int,
        srcH: Int,
        rowStride: Int,
        pixelStride: Int,
        out: ByteBuffer,
        byteStage: ByteArray,
    ) {
        val bytes = readYPlaneToScratch(src, srcW, srcH, rowStride, pixelStride)
        // Largest 4:3 box centred on source (preserved from prior
        // bilinear kernel — bounds the NN sampling range so a wider
        // or taller source doesn't aspect-warp).
        val targetAspectNum = XFEAT_W
        val targetAspectDen = XFEAT_H
        val srcAspectNumByH = srcW * targetAspectDen
        val srcAspectDenByH = srcH * targetAspectNum
        var cropW: Int
        var cropH: Int
        if (srcAspectNumByH >= srcAspectDenByH) {
            cropH = srcH
            cropW = (srcH.toLong() * targetAspectNum / targetAspectDen).toInt()
            if (cropW > srcW) cropW = srcW
        } else {
            cropW = srcW
            cropH = (srcW.toLong() * targetAspectDen / targetAspectNum).toInt()
            if (cropH > srcH) cropH = srcH
        }
        val offsetX = (srcW - cropW) / 2
        val offsetY = (srcH - cropH) / 2
        for (y in 0 until XFEAT_H) {
            val sy = (y * cropH) / XFEAT_H + offsetY
            val rowBase = sy * srcW
            val dstBase = y * XFEAT_W
            for (x in 0 until XFEAT_W) {
                val sx = (x * cropW) / XFEAT_W + offsetX
                byteStage[dstBase + x] = bytes[rowBase + sx]
            }
        }
        out.position(0)
        out.put(byteStage, 0, XFEAT_W * XFEAT_H)
    }

    /**
     * Bulk-read the source Y-plane into the reusable [yPlaneScratch]
     * `ByteArray`, honouring `rowStride` and `pixelStride`. Returns
     * the scratch reference for caller-side indexing.
     *
     * Fast paths:
     *  - `pixelStride == 1 && rowStride == srcW`: single
     *    `src.get(bytes, 0, n)`.
     *  - `pixelStride == 1 && rowStride > srcW`: row-by-row, still
     *    one bulk `src.get(bytes, off, srcW)` per row.
     *  - `pixelStride > 1`: per-pixel `view.get(...)` — only hit on
     *    exotic codec output.
     */
    private fun readYPlaneToScratch(
        src: ByteBuffer,
        srcW: Int,
        srcH: Int,
        rowStride: Int,
        pixelStride: Int,
    ): ByteArray {
        val n = srcW * srcH
        val bytes = ensureYPlaneScratch(n)
        val view = src.duplicate()
        view.order(ByteOrder.nativeOrder())
        if (pixelStride == 1) {
            if (rowStride == srcW) {
                view.position(0)
                view.get(bytes, 0, n)
            } else {
                for (y in 0 until srcH) {
                    view.position(y * rowStride)
                    view.get(bytes, y * srcW, srcW)
                }
            }
        } else {
            for (y in 0 until srcH) {
                val rowStart = y * rowStride
                val dstRow = y * srcW
                for (x in 0 until srcW) {
                    bytes[dstRow + x] = view.get(rowStart + x * pixelStride)
                }
            }
        }
        return bytes
    }

    /**
     * Encode an ARGB_8888 bitmap into JPEG bytes at q=92, matching
     * the live path's CameraX `takePhoto` output quality.
     */
    private fun bitmapToJpeg(bitmap: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        return out.toByteArray()
    }

    /**
     * Build an ARGB_8888 bitmap from the contiguous 640×480 uint8
     * Y-plane by duplicating each Y byte into the R/G/B channels for
     * a neutral grayscale rendering. Allocation-heavy (an IntArray +
     * a Bitmap per frame); fine here on the IO dispatcher and replay
     * budgets are non-real-time.
     */
    private fun grayBitmapFromUint8Buf(buf: ByteBuffer): Bitmap {
        val n = XFEAT_W * XFEAT_H
        val bytes = ByteArray(n)
        val view = buf.duplicate()
        view.position(0)
        view.get(bytes, 0, n)
        val pixels = IntArray(n)
        for (i in 0 until n) {
            val v = bytes[i].toInt() and 0xFF
            pixels[i] = Color.rgb(v, v, v)
        }
        return Bitmap.createBitmap(pixels, XFEAT_W, XFEAT_H, Bitmap.Config.ARGB_8888)
    }

    /**
     * Reusable scratch for [colorBitmapFromYuv420]. Sized at the source
     * MP4's plane dimensions; lazy-allocated on the first frame so we
     * don't allocate ~1 MB / frame from the decode loop hot path.
     */
    private var colorYScratch: ByteArray = ByteArray(0)
    private var colorUScratch: ByteArray = ByteArray(0)
    private var colorVScratch: ByteArray = ByteArray(0)
    private var colorPixelScratch: IntArray = IntArray(0)
    private var colorPreviewW: Int = 0
    private var colorPreviewH: Int = 0

    /**
     * YUV420 (NV12/I420) → ARGB conversion for the Compose preview.
     * Reads all three planes from the MediaCodec [Image], decimates
     * to half resolution, and synthesises a per-pixel BT.601 RGB
     * conversion via primitive-`ByteArray` indexing. The dwell
     * tracker does NOT consume this Bitmap — it operates on luma only
     * via the [uint8Buf] / [float32Buf] outputs — so half resolution
     * is fine for the operator preview (the host upscales via
     * `ContentScale.Crop`).
     *
     * Half-res is mandatory at this code path: at native 640×480 the
     * per-pixel YUV→RGB loop on slow Cortex-A55 cores ran 150-250 ms
     * per frame, beyond the MP4's 33 ms PTS budget at 30 fps. At
     * 320×240 it lands at ~10-30 ms.
     *
     * Bulk-drain each plane via `ByteBuffer.get(byte[])` once per
     * frame (NEON-accelerated direct-buffer memcpy on ARM kernels),
     * then index primitive arrays in the inner loop — orders of
     * magnitude cheaper than ~1M per-pixel `get(int)` direct-buffer
     * reads per frame.
     *
     * Handles both planar (I420, pixelStride=1) and semi-planar
     * (NV12/NV21, pixelStride=2) chroma layouts via the per-plane
     * `pixelStride` field.
     */
    private fun colorBitmapFromYuv420(
        image: android.media.Image,
        width: Int,
        height: Int,
    ): Bitmap {
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        val yBuf = yPlane.buffer
        val uBuf = uPlane.buffer
        val vBuf = vPlane.buffer
        val yRowStride = yPlane.rowStride
        val yPixelStride = yPlane.pixelStride
        val uRowStride = uPlane.rowStride
        val uPixelStride = uPlane.pixelStride
        val vRowStride = vPlane.rowStride
        val vPixelStride = vPlane.pixelStride

        val yPlaneBytes = yBuf.remaining()
        val uPlaneBytes = uBuf.remaining()
        val vPlaneBytes = vBuf.remaining()
        if (colorYScratch.size < yPlaneBytes) colorYScratch = ByteArray(yPlaneBytes)
        if (colorUScratch.size < uPlaneBytes) colorUScratch = ByteArray(uPlaneBytes)
        if (colorVScratch.size < vPlaneBytes) colorVScratch = ByteArray(vPlaneBytes)
        // Bulk-drain each plane to primitive arrays. The DirectByteBuffer
        // `get(byte[], offset, length)` is a single NEON memcpy on ARM
        // kernels — orders of magnitude cheaper than the per-pixel
        // `get(int)` calls the inner loop used to make.
        yBuf.get(colorYScratch, 0, yPlaneBytes)
        uBuf.get(colorUScratch, 0, uPlaneBytes)
        vBuf.get(colorVScratch, 0, vPlaneBytes)

        val outW = width / 2
        val outH = height / 2
        val outLen = outW * outH
        if (colorPreviewW != outW || colorPreviewH != outH || colorPixelScratch.size < outLen) {
            colorPixelScratch = IntArray(outLen)
            colorPreviewW = outW
            colorPreviewH = outH
        }
        val pixels = colorPixelScratch
        val yArr = colorYScratch
        val uArr = colorUScratch
        val vArr = colorVScratch
        var dstIdx = 0
        for (yh in 0 until outH) {
            val srcY = yh * 2
            val yRowBase = srcY * yRowStride
            val cRowBase = (srcY shr 1) * uRowStride
            for (xh in 0 until outW) {
                val srcX = xh * 2
                val yV = (yArr[yRowBase + srcX * yPixelStride].toInt() and 0xFF) - 16
                val uV = (uArr[cRowBase + (srcX shr 1) * uPixelStride].toInt() and 0xFF) - 128
                val vV = (vArr[cRowBase + (srcX shr 1) * vPixelStride].toInt() and 0xFF) - 128
                // BT.601 limited-range → full-range RGB; coefficients
                // pre-multiplied by 1024 for fixed-point, +512 to round.
                val yScaled = 1192 * yV
                var r = (yScaled + 1634 * vV + 512) shr 10
                var g = (yScaled - 833 * vV - 400 * uV + 512) shr 10
                var b = (yScaled + 2066 * uV + 512) shr 10
                if (r < 0) r = 0 else if (r > 255) r = 255
                if (g < 0) g = 0 else if (g > 255) g = 255
                if (b < 0) b = 0 else if (b > 255) b = 255
                pixels[dstIdx++] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        // Bitmap.createBitmap copies the IntArray internally so the
        // emitted Bitmap is independent of the reused scratch — the
        // next frame can overwrite `colorPixelScratch` safely.
        return Bitmap.createBitmap(pixels, outW, outH, Bitmap.Config.ARGB_8888)
    }

    private fun paceToPts(
        ptsUs: Long,
        firstPtsUs: Long,
        firstWallNanos: Long,
        frameIndex: Int,
        frameIntervalNanos: Long,
    ) {
        val elapsedPtsNanos =
            if (ptsUs > firstPtsUs) {
                (ptsUs - firstPtsUs) * 1000L
            } else {
                frameIndex.toLong() * frameIntervalNanos
            }
        val targetWallNanos = firstWallNanos + elapsedPtsNanos
        val now = System.nanoTime()
        val sleepNanos = targetWallNanos - now
        if (sleepNanos > 0) {
            val millis = sleepNanos / 1_000_000L
            val rem = (sleepNanos - millis * 1_000_000L).toInt()
            runCatching { Thread.sleep(millis, rem) }
        }
    }

    private fun selectVideoTrack(extractor: MediaExtractor): Int {
        for (i in 0 until extractor.trackCount) {
            val fmt = extractor.getTrackFormat(i)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/")) return i
        }
        return -1
    }

    private fun nsToMs(ns: Long): String {
        val ms = ns / 1_000_000.0
        return String.format("%.1f", ms)
    }

    /**
     * Marker-focus sink seam — exists so the replay engine doesn't take
     * a hard reference to [MarkerFocusController]'s exact API shape (it
     * does match `ingestFrame(gray, w, h, rowStride)` today, but
     * keeping the seam local makes the replay engine unit-testable in
     * isolation and keeps the dependency direction one-way).
     */
    fun interface MarkerSink {
        fun onMarkerFrame(
            gray: ByteBuffer,
            width: Int,
            height: Int,
            rowStride: Int,
        )
    }

    /**
     * Per-frame perf line sink. The engine always writes its own
     * `Log.i` and `frame_log.jsonl` mirror; this hook lets the host
     * forward to any additional sinks (e.g. an in-memory ring buffer
     * for an on-screen HUD).
     */
    fun interface PerfLogSink {
        fun onPerfLine(line: String)
    }

    companion object {
        private const val LOG_TAG: String = "RimbaudReplay"
        private const val PERF_TAG: String = "AnalyserPerf"
        private const val FRAME_LOG_FILENAME: String = "frame_log.jsonl"

        private const val XFEAT_W: Int = 640
        private const val XFEAT_H: Int = 480

        /** Per-arm shutter JPEG quality. */
        private const val JPEG_QUALITY: Int = 92

        /** Cadence at which marker-focus is fed; matches
         *  [CameraSessionController.MARKER_CADENCE] so the perf-debug
         *  timeline is faithful to live numbers. */
        private const val MARKER_CADENCE: Int = 5

        /**
         * Safety cap for the trajectory replay loop. The 1020-frame
         * mock trajectories occasionally exhaust before every
         * uncaptured arm has cleared its dwell window; looping the
         * trajectory feeds the picker a second chance without making
         * the QA harness unbounded. 8 × 1020 frames at synthetic 30
         * fps is ~4.5 minutes — bounded enough to fail closed when a
         * scene is genuinely missing an arm's pose.
         */
        const val MAX_REPLAY_PASSES: Int = 8

        private const val DEFAULT_FPS: Int = 30
        private const val DEFAULT_FX: Float = 520f
        private const val DEFAULT_FY: Float = 520f
        private const val DEFAULT_CX: Float = 320f
        private const val DEFAULT_CY: Float = 240f
        private const val DEQUEUE_TIMEOUT_US: Long = 10_000L
    }
}
