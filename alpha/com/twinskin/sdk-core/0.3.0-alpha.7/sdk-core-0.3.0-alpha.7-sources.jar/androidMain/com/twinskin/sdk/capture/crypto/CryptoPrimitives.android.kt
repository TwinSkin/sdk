package com.twinskin.sdk.capture.crypto

import java.security.KeyFactory
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.spec.MGF1ParameterSpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource

private val random = SecureRandom()

internal actual fun secureRandomBytes(out: ByteArray): Unit = random.nextBytes(out)

internal actual fun rsaOaepSha256Encrypt(publicKeyDer: ByteArray, plaintext: ByteArray): ByteArray {
    val pubKey = KeyFactory.getInstance("RSA")
        .generatePublic(X509EncodedKeySpec(publicKeyDer))
    // Explicit OAEP parameters — AndroidKeyStore's default MGF1 digest is SHA-1 even when
    // the outer digest is SHA-256. Force SHA-256 for MGF1 to match the server.
    val cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
    val oaep = OAEPParameterSpec(
        "SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT,
    )
    cipher.init(Cipher.ENCRYPT_MODE, pubKey, oaep)
    return cipher.doFinal(plaintext)
}

internal actual fun sha256(input: ByteArray): ByteArray =
    MessageDigest.getInstance("SHA-256").digest(input)
