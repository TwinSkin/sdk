package com.twinskin.sdk.ui.capture

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.util.Log

/**
 * [CameraSessionController.lockLensAndExposureForPhotosphere] (via
 * [LensFocusLockPolicy.decideStrategy]) to pick the correct per-HAL
 * lens-lock posture for the photosphere sweep.
 *
 * Background — see
 * `evaluate-xfeat-lighterglue/docs/tracking/cl103-pixel6-focus-lock-fix-2026-05-08.md`
 * § "XCover 5 HAL caveat" and the predecessor architect finding
 * `android-focus-lock-broken-2026-04-30.md`. The hardware level
 * (`INFO_SUPPORTED_HARDWARE_LEVEL`) gates whether the HAL honours
 * `LENS_FOCUS_DISTANCE` writes reliably enough for the
 * `AF_MODE_OFF_PIN_DISTANCE` strategy to land cleanly. LIMITED HALs
 * (XCover 5 / SM-G525F, A21s) keep the legacy `AF_MODE_OFF_ONLY`
 * posture; FULL / LEVEL_3 with calibrated lenses get pin-distance.
 *
 * The detection is split into a pure scoring function
 * ([needsLimitedHalGlRaceCure]) and an Android-edge query
 * ([queryBackCameraHardwareLevel]) so the policy is unit-testable
 * without driving a real `CameraManager` through Robolectric shadows.
 *
 * Ported verbatim from
 * `evaluate-xfeat-lighterglue/android/app/src/main/kotlin/ai/twinskin/xfeat/demoapp/Camera2HardwareLevel.kt`
 * with package + logging-tag adjustments only.
 */
internal object Camera2HardwareLevel {
    private const val TAG = "sdk-cl103-hw-level"

    /**
     * Pure policy: returns `true` when the supplied Camera2 hardware
     * level signals a HAL class that needs the LIMITED-HAL GL-race
     * preview cure. Currently informational on the SDK side (the SDK
     * does not yet wire the surface-gate); kept for parity with the
     * upstream demo and because a future preview-binding fix in the
     * SDK will need the same mapping.
     *
     * Mapping (from `android.hardware.camera2.CameraMetadata`):
     * - `INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED` (0) — needs cure
     * - `INFO_SUPPORTED_HARDWARE_LEVEL_FULL` (1) — safe
     * - `INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY` (2) — safe (see KDoc)
     * - `INFO_SUPPORTED_HARDWARE_LEVEL_3` (3) — safe
     * - `INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL` (4) — safe
     * - `null` — safe (we cannot identify the HAL; default to the
     *   pre-CL-092 behaviour of binding immediately)
     */
    fun needsLimitedHalGlRaceCure(level: Int?): Boolean {
        val limited = CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED
        return level == limited
    }

    /**
     * Android-edge query: reads `INFO_SUPPORTED_HARDWARE_LEVEL` for the
     * first back-facing camera the system reports. Returns `null` when
     * the system has no `CameraManager`, no back camera, or the lookup
     * throws (Camera2 query exceptions are non-fatal — we propagate
     * `null` so [needsLimitedHalGlRaceCure] picks the safe default).
     *
     * Intended to be called once per [CameraSessionController.bindToLifecycle]
     * and the result cached on the controller; the hardware level is a
     * stable property of the device and does not change at runtime.
     */
    fun queryBackCameraHardwareLevel(context: Context): Int? =
        runCatching {
            val manager =
                context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                    ?: return@runCatching null
            val cameraId = firstBackCameraId(manager) ?: return@runCatching null
            val chars = manager.getCameraCharacteristics(cameraId)
            chars.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)
        }.onFailure { Log.w(TAG, "hardware level query failed", it) }
            .getOrNull()

    /**
     * Human-readable label for [Log] sites. Mirrors the constant names
     * in `android.hardware.camera2.CameraMetadata` so logcat sweeps for
     * "LIMITED" land here.
     */
    fun describe(level: Int?): String =
        when (level) {
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
            null -> "UNKNOWN"
            else -> "UNKNOWN($level)"
        }

    private fun firstBackCameraId(manager: CameraManager): String? {
        for (id in manager.cameraIdList) {
            val c = manager.getCameraCharacteristics(id)
            if (c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK) {
                return id
            }
        }
        return manager.cameraIdList.firstOrNull()
    }
}
