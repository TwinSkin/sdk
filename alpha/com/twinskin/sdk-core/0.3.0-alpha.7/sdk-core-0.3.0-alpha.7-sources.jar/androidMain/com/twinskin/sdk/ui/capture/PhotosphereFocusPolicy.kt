package com.twinskin.sdk.ui.capture

import android.graphics.PointF
import com.twinskin.photosphere.PhotosphereState

internal enum class PhotosphereFocusMode {
    ContinuousAutoFocus,
    Locked,
}

internal enum class PhotosphereExposureMode {
    ContinuousAutoExposure,
    Locked,
}

/**
 * `pointOfInterest` is analyser-frame pixels (origin top-left), the
 * coordinate system [CameraSessionController.lockLensAndExposureForPhotosphere]
 * consumes. A `null` field means "leave alone" — partial updates are
 * intentional.
 */
internal data class PhotosphereFocusDecision(
    val focusMode: PhotosphereFocusMode?,
    val exposureMode: PhotosphereExposureMode?,
    val pointOfInterest: PointF?,
)

internal object PhotosphereFocusPolicy {

    fun decide(
        stage: PhotosphereState.Stage,
        markerPoi: PointF? = null,
        sceneCenter: PointF? = null,
    ): PhotosphereFocusDecision = when (stage) {
        is PhotosphereState.Stage.RefCapture ->
            PhotosphereFocusDecision(
                focusMode = PhotosphereFocusMode.ContinuousAutoFocus,
                exposureMode = PhotosphereExposureMode.ContinuousAutoExposure,
                pointOfInterest = markerPoi ?: sceneCenter,
            )

        is PhotosphereState.Stage.RoundWaiting,
        is PhotosphereState.Stage.Aiming,
        is PhotosphereState.Stage.OnTarget,
        is PhotosphereState.Stage.Capturing,
        is PhotosphereState.Stage.RoundComplete,
        ->
            PhotosphereFocusDecision(
                focusMode = PhotosphereFocusMode.Locked,
                exposureMode = PhotosphereExposureMode.Locked,
                pointOfInterest = null,
            )

        is PhotosphereState.Stage.Done,
        is PhotosphereState.Stage.Aborted,
        ->
            PhotosphereFocusDecision(
                focusMode = PhotosphereFocusMode.ContinuousAutoFocus,
                exposureMode = PhotosphereExposureMode.ContinuousAutoExposure,
                pointOfInterest = markerPoi ?: sceneCenter,
            )
    }

    /**
     * Edge-triggered at the ref-shutter moment — the
     * `RefCapture → RoundWaiting` transition straddles the shutter, so
     * the lock is issued by the call site, not by a stage value.
     */
    fun refShutterLockDecision(
        markerPoi: PointF?,
        sceneCenter: PointF? = null,
    ): PhotosphereFocusDecision =
        PhotosphereFocusDecision(
            focusMode = PhotosphereFocusMode.Locked,
            exposureMode = PhotosphereExposureMode.Locked,
            pointOfInterest = markerPoi ?: sceneCenter,
        )
}
