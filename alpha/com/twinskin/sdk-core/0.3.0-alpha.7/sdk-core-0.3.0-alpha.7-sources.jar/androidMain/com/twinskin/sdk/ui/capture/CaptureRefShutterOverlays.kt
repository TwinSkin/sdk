@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.capture

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.photosphere.MarkerValidator

internal enum class RefVerdictChoice { Accept, Retake }

/**
 * Modal low-light card shown after a reference capture. It appears
 * only when the reference is too dark; a well-lit reference shows no
 * overlay. The torch is on by default — the operator retakes with it
 * or turns it off to keep the current reference.
 */
@Composable
internal fun RefVerdictCard(
    luminance: MarkerValidator.RefLuminance,
    hasTorchUnit: Boolean,
    torchOn: Boolean,
    onTorchChange: (Boolean) -> Unit,
    onChoice: (RefVerdictChoice) -> Unit,
) {
    // The card is shown only for a low-light reference, so it is always
    // the torch advisory — amber, single purpose.
    val accent = Color(0xFFF59E0B)
    val body = CaptureViewCopy.lowLightBody(hasTorchUnit)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f)),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.82f)
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFF1A1A1A),
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(accent, RoundedCornerShape(percent = 50)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "!",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    CaptureViewCopy.lowLightTitle,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    body,
                    color = Color(0xFFB9B9B9),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    "Brightness ${luminance.meanLuma.toInt()} / 255",
                    color = Color(0xFF6B7280),
                    fontSize = 12.sp,
                )
                if (hasTorchUnit) {
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Torch", color = Color.White, fontSize = 14.sp)
                        Spacer(Modifier.width(12.dp))
                        Switch(checked = torchOn, onCheckedChange = onTorchChange)
                    }
                }
                Spacer(Modifier.height(20.dp))
                // Torch on → retake with the torch; torch off → keep the
                // current reference. With no torch unit, retaking would
                // not change the lighting, so only "keep" is offered.
                if (hasTorchUnit && torchOn) {
                    Button(
                        onClick = { onChoice(RefVerdictChoice.Retake) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = accent,
                            contentColor = Color.White,
                        ),
                    ) {
                        Text(CaptureViewCopy.lowLightRetakeWithTorch)
                    }
                } else {
                    Button(
                        onClick = { onChoice(RefVerdictChoice.Accept) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF3A3A3A),
                            contentColor = Color.White,
                        ),
                    ) {
                        Text(CaptureViewCopy.lowLightKeepCurrent)
                    }
                }
            }
        }
    }
}

/** Marker-missing advisory card shown after a reference capture. */
@Composable
internal fun RefMarkerWarningCard(
    warning: RefMarkerWarning,
    onRetake: () -> Unit,
) {
    val accent = Color(0xFFF59E0B)
    val body = CaptureViewCopy.markerMissingBody(warning)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f)),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.82f)
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFF1A1A1A),
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .background(accent, RoundedCornerShape(percent = 50)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        "!",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    CaptureViewCopy.markerMissingTitleFor(warning),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    body,
                    color = Color(0xFFB9B9B9),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onRetake,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = accent,
                        contentColor = Color.White,
                    ),
                ) {
                    Text(CaptureViewCopy.markerMissingRetake)
                }
            }
        }
    }
}

/** Full-screen "do not move" / "ready" message overlay during ref capture. */
@Composable
internal fun RefShutterMessageOverlay(text: String, color: Color) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center,
    ) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = color.copy(alpha = 0.92f),
        ) {
            Text(
                text = text,
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 32.dp, vertical = 20.dp),
            )
        }
    }
}
