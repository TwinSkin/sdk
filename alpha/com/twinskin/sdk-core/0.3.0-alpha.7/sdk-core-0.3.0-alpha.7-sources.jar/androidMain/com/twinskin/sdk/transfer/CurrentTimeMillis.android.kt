package com.twinskin.sdk.transfer

internal actual fun currentTimeMillis(): Long = System.currentTimeMillis()
