package com.twinskin.sdk.ui

import java.io.File

/**
 * Bundled-scene assets that drive [CaptureScreen] in synthetic-replay
 * mode. When supplied, the screen bypasses the camera and feeds the
 * dwell tracker from `<sceneDir>/trajectory.mp4`, binding the
 * reference frame from `<sceneDir>/ref.jpg`. Optional
 * `<sceneDir>/index.json` overrides the analyser intrinsics and frame
 * rate; absent values fall back to the bundled defaults baked into
 * [com.twinskin.sdk.ui.capture.RimbaudReplayFrameSource].
 *
 * Public SDK API — lets integrators exercise the full
 * capture → finalize → upload pipeline without a camera (CI smoke
 * tests, mocked QA flows, demo-mode integrations). Mirrors the iOS
 * `CaptureReplaySource` struct in `packages/sdk/sdk-ios/Sources/CaptureView.swift`.
 *
 * @property sceneId Stable identifier (only used for logging /
 *     telemetry; the SDK does not interpret it).
 * @property sceneDir Directory containing `trajectory.mp4` and
 *     `ref.jpg` (and optionally `index.json`). The integrator is
 *     responsible for staging the files there before navigating to
 *     `CaptureScreen`.
 */
public data class CaptureReplaySource(
    public val sceneId: String,
    public val sceneDir: File,
)
