package com.twinskin.sdk.ui.fallback

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.twinskin.sdk.db.DatabaseDriverFactory

// Uses the system [Vibrator] (not View.performHapticFeedback) because events
// fire from non-composable signal-drain callbacks; VIBRATE is already declared
// and a missing actuator is a silent no-op.
public actual fun performCaptureHaptic(event: CaptureHapticEvent) {
    val vibrator = resolveVibrator() ?: return
    if (!vibrator.hasVibrator()) return
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
        // Predefined effects/waveforms are API 26+; older devices fall back to a single short buzz.
        @Suppress("DEPRECATION")
        vibrator.vibrate(LEGACY_MS)
        return
    }
    when (event) {
        CaptureHapticEvent.PhotoCaptured,
        CaptureHapticEvent.SectorFilled ->
            vibrator.vibrate(VibrationEffect.createOneShot(LIGHT_MS, LIGHT_AMP))

        CaptureHapticEvent.RecordingStarted ->
            vibrator.vibrate(VibrationEffect.createOneShot(MEDIUM_MS, MEDIUM_AMP))

        CaptureHapticEvent.OrbitComplete ->
            vibrator.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0L, MEDIUM_MS, GAP_MS, LIGHT_MS), -1),
            )

        CaptureHapticEvent.TooFast ->
            vibrator.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0L, TICK_MS, GAP_MS, TICK_MS), -1),
            )

        CaptureHapticEvent.Error ->
            vibrator.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0L, TICK_MS, GAP_MS, TICK_MS, GAP_MS, TICK_MS), -1),
            )
    }
}

private fun resolveVibrator(): Vibrator? {
    val ctx = DatabaseDriverFactory.appContextOrNull() ?: return null
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
}

private const val LEGACY_MS = 20L
private const val LIGHT_MS = 12L
private const val MEDIUM_MS = 22L
private const val TICK_MS = 14L
private const val GAP_MS = 70L
private const val LIGHT_AMP = 90
private const val MEDIUM_AMP = 160
