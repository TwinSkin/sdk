package com.twinskin.sdk.ui.capture

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.photosphere.PhotosphereMath
import com.twinskin.photosphere.PhotosphereState
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * XFeat-DemoApp per-arm capture overlay
 *
 * Replaces the v6.1 single-progress-bar `CaptureProgressOverlay`. The
 * overlay reads off the upstream [PhotosphereState] (capturedArms,
 * currentRound, currentAzEstimate, currentTiltMagDeg, stage) and
 * renders the same chrome the XFeat DemoApp ships.
 */
@Composable
internal fun XFeatPhotosphereOverlay(state: PhotosphereState) {
    Box(Modifier.fillMaxSize()) {
        PhotosphereRingOverlay(
            state = state,
            modifier = Modifier.fillMaxSize().align(Alignment.Center),
        )

        PhotosphereBanner(
            state = state,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(horizontal = 16.dp)
                .padding(top = TOP_BAR_HEIGHT_DP.dp + BANNER_TOP_GAP_DP.dp)
                .height(BANNER_HEIGHT_DP.dp),
        )

        ProgressLegend(
            state = state,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(bottom = BOTTOM_CHROME_PADDING_DP.dp)
                .padding(horizontal = 16.dp),
        )
    }
}

@Composable
private fun PhotosphereBanner(
    state: PhotosphereState,
    modifier: Modifier = Modifier,
) {
    val stage = state.stage
    val bins = ringBinsCovered(state.capturedArms)
    val (title, subtitle) = when (stage) {
        is PhotosphereState.Stage.RefCapture ->
            "Initialising reference…" to
                "The reference frame anchors all 16 ring sectors."
        is PhotosphereState.Stage.RoundWaiting ->
            "$bins / $BIN_COUNT sectors captured" to
                "Aim toward the highlighted sector."
        is PhotosphereState.Stage.Aiming ->
            "$bins / $BIN_COUNT sectors captured" to
                "Aim toward the highlighted sector."
        is PhotosphereState.Stage.OnTarget ->
            "$bins / $BIN_COUNT sectors captured" to "On target — hold steady."
        is PhotosphereState.Stage.Capturing ->
            "$bins / $BIN_COUNT sectors captured" to "Hold steady — XFeat is firing."
        is PhotosphereState.Stage.RoundComplete ->
            "$bins / $BIN_COUNT sectors captured" to "Next sector…"
        is PhotosphereState.Stage.Done ->
            "All $BIN_COUNT sectors captured." to "Finalising bundle…"
        is PhotosphereState.Stage.Aborted ->
            "Session aborted." to (stage.reason.message ?: "")
    }
    val errText = state.currentError?.message
    Column(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            text = subtitle,
            color = Color.White.copy(alpha = 0.75f),
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (errText != null) {
            Text(
                text = errText,
                color = AMBER,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun PhotosphereRingOverlay(
    state: PhotosphereState,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val baseRadius = min(size.width, size.height) * RING_RADIUS_FRAC

        val binCount = IntArray(BIN_COUNT)
        for (globalIdx in state.capturedArms) {
            if (globalIdx < 0 || globalIdx >= ARM_BIN.size) continue
            binCount[ARM_BIN[globalIdx]]++
        }

        val pickerBin: Int? = activeRoundAndArm(state)?.let { (round, arm) ->
            val globalIdx = (round - 1) * ARMS_PER_ROUND + arm
            ARM_BIN.getOrNull(globalIdx)
        }
        // Amber rule: a sector only shows orange while it is still
        // gray (0 captures). If the picker is currently targeting a
        // sector that already has a capture (the operator is mid-
        // sweep across it), redirect the amber to the closest
        // remaining gray sector so the visual hint never sits on a
        // light-green or full-green slice.
        val activeBin: Int? = when {
            pickerBin == null -> null
            pickerBin in 0 until BIN_COUNT && binCount[pickerBin] == 0 -> pickerBin
            else -> nearestGrayBin(binCount, state.currentAzEstimate)
        }

        val innerR = baseRadius * RING_INNER_FRAC
        val outerNormal = baseRadius * RING_OUTER_NORMAL_FRAC
        val outerCardinal = baseRadius * RING_OUTER_CARDINAL_FRAC

        for (bin in 0 until BIN_COUNT) {
            val isCardinal = bin % BINS_PER_CARDINAL == 0
            val outer = if (isCardinal) outerCardinal else outerNormal
            val baseColor = when {
                binCount[bin] >= 2 -> GREEN
                binCount[bin] == 1 -> GREEN_LIGHT
                else -> SECTOR_EMPTY
            }
            val color = if (bin == activeBin) AMBER else baseColor
            drawRingSector(
                cx = cx, cy = cy,
                inner = innerR, outer = outer,
                startAzDeg = bin * SECTOR_SPAN_DEG - BIN_CENTER_OFFSET_DEG,
                sweepDeg = SECTOR_SPAN_DEG,
                gapDeg = SECTOR_GAP_DEG,
                color = color,
            )
        }

        for (bin in 0 until BIN_COUNT step BINS_PER_CARDINAL) {
            val az = bin * SECTOR_SPAN_DEG
            drawCardinalTiltChevron(cx, cy, outerCardinal, az)
        }

        drawCircle(
            color = Color(COLOR_REF_FILL),
            radius = baseRadius * REF_DISC_RADIUS_FRAC,
            center = Offset(cx, cy),
            style = Stroke(width = ARM_STROKE_PX),
        )

        val az = state.currentAzEstimate
        val mag = state.currentTiltMagDeg
        if (az != null && mag != null) {
            val dotRadius = (mag / TILT_MAG_REF_DEG * baseRadius)
                .coerceAtMost(baseRadius * LIVE_DOT_MAX_RADIUS_FRAC)
            val (lx, ly) = armEndpoint(cx, cy, dotRadius, az)
            val center = Offset(lx, ly)
            drawCircle(
                color = Color.Black,
                radius = LIVE_DOT_SIZE_PX + LIVE_DOT_OUTLINE_PX,
                center = center,
            )
            drawCircle(
                color = Color.White,
                radius = LIVE_DOT_SIZE_PX,
                center = center,
            )
        }
    }
}

private fun DrawScope.drawRingSector(
    cx: Float,
    cy: Float,
    inner: Float,
    outer: Float,
    startAzDeg: Float,
    sweepDeg: Float,
    gapDeg: Float,
    color: Color,
) {
    val halfGap = gapDeg / 2f
    val a0 = startAzDeg + halfGap
    val a1 = startAzDeg + sweepDeg - halfGap
    val sweep = a1 - a0
    if (sweep <= 0f) return
    val steps = (sweep / 1.5f).toInt().coerceAtLeast(4)
    val path = Path()
    fun point(r: Float, azDeg: Float): Offset {
        val rad = Math.toRadians(azDeg.toDouble())
        return Offset(cx + r * sin(rad).toFloat(), cy + r * cos(rad).toFloat())
    }
    var first = true
    for (i in 0..steps) {
        val t = i.toFloat() / steps
        val a = a0 + sweep * t
        val p = point(outer, a)
        if (first) { path.moveTo(p.x, p.y); first = false } else path.lineTo(p.x, p.y)
    }
    for (i in 0..steps) {
        val t = i.toFloat() / steps
        val a = a1 - sweep * t
        val p = point(inner, a)
        path.lineTo(p.x, p.y)
    }
    path.close()
    drawPath(path = path, color = color)
}

private fun DrawScope.drawCardinalTiltChevron(
    cx: Float,
    cy: Float,
    sectorOuter: Float,
    azDeg: Float,
) {
    val rad = Math.toRadians(azDeg.toDouble())
    val sinA = sin(rad).toFloat()
    val cosA = cos(rad).toFloat()
    val tipR = sectorOuter + CARDINAL_CHEVRON_GAP_PX + CARDINAL_CHEVRON_LEN_PX
    val baseR = sectorOuter + CARDINAL_CHEVRON_GAP_PX
    val tip = Offset(cx + tipR * sinA, cy + tipR * cosA)
    val baseCenter = Offset(cx + baseR * sinA, cy + baseR * cosA)
    val perpSin = cosA
    val perpCos = -sinA
    val left = Offset(
        baseCenter.x + CARDINAL_CHEVRON_HALF_W_PX * perpSin,
        baseCenter.y + CARDINAL_CHEVRON_HALF_W_PX * perpCos,
    )
    val right = Offset(
        baseCenter.x - CARDINAL_CHEVRON_HALF_W_PX * perpSin,
        baseCenter.y - CARDINAL_CHEVRON_HALF_W_PX * perpCos,
    )
    val path = Path().apply {
        moveTo(tip.x, tip.y)
        lineTo(left.x, left.y)
        lineTo(right.x, right.y)
        close()
    }
    drawPath(path = path, color = AMBER)
}

private fun activeRoundAndArm(state: PhotosphereState): Pair<Int, Int>? =
    when (val stage = state.stage) {
        is PhotosphereState.Stage.Aiming -> stage.round to stage.targetArm
        is PhotosphereState.Stage.OnTarget -> stage.round to stage.targetArm
        is PhotosphereState.Stage.Capturing -> stage.round to stage.targetArm
        else -> null
    }

private fun armEndpoint(
    cx: Float,
    cy: Float,
    radius: Float,
    azDeg: Float,
): Pair<Float, Float> {
    val rad = Math.toRadians(azDeg.toDouble())
    val x = cx + radius * sin(rad).toFloat()
    val y = cy + radius * cos(rad).toFloat()
    return x to y
}

@Composable
private fun ProgressLegend(
    state: PhotosphereState,
    modifier: Modifier = Modifier,
) {
    val bins = ringBinsCovered(state.capturedArms)
    val bonusExtras = (state.capturedArms.size - bins).coerceAtLeast(0)
    Column(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .padding(8.dp),
    ) {
        Text(
            text = "Sectors  $bins / $BIN_COUNT",
            color = Color.White,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
        )
        if (bonusExtras > 0) {
            Text(
                text = "Coverage  +$bonusExtras",
                color = COVERAGE_CYAN,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
            )
        }
    }
}

private const val ARMS_PER_ROUND: Int = 4

private const val SECTOR_SPAN_DEG: Float = 22.5f
private const val BINS_PER_CARDINAL: Int = 4

private const val BIN_CENTER_OFFSET_DEG: Float = SECTOR_SPAN_DEG / 2f

private val BIN_COUNT: Int = PhotosphereMath.BIN_COUNT
private val ARM_BIN: List<Int> = PhotosphereMath.BIN_OF_VIEW_INDEX

private fun ringBinsCovered(captured: Set<Int>): Int =
    PhotosphereMath.binsCovered(captured)

/** Closest 0-capture sector to [currentAzDeg] (degrees), or null when
 *  every sector already has at least one capture. */
private fun nearestGrayBin(binCount: IntArray, currentAzDeg: Float?): Int? {
    var best: Int? = null
    var bestDist = Float.MAX_VALUE
    val heading = ((currentAzDeg ?: 0f) % 360f + 360f) % 360f
    for (bin in 0 until BIN_COUNT) {
        if (binCount[bin] != 0) continue
        val center = bin * SECTOR_SPAN_DEG
        val raw = kotlin.math.abs(heading - center) % 360f
        val dist = if (raw > 180f) 360f - raw else raw
        if (dist < bestDist) {
            bestDist = dist
            best = bin
        }
    }
    return best
}

private const val TOP_BAR_HEIGHT_DP: Int = 56
private const val BANNER_TOP_GAP_DP: Int = 4
private const val BANNER_HEIGHT_DP: Int = 56
internal const val BOTTOM_CHROME_PADDING_DP: Int = 12

private const val RING_RADIUS_FRAC: Float = 0.38f
private const val RING_INNER_FRAC: Float = 0.55f
private const val RING_OUTER_NORMAL_FRAC: Float = 0.85f
private const val RING_OUTER_CARDINAL_FRAC: Float = 1.10f
private const val SECTOR_GAP_DEG: Float = 1.5f
private const val CARDINAL_CHEVRON_GAP_PX: Float = 4f
private const val CARDINAL_CHEVRON_LEN_PX: Float = 14f
private const val CARDINAL_CHEVRON_HALF_W_PX: Float = 7f

private const val REF_DISC_RADIUS_FRAC: Float = 0.2f
private const val TILT_MAG_REF_DEG: Float = 20f
private const val LIVE_DOT_MAX_RADIUS_FRAC: Float = 1.2f
private const val LIVE_DOT_SIZE_PX: Float = 11f
private const val LIVE_DOT_OUTLINE_PX: Float = 3f
private const val ARM_STROKE_PX: Float = 5f

private const val COLOR_REF_FILL: Long = 0xFF222222
private val SECTOR_EMPTY: Color = Color(0x55FFFFFF)
private val GREEN: Color = Color(0xFF2EB872)
private val GREEN_LIGHT: Color = Color(0xFFA8E6BB)
private val AMBER: Color = Color(0xFFFF9F1C)
private val COVERAGE_CYAN: Color = Color(red = 0.28f, green = 0.79f, blue = 0.89f)
