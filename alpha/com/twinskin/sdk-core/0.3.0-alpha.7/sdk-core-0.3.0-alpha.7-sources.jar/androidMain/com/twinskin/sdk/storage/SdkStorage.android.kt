package com.twinskin.sdk.storage

import android.content.Context
import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.warn
import java.io.File

/**
 * Android [SdkStorage]. Evictable purposes ([Purpose.evictable]) are rooted
 * under `cacheDir/twinskin/` so the OS can reclaim that space under storage
 * pressure — those artefacts are re-creatable on demand. Non-evictable
 * purposes are rooted under `filesDir/twinskin/`, which the OS never reclaims;
 * encrypted capture bundles live here because a bundle lost mid-upload cannot
 * be reconstructed.
 *
 * [Purpose.Databases] points at `context.getDatabasePath("dummy").parentFile`
 * — the app-private SQLite dir where both SqlDelight and PowerSync land
 * by default. Callers must filename-filter on this purpose to avoid
 * stomping unrelated DBs.
 */
internal class AndroidSdkStorage(context: Context) : SdkStorage {
    private val appContext = context.applicationContext
    private val twinskinCacheRoot: File by lazy {
        File(appContext.cacheDir, SDK_STORAGE_ROOT_DIR_NAME).apply { mkdirs() }
    }
    private val twinskinFilesRoot: File by lazy {
        File(appContext.filesDir, SDK_STORAGE_ROOT_DIR_NAME).apply { mkdirs() }
    }

    // Databases dir is owned by the SQLite/PowerSync layer — we never create it,
    // only enumerate for sweep/wipe.
    private val databasesDir: String by lazy {
        appContext.getDatabasePath("dummy").parentFile?.absolutePath
            ?: error("Android DB dir unexpectedly null — getDatabasePath returned a file with no parent")
    }

    override fun dir(purpose: Purpose): String = when (purpose) {
        Purpose.Databases -> databasesDir
        else -> subdir(purpose)
    }

    override fun sweep(
        purpose: Purpose,
        olderThanMs: Long,
        logger: SdkLogger,
        filter: (name: String) -> Boolean,
    ) {
        val cutoff = System.currentTimeMillis() - olderThanMs
        forEachEntry(purpose, logger) { entry ->
            if (filter(entry.name) && entry.lastModified() < cutoff) {
                deleteRecursively(entry, logger)
            }
        }
    }

    override fun wipe(
        purpose: Purpose,
        logger: SdkLogger,
        filter: (name: String) -> Boolean,
    ) {
        forEachEntry(purpose, logger) { entry ->
            if (filter(entry.name)) deleteRecursively(entry, logger)
        }
    }

    private fun subdir(purpose: Purpose): String {
        val root = if (purpose.evictable) twinskinCacheRoot else twinskinFilesRoot
        return File(root, purpose.subdirName).apply { mkdirs() }.absolutePath
    }

    private inline fun forEachEntry(
        purpose: Purpose,
        logger: SdkLogger,
        block: (File) -> Unit,
    ) {
        runCatching {
            val root = File(dir(purpose))
            if (!root.isDirectory) return
            root.listFiles()?.forEach(block)
        }.onFailure { logger.warn("SdkStorage: failed to enumerate ${purpose.name}", it) }
    }

    private fun deleteRecursively(entry: File, logger: SdkLogger) {
        runCatching {
            if (!entry.deleteRecursively()) {
                logger.warn("SdkStorage: deleteRecursively returned false for ${entry.name}")
            }
        }.onFailure { logger.warn("SdkStorage: failed to delete ${entry.name}", it) }
    }
}
