# `ui/capture` (Android)

The photosphere capture screen and its camera stack used to live here; they
were removed when `CaptureMode.Photosphere` was routed to the accelerometer
capture. One file remains:

- `CapturePermissions.kt` — `rememberCapturePermissionsState()`, the
  Compose-side runtime permission gate. CAMERA is blocking; on API 33+
  POST_NOTIFICATIONS is bundled into the same prompt as optional (denial only
  hides the upload progress notification). Re-checks on `ON_RESUME` so a grant
  made from system Settings is picked up without another tap.

Its only consumer is the accelerometer capture host,
`../fallback/AccelerometerCaptureScreenHost.kt`.

`shared/src/jvmTest/.../ui/fallback/CapturePermissionWiringSourceScanTest.kt`
reads `CapturePermissions.kt` by path and asserts on `Lifecycle.Event.ON_RESUME`
and the "Motion is intentionally absent" note — keep the filename and those
strings if you touch it.

The cross-platform `commonMain/.../ui/capture/` package (`i18n/`,
`CaptureViewShared.kt`) is a different directory and not covered by this note.
