@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.annotation_editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.GenericAnnotation
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.capture.WoundAnnotation
import com.twinskin.sdk.error
import com.twinskin.sdk.ui.annotation_editor.generic.GenericAnnotationEditor
import com.twinskin.sdk.view.readImageBytes
import kotlinx.coroutines.CancellationException

/**
 * Decodes the capture's 2D reference image and renders the matching editor —
 * wound or generic, seeded with [existing] or chosen from [conditionType].
 * Shared by the in-viewer overlay and the standalone [EditAnnotationScreenHost];
 * the (suspending) [onDone] owns submission. [onImageUnavailable] fires when the
 * image can't be decoded.
 */
@TwinSkinInternalApi
@Composable
public fun AnnotationEditorForCapture(
    imageLocation: String,
    existing: SdkAnnotation?,
    conditionType: ConditionType?,
    onDone: suspend (SdkAnnotation) -> Unit,
    onCancel: () -> Unit,
    onImageUnavailable: () -> Unit,
) {
    var bitmap by remember(imageLocation) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(imageLocation) {
        bitmap = try {
            readImageBytes(imageLocation).toImageBitmap()
        } catch (c: CancellationException) {
            // Cancellation is teardown, not a decode failure.
            throw c
        } catch (t: Throwable) {
            runCatching { TwinSkinSdk.requireComponent().logger }.getOrNull()
                ?.error("Annotation editor: failed to decode reference image", t)
            onImageUnavailable()
            null
        }
    }

    val image = bitmap ?: return
    when (selectAnnotationEditorKind(existing, conditionType)) {
        AnnotationEditorKind.Wound -> WoundAnnotationEditor(
            image = image,
            onDone = { onDone(it) },
            onCancel = onCancel,
            initial = existing as? WoundAnnotation ?: WoundAnnotation(regions = emptyList()),
        )
        AnnotationEditorKind.Generic -> GenericAnnotationEditor(
            image = image,
            onDone = { onDone(it) },
            onCancel = onCancel,
            initial = existing as? GenericAnnotation ?: GenericAnnotation(regions = emptyList()),
        )
    }
}
