// GENERATED CODE — DO NOT EDIT BY HAND
// Source: lib/src/sdk_apis/upload/api.dart
// Regenerate: fvm dart run tool/generate_kotlin_sdk_client.dart

package com.twinskin.sdk.sdk_client

import com.twinskin.sdk.capture.ConditionType
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonClassDiscriminator
import kotlinx.serialization.json.JsonElement

internal class SdkUploadClient(
    private val client: HttpClient,
    private val basePath: String,
) {
    /**
     * Starts a capture and returns a short-lived upload URL the SDK uses to
     * upload the capture bundle. Processing and results are delivered
     * asynchronously via the `capture.updated` webhook and the status endpoint.
     */
    suspend fun startCapture(request: StartCaptureRequest): StartCaptureResponse =
        client.post("$basePath/upload/start-capture") {
            contentType(ContentType.Application.Json)
            setBody(request)
        }.body()

    /**
     * Submits an annotation (region polygons on the reference image) for a
     * capture and starts a new measurement revision.
     * 
     * `POST /upload/submit-annotation`
     * 
     * `annotation` is discriminated by `type` (`wound` | `generic`) and must
     * match the capture's `condition_type`, else the call is rejected. Each
     * call allocates a fresh revision and supersedes any still-measuring one;
     * a `capture.updated` webhook fires when the result is ready.
     */
    suspend fun submitAnnotation(request: SubmitAnnotationRequest): SubmitAnnotationResponse =
        client.post("$basePath/upload/submit-annotation") {
            contentType(ContentType.Application.Json)
            setBody(request)
        }.body()
}

@Serializable
internal data class StartCaptureRequest(
    @SerialName("user_ref") val userRef: String,
    @SerialName("subject_ref") val subjectRef: String,
    @SerialName("condition_type") val conditionType: ConditionType,
    @SerialName("capture_id") val captureId: String? = null,
    @SerialName("capture_group") val captureGroup: String? = null,
    @SerialName("body_location") val bodyLocation: List<String>? = null,
    @SerialName("custom") val custom: Map<String, JsonElement>? = null,
    @SerialName("device_info") val deviceInfo: DeviceInfo? = null
)

@Serializable
internal data class SubmitAnnotationRequest(
    @SerialName("capture_id") val captureId: String,
    @SerialName("annotation") val annotation: SdkAnnotation
)

/**
 * Response from `startCapture`.
 * 
 * Idempotent when the client supplies its own `capture_id`: a repeat call
 * returns the capture's current status. [uploadUrl] is present only while
 * the capture is `queued`.
 */
@Serializable
internal data class StartCaptureResponse(
    /**
     * Unique capture identifier. Format: `tsc_<id>`.
     */
    @SerialName("capture_id") val captureId: String,
    /**
     * Current status of the capture.
     */
    @SerialName("status") val status: SdkCaptureStatus,
    /**
     * Short-lived upload URL for the capture bundle (HTTP PUT). Present only
     * when [status] is `queued`; null once a bundle has been received.
     */
    @SerialName("upload_url") val uploadUrl: String? = null,
    /**
     * Expiry of [uploadUrl]. Present when [uploadUrl] is.
     */
    @SerialName("upload_url_expires_at") val uploadUrlExpiresAt: String? = null
)

/**
 * Device metadata collected by the mobile SDK. All fields optional so
 * older SDK builds keep working.
 */
@Serializable
internal data class DeviceInfo(
    /**
     * `"android"` or `"ios"`.
     */
    @SerialName("os") val os: String? = null,
    /**
     * OS version, e.g. `"14.2"`.
     */
    @SerialName("os_version") val osVersion: String? = null,
    /**
     * e.g. `"Google"`, `"Apple"`, `"Samsung"`.
     */
    @SerialName("device_manufacturer") val deviceManufacturer: String? = null,
    /**
     * Platform model identifier, e.g. `"Pixel 6a"`, `"iPhone15,3"`.
     */
    @SerialName("device_model") val deviceModel: String? = null,
    /**
     * SDK version, e.g. `"1.4.2"`.
     */
    @SerialName("sdk_version") val sdkVersion: String? = null,
    /**
     * Integrator app version, e.g. `"3.7.1"`.
     */
    @SerialName("app_version") val appVersion: String? = null,
    /**
     * Integrator app bundle id / package name, e.g. `"com.acme.skinapp"`.
     */
    @SerialName("app_bundle_id") val appBundleId: String? = null,
    /**
     * BCP 47 language tag, e.g. `"en-US"`.
     */
    @SerialName("locale") val locale: String? = null
)

/**
 * Response from `submitAnnotation`.
 */
@Serializable
internal data class SubmitAnnotationResponse(
    /**
     * 1-based, monotonically increasing per capture.
     */
    @SerialName("revision") val revision: Long
)

@Serializable
@JsonClassDiscriminator("type")
public sealed class SdkAnnotation

@Serializable
@SerialName("generic")
public data class GenericAnnotation(
    @SerialName("regions") val regions: List<GenericRegion>
) : SdkAnnotation()

@Serializable
@SerialName("wound")
public data class WoundAnnotation(
    @SerialName("regions") val regions: List<WoundRegion>
) : SdkAnnotation()

@Serializable
internal enum class SdkCaptureStatus {
    @SerialName("queued") Queued,
    @SerialName("in_progress") InProgress,
    @SerialName("completed") Completed,
    @SerialName("failed") Failed;
}

/**
 * An instant in time, such as July 20, 1969, 8:18pm GMT.
 * 
 * DateTimes can represent time values that are at a distance of at most
 * 100,000,000 days from epoch (1970-01-01 UTC): -271821-04-20 to 275760-09-13.
 * 
 * Create a `DateTime` object by using one of the constructors
 * or by parsing a correctly formatted string,
 * which complies with a subset of ISO 8601.
 * **Note:** hours are specified between 0 and 23,
 * as in a 24-hour clock.
 * 
 * For example:
 * ```dart
 * final now = DateTime.now();
 * final berlinWallFell = DateTime.utc(1989, 11, 9);
 * final moonLanding = DateTime.parse('1969-07-20 20:18:04Z'); // 8:18pm
 * ```
 * 
 * A `DateTime` object is anchored either in the UTC time zone
 * or in the local time zone of the current computer
 * when the object is created.
 * 
 * Once created, neither the value nor the time zone
 * of a `DateTime` object may be changed.
 * 
 * You can use properties to get
 * the individual units of a `DateTime` object.
 * ```
 * print(berlinWallFell.year); // 1989
 * print(berlinWallFell.month); // 11
 * print(berlinWallFell.day); // 9
 * print(moonLanding.hour); // 20
 * print(moonLanding.minute); // 18
 * ```
 * For convenience and readability,
 * the `DateTime` class provides a constant for each `day` and `month`
 * name - for example, [august] and [friday].
 * You can use these constants to improve code readability:
 * ```dart
 * final berlinWallFell = DateTime.utc(1989, DateTime.november, 9);
 * print(DateTime.november); // 11
 * assert(berlinWallFell.month == DateTime.november);
 * assert(berlinWallFell.weekday == DateTime.thursday);
 * ```
 * 
 * `Day` and `month` values begin at 1, and the week starts on `Monday`.
 * That is, the constants [january] and [monday] are both 1.
 * 
 * ## Working with UTC and local time
 * 
 * A `DateTime` object is in the local time zone
 * unless explicitly created in the UTC time zone.
 * Use [isUtc] to determine whether a `DateTime` object is based in UTC.
 * 
 * ```dart
 * final dDay = DateTime.utc(1944, 6, 6);
 * print(dDay.isUtc); // true
 * 
 * final dDayLocal = DateTime(1944, 6, 6);
 * print(dDayLocal.isUtc); // false
 * ```
 * Use the methods [toLocal] and [toUtc]
 * to get the equivalent date/time value specified in the other time zone.
 * ```
 * final localDay = dDay.toLocal(); // e.g. 1944-06-06 02:00:00.000
 * print(localDay.isUtc); // false
 * 
 * final utcFromLocal = localDay.toUtc(); // 1944-06-06 00:00:00.000Z
 * print(utcFromLocal.isUtc); // true
 * ```
 * Use [timeZoneName] to get an abbreviated name of the time zone
 * for the `DateTime` object.
 * ```
 * print(dDay.timeZoneName); // UTC
 * print(localDay.timeZoneName); // e.g. EET
 * ```
 * To find the difference
 * between UTC and the time zone of a `DateTime` object
 * call [timeZoneOffset].
 * ```
 * print(dDay.timeZoneOffset); // 0:00:00.000000
 * print(localDay.timeZoneOffset); // e.g. 2:00:00.000000
 * ```
 * 
 * ## Comparing DateTime objects
 * 
 * The `DateTime` class contains methods for comparing `DateTime`s
 * chronologically, such as [isAfter], [isBefore], and [isAtSameMomentAs].
 * ```
 * print(berlinWallFell.isAfter(moonLanding)); // true
 * print(berlinWallFell.isBefore(moonLanding)); // false
 * print(dDay.isAtSameMomentAs(localDay)); // true
 * ```
 * 
 * ## Using DateTime with Duration
 * 
 * Use the [add] and [subtract] methods with a [Duration] object
 * to create a `DateTime` object based on another.
 * For example, to find the point in time that is 36 hours after now,
 * you can write:
 * ```dart
 * final now = DateTime.now();
 * final later = now.add(const Duration(hours: 36));
 * ```
 * 
 * To find out how much time is between two `DateTime` objects use
 * [difference], which returns a [Duration] object:
 * ```
 * final difference = berlinWallFell.difference(moonLanding);
 * print(difference.inDays); // 7416
 * ```
 * 
 * The difference between two dates in different time zones
 * is just the number of nanoseconds between the two points in time.
 * It doesn't take calendar days into account.
 * That means that the difference between two midnights in local time may be
 * less than 24 hours times the number of days between them,
 * if there is a daylight saving change in between.
 * If the difference above is calculated using Australian local time, the
 * difference is 7415 days and 23 hours, which is only 7415 whole days as
 * reported by `inDays`.
 * 
 * ## Other resources
 * 
 *  * See [Duration] to represent a span of time.
 *  * See [Stopwatch] to measure timespans.
 *  * The `DateTime` class does not provide internationalization.
 *  To internationalize your code, use
 *  the [intl](https://pub.dev/packages/intl) package.
 */
@Serializable
internal data class DateTime(
    /**
     * True if this [DateTime] is set to UTC time.
     * 
     * ```dart
     * final dDay = DateTime.utc(1944, 6, 6);
     * print(dDay.isUtc); // true
     * 
     * final local = DateTime(1944, 6, 6);
     * print(local.isUtc); // false
     * ```
     */
    @SerialName("isUtc") val isUtc: Boolean,
    @SerialName("hashCode") val hashCode: Long,
    @SerialName("millisecondsSinceEpoch") val millisecondsSinceEpoch: Long,
    @SerialName("microsecondsSinceEpoch") val microsecondsSinceEpoch: Long,
    @SerialName("timeZoneName") val timeZoneName: String,
    @SerialName("timeZoneOffset") val timeZoneOffset: Duration,
    @SerialName("year") val year: Long,
    @SerialName("month") val month: Long = 1,
    @SerialName("day") val day: Long = 1,
    @SerialName("hour") val hour: Long = 0,
    @SerialName("minute") val minute: Long = 0,
    @SerialName("second") val second: Long = 0,
    @SerialName("millisecond") val millisecond: Long = 0,
    @SerialName("microsecond") val microsecond: Long = 0,
    @SerialName("weekday") val weekday: Long
)

@Serializable
public data class GenericRegion(
    @SerialName("points") val points: List<Point2D>
)

@Serializable
public data class WoundRegion(
    @SerialName("contour") val contour: List<Point2D>,
    @SerialName("tissues") val tissues: List<TissueRegion>
)

/**
 * A span of time, such as 27 days, 4 hours, 12 minutes, and 3 seconds.
 * 
 * A `Duration` represents a difference from one point in time to another. The
 * duration may be "negative" if the difference is from a later time to an
 * earlier.
 * 
 * Durations are context independent. For example, a duration of 2 days is
 * always 48 hours, even when it is added to a `DateTime` just when the
 * time zone is about to make a daylight-savings switch. (See [DateTime.add]).
 * 
 * Despite the same name, a `Duration` object does not implement "Durations"
 * as specified by ISO 8601. In particular, a duration object does not keep
 * track of the individually provided members (such as "days" or "hours"), but
 * only uses these arguments to compute the length of the corresponding time
 * interval.
 * 
 * To create a new `Duration` object, use this class's single constructor
 * giving the appropriate arguments:
 * ```dart
 * const fastestMarathon = Duration(hours: 2, minutes: 3, seconds: 2);
 * ```
 * The [Duration] represents a single number of microseconds,
 * which is the sum of all the individual arguments to the constructor.
 * 
 * Properties can access that single number in different ways.
 * For example the [inMinutes] gives the number of whole minutes
 * in the total duration, which includes the minutes that were provided
 * as "hours" to the constructor, and can be larger than 59.
 * 
 * ```dart
 * const fastestMarathon = Duration(hours: 2, minutes: 0, seconds: 35);
 * print(fastestMarathon.inDays); // 0
 * print(fastestMarathon.inHours); // 2
 * print(fastestMarathon.inMinutes); // 120
 * print(fastestMarathon.inSeconds); // 7235
 * print(fastestMarathon.inMilliseconds); // 7235000
 * ```
 * The duration can be negative, in which case
 * all the properties derived from the duration are also non-positive.
 * ```dart
 * const overDayAgo = Duration(days: -1, hours: -10);
 * print(overDayAgo.inDays); // -1
 * print(overDayAgo.inHours); // -34
 * print(overDayAgo.inMinutes); // -2040
 * ```
 * Use one of the properties, such as [inDays],
 * to retrieve the integer value of the `Duration` in the specified time unit.
 * Note that the returned value is rounded down.
 * For example,
 * ```dart
 * const aLongWeekend = Duration(hours: 88);
 * print(aLongWeekend.inDays); // 3
 * ```
 * This class provides a collection of arithmetic
 * and comparison operators,
 * plus a set of constants useful for converting time units.
 * ```dart
 * const firstHalf = Duration(minutes: 45); // 00:45:00.000000
 * const secondHalf = Duration(minutes: 45); // 00:45:00.000000
 * const overTime = Duration(minutes: 30); // 00:30:00.000000
 * final maxGameTime = firstHalf + secondHalf + overTime;
 * print(maxGameTime.inMinutes); // 120
 * 
 * // The duration of the firstHalf and secondHalf is the same, returns 0.
 * var result = firstHalf.compareTo(secondHalf);
 * print(result); // 0
 * 
 * // Duration of overTime is shorter than firstHalf, returns < 0.
 * result = overTime.compareTo(firstHalf);
 * print(result); // < 0
 * 
 * // Duration of secondHalf is longer than overTime, returns > 0.
 * result = secondHalf.compareTo(overTime);
 * print(result); // > 0
 * ```
 * 
 * **See also:**
 * * [DateTime] to represent a point in time.
 * * [Stopwatch] to measure time-spans.
 */
@Serializable
internal data class Duration(
    @SerialName("inDays") val inDays: Long,
    @SerialName("inHours") val inHours: Long,
    @SerialName("inMinutes") val inMinutes: Long,
    @SerialName("inSeconds") val inSeconds: Long,
    @SerialName("inMilliseconds") val inMilliseconds: Long,
    @SerialName("inMicroseconds") val inMicroseconds: Long,
    @SerialName("hashCode") val hashCode: Long,
    @SerialName("isNegative") val isNegative: Boolean
)

@Serializable
public data class Point2D(
    @SerialName("x") val x: Double,
    @SerialName("y") val y: Double
)

@Serializable
public data class TissueRegion(
    @SerialName("tissue_type") val tissueType: String,
    @SerialName("contour") val contour: List<Point2D>
)
