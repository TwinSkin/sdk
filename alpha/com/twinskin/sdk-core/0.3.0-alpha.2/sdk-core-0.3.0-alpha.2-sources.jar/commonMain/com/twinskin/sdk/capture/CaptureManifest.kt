// GENERATED CODE — DO NOT EDIT BY HAND
// Source: lib/src/capture_processing/capture_pipeline_models.dart
// Regenerate: fvm dart run tool/generate_kotlin_sdk_client.dart

package com.twinskin.sdk.capture

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class CaptureManifest(
    @SerialName("capture_id") val captureId: String,
    @SerialName("sdk_version") val sdkVersion: String,
    @SerialName("capture_timestamp") val captureTimestamp: String,
    @SerialName("image_filename") val imageFilename: String,
    @SerialName("image_frames") val imageFrames: List<SdkFrameEntry>,
    @SerialName("capture_mode") val captureMode: String = "photosphere",
    @SerialName("video_filename") val videoFilename: String? = null,
    @SerialName("video_metadata_filename") val videoMetadataFilename: String? = null,
    @SerialName("marker_version") val markerVersion: String? = null,
    @SerialName("sidecars") val sidecars: List<String> = emptyList(),
    @SerialName("reference_luminance") val referenceLuminance: SdkReferenceLuminance? = null
) {
    init {
        if (captureMode == "accelerometer_capture") {
            require(videoFilename != null && videoMetadataFilename != null) {
                "capture_mode='accelerometer_capture' requires both " +
                    "video_filename and video_metadata_filename to be set"
            }
        } else {
            require(videoFilename == null && videoMetadataFilename == null) {
                "capture_mode='photosphere' must not set " +
                    "video_filename or video_metadata_filename"
            }
        }
    }
}

@Serializable
public data class SdkFrameEntry(
    @SerialName("filename") val filename: String
)

@Serializable
public data class SdkReferenceLuminance(
    @SerialName("mean_y") val meanY: Double,
    @SerialName("dark_share") val darkShare: Double,
    @SerialName("bright_share") val brightShare: Double,
    @SerialName("recommendation") val recommendation: String,
    @SerialName("torch") val torch: Boolean
)
