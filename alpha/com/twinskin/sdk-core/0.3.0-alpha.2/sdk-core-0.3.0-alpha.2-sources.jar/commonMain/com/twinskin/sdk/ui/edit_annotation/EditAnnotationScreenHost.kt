@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.edit_annotation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.ui.annotation_editor.AnnotationEditorForCapture
import com.twinskin.sdk.ui.theme.TwinSkinColors
import com.twinskin.sdk.ui.view_capture.subview.ViewCaptureErrorView
import com.twinskin.sdk.view.CaptureSource
import com.twinskin.sdk.view.ViewCaptureState

/**
 * Standalone annotation-editor host: opens the editor for an existing capture,
 * seeded with the latest synced annotation, submits the edited contour itself,
 * and reports the [EditAnnotationResult]. No 3D viewer around it.
 */
@TwinSkinInternalApi
@Composable
public fun EditAnnotationScreenHost(
    captureId: String,
    subjectRef: String,
    onResult: (EditAnnotationResult) -> Unit,
) {
    var retryKey by remember { mutableIntStateOf(0) }
    val source = remember(captureId, subjectRef) {
        CaptureSource.CaptureId(id = captureId, subjectRef = subjectRef)
    }
    val session = remember(source, retryKey) { TwinSkinSdk.viewCapture(source) }
    DisposableEffect(session) { onDispose { session.close() } }

    val state by session.state.collectAsState()

    when (val current = state) {
        is ViewCaptureState.Error -> Box(modifier = Modifier.fillMaxSize()) {
            // ViewCaptureErrorView owns only Retry; add a Close so a
            // non-retryable error doesn't strand the caller awaiting a result.
            ViewCaptureErrorView(
                error = current.error,
                onRetry = { retryKey++ },
            )
            IconButton(
                onClick = { onResult(EditAnnotationResult.Cancelled) },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .statusBarsPadding()
                    .padding(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = Color.White,
                )
            }
        }

        is ViewCaptureState.Ready -> {
            val image2D = current.image2D
            if (image2D == null) {
                EditAnnotationLoading(onClose = { onResult(EditAnnotationResult.Cancelled) })
            } else {
                AnnotationEditorForCapture(
                    imageLocation = image2D.location,
                    existing = current.annotation,
                    conditionType = current.conditionType,
                    onDone = { annotation ->
                        val response = TwinSkinSdk.requireComponent().serverClient
                            .submitAnnotation(
                                captureId = captureId,
                                subjectRef = subjectRef,
                                annotation = annotation,
                            )
                        onResult(EditAnnotationResult.Submitted(response.revision))
                    },
                    onCancel = { onResult(EditAnnotationResult.Cancelled) },
                    onImageUnavailable = { onResult(EditAnnotationResult.Cancelled) },
                )
            }
        }

        else -> EditAnnotationLoading(onClose = { onResult(EditAnnotationResult.Cancelled) })
    }
}

@Composable
private fun EditAnnotationLoading(onClose: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().background(TwinSkinColors.Surface),
        contentAlignment = Alignment.Center,
    ) {
        CircularProgressIndicator(color = TwinSkinColors.Cyan)
        // A Close so a hung sync isn't a dead end.
        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(8.dp),
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = TwinSkinColors.Ink,
            )
        }
    }
}
