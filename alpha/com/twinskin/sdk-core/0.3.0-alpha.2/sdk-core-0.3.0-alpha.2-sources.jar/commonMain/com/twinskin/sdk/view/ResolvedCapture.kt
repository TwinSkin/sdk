package com.twinskin.sdk.view

import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.capture.SdkMeasurement

/** A 3D asset resolved to a location the renderer can load. */
@TwinSkinInternalApi
public data class Asset3D(
    /** Filesystem path OR http(s) URL — renderer decides based on scheme. */
    val location: String,
    val format: Asset3DFormat,
    /**
     * Camera-framing hints for opening the model at the reference-photo
     * perspective and orbiting around the calibration marker. Null when the
     * capture carries no marker view (older captures, captures without a visual
     * 3D model, or URL/path resolvers) — renderers fall back to auto-framing.
     */
    val viewMetadata: Model3DViewMetadata? = null,
)

/** A 3D point in the preview GLB's published coordinate frame. */
public data class Vector3(val x: Float, val y: Float, val z: Float)

/**
 * Camera-framing metadata for the 3D viewer, expressed in the published GLB
 * frame (the reference camera sits at the origin looking down -Z).
 *
 * - [markerCenter] is the orbit pivot.
 * - [fovYDeg] is the reference camera's vertical field of view in degrees, so
 *   the model opens at the same perspective as the reference photo.
 * - [fovXDeg] is the reference camera's horizontal field of view in degrees;
 *   null on older captures, where renderers constrain only the vertical FoV.
 * - [cameraDistance] is the origin->marker distance in GLB units.
 */
public data class Model3DViewMetadata(
    val markerCenter: Vector3,
    val fovYDeg: Float,
    val fovXDeg: Float? = null,
    val cameraDistance: Float,
)

@TwinSkinInternalApi
public enum class Asset3DFormat { GLB, USDZ }

/**
 * A 2D reference image resolved to a local filesystem path. The capture's
 * annotation polygon is overlaid by the renderer on top of this image.
 */
@TwinSkinInternalApi
public data class Image2DAsset(
    /** Absolute filesystem path to a JPEG/PNG file. */
    val location: String,
)

/**
 * What a [CaptureResolver] produces. The resolver streams updates, so any
 * nullable field means "not known yet" rather than "not present".
 *
 * A typical [com.twinskin.sdk.view.resolvers.CaptureIdResolver] emission
 * carries the 3D mesh ([model]) plus the 2D reference image ([image2D]),
 * the latest [annotation] traced on top of it, and the
 * [measurement] computed from it — together they back the viewer's
 * two tabs (3D / 2D). The URL/path-based resolvers
 * ([com.twinskin.sdk.view.resolvers.HttpGlbResolver],
 * [com.twinskin.sdk.view.resolvers.LocalGlbResolver]) only ever set [model].
 */
@TwinSkinInternalApi
public data class ResolvedCapture(
    val model: Asset3D? = null,
    val image2D: Image2DAsset? = null,
    val annotation: SdkAnnotation? = null,
    val measurement: SdkMeasurement? = null,
    val metadata: Map<String, String> = emptyMap(),
    /** True iff a measure step for a newer revision is queued or in flight. */
    val isMeasurementCalculating: Boolean = false,
    /** Capture condition type; null when unknown. Drives annotation-editor selection on edit-contour. */
    val conditionType: ConditionType? = null,
)
