@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.error
import com.twinskin.sdk.ui.annotation_editor.AnnotationEditorForCapture
import com.twinskin.sdk.view.CaptureSource
import com.twinskin.sdk.view.ViewCaptureSession
import com.twinskin.sdk.view.ViewCaptureState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/**
 * Stateful wrapper: spins up a [ViewCaptureSession] for [source], collects its
 * state, and feeds the stateless [ViewCaptureScreen]. Tearing down the
 * composable closes the session.
 *
 * For a [CaptureSource.CaptureId] source, also surfaces an "Edit contour"
 * affordance on the 2D pane: tapping opens the shared [AnnotationEditorForCapture]
 * pre-populated with the current annotation; on Done the host submits via
 * [com.twinskin.sdk.sdk_client.SdkServerClient.submitAnnotation] and lets
 * PowerSync re-emit. Submit failures surface as a snackbar with Retry.
 */
@TwinSkinInternalApi
@Composable
public fun ViewCaptureScreenHost(
    source: CaptureSource,
    onClose: () -> Unit = {},
) {
    var retryKey by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf(false) }

    val session = remember(source, retryKey) { TwinSkinSdk.viewCapture(source) }
    DisposableEffect(session) { onDispose { session.close() } }

    val state by session.state.collectAsState()
    val ready = state as? ViewCaptureState.Ready
    // M15.18 — true from optimistic-apply until the server's
    // recomputed measurement arrives. ORed with `pendingSubmit`
    // below so the 2D pane keeps showing the "Calculating…"
    // placeholder for measurement values across the whole
    // submit + PowerSync-refresh window, not just the brief
    // submit-in-flight portion (which is sub-second on a healthy
    // stack and easy to miss visually).
    val isMeasurementStale by session.isMeasurementStale.collectAsState()

    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var pendingSubmit by remember { mutableStateOf<SdkAnnotation?>(null) }

    val captureIdSource = source as? CaptureSource.CaptureId
    val onEditContour: (() -> Unit)? = if (captureIdSource != null && ready?.image2D != null) {
        { editing = true }
    } else null

    Box(modifier = Modifier.fillMaxSize()) {
        ViewCaptureScreen(
            state = state,
            actions = ViewCaptureActions(
                onClose = onClose,
                onRetry = { retryKey++ },
                onEditContour = onEditContour,
                isSavingAnnotation = pendingSubmit != null || isMeasurementStale,
            ),
        )

        // Hand the edited annotation to the background submit below, so the
        // user returns to the 2D pane immediately rather than waiting on the POST.
        if (editing && captureIdSource != null && ready?.image2D != null) {
            AnnotationEditorForCapture(
                imageLocation = ready.image2D.location,
                existing = ready.annotation,
                conditionType = ready.conditionType,
                onDone = { annotation ->
                    editing = false
                    pendingSubmit = annotation
                },
                onCancel = { editing = false },
                onImageUnavailable = { editing = false },
            )
        }

        SnackbarHost(snackbar, modifier = Modifier.align(Alignment.BottomCenter))
    }

    val submit = pendingSubmit
    if (submit != null && captureIdSource != null) {
        LaunchedEffect(submit, captureIdSource.id, captureIdSource.subjectRef) {
            try {
                val component = TwinSkinSdk.requireComponent()
                component.serverClient.submitAnnotation(
                    captureId = captureIdSource.id,
                    subjectRef = captureIdSource.subjectRef,
                    annotation = submit,
                )
                // M15.11 — push the just-confirmed annotation into the
                // session's state flow so the 2D pane re-renders
                // immediately, instead of waiting for PowerSync to
                // round-trip the new value back down. Superseded by
                // the next genuine resolver emission.
                session.applyOptimisticAnnotation(submit)
                pendingSubmit = null
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                TwinSkinSdk.requireComponent().logger.error("Annotation submit failed", t)
                pendingSubmit = null
                scope.launch {
                    val res = snackbar.showSnackbar(
                        message = "Failed to save annotation",
                        actionLabel = "Retry",
                    )
                    if (res == androidx.compose.material3.SnackbarResult.ActionPerformed) {
                        pendingSubmit = submit
                    }
                }
            }
        }
    }
}
