@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class, kotlinx.cinterop.ExperimentalForeignApi::class)

package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.interop.UIKitView
import androidx.compose.ui.window.ComposeUIViewController
import com.twinskin.sdk.CaptureMode
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.TwinSkinUiKit
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.capture.SdkReferenceLuminance
import com.twinskin.sdk.capture.fallback.VideoCaptureResult
import com.twinskin.sdk.capture.fallback.createAccelerometerDriver
import com.twinskin.sdk.capture.fallback.createAccelerometerVideoRecorder
import kotlinx.cinterop.UByteVar
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.readValue
import kotlinx.cinterop.usePinned
import kotlinx.cinterop.value
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.skia.Image
import platform.AVFoundation.AVCaptureVideoPreviewLayer
import platform.AVFoundation.AVLayerVideoGravityResizeAspectFill
import platform.CoreGraphics.CGBitmapContextCreate
import platform.CoreGraphics.CGColorSpaceCreateDeviceGray
import platform.CoreGraphics.CGColorSpaceRelease
import platform.CoreGraphics.CGContextDrawImage
import platform.CoreGraphics.CGContextRelease
import platform.CoreGraphics.CGImageAlphaInfo
import platform.CoreGraphics.CGRectMake
import platform.CoreGraphics.CGRectZero
import platform.Foundation.NSBundle
import platform.Foundation.NSData
import platform.Foundation.dataWithContentsOfFile
import platform.UIKit.UIImage
import platform.UIKit.UIImagePNGRepresentation
import platform.UIKit.UIView
import platform.UIKit.UIViewController
import platform.posix.memcpy

// Cancel routing: in-screen Cancel TopBar goes through
// `session.cancel()` inline; swipe-to-dismiss bypasses the Compose
// tree (DisposableEffect.onDispose only runs controller.cancel()), so
// [onSessionStarted] hands the live session up to Swift's
// CapturePresenter.DismissBridge for the same `session.cancel()`.
@TwinSkinInternalApi
public fun AccelerometerCaptureViewController(
    metadata: SdkCaptureMetadata,
    onDone: (CaptureSession) -> Unit = {},
    onCancel: () -> Unit = {},
    onSessionStarted: (CaptureSession) -> Unit = {},
    // Swift-injected because the OpenCV ArUco detector lives in the `Photosphere`
    // SwiftPM module, reachable from Swift but not from K/N (no opencv cinterop in
    // :shared). Null leaves the controller's "detected, no version" default.
    markerProbe: ((String) -> MarkerProbeResult)? = null,
    // Swift-injected for the same reason as [markerProbe]. The Swift shell returns
    // the native verdict with a placeholder `torch` that the host overrides from
    // its bound torch control. Null leaves the manifest block null (no fabrication).
    referenceLuminanceProbe: ((String) -> com.twinskin.sdk.capture.SdkReferenceLuminance?)? = null,
    // Swift-injected `Bundle.module` path: its SPM resource bundle isn't
    // enumerated by `NSBundle.allBundles`, so the scan below can't reach it.
    resourceBundlePath: String? = null,
): UIViewController = ComposeUIViewController {
    // Raise the SDK capture-orientation latch while this VC is mounted so a host
    // that forwards `TwinSkin.uiKit.preferredOrientationMask` from its AppDelegate
    // keeps the device upright. The presented VC's own
    // `supportedInterfaceOrientations` override is the fallback for hosts that did
    // not wire the AppDelegate forwarder.
    DisposableEffect(Unit) {
        TwinSkinUiKit.enterCaptureOrientationLock()
        onDispose { TwinSkinUiKit.exitCaptureOrientationLock() }
    }
    val scope = rememberCoroutineScope()
    val session = remember(metadata) {
        TwinSkinSdk.startCapture(metadata, CaptureMode.AccelerometerCapture)
            .also(onSessionStarted)
    }
    // Concrete iOS type so the preview layer can attach to the SAME
    // AVCaptureSession the recorder owns — without a preview layer on
    // a running session, didFinishRecordingTo never fires (#538).
    val recorder = remember { createAccelerometerVideoRecorder() }
    val torchControl = remember(recorder) { AVCaptureDeviceTorchControl() }
    val controller = remember(session, recorder) {
        AccelerometerCaptureController(
            scope = scope,
            recorder = recorder,
            driver = createAccelerometerDriver(),
            takeStillPhoto = {
                recorder.takeStillPhoto(
                    "${session.workingDir.trimEnd('/')}/photo.jpg"
                )
            },
            videoOutputPath = {
                "${session.workingDir.trimEnd('/')}/video.mov"
            },
            onResult = { result -> deliverResult(session, result, onDone) },
            // Overrides the probe's placeholder `torch` with the bound control's
            // live state. Off the UI thread so the OpenCV pass doesn't block it.
            lowLightProbe = { stillPath ->
                withContext(Dispatchers.Default) {
                    val lowLight = stillReadsLowLight(stillPath)
                    val luminance = referenceLuminanceProbe?.invoke(stillPath)
                        ?.copy(torch = torchControl.isTorchEnabled())
                    LowLightProbeResult(lowLight = lowLight, referenceLuminance = luminance)
                }
            },
            // Off the UI thread so the OpenCV pass doesn't block it.
            markerProbe = markerProbe?.let { probe ->
                { stillPath -> withContext(Dispatchers.Default) { probe(stillPath) } }
            } ?: { MarkerProbeResult.Detected },
        )
    }
    val preferences = remember { defaultSdkUserPreferences() }
    LaunchedEffect(controller) {
        controller.markCameraReady()
        torchControl.bind(recorder.videoDevice)
    }
    val coachImages = remember { loadCoachImages(resourceBundlePath) }
    AccelerometerCaptureScreen(
        controller = controller,
        onCancel = {
            scope.launch {
                try { session.cancel() } finally { onCancel() }
            }
        },
        torchControl = torchControl,
        userPreferences = preferences,
        cameraPreview = {
            UIKitView(
                factory = {
                    val view = PreviewContainerView()
                    val layer = AVCaptureVideoPreviewLayer(session = recorder.session)
                    layer.videoGravity = AVLayerVideoGravityResizeAspectFill
                    view.previewLayer = layer
                    view.layer.addSublayer(layer)
                    view
                },
                modifier = Modifier.fillMaxSize(),
            )
        },
        coachImages = coachImages,
        demoSession = session,
        onDemoSubmitted = { onDone(session) },
    )
}

/**
 * Host-supplied coach imagery, shipped as SPM resources in
 * `sdk-ios/Sources/Resources` so partner apps get it for free. Both wound coach
 * slots use the same illustration; the marker-not-detected card uses the distinct
 * `calibration_marker.png`. A miss leaves the slot null (card shows its white box).
 */
private fun loadCoachImages(bundlePath: String?): CaptureCoachImages {
    val wound = loadBundledPainter(COACH_WOUND_NAME, COACH_WOUND_EXT, bundlePath)
    val marker = loadBundledPainter(COACH_MARKER_NAME, COACH_MARKER_EXT, bundlePath)
    return CaptureCoachImages(woundLive = wound, woundMarker = wound, markerReference = marker)
}

private fun loadBundledPainter(name: String, ext: String, bundlePath: String?): Painter? {
    val path = resolveBundledResourcePath(name, ext, bundlePath) ?: return null
    val bitmap = decodeImageBitmap(path) ?: return null
    return BitmapPainter(bitmap)
}

private fun resolveBundledResourcePath(
    name: String,
    ext: String,
    preferredBundlePath: String?,
): String? {
    val candidates = buildList {
        preferredBundlePath?.let { NSBundle.bundleWithPath(it) }?.let(::add)
        add(NSBundle.mainBundle)
        addAll(NSBundle.allBundles.filterIsInstance<NSBundle>())
        addAll(NSBundle.allFrameworks.filterIsInstance<NSBundle>())
    }
    for (bundle in candidates) {
        val path = bundle.pathForResource(name, ext)
        if (path != null) return path
    }
    return null
}

private fun decodeImageBitmap(path: String): ImageBitmap? {
    // UIImage honours the asset's EXIF orientation on decode; PNG round-trip
    // then hands orientation-correct bytes to Skia (which would otherwise apply
    // EXIF itself). Both paths land upright, so a single decode route is fine.
    val image = try {
        UIImage(contentsOfFile = path)
    } catch (_: Throwable) {
        null
    } ?: return null
    val data: NSData = UIImagePNGRepresentation(image)
        ?: NSData.dataWithContentsOfFile(path)
        ?: return null
    val len = data.length.toInt()
    if (len == 0) return null
    val bytes = ByteArray(len).also { out ->
        out.usePinned { pinned -> memcpy(pinned.addressOf(0), data.bytes, data.length) }
    }
    return try {
        Image.makeFromEncoded(bytes).toComposeImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

private const val COACH_WOUND_NAME = "wound_b_2"
private const val COACH_WOUND_EXT = "jpg"
private const val COACH_MARKER_NAME = "calibration_marker"
private const val COACH_MARKER_EXT = "png"

// Preview layer needs explicit frame propagation, else renders at
// (0,0,0,0) → black screen with the session still running.
private class PreviewContainerView : UIView(frame = CGRectZero.readValue()) {
    var previewLayer: AVCaptureVideoPreviewLayer? = null

    override fun layoutSubviews() {
        super.layoutSubviews()
        previewLayer?.setFrame(bounds)
    }
}

private suspend fun deliverResult(
    session: CaptureSession,
    result: VideoCaptureResult,
    onDone: (CaptureSession) -> Unit,
) {
    session.submit(result)
    onDone(session)
}

/**
 * Downscales the still to a single pixel via a grayscale `CGBitmapContext` — the
 * resample averages scene luma in one step — and maps it through [LowLightProbe].
 * Any failure reads as "not low-light" so a probe error never traps the operator.
 * Presentation-only; nothing here touches the recorded bundle.
 */
private fun stillReadsLowLight(stillPath: String): Boolean {
    // The binding declares UIImage(contentsOfFile:) non-null, but it returns
    // nil at runtime for a missing / corrupt file — guard via the catch.
    val cg = try {
        UIImage(contentsOfFile = stillPath).CGImage
    } catch (_: Throwable) {
        null
    } ?: return false
    val colorSpace = CGColorSpaceCreateDeviceGray() ?: return false
    return try {
        memScoped {
            val pixel = alloc<UByteVar>()
            pixel.value = 0u
            val ctx = CGBitmapContextCreate(
                data = pixel.ptr,
                width = 1u,
                height = 1u,
                bitsPerComponent = 8u,
                bytesPerRow = 1u,
                space = colorSpace,
                bitmapInfo = CGImageAlphaInfo.kCGImageAlphaNone.value,
            ) ?: return@memScoped false
            // The context retains the memScoped pixel buffer, so release it before
            // the scope frees that buffer — else one CGContext leaks per photo/retake.
            try {
                CGContextDrawImage(ctx, CGRectMake(0.0, 0.0, 1.0, 1.0), cg)
                LowLightProbe.isLowLight(pixel.value.toDouble())
            } finally {
                CGContextRelease(ctx)
            }
        }
    } finally {
        CGColorSpaceRelease(colorSpace)
    }
}
