package com.twinskin.sdk.capture

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.db.TransferTask
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.storage.SdkStorage
import com.twinskin.sdk.transfer.TransferManager
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.TransferType
import com.twinskin.sdk.warn
import kotlinx.coroutines.flow.collect

/**
 * Delete the [Purpose.EncryptedBundles] files whose upload reached COMPLETED or
 * CANCELLED. Both are final for a bundle: only a FAILED task can be retried.
 *
 * A file is deleted on the evidence of its row, never on the absence of one.
 * [CaptureApi] creates the bundle, encrypts into it for seconds, and only then
 * inserts the row; a list that names no owner for a file proves nothing about it.
 * Row-less leftovers are [sweepLeftoverBundles]'s job.
 */
internal fun pruneBundles(
    storage: SdkStorage,
    tasks: List<TransferTask>,
    logger: SdkLogger,
) {
    val finished = tasks.bundleNames(TransferStatus.COMPLETED, TransferStatus.CANCELLED)
    if (finished.isEmpty()) return
    storage.wipe(Purpose.EncryptedBundles, logger) { name -> name in finished }
}

/**
 * Delete every [Purpose.EncryptedBundles] file no capture can still need: what a
 * crash left half-written, and bundles whose row is gone.
 *
 * Only sound while nothing can be writing a bundle, so `TwinSkinSdk.initialize`
 * calls it before it installs the component that starts captures.
 *
 * [unqueuedCapturePaths] are the bundles of captures that died between
 * `SdkCaptureStore.insert` and `TransferManager.upload`; [CaptureApi.recover]
 * re-enqueues them from that same file. Bundles are matched by file name: those
 * paths are stored absolute, and iOS moves the app container between installs.
 */
internal fun sweepLeftoverBundles(
    storage: SdkStorage,
    tasks: List<TransferTask>,
    unqueuedCapturePaths: List<String>,
    logger: SdkLogger,
) {
    val needed = tasks.bundleNames(
        TransferStatus.PENDING,
        TransferStatus.ACTIVE,
        TransferStatus.FAILED,
    ) + unqueuedCapturePaths.map { it.fileName() }
    storage.wipe(Purpose.EncryptedBundles, logger) { name -> name !in needed }
}

/**
 * [sweepLeftoverBundles] against the database as it stands. Never throws: a
 * cleanup must not break `initialize`.
 */
internal fun sweepLeftoverBundles(
    storage: SdkStorage,
    database: TwinSkinDatabase,
    logger: SdkLogger,
) {
    runCatching {
        sweepLeftoverBundles(
            storage = storage,
            tasks = database.transferTaskQueries.selectAll().executeAsList(),
            unqueuedCapturePaths = database.sdkCaptureUploadQueries.selectOrphans()
                .executeAsList()
                .map { it.encryptedPath },
            logger = logger,
        )
    }.onFailure { logger.warn("SdkStorage: leftover bundle sweep failed", it) }
}

/**
 * Re-run [pruneBundles] on every change to the task table, so a bundle is
 * reclaimed as soon as its upload ends — including uploads a background worker
 * finished while the app was dead, which show up in the first database read.
 *
 * Suspends forever; call from a long-lived coroutine.
 */
internal suspend fun observeAndPruneBundles(
    storage: SdkStorage,
    transferManager: TransferManager,
    logger: SdkLogger,
) {
    transferManager.observeAllTasks().collect { tasks ->
        pruneBundles(storage, tasks, logger)
    }
}

private fun List<TransferTask>.bundleNames(vararg statuses: TransferStatus): Set<String> {
    val names = statuses.map { it.name }
    return asSequence()
        .filter { it.type == TransferType.UPLOAD.name && it.status in names }
        .map { it.localPath.fileName() }
        .toSet()
}

private fun String.fileName(): String = substringAfterLast('/')
