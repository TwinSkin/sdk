// GENERATED CODE — DO NOT EDIT BY HAND
// Source: lib/src/sdk_apis/upload/api.dart
// Regenerate: fvm dart run tool/generate_kotlin_sdk_client.dart

package com.twinskin.sdk.sdk_client

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonClassDiscriminator
import kotlinx.serialization.json.JsonElement

internal class SdkUploadClient(
    private val client: HttpClient,
    private val basePath: String,
) {
    /**
     * Starts a capture and returns a short-lived upload URL the SDK uses to
     * upload the capture bundle. Processing and results are delivered
     * asynchronously via the `capture.updated` webhook and the status endpoint.
     */
    suspend fun startCapture(request: StartCaptureRequest): StartCaptureResponse =
        client.post("$basePath/upload/start-capture") {
            contentType(ContentType.Application.Json)
            setBody(request)
        }.body()

    /**
     * Submits an annotation (region polygons on the reference image) for a
     * capture and starts a new measurement revision.
     * 
     * `POST /upload/submit-annotation`
     * 
     * `annotation` is discriminated by `type` (`wound` | `generic`) and must
     * match the capture's `condition_type`, else the call is rejected. Each
     * call allocates a fresh revision and supersedes any still-measuring one;
     * a `capture.updated` webhook fires when the result is ready.
     */
    suspend fun submitAnnotation(request: SubmitAnnotationRequest): SubmitAnnotationResponse =
        client.post("$basePath/upload/submit-annotation") {
            contentType(ContentType.Application.Json)
            setBody(request)
        }.body()
}

@Serializable
internal data class StartCaptureRequest(
    @SerialName("user_ref") val userRef: String,
    @SerialName("subject_ref") val subjectRef: String,
    @SerialName("condition_type") val conditionType: String,
    @SerialName("capture_id") val captureId: String? = null,
    @SerialName("capture_group") val captureGroup: String? = null,
    @SerialName("body_location") val bodyLocation: List<String>? = null,
    @SerialName("custom") val custom: Map<String, JsonElement>? = null,
    @SerialName("device_info") val deviceInfo: DeviceInfo? = null
)

@Serializable
internal data class SubmitAnnotationRequest(
    @SerialName("capture_id") val captureId: String,
    @SerialName("annotation") val annotation: SdkAnnotation
)

/**
 * Response from `startCapture`.
 * 
 * Idempotent when the client supplies its own `capture_id`: a repeat call
 * returns the capture's current status. [uploadUrl] is present only while
 * the capture is `queued`.
 */
@Serializable
internal data class StartCaptureResponse(
    /**
     * Unique capture identifier. Format: `tsc_<id>`.
     */
    @SerialName("capture_id") val captureId: String,
    /**
     * Current status of the capture.
     */
    @SerialName("status") val status: SdkCaptureStatus,
    /**
     * Short-lived upload URL for the capture bundle (HTTP PUT). Present only
     * when [status] is `queued`; null once a bundle has been received.
     */
    @SerialName("upload_url") val uploadUrl: String? = null,
    /**
     * Expiry of [uploadUrl]. Present when [uploadUrl] is.
     */
    @SerialName("upload_url_expires_at") val uploadUrlExpiresAt: String? = null
)

/**
 * Device metadata collected by the mobile SDK. All fields optional so
 * older SDK builds keep working.
 */
@Serializable
internal data class DeviceInfo(
    /**
     * `"android"` or `"ios"`.
     */
    @SerialName("os") val os: String? = null,
    /**
     * OS version, e.g. `"14.2"`.
     */
    @SerialName("os_version") val osVersion: String? = null,
    /**
     * e.g. `"Google"`, `"Apple"`, `"Samsung"`.
     */
    @SerialName("device_manufacturer") val deviceManufacturer: String? = null,
    /**
     * Platform model identifier, e.g. `"Pixel 6a"`, `"iPhone15,3"`.
     */
    @SerialName("device_model") val deviceModel: String? = null,
    /**
     * SDK version, e.g. `"1.4.2"`.
     */
    @SerialName("sdk_version") val sdkVersion: String? = null,
    /**
     * Integrator app version, e.g. `"3.7.1"`.
     */
    @SerialName("app_version") val appVersion: String? = null,
    /**
     * Integrator app bundle id / package name, e.g. `"com.acme.skinapp"`.
     */
    @SerialName("app_bundle_id") val appBundleId: String? = null,
    /**
     * BCP 47 language tag, e.g. `"en-US"`.
     */
    @SerialName("locale") val locale: String? = null
)

/**
 * Response from `submitAnnotation`.
 */
@Serializable
internal data class SubmitAnnotationResponse(
    /**
     * 1-based, monotonically increasing per capture.
     */
    @SerialName("revision") val revision: Long
)

@Serializable
@JsonClassDiscriminator("type")
public sealed class SdkAnnotation

@Serializable
@SerialName("generic")
public data class GenericAnnotation(
    @SerialName("regions") val regions: List<GenericRegion>
) : SdkAnnotation()

@Serializable
@SerialName("wound")
public data class WoundAnnotation(
    @SerialName("regions") val regions: List<WoundRegion>
) : SdkAnnotation()

@Serializable
internal enum class SdkCaptureStatus {
    @SerialName("queued") Queued,
    @SerialName("in_progress") InProgress,
    @SerialName("completed") Completed,
    @SerialName("failed") Failed;
}

@Serializable
public data class GenericRegion(
    @SerialName("points") val points: List<Point2D>
)

@Serializable
public data class WoundRegion(
    @SerialName("contour") val contour: List<Point2D>,
    @SerialName("tissues") val tissues: List<TissueRegion>
)

@Serializable
public data class Point2D(
    @SerialName("x") val x: Double,
    @SerialName("y") val y: Double
)

@Serializable
public data class TissueRegion(
    @SerialName("tissue_type") val tissueType: String,
    @SerialName("contour") val contour: List<Point2D>
)
