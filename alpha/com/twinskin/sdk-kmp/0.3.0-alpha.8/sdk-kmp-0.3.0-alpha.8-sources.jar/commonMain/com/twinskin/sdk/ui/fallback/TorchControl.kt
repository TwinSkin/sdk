package com.twinskin.sdk.ui.fallback

public enum class FlashMode { Off, Auto, On }

// The FAB toggles Off ↔ On only; the luminosity check already drives the
// auto-torch decision, so a manual Auto option only confused operators.
// `FlashMode.Auto` stays a member because the per-platform actuals still map it,
// but it never enters the user-facing cycle.
public val FLASH_MODE_CYCLE: List<FlashMode> = listOf(FlashMode.Off, FlashMode.On)

public fun nextFlashMode(current: FlashMode): FlashMode {
    val idx = FLASH_MODE_CYCLE.indexOf(current)
    return FLASH_MODE_CYCLE[(idx + 1) % FLASH_MODE_CYCLE.size]
}

// applyFlashMode is idempotent + cheap; UI may call it on every
// shutter-state change. No actual implementation requests the
// microphone permission (AC-#525-5 regression guard).
public interface TorchControl {
    public fun isAvailable(): Boolean
    public fun applyFlashMode(mode: FlashMode)

    public fun isTorchEnabled(): Boolean
}

public class NoopTorchControl(
    private val available: Boolean = true,
) : TorchControl {
    private var lastApplied: FlashMode? = null
    public val applied: List<FlashMode> get() = appliedHistory.toList()
    private val appliedHistory = mutableListOf<FlashMode>()
    override fun isAvailable(): Boolean = available
    override fun applyFlashMode(mode: FlashMode) {
        lastApplied = mode
        appliedHistory.add(mode)
    }
    override fun isTorchEnabled(): Boolean = lastApplied == FlashMode.On
    public fun lastFlashMode(): FlashMode? = lastApplied
}
