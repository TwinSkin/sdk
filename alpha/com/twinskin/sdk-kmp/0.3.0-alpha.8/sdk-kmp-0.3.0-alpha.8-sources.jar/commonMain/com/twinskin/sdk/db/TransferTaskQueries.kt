package com.twinskin.sdk.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class TransferTaskQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> selectById(id: String, mapper: (
    id: String,
    url: String,
    localPath: String,
    type: String,
    status: String,
    progress: Long,
    errorMessage: String?,
    unzip: Long,
    headers: String?,
    createdAt: Long,
    updatedAt: Long,
    presignedUrl: String?,
    presignedUrlExpiresAt: Long?,
  ) -> T): Query<T> = SelectByIdQuery(id) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4)!!,
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getLong(7)!!,
      cursor.getString(8),
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getString(11),
      cursor.getLong(12)
    )
  }

  public fun selectById(id: String): Query<TransferTask> = selectById(id, ::TransferTask)

  public fun <T : Any> selectActiveUploadByUrl(url: String, mapper: (
    id: String,
    url: String,
    localPath: String,
    type: String,
    status: String,
    progress: Long,
    errorMessage: String?,
    unzip: Long,
    headers: String?,
    createdAt: Long,
    updatedAt: Long,
    presignedUrl: String?,
    presignedUrlExpiresAt: Long?,
  ) -> T): Query<T> = SelectActiveUploadByUrlQuery(url) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4)!!,
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getLong(7)!!,
      cursor.getString(8),
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getString(11),
      cursor.getLong(12)
    )
  }

  public fun selectActiveUploadByUrl(url: String): Query<TransferTask> = selectActiveUploadByUrl(url, ::TransferTask)

  public fun <T : Any> selectAll(mapper: (
    id: String,
    url: String,
    localPath: String,
    type: String,
    status: String,
    progress: Long,
    errorMessage: String?,
    unzip: Long,
    headers: String?,
    createdAt: Long,
    updatedAt: Long,
    presignedUrl: String?,
    presignedUrlExpiresAt: Long?,
  ) -> T): Query<T> = Query(-2_056_994_981, arrayOf("TransferTask"), driver, "TransferTask.sq", "selectAll", "SELECT TransferTask.id, TransferTask.url, TransferTask.localPath, TransferTask.type, TransferTask.status, TransferTask.progress, TransferTask.errorMessage, TransferTask.unzip, TransferTask.headers, TransferTask.createdAt, TransferTask.updatedAt, TransferTask.presignedUrl, TransferTask.presignedUrlExpiresAt FROM TransferTask ORDER BY createdAt DESC") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4)!!,
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getLong(7)!!,
      cursor.getString(8),
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getString(11),
      cursor.getLong(12)
    )
  }

  public fun selectAll(): Query<TransferTask> = selectAll(::TransferTask)

  public fun <T : Any> selectByStatus(status: String, mapper: (
    id: String,
    url: String,
    localPath: String,
    type: String,
    status: String,
    progress: Long,
    errorMessage: String?,
    unzip: Long,
    headers: String?,
    createdAt: Long,
    updatedAt: Long,
    presignedUrl: String?,
    presignedUrlExpiresAt: Long?,
  ) -> T): Query<T> = SelectByStatusQuery(status) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4)!!,
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getLong(7)!!,
      cursor.getString(8),
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getString(11),
      cursor.getLong(12)
    )
  }

  public fun selectByStatus(status: String): Query<TransferTask> = selectByStatus(status, ::TransferTask)

  public fun <T : Any> selectStaleUploads(mapper: (
    id: String,
    url: String,
    localPath: String,
    type: String,
    status: String,
    progress: Long,
    errorMessage: String?,
    unzip: Long,
    headers: String?,
    createdAt: Long,
    updatedAt: Long,
    presignedUrl: String?,
    presignedUrlExpiresAt: Long?,
  ) -> T): Query<T> = Query(2_105_836_607, arrayOf("TransferTask"), driver, "TransferTask.sq", "selectStaleUploads", "SELECT TransferTask.id, TransferTask.url, TransferTask.localPath, TransferTask.type, TransferTask.status, TransferTask.progress, TransferTask.errorMessage, TransferTask.unzip, TransferTask.headers, TransferTask.createdAt, TransferTask.updatedAt, TransferTask.presignedUrl, TransferTask.presignedUrlExpiresAt FROM TransferTask WHERE type = 'UPLOAD' AND status IN ('PENDING', 'ACTIVE')") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4)!!,
      cursor.getLong(5)!!,
      cursor.getString(6),
      cursor.getLong(7)!!,
      cursor.getString(8),
      cursor.getLong(9)!!,
      cursor.getLong(10)!!,
      cursor.getString(11),
      cursor.getLong(12)
    )
  }

  public fun selectStaleUploads(): Query<TransferTask> = selectStaleUploads(::TransferTask)

  /**
   * @return The number of rows updated.
   */
  public fun insert(
    id: String,
    url: String,
    localPath: String,
    type: String,
    status: String,
    progress: Long,
    errorMessage: String?,
    unzip: Long,
    headers: String?,
    createdAt: Long,
    updatedAt: Long,
  ): QueryResult<Long> {
    val result = driver.execute(-1_791_480_285, """
        |INSERT INTO TransferTask (id, url, localPath, type, status, progress, errorMessage, unzip, headers, createdAt, updatedAt)
        |VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 11) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
          bindString(parameterIndex++, url)
          bindString(parameterIndex++, localPath)
          bindString(parameterIndex++, type)
          bindString(parameterIndex++, status)
          bindLong(parameterIndex++, progress)
          bindString(parameterIndex++, errorMessage)
          bindLong(parameterIndex++, unzip)
          bindString(parameterIndex++, headers)
          bindLong(parameterIndex++, createdAt)
          bindLong(parameterIndex++, updatedAt)
        }
    notifyQueries(-1_791_480_285) { emit ->
      emit("TransferTask")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateStatus(
    status: String,
    updatedAt: Long,
    id: String,
  ): QueryResult<Long> {
    val result = driver.execute(-1_802_686_971, """UPDATE TransferTask SET status = ?, updatedAt = ? WHERE id = ?""", 3) {
          var parameterIndex = 0
          bindString(parameterIndex++, status)
          bindLong(parameterIndex++, updatedAt)
          bindString(parameterIndex++, id)
        }
    notifyQueries(-1_802_686_971) { emit ->
      emit("TransferTask")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateProgress(
    progress: Long,
    updatedAt: Long,
    id: String,
  ): QueryResult<Long> {
    val result = driver.execute(464_840_576, """UPDATE TransferTask SET progress = ?, updatedAt = ? WHERE id = ?""", 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, progress)
          bindLong(parameterIndex++, updatedAt)
          bindString(parameterIndex++, id)
        }
    notifyQueries(464_840_576) { emit ->
      emit("TransferTask")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateStatusAndError(
    status: String,
    errorMessage: String?,
    updatedAt: Long,
    id: String,
  ): QueryResult<Long> {
    val result = driver.execute(-1_298_812_010, """UPDATE TransferTask SET status = ?, errorMessage = ?, updatedAt = ? WHERE id = ?""", 4) {
          var parameterIndex = 0
          bindString(parameterIndex++, status)
          bindString(parameterIndex++, errorMessage)
          bindLong(parameterIndex++, updatedAt)
          bindString(parameterIndex++, id)
        }
    notifyQueries(-1_298_812_010) { emit ->
      emit("TransferTask")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateError(
    errorMessage: String?,
    updatedAt: Long,
    id: String,
  ): QueryResult<Long> {
    val result = driver.execute(-1_872_239_211, """UPDATE TransferTask SET errorMessage = ?, updatedAt = ? WHERE id = ?""", 3) {
          var parameterIndex = 0
          bindString(parameterIndex++, errorMessage)
          bindLong(parameterIndex++, updatedAt)
          bindString(parameterIndex++, id)
        }
    notifyQueries(-1_872_239_211) { emit ->
      emit("TransferTask")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updatePresignedUrl(
    presignedUrl: String?,
    presignedUrlExpiresAt: Long?,
    updatedAt: Long,
    id: String,
  ): QueryResult<Long> {
    val result = driver.execute(34_541_891, """UPDATE TransferTask SET presignedUrl = ?, presignedUrlExpiresAt = ?, updatedAt = ? WHERE id = ?""", 4) {
          var parameterIndex = 0
          bindString(parameterIndex++, presignedUrl)
          bindLong(parameterIndex++, presignedUrlExpiresAt)
          bindLong(parameterIndex++, updatedAt)
          bindString(parameterIndex++, id)
        }
    notifyQueries(34_541_891) { emit ->
      emit("TransferTask")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun clearPresignedUrl(updatedAt: Long, id: String): QueryResult<Long> {
    val result = driver.execute(842_463_923, """UPDATE TransferTask SET presignedUrl = NULL, presignedUrlExpiresAt = NULL, updatedAt = ? WHERE id = ?""", 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, updatedAt)
          bindString(parameterIndex++, id)
        }
    notifyQueries(842_463_923) { emit ->
      emit("TransferTask")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun resetForRetry(updatedAt: Long, id: String): QueryResult<Long> {
    val result = driver.execute(-1_742_747_868, """UPDATE TransferTask SET status = 'PENDING', progress = 0, errorMessage = NULL, updatedAt = ? WHERE id = ?""", 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, updatedAt)
          bindString(parameterIndex++, id)
        }
    notifyQueries(-1_742_747_868) { emit ->
      emit("TransferTask")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteById(id: String): QueryResult<Long> {
    val result = driver.execute(-216_715_641, """DELETE FROM TransferTask WHERE id = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
        }
    notifyQueries(-216_715_641) { emit ->
      emit("TransferTask")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteByStatus(status: String): QueryResult<Long> {
    val result = driver.execute(39_607_134, """DELETE FROM TransferTask WHERE status = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, status)
        }
    notifyQueries(39_607_134) { emit ->
      emit("TransferTask")
    }
    return result
  }

  private inner class SelectByIdQuery<out T : Any>(
    public val id: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("TransferTask", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("TransferTask", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(657_706_328, """SELECT TransferTask.id, TransferTask.url, TransferTask.localPath, TransferTask.type, TransferTask.status, TransferTask.progress, TransferTask.errorMessage, TransferTask.unzip, TransferTask.headers, TransferTask.createdAt, TransferTask.updatedAt, TransferTask.presignedUrl, TransferTask.presignedUrlExpiresAt FROM TransferTask WHERE id = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, id)
    }

    override fun toString(): String = "TransferTask.sq:selectById"
  }

  private inner class SelectActiveUploadByUrlQuery<out T : Any>(
    public val url: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("TransferTask", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("TransferTask", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(186_927_467, """
    |SELECT TransferTask.id, TransferTask.url, TransferTask.localPath, TransferTask.type, TransferTask.status, TransferTask.progress, TransferTask.errorMessage, TransferTask.unzip, TransferTask.headers, TransferTask.createdAt, TransferTask.updatedAt, TransferTask.presignedUrl, TransferTask.presignedUrlExpiresAt FROM TransferTask
    |WHERE type = 'UPLOAD' AND url = ? AND status IN ('PENDING', 'ACTIVE', 'UNZIPPING')
    |LIMIT 1
    """.trimMargin(), mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, url)
    }

    override fun toString(): String = "TransferTask.sq:selectActiveUploadByUrl"
  }

  private inner class SelectByStatusQuery<out T : Any>(
    public val status: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("TransferTask", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("TransferTask", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_250_088_529, """SELECT TransferTask.id, TransferTask.url, TransferTask.localPath, TransferTask.type, TransferTask.status, TransferTask.progress, TransferTask.errorMessage, TransferTask.unzip, TransferTask.headers, TransferTask.createdAt, TransferTask.updatedAt, TransferTask.presignedUrl, TransferTask.presignedUrlExpiresAt FROM TransferTask WHERE status = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, status)
    }

    override fun toString(): String = "TransferTask.sq:selectByStatus"
  }
}
