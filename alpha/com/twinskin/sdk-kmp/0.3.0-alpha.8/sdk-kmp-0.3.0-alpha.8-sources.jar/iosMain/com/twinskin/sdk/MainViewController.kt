@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk

import androidx.compose.ui.window.ComposeUIViewController
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.ui.edit_annotation.EditAnnotationResult
import com.twinskin.sdk.ui.edit_annotation.EditAnnotationScreenHost
import com.twinskin.sdk.ui.capture.i18n.ProvideSdkCaptureStrings
import com.twinskin.sdk.ui.post_submit.PostSubmitFlow
import com.twinskin.sdk.ui.view_capture.ViewCaptureScreenHost
import com.twinskin.sdk.view.CaptureSource
import platform.UIKit.UIViewController


public fun ViewCaptureViewController(
    source: CaptureSource,
    onClose: () -> Unit = {},
): UIViewController = ComposeUIViewController {
    ViewCaptureScreenHost(source = source, onClose = onClose)
}

/**
 * Hosts [EditAnnotationScreenHost] for Swift. The result is split into two
 * callbacks to keep the ObjC bridge simple: [onSubmitted] carries the new
 * revision, [onCancelled] fires on dismiss.
 */
public fun EditAnnotationViewController(
    captureId: String,
    subjectRef: String,
    onSubmitted: (Long) -> Unit,
    onCancelled: () -> Unit = {},
): UIViewController = ComposeUIViewController {
    EditAnnotationScreenHost(
        captureId = captureId,
        subjectRef = subjectRef,
        onResult = { result ->
            when (result) {
                is EditAnnotationResult.Submitted -> onSubmitted(result.revision)
                EditAnnotationResult.Cancelled -> onCancelled()
            }
        },
    )
}

public fun PostSubmitFlowViewController(
    session: CaptureSession,
    onDone: () -> Unit = {},
    onCancel: () -> Unit = {},
): UIViewController = ComposeUIViewController {
    ProvideSdkCaptureStrings {
        PostSubmitFlow(session = session, onDone = onDone, onCancel = onCancel)
    }
}
