package com.twinskin.sdk.view

import platform.Foundation.NSFileManager
import platform.Foundation.NSURL

internal actual fun listGlbFiles(dir: String): List<String> {
    val fm = NSFileManager.defaultManager
    val rootUrl = NSURL.fileURLWithPath(dir, isDirectory = true)
    if (!fm.fileExistsAtPath(dir)) return emptyList()

    val enumerator = fm.enumeratorAtURL(
        rootUrl,
        includingPropertiesForKeys = null,
        options = 0u,
        errorHandler = null,
    ) ?: return emptyList()

    val result = mutableListOf<String>()
    while (true) {
        val next = enumerator.nextObject() as? NSURL ?: break
        val path = next.path ?: continue
        if (path.endsWith(".glb", ignoreCase = true) || path.endsWith(".GLB")) {
            result.add(path)
        }
    }
    return result
}
