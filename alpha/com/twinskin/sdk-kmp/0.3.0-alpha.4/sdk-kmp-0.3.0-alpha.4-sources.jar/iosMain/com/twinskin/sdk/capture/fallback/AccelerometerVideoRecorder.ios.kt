@file:OptIn(ExperimentalForeignApi::class, ExperimentalAtomicApi::class)

package com.twinskin.sdk.capture.fallback

import kotlin.concurrent.atomics.AtomicReference
import kotlin.concurrent.atomics.ExperimentalAtomicApi
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.suspendCancellableCoroutine
import platform.AVFoundation.AVCaptureDevice
import platform.AVFoundation.AVCaptureDeviceInput
import platform.AVFoundation.AVCaptureDevicePositionBack
import platform.AVFoundation.AVCaptureFileOutput
import platform.AVFoundation.AVCaptureFileOutputRecordingDelegateProtocol
import platform.AVFoundation.AVCaptureMovieFileOutput
import platform.AVFoundation.AVCapturePhoto
import platform.AVFoundation.AVCapturePhotoCaptureDelegateProtocol
import platform.AVFoundation.AVCapturePhotoOutput
import platform.AVFoundation.AVCapturePhotoQualityPrioritizationSpeed
import platform.AVFoundation.AVCapturePhotoSettings
import platform.AVFoundation.AVCaptureSession
import platform.AVFoundation.AVCaptureSessionPreset3840x2160
import platform.AVFoundation.AVCaptureSessionPresetHigh
import platform.AVFoundation.AVCaptureVideoOrientationPortrait
import platform.AVFoundation.AVMediaTypeVideo
import platform.AVFoundation.AVVideoCodecKey
import platform.AVFoundation.AVVideoCodecTypeJPEG
import platform.AVFoundation.fileDataRepresentation
import platform.AVFoundation.position
import platform.Foundation.NSData
import platform.Foundation.NSDate
import platform.Foundation.NSError
import platform.Foundation.NSFileManager
import platform.Foundation.NSURL
import platform.Foundation.timeIntervalSinceReferenceDate
import platform.Foundation.writeToFile
import platform.darwin.NSObject
import platform.posix.usleep

public class AVFoundationAccelerometerVideoRecorder : VideoRecorder {

    private val stateMachine = AccelerometerVideoRecorderStateMachine(
        partialFileCleanup = { path ->
            NSFileManager.defaultManager.removeItemAtURL(
                NSURL.fileURLWithPath(path),
                error = null,
            )
        },
    )
    private val pendingOutputUrl = AtomicReference<NSURL?>(null)
    private val finalizedPath = AtomicReference<String?>(null)
    private val finalizedError = AtomicReference<NSError?>(null)

    public val session: AVCaptureSession = AVCaptureSession()
    public val videoDevice: AVCaptureDevice? get() = boundVideoDevice
    private var boundVideoDevice: AVCaptureDevice? = null
    private val movieOutput = AVCaptureMovieFileOutput()
    private val delegate = MovieDelegate(this)
    private val photoOutput = AVCapturePhotoOutput()
    private val photoDelegate = PhotoDelegate(this)
    // AVCapturePhotoOutput does NOT retain its delegate — hold the
    // pending continuation here for the delegate trampoline to resume.
    private val pendingPhotoPath = AtomicReference<String?>(null)
    private val pendingPhotoCompletion =
        AtomicReference<((Result<String>) -> Unit)?>(null)

    private val prepared = AtomicReference<Boolean>(false)

    override fun prepare() {
        // Idempotent — re-configuring + restarting a running session
        // would tear the operator's preview layer down.
        if (prepared.load() == true) return
        // Track the open beginConfiguration() so the catch path can commit it: an unbalanced
        // begin/commit (e.g. a denied camera) wedges the session and crashes a later preview attach (#561).
        var inConfiguration = false
        try {
            session.beginConfiguration()
            inConfiguration = true
            // Apply the resolution preset BEFORE adding inputs; the
            // session validates compatibility on `addInput` and would
            // reject a 4K preset on a device whose front camera caps
            // at 1080p (a corner the `.high` fallback covers).
            if (session.canSetSessionPreset(AVCaptureSessionPreset3840x2160)) {
                session.sessionPreset = AVCaptureSessionPreset3840x2160
            } else {
                session.sessionPreset = AVCaptureSessionPresetHigh
            }

            val device = AVCaptureDevice.devicesWithMediaType(AVMediaTypeVideo)
                .filterIsInstance<AVCaptureDevice>()
                .firstOrNull { it.position == AVCaptureDevicePositionBack }
                ?: AVCaptureDevice.defaultDeviceWithMediaType(AVMediaTypeVideo)
                ?: error("No back-camera AVCaptureDevice available")

            val deviceInput = AVCaptureDeviceInput.deviceInputWithDevice(device, error = null)
                ?: error("AVCaptureDeviceInput init failed for default video device")

            if (session.canAddInput(deviceInput)) {
                session.addInput(deviceInput)
                boundVideoDevice = device
            } else {
                error("AVCaptureSession cannot add default video device input")
            }
            if (session.canAddOutput(movieOutput)) {
                session.addOutput(movieOutput)
            } else {
                error("AVCaptureSession cannot add movie output")
            }
            if (session.canAddOutput(photoOutput)) {
                session.addOutput(photoOutput)
            } else {
                error("AVCaptureSession cannot add photo output")
            }
            // AC #5: no `addInput(audioDeviceInput)` — the recorder
            // never asks for microphone access.

            session.commitConfiguration()
            inConfiguration = false
            session.startRunning()

            // Set portrait orientation AFTER session start so the
            // connection's `isVideoOrientationSupported` reflects the
            // running device.
            movieOutput.connectionWithMediaType(AVMediaTypeVideo)?.let { conn ->
                if (conn.isVideoOrientationSupported()) {
                    conn.videoOrientation = AVCaptureVideoOrientationPortrait
                }
            }
            photoOutput.connectionWithMediaType(AVMediaTypeVideo)?.let { conn ->
                if (conn.isVideoOrientationSupported()) {
                    conn.videoOrientation = AVCaptureVideoOrientationPortrait
                }
            }

            prepared.store(true)
        } catch (t: Throwable) {
            if (inConfiguration) {
                try { session.commitConfiguration() } catch (_: Throwable) {}
            }
            try { session.stopRunning() } catch (_: Throwable) {}
            throw t
        }
    }

    public suspend fun takeStillPhoto(outputPath: String): String =
        suspendCancellableCoroutine { cont ->
            if (prepared.load() != true) {
                try {
                    prepare()
                } catch (t: Throwable) {
                    cont.resumeWithException(t)
                    return@suspendCancellableCoroutine
                }
            }
            // Defensive: AVCapturePhoto.fileDataRepresentation refuses
            // to overwrite an existing path on some configurations;
            // clear stale bytes from a previous take inside the same
            // workingDir.
            NSFileManager.defaultManager.removeItemAtURL(
                NSURL.fileURLWithPath(outputPath),
                error = null,
            )
            val completion: (Result<String>) -> Unit = { result ->
                result.fold(
                    onSuccess = { cont.resume(it) },
                    onFailure = { cont.resumeWithException(it) },
                )
            }
            if (!pendingPhotoCompletion.compareAndSet(null, completion)) {
                cont.resumeWithException(
                    IllegalStateException(
                        "AVFoundationAccelerometerVideoRecorder.takeStillPhoto(): " +
                            "a still capture is already in flight"
                    )
                )
                return@suspendCancellableCoroutine
            }
            pendingPhotoPath.store(outputPath)
            try {
                val settings = AVCapturePhotoSettings.photoSettingsWithFormat(
                    mapOf<Any?, Any?>(AVVideoCodecKey to AVVideoCodecTypeJPEG),
                )
                settings.photoQualityPrioritization =
                    AVCapturePhotoQualityPrioritizationSpeed
                photoOutput.capturePhotoWithSettings(settings, delegate = photoDelegate)
            } catch (t: Throwable) {
                pendingPhotoCompletion.store(null)
                pendingPhotoPath.store(null)
                cont.resumeWithException(t)
            }
        }

    internal fun onPhotoFinished(data: NSData?, error: NSError?) {
        val completion = pendingPhotoCompletion.load() ?: return
        pendingPhotoCompletion.store(null)
        val outputPath = pendingPhotoPath.load()
        pendingPhotoPath.store(null)
        if (error != null) {
            completion(
                Result.failure(
                    IllegalStateException(
                        "AVCapturePhoto delegate error: ${error.localizedDescription}"
                    )
                )
            )
            return
        }
        if (outputPath == null) {
            completion(
                Result.failure(IllegalStateException("AVCapturePhoto output path missing"))
            )
            return
        }
        if (data == null) {
            completion(
                Result.failure(
                    IllegalStateException(
                        "AVCapturePhoto.fileDataRepresentation returned null"
                    )
                )
            )
            return
        }
        val ok = data.writeToFile(outputPath, atomically = true)
        if (!ok) {
            completion(
                Result.failure(IllegalStateException("Failed to write JPEG to $outputPath"))
            )
            return
        }
        completion(Result.success(outputPath))
    }

    override fun start(outputPath: String) {
        stateMachine.requestStart()

        try {
            // Lazy-prepare in case the host bypassed
            // AccelerometerCaptureController.markCameraReady (e.g., an integrator-
            // built UI). The session needs to be running before
            // startRecording fires.
            if (prepared.load() != true) prepare()

            val url = NSURL.fileURLWithPath(outputPath)
            pendingOutputUrl.store(url)
            stateMachine.trackPartialFile(outputPath)
            // Defensive: AVFoundation refuses to overwrite an existing
            // file at the same URL. A stale `.mov` from a crashed
            // prior session would otherwise wedge the next capture.
            NSFileManager.defaultManager.removeItemAtURL(url, error = null)

            movieOutput.startRecordingToOutputFileURL(url, recordingDelegate = delegate)
        } catch (t: Throwable) {
            stateMachine.markErrored()
            try { session.stopRunning() } catch (_: Throwable) {}
            throw t
        }
    }

    override fun stop(): String {
        val action = stateMachine.requestStop()
        check(action == AccelerometerVideoRecorderAction.NativeStop)

        // Snapshot the path BEFORE any blocking work. A concurrent
        // cancel() (e.g. the host VC's onDisappear firing during the
        // up-to-30s finalisation window) nulls pendingOutputUrl, and
        // the delegate's `didFinishRecordingTo` may not fire at all
        // when the session is torn down mid-finalise. Snapshotting
        // the start-time path here keeps stop() returning the same
        // value the recording was opened with (#541).
        val outputPath = pendingOutputUrl.load()?.path
            ?: error("AccelerometerVideoRecorder.stop(): output path lost")

        movieOutput.stopRecording()
        // Block until delegate fires `didFinishRecordingTo`. When the
        // session also drives a preview layer the running AVCaptureSession
        // keeps the source busy after `stopRecording`, and AVFoundation
        // can take several seconds to finalise — same pattern as the
        // Android side (#538). A 30s ceiling absorbs that tail.
        //
        // Polling via `usleep` rather than spinning the runloop with
        // `NSRunLoop.runUntilDate` so that this works even when called
        // from a background coroutine dispatcher that has no runloop
        // attached. `AVCaptureMovieFileOutput` dispatches its delegate
        // callback on the AV foundation session queue (not the caller),
        // so the polling loop and the delegate run on distinct threads
        // and the atomics see the publication promptly.
        val started = NSDate().timeIntervalSinceReferenceDate
        while (finalizedPath.load() == null && finalizedError.load() == null) {
            val now = NSDate().timeIntervalSinceReferenceDate
            if (now - started > 30.0) {
                stateMachine.markErrored()
                try { session.stopRunning() } catch (_: Throwable) {}
                throw IllegalStateException("VideoRecorder.stop() timed out waiting for finalisation")
            }
            usleep(50_000u) // 50 ms
        }
        try { session.stopRunning() } catch (_: Throwable) {}

        finalizedError.load()?.let { err ->
            throw IllegalStateException(
                "VideoRecorder finalisation failed: ${err.localizedDescription}"
            )
        }
        return outputPath
    }

    override fun cancel() {
        when (stateMachine.requestCancel()) {
            AccelerometerVideoRecorderAction.None -> Unit
            AccelerometerVideoRecorderAction.NativeAbort -> {
                // Partial-file delete is routed via the state machine's
                // `partialFileCleanup` seam so the disk-touch is
                // testable on `:shared:jvmTest`.
                try { movieOutput.stopRecording() } catch (_: Throwable) {}
                try { session.stopRunning() } catch (_: Throwable) {}
                pendingOutputUrl.store(null)
            }
            else -> Unit
        }
    }

    internal fun onFinalised(path: String, error: NSError?) {
        if (error != null) {
            finalizedError.store(error)
            stateMachine.markErrored()
        } else {
            finalizedPath.store(path)
            stateMachine.markStopped()
        }
    }
}

private class MovieDelegate(
    private val owner: AVFoundationAccelerometerVideoRecorder,
) : NSObject(), AVCaptureFileOutputRecordingDelegateProtocol {

    override fun captureOutput(
        output: AVCaptureFileOutput,
        didFinishRecordingToOutputFileAtURL: NSURL,
        fromConnections: List<*>,
        error: NSError?,
    ) {
        val path = didFinishRecordingToOutputFileAtURL.path ?: ""
        owner.onFinalised(path, error)
    }
}

private class PhotoDelegate(
    private val owner: AVFoundationAccelerometerVideoRecorder,
) : NSObject(), AVCapturePhotoCaptureDelegateProtocol {

    // K/N binds the iOS 11+ photo delegate under `captureOutput`, not
    // the Obj-C `photoOutput:` selector, to disambiguate from the
    // file-output recording delegate.
    override fun captureOutput(
        output: AVCapturePhotoOutput,
        didFinishProcessingPhoto: AVCapturePhoto,
        error: NSError?,
    ) {
        val data = didFinishProcessingPhoto.fileDataRepresentation()
        owner.onPhotoFinished(data, error)
    }
}

public actual fun createVideoRecorder(): VideoRecorder = NotImplementedVideoRecorder()

private class NotImplementedVideoRecorder : VideoRecorder {
    override fun start(outputPath: String): Unit =
        throw NotImplementedError(VIDEO_RECORDER_NOT_IMPLEMENTED_MESSAGE)
    override fun stop(): String =
        throw NotImplementedError(VIDEO_RECORDER_NOT_IMPLEMENTED_MESSAGE)
    override fun cancel() {
    }
}

public fun createAccelerometerVideoRecorder(): AVFoundationAccelerometerVideoRecorder =
    AVFoundationAccelerometerVideoRecorder()
