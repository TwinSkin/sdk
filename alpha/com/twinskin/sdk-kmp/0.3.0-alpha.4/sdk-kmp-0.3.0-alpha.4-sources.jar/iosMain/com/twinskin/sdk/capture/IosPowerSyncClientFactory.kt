package com.twinskin.sdk.capture

import com.powersync.DatabaseDriverFactory
import com.powersync.PowerSyncDatabase
import com.powersync.connectors.PowerSyncBackendConnector
import com.twinskin.sdk.SdkLogger
import kotlinx.coroutines.CoroutineScope

/**
 * iOS-side [PowerSyncClientFactory]. Mirrors
 * `AndroidPowerSyncClientFactory` — separate file only because the
 * `DatabaseDriverFactory` on Darwin has a different constructor
 * (no Context).
 *
 * `observeSubject` cannot actually link on iOS until PR 3-B4 adds the
 * `powersync-sqlite-core-swift` SPM dep to the host app; Kotlin
 * compilation of the shared module works regardless. Integrators
 * calling `observeSubject` before that PR lands will see a
 * `dlopen`-time failure — which is the correct moment to surface the
 * missing SPM dep.
 */
internal class IosPowerSyncClientFactory(
    private val scope: CoroutineScope,
    private val logger: SdkLogger? = null,
) : PowerSyncClientFactory {
    override suspend fun open(
        subjectRef: String,
        connector: PowerSyncBackendConnector,
    ): PowerSyncClient {
        val database = PowerSyncDatabase(
            factory = DatabaseDriverFactory(),
            schema = SdkCapturePowerSyncSchema.schema,
            dbFilename = sdkCapturesDbFilename(subjectRef),
        )
        return RealPowerSyncClient(database, connector, scope, logger)
    }
}
