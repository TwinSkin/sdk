@file:OptIn(kotlinx.cinterop.ExperimentalForeignApi::class)

package com.twinskin.sdk.capture.crypto

import com.twinskin.sdk.capture.crypto.aesgcm.twinskin_aesgcm_seal_chunk
import kotlinx.cinterop.UByteVar
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.allocArray
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.reinterpret
import kotlinx.cinterop.usePinned

internal actual class AesGcmEncryptor actual constructor(
    key: ByteArray,
    baseNonce: ByteArray,
) {
    init {
        require(key.size == 32) { "AES-256 key must be 32 bytes" }
        require(baseNonce.size == 12) { "GCM base nonce must be 12 bytes" }
    }

    private val key = key.copyOf()
    private val baseNonce = baseNonce.copyOf()
    private var counter: Int = 0

    actual fun encryptChunk(plaintext: ByteArray, off: Int, len: Int): EncryptedChunk {
        require(off >= 0 && len >= 0 && off + len <= plaintext.size) {
            "encryptChunk slice out of range: off=$off len=$len size=${plaintext.size}"
        }
        val nonce = baseNonce.copyOf().also {
            it[8] = ((counter ushr 24) and 0xff).toByte()
            it[9] = ((counter ushr 16) and 0xff).toByte()
            it[10] = ((counter ushr 8) and 0xff).toByte()
            it[11] = (counter and 0xff).toByte()
        }
        val ciphertext = ByteArray(len)
        val tag = ByteArray(16)

        val rc: Int = memScoped {
            // Stand-in pointer for the len==0 path: Kotlin/Native rejects
            // addressOf(0) on an empty pinned ByteArray, so the shim gets a
            // valid (unused) buffer for both inputs (`plaintext`) and outputs
            // (`outCiphertext`). The Swift side never reads or writes through
            // these pointers when plaintextLen == 0.
            val emptyByte = allocArray<UByteVar>(1)
            var rcInner = Int.MIN_VALUE
            key.usePinned { kp ->
                nonce.usePinned { np ->
                    tag.usePinned { tagp ->
                        if (len == 0) {
                            rcInner = twinskin_aesgcm_seal_chunk(
                                kp.addressOf(0).reinterpret(), 32,
                                np.addressOf(0).reinterpret(),
                                emptyByte, 0,
                                emptyByte,
                                tagp.addressOf(0).reinterpret(),
                            )
                        } else {
                            ciphertext.usePinned { ctp ->
                                plaintext.usePinned { ptp ->
                                    rcInner = twinskin_aesgcm_seal_chunk(
                                        kp.addressOf(0).reinterpret(), 32,
                                        np.addressOf(0).reinterpret(),
                                        ptp.addressOf(off).reinterpret(), len,
                                        ctp.addressOf(0).reinterpret(),
                                        tagp.addressOf(0).reinterpret(),
                                    )
                                }
                            }
                        }
                    }
                }
            }
            rcInner
        }
        check(rc == 0) { "twinskin_aesgcm_seal_chunk failed: rc=$rc" }
        counter++
        return EncryptedChunk(ciphertext = ciphertext, tag = tag)
    }
}
