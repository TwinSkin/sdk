@file:OptIn(kotlinx.cinterop.ExperimentalForeignApi::class)

package com.twinskin.sdk.ui.fallback

import platform.AVFoundation.AVCaptureDevice
import platform.AVFoundation.AVCaptureTorchModeAuto
import platform.AVFoundation.AVCaptureTorchModeOff
import platform.AVFoundation.AVCaptureTorchModeOn
import platform.AVFoundation.hasTorch
import platform.AVFoundation.isTorchActive
import platform.AVFoundation.isTorchAvailable
import platform.AVFoundation.setTorchMode

/**
 * `AVCaptureDevice.torchMode`-backed [TorchControl] for the iOS
 * accelerometer-capture screen.
 *
 * The device is supplied by the iOS host
 * ([com.twinskin.sdk.ui.fallback.AccelerometerCaptureViewController]) via
 * [bind] once the recorder's [AVCaptureSession] has its back-camera
 * input added — same pattern as the Android sibling.
 *
 * No microphone permission is requested by any path: every call is on
 * `AVCaptureDevice` (video), and the recorder pointedly does NOT add
 * an `AVMediaType.audio` device input (see `AccelerometerVideoRecorder.ios.kt`
 * AC #525-5 note). Locking the device for torch configuration does
 * NOT trigger `AVAudioSession.requestRecordPermission`.
 */
public class AVCaptureDeviceTorchControl : TorchControl {
    private var device: AVCaptureDevice? = null

    public fun bind(device: AVCaptureDevice?) {
        this.device = device
    }

    override fun isAvailable(): Boolean {
        val d = device ?: return false
        return d.hasTorch && d.isTorchAvailable()
    }

    override fun applyFlashMode(mode: FlashMode) {
        val d = device ?: return
        if (!d.hasTorch || !d.isTorchAvailable()) return
        val nativeMode = when (mode) {
            FlashMode.Off -> AVCaptureTorchModeOff
            FlashMode.Auto -> AVCaptureTorchModeAuto
            FlashMode.On -> AVCaptureTorchModeOn
        }
        // `lockForConfiguration`/`unlockForConfiguration` come in via
        // member-method position on `AVCaptureDevice` (Obj-C category
        // selectors are flattened into the class). Errors are swallowed:
        // a torch toggle that the OS rejects (device in-use by another
        // app) is a soft failure — the operator just sees no torch.
        if (d.lockForConfiguration(null)) {
            try {
                d.setTorchMode(nativeMode)
            } finally {
                d.unlockForConfiguration()
            }
        }
    }

    // AVFoundation exposes a synchronous `isTorchActive` read, so (unlike the
    // Android latch) this reflects the hardware directly. `false` when unbound.
    override fun isTorchEnabled(): Boolean = device?.isTorchActive() == true
}
