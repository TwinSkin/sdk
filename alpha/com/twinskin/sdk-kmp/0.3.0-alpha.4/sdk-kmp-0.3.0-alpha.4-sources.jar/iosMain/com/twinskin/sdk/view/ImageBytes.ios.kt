@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.view

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.usePinned
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import platform.Foundation.NSData
import platform.Foundation.dataWithContentsOfFile
import platform.posix.memcpy

internal actual suspend fun readImageBytes(path: String): ByteArray =
    withContext(Dispatchers.Default) {
        val data = NSData.dataWithContentsOfFile(path)
            ?: error("Failed to read image bytes from $path")
        val len = data.length.toInt()
        if (len == 0) {
            ByteArray(0)
        } else {
            val out = ByteArray(len)
            out.usePinned { pinned -> memcpy(pinned.addressOf(0), data.bytes, data.length) }
            out
        }
    }
