@file:OptIn(ExperimentalForeignApi::class, com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.transfer

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.debug
import kotlinx.cinterop.ExperimentalForeignApi

/**
 * Init-optional iOS BGProcessingTask wakeup handler.
 *
 * Walks upload rows in [database] and runs [UploadAttemptRunner.run] on each. When
 * [refresh] is null (SDK not initialized), rows that need a fresh presigned URL stay
 * PENDING and will be retried on the next wakeup. When [refresh] is provided, the
 * runner mints a fresh URL via the SDK's resolver, persists it on the row (Phase F),
 * and re-attempts the PUT in the same call.
 *
 * Row selection branches on [TwinSkinSdk.isInitialized]:
 * - **Init absent** — pick up both PENDING and ACTIVE upload rows. An ACTIVE row
 *   stranded by a process kill has no other retry surface in the init-free path.
 * - **Init present** — pick up only PENDING rows. The background URLSession owned by
 *   [NativeFileTransferProvider] is still alive and will replay terminal callbacks
 *   for any ACTIVE row via [NativeSessionDelegate.handleOrphanedTaskCompletion],
 *   plus [TransferManager.launchRecovery] resets stranded ACTIVE rows on init.
 *   Touching ACTIVE rows here would race with the URLSession and double-upload.
 *
 * The PUT side ([iosBgTaskHttpPut]) uses a default — non-background — [NSURLSession]
 * because BGTask handlers have only ~30 s of wall-clock budget; handing the transfer
 * off to `nsurlsessiond` for later resumption is unnecessary and would race with the
 * already-existing background session owned by [NativeFileTransferProvider] when
 * [TwinSkinSdk.initialize] has run.
 */
internal class IosBgTaskUploadRunner(
    private val database: TwinSkinDatabase,
    private val refresh: (suspend (taskId: String, uploadKey: String) -> UrlResult)?,
    private val clock: () -> Long = ::currentTimeMillis,
    private val logger: SdkLogger = SdkLogger.None,
    private val httpPut: HttpPutFn = iosBgTaskHttpPut,
    private val isSdkInitialized: () -> Boolean = { TwinSkinSdk.isInitialized },
) {
    suspend fun runOnce() {
        val rows = if (isSdkInitialized()) {
            database.transferTaskQueries.selectByStatus(TransferStatus.PENDING.name)
                .executeAsList()
                .filter { it.type == TransferType.UPLOAD.name }
        } else {
            database.transferTaskQueries.selectStaleUploads().executeAsList()
        }
        if (rows.isEmpty()) return
        val cached = CachedUrlUploader(
            database = database,
            httpPut = httpPut,
            clock = clock,
            logger = logger,
            pathResolver = IosPathResolver(),
        )
        val runner = UploadAttemptRunner(
            database = database,
            cachedUploader = cached,
            refresh = refresh,
            clock = clock,
            logger = logger,
        )
        for (row in rows) {
            val outcome = runner.run(taskId = row.id, uploadKey = row.url) { _, _ -> }
            logger.debug("IosBgTaskUploadRunner[${row.id}] outcome=$outcome")
        }
    }
}
