package com.twinskin.sdk.ui.annotation_editor.polygon.orientation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import com.twinskin.sdk.TwinSkinUiKit

@Composable
internal actual fun LockOrientationDuringSession() {
    DisposableEffect(Unit) {
        // Capture the current interface orientation BEFORE
        // incrementing the counter so the outermost session
        // freezes whatever the clinician was holding the device
        // in. Nested sessions inherit the outermost's capture
        // (captureEntryOrientation no-ops when depth > 0).
        TwinSkinUiKit.captureEntryOrientation()
        OrientationLockCounter.enter()
        onDispose {
            OrientationLockCounter.exit()
        }
    }
}
