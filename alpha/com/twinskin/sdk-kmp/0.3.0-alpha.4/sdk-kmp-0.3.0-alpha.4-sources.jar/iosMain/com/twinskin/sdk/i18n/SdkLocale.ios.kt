package com.twinskin.sdk.i18n

import platform.Foundation.NSLocale
import platform.Foundation.currentLocale
import platform.Foundation.languageCode

internal actual fun deviceLocale(): String =
    NSLocale.currentLocale.languageCode.takeIf { it.isNotEmpty() } ?: "en"
