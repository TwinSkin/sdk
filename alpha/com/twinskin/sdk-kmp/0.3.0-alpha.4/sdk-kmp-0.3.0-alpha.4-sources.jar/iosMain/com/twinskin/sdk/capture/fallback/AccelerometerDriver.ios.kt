@file:OptIn(kotlinx.cinterop.ExperimentalForeignApi::class)

package com.twinskin.sdk.capture.fallback

import com.twinskin.sdk.ui.fallback.GuidanceSnapshot
import kotlin.math.roundToLong
import kotlinx.cinterop.useContents
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import platform.CoreMotion.CMAccelerometerData
import platform.CoreMotion.CMGyroData
import platform.CoreMotion.CMMagnetometerData
import platform.CoreMotion.CMMotionManager
import platform.Foundation.NSDate
import platform.Foundation.NSOperationQueue
import platform.Foundation.timeIntervalSince1970

/**
 * iOS [AccelerometerDriver] backed by [CMMotionManager]. Holds a
 * single manager for the session lifetime — `CMMotionManager` is
 * documented as a process-wide singleton-ish resource; instantiating
 * multiple instances under the same app may silently drop callbacks.
 *
 * Sampling cadence: `accelerometerUpdateInterval = 0.005` (200 Hz)
 * across all four streams, matching the web_app's `sensors_plus`
 * configuration on iOS and the Android driver's
 * [android.hardware.SensorManager.SENSOR_DELAY_FASTEST].
 *
 * `deviceMotion.userAcceleration` is the gravity-compensated stream
 * (`TYPE_LINEAR_ACCELERATION` equivalent) — we subscribe to that
 * specifically because the raw `accelerometerData` stream is the
 * gravity-included one and feeds the polar-projection state machine.
 */
internal class IosAccelerometerDriver(
    private val motionManager: CMMotionManager,
    override val angleThreshold: Double,
) : AccelerometerDriver {
    private val accumulator = AccelerometerSampleAccumulator(angleThreshold)

    override val guidance: StateFlow<GuidanceSnapshot> = accumulator.guidance.asStateFlow()

    // Pinned to serial — default NSOperationQueue runs concurrently, and
    // AccelerometerSampleAccumulator's `accept*` methods document a
    // single-producer-thread contract per stream. Without this the four
    // CoreMotion callbacks race on the mutableList appends and the
    // `pie.value` reassignment.
    private val queue: NSOperationQueue = NSOperationQueue().apply {
        maxConcurrentOperationCount = 1
    }
    private var started: Boolean = false

    override fun start(): StateFlow<Pie> {
        if (started) return accumulator.pie.readOnly()
        started = true

        // CMMotionManager rejects intervals < its internal minimum
        // (~0.01s on some devices) silently — set the same value we
        // ask for on every stream so a developer reading the
        // overlay's tick rate sees what we configured.
        motionManager.accelerometerUpdateInterval = SAMPLE_INTERVAL_SECONDS
        motionManager.gyroUpdateInterval = SAMPLE_INTERVAL_SECONDS
        motionManager.magnetometerUpdateInterval = SAMPLE_INTERVAL_SECONDS
        motionManager.deviceMotionUpdateInterval = SAMPLE_INTERVAL_SECONDS

        if (motionManager.accelerometerAvailable) {
            motionManager.startAccelerometerUpdatesToQueue(queue) { data, _ ->
                onAccelerometer(data)
            }
        }
        if (motionManager.gyroAvailable) {
            motionManager.startGyroUpdatesToQueue(queue) { data, _ -> onGyro(data) }
        }
        if (motionManager.magnetometerAvailable) {
            motionManager.startMagnetometerUpdatesToQueue(queue) { data, _ ->
                onMagnetometer(data)
            }
        }
        if (motionManager.deviceMotionAvailable) {
            motionManager.startDeviceMotionUpdatesToQueue(queue) { data, _ ->
                val motion = data ?: return@startDeviceMotionUpdatesToQueue
                val accel = motion.userAcceleration
                // Normalise CoreMotion → Android/sensors_plus frame before
                // recording (see [normalizeCoreMotionAccel]).
                accumulator.acceptUserAccelerometer(
                    normalizeCoreMotionAccel(
                        timestampMilliseconds = currentEpochMillis(),
                        x = accel.useContents { x },
                        y = accel.useContents { y },
                        z = accel.useContents { z },
                    ),
                )
            }
        }
        return accumulator.pie.readOnly()
    }

    override fun stop(): VideoMetaData {
        if (started) {
            motionManager.stopAccelerometerUpdates()
            motionManager.stopGyroUpdates()
            motionManager.stopMagnetometerUpdates()
            motionManager.stopDeviceMotionUpdates()
            started = false
        }
        return accumulator.snapshotMetadata()
    }

    private fun onAccelerometer(data: CMAccelerometerData?) {
        val sample = data ?: return
        val accel = sample.acceleration
        // CoreMotion's raw accelerometer is in g and sign-inverted vs Android
        // `SensorManager`; feeding it RAW reflects the heading (theta → −theta).
        // Normalise to the Android/sensors_plus frame so the recorded data and the
        // live dial heading match (see [normalizeCoreMotionAccel]).
        accumulator.acceptAccelerometer(
            normalizeCoreMotionAccel(
                timestampMilliseconds = currentEpochMillis(),
                x = accel.useContents { x },
                y = accel.useContents { y },
                z = accel.useContents { z },
            ),
        )
    }

    private fun onGyro(data: CMGyroData?) {
        val sample = data ?: return
        val rate = sample.rotationRate
        accumulator.acceptGyroscope(
            AccelerometerData(
                timestampMilliseconds = currentEpochMillis(),
                x = rate.useContents { x },
                y = rate.useContents { y },
                z = rate.useContents { z },
            ),
        )
    }

    private fun onMagnetometer(data: CMMagnetometerData?) {
        val sample = data ?: return
        val field = sample.magneticField
        accumulator.acceptMagnetometer(
            AccelerometerData(
                timestampMilliseconds = currentEpochMillis(),
                x = field.useContents { x },
                y = field.useContents { y },
                z = field.useContents { z },
            ),
        )
    }

    private fun currentEpochMillis(): Long =
        (NSDate().timeIntervalSince1970 * 1000.0).roundToLong()

    private companion object {
        const val SAMPLE_INTERVAL_SECONDS: Double = 0.005
    }
}

public actual fun createAccelerometerDriver(
    angleThreshold: Double,
): AccelerometerDriver = IosAccelerometerDriver(
    motionManager = CMMotionManager(),
    angleThreshold = angleThreshold,
)
