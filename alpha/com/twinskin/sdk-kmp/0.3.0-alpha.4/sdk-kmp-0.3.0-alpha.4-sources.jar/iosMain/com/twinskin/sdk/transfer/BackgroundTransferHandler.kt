@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.transfer

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.db.DatabaseDriverFactory
import com.twinskin.sdk.db.TwinSkinDatabaseHolder
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import platform.Foundation.NSLock

/**
 * Identifier of the background `NSURLSession` the SDK uses for capture uploads. Lives
 * here (not on [TwinSkinSdk.initialize]) so it can be referenced from
 * [TwinSkinIosBackground.urlSessionIdentifier] without a runtime init dependency.
 */
internal const val CAPTURE_URL_SESSION_IDENTIFIER: String = "com.twinskin.sdk.capture"

/**
 * Singleton bridge between iOS background URL session lifecycle events and the SDK.
 *
 * ## Init-optional design
 *
 * Two paths flow through this object:
 *
 * 1. **BGProcessingTask wakeup** ([handleUploadRetryTask]) — woken by iOS when the SDK
 *    has scheduled a retry. Works without [TwinSkinSdk.initialize] having run in the
 *    current process: the handler opens the DB via [TwinSkinDatabaseHolder] and runs
 *    [IosBgTaskUploadRunner] (which uses [CachedUrlUploader] + [UploadAttemptRunner]).
 *    Cached-URL retries complete without needing the SDK component; refresh-requiring
 *    rows stay PENDING for the next wakeup. When init *has* run, [onUploadRetryRequested]
 *    is invoked instead so the full [TransferManager] retry loop runs (with the
 *    background-session provider) — same behavior as before.
 *
 * 2. **`handleEventsForBackgroundURLSession`** ([handleBackgroundEvents]) — iOS replays
 *    pending background-session delegate callbacks. This still requires [configure] to
 *    have wired the [NativeFileTransferProvider] (and therefore [TwinSkinSdk.initialize]
 *    to have run) because the session identifier and delegate are owned by the provider.
 *    Without configure, the orphan callbacks are stored but unwound on the next launch
 *    that does call initialize.
 */
internal object BackgroundTransferHandler {

    private var provider: NativeFileTransferProvider? = null
    private val completionHandlers = mutableMapOf<String, () -> Unit>()
    private val lock = NSLock()

    /**
     * Coroutine scope used by the init-optional [handleUploadRetryTask] path. A
     * SupervisorJob so one row's failure can't cancel sibling rows; Dispatchers.Default
     * because Kotlin/Native has no public Dispatchers.IO and this scope only ever runs
     * suspending DB + URLSession work.
     */
    private val wakeupScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /**
     * Set by [TwinSkinSdk.initialize] when full wiring is in place. When non-null, BGTask
     * wakeups dispatch through it (so the SDK's [TransferManager] runs the full retry
     * loop using the background-session provider). When null (init has not run in this
     * process), [handleUploadRetryTask] falls back to the init-optional path.
     */
    var onUploadRetryRequested: (() -> Unit)? = null

    /**
     * Optional hook installed by [TwinSkinSdk.initialize] that mints a fresh presigned
     * URL when [UploadAttemptRunner] needs one. Used only by the init-optional wakeup
     * path; the init-wired path goes through [onUploadRetryRequested] instead.
     */
    var refreshHook: (suspend (taskId: String, uploadKey: String) -> UrlResult)? = null

    /**
     * Optional logger installed at initialize time. Defaults to [SdkLogger.None] so the
     * init-optional path stays quiet on production hosts that haven't configured one.
     */
    var logger: SdkLogger = SdkLogger.None

    /**
     * Wire the [provider] into this handler so [handleBackgroundEvents] can reconnect
     * the session and stored iOS completion handlers fire at the right time. Called by
     * [TwinSkinSdk.initialize]; not required for the BGTask wakeup path.
     */
    fun configure(provider: NativeFileTransferProvider) {
        this.provider = provider
        provider.delegate.onBackgroundEventsFinished = { identifier ->
            val handler: (() -> Unit)?
            lock.lock()
            handler = completionHandlers.remove(identifier)
            lock.unlock()
            handler?.invoke()
        }
    }

    /**
     * Initialises the background [NSURLSession] immediately at app launch so iOS can
     * begin replaying any pending delegate callbacks as soon as possible.
     */
    fun reconnectOnLaunch() {
        provider?.reconnect()
    }

    /**
     * Called from the AppDelegate to hand off a background session event.
     *
     * Stores the [completionHandler] and re-attaches the [NSURLSession] with the matching
     * identifier so its delegate receives all queued callbacks. The stored handler is
     * invoked automatically once `URLSessionDidFinishEventsForBackgroundURLSession` fires.
     *
     * Requires [configure] to have run (i.e. [TwinSkinSdk.initialize]) — the session
     * identifier and the delegate live on the provider. Without configure, the handler
     * is still stored, but no provider exists to drive the callbacks; in that case the
     * host should call this again after initialize.
     */
    fun handleBackgroundEvents(identifier: String, completionHandler: () -> Unit) {
        lock.lock()
        completionHandlers[identifier] = completionHandler
        lock.unlock()
        provider?.reconnect()
    }

    /**
     * Called from the AppDelegate's BGProcessingTask handler when iOS wakes the app to
     * retry pending uploads.
     *
     * - When [onUploadRetryRequested] is set ([TwinSkinSdk.initialize] has run): forward
     *   to it so the SDK's [TransferManager.launchRecoverPendingUploads] runs.
     * - Otherwise: open the DB via [TwinSkinDatabaseHolder] and run
     *   [IosBgTaskUploadRunner] directly so cached-URL retries can complete without the
     *   SDK component. Refresh-requiring rows stay PENDING for the next wakeup.
     */
    fun handleUploadRetryTask() {
        val initWired = onUploadRetryRequested
        if (initWired != null) {
            initWired.invoke()
            return
        }
        wakeupScope.launch {
            val database = TwinSkinDatabaseHolder.acquire(
                DatabaseDriverFactory("twinskin_transfers.db"),
            )
            IosBgTaskUploadRunner(
                database = database,
                refresh = refreshHook,
                logger = logger,
            ).runOnce()
        }
    }

    /** Test-only — reset listener / hooks installed by initialize. */
    internal fun resetForTest() {
        provider = null
        onUploadRetryRequested = null
        refreshHook = null
        logger = SdkLogger.None
        lock.lock()
        completionHandlers.clear()
        lock.unlock()
    }
}
