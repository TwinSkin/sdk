@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.transfer

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.suspendCancellableCoroutine
import platform.Foundation.NSError
import platform.Foundation.NSHTTPURLResponse
import platform.Foundation.NSMutableURLRequest
import platform.Foundation.NSURL
import platform.Foundation.NSURLSession
import platform.Foundation.NSURLSessionConfiguration
import platform.Foundation.dataTaskWithRequest
import platform.Foundation.setHTTPMethod
import platform.Foundation.setValue
import platform.Foundation.uploadTaskWithRequest
import kotlin.coroutines.resume

/**
 * Suspending HTTP PUT used by the init-optional iOS BGProcessingTask wakeup path.
 *
 * Uses a default (non-background) [NSURLSession] because the BGTask handler only has
 * ~30 seconds of wall-clock budget before iOS suspends the app again — there is no
 * point handing the transfer to `nsurlsessiond` for resumption since the foreground
 * upload window is short and bounded. The full background-session machinery in
 * [NativeFileTransferProvider] continues to be used when [TwinSkinSdk.initialize] has
 * run (via the resolver → PUT loop owned by [TransferManager]).
 *
 * Maps the response onto [HttpPutResult] using the same convention as Android's
 * Ktor PUT in `UploadWorker`:
 * - 2xx → [HttpPutResult.Success]
 * - 403 → [HttpPutResult.UrlExpired] (S3 expired presign)
 * - other 4xx → [HttpPutResult.ClientError]
 * - 5xx / transport error → [HttpPutResult.TransientError]
 */
internal val iosBgTaskHttpPut: HttpPutFn = put@{ url, localPath, _ ->
    val nsUrl = NSURL.URLWithString(url) ?: return@put HttpPutResult.TransientError
    val request = NSMutableURLRequest.requestWithURL(nsUrl)
    request.setHTTPMethod("PUT")
    request.setValue("application/octet-stream", forHTTPHeaderField = "Content-Type")

    val session = NSURLSession.sessionWithConfiguration(
        NSURLSessionConfiguration.defaultSessionConfiguration(),
    )

    suspendCancellableCoroutine<HttpPutResult> { cont ->
        val task = session.uploadTaskWithRequest(
            request  = request,
            fromFile = NSURL.fileURLWithPath(localPath),
            completionHandler = { _, response, error ->
                val result = mapResponse(response as? NSHTTPURLResponse, error)
                if (cont.isActive) cont.resume(result)
            },
        )
        cont.invokeOnCancellation { task.cancel() }
        task.resume()
    }
}

private fun mapResponse(response: NSHTTPURLResponse?, error: NSError?): HttpPutResult {
    if (error != null) return HttpPutResult.TransientError
    val status = response?.statusCode?.toInt() ?: return HttpPutResult.TransientError
    return when {
        status in 200..299 -> HttpPutResult.Success
        status == 403 -> HttpPutResult.UrlExpired
        status in 400..499 -> HttpPutResult.ClientError(status)
        else -> HttpPutResult.TransientError
    }
}
