package com.twinskin.sdk.capture

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.toKString
import platform.Foundation.NSBundle
import platform.Foundation.NSLocale
import platform.Foundation.currentLocale
import platform.Foundation.localeIdentifier
import platform.UIKit.UIDevice
import platform.posix.uname
import platform.posix.utsname

/**
 * iOS implementation of [systemDevicePlatformInfo]. See the
 * [DevicePlatformInfo] commonMain doc for cross-platform contracts.
 *
 * Notes specific to this implementation:
 * - `deviceModel` is the raw machine identifier (`"iPhone15,3"`,
 *   `"iPad13,1"`, etc.) read from `utsname.machine`. The simulator
 *   returns `"arm64"` / `"x86_64"`, which is fine to pass through —
 *   the admin display layer is responsible for any pretty-printing.
 * - `locale` normalizes `NSLocale.localeIdentifier` (underscored
 *   POSIX form, e.g. `"en_US"`) to BCP-47 (`"en-US"`) by replacing
 *   underscores with hyphens. This is sufficient for the common
 *   `language_REGION` cases; a fully RFC-compliant transform would
 *   require platform.Foundation's
 *   `NSLocale.canonicalLanguageIdentifierFromString`, which is
 *   overkill for the support-triage use case.
 * - `deviceManufacturer` is the constant `"Apple"` because iOS
 *   doesn't have a `Build.MANUFACTURER` equivalent — every device
 *   running iOS is Apple by definition.
 */
internal actual fun systemDevicePlatformInfo(): DevicePlatformInfo =
    DevicePlatformInfo(
        os = "ios",
        osVersion = UIDevice.currentDevice.systemVersion,
        deviceManufacturer = "Apple",
        deviceModel = readMachineIdentifier(),
        appVersion = NSBundle.mainBundle.infoDictionary
            ?.get("CFBundleShortVersionString") as? String,
        appBundleId = NSBundle.mainBundle.bundleIdentifier,
        locale = NSLocale.currentLocale.localeIdentifier.replace('_', '-'),
    )

@OptIn(ExperimentalForeignApi::class)
private fun readMachineIdentifier(): String? = memScoped {
    val info = alloc<utsname>()
    if (uname(info.ptr) != 0) return@memScoped null
    info.machine.toKString()
}
