@file:OptIn(kotlinx.cinterop.ExperimentalForeignApi::class)

package com.twinskin.sdk.capture

import platform.Foundation.NSDate
import platform.Foundation.NSISO8601DateFormatWithFractionalSeconds
import platform.Foundation.NSISO8601DateFormatWithInternetDateTime
import platform.Foundation.NSISO8601DateFormatter
import platform.Foundation.dateWithTimeIntervalSince1970
import platform.Foundation.timeIntervalSince1970

internal actual fun epochMillisToIso8601(epochMillis: Long): String {
    val formatter = NSISO8601DateFormatter()
    formatter.formatOptions = NSISO8601DateFormatWithInternetDateTime
    val date = NSDate.dateWithTimeIntervalSince1970(epochMillis / 1000.0)
    return formatter.stringFromDate(date)
}

internal actual fun iso8601ToEpochMillis(iso: String): Long? {
    // The default NSISO8601DateFormatter can't parse fractional seconds;
    // fall back to a second formatter that can, so timestamps like
    // `2026-04-22T10:11:12.345Z` round-trip.
    val plain = NSISO8601DateFormatter().apply {
        formatOptions = NSISO8601DateFormatWithInternetDateTime
    }
    val fractional = NSISO8601DateFormatter().apply {
        formatOptions = NSISO8601DateFormatWithInternetDateTime or
            NSISO8601DateFormatWithFractionalSeconds
    }
    val date = plain.dateFromString(iso) ?: fractional.dateFromString(iso) ?: return null
    return (date.timeIntervalSince1970 * 1000.0).toLong()
}
