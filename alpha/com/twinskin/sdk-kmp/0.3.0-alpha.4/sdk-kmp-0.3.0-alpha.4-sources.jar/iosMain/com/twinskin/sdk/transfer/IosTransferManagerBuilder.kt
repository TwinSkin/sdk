@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.transfer

import com.twinskin.sdk.db.TwinSkinDatabase
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import platform.Foundation.NSURLSessionConfiguration
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/**
 * Swift-friendly builder that wires up a [NativeFileTransferProvider] and a [TransferManager]
 * for use in iOS host apps.
 *
 * ## Why this exists
 * KMP `suspend` lambdas are not directly callable from Swift as closures. This builder
 * accepts a callback-style URL resolver that Swift can provide as a standard closure,
 * wraps it in the `suspend` form that [NativeFileTransferProvider] requires, and creates
 * both the provider and the manager in one step.
 *
 * ## Swift usage
 * ```swift
 * let builder = IosTransferManagerBuilder(
 *     database: db,
 *     sessionIdentifier: bundleId + ".sdk.transfers",
 *     resolveUrl: { uploadKey, completion in
 *         MyApi.fetchPresignedUrl(for: uploadKey) { url in
 *             if let url = url {
 *                 completion(UrlResultUrl(url: url))
 *             } else {
 *                 completion(UrlResultRetryableError())
 *             }
 *         }
 *     }
 * )
 * let manager = builder.build()
 * BackgroundTransferHandler.shared.configure(provider: builder.provider!)
 * ```
 */
internal class IosTransferManagerBuilder(
    private val database: TwinSkinDatabase,
    private val sessionIdentifier: String,
    private val zipEngine: ZipEngine = NoOpZipEngine(),
    /**
     * Callback-style URL resolver. Called with the upload key and a completion block.
     * The completion block must be invoked exactly once with a [UrlResult].
     */
    private val resolveUrl: (uploadKey: String, completion: (UrlResult) -> Unit) -> Unit,
    private val backgroundScheduler: BackgroundScheduler = IosBackgroundScheduler(),
    private val uploadRetryDelayMs: Long = 5_000L,
    /**
     * Optional override for the NSURLSession configuration factory (e.g. for tests).
     * When null, uses `NSURLSessionConfiguration.backgroundSessionConfigurationWithIdentifier`.
     */
    private val sessionConfigurationFactory: ((String) -> NSURLSessionConfiguration)? = null,
) {
    /**
     * The [NativeFileTransferProvider] created by [build]. Available after [build] is called
     * so the host app can pass it to [BackgroundTransferHandler.configure].
     */
    var provider: NativeFileTransferProvider? = null
        private set

    fun build(): TransferManager {
        val scope = CoroutineScope(Dispatchers.Default)
        val resolver: UrlResolver = { uploadKey ->
            suspendCoroutine { cont ->
                resolveUrl(uploadKey) { result -> cont.resume(result) }
            }
        }
        val builtProvider = NativeFileTransferProvider(
            sessionIdentifier       = sessionIdentifier,
            urlResolver             = resolver,
            backgroundScheduler     = backgroundScheduler,
            retryDelayMs            = uploadRetryDelayMs,
            sessionConfigurationFactory = sessionConfigurationFactory
                ?: { id ->
                    NSURLSessionConfiguration
                        .backgroundSessionConfigurationWithIdentifier(id)
                        .also {
                            it.discretionary = false
                            it.sessionSendsLaunchEvents = true
                        }
                },
            transferQueries         = database.transferTaskQueries,
        )
        provider = builtProvider
        return TransferManager(
            database     = database,
            provider     = builtProvider,
            zipEngine    = zipEngine,
            scope        = scope,
            pathResolver = IosPathResolver(),
        )
    }
}
