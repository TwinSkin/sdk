package com.twinskin.sdk.ui.view_capture.renderer

import com.twinskin.sdk.view.Model3DViewMetadata
import platform.UIKit.UIView

/**
 * Platform hook for the iOS 3D renderer. [Model3DViewer] on iOS uses
 * whatever [factory] produces.
 *
 * ## Why this indirection
 *
 * SceneKit can't load `.glb` files out of the box — that requires a
 * Swift-only library (`GLTFSceneKit` or `GLTFKit2`) that isn't reachable
 * from Kotlin/Native without a cinterop bridge. Rather than pulling a
 * Swift package into the KMP build, we let the Swift side register a
 * factory at init time.
 *
 * The `sdk-ios` Swift package (consumed by integrator apps) auto-registers
 * a default implementation backed by GLTFSceneKit during
 * `TwinSkin.initialize(_:)`. Integrators who want a different renderer
 * can set [factory] themselves.
 *
 * If no factory is registered when [Model3DViewer] is asked to render,
 * a small placeholder UIView is shown explaining what to do.
 */
public object Ios3DRenderer {
    /**
     * Build a UIView that renders the GLB at [glbPath]. Called on the
     * main thread from the Compose update phase.
     *
     * [viewMetadata] carries the reference-camera framing (marker centre,
     * FoV, distance) when available, so the renderer opens at the reference
     * perspective and orbits around the marker; null falls back to auto-framing.
     */
    public var factory: ((glbPath: String, viewMetadata: Model3DViewMetadata?) -> UIView)? = null
}
