package com.twinskin.sdk.capture

import com.twinskin.sdk.TransferSnapshot
import com.twinskin.sdk.TwinSkinDebug
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import platform.Foundation.NSLog

/**
 * Glue used by the Swift `TwinSkinCaptureObserver` wrapper. Kotlin's
 * cold `Flow` doesn't bridge cleanly to Swift on its own (no `for await`,
 * no `.value`), so we offer a callback-based subscription that the Swift
 * side wraps into an `AsyncStream`.
 *
 * Not part of the public Kotlin API — Android callers use the original
 * `Flow` directly via `collectAsState`.
 */

/** Cancellation handle returned to Swift. */
public class FlowSubscription internal constructor(private val job: Job) {
    public fun cancel() {
        job.cancel()
    }
}

/**
 * Long-lived scope used to drive every Swift-side subscription. Uses
 * `Dispatchers.Main` so callbacks land on the main thread — SwiftUI
 * requires `AsyncStream.yield` from the main actor when the consumer is
 * `@MainActor`.
 *
 * The [CoroutineExceptionHandler] is defense-in-depth against any
 * upstream flow leaking an exception out of `collect`. Without it,
 * Kotlin/Native's default unhandled-coroutine-exception path calls
 * `processUnhandledException`, which terminates the host iOS process.
 * Upstreams that need retry semantics (e.g. `observeSubject`) handle
 * their own errors internally and log via [com.twinskin.sdk.SdkLogger];
 * this handler exists only to keep an unforeseen throw from aborting
 * the integrator's app.
 */
private val swiftBridgeScope = CoroutineScope(
    SupervisorJob() + Dispatchers.Main + CoroutineExceptionHandler { _, t ->
        NSLog("TwinSkinSDK: swallowed unhandled exception from Swift bridge: %s", t.toString())
    },
)

public fun CaptureObserver.observePendingUploadsFromSwift(
    onEach: (List<PendingUpload>) -> Unit,
): FlowSubscription =
    observePendingUploads().subscribeFromSwift(onEach)

public fun CaptureObserver.observeSubjectFromSwift(
    subjectRef: String,
    onEach: (List<CaptureEntry>) -> Unit,
): FlowSubscription =
    observeSubject(subjectRef).subscribeFromSwift(onEach)

public fun CaptureSession.observeStateFromSwift(
    onEach: (CaptureState) -> Unit,
): FlowSubscription =
    state.subscribeFromSwift(onEach)

public fun TwinSkinDebug.observeTransfersFromSwift(
    onEach: (List<TransferSnapshot>) -> Unit,
): FlowSubscription =
    observeTransfers().subscribeFromSwift(onEach)

private fun <T> Flow<T>.subscribeFromSwift(onEach: (T) -> Unit): FlowSubscription {
    val job = swiftBridgeScope.launch {
        collect { onEach(it) }
    }
    return FlowSubscription(job)
}
