@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk.ui.annotation_editor

import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.usePinned
import org.jetbrains.skia.Image
import platform.Foundation.NSData
import platform.Foundation.dataWithContentsOfFile
import platform.posix.memcpy

/**
 * Skia's `Image.makeFromEncoded` honours EXIF orientation on JPEG
 * input, so no extra rotation pass is needed on iOS.
 */
public actual fun loadImageFromPath(path: String): ImageBitmap {
    val data = NSData.dataWithContentsOfFile(path)
        ?: error("Failed to read image bytes from $path")
    val len = data.length.toInt()
    val bytes = if (len == 0) {
        ByteArray(0)
    } else {
        ByteArray(len).also { out ->
            out.usePinned { pinned -> memcpy(pinned.addressOf(0), data.bytes, data.length) }
        }
    }
    return Image.makeFromEncoded(bytes).toComposeImageBitmap()
}

public actual fun ByteArray.toImageBitmap(): ImageBitmap =
    Image.makeFromEncoded(this).toComposeImageBitmap()
