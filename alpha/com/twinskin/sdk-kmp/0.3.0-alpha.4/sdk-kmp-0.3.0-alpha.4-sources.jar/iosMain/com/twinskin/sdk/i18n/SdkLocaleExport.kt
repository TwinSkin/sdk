package com.twinskin.sdk.i18n

/**
 * The SDK's active locale tag for the native SwiftUI layer — the single source
 * of truth shared with Compose. The generated `CaptureStrings` (Swift) resolves
 * its table from this value; see `sdk-ios/Sources/LocaleMatch.swift`. Mirrors
 * [sdkLocale] (integrator override ?: device locale, lowercased) and is exported
 * through the K/N framework as `SdkLocaleExportKt.sdkResolvedLocale()`.
 */
public fun sdkResolvedLocale(): String = sdkLocale()
