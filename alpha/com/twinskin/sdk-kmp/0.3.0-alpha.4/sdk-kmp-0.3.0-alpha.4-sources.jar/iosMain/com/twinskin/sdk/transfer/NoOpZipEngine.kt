package com.twinskin.sdk.transfer

/**
 * No-operation [ZipEngine] used when the app does not need to unzip downloaded bundles.
 *
 * For production unzipping on iOS, replace with a [ZipEngine] implementation backed by
 * a native zip library (e.g. minizip-ng via cinterop, or SSZipArchive bridged from Swift).
 * Foundation does not expose a zip API, and process spawning (`ditto`, `unzip`) is not
 * available on-device iOS.
 */
internal class NoOpZipEngine : ZipEngine {
    override suspend fun unzip(source: String, target: String): Result<Unit> = Result.success(Unit)
    override suspend fun cleanup(path: String): Result<Unit> = Result.success(Unit)
}
