package com.twinskin.sdk.ui.fallback

import platform.UIKit.UIImpactFeedbackGenerator
import platform.UIKit.UIImpactFeedbackStyle
import platform.UIKit.UINotificationFeedbackGenerator
import platform.UIKit.UINotificationFeedbackType

// Generators are a no-op on hardware without a Taptic Engine, so no availability guard is needed.
public actual fun performCaptureHaptic(event: CaptureHapticEvent) {
    when (event) {
        CaptureHapticEvent.PhotoCaptured,
        CaptureHapticEvent.SectorFilled ->
            impact(UIImpactFeedbackStyle.UIImpactFeedbackStyleLight)

        CaptureHapticEvent.RecordingStarted ->
            impact(UIImpactFeedbackStyle.UIImpactFeedbackStyleMedium)

        CaptureHapticEvent.OrbitComplete ->
            notify(UINotificationFeedbackType.UINotificationFeedbackTypeSuccess)

        CaptureHapticEvent.TooFast ->
            notify(UINotificationFeedbackType.UINotificationFeedbackTypeWarning)

        CaptureHapticEvent.Error ->
            notify(UINotificationFeedbackType.UINotificationFeedbackTypeError)
    }
}

private fun impact(style: UIImpactFeedbackStyle) {
    val gen = UIImpactFeedbackGenerator(style)
    gen.prepare()
    gen.impactOccurred()
}

private fun notify(type: UINotificationFeedbackType) {
    val gen = UINotificationFeedbackGenerator()
    gen.prepare()
    gen.notificationOccurred(type)
}
