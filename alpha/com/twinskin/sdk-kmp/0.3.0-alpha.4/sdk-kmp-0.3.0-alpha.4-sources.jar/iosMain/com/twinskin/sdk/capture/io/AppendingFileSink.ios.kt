@file:OptIn(ExperimentalForeignApi::class, BetaInteropApi::class)

package com.twinskin.sdk.capture.io

import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.autoreleasepool
import kotlinx.cinterop.convert
import kotlinx.cinterop.usePinned
import platform.Foundation.NSData
import platform.Foundation.NSFileHandle
import platform.Foundation.NSFileManager
import platform.Foundation.closeFile
import platform.Foundation.dataWithBytesNoCopy
import platform.Foundation.fileHandleForWritingAtPath
import platform.Foundation.writeData

internal actual open class AppendingFileSink actual constructor(path: String) {

    private val handle: NSFileHandle
    private var closed = false

    init {
        // createFileAtPath truncates if the file already exists.
        NSFileManager.defaultManager.createFileAtPath(path, contents = null, attributes = null)
        handle = NSFileHandle.fileHandleForWritingAtPath(path)
            ?: error("Failed to open for writing: $path")
    }

    actual open fun write(src: ByteArray, off: Int, len: Int) {
        if (len == 0) return
        // autoreleasepool bounds NSData accumulation — writes happen in a tight
        // streaming loop and the outer pool only drains at thread-top, which would
        // otherwise grow unboundedly for large bundles.
        autoreleasepool {
            src.usePinned { pinned ->
                val data = NSData.dataWithBytesNoCopy(
                    bytes = pinned.addressOf(off),
                    length = len.convert(),
                    freeWhenDone = false,
                )
                handle.writeData(data)
            }
        }
    }

    actual open fun close() {
        if (closed) return
        closed = true
        handle.closeFile()
    }
}
