package com.twinskin.sdk.ui.annotation_editor.delineation.draft

import com.russhwolf.settings.NSUserDefaultsSettings
import com.russhwolf.settings.Settings
import platform.Foundation.NSUserDefaults

internal actual fun provideDraftSettings(): Settings =
    NSUserDefaultsSettings(NSUserDefaults(suiteName = SUITE_NAME))

private const val SUITE_NAME = "twinskin_delineation_drafts"
