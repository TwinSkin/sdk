@file:OptIn(
    com.twinskin.sdk.TwinSkinInternalApi::class,
    kotlinx.cinterop.ExperimentalForeignApi::class,
)

package com.twinskin.sdk

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.window.ComposeUIViewController
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.ui.annotation_editor.toImageBitmap
import com.twinskin.sdk.ui.edit_annotation.EditAnnotationResult
import com.twinskin.sdk.ui.edit_annotation.EditAnnotationScreenHost
import com.twinskin.sdk.ui.capture.i18n.ProvideSdkCaptureStrings
import com.twinskin.sdk.ui.photosphere_tutorial.PhotosphereTutorialOverlay
import com.twinskin.sdk.ui.post_submit.PostSubmitFlow
import com.twinskin.sdk.ui.view_capture.ViewCaptureScreenHost
import com.twinskin.sdk.view.CaptureSource
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.convert
import kotlinx.cinterop.usePinned
import platform.Foundation.NSData
import platform.UIKit.UIViewController
import platform.posix.memcpy

// iOS capture is SwiftUI+AVFoundation (sdk-ios/Sources/CaptureView.swift),
// not Compose — no CaptureViewController here.

public fun ViewCaptureViewController(
    source: CaptureSource,
    onClose: () -> Unit = {},
): UIViewController = ComposeUIViewController {
    ViewCaptureScreenHost(source = source, onClose = onClose)
}

/**
 * Hosts [EditAnnotationScreenHost] for Swift. The result is split into two
 * callbacks to keep the ObjC bridge simple: [onSubmitted] carries the new
 * revision, [onCancelled] fires on dismiss.
 */
public fun EditAnnotationViewController(
    captureId: String,
    subjectRef: String,
    onSubmitted: (Long) -> Unit,
    onCancelled: () -> Unit = {},
): UIViewController = ComposeUIViewController {
    EditAnnotationScreenHost(
        captureId = captureId,
        subjectRef = subjectRef,
        onResult = { result ->
            when (result) {
                is EditAnnotationResult.Submitted -> onSubmitted(result.revision)
                EditAnnotationResult.Cancelled -> onCancelled()
            }
        },
    )
}

public fun PostSubmitFlowViewController(
    session: CaptureSession,
    onDone: () -> Unit = {},
    onCancel: () -> Unit = {},
): UIViewController = ComposeUIViewController {
    ProvideSdkCaptureStrings {
        PostSubmitFlow(session = session, onDone = onDone, onCancel = onCancel)
    }
}

/**
 * Hosts the shared photosphere tutorial composable inside a UIViewController
 * so Swift can present it via UIViewControllerRepresentable. `refImageData`
 * is the encoded reference still; persistence + capture-pause wiring lives
 * on the Swift side.
 */
public fun PhotosphereTutorialViewController(
    refImageData: NSData,
    seenAtLeastOnce: Boolean,
    dontShowAgainInitial: Boolean,
    onPauseChanged: (Boolean) -> Unit,
    onDontShowAgainChanged: (Boolean) -> Unit,
    onDismiss: () -> Unit,
): UIViewController = ComposeUIViewController {
    // Skiko's `Image.makeFromEncoded` returns null on malformed bytes;
    // wrap to avoid an NPE in `remember` crashing the capture screen.
    val refImage = remember(refImageData) {
        runCatching { refImageData.toByteArray().toImageBitmap() }
            .getOrNull()
    }
    if (refImage == null) {
        LaunchedEffect(Unit) { onDismiss() }
        return@ComposeUIViewController
    }
    ProvideSdkCaptureStrings {
        PhotosphereTutorialOverlay(
            refImage = refImage,
            seenAtLeastOnce = seenAtLeastOnce,
            dontShowAgainInitial = dontShowAgainInitial,
            onPauseChanged = onPauseChanged,
            onDontShowAgainChanged = onDontShowAgainChanged,
            onDismiss = onDismiss,
        )
    }
}

/** Single-memcpy `NSData → ByteArray` so multi-MB JPEGs don't pay a
 *  per-byte Swift→Kotlin loop. */
private fun NSData.toByteArray(): ByteArray {
    val len = length.toInt()
    if (len == 0) return ByteArray(0)
    val out = ByteArray(len)
    out.usePinned { pinned ->
        memcpy(pinned.addressOf(0), bytes, len.convert())
    }
    return out
}
