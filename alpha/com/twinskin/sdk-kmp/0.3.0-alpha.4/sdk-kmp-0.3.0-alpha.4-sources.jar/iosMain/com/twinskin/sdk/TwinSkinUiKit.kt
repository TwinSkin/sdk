@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk

import com.twinskin.sdk.ui.annotation_editor.polygon.orientation.OrientationLockCounter
import com.twinskin.sdk.ui.annotation_editor.polygon.system.SystemGesturesLockCounter
import kotlinx.cinterop.ExperimentalForeignApi
import platform.UIKit.UIApplication
import platform.UIKit.UIInterfaceOrientationLandscapeLeft
import platform.UIKit.UIInterfaceOrientationLandscapeRight
import platform.UIKit.UIInterfaceOrientationMask
import platform.UIKit.UIInterfaceOrientationMaskAll
import platform.UIKit.UIInterfaceOrientationMaskLandscapeLeft
import platform.UIKit.UIInterfaceOrientationMaskLandscapeRight
import platform.UIKit.UIInterfaceOrientationMaskPortrait
import platform.UIKit.UIInterfaceOrientationMaskPortraitUpsideDown
import platform.UIKit.UIInterfaceOrientationPortrait
import platform.UIKit.UIInterfaceOrientationPortraitUpsideDown
import platform.UIKit.UIRectEdge
import platform.UIKit.UIRectEdgeAll
import platform.UIKit.UIRectEdgeNone
import platform.UIKit.UIWindowScene

/**
 * iOS-only integrator hooks for UIKit-side concerns the SDK can't
 * resolve on its own (orientation lock during the annotation
 * editor session, future UIKit lifecycle hooks).
 *
 * **Orientation lock — required `AppDelegate` wire-up.**
 *
 * The SDK declares an orientation preference via
 * [preferredOrientationMask] while a session is active. UIKit
 * consults the host app's `supportedInterfaceOrientationsFor` on
 * every orientation event; forward the property from there:
 *
 * ```swift
 * func application(
 *     _ app: UIApplication,
 *     supportedInterfaceOrientationsFor window: UIWindow?
 * ) -> UIInterfaceOrientationMask {
 *     return TwinSkin.uiKit.preferredOrientationMask
 * }
 * ```
 *
 * One-time wire-up at app init. No callback registration; the
 * property is read on demand. When no editor session is active the
 * mask returns `UIInterfaceOrientationMaskAll` so the host app's
 * normal orientation rules are preserved.
 *
 * **Declare-intent-only.** This is the SDK's preference, not a force.
 * UIKit consults [preferredOrientationMask] on the next orientation
 * event — typically on the next layout pass (within a frame of the
 * editor opening). If your host needs immediate rotation, call
 * `setNeedsUpdateOfSupportedInterfaceOrientations()` (iOS 16+) in
 * the same flow that opens the editor; pre-iOS-16 hosts rely on the
 * defer-to-next-layout behaviour, which matches the editor's typical
 * UX (the canvas is laid out within a frame or two of opening
 * anyway).
 *
 * **System-edge gestures lock — required `UIViewController` wire-up
 * (M15.6).**
 *
 * The SDK defers the system's back-swipe and home-indicator gestures
 * while an annotation-editor session is active so strokes that reach
 * the left/right edge of the screen don't trigger system overlays
 * mid-drawing. The host view controller (the one whose view
 * contains the editor) must override the two UIKit properties and
 * forward them to the matching getters here:
 *
 * ```swift
 * override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge {
 *     return TwinSkin.uiKit.preferredScreenEdgesDeferringSystemGestures
 * }
 *
 * override var prefersHomeIndicatorAutoHidden: Bool {
 *     return TwinSkin.uiKit.prefersHomeIndicatorAutoHidden
 * }
 * ```
 *
 * The integrator's wrapper should additionally call
 * `setNeedsUpdateOfScreenEdgesDeferringSystemGestures()` +
 * `setNeedsUpdateOfHomeIndicatorAutoHidden()` whenever the editor
 * is mounted or unmounted, so UIKit re-reads the properties promptly
 * instead of waiting for the next layout pass.
 */
public object TwinSkinUiKit {

    /**
     * The orientation mask captured at the moment the first
     * annotation-editor session entered. Mutated only from the
     * main thread via [captureEntryOrientation] before the
     * counter increments (same call site, same thread).
     */
    private var entryMask: UIInterfaceOrientationMask = UIInterfaceOrientationMaskAll

    /**
     * The orientation mask the integrator should return from
     * `supportedInterfaceOrientationsFor`. Defaults to
     * `UIInterfaceOrientationMaskAll` when no annotation-editor
     * session is active (the host app's normal orientation rules
     * apply); switches to the **entry-time orientation** of the
     * outermost active session for as long as that session lives
     * (spec §13.5 — the canvas geometry must not change
     * mid-session, regardless of which physical orientation the
     * clinician was holding the device in when they opened the
     * editor).
     *
     * "Active session" is tracked via [OrientationLockCounter] —
     * a re-entrant depth counter the annotation editor's
     * `LockOrientationDuringSession()` composable increments on
     * enter and decrements on dispose.
     */
    public val preferredOrientationMask: UIInterfaceOrientationMask
        get() = when {
            // Capture (photosphere + accelerometer) is portrait-only on
            // every device — the camera pixel path and the on-device
            // guidance geometry both assume an upright frame. While a
            // capture VC is on screen this wins over the editor's
            // entry-orientation freeze (the two are mutually exclusive
            // in practice; capture never nests inside the editor).
            captureLockDepth > 0 -> UIInterfaceOrientationMaskPortrait
            OrientationLockCounter.depth > 0 -> entryMask
            else -> UIInterfaceOrientationMaskAll
        }

    /**
     * Re-entrant depth of the SDK's capture-flow portrait lock. Raised
     * by [enterCaptureOrientationLock] when a capture VC mounts and
     * lowered by [exitCaptureOrientationLock] on unmount. Mutated only
     * from the main thread (the iOS capture VC lifecycle runs there).
     */
    private var captureLockDepth: Int = 0

    /**
     * Called by the iOS capture VC when it mounts. While the depth is
     * > 0, [preferredOrientationMask] reports portrait so a host that
     * forwarded the mask from `supportedInterfaceOrientationsFor`
     * keeps the device upright for the whole capture. The presented
     * VC's own `supportedInterfaceOrientations` override is the
     * fallback for hosts that did NOT wire the AppDelegate forwarder.
     */
    public fun enterCaptureOrientationLock() {
        captureLockDepth++
    }

    /** Lowers the capture lock on unmount. Capped at zero. */
    public fun exitCaptureOrientationLock() {
        if (captureLockDepth > 0) captureLockDepth--
    }

    /**
     * Called by `Orientation.ios.kt::LockOrientationDuringSession`
     * before [OrientationLockCounter.enter]. On the **outermost**
     * enter (depth 0 → 1) we snapshot the current interface
     * orientation; nested enters preserve that snapshot so the
     * lock semantics are "freeze the outermost session's entry
     * orientation", not "follow rotation across nested sessions".
     */
    internal fun captureEntryOrientation() {
        if (OrientationLockCounter.depth == 0) {
            entryMask = currentInterfaceOrientationMask()
        }
    }

    /**
     * The screen-edge mask the integrator should return from
     * `preferredScreenEdgesDeferringSystemGestures`. Returns
     * `UIRectEdgeAll` while an editor session is active (the user
     * has to swipe twice from any edge before the system gesture
     * fires — the first swipe lands in the editor), `UIRectEdgeNone`
     * otherwise (host app's normal gesture rules apply).
     *
     * Active session is tracked via [SystemGesturesLockCounter] —
     * a re-entrant depth counter the annotation editor's
     * `DeferSystemGesturesDuringSession()` composable increments on
     * enter and decrements on dispose.
     */
    public val preferredScreenEdgesDeferringSystemGestures: UIRectEdge
        get() = if (SystemGesturesLockCounter.depth > 0) UIRectEdgeAll else UIRectEdgeNone

    /**
     * Whether the host's `prefersHomeIndicatorAutoHidden` should
     * return `true` (home-indicator bar hidden during the editor
     * session). Hiding the bar reduces the area at the bottom of
     * the screen where a long upward swipe is interpreted as the
     * home gesture instead of a stroke point.
     */
    public val prefersHomeIndicatorAutoHidden: Boolean
        get() = SystemGesturesLockCounter.depth > 0
}

/**
 * Reads the current interface orientation from the active
 * [UIWindowScene] and maps it to the matching single-orientation
 * mask. If no scene is reachable at this instant (early launch,
 * scene-detach race), the lock degrades to a no-op
 * (`UIInterfaceOrientationMaskAll`) rather than guessing portrait —
 * a wrong guess would force-rotate a landscape host out of its
 * orientation, which is the opposite of "lock the entry orientation".
 */
private fun currentInterfaceOrientationMask(): UIInterfaceOrientationMask {
    val scenes = UIApplication.sharedApplication.connectedScenes
    val windowScene = scenes
        .filterIsInstance<UIWindowScene>()
        .firstOrNull()
        ?: return UIInterfaceOrientationMaskAll
    return when (windowScene.interfaceOrientation) {
        UIInterfaceOrientationLandscapeLeft -> UIInterfaceOrientationMaskLandscapeLeft
        UIInterfaceOrientationLandscapeRight -> UIInterfaceOrientationMaskLandscapeRight
        UIInterfaceOrientationPortraitUpsideDown -> UIInterfaceOrientationMaskPortraitUpsideDown
        UIInterfaceOrientationPortrait -> UIInterfaceOrientationMaskPortrait
        else -> UIInterfaceOrientationMaskAll
    }
}

/**
 * Extension property mirroring [TwinSkinSdk.iosBackground]'s shape.
 * iOS integrators access the UIKit hooks via
 * `TwinSkin.uiKit.preferredOrientationMask` from their `AppDelegate`.
 */
public val TwinSkinSdk.uiKit: TwinSkinUiKit get() = TwinSkinUiKit
