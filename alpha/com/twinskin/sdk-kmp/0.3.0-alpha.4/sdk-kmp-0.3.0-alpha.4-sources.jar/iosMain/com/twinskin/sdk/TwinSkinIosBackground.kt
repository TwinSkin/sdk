@file:OptIn(ExperimentalForeignApi::class)

package com.twinskin.sdk

import com.twinskin.sdk.transfer.BackgroundTransferHandler
import com.twinskin.sdk.transfer.CAPTURE_URL_SESSION_IDENTIFIER
import com.twinskin.sdk.transfer.IosBackgroundScheduler
import kotlinx.cinterop.ExperimentalForeignApi

/**
 * iOS-only integrator hooks for background-transfer lifecycle. The
 * SDK does the heavy wiring inside [TwinSkinSdk.initialize]; the host
 * app only needs to forward two callbacks the iOS framework
 * surfaces in `AppDelegate`.
 *
 * ## Required AppDelegate plumbing
 *
 * 1. Register the BGProcessingTask handler **before**
 *    `application(_:didFinishLaunchingWithOptions:)` returns:
 *
 *    ```swift
 *    BGTaskScheduler.shared.register(
 *        forTaskWithIdentifier: TwinSkin.iosBackground.bgTaskIdentifier,
 *        using: nil
 *    ) { task in
 *        TwinSkin.iosBackground.handleBgTaskWakeup()
 *        task.setTaskCompleted(success: true)
 *    }
 *    ```
 *
 * 2. Forward `handleEventsForBackgroundURLSession`:
 *
 *    ```swift
 *    func application(
 *        _ application: UIApplication,
 *        handleEventsForBackgroundURLSession identifier: String,
 *        completionHandler: @escaping () -> Void
 *    ) {
 *        TwinSkin.iosBackground.handleBackgroundUrlSessionEvents(
 *            identifier: identifier,
 *            completionHandler: completionHandler
 *        )
 *    }
 *    ```
 *
 * Add `TwinSkin.iosBackground.bgTaskIdentifier` to your Info.plist
 * under `BGTaskSchedulerPermittedIdentifiers`. The matching
 * `Info.plist` snippet shipped with the iosApp demo is the
 * canonical example.
 */
public val TwinSkinSdk.iosBackground: TwinSkinIosBackground get() = TwinSkinIosBackground

public object TwinSkinIosBackground {
    /**
     * Identifier the integrator's `BGTaskScheduler.register` call must
     * pass. Also the value to add to `BGTaskSchedulerPermittedIdentifiers`
     * in Info.plist.
     */
    public val bgTaskIdentifier: String get() = IosBackgroundScheduler.taskIdentifier

    /**
     * Identifier of the background `NSURLSession` the SDK uses for capture
     * uploads. Hosts that multiplex
     * `application(_:handleEventsForBackgroundURLSession:completionHandler:)`
     * across several frameworks (e.g. a Flutter plugin) can match on this
     * value before forwarding to [handleBackgroundUrlSessionEvents], so
     * sessions owned by other plugins stay with their owners.
     */
    public val urlSessionIdentifier: String get() = CAPTURE_URL_SESSION_IDENTIFIER

    /**
     * Called from the integrator's BGProcessingTask handler. Re-runs
     * pending uploads while iOS is keeping the app alive.
     */
    public fun handleBgTaskWakeup() {
        BackgroundTransferHandler.handleUploadRetryTask()
    }

    /**
     * Forwarded from
     * `application(_:handleEventsForBackgroundURLSession:completionHandler:)`.
     * Reconnects the background NSURLSession so iOS can replay any
     * pending delegate callbacks; calls [completionHandler] once
     * delivery completes.
     */
    public fun handleBackgroundUrlSessionEvents(
        identifier: String,
        completionHandler: () -> Unit,
    ) {
        BackgroundTransferHandler.handleBackgroundEvents(identifier, completionHandler)
    }
}
