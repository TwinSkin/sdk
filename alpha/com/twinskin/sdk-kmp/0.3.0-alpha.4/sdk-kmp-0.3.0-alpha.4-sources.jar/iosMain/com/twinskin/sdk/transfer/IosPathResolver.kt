package com.twinskin.sdk.transfer

import platform.Foundation.NSHomeDirectory

/**
 * iOS [PathResolver] that stores paths relative to the app's home directory.
 *
 * The iOS app container path (`/var/mobile/Containers/Data/Application/[UUID]/`)
 * changes when the app is reinstalled, restored from backup, or sometimes updated.
 * Storing absolute paths in the database would silently break all persisted transfers
 * after such an event.
 *
 * This resolver strips the home directory prefix when writing to the DB ([toStorage])
 * and prepends the current home directory when reading back ([fromStorage]).
 *
 * ## Example
 * ```
 * // Launch 1: NSHomeDirectory() = "/var/mobile/.../A1B2C3D4/"
 * toStorage("/var/mobile/.../A1B2C3D4/Documents/photo.jpg")
 *   → "Documents/photo.jpg"
 *
 * // Launch 2 (after reinstall): NSHomeDirectory() = "/var/mobile/.../E5F6G7H8/"
 * fromStorage("Documents/photo.jpg")
 *   → "/var/mobile/.../E5F6G7H8/Documents/photo.jpg"
 * ```
 *
 * Paths that do NOT start with the home directory (e.g. `/tmp/` or external paths)
 * are stored as-is — [toStorage] is a no-op for those, and [fromStorage] returns
 * them unchanged.
 */
internal class IosPathResolver : PathResolver {

    // Snapshot once — NSHomeDirectory() is stable within a single process lifetime.
    // Ends with "/" for reliable prefix matching.
    private val homeDir: String = NSHomeDirectory().let { home ->
        if (home.endsWith("/")) home else "$home/"
    }

    override fun toStorage(absolutePath: String): String =
        if (absolutePath.startsWith(homeDir)) {
            absolutePath.removePrefix(homeDir)
        } else {
            absolutePath
        }

    override fun fromStorage(storagePath: String): String =
        if (storagePath.startsWith("/")) {
            // Already absolute (external path or legacy entry) — return as-is.
            storagePath
        } else {
            // Relative path — prepend current home directory.
            "$homeDir$storagePath"
        }
}
