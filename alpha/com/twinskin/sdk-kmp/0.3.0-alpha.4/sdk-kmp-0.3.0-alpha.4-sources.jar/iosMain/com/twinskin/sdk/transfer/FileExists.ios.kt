package com.twinskin.sdk.transfer

import platform.Foundation.NSFileManager

internal actual fun fileExists(path: String): Boolean =
    NSFileManager.defaultManager.fileExistsAtPath(path)
