@file:OptIn(
    ExperimentalForeignApi::class,
    kotlinx.cinterop.BetaInteropApi::class,
    com.twinskin.sdk.TwinSkinInternalApi::class,
)

package com.twinskin.sdk.view

import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.onDownload
import io.ktor.client.request.header
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.bodyAsChannel
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import io.ktor.http.isSuccess
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.readAvailable
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.ObjCObjectVar
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.alloc
import kotlinx.cinterop.autoreleasepool
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.usePinned
import kotlinx.cinterop.value
import platform.Foundation.NSData
import platform.Foundation.NSError
import platform.Foundation.NSFileHandle
import platform.Foundation.NSFileManager
import platform.Foundation.NSURL
import platform.Foundation.dataWithBytesNoCopy
import platform.Foundation.fileHandleForWritingAtPath
import platform.posix.rename

// socketTimeoutMillis bounds time *between* bytes — the trap we hit
// otherwise is NSURLSession's `timeoutIntervalForResource` default of 7
// days, which means a mid-stream stall freezes the UI's progress bar
// indefinitely. requestTimeoutMillis is left null because legitimate
// downloads of multi-MB GLBs over slow LTE can outlast any reasonable cap.
private val client = HttpClient {
    install(HttpTimeout) {
        requestTimeoutMillis = null
        socketTimeoutMillis = 60_000L
        connectTimeoutMillis = 30_000L
    }
}

public actual fun cachedFileExists(path: String): Boolean {
    val fm = NSFileManager.defaultManager
    if (!fm.fileExistsAtPath(path)) return false
    val attrs = fm.attributesOfItemAtPath(path, null) ?: return false
    val size = attrs[platform.Foundation.NSFileSize] as? platform.Foundation.NSNumber
    return (size?.longLongValue ?: 0L) > 0L
}

public actual suspend fun downloadToPath(
    url: String,
    destPath: String,
    headers: Map<String, String>,
    onProgress: (bytesRead: Long, total: Long?) -> Unit,
) {
    // No `withContext(Dispatchers.IO)` here, unlike the Android actual:
    // - `Dispatchers.IO` is `internal` in kotlinx-coroutines' Native build, so
    //   we can't reach it from iosMain.
    // - ktor's Darwin engine performs HTTP I/O on `NSURLSession`'s private
    //   serial queue, not on our coroutine dispatcher.
    // - The only work that lands on the caller's dispatcher is the
    //   `NSFileHandle.writeData` call per chunk, which is a fast buffered
    //   kernel syscall (~microseconds for 64 KB).
    // Net: wrapping here would add synchronization cost without measurable
    // latency benefit on Native. Reassess if profiling shows Default-pool
    // starvation under concurrent downloads.

    // Stream into a sibling `.partial` file and atomically rename on
    // success. Without this, a process kill mid-download leaves a truncated
    // file at `destPath` that `cachedFileExists` happily reports as a hit
    // on next launch — handing the renderer a corrupt GLB.
    val partialPath = "$destPath.partial"

    // ktor's `HttpStatement.execute { block }` requires the lambda to
    // either fully consume the response body or hit the body-channel's
    // cancel path. Returning without doing so leaves `cleanup()` (in the
    // execute `finally`) suspended forever on `body.join()` — `execute`
    // never returns to us. Throwing from inside the block hits the same
    // suspended cleanup. So on every non-2xx path we drain the body
    // first, then return the error and throw outside execute.
    val error: Throwable? = client.prepareGet(url) {
        headers.forEach { (name, value) -> header(name, value) }
        onDownload { bytesSentTotal, contentLength ->
            onProgress(bytesSentTotal, contentLength)
        }
    }.execute { response ->
        when {
            response.status == HttpStatusCode.NotFound -> {
                runCatching { response.bodyAsText() }
                CaptureNotFoundException("$url returned 404")
            }
            !response.status.isSuccess() -> {
                val body = runCatching { response.bodyAsText() }.getOrDefault("")
                CaptureNetworkException(
                    "$url returned ${response.status.value}: $body",
                )
            }
            else -> {
                writeBodyToPath(partialPath, response.bodyAsChannel())
                null
            }
        }
    }
    if (error != null) {
        NSFileManager.defaultManager.removeItemAtPath(partialPath, null)
        throw error
    }
    renamePartialToDest(partialPath, destPath)
}

private suspend fun writeBodyToPath(destPath: String, channel: ByteReadChannel) {
    val fm = NSFileManager.defaultManager
    val parent = NSURL.fileURLWithPath(destPath).URLByDeletingLastPathComponent
    if (parent != null) {
        fm.createDirectoryAtURL(parent, true, null, null)
    }
    if (fm.fileExistsAtPath(destPath)) fm.removeItemAtPath(destPath, null)
    fm.createFileAtPath(destPath, null, null)

    // Stream chunks straight to an NSFileHandle rather than buffering the
    // whole body — avoids OOM on 10-20+ MB wound captures.
    val handle = NSFileHandle.fileHandleForWritingAtPath(destPath)
        ?: throw CaptureNetworkException("Failed to open $destPath for writing")

    var ok = false
    try {
        val buffer = ByteArray(64 * 1024)
        while (true) {
            val read = channel.readAvailable(buffer, 0, buffer.size)
            if (read < 0) break
            if (read == 0) continue
            // Per-iteration autorelease pool: `dataWithBytesNoCopy` returns an
            // autoreleased NSData. Kotlin/Native worker threads don't run a
            // CFRunLoop, so without an explicit pool the NSData wrappers
            // accumulate until this function returns — for a 10 MB body at
            // 64 KB chunks that's ~160 lingering objects (~10 MB resident).
            // On constrained devices that triggers memory pressure and the
            // OS throttles NSURLSession, which manifests as the progress
            // bar freezing mid-stream. Pool drains each iteration.
            //
            // `freeWhenDone = false` because the underlying memory is the
            // pinned ByteArray, freed by `usePinned` when the inner block
            // exits — `writeData` consumes synchronously, so the pin
            // outlives the kernel write.
            autoreleasepool {
                buffer.usePinned { pinned ->
                    val data = NSData.dataWithBytesNoCopy(
                        bytes = pinned.addressOf(0),
                        length = read.toULong(),
                        freeWhenDone = false,
                    )
                    memScoped {
                        val errorRef = alloc<ObjCObjectVar<NSError?>>()
                        if (!handle.writeData(data, errorRef.ptr)) {
                            val err = errorRef.value
                            throw CaptureNetworkException(
                                "Failed to write to $destPath: " +
                                    (err?.localizedDescription ?: "unknown error"),
                            )
                        }
                    }
                }
            }
        }
        ok = true
    } finally {
        // closeAndReturnError replaces the deprecated dealloc-flush path: we
        // surface a final flush error as an exception instead of silently
        // returning success and handing the renderer a truncated GLB.
        memScoped {
            val errorRef = alloc<ObjCObjectVar<NSError?>>()
            val closed = handle.closeAndReturnError(errorRef.ptr)
            if (ok && !closed) {
                val err = errorRef.value
                throw CaptureNetworkException(
                    "Failed to close $destPath: ${err?.localizedDescription ?: "unknown error"}",
                )
            }
        }
        if (!ok) {
            // Drop the half-written `.partial` so a future retry starts clean.
            fm.removeItemAtPath(destPath, null)
        }
    }
}

private fun renamePartialToDest(partialPath: String, destPath: String) {
    // POSIX `rename(2)` is atomic on the same filesystem and overwrites the
    // destination — exactly the swap we need, and both paths live under the
    // same cacheDir so we're guaranteed same-filesystem.
    if (rename(partialPath, destPath) != 0) {
        val errno = platform.posix.errno
        // Best effort cleanup so a subsequent attempt isn't blocked by the
        // stale partial.
        NSFileManager.defaultManager.removeItemAtPath(partialPath, null)
        throw CaptureNetworkException(
            "Failed to rename $partialPath → $destPath (errno=$errno)",
        )
    }
}
