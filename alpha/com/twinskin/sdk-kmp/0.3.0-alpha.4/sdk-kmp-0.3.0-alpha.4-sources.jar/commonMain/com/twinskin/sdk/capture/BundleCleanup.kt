package com.twinskin.sdk.capture

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.db.TransferTask
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.storage.SdkStorage
import com.twinskin.sdk.transfer.TransferManager
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.TransferType
import kotlinx.coroutines.flow.collect

/**
 * Sweep [Purpose.EncryptedBundles] keeping only files referenced by an
 * upload task that's still in flight or eligible for retry (PENDING,
 * ACTIVE, FAILED). Every other file — bundles whose upload reached
 * COMPLETED/CANCELLED, plus orphans with no DB row — is deleted.
 *
 * FAILED is kept because the user can still trigger a retry; PENDING
 * and ACTIVE are obviously still needed. UNZIPPING never applies to
 * uploads in practice.
 */
internal fun pruneBundles(
    storage: SdkStorage,
    tasks: List<TransferTask>,
    logger: SdkLogger,
) {
    val bundlesDir = storage.dir(Purpose.EncryptedBundles)
    val keepPaths: Set<String> = tasks.asSequence()
        .filter { it.type == TransferType.UPLOAD.name }
        .filter { task ->
            task.status == TransferStatus.PENDING.name ||
                task.status == TransferStatus.ACTIVE.name ||
                task.status == TransferStatus.FAILED.name
        }
        .map { it.localPath }
        .toSet()
    storage.wipe(Purpose.EncryptedBundles, logger) { name ->
        "$bundlesDir/$name" !in keepPaths
    }
}

/**
 * Subscribe to [TransferManager.observeAllTasks] and re-run
 * [pruneBundles] on every emission so terminal uploads' bundle files
 * are deleted promptly. The first emission also handles startup
 * recovery — anything left COMPLETED by a background worker while the
 * app was dead is cleaned up on next launch.
 *
 * Suspends forever; call from a long-lived coroutine.
 */
internal suspend fun observeAndPruneBundles(
    storage: SdkStorage,
    transferManager: TransferManager,
    logger: SdkLogger,
) {
    transferManager.observeAllTasks().collect { tasks ->
        pruneBundles(storage, tasks, logger)
    }
}
