// GENERATED CODE — DO NOT EDIT BY HAND
// Source: lib/src/capture_processing/capture_pipeline_models.dart
// Regenerate: fvm dart run tool/generate_kotlin_sdk_client.dart

package com.twinskin.sdk.capture

import com.twinskin.sdk.sdk_client.Point2D
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonClassDiscriminator

@Serializable
@JsonClassDiscriminator("type")
public sealed class SdkMeasurement

@Serializable
@SerialName("generic")
public data class GenericMeasurement(
    @SerialName("regions") val regions: List<RegionMeasurement>
) : SdkMeasurement()

@Serializable
@SerialName("wound")
public data class WoundMeasurement(
    @SerialName("regions") val regions: List<WoundRegionMeasurement>
) : SdkMeasurement()

@Serializable
public data class RegionMeasurement(
    @SerialName("surface_mm2") val surfaceMm2: Double,
    @SerialName("perimeter_mm") val perimeterMm: Double? = null,
    @SerialName("volume_mm3") val volumeMm3: Double? = null,
    @SerialName("max_depth_mm") val maxDepthMm: Double? = null
)

@Serializable
public data class WoundRegionMeasurement(
    @SerialName("surface_mm2") val surfaceMm2: Double,
    @SerialName("perimeter_mm") val perimeterMm: Double? = null,
    @SerialName("volume_mm3") val volumeMm3: Double? = null,
    @SerialName("max_depth_mm") val maxDepthMm: Double? = null,
    @SerialName("length") val length: Segment? = null,
    @SerialName("width") val width: Segment? = null,
    @SerialName("depth") val depth: Segment? = null,
    @SerialName("tissues") val tissues: List<TissueMeasurement> = emptyList()
)

@Serializable
public data class Segment(
    @SerialName("a") val a: Point2D,
    @SerialName("b") val b: Point2D,
    @SerialName("physical_length") val physicalLength: Double
)

@Serializable
public data class TissueMeasurement(
    @SerialName("tissue_type") val tissueType: String,
    @SerialName("surface_mm2") val surfaceMm2: Double
)
