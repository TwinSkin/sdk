package com.twinskin.sdk

public interface Platform {
    public val name: String
}

public expect fun getPlatform(): Platform
