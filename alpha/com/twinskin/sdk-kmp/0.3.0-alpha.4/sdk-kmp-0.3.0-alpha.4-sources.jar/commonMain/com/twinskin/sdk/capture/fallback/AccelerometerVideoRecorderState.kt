package com.twinskin.sdk.capture.fallback

internal enum class AccelerometerVideoRecorderState {
    Idle,
    Started,
    Stopping,
    Stopped,
    Errored,
}

internal enum class AccelerometerVideoRecorderAction {
    None,
    NativeStart,
    NativeStop,
    NativeAbort,
}

/** Recorder is not reusable: a second `start()` or `stop()` from a terminal state throws. */
internal class AccelerometerVideoRecorderStateMachine(
    private val partialFileCleanup: (String) -> Unit = {},
) {
    private var _state: AccelerometerVideoRecorderState = AccelerometerVideoRecorderState.Idle
    val state: AccelerometerVideoRecorderState get() = _state

    private var partialFilePath: String? = null

    fun requestStart(): AccelerometerVideoRecorderAction {
        check(_state == AccelerometerVideoRecorderState.Idle) {
            "AccelerometerVideoRecorder.start() called in state $_state — recorder is not reusable"
        }
        _state = AccelerometerVideoRecorderState.Started
        return AccelerometerVideoRecorderAction.NativeStart
    }

    fun requestStop(): AccelerometerVideoRecorderAction {
        check(_state == AccelerometerVideoRecorderState.Started) {
            "AccelerometerVideoRecorder.stop() called in state $_state — only Started is valid"
        }
        _state = AccelerometerVideoRecorderState.Stopping
        return AccelerometerVideoRecorderAction.NativeStop
    }

    fun requestCancel(): AccelerometerVideoRecorderAction = when (_state) {
        AccelerometerVideoRecorderState.Idle,
        AccelerometerVideoRecorderState.Stopped,
        AccelerometerVideoRecorderState.Errored,
        -> AccelerometerVideoRecorderAction.None
        AccelerometerVideoRecorderState.Started,
        AccelerometerVideoRecorderState.Stopping,
        -> {
            _state = AccelerometerVideoRecorderState.Errored
            partialFilePath?.let { path ->
                // Swallow cleanup throws so the cancel transition is
                // still observable to the caller — the platform impl
                // already best-effort-deletes; this seam mirrors that.
                try { partialFileCleanup(path) } catch (_: Throwable) {}
            }
            partialFilePath = null
            AccelerometerVideoRecorderAction.NativeAbort
        }
    }

    fun trackPartialFile(path: String) {
        partialFilePath = path
    }

    fun markStopped() {
        _state = AccelerometerVideoRecorderState.Stopped
        partialFilePath = null
    }

    fun markErrored() {
        _state = AccelerometerVideoRecorderState.Errored
        partialFilePath = null
    }
}
