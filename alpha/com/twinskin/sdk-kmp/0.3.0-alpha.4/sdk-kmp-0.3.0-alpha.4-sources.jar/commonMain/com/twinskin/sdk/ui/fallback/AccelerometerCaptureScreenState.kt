package com.twinskin.sdk.ui.fallback

import com.twinskin.sdk.capture.fallback.Pie

/**
 * The four operator-visible phases of the accelerometer-capture capture flow,
 * plus terminal `Error` and the in-between `Submitting` upload state.
 *
 * Mirrors the web_app's `CompleteCaptureScreen` mental model
 * (`packages/web_app/lib/src/app/mobile/camera/complete_capture_screen.dart`):
 * frame -> shoot still -> orbit 20 s -> hand off bundle. The SDK
 * uses a sealed-class state instead of the web_app's bag of booleans
 * so unit tests can pin every transition.
 *
 * Transition table:
 *
 * | From            | Trigger                              | To              |
 * |-----------------|--------------------------------------|-----------------|
 * | [Initializing]  | permissions granted + camera ready   | [ReadyForPhoto] |
 * | [ReadyForPhoto] | shutter tap (`takeStillPhoto()`)     | [PhotoTaken]    |
 * | [PhotoTaken]    | shutter tap (`startRecording()`)     | [RecordingVideo]|
 * | [RecordingVideo]| stop tap OR 20 s timer               | [Submitting]    |
 * | [Submitting]    | bundle uploaded                      | screen finishes |
 * | any             | unrecoverable error                  | [Error]         |
 */
public sealed class AccelerometerCaptureScreenState {

    /** Permissions and camera bind are in flight. */
    public data object Initializing : AccelerometerCaptureScreenState()

    /** Preview is live; tapping the shutter takes the single still. */
    public data object ReadyForPhoto : AccelerometerCaptureScreenState()

    /**
     * The still photo has been captured to [stillPath]; the screen is
     * ready for the operator's second tap, which starts the 20 s
     * recording.
     *
     * @param lowLight presentation-only luminance verdict on the still. `true`
     *        raises the non-blocking torch-on / retake card; the operator can
     *        always proceed regardless. Never written to [VideoMetaData] or the
     *        bundle.
     * @param markerDetected presentation-only marker verdict on the still. `true`
     *        (the default, and what a controller with no marker probe emits)
     *        renders no warning; `false` raises the non-blocking
     *        [MarkerWarningCard]. Never written to [VideoMetaData] or the bundle
     *        (parity-safe by construction).
     */
    public data class PhotoTaken(
        val stillPath: String,
        val lowLight: Boolean = false,
        val markerDetected: Boolean = true,
    ) : AccelerometerCaptureScreenState()

    /**
     * Recording is in flight.
     *
     * @param elapsedMs ticks once per timer pulse — drives the draining time arc.
     * @param pie the [com.twinskin.sdk.capture.fallback.AccelerometerDriver]'s
     *        latest 8-sector coverage snapshot.
     * @param guidance presentation-only heading / speed / tilt signal. `null`
     *        (the default) renders exactly the coverage ring + count + time. Never
     *        written to [com.twinskin.sdk.capture.fallback.VideoMetaData] or the
     *        bundle (parity-safe by construction).
     */
    public data class RecordingVideo(
        val elapsedMs: Long,
        val pie: Pie,
        val guidance: GuidanceSnapshot? = null,
    ) : AccelerometerCaptureScreenState() {

        /** Whole seconds remaining of the fixed 20 s window — shown in the rec timer. */
        public val remainingSeconds: Int
            get() = ((VIDEO_CAPTURE_DURATION_MS - elapsedMs).coerceAtLeast(0L) / 1000L).toInt()

        /** 1f at start → 0f at the 20 s mark; drives the draining time arc. */
        public val remainingFraction: Float
            get() = ((VIDEO_CAPTURE_DURATION_MS - elapsedMs).toFloat() / VIDEO_CAPTURE_DURATION_MS)
                .coerceIn(0f, 1f)

        /**
         * Fires the one-shot completion burst.
         *
         * **Driven only by the real stop** (`elapsedMs >= VIDEO_CAPTURE_DURATION_MS`),
         * NOT by `pie.all { it }`. The [AccelerometerCaptureController] ends
         * recording only at the 20 s timer — filling 8/8 sectors early does NOT
         * transition to [Submitting] — so a pie-based check would flip the dial to
         * green while the countdown is still running. The burst must match the
         * actual `RecordingVideo → Submitting` boundary.
         */
        public val isComplete: Boolean
            get() = elapsedMs >= VIDEO_CAPTURE_DURATION_MS
    }

    /**
     * Bundle is being packed and uploaded. [progressPercent] is the
     * byte-level upload progress once the transfer is running; `null`
     * during the bundle-pack window.
     */
    public data class Submitting(val progressPercent: Int?) : AccelerometerCaptureScreenState()

    /**
     * Terminal error. Cancel + retake-from-phase-1 is the only
     * recovery path in v1 — mid-recording recovery (open question on
     * #504) is parked.
     */
    public data class Error(val message: String) : AccelerometerCaptureScreenState()
}

/**
 * Recording duration is fixed at 20 s in v1 to match the web_app
 * default. A `TwinSkinConfiguration.videoCaptureDurationMs` knob is
 * parked for Capture v2.1; if integrators ask we add it then.
 */
public const val VIDEO_CAPTURE_DURATION_MS: Long = 20_000L

/**
 * Cadence the `RecordingVideo` timer ticks at. Drives the countdown
 * ring's progress fraction (`elapsedMs / VIDEO_CAPTURE_DURATION_MS`).
 * Public so the iOS Swift bridge can read it as a Swift-side
 * constant without re-deriving the cadence per platform.
 */
public const val VIDEO_CAPTURE_TIMER_TICK_MS: Long = 50L
