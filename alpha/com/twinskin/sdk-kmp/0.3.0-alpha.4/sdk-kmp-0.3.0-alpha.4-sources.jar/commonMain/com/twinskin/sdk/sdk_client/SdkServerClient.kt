package com.twinskin.sdk.sdk_client

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.SdkAnnotation
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpResponseValidator
import io.ktor.client.plugins.HttpSend
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.plugin
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpHeaders
import io.ktor.http.isSuccess
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.Json

/**
 * Per-subject HttpClient lifecycle around the generated
 * [SdkUploadClient]: auth-header injection, 401 retry, JSON
 * negotiation, and error-envelope translation.
 *
 * Each subjectRef gets its own HttpClient so the [HttpSend]
 * interceptor captures the bound subjectRef and calls
 * [SdkAuthorizationProvider.fetchSessionToken] fresh on every
 * `execute(...)` — load-bearing for the 401 retry path.
 *
 * Tests inject an [httpClient] and reuse it across subjects; auth
 * install is skipped since the stubbed responses ignore headers.
 *
 * **When you add a new method here**, also add a case to the Dart
 * cross-SDK integration test at
 * `packages/server/integration_test/api/sdk/sdk_client_jvm_test.dart`
 * (+ the matching subcommand in `SdkClientCli.kt`).
 */
internal open class SdkServerClient(
    internal val baseUrl: String,
    internal val publishableKey: String,
    internal val auth: SdkAuthorizationProvider,
    private val logger: SdkLogger? = null,
    httpClient: HttpClient? = null,
) {
    private val ownsClient = httpClient == null

    /**
     * Bare HttpClient with no auth install. Used by
     * `DemoCaptureRepository`, which authenticates manually.
     */
    internal val client: HttpClient = httpClient ?: HttpClient {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    internal val apiBaseUrl: String = "${baseUrl.trimEnd('/')}$SDK_API_PATH"

    private class SubjectScopedClient(
        val http: HttpClient,
        val upload: SdkUploadClient,
        val ownsHttp: Boolean,
    )

    private val perSubject = mutableMapOf<String, SubjectScopedClient>()

    // [uploadFor] runs from multiple coroutines (UI for
    // submitAnnotation, transfer-manager dispatcher for startCapture
    // retries); `mutableMapOf().getOrPut` is unsynchronised.
    private val perSubjectLock = Mutex()

    private suspend fun uploadFor(subjectRef: String): SdkUploadClient =
        perSubjectLock.withLock {
            perSubject.getOrPut(subjectRef) { buildSubjectScoped(subjectRef) }.upload
        }

    private fun buildSubjectScoped(subjectRef: String): SubjectScopedClient {
        if (!ownsClient) {
            return SubjectScopedClient(
                http = client,
                upload = SdkUploadClient(client, apiBaseUrl),
                ownsHttp = false,
            )
        }
        val http = HttpClient {
            install(ContentNegotiation) {
                json(Json { ignoreUnknownKeys = true })
            }
            HttpResponseValidator {
                validateResponse { response ->
                    if (!response.status.isSuccess()) {
                        throw SdkServerException(
                            response.status.value,
                            response.bodyAsText(),
                        )
                    }
                }
            }
        }.also { c ->
            // Auth lives inside the Send phase so the 401-driven
            // replay re-fetches the token: a Ktor plugin's
            // `onRequest` only fires on the first execute, and
            // `HttpSend.Sender.execute(request)` bypasses upstream
            // phases on the retry.
            c.plugin(HttpSend).intercept { request ->
                suspend fun applyAuth() {
                    val token = auth.fetchAndParseSessionToken(subjectRef, logger).token
                    request.headers[HttpHeaders.Authorization] = "Bearer $token"
                    request.headers["X-Publishable-Key"] = publishableKey
                }
                applyAuth()
                var call = execute(request)
                if (call.response.status.value == 401) {
                    applyAuth()
                    call = execute(request)
                }
                call
            }
        }
        return SubjectScopedClient(
            http = http,
            upload = SdkUploadClient(http, apiBaseUrl),
            ownsHttp = true,
        )
    }

    open suspend fun startCapture(
        request: SdkStartCaptureRequest,
    ): SdkStartCaptureResponse = uploadFor(request.subjectRef).startCapture(request)

    /**
     * Submit a discriminated-union annotation for an existing capture.
     * The server allocates a new measurement revision per call;
     * submitting again supersedes the previous one.
     */
    open suspend fun submitAnnotation(
        captureId: String,
        subjectRef: String,
        annotation: SdkAnnotation,
    ): SubmitAnnotationResponse =
        uploadFor(subjectRef).submitAnnotation(
            SubmitAnnotationRequest(captureId = captureId, annotation = annotation),
        )

    /**
     * Releases every per-subject HttpClient plus the bare [client] if
     * this instance owns them. Acquires [perSubjectLock] so it can't
     * race with an in-flight [uploadFor].
     */
    suspend fun close() {
        perSubjectLock.withLock {
            for (entry in perSubject.values) {
                if (entry.ownsHttp) entry.http.close()
            }
            perSubject.clear()
        }
        if (ownsClient) client.close()
    }
}

internal class SdkServerException(val statusCode: Int, val responseBody: String) :
    RuntimeException("SDK server returned $statusCode: $responseBody")

/**
 * URL prefix every Twinskin SDK HTTP API hangs off (sessions, upload,
 * status, asset, demo captures). Appended to [TwinSkinConfig.baseUrl] —
 * which is the server's scheme+host(+port) root — by the SDK internals.
 */
internal const val SDK_API_PATH: String = "/api/sdk"

internal typealias SdkStartCaptureRequest = StartCaptureRequest
internal typealias SdkStartCaptureResponse = StartCaptureResponse
internal typealias SdkDeviceInfo = DeviceInfo
