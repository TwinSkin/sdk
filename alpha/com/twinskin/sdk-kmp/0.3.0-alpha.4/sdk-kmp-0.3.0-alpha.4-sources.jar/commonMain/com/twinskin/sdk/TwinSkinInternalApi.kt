package com.twinskin.sdk

/**
 * Marks a TwinSkin SDK declaration as internal-but-publicly-visible.
 *
 * Symbols carrying this annotation are part of the SDK's *demo*
 * extension surface — used by `:demo-shared` to drive the storybook
 * UI catalog, fake resolvers, and annotation-editor playground — but
 * are NOT a stable integrator contract. Their signatures, semantics,
 * or existence may change in any minor release without a deprecation
 * cycle.
 *
 * Integrators should not opt in. If you find yourself needing one of
 * these symbols in production code, file an issue so we can curate
 * the right stable shape.
 */
@RequiresOptIn(
    level = RequiresOptIn.Level.ERROR,
    message = "This is an internal TwinSkin SDK API used only by the bundled demo " +
        "modules. It is not a stable integrator contract — use the documented " +
        "TwinSkin.* surface instead.",
)
@Retention(AnnotationRetention.BINARY)
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.FUNCTION,
    AnnotationTarget.PROPERTY,
    AnnotationTarget.TYPEALIAS,
    AnnotationTarget.CONSTRUCTOR,
)
public annotation class TwinSkinInternalApi
