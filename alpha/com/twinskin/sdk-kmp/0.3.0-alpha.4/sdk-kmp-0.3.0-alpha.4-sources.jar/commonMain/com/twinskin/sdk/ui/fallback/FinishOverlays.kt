package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.capture.i18n.LocalCaptureStrings

@Composable
public fun InitializingOverlay(
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    Box(
        modifier = modifier.fillMaxSize().background(colors.scrim),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = colors.orbit)
            Text(LocalCaptureStrings.current.initializing, color = colors.onPrimary,
                fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 16.dp))
        }
    }
}

@Composable
public fun PreparingOverlay(
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    FinishScrim(modifier) {
        CircularProgressIndicator(color = colors.orbit)
        Text(LocalCaptureStrings.current.preparing, color = colors.onSurface,
            fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 16.dp))
        Spacer(Modifier.height(6.dp))
        Text(LocalCaptureStrings.current.preparingDetail,
            color = colors.onSurfaceVariant, fontSize = 13.5.sp, textAlign = TextAlign.Center)
    }
}

@Composable
public fun BackgroundUploadOverlay(
    uploadPercent: Int,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    Box(modifier = modifier.fillMaxSize()) {
        FinishScrim(Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier.size(60.dp).border(2.5.dp, colors.progressComplete, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text("\u2713", color = colors.progressComplete, fontSize = 31.sp) }
            Text(LocalCaptureStrings.current.uploadCompleteTitle, color = colors.onSurface,
                fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 16.dp))
            Spacer(Modifier.height(6.dp))
            Text(LocalCaptureStrings.current.uploadCompleteDetail,
                color = colors.onSurfaceVariant, fontSize = 13.5.sp, textAlign = TextAlign.Center)

            Row(
                modifier = Modifier
                    .padding(top = 22.dp)
                    .background(colors.surfaceContainer, RoundedCornerShape(999.dp))
                    .border(1.dp, colors.outlineVariant, RoundedCornerShape(999.dp))
                    .padding(horizontal = 15.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(Modifier.size(8.dp).background(colors.orbit, CircleShape))
                Text(LocalCaptureStrings.current.uploading(uploadPercent.toString()), color = colors.onSurface,
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Box(
                    modifier = Modifier.width(56.dp).height(4.dp)
                        .background(colors.outlineVariant, RoundedCornerShape(3.dp)),
                ) {
                    Box(
                        Modifier.fillMaxWidth(fraction = (uploadPercent / 100f).coerceIn(0f, 1f))
                            .height(4.dp).background(colors.orbit, RoundedCornerShape(3.dp)),
                    )
                }
            }
        }
        BottomActionBar(modifier = Modifier.align(Alignment.BottomCenter)) {
            ActionButton(LocalCaptureStrings.current.uploadDone, primary = true, onClick = onDone, colors = colors, modifier = Modifier.weight(1f))
        }
    }
}

// onRetry is null because the capture controller exposes no reset/retry, so only Close is shown.
@Composable
public fun ErrorOverlay(
    message: String,
    onClose: () -> Unit,
    onRetry: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    Box(modifier = modifier.fillMaxSize().background(colors.errorScrim)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 30.dp, vertical = 100.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                modifier = Modifier.size(54.dp).border(2.dp, colors.error, CircleShape),
                contentAlignment = Alignment.Center,
            ) { Text("!", color = colors.error, fontSize = 30.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(16.dp))
            Text(LocalCaptureStrings.current.errorTitle, color = colors.onSurface, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text(message, color = colors.onSurfaceVariant, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        BottomActionBar(modifier = Modifier.align(Alignment.BottomCenter)) {
            ActionButton(LocalCaptureStrings.current.errorDismiss, primary = onRetry == null, onClick = onClose, colors = colors, modifier = Modifier.weight(1f))
            if (onRetry != null) {
                ActionButton(LocalCaptureStrings.current.errorRetry, primary = true, onClick = onRetry, colors = colors, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun FinishScrim(modifier: Modifier, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xCC060A0B), Color(0xED060A0B))))
            .padding(horizontal = 36.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
}

@Composable
private fun BottomActionBar(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 22.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        content = content,
    )
}

@Composable
private fun RowScope.ActionButton(
    label: String,
    primary: Boolean,
    onClick: () -> Unit,
    colors: AccelerometerCaptureColors,
    modifier: Modifier = Modifier,
) {
    val base = if (primary) Modifier.background(colors.orbit, RoundedCornerShape(14.dp))
    else Modifier.border(1.dp, colors.outline, RoundedCornerShape(14.dp))
    Box(
        modifier = modifier.then(base).clickable { onClick() }.padding(vertical = 15.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (primary) colors.onOrbit else colors.onSurface,
            fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}
