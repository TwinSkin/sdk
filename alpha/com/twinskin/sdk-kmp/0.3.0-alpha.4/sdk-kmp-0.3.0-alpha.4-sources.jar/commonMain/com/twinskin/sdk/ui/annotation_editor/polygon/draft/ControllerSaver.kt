package com.twinskin.sdk.ui.annotation_editor.polygon.draft

import androidx.compose.runtime.saveable.Saver
import androidx.compose.ui.geometry.Offset
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.EditorController
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json

/**
 * Saves polygons + focusedIndex only — a 100-deep undo stack of
 * detailed polygons can overflow Android's ~1 MB Bundle limit, so
 * the undo stack and in-flight gesture state are dropped. The
 * disk-backed draft store is the safety net for true process death.
 * Decode failures return null; the host rebuilds an empty controller.
 */
internal object ControllerSaver {
    /** Bump on every wire-format change. Old saved states decode to null. */
    const val CURRENT_VERSION: Int = 1

    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = false
    }

    fun encode(polygons: List<List<Offset>>, focusedIndex: Int?): String {
        val payload = SavedControllerPayload(
            polygons = polygons.map { poly -> poly.map { WireSavedPoint(it.x, it.y) } },
            focusedIndex = focusedIndex,
        )
        return json.encodeToString(
            SavedControllerEnvelope.serializer(),
            SavedControllerEnvelope(version = CURRENT_VERSION, payload = payload),
        )
    }

    fun decode(text: String): Pair<List<List<Offset>>, Int?>? {
        val envelope = try {
            json.decodeFromString(SavedControllerEnvelope.serializer(), text)
        } catch (_: SerializationException) {
            return null
        } catch (_: IllegalArgumentException) {
            return null
        }
        if (envelope.version != CURRENT_VERSION) return null
        val payload = envelope.payload
        val polygons = payload.polygons.map { poly -> poly.map { Offset(it.x, it.y) } }
        val focusedIndex = payload.focusedIndex
        // Defensive: out-of-bounds focusedIndex from a tampered payload
        // is dropped to null rather than crashing the screen.
        val safeFocused = focusedIndex?.takeIf { it in polygons.indices }
        return polygons to safeFocused
    }
}

/**
 * Compose [Saver] instance the canvas screens pass to
 * `rememberSaveable`. Round-trips a live [EditorController]'s
 * polygons + focused index through [ControllerSaver]'s JSON
 * envelope.
 */
internal val EditorControllerSaver: Saver<EditorController, String> = Saver(
    save = { controller ->
        ControllerSaver.encode(
            polygons = controller.polygons.map { it.toList() },
            focusedIndex = controller.focusedIndex,
        )
    },
    restore = { text ->
        ControllerSaver.decode(text)?.let { (polygons, focusedIndex) ->
            EditorController.fromState(polygons, focusedIndex)
        }
    },
)

// ── wire types ───────────────────────────────────────────────────────

@Serializable
private data class SavedControllerEnvelope(
    @SerialName("version") val version: Int,
    @SerialName("payload") val payload: SavedControllerPayload,
)

@Serializable
private data class SavedControllerPayload(
    @SerialName("polygons") val polygons: List<List<WireSavedPoint>>,
    @SerialName("focusedIndex") val focusedIndex: Int?,
)

@Serializable
private data class WireSavedPoint(
    @SerialName("x") val x: Float,
    @SerialName("y") val y: Float,
)
