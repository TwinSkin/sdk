package com.twinskin.sdk.capture.io

/**
 * Append-only file sink. Opens [path] for writing (truncating any existing content)
 * and appends via [write]. The bundle pipeline streams the encrypted bundle straight
 * through this sink — no random-access patching is needed because chunked AES-GCM
 * writes the auth tag inline at the end of each chunk.
 *
 * Non-thread-safe; the whole streaming pipeline runs on a single coroutine.
 */
internal expect open class AppendingFileSink(path: String) {
    open fun write(src: ByteArray, off: Int, len: Int)
    open fun close()
}
