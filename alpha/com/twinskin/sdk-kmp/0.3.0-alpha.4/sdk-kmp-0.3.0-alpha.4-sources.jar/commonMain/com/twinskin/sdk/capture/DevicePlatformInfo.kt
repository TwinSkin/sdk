package com.twinskin.sdk.capture

/**
 * Platform-collected device metadata, resolved once at SDK init.
 *
 * The seven fields below come from raw platform APIs (no user input,
 * no permissions). The eighth field — `sdkVersion` — is supplied
 * separately because it's a build-time constant of the SDK itself,
 * not a property of the host device; [CaptureApi] combines this
 * value with the SDK version when it builds the [SdkDeviceInfo]
 * payload sent to the server on every `startCapture`.
 *
 * Fields are nullable so the platform implementation can return
 * `null` for anything it can't surface (e.g. an integrator app
 * without a `versionName` set), instead of silently sending an
 * empty string. Tests construct this class directly with fixture
 * values; production code obtains it via [systemDevicePlatformInfo].
 *
 * ## Cross-platform contract
 *
 * Every [systemDevicePlatformInfo] actual MUST honor these field
 * shapes — the server is case-sensitive on the closed token sets
 * and parses `locale` as BCP-47:
 *
 * - **`os`**: a lowercase platform token from the closed set
 *   `"android"` or `"ios"`. Do NOT emit `"Android"`, `"iOS"`,
 *   `"darwin"`, or any other variant.
 * - **`locale`**: a BCP-47 language tag (e.g. `"en-US"`, `"fr-FR"`,
 *   `"pt-BR"`), with a hyphen between the language and region
 *   subtags. Implementations using a platform API that returns the
 *   underscored POSIX form (e.g. iOS `NSLocale.localeIdentifier` →
 *   `"en_US"`) MUST normalize to the hyphenated BCP-47 form before
 *   returning.
 */
internal data class DevicePlatformInfo(
    val os: String,                  // "android" | "ios" — see KDoc contract
    val osVersion: String? = null,
    val deviceManufacturer: String? = null,
    val deviceModel: String? = null,
    val appVersion: String? = null,
    val appBundleId: String? = null,
    val locale: String? = null,      // BCP-47 (e.g. "en-US") — see KDoc contract
)

/**
 * Resolves the host platform's [DevicePlatformInfo] at runtime.
 *
 * Implemented per platform: see `DevicePlatformInfo.android.kt` and
 * `DevicePlatformInfo.ios.kt`. The implementation is expected to be
 * a fast, allocation-light call — callers may invoke it once at SDK
 * init and cache the result, but doing so on every call is also
 * cheap.
 */
internal expect fun systemDevicePlatformInfo(): DevicePlatformInfo
