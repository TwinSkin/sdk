package com.twinskin.sdk.geometry

import androidx.compose.ui.geometry.Offset
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Re-densifies [poly] so every consecutive pair sits in
 * `[minSpacingPx, maxSpacingPx]`. The algorithm runs in two phases per
 * pass:
 *
 *  1. Insert the midpoint of any pair whose gap exceeds [maxSpacingPx].
 *  2. Drop the second vertex of any pair whose gap is below
 *     [minSpacingPx] (preserving the first + last vertices).
 *
 * Iterates up to [maxPasses] times or until no change. Closed polygons
 * wrap last → first; open polylines do not. Mutates [poly] in place.
 *
 * The convergent average spacing emerges from `[min, max]` (roughly
 * `(min + max) / 2`). The default `[2, 10]` matches the spec's
 * "~5 image-px target" without exposing it as a tunable.
 */
internal fun densifyInPlace(
    poly: MutableList<Offset>,
    minSpacingPx: Float = 2f,
    maxSpacingPx: Float = 10f,
    closed: Boolean = true,
    maxPasses: Int = 10,
) {
    require(minSpacingPx > 0f && maxSpacingPx >= minSpacingPx) {
        "Need 0 < minSpacingPx ≤ maxSpacingPx (got min=$minSpacingPx, max=$maxSpacingPx)"
    }
    var guard = 0
    while (guard < maxPasses) {
        var changed = false
        if (poly.size < 2) break

        // Phase 1 — densify oversized segments by midpoint insertion.
        val expanded = mutableListOf<Offset>()
        val n = poly.size
        val end = if (closed) n else n - 1
        for (i in 0 until end) {
            val a = poly[i]
            val b = poly[(i + 1) % n]
            expanded += a
            if (segmentLength(a, b) > maxSpacingPx) {
                expanded += Offset((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f)
                changed = true
            }
        }
        if (!closed) expanded += poly.last()
        poly.clear()
        poly += expanded

        // Phase 2 — drop the second vertex of underspaced pairs. Closed
        // polygons may shrink to size < 3; we don't defend against that
        // here — the caller is expected to feed non-degenerate input.
        var i = 0
        val keep = mutableListOf(poly[0])
        while (i < poly.size - 1) {
            val a = keep.last()
            val b = poly[i + 1]
            if (segmentLength(a, b) < minSpacingPx) {
                changed = true
            } else {
                keep += b
            }
            i++
        }
        // For closed polygons, also check the closing pair (last, first).
        if (closed && keep.size >= 2) {
            val a = keep.last()
            val b = keep.first()
            if (segmentLength(a, b) < minSpacingPx) {
                keep.removeAt(keep.size - 1)
                changed = true
            }
        }
        if (!closed) {
            val last = poly.last()
            if (keep.last() != last) {
                if (keep.size > 1 && segmentLength(keep.last(), last) < minSpacingPx) {
                    keep[keep.size - 1] = last
                } else {
                    keep += last
                }
                changed = true
            }
        }
        poly.clear()
        poly += keep

        if (!changed) break
        guard++
    }
}

/**
 * Drops vertices whose included angle is ≥ [angleThresholdDeg] (i.e.
 * quasi-collinear). The default 177° matches the Flutter reference and
 * the spec's analyser-side reduceToRelevants.
 *
 * For open polylines, the first and last vertices are preserved
 * unconditionally. For closed polygons, the list is treated circularly.
 *
 * Inputs with fewer than 12 vertices are returned unchanged — below
 * that count the polygon is already at-or-near the 3-vertex floor and
 * a further pass risks pushing it under.
 *
 * Idempotence: a single pass measures each vertex against the *input*
 * list, so when a neighbour drops the survivor may straighten to the
 * threshold; iterating to a size-stable fixed point makes
 * `reduce(reduce(p)) == reduce(p)`. Bounded by `poly.size` iterations.
 */
internal fun reduceToRelevants(
    poly: List<Offset>,
    angleThresholdDeg: Float = 177f,
    closed: Boolean = true,
): List<Offset> {
    var current = poly.toList()
    while (true) {
        val next = reduceToRelevantsSinglePass(current, angleThresholdDeg, closed)
        if (next.size == current.size) return next
        current = next
    }
}

private fun reduceToRelevantsSinglePass(
    poly: List<Offset>,
    angleThresholdDeg: Float,
    closed: Boolean,
): List<Offset> {
    if (poly.size < 12) return poly.toList()
    val n = poly.size
    val out = mutableListOf<Offset>()
    val range = if (closed) 0 until n else 1 until n - 1

    if (!closed) out += poly.first()
    for (i in range) {
        val a = poly[if (i == 0) n - 1 else i - 1]
        val b = poly[i]
        val c = poly[(i + 1) % n]
        val ux = a.x - b.x; val uy = a.y - b.y
        val vx = c.x - b.x; val vy = c.y - b.y
        val nu = sqrt(ux * ux + uy * uy)
        val nv = sqrt(vx * vx + vy * vy)
        if (nu == 0f || nv == 0f) continue
        val dot = ux * vx + uy * vy
        val cross = ux * vy - uy * vx
        val angRad = atan2(cross, dot)
        val angDeg = (kotlin.math.abs(angRad) * 180.0 / PI).toFloat()
        if (angDeg < angleThresholdDeg) out += b
    }
    if (!closed) out += poly.last()
    return out
}

private fun segmentLength(a: Offset, b: Offset): Float {
    val dx = b.x - a.x
    val dy = b.y - a.y
    return sqrt(dx * dx + dy * dy)
}
