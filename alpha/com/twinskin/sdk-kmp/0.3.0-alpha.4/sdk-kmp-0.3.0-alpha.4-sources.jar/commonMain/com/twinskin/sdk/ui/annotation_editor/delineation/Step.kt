package com.twinskin.sdk.ui.annotation_editor.delineation

import androidx.compose.runtime.saveable.Saver
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType

/**
 * Where the user is in the four-screen flow at any moment. Used by
 * the root [com.twinskin.sdk.ui.annotation_editor.WoundAnnotationEditor]'s
 * navigation state and by the draft codec so a resumed session can
 * land on the same step the user left.
 *
 * Stub introduced in M2b — fully wired by M11
 * (`flow/IntroScreen.kt`, `WoundDrawingScreen.kt`,
 * `TissueDashboardScreen.kt`, `TissueDrawingScreen.kt`) and M13
 * (root composable hosting the `step` state).
 */
internal sealed class Step {
    data object Intro : Step()
    data object Wound : Step()
    data object Dashboard : Step()
    data class TissueDrawing(val type: TissueType) : Step()
}

/**
 * Stable wire encoding for a [Step] — used by both [stepSaver]
 * (rememberSaveable round-trip across configuration changes) and
 * `DraftCodec` (disk-backed draft).
 */
internal fun Step.toWire(): String = when (this) {
    Step.Intro -> "intro"
    Step.Wound -> "wound"
    Step.Dashboard -> "dashboard"
    is Step.TissueDrawing -> "tissue:${type.wire}"
}

/**
 * Decodes a wire string back to a [Step]. Returns `null` on
 * unrecognised input so callers can choose their own fallback
 * (`DraftCodec` rejects the whole draft; [stepSaver] falls back to
 * `Step.Intro`).
 */
internal fun parseStepFromWire(s: String): Step? = when {
    s == "intro" -> Step.Intro
    s == "wound" -> Step.Wound
    s == "dashboard" -> Step.Dashboard
    s.startsWith("tissue:") -> Step.TissueDrawing(TissueType.fromWire(s.removePrefix("tissue:")))
    else -> null
}

/**
 * `rememberSaveable` Saver for [Step]. Used by M13's root
 * composable to survive configuration changes (rotation, theme
 * switch, fold/unfold) without losing the current screen.
 *
 * Unknown wire strings fall back to [Step.Intro] — a corrupted /
 * future-version payload that survived rememberSaveable rebuilds
 * still produces a working session starting fresh.
 */
internal val stepSaver: Saver<Step, String> = Saver(
    save = { it.toWire() },
    restore = { parseStepFromWire(it) ?: Step.Intro },
)
