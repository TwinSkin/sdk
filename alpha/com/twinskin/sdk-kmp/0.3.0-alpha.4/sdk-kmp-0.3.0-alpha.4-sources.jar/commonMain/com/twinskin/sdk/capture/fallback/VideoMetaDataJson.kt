package com.twinskin.sdk.capture.fallback

/**
 * Byte-identical serializer for [VideoMetaData] that mirrors the
 * web_app's `package:json_serializable` + `dart:convert.jsonEncode`
 * output for the same type (`packages/server/lib/src/front_apis/case/api.dart`).
 *
 * The accelerometer-capture bundle's `video_metadata.json` sidecar must
 * round-trip a web_app payload byte-for-byte so the decrypt lambda
 * has a single parser regardless of which client uploaded the
 * capture. `kotlinx.serialization`'s defaults disagree with Dart on
 * three counts that matter on the wire:
 *
 * - **null handling**: kotlinx drops nullable fields whose value is
 *   `null` and whose schema carries a default. Dart's
 *   `_$VideoMetaDataToJson` emits them verbatim as `"key":null`.
 * - **field ordering**: kotlinx emits in declaration order; Dart's
 *   `json_serializable` emits in declaration order too, but the SDK
 *   side's class layout is independent. Pinning the order here keeps
 *   the bytes stable even if [VideoMetaData] is refactored.
 * - **number formatting**: kotlinx prints `Double(1.0)` as `1.0` and
 *   Dart's `jsonEncode` prints `double 1.0` as `1.0`, matching for
 *   finite values. NaN / Inf are not produced by the IMU samplers so
 *   they're not part of the contract.
 *
 * The output is compact (no whitespace), matches Dart's
 * `jsonEncode({...})`, and is encoded as UTF-8 by the caller.
 */
internal object VideoMetaDataJson {
    fun encodeToBytes(data: VideoMetaData): ByteArray =
        encodeToString(data).encodeToByteArray()

    fun encodeToString(data: VideoMetaData): String {
        val sb = StringBuilder()
        sb.append('{')
        appendListField(sb, "accelerometerData", data.accelerometerData, isFirst = true)
        appendListField(sb, "gyroscoptData", data.gyroscoptData, isFirst = false)
        appendListField(
            sb,
            "userAccelerometerData",
            data.userAccelerometerData,
            isFirst = false,
        )
        appendListField(sb, "magnetoscopeData", data.magnetoscopeData, isFirst = false)
        sb.append('}')
        return sb.toString()
    }

    private fun appendListField(
        sb: StringBuilder,
        name: String,
        list: List<AccelerometerData>?,
        isFirst: Boolean,
    ) {
        if (!isFirst) sb.append(',')
        sb.append('"').append(name).append("\":")
        if (list == null) {
            sb.append("null")
            return
        }
        sb.append('[')
        for (i in list.indices) {
            if (i > 0) sb.append(',')
            appendSample(sb, list[i])
        }
        sb.append(']')
    }

    private fun appendSample(sb: StringBuilder, sample: AccelerometerData) {
        sb.append("{\"timestampMilliseconds\":")
            .append(sample.timestampMilliseconds)
            .append(",\"x\":")
            .append(formatDouble(sample.x))
            .append(",\"y\":")
            .append(formatDouble(sample.y))
            .append(",\"z\":")
            .append(formatDouble(sample.z))
            .append('}')
    }

    /**
     * Mirrors Dart's `jsonEncode` numeric output for `double` values.
     * Dart picks decimal vs exponential by magnitude:
     *  - `abs(v) == 0` → `"0.0"` (or `"-0.0"` for negative zero).
     *  - `1e-6 <= abs(v) < 1e21` → decimal (`0.1`, `0.000001`,
     *    `0.00021713848421777565`, `1234567.89`, `1.0`).
     *  - otherwise non-zero finite → exponential, lowercase `e`,
     *    with `+` on positive exponents (`1e-7`, `5e-7`, `1e+21`,
     *    `1.5e+21`).
     *
     * Kotlin's `Double.toString` picks the same shortest round-trip
     * digits but switches to exponential at `abs(v) < 1e-3`
     * (`-2.1713848421777565E-4`) and uses uppercase `E` without a `+`
     * sign — so a verbatim Kotlin-side toString diverges from Dart on
     * the IMU noise floor (`~1e-4` to `~1e-21`), which the byte-parity
     * harness against the web_app catches. The formatter normalises
     * both branches:
     *  - Kotlin emits exponential in `[1e-6, 1e-3)`: convert to
     *    decimal so it matches Dart.
     *  - Kotlin emits exponential outside Dart's decimal band: rewrite
     *    `E` → `e` and prepend `+` to positive exponents.
     *
     * NaN / Inf are out of scope — the IMU samplers never produce them
     * and Dart's `jsonEncode` throws on those anyway.
     */
    internal fun formatDouble(value: Double): String {
        if (value == 0.0) {
            // Preserve sign of negative zero (`-0.0` round-trips on both
            // sides). `value == 0.0` matches both +0 and -0.
            return if (1.0 / value < 0) "-0.0" else "0.0"
        }
        val abs = if (value < 0) -value else value
        val kotlinRendered = value.toString()
        val expIndex = kotlinRendered.indexOf('E').let {
            if (it < 0) kotlinRendered.indexOf('e') else it
        }
        // Dart's decimal band — `[1e-6, 1e21)` on absolute magnitude.
        val dartWantsDecimal = abs >= 1e-6 && abs < 1e21
        return if (dartWantsDecimal) {
            if (expIndex < 0) {
                // Kotlin already chose decimal — agrees with Dart.
                kotlinRendered
            } else {
                expToDecimal(kotlinRendered, expIndex)
            }
        } else {
            if (expIndex < 0) {
                // Kotlin chose decimal where Dart picks exponential —
                // can happen for very small values whose magnitude
                // straddles a boundary in some edge cases; rebuild via
                // the canonical exponential form.
                decimalToExp(kotlinRendered)
            } else {
                // Normalise `E` → `e` and force the `+` sign for
                // positive exponents to match Dart's `1e+21`.
                normaliseExponential(kotlinRendered, expIndex)
            }
        }
    }

    private fun expToDecimal(rendered: String, expIndex: Int): String {
        val sign = if (rendered.startsWith('-')) "-" else ""
        val mantissa = rendered.substring(if (sign.isNotEmpty()) 1 else 0, expIndex)
        val exponent = rendered.substring(expIndex + 1).toInt()
        // Mantissa is `D.DDDD` or `D` (Kotlin's `Double.toString` always
        // includes the `.` for the exponential form, but guard either
        // way).
        val dotIdx = mantissa.indexOf('.')
        val intPart: String
        val fracPart: String
        if (dotIdx < 0) {
            intPart = mantissa
            fracPart = ""
        } else {
            intPart = mantissa.substring(0, dotIdx)
            fracPart = mantissa.substring(dotIdx + 1)
        }
        // Dart emits the shortest round-trip mantissa — drop the
        // trailing zero Kotlin's `Double.toString` always tacks onto
        // integral exponential forms (`1.0E-4` → digits `1`, not `10`).
        val trimmedFrac = fracPart.trimEnd('0')
        val digits = intPart + trimmedFrac
        return if (exponent < 0) {
            // Shift the decimal `-exponent` places to the left.
            val shift = -exponent
            val zerosBeforeDigits = shift - intPart.length
            val sb = StringBuilder()
            sb.append(sign).append("0.")
            repeat(zerosBeforeDigits) { sb.append('0') }
            sb.append(digits)
            sb.toString()
        } else {
            // Positive exponent — Kotlin uses exponential at `>= 1e7`
            // (`Double.toString`), but Dart's decimal band reaches
            // `1e21`. Shift the decimal `exponent` places to the right.
            val newDotPos = intPart.length + exponent
            val sb = StringBuilder()
            sb.append(sign)
            if (newDotPos >= digits.length) {
                sb.append(digits)
                repeat(newDotPos - digits.length) { sb.append('0') }
                sb.append(".0")
            } else {
                sb.append(digits.substring(0, newDotPos))
                sb.append('.')
                sb.append(digits.substring(newDotPos))
            }
            sb.toString()
        }
    }

    private fun decimalToExp(rendered: String): String {
        val sign = if (rendered.startsWith('-')) "-" else ""
        val mantissa = rendered.substring(if (sign.isNotEmpty()) 1 else 0)
        val dotIdx = mantissa.indexOf('.')
        val (intPart, fracPart) = if (dotIdx < 0) {
            mantissa to ""
        } else {
            mantissa.substring(0, dotIdx) to mantissa.substring(dotIdx + 1)
        }
        // Strip leading zeros in intPart (shouldn't be any for a
        // shortest-round-trip rendering) and trailing zeros in fracPart.
        val intTrimmed = intPart.trimStart('0')
        return if (intTrimmed.isNotEmpty()) {
            // Magnitude >= 1; exponent = digits to the right of the
            // first significant digit.
            val firstDigit = intTrimmed.first()
            val tail = intTrimmed.substring(1) + fracPart.trimEnd('0')
            val exp = intTrimmed.length - 1
            if (tail.isEmpty()) {
                "${sign}${firstDigit}e+$exp"
            } else {
                "${sign}${firstDigit}.${tail}e+$exp"
            }
        } else {
            // Magnitude < 1; find first non-zero digit in fracPart.
            val firstNonZero = fracPart.indexOfFirst { it != '0' }
            if (firstNonZero < 0) {
                // Pure zero — already handled by the top-level guard.
                "0.0"
            } else {
                val exp = -(firstNonZero + 1)
                val firstDigit = fracPart[firstNonZero]
                val tail = fracPart.substring(firstNonZero + 1).trimEnd('0')
                if (tail.isEmpty()) {
                    "${sign}${firstDigit}e$exp"
                } else {
                    "${sign}${firstDigit}.${tail}e$exp"
                }
            }
        }
    }

    private fun normaliseExponential(rendered: String, expIndex: Int): String {
        var mantissa = rendered.substring(0, expIndex)
        if (mantissa.endsWith(".0")) {
            mantissa = mantissa.substring(0, mantissa.length - 2)
        }
        val expText = rendered.substring(expIndex + 1)
        val signedExpText = when {
            expText.startsWith('-') -> expText
            expText.startsWith('+') -> expText
            else -> "+$expText"
        }
        return "${mantissa}e${signedExpText}"
    }
}
