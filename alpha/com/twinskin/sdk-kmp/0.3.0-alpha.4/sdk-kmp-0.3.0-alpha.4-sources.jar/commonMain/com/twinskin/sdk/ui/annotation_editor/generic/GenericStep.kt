package com.twinskin.sdk.ui.annotation_editor.generic

import androidx.compose.runtime.saveable.Saver

/**
 * Where the user is in the generic editor's two-screen flow. The
 * root [GenericAnnotationEditor] hosts the `step` state with
 * `rememberSaveable(saver = genericStepSaver)` so configuration
 * changes (rotation, theme switch, fold/unfold) don't reset the
 * screen.
 */
internal sealed class GenericStep {
    data object Intro : GenericStep()
    data object Drawing : GenericStep()
}

private fun GenericStep.toWire(): String = when (this) {
    GenericStep.Intro -> "intro"
    GenericStep.Drawing -> "drawing"
}

private fun parseGenericStepFromWire(s: String): GenericStep? = when (s) {
    "intro" -> GenericStep.Intro
    "drawing" -> GenericStep.Drawing
    else -> null
}

/**
 * Unknown wire strings fall back to [GenericStep.Intro] — a
 * corrupted / future-version payload that survived `rememberSaveable`
 * rebuilds still produces a working session starting fresh.
 */
internal val genericStepSaver: Saver<GenericStep, String> = Saver(
    save = { it.toWire() },
    restore = { parseGenericStepFromWire(it) ?: GenericStep.Intro },
)
