package com.twinskin.sdk.ui.capture.i18n

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import com.twinskin.sdk.i18n.sdkLocale

/**
 * Resolved capture-screen strings for the current locale, for `@Composable`
 * code. Defaults to English; [ProvideSdkCaptureStrings] overrides it at each
 * capture Compose root with the locale-resolved table.
 *
 * Reachable only from Compose. The Swift/Android-facing [CaptureViewCopy] bridge
 * reads [EnCaptureStrings] directly, since it is consumed outside any Compose
 * scope (and from Swift, which can't see a CompositionLocal).
 */
internal val LocalCaptureStrings =
    staticCompositionLocalOf<SdkCaptureStrings> { EnCaptureStrings }

/**
 * Provides [LocalCaptureStrings] resolved for the SDK's active locale
 * ([sdkLocale]) to [content]. Wrap every capture Compose root — the
 * accelerometer screen, the Android photosphere screen + post-submit flow, and
 * the iOS photosphere tutorial / post-submit view controllers — so capture UI
 * renders the integrator-configured / device locale instead of the English
 * default.
 *
 * The locale is resolved once when the root enters composition — matching the
 * annotation editors' `remember { delineationStringsFor(sdkLocale()) }` — so a
 * [com.twinskin.sdk.TwinSkinSdk.setLocale] change takes effect on the next
 * screen open, not mid-capture.
 */
@Composable
internal fun ProvideSdkCaptureStrings(content: @Composable () -> Unit) {
    val strings = remember { captureStringsFor(sdkLocale()) }
    CompositionLocalProvider(LocalCaptureStrings provides strings, content = content)
}
