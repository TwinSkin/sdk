package com.twinskin.sdk.capture

/**
 * Format an epoch-millis timestamp as an ISO-8601 UTC string, with second
 * precision and a `Z` suffix (e.g. `2026-04-17T09:12:34Z`). Kept narrow so
 * the capture manifest timestamp matches the `capture_timestamp` shape the
 * server-side Pydantic schema validates.
 */
internal expect fun epochMillisToIso8601(epochMillis: Long): String

/**
 * Inverse of [epochMillisToIso8601]. Accepts the ISO-8601 strings PowerSync
 * emits for `timestamp with time zone` columns (e.g. `2026-04-22T10:11:12Z`
 * or `2026-04-22T10:11:12.345+00:00`). Returns `null` on unparseable input
 * rather than throwing — a malformed server timestamp is not a reason to
 * fail the whole watch stream.
 */
internal expect fun iso8601ToEpochMillis(iso: String): Long?
