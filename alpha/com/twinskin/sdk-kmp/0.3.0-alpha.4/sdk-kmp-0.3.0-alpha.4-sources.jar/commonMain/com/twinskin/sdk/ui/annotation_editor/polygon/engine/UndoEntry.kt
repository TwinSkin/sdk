package com.twinskin.sdk.ui.annotation_editor.polygon.engine

import androidx.compose.ui.geometry.Offset

/**
 * Immutable snapshot of the controller's committed-polygon state.
 * Pushed before every mutating operation (commit-stroke,
 * delete-focused, reshape-commit); popped by [EditorController.undo].
 *
 * Snapshot-of-state, not diff-of-state — with the 100-entry cap
 * (C3 in the plan) the working set tops out in the hundreds of
 * kilobytes, easily affordable; diff-based replay would be a tar
 * pit when reshape lands in M5 and polygons mutate per-pointer-move.
 *
 * Open-stroke undo is *not* captured here — that's the OpenStroke
 * palier subsystem's responsibility (M3). Atomicity between a wound
 * outline and its tissues is M11's wiring concern; this controller
 * stays a single-layer state machine.
 */
internal data class UndoEntry(
    val polygons: List<List<Offset>>,
    val focusedIndex: Int?,
    /**
     * Opaque side-state slot the host screen can attach to a freshly-pushed
     * undo entry (typically a `DelineationStore.StoreSnapshot`). Carried
     * unchanged through to [UiSignal.UndoApplied] so the screen can restore
     * external state in lockstep with the controller's polygon rollback.
     * Decouples the screen's undo mirror from a parallel stack — making
     * drift between the two impossible.
     */
    val sideState: Any? = null,
)
