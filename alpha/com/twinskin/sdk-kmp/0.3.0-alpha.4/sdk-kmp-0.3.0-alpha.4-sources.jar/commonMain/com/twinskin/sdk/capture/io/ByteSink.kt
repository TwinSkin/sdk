package com.twinskin.sdk.capture.io

/**
 * Minimal forward-only byte sink used by the capture bundle streaming pipeline.
 * Chosen over `kotlinx-io.RawSink` to keep the shared module free of yet another
 * dependency — the whole pipeline needs is `write(bytes, off, len)`.
 */
internal fun interface ByteSink {
    fun write(src: ByteArray, off: Int, len: Int)
}
