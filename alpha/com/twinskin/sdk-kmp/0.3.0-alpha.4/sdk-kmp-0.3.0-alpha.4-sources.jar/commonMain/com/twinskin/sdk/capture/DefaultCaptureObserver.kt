package com.twinskin.sdk.capture

import com.twinskin.sdk.transfer.currentTimeMillis
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

/**
 * Default [CaptureObserver] implementation. Reads local state from
 * [SdkCaptureStore]; layers server state on top via [ServerCaptureSource]
 * when a caller opts into `observeSubject`.
 *
 * [serverAckGraceMs] bounds the `Uploaded → Analyzing` flicker
 * substitution — see [mergeEntries] for the full rationale. A local
 * `Uploaded` row whose `updatedAtEpochMs` is older than this window
 * reverts to the truthful `Uploaded` state, so a dropped server-side
 * event doesn't leave the UI pinned on `Analyzing` forever.
 */
internal class DefaultCaptureObserver(
    private val store: SdkCaptureStore,
    private val serverSource: ServerCaptureSource,
    private val clock: () -> Long = ::currentTimeMillis,
    private val serverAckGraceMs: Long = DEFAULT_SERVER_ACK_GRACE_MS,
) : CaptureObserver {

    override fun observePendingUploads(): Flow<List<PendingUpload>> =
        store.observeAll().map { rows ->
            rows.asSequence()
                .filter { it.status.isVisibleOnPendingUploads() }
                .map { it.toPendingUpload() }
                .toList()
        }

    override fun observeSubject(subjectRef: String): Flow<List<CaptureEntry>> =
        combine(
            store.observeAll().map { rows ->
                rows.filter { it.request.subjectRef == subjectRef }
            },
            serverSource.observeSubject(subjectRef),
        ) { localRows, serverEntries ->
            mergeEntries(localRows, serverEntries, clock(), serverAckGraceMs)
        }

    override fun observeCapture(captureId: String, subjectRef: String): Flow<CaptureEntry?> =
        observeSubject(subjectRef)
            .map { entries -> entries.firstOrNull { it.captureId == captureId } }
            .distinctUntilChanged()

    companion object {
        /** 60s — covers a healthy S3 → SNS → webhook → DB insert round-trip with plenty of slack. */
        const val DEFAULT_SERVER_ACK_GRACE_MS: Long = 60_000L
    }
}

/**
 * Merge the per-subject local and server sides into a single
 * [CaptureEntry] list.
 *
 *  - Local state is [CaptureState.Uploading] AND the server state for
 *    the same capture is [CaptureState.Analyzing] → emit the local
 *    entry. The server inserts the `sdk_captures` row at
 *    `POST /upload/start-capture` time — *before* any bytes arrive —
 *    with `status = queued`, which `statusToState` maps to
 *    `Analyzing`. Without this branch the server would overwrite the
 *    in-flight local `Uploading(percent)` on the very next PowerSync
 *    tick and the user would see "Analyzing" with no progress for the
 *    whole upload. While local says Uploading, the client has
 *    byte-level progress the server's `queued`/`in_progress` can't
 *    surface — keep it on screen. Terminal server states
 *    (`Succeeded` / `Failed` / `Cancelled`) still take precedence in
 *    the branch below, so a crashed / disconnected client that never
 *    flipped its local status won't stay pinned on Uploading.
 *  - Server row present for a capture id (any other state) → emit the
 *    server entry. The server is authoritative once the capture is
 *    past the upload phase.
 *  - Local-only row with state [CaptureState.Uploaded] and
 *    `updatedAtEpochMs` within `serverAckGraceMs` of [nowEpochMs] →
 *    substitute [CaptureState.Analyzing]. The upload succeeded but the
 *    server's first `sdk_captures` row hasn't arrived yet (1–2s window
 *    after S3 → SNS → webhook → DB insert); displaying "Uploaded" and
 *    then flipping to "Analyzing" looks like a bug.
 *  - Local-only row with state [CaptureState.Uploaded] past the grace
 *    window → emit the truthful `Uploaded`. "Uploaded" is honest: the
 *    upload genuinely succeeded; the server just hasn't ack'd (dropped
 *    SNS event, server outage, etc.). Better than lying with a
 *    permanent `Analyzing`.
 *  - Local-only row otherwise → emit the local state as-is.
 *
 * The result is sorted by `updatedAtEpochMs` descending so UIs can
 * render newest-first without further work.
 */
internal fun mergeEntries(
    localRows: List<SdkCaptureUploadRecord>,
    serverEntries: List<CaptureEntry>,
    nowEpochMs: Long,
    serverAckGraceMs: Long,
): List<CaptureEntry> {
    val serverById = serverEntries.associateBy { it.captureId }
    val byId = LinkedHashMap<String, CaptureEntry>(localRows.size + serverEntries.size)
    for (local in localRows) {
        val localState = local.toCaptureState()
        val server = serverById[local.captureId]
        val chosen = when {
            localState is CaptureState.Uploading && server?.state is CaptureState.Analyzing ->
                CaptureEntry(
                    captureId = local.captureId,
                    subjectRef = local.request.subjectRef,
                    state = localState,
                    updatedAtEpochMs = local.updatedAtEpochMs,
                    custom = customFromJsonElements(local.request.custom),
                    captureGroup = local.request.captureGroup,
                    conditionType = local.request.conditionType,
                )
            server != null -> server
            else -> {
                val withinGrace = (nowEpochMs - local.updatedAtEpochMs) <= serverAckGraceMs
                local.toCaptureEntry(flickerSubstitute = withinGrace)
            }
        }
        // Backfill condition type, custom (the join key), and capture group
        // from the local request: the device knows them from the start, but the
        // server only carries them once its synced columns land.
        byId[local.captureId] = chosen.copy(
            conditionType = chosen.conditionType ?: local.request.conditionType,
            custom = chosen.custom ?: customFromJsonElements(local.request.custom),
            captureGroup = chosen.captureGroup ?: local.request.captureGroup,
        )
    }
    // Server rows without a local counterpart (e.g. a capture started on
    // another device for the same subject) still flow through.
    // `putIfAbsent` isn't available on Kotlin/Native Map, so do it manually.
    for (server in serverEntries) {
        if (server.captureId !in byId) byId[server.captureId] = server
    }
    return byId.values.sortedByDescending { it.updatedAtEpochMs }
}

/**
 * Map a persisted [SdkCaptureUploadStatus] to the coarse public [CaptureState].
 *
 * When the row is in `UPLOADING`, the byte-level percent comes from the joined
 * [TransferTask.progress] column via [SdkCaptureUploadRecord.transferProgressPercent];
 * `PENDING_UPLOAD` rows (bundle on disk, no TransferTask yet) emit
 * `Uploading(progressPercent = null)`.
 */
private fun SdkCaptureUploadRecord.toPendingUpload(): PendingUpload =
    PendingUpload(
        captureId = captureId,
        subjectRef = request.subjectRef,
        state = toCaptureState(),
        updatedAtEpochMs = updatedAtEpochMs,
    )

/**
 * Merge-path mapping. Differs from [toPendingUpload] only in that
 * [flickerSubstitute] upgrades a local `Uploaded` to `Analyzing` —
 * never the other way around.
 */
internal fun SdkCaptureUploadRecord.toCaptureEntry(
    flickerSubstitute: Boolean,
): CaptureEntry {
    val raw = toCaptureState()
    val effective = if (flickerSubstitute && raw is CaptureState.Uploaded) {
        CaptureState.Analyzing
    } else {
        raw
    }
    return CaptureEntry(
        captureId = captureId,
        subjectRef = request.subjectRef,
        state = effective,
        updatedAtEpochMs = updatedAtEpochMs,
        custom = customFromJsonElements(request.custom),
        captureGroup = request.captureGroup,
        conditionType = request.conditionType,
    )
}

/**
 * Statuses surfaced on [CaptureObserver.observePendingUploads]. Rows are
 * either currently moving (`PENDING_UPLOAD` / `UPLOADING`) or terminally
 * stuck (`FAILED`). `COMPLETED` and `CANCELLED` drop out immediately —
 * the upload either succeeded (no further integrator attention needed) or
 * was explicitly cancelled (user already acknowledged the end state).
 *
 * `FAILED` persists with no time-based eviction. The product invariant is
 * that uploads never give up; if a row reaches `FAILED`, it represents a
 * bug (e.g. the encrypted bundle missing on disk, an SDK-misconfiguration
 * path, or a platform-level retry budget the SDK does not yet treat as
 * unbounded) that warrants an SDK update rather than a UI dismissal.
 */
private fun SdkCaptureUploadStatus.isVisibleOnPendingUploads(): Boolean = when (this) {
    SdkCaptureUploadStatus.PENDING_UPLOAD,
    SdkCaptureUploadStatus.UPLOADING,
    SdkCaptureUploadStatus.FAILED -> true
    SdkCaptureUploadStatus.COMPLETED,
    SdkCaptureUploadStatus.CANCELLED -> false
}

private fun SdkCaptureUploadRecord.toCaptureState(): CaptureState = when (status) {
    SdkCaptureUploadStatus.PENDING_UPLOAD -> CaptureState.Uploading(progressPercent = null)
    SdkCaptureUploadStatus.UPLOADING -> CaptureState.Uploading(progressPercent = transferProgressPercent)
    SdkCaptureUploadStatus.COMPLETED -> CaptureState.Uploaded
    SdkCaptureUploadStatus.FAILED -> CaptureState.Failed(
        stage = FailureStage.Upload,
        message = null,
    )
    SdkCaptureUploadStatus.CANCELLED -> CaptureState.Cancelled
}
