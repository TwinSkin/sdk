package com.twinskin.sdk.ui.annotation_editor.polygon.canvas

import androidx.compose.ui.geometry.Offset

/**
 * Double-tap recognition across the canvas's per-gesture loop.
 *
 * [DrawingCanvas]'s `awaitEachGesture` loop sees one gesture at a
 * time, so two consecutive taps arrive as two independent gesture
 * completions — this detector holds the cross-gesture state (last
 * tap time + position) and reports when a tap completes a
 * double-tap.
 *
 * Single taps are NEVER delayed waiting for a possible second tap:
 * the first tap dispatches to the controller immediately (stroke
 * seeding / focus must stay latency-free for drawing), and the
 * double-tap action compensates for the first tap's side effects
 * after the fact (see `EditorController.discardNascentOpenStroke`).
 */
internal class DoubleTapDetector(
    private val timeSource: kotlin.time.TimeSource = kotlin.time.TimeSource.Monotonic,
) {
    private var lastTapMark: kotlin.time.TimeMark? = null
    private var lastTapPos: Offset? = null

    /**
     * Records a completed tap at [pos]. Returns true when this tap
     * lands within [DOUBLE_TAP_TIMEOUT] and [DOUBLE_TAP_SLOP_CANVAS_PX]
     * of the previous one — a double-tap. The pair state is consumed
     * either way, so a triple tap reads as double-tap + fresh first tap.
     */
    fun onTap(pos: Offset): Boolean {
        val mark = lastTapMark
        val prev = lastTapPos
        val isDouble = mark != null && prev != null &&
            mark.elapsedNow() < DOUBLE_TAP_TIMEOUT &&
            run {
                val dx = pos.x - prev.x
                val dy = pos.y - prev.y
                dx * dx + dy * dy <=
                    DOUBLE_TAP_SLOP_CANVAS_PX * DOUBLE_TAP_SLOP_CANVAS_PX
            }
        if (isDouble) {
            lastTapMark = null
            lastTapPos = null
        } else {
            lastTapMark = timeSource.markNow()
            lastTapPos = pos
        }
        return isDouble
    }

    internal companion object {
        /** Platform-typical double-tap window (Android ViewConfiguration = 300 ms). */
        val DOUBLE_TAP_TIMEOUT: kotlin.time.Duration = kotlin.time.Duration.parse("300ms")

        /**
         * Max canvas-px between the two taps. Deliberately EQUAL to
         * [com.twinskin.sdk.ui.annotation_editor.polygon.engine.OpenStroke.RESUME_ZONE_CANVAS_PX]:
         * the first tap of a double-tap seeds a dot stroke, and the
         * second tap routes through the resume-zone check before the
         * detector sees it. With a wider slop, taps 50–100 px apart
         * would zoom while ALSO flashing the "too far from your line"
         * hint (the second tap falls outside the resume zone) — the
         * two "same spot" bands must agree.
         */
        const val DOUBLE_TAP_SLOP_CANVAS_PX: Float = 50f
    }
}

/**
 * Double-tap zoom toggle target (spec'd on the web_app editor's
 * behavior class: tap-to-zoom-in, tap-again-to-reset). Anything
 * meaningfully above fit resets to fit; from fit (or near it) the
 * canvas jumps to a comfortable inspection zoom.
 */
internal fun doubleTapTargetScale(currentScale: Float): Float =
    if (currentScale > DOUBLE_TAP_RESET_THRESHOLD) {
        ZoomPanController.MIN_SCALE
    } else {
        DOUBLE_TAP_ZOOM_SCALE
    }

/** Above this the toggle reads "zoomed" and resets to fit. */
internal const val DOUBLE_TAP_RESET_THRESHOLD: Float = 1.1f

/** Inspection zoom the toggle jumps to from fit. */
internal const val DOUBLE_TAP_ZOOM_SCALE: Float = 4f
