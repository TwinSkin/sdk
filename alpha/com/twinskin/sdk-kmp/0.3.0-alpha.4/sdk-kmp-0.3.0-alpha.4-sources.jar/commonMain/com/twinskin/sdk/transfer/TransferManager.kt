package com.twinskin.sdk.transfer

import app.cash.sqldelight.coroutines.asFlow
import app.cash.sqldelight.coroutines.mapToList
import app.cash.sqldelight.coroutines.mapToOneOrNull
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.db.TransferTask
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.random.Random

/**
 * Central state machine for all file transfers (uploads and downloads).
 *
 * ## Upload flow
 * Call [upload] with a file path and a stable server-side [uploadKey]. The manager
 * delegates to the platform [FileTransferProvider], which handles URL resolution and
 * HTTP PUT internally (including retries and offline resilience).
 *
 * ## Download flow
 * Call [download] with a URL, optional request headers, a destination path, and an optional
 * [unzip] flag. The manager streams the file to a `.tmp` path (platform workers do the
 * atomic rename), then optionally unzips the result.
 *
 * ## Observability
 * - [observeTask] watches a single task by ID.
 * - [observeAllTasks] exposes the full live list of all tasks.
 *
 * ## App-lifecycle hooks
 * - Call [initialize] on startup to mark interrupted ACTIVE/UNZIPPING tasks as FAILED.
 * - Call [recover] on startup (after [initialize]) to restart ACTIVE tasks that survived a crash.
 * - Call [recoverPendingUploads] when woken by a background scheduler (e.g. iOS BGProcessingTask)
 *   to retry PENDING upload tasks while network is available.
 *
 * ## Single source of truth
 * The database is the **only** source of state. Every write goes directly to SQLDelight and
 * the reactive [Flow] plumbing propagates changes to all observers automatically — there is no
 * parallel in-memory state to keep in sync.
 */
internal class TransferManager(
    private val database: TwinSkinDatabase,
    private val provider: FileTransferProvider,
    private val zipEngine: ZipEngine,
    private val scope: CoroutineScope,
    private val clock: () -> Long = { currentTimeMillis() },
    private val pathResolver: PathResolver = IdentityPathResolver,
) {
    private val queries = database.transferTaskQueries

    // Guards against duplicate upload coroutines launched concurrently (e.g. when
    // recoverPendingUploads() races with a freshly-enqueued upload for the same task ID).
    private val runningUploadIds = mutableSetOf<String>()
    private val runningUploadIdsMutex = Mutex()

    // Active coroutine jobs, keyed by task ID, so cancelTask() can cancel them.
    private val activeJobs = mutableMapOf<String, Job>()
    private val activeJobsMutex = Mutex()

    // Lazily initialised so the DB query is not executed before the manager is used.
    // Eagerly: starts collecting from the DB as soon as first accessed, so the StateFlow's
    // .value is always current. WhileSubscribed would require a Kotlin coroutine subscriber
    // to start the upstream — Swift polling via .value does not count as a subscriber,
    // meaning .value would stay as emptyList() indefinitely on iOS.
    private val allTasksFlow: StateFlow<List<TransferTask>> by lazy {
        queries.selectAll()
            .asFlow()
            .mapToList(Dispatchers.Default)
            .map { tasks -> tasks.map { it.withResolvedPath() } }
            .stateIn(scope, SharingStarted.Eagerly, emptyList())
    }

    // -------------------------------------------------------------------------
    // Public API — start transfers
    // -------------------------------------------------------------------------

    /**
     * Enqueue an upload.
     *
     * @param filePath   Absolute path to the file to upload.
     * @param uploadKey  Stable identifier for the content on the server. Passed to the
     *                   [urlResolver] on every attempt (including retries) to obtain a
     *                   presigned URL. Stored in the database as the task's [TransferTask.url].
     * @return The task ID (opaque string; use with [observeTask]).
     *
     * Idempotent on [uploadKey]: if a non-terminal task already exists for the same
     * [uploadKey], its id is returned and no new row is inserted. This makes callers'
     * recovery flows safe to re-run without creating duplicate uploads (see
     * `CaptureApi.recover`). The behaviour is backed by a partial unique index on
     * `TransferTask(url, type) WHERE status IN ('PENDING','ACTIVE','UNZIPPING')`.
     */
    suspend fun upload(filePath: String, uploadKey: String): String {
        queries.selectActiveUploadByUrl(uploadKey)
            .executeAsOneOrNull()
            ?.let {
                launchUploadIfIdle(it.id)
                return it.id
            }
        val id = generateId()
        val now = clock()
        queries.insert(
            id = id,
            url = uploadKey,
            localPath = pathResolver.toStorage(filePath),
            type = TransferType.UPLOAD.name,
            status = TransferStatus.PENDING.name,
            progress = 0L,
            errorMessage = null,
            unzip = 0L,
            headers = null,
            createdAt = now,
            updatedAt = now,
        )
        launchUploadIfIdle(id)
        return id
    }

    /**
     * Enqueue a download.
     *
     * @param url              HTTP(S) URL of the file to download.
     * @param destinationPath  Absolute path where the downloaded file should be written.
     * @param headers          Optional HTTP request headers (e.g. for pre-signed URLs that
     *                         require specific headers).
     * @param unzip            If `true`, the downloaded file is unzipped to
     *                         `"$destinationPath.unzipped"` after a successful download.
     * @return The task ID (opaque string; use with [observeTask]).
     */
    suspend fun download(
        url: String,
        destinationPath: String,
        headers: Map<String, String> = emptyMap(),
        unzip: Boolean = false,
    ): String {
        val id = generateId()
        val now = clock()
        queries.insert(
            id = id,
            url = url,
            localPath = pathResolver.toStorage(destinationPath),
            type = TransferType.DOWNLOAD.name,
            status = TransferStatus.PENDING.name,
            progress = 0L,
            errorMessage = null,
            unzip = if (unzip) 1L else 0L,
            headers = if (headers.isEmpty()) null else Json.encodeToString(headers),
            createdAt = now,
            updatedAt = now,
        )
        launchDownloadJob(id)
        return id
    }

    // -------------------------------------------------------------------------
    // Public API — observe
    // -------------------------------------------------------------------------

    /**
     * Returns a cold [Flow] that emits the latest [TransferTask] snapshot for [id] on every
     * database change. Emits `null` if the task does not exist.
     *
     * The database is the single source of truth: every status/progress write propagates
     * automatically — including writes from background workers (e.g. [UploadWorker] on Android)
     * that run without the app UI open.
     */
    fun observeTask(id: String): Flow<TransferTask?> =
        queries.selectById(id).asFlow().mapToOneOrNull(Dispatchers.Default)
            .map { it?.withResolvedPath() }

    /**
     * Returns the current [TransferTask] snapshot for [id] directly from the database, or `null`
     * if no task with that ID exists. Use this for one-shot reads; prefer [observeTask] when you
     * need to react to changes over time.
     */
    fun queryTask(id: String): TransferTask? =
        queries.selectById(id).executeAsOneOrNull()?.withResolvedPath()

    /** Returns a [StateFlow] that always reflects the full list of known transfer tasks. */
    fun observeAllTasks(): StateFlow<List<TransferTask>> = allTasksFlow

    // -------------------------------------------------------------------------
    // Public API — lifecycle
    // -------------------------------------------------------------------------

    /**
     * Mark any tasks that were ACTIVE or UNZIPPING (i.e. interrupted by app termination)
     * as FAILED. Call this on startup before resuming transfers.
     */
    suspend fun initialize() {
        val now = clock()
        val interrupted =
            queries.selectByStatus(TransferStatus.ACTIVE.name).executeAsList() +
            queries.selectByStatus(TransferStatus.UNZIPPING.name).executeAsList()
        for (task in interrupted) {
            queries.updateStatusAndError(
                TransferStatus.FAILED.name,
                "Interrupted by app termination",
                now,
                task.id,
            )
        }
    }

    /**
     * Re-run all tasks that are still marked ACTIVE after a crash (were not caught by
     * [initialize]). Safe to call after [initialize]; typically used for downloads since
     * uploads have their own recovery path via [recoverPendingUploads].
     */
    suspend fun recover() {
        val active = queries.selectByStatus(TransferStatus.ACTIVE.name).executeAsList()
        for (task in active) {
            queries.updateStatus(TransferStatus.PENDING.name, clock(), task.id)
            when (TransferType.valueOf(task.type)) {
                TransferType.UPLOAD   -> launchUploadIfIdle(task.id)
                TransferType.DOWNLOAD -> launchDownloadJob(task.id)
            }
        }
    }

    /**
     * Recovers upload tasks that were interrupted by an app kill, then returns immediately.
     *
     * Schedules the recovery on the manager's [scope] so it is safe to call from any thread
     * or from Swift without bridging through Kotlin/Swift async. Prefer this over the suspend
     * [recoverInterruptedUploads] when calling from Swift host code.
     *
     * Resets every ACTIVE upload to PENDING (their coroutine no longer exists after process
     * kill) then re-runs all PENDING uploads via [recoverPendingUploads].
     *
     * Restarting is safe even if the background session delivered the upload successfully
     * while the app was closed: the [urlResolver] should return [UrlResult.AlreadyExist] for
     * content already accepted by the server, completing the task immediately without
     * re-uploading bytes.
     *
     * Call on every app launch before showing the transfer UI.
     */
    fun launchRecovery() {
        scope.launch {
            // 1. Reset ACTIVE uploads to PENDING so initialize() does not fail them.
            val now = clock()
            queries.selectByStatus(TransferStatus.ACTIVE.name).executeAsList()
                .filter { it.type == TransferType.UPLOAD.name }
                .forEach { queries.updateStatus(TransferStatus.PENDING.name, now, it.id) }
            // 2. Fail any remaining ACTIVE/UNZIPPING tasks (interrupted downloads cannot resume).
            initialize()
            // 3. Restart all PENDING uploads.
            recoverPendingUploads()
        }
    }

    /**
     * Re-run PENDING uploads on a background scheduler wake, then returns immediately.
     *
     * Schedules [recoverPendingUploads] on the manager's [scope] so it is safe to call from
     * Swift without bridging through Kotlin/Swift async. Each upload is guarded by
     * [launchUploadIfIdle] so no duplicate coroutines are spawned for uploads that are
     * already running (e.g. when the app is suspended, not killed, and coroutines simply
     * resume from their last suspension point).
     *
     * **Prefer this over [launchRecovery] when woken by a BGProcessingTask.** This only
     * re-queues PENDING uploads; it does not call [initialize] or alter ACTIVE tasks.
     * That makes it safe when the app is suspended — [launchRecovery] would destructively
     * mark in-flight downloads as FAILED via [initialize].
     */
    fun launchRecoverPendingUploads() {
        scope.launch { recoverPendingUploads() }
    }

    /**
     * Recovers upload tasks that were interrupted by an app kill.
     *
     * Resets every ACTIVE upload to PENDING (they lost their coroutine when the process was
     * killed) then re-runs all PENDING uploads via [recoverPendingUploads].
     *
     * Restarting is safe even if the background session already delivered the upload
     * successfully: the platform's [urlResolver] should return [UrlResult.AlreadyExist]
     * for content already accepted by the server, causing the task to complete immediately
     * without re-uploading the bytes.
     *
     * Call on every app launch (iOS) or process restart (Android) before showing the UI.
     */
    suspend fun recoverInterruptedUploads() {
        val now = clock()
        // 1. Reset ACTIVE uploads — their coroutine no longer exists.
        queries.selectByStatus(TransferStatus.ACTIVE.name).executeAsList()
            .filter { it.type == TransferType.UPLOAD.name }
            .forEach { queries.updateStatus(TransferStatus.PENDING.name, now, it.id) }
        // 2. Restart all PENDING uploads (includes the ones just reset above).
        recoverPendingUploads()
    }

    /**
     * Re-run all PENDING upload tasks. Call this when woken by a background scheduler
     * (e.g. [BackgroundTransferHandler.handleUploadRetryTask] on iOS) to retry the
     * URL-resolver → PUT loop while network connectivity is available.
     */
    suspend fun recoverPendingUploads() {
        val pending = queries.selectByStatus(TransferStatus.PENDING.name).executeAsList()
            .filter { it.type == TransferType.UPLOAD.name }
        for (task in pending) {
            launchUploadIfIdle(task.id)
        }
    }

    /**
     * Reset a FAILED task to PENDING and re-run it.
     */
    suspend fun retryTask(id: String) {
        val task = queries.selectById(id).executeAsOneOrNull() ?: return
        check(task.status == TransferStatus.FAILED.name) {
            "Only FAILED tasks can be retried, but task $id has status ${task.status}"
        }
        queries.resetForRetry(clock(), id)
        when (TransferType.valueOf(task.type)) {
            TransferType.UPLOAD   -> launchUploadIfIdle(id)
            TransferType.DOWNLOAD -> launchDownloadJob(id)
        }
    }

    // -------------------------------------------------------------------------
    // Public API — cancel / delete / clear
    // -------------------------------------------------------------------------

    /**
     * Cancel an in-progress or pending task.
     *
     * Cancels the coroutine/job associated with the task (if any) and marks it CANCELLED
     * in the database. Platform providers handle the platform-specific cancellation
     * (WorkManager on Android, NSURLSessionTask on iOS) via coroutine cancellation
     * propagation.
     *
     * No-op if the task is already in a terminal state (COMPLETED, FAILED, CANCELLED).
     */
    suspend fun cancelTask(id: String) {
        val task = queries.selectById(id).executeAsOneOrNull() ?: return
        val status = TransferStatus.valueOf(task.status)
        if (status == TransferStatus.COMPLETED ||
            status == TransferStatus.FAILED ||
            status == TransferStatus.CANCELLED
        ) return

        // Cancel the coroutine job first, then update DB.
        activeJobsMutex.withLock { activeJobs.remove(id) }?.cancel()
        runningUploadIdsMutex.withLock { runningUploadIds.remove(id) }
        queries.updateStatusAndError(TransferStatus.CANCELLED.name, "Cancelled by user", clock(), id)
    }

    /**
     * Delete a task from the database. Only terminal tasks (COMPLETED, FAILED, CANCELLED)
     * can be deleted. Active tasks must be cancelled first.
     */
    suspend fun deleteTask(id: String) {
        val task = queries.selectById(id).executeAsOneOrNull() ?: return
        val status = TransferStatus.valueOf(task.status)
        check(
            status == TransferStatus.COMPLETED ||
            status == TransferStatus.FAILED ||
            status == TransferStatus.CANCELLED
        ) {
            "Only terminal tasks can be deleted, but task $id has status ${task.status}"
        }
        queries.deleteById(id)
    }

    /**
     * Remove all tasks in a terminal state (COMPLETED, FAILED, CANCELLED) from the database.
     */
    fun clearCompleted() {
        queries.deleteByStatus(TransferStatus.COMPLETED.name)
        queries.deleteByStatus(TransferStatus.FAILED.name)
        queries.deleteByStatus(TransferStatus.CANCELLED.name)
    }

    /**
     * Suspends until no tasks are in [TransferStatus.ACTIVE] or [TransferStatus.UNZIPPING]
     * state. Returns immediately if the SDK is already idle.
     */
    suspend fun awaitIdle() {
        queries.selectByStatus(TransferStatus.ACTIVE.name)
            .asFlow()
            .mapToList(Dispatchers.Default)
            .combine(
                queries.selectByStatus(TransferStatus.UNZIPPING.name)
                    .asFlow()
                    .mapToList(Dispatchers.Default)
            ) { active, unzipping -> active + unzipping }
            .filter { it.isEmpty() }
            .first()
    }

    // -------------------------------------------------------------------------
    // Internal — task execution
    // -------------------------------------------------------------------------

    /**
     * Launches [runUploadTask] for [id] in [scope] only if no coroutine is already running it.
     * Uses [runningUploadIdsMutex] to make the check-and-insert atomic, preventing duplicate
     * coroutines from being spawned when [recoverPendingUploads] races with a new [upload] call
     * or is triggered multiple times in quick succession.
     */
    private suspend fun launchUploadIfIdle(id: String) {
        val alreadyRunning = runningUploadIdsMutex.withLock { !runningUploadIds.add(id) }
        if (alreadyRunning) return
        val job = scope.launch {
            try {
                runUploadTask(id)
            } finally {
                runningUploadIdsMutex.withLock { runningUploadIds.remove(id) }
            }
        }
        trackJob(id, job)
    }

    /**
     * Launches [runDownloadTask] for [id] in [scope] and registers the job for
     * cancellation support. All download launch sites go through this helper so
     * the [invokeOnCompletion] cleanup is never forgotten.
     */
    private fun launchDownloadJob(id: String) {
        val job = scope.launch { runDownloadTask(id) }
        trackJob(id, job)
    }

    /**
     * Registers [job] in [activeJobs] and schedules its removal on completion.
     *
     * Uses `scope.launch` inside `invokeOnCompletion` to acquire the mutex
     * asynchronously — `invokeOnCompletion` runs synchronously and must not block,
     * but we still need guaranteed cleanup (unlike the previous `tryLock` approach
     * which silently dropped the removal when the lock was contended).
     */
    private fun trackJob(id: String, job: Job) {
        // Synchronous insertion is fine here — we're called from a coroutine context
        // or from scope.launch. The mutex protects against concurrent map access.
        scope.launch { activeJobsMutex.withLock { activeJobs[id] = job } }
        job.invokeOnCompletion {
            scope.launch { activeJobsMutex.withLock { activeJobs.remove(id) } }
        }
    }

    private suspend fun runUploadTask(id: String) {
        try {
            val task = queries.selectById(id).executeAsOneOrNull() ?: return
            setStatus(id, TransferStatus.ACTIVE)
            // The platform provider owns the full resolver → PUT loop (including retries
            // and offline resilience). The manager only tracks status transitions.
            provider.execute(
                id = id,
                url = task.url,   // uploadKey stored in the url field at enqueue time
                path = pathResolver.fromStorage(task.localPath),
                type = TransferType.UPLOAD,
                headers = emptyMap(),
            ).collect { update ->
                when (update) {
                    is TransferUpdate.Progress -> setProgress(id, update.percent.toLong())
                    is TransferUpdate.Success  -> setStatus(id, TransferStatus.COMPLETED)
                    is TransferUpdate.Failure  ->
                        queries.updateStatusAndError(TransferStatus.FAILED.name, update.error, clock(), id)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            queries.updateStatusAndError(TransferStatus.FAILED.name, e.message ?: "Unknown error", clock(), id)
        }
    }

    private suspend fun runDownloadTask(id: String) {
        try {
            setStatus(id, TransferStatus.ACTIVE)

            val task = queries.selectById(id).executeAsOneOrNull() ?: return
            val headers: Map<String, String> = task.headers
                ?.let { Json.decodeFromString(it) }
                ?: emptyMap()

            provider.execute(
                id = id,
                url = task.url,
                path = pathResolver.fromStorage(task.localPath),
                type = TransferType.DOWNLOAD,
                headers = headers,
            ).collect { update ->
                when (update) {
                    is TransferUpdate.Progress -> setProgress(id, update.percent.toLong())
                    is TransferUpdate.Failure  -> throw TransferException(update.error)
                    is TransferUpdate.Success  -> Unit
                }
            }

            if (task.unzip != 0L) {
                setStatus(id, TransferStatus.UNZIPPING)
                val fresh = queries.selectById(id).executeAsOneOrNull() ?: return
                val absolutePath = pathResolver.fromStorage(fresh.localPath)
                val targetPath = "${absolutePath}.unzipped"
                zipEngine.cleanup(targetPath)
                    .getOrElse { throw TransferException(it.message ?: "Cleanup failed") }
                zipEngine.unzip(absolutePath, targetPath)
                    .getOrElse { throw TransferException(it.message ?: "Unzip failed") }
            }

            setStatus(id, TransferStatus.COMPLETED)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            queries.updateStatusAndError(TransferStatus.FAILED.name, e.message ?: "Unknown error", clock(), id)
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Returns a copy of [TransferTask] with [TransferTask.localPath] resolved from its
     * storage form to an absolute filesystem path via [pathResolver].
     */
    private fun TransferTask.withResolvedPath(): TransferTask =
        copy(localPath = pathResolver.fromStorage(localPath))

    private fun setStatus(id: String, status: TransferStatus) {
        queries.updateStatus(status.name, clock(), id)
    }

    private fun setProgress(id: String, percent: Long) {
        queries.updateProgress(percent, clock(), id)
    }

    private fun generateId(): String =
        Random.Default.nextBytes(16)
            .joinToString("") { it.toUByte().toString(16).padStart(2, '0') }
}

private class TransferException(message: String) : Exception(message)

/**
 * Returns the current time in milliseconds since epoch.
 * Uses platform.Foundation.NSDate on iOS / System.currentTimeMillis() on JVM+Android.
 */
internal expect fun currentTimeMillis(): Long
