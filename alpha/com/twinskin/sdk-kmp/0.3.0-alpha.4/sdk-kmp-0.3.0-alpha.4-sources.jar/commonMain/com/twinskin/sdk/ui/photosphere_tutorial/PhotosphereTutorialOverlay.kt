@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.photosphere_tutorial

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.capture.i18n.LocalCaptureStrings
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Tutorial overlay shown after `captureReference` succeeds. Demonstrates
 * the 16-stop orbital motion (4 rounds × 4 cardinals, R1..R4 offset by
 * +22.5°) by animating the freshly captured reference image around a
 * full-screen orbit.
 *
 * The host (iOS `CaptureView`, Android `CaptureScreen`) pauses the
 * upstream photosphere session on `onPauseChanged(true)` and resumes on
 * `onPauseChanged(false)`. Persistence of `seenAtLeastOnce` and
 * `dontShowAgain` lives on the host side (UserDefaults / SharedPreferences).
 */
@Composable
public fun PhotosphereTutorialOverlay(
    refImage: ImageBitmap,
    seenAtLeastOnce: Boolean,
    dontShowAgainInitial: Boolean,
    onPauseChanged: (Boolean) -> Unit,
    onDontShowAgainChanged: (Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    val phoneAngleDeg = remember { Animatable(0f) }
    val phoneRadiusFrac = remember { Animatable(0f) }
    val tiltAngleDeg = remember { Animatable(0f) }
    val shutterPulse = remember { Animatable(0f) }
    // Slides the cardinal-dot ring by +22.5° between rounds.
    val cardinalOffsetDeg = remember { Animatable(0f) }

    var dismissEnabled by remember { mutableStateOf(seenAtLeastOnce) }
    var dontShowAgain by remember { mutableStateOf(dontShowAgainInitial) }
    var currentRound by remember { mutableStateOf(0) }

    // DisposableEffect so `onPauseChanged(false)` fires on every dispose
    // path (Got-it tap, parent toggle, configuration change, external
    // VC dismiss) — coupling it to LaunchedEffect's cancellation would
    // miss the cases where the driver short-circuits.
    DisposableEffect(Unit) {
        onPauseChanged(true)
        onDispose { onPauseChanged(false) }
    }

    LaunchedEffect(Unit) {
        delay((InitialSettleSec * 1000).toLong())

        val exitSpec = tween<Float>(
            durationMillis = (ExitCentreSec * 1000).toInt(),
        )
        coroutineScope {
            launch { phoneRadiusFrac.animateTo(1f, exitSpec) }
            launch { tiltAngleDeg.animateTo(TiltMagDeg, exitSpec) }
        }
        launch { triggerShutter(shutterPulse) }

        // Per round: 3 inter-cardinal legs (90°, 5 s each) then a
        // 112.5° transition (90° + RoundOffsetDeg, 1 s) that lands on
        // cardinal 1 of the next round while sliding the dot ring by
        // +22.5°. The phone always moves clockwise.
        //
        // Targets are held in local accumulators rather than
        // re-reading `Animatable.value`; a stale-frame race on
        // Compose-for-iOS would otherwise repeat the previous target.
        val legSpec = tween<Float>(
            durationMillis = (OrbitLegSec * 1000).toInt(),
            easing = LinearEasing,
        )
        val transitionSpec = tween<Float>(
            durationMillis = (RoundTransitionSec * 1000).toInt(),
            easing = LinearEasing,
        )
        var cumulativeAngleDeg = 0f
        var cumulativeOffsetDeg = 0f
        var loopsCompleted = 0
        while (true) {
            for (cardinalStep in 0 until 3) {
                cumulativeAngleDeg += 90f
                phoneAngleDeg.animateTo(cumulativeAngleDeg, legSpec)
                launch { triggerShutter(shutterPulse) }
            }
            currentRound = (currentRound + 1) % RoundsInCycle
            cumulativeAngleDeg += 90f + RoundOffsetDeg
            cumulativeOffsetDeg += RoundOffsetDeg
            val transitionPhoneTarget = cumulativeAngleDeg
            val transitionOffsetTarget = cumulativeOffsetDeg
            coroutineScope {
                launch {
                    phoneAngleDeg.animateTo(transitionPhoneTarget, transitionSpec)
                }
                launch {
                    cardinalOffsetDeg.animateTo(transitionOffsetTarget, transitionSpec)
                }
            }
            launch { triggerShutter(shutterPulse) }
            loopsCompleted += 1
            if (loopsCompleted >= 1 && !dismissEnabled) {
                dismissEnabled = true
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Spacer(Modifier.height(56.dp))

            Text(
                text = LocalCaptureStrings.current.psTutorialMoveAround,
                style = TextStyle(
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                ),
                modifier = Modifier.padding(horizontal = 24.dp),
            )

            Text(
                text = LocalCaptureStrings.current.psTutorialOrbitExplain,
                style = TextStyle(
                    fontSize = 14.sp,
                    color = Color.White.copy(alpha = 0.75f),
                    textAlign = TextAlign.Center,
                ),
                modifier = Modifier.padding(horizontal = 24.dp),
            )

            OrbitScene(
                refImage = refImage,
                phoneAngleDeg = phoneAngleDeg,
                phoneRadiusFrac = phoneRadiusFrac,
                tiltAngleDeg = tiltAngleDeg,
                shutterPulse = shutterPulse,
                cardinalOffsetDeg = cardinalOffsetDeg,
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )

            RoundIndicator(
                currentRound = currentRound,
                totalRounds = RoundsInCycle,
                modifier = Modifier.padding(top = 2.dp),
            )

            DontShowAgainRow(
                checked = dontShowAgain,
                onToggle = {
                    val next = !dontShowAgain
                    dontShowAgain = next
                    onDontShowAgainChanged(next)
                },
                modifier = Modifier.padding(horizontal = 40.dp, vertical = 6.dp),
            )

            Button(
                onClick = {
                    if (dismissEnabled) onDismiss()
                },
                enabled = dismissEnabled,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF33C759),
                    disabledContainerColor = Color.White.copy(alpha = 0.15f),
                    contentColor = Color.White,
                    disabledContentColor = Color.White,
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 40.dp)
                    .height(52.dp),
            ) {
                Text(
                    text = if (dismissEnabled) {
                        LocalCaptureStrings.current.psTutorialStart
                    } else {
                        LocalCaptureStrings.current.psTutorialWatching
                    },
                    style = TextStyle(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                    ),
                )
            }

            Text(
                text = LocalCaptureStrings.current.psTutorialPaused,
                style = TextStyle(
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center,
                ),
                modifier = Modifier
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 24.dp),
            )
        }
    }
}

@Composable
private fun OrbitScene(
    refImage: ImageBitmap,
    phoneAngleDeg: Animatable<Float, *>,
    phoneRadiusFrac: Animatable<Float, *>,
    tiltAngleDeg: Animatable<Float, *>,
    shutterPulse: Animatable<Float, *>,
    cardinalOffsetDeg: Animatable<Float, *>,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(
        modifier = modifier,
        contentAlignment = Alignment.Center,
    ) {
        val sideDp = min(maxWidth.value, maxHeight.value).dp
        val orbitRDp = sideDp * 0.34f
        val woundDiaDp = orbitRDp * 1.6f

        Box(
            modifier = Modifier
                .size(woundDiaDp)
                .clip(CircleShape),
        ) {
            Image(
                bitmap = refImage,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f)),
            )
        }
        Box(
            modifier = Modifier
                .size(woundDiaDp)
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.18f),
                    shape = CircleShape,
                ),
        )

        Canvas(modifier = Modifier.size(orbitRDp * 2)) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val r = min(size.width, size.height) / 2f - 4f
            drawCircle(
                color = Color.White.copy(alpha = 0.35f),
                radius = r,
                center = Offset(cx, cy),
                style = Stroke(
                    width = 1.5f * density,
                    pathEffect = PathEffect.dashPathEffect(
                        floatArrayOf(3f * density, 4f * density),
                    ),
                ),
            )
            // Read `.value` inside Canvas (deferred-read form) so the
            // dots slide smoothly without triggering recomposition.
            val offsetRad = cardinalOffsetDeg.value * (PI.toFloat() / 180f)
            for (i in 0 until 4) {
                val p = i * 90f * (PI.toFloat() / 180f) + offsetRad
                drawCircle(
                    color = Color.White.copy(alpha = 0.55f),
                    radius = 3f * density,
                    center = Offset(
                        x = cx + sin(p) * r,
                        y = cy - cos(p) * r,
                    ),
                )
            }
        }

        // `.value` read inside the graphicsLayer lambda: deferred-read
        // form re-invokes the block on every animator tick without
        // recomposing the tree.
        val orbitRadiusDp = orbitRDp
        Box(
            modifier = Modifier.graphicsLayer {
                val phi = phoneAngleDeg.value * (PI.toFloat() / 180f)
                val radiusPx = orbitRadiusDp.toPx() * phoneRadiusFrac.value
                translationX = sin(phi) * radiusPx
                translationY = -cos(phi) * radiusPx
            },
        ) {
            PhoneFrame(
                refImage = refImage,
                phoneAngleDeg = phoneAngleDeg,
                tiltAngleDeg = tiltAngleDeg,
            )
            ShutterRing(
                pulse = shutterPulse,
                diameterDp = 110f,
            )
        }
    }
}

@Composable
private fun PhoneFrame(
    refImage: ImageBitmap,
    phoneAngleDeg: Animatable<Float, *>,
    tiltAngleDeg: Animatable<Float, *>,
) {
    // Decompose "rotate by θ around (cos φ, sin φ, 0)" into Compose's
    // separate rotationX/rotationY eulers; the sequential composition
    // differs from a true arbitrary-axis rotation but visually matches
    // at ~40°. Sign convention: φ=0→top tilts away, φ=90→right tilts
    // away, φ=180→bottom tilts away, φ=270→left tilts away.
    val frameW = 84.dp
    val frameH = 158.dp
    val bezelCorner = 15.dp
    val screenCorner = 12.dp
    val bezelInset = 3.dp
    val islandW = 35.dp
    val islandH = 8.dp
    Box(
        modifier = Modifier
            .size(width = frameW, height = frameH)
            .shadow(8.dp, RoundedCornerShape(bezelCorner))
            .graphicsLayer {
                val phi = phoneAngleDeg.value * (PI.toFloat() / 180f)
                val tilt = tiltAngleDeg.value
                rotationX = tilt * cos(phi)
                rotationY = tilt * sin(phi)
                cameraDistance = 16f * density
            },
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(bezelCorner))
                .background(Color.Black)
                .border(
                    width = 1.5.dp,
                    color = Color.White.copy(alpha = 0.22f),
                    shape = RoundedCornerShape(bezelCorner),
                ),
        )
        Image(
            bitmap = refImage,
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .padding(bezelInset)
                .clip(RoundedCornerShape(screenCorner)),
            contentScale = ContentScale.Crop,
        )
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = bezelInset + 4.dp)
                .size(width = islandW, height = islandH)
                .clip(RoundedCornerShape(percent = 50))
                .background(Color.Black),
        )
    }
}

@Composable
private fun ShutterRing(pulse: Animatable<Float, *>, diameterDp: Float) {
    val dia = diameterDp.dp
    Box(
        modifier = Modifier
            .size(dia)
            .graphicsLayer {
                val p = pulse.value
                val scale = 1f + p * 1.4f
                scaleX = scale
                scaleY = scale
                alpha = 1f - p
            }
            .border(
                width = 3.dp,
                color = Color.White.copy(alpha = 0.85f),
                shape = CircleShape,
            ),
    )
}

@Composable
private fun RoundIndicator(
    currentRound: Int,
    totalRounds: Int,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(
            text = LocalCaptureStrings.current.psRoundIndicator((currentRound + 1).toString(), totalRounds.toString()),
            style = TextStyle(
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White.copy(alpha = 0.85f),
            ),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(totalRounds) { i ->
                val isCurrent = i == currentRound
                Box(
                    modifier = Modifier
                        .size(width = 18.dp, height = 4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            if (isCurrent) {
                                Color(0xFF33C759)
                            } else {
                                Color.White.copy(alpha = 0.25f)
                            },
                        ),
                )
            }
        }
    }
}

@Composable
private fun DontShowAgainRow(
    checked: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onToggle,
            ),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(RoundedCornerShape(4.dp))
                .border(
                    width = 1.5.dp,
                    color = Color.White.copy(alpha = 0.8f),
                    shape = RoundedCornerShape(4.dp),
                )
                .background(
                    color = if (checked) {
                        Color(0xFF33C759)
                    } else {
                        Color.Transparent
                    },
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (checked) {
                Text(
                    text = "✓",
                    style = TextStyle(
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                    ),
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = LocalCaptureStrings.current.psDoNotShowAgain,
            style = TextStyle(
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.9f),
            ),
        )
    }
}

private suspend fun triggerShutter(pulse: Animatable<Float, *>) {
    pulse.snapTo(0f)
    pulse.animateTo(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 550),
    )
}

/** Exaggerated tilt — pedagogical, not the true 15° capture target. */
private const val TiltMagDeg: Float = 40f

private const val ExitCentreSec: Float = 1.0f
private const val OrbitLegSec: Float = 5.0f

/** Azimuth shift between successive rounds (R2 = R1 + 22.5°, …). */
private const val RoundOffsetDeg: Float = 22.5f
private const val RoundsInCycle: Int = 4
private const val RoundTransitionSec: Float = 1.0f
private const val InitialSettleSec: Float = 0.4f
