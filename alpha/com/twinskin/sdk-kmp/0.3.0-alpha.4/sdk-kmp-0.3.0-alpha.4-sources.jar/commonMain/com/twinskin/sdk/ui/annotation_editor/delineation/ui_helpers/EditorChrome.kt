package com.twinskin.sdk.ui.annotation_editor.delineation.ui_helpers

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.outlined.Help
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.theme.TwinSkinColors

/**
 * Shared editor chrome that mirrors the Claude Design prototype's
 * `editor_shared.jsx` (`EditorBar` + `EditorToolbar`) verbatim in
 * layout / visuals. Kept in `delineation/ui_helpers` (not the
 * shared `theme/` package) because it is specific to the
 * wound-delineation flow's chrome and the brand components in
 * `theme/` stay generic.
 *
 * Visual-only: these are dumb composables driven entirely by their
 * callbacks. State, navigation, and the canvas engine live in the
 * caller.
 */

/**
 * Prototype `EditorBar` — a status-bar-inset top bar with a leading
 * back chevron, a title (17 sp, w600, ink) + optional step subtitle
 * (11.5 sp, w600, ink2), an optional trailing help icon, and a
 * hairline bottom border (`tintHi`).
 */
@Composable
internal fun EditorBar(
    title: String,
    onBack: () -> Unit,
    backContentDescription: String,
    modifier: Modifier = Modifier,
    onHelp: (() -> Unit)? = null,
    helpContentDescription: String? = null,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
                .padding(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = backContentDescription,
                    tint = TwinSkinColors.Ink,
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                ),
                color = TwinSkinColors.Ink,
                modifier = Modifier.weight(1f).padding(start = 4.dp),
            )
            if (onHelp != null) {
                IconButton(onClick = onHelp) {
                    Icon(
                        Icons.Outlined.Help,
                        contentDescription = helpContentDescription,
                        tint = TwinSkinColors.Ink2,
                    )
                }
            }
        }
        HorizontalDivider(thickness = 1.dp, color = TwinSkinColors.TintHi)
    }
}

/**
 * Prototype `EditorToolbar` — the canvas bottom bar: Undo + Redo
 * icon+label tool buttons, a danger-tinted Delete icon+label tool
 * button, and a prominent filled primary CTA (UPPERCASE, teal fill
 * when enabled, `line` fill when disabled) pushed to the trailing
 * edge. Surface with a `tintHi` top border on the `card` surface.
 * Paddings are tighter than the two-button prototype so the
 * three-button row + CTA fits 360 dp-class phones.
 */
@Composable
internal fun EditorToolbar(
    undoLabel: String,
    onUndo: () -> Unit,
    undoEnabled: Boolean,
    redoLabel: String,
    onRedo: () -> Unit,
    redoEnabled: Boolean,
    deleteLabel: String,
    onDelete: () -> Unit,
    deleteEnabled: Boolean,
    primaryLabel: String,
    onPrimary: () -> Unit,
    primaryEnabled: Boolean,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxWidth()) {
        HorizontalDivider(thickness = 1.dp, color = TwinSkinColors.TintHi)
        Surface(color = TwinSkinColors.CardSurface) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(start = 10.dp, end = 12.dp, top = 14.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                ToolButton(
                    icon = Icons.AutoMirrored.Filled.Undo,
                    label = undoLabel,
                    onClick = onUndo,
                    enabled = undoEnabled,
                )
                ToolButton(
                    icon = Icons.AutoMirrored.Filled.Redo,
                    label = redoLabel,
                    onClick = onRedo,
                    enabled = redoEnabled,
                )
                ToolButton(
                    icon = Icons.Filled.Delete,
                    label = deleteLabel,
                    onClick = onDelete,
                    enabled = deleteEnabled,
                    danger = true,
                )
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = onPrimary,
                    enabled = primaryEnabled,
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TwinSkinColors.Teal,
                        contentColor = TwinSkinColors.OnTeal,
                        disabledContainerColor = TwinSkinColors.Line,
                        disabledContentColor = TwinSkinColors.OnTeal,
                    ),
                    contentPadding = PaddingValues(
                        horizontal = 22.dp,
                        vertical = 14.dp,
                    ),
                ) {
                    Text(
                        primaryLabel.uppercase(),
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontSize = 14.5.sp,
                            letterSpacing = 0.6.sp,
                        ),
                    )
                }
            }
        }
    }
}

@Composable
private fun ToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    enabled: Boolean,
    danger: Boolean = false,
) {
    val tint: Color = when {
        !enabled -> TwinSkinColors.Line
        danger -> TwinSkinColors.Error
        else -> TwinSkinColors.Ink2
    }
    Column(
        // Width follows the localised label (min 48 dp touch target)
        // — a fixed width truncated longer locales ("Supprimer").
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .height(52.dp)
            .widthIn(min = 48.dp)
            .padding(horizontal = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(22.dp),
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = label,
            maxLines = 1,
            softWrap = false,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.5.sp,
                fontWeight = FontWeight.SemiBold,
            ),
            color = tint,
        )
    }
}
