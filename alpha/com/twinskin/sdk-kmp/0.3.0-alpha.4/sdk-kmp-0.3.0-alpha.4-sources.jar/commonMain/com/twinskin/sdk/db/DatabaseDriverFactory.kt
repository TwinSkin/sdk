package com.twinskin.sdk.db

import app.cash.sqldelight.db.SqlDriver

internal expect class DatabaseDriverFactory(dbName: String) {
    fun create(): SqlDriver
}
