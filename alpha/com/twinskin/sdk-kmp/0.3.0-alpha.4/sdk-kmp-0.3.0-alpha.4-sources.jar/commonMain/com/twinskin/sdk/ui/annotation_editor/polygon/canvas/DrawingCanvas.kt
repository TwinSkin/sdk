package com.twinskin.sdk.ui.annotation_editor.polygon.canvas

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.twinskin.sdk.ui.annotation_editor.delineation.canvas.parentWoundOfTissue
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Tissue
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.EditorController
import kotlin.math.roundToInt
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Shared drawing canvas (spec §9) — the per-screen Compose widget
 * that hosts the image, the editable polygons, the open stroke,
 * the magnifier, and the gesture loop. Used by both screen 2
 * (wound editor, [readOnlyWounds] empty) and screen 4 (tissue
 * editor, [readOnlyWounds] = wound outlines + [readOnlyOtherTissues]
 * = tissues of other types).
 *
 * **Coordinate convention** (per M8b prep architecture): the image
 * is drawn directly via `drawImage(dstOffset, dstSize)` with the
 * combined fit + zoom transform composed into dst space. All
 * polygon painters operate on **canvas-pixel** vertices — the host
 * walks `imageToCanvas` per-vertex at paint time. M8b's
 * `Modifier.graphicsLayer` swap on the image painter is therefore
 * additive: the polygon painters don't move.
 *
 * **Gesture loop** (spec §6.7/§6.8): manually tracks pointer count
 * via `awaitEachGesture`. One finger → controller. Two fingers →
 * `ZoomPanController`. While one finger is mid-gesture, additional
 * pointer-downs are silently ignored. See [drawCanvasGesture] for
 * the state machine.
 *
 * **A11y**: callers supply localised `contentDescription`s via the
 * `Strings` interface (`woundCanvasContentDescription`,
 * `magnifierContentDescription`, …).
 */
@Composable
internal fun DrawingCanvas(
    image: ImageBitmap,
    imageSize: Size,
    controller: EditorController,
    zoomPan: ZoomPanController,
    readOnlyWounds: List<Wound>,
    readOnlyOtherTissues: List<Tissue>,
    canvasContentDescription: String,
    magnifierContentDescription: String,
    modifier: Modifier = Modifier,
    /**
     * Color of each editable polygon at index `i`. Default is the
     * wound-screen shared orange ([ClosedPolygonColor]); the tissue
     * screen passes a function that returns the per-tissue clinical
     * color. Pure painter input — has no effect on gesture routing.
     */
    polygonColorAt: (Int) -> Color = { ClosedPolygonColor },
    /**
     * Screen-2 controllers pass null. Screen-4 controllers pass the
     * tissue list (the controller's `_polygons`), which DrawingCanvas
     * uses to (a) resolve the parent wound at gesture start and pass
     * it through `GestureCtx.confinementOutline`, and (b) re-resolve
     * the parent on focus change for reshape. Color is decided by
     * [polygonColorAt] separately — this parameter is purely about
     * the parent-wound source.
     */
    tissueParentSource: List<Tissue>? = null,
    /**
     * Colour for the in-progress open stroke and its closure halo.
     * Defaults to [OpenStrokeColor] (green — wound screen); the
     * tissue screen passes the type's clinical colour so the
     * dashed in-progress line previews the closed colour.
     */
    openStrokeColor: Color = OpenStrokeColor,
    /**
     * Screen hook for double-tap, in image-pixel coordinates. Return
     * true to consume the double-tap (e.g. the tissue screen's
     * region fill); false / null falls through to the built-in zoom
     * toggle (fit ↔ [DOUBLE_TAP_ZOOM_SCALE] anchored at the tap).
     */
    onDoubleTap: ((Offset) -> Boolean)? = null,
) {
    var lastFingerCanvas by remember { mutableStateOf<Offset?>(null) }
    var canvasSize by remember { mutableStateOf(Size.Zero) }
    var activeParentWoundIdx by remember { mutableStateOf<Int?>(null) }
    val doubleTapDetector = remember { DoubleTapDetector() }
    val zoomAnimScope = rememberCoroutineScope()
    val zoomAnimJob = remember { arrayOfNulls<Job>(1) }
    val onDoubleTapState = rememberUpdatedState(onDoubleTap)

    // pointerInput keys compare via equals(); a fresh
    // tissueParentSource list every recomposition would cancel and
    // restart the gesture loop mid-reshape. The gesture loop only
    // needs the boolean — keep the list reachable through
    // rememberUpdatedState so the key set stays stable.
    val onScreen4: Boolean = tissueParentSource != null
    val tissueParentSourceState = rememberUpdatedState(tissueParentSource)

    // Propagate canvas / image size into the ZoomPanController so its
    // fit transform stays current after a device rotation, foldable
    // unfold, or split-screen resize. Without this, pan/zoom math
    // clamps against the stale fit while DrawScope draws into the new
    // viewport — visible as image edges revealing blank canvas after
    // rotation. Width > 0 guard skips the initial Size.Zero tick
    // before the first layout pass.
    LaunchedEffect(canvasSize, imageSize) {
        if (canvasSize.width > 0f && canvasSize.height > 0f) {
            zoomPan.setViewport(canvasSize, imageSize)
            // The held magnifier position is canvas-px; after a resize
            // it would map to a different image point, so drop it
            // rather than silently retarget the crosshair.
            lastFingerCanvas = null
        }
    }

    // Reshape on screen 4: parent wound = the wound containing the
    // focused tissue's centroid. Re-resolved whenever focus changes.
    // Reads the latest tissue list via [tissueParentSourceState]
    // so the effect doesn't restart on every recomposition.
    LaunchedEffect(controller, readOnlyWounds) {
        snapshotFlow { controller.focusedIndex }.collect { idx ->
            val tissues = tissueParentSourceState.value
            if (idx != null && tissues != null && idx in tissues.indices) {
                activeParentWoundIdx = parentWoundOfTissue(
                    tissue = tissues[idx],
                    wounds = readOnlyWounds.map { it.outline },
                )
            }
        }
    }

    // U6 non-traversal cue fade — animated at the composable scope so
    // the State subscription survives recompositions inside the
    // DrawScope block below. The last non-null contact is held
    // separately: the controller nulls the contact the instant the
    // stroke leaves the boundary, and drawing gated on the live value
    // would kill the cue on that exact frame — the documented 250 ms
    // fade-out could never render.
    val cueContact = controller.lastStrokeClampContact.value
    // Plain holder, not snapshot state: recomposition is already driven
    // by the cueContact / cueAlpha reads, and a state write here would
    // be a backwards write (read-then-write in the same composition).
    val heldCue = remember { arrayOfNulls<Offset>(1) }
    if (cueContact != null) heldCue[0] = cueContact
    val heldCueContact: Offset? = heldCue[0]
    val cueAlpha by animateFloatAsState(
        targetValue = if (cueContact != null) 1f else 0f,
        animationSpec = tween(durationMillis = 250),
        label = "non-traversal-cue-fade",
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            // Compose Canvas doesn't clip to its bounds; without this the
            // zoomed drawImage below paints over the sibling app bar / toolbar.
            .clipToBounds()
            .semantics {
                contentDescription = canvasContentDescription
                role = Role.Image
            }
            .onSizeChanged { canvasSize = Size(it.width.toFloat(), it.height.toFloat()) }
            .pointerInput(controller, zoomPan, readOnlyWounds, readOnlyOtherTissues, onScreen4) {
                try {
                    awaitEachGesture {
                        drawCanvasGesture(
                            controller = controller,
                            zoomPan = zoomPan,
                            canvasSizeRead = { canvasSize },
                            imageSize = imageSize,
                            readOnlyWounds = readOnlyWounds,
                            readOnlyOtherTissues = readOnlyOtherTissues,
                            onScreen4 = onScreen4,
                            onFingerCanvasUpdate = {
                                // A fresh touch takes over from any running
                                // double-tap zoom animation.
                                if (it != null) zoomAnimJob[0]?.cancel()
                                lastFingerCanvas = it
                            },
                            getActiveParentWoundIdx = { activeParentWoundIdx },
                            setActiveParentWoundIdx = { activeParentWoundIdx = it },
                            onTapGesture = { tapCanvas ->
                                if (doubleTapDetector.onTap(tapCanvas)) {
                                    // Undo the taps' side effect before acting:
                                    // each tap on free canvas seeded a dot stroke.
                                    controller.discardNascentOpenStroke()
                                    val consumed = onDoubleTapState.value
                                        ?.invoke(zoomPan.toScene(tapCanvas)) == true
                                    if (!consumed) {
                                        val target = doubleTapTargetScale(zoomPan.scale)
                                        zoomAnimJob[0]?.cancel()
                                        zoomAnimJob[0] = zoomAnimScope.launch {
                                            animate(
                                                initialValue = zoomPan.scale,
                                                targetValue = target,
                                                animationSpec = tween(durationMillis = 250),
                                            ) { value, _ ->
                                                zoomPan.setScaleAnchored(value, tapCanvas)
                                            }
                                        }
                                    }
                                }
                            },
                        )
                    }
                } finally {
                    // The gesture coroutine dies without an up event when
                    // a pointerInput key changes or the canvas leaves
                    // composition mid-gesture. A hoisted controller would
                    // then silently resume the stale stroke/reshape on
                    // the next touch — abort it instead.
                    controller.cancelActiveGesture()
                }
            },
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Re-read state values inside the draw scope so Compose
            // re-invokes the draw block when any changes.
            @Suppress("UNUSED_VARIABLE") val rev = controller.revision.value
            val zp = zoomPan.state.value
            val zoomScale = zp.first
            val zoomPanOffset = zp.second
            val sz = size

            // 1. Image — composed fit + zoom transform into dst space.
            val fit = fitTransform(sz, imageSize)
            val effectiveScale = fit.fitScale * zoomScale
            val centredOriginX = (sz.width - imageSize.width * effectiveScale) * 0.5f
            val centredOriginY = (sz.height - imageSize.height * effectiveScale) * 0.5f
            // Round (don't truncate) the integer dst, and derive the
            // size from the rounded edges: the polygon painters use the
            // exact float transform, and toInt()'s truncation toward
            // zero drifted the image up to ~1 px against the contours
            // while zoomed (visible contour "swimming" during a pinch).
            val originX = centredOriginX + zoomPanOffset.x
            val originY = centredOriginY + zoomPanOffset.y
            val dstX = originX.roundToInt()
            val dstY = originY.roundToInt()
            drawImage(
                image = image,
                dstOffset = IntOffset(dstX, dstY),
                dstSize = IntSize(
                    ((originX + imageSize.width * effectiveScale).roundToInt() - dstX)
                        .coerceAtLeast(1),
                    ((originY + imageSize.height * effectiveScale).roundToInt() - dstY)
                        .coerceAtLeast(1),
                ),
            )

            fun toCanvas(p: Offset): Offset = imageToCanvas(
                imagePos = p,
                canvasSize = sz,
                imageSize = imageSize,
                zoomScale = zoomScale,
                zoomPan = zoomPanOffset,
            )

            // 2. Read-only wounds (screen 4) — dashed gray.
            for (wound in readOnlyWounds) {
                drawDashedWound(wound.outline.map(::toCanvas), zoomScale = zoomScale)
            }

            // 3. Read-only other-type tissues (screen 4) — clinical colours, thin.
            for (tissue in readOnlyOtherTissues) {
                drawClosedPolygon(
                    canvasPoly = tissue.outline.map(::toCanvas),
                    color = clinicalColorFor(tissue.type),
                    focused = false,
                    zoomScale = zoomScale,
                )
            }

            // 4. Editable polygons (wounds on screen 2; tissues on screen 4).
            for ((i, poly) in controller.polygons.withIndex()) {
                drawClosedPolygon(
                    canvasPoly = poly.map(::toCanvas),
                    color = polygonColorAt(i),
                    focused = (i == controller.focusedIndex),
                    zoomScale = zoomScale,
                )
            }

            // 5. Open stroke + closure halo + paused-stroke resume dot.
            val open = controller.openStroke
            if (open != null) {
                drawOpenStroke(
                    open.samples.map(::toCanvas),
                    color = openStrokeColor,
                    zoomScale = zoomScale,
                )
                val finger = lastFingerCanvas
                val firstCanvas = toCanvas(open.firstPoint)
                if (finger != null && open.isClosureCandidate(finger, firstCanvas)) {
                    drawFirstPointHalo(firstCanvas, color = openStrokeColor)
                }
                // Stroke is "on hold" between gestures — mark the
                // resume end so the user knows which side to touch
                // back near. Hidden during draw / resume since the
                // end is then under the moving fingertip.
                if (controller.activeGesture == null) {
                    drawResumePointDot(toCanvas(open.lastSampleImagePx))
                }
            }

            // 6. Non-traversal cue (U6) — fades to 0 over 250 ms after
            // controller.lastStrokeClampContact transitions to null,
            // drawn at the held (last non-null) contact position.
            if (cueAlpha > 0f) {
                heldCueContact?.let { cueImagePx ->
                    drawNonTraversalCue(toCanvas(cueImagePx), alpha = cueAlpha)
                }
            }
        }

        // 7. Magnifier strip — top-anchored, follows the finger.
        // Read revision so polygon/openStroke commits trigger a
        // recompose of the magnifier's overlay state.
        @Suppress("UNUSED_VARIABLE") val magRev = controller.revision.value
        val fingerImage: Offset? = lastFingerCanvas?.let { finger ->
            canvasToImage(
                canvasPos = finger,
                canvasSize = canvasSize,
                imageSize = imageSize,
                zoomScale = zoomPan.scale,
                zoomPan = zoomPan.offset,
            )
        }
        val magnifierOverlay = buildMagnifierOverlay(
            controller = controller,
            readOnlyWounds = readOnlyWounds,
            readOnlyOtherTissues = readOnlyOtherTissues,
            polygonColorAt = polygonColorAt,
            fingerCanvasPx = lastFingerCanvas,
            cueContact = heldCueContact,
            cueAlpha = cueAlpha,
            canvasSize = canvasSize,
            imageSize = imageSize,
            zoomScale = zoomPan.scale,
            zoomPan = zoomPan.offset,
            openStrokeColor = openStrokeColor,
        )
        MagnifierBar(
            image = image,
            imageSize = imageSize,
            fingerImagePx = fingerImage,
            contentDescription = magnifierContentDescription,
            overlay = magnifierOverlay,
            canvasZoomScale = zoomPan.scale,
        )
    }
}

private fun buildMagnifierOverlay(
    controller: EditorController,
    readOnlyWounds: List<Wound>,
    readOnlyOtherTissues: List<Tissue>,
    polygonColorAt: (Int) -> Color,
    fingerCanvasPx: Offset?,
    cueContact: Offset?,
    cueAlpha: Float,
    canvasSize: Size,
    imageSize: Size,
    zoomScale: Float,
    zoomPan: Offset,
    openStrokeColor: Color,
): MagnifierOverlay {
    val polygons = controller.polygons.mapIndexed { i, poly ->
        MagnifierPolygon(
            outline = poly,
            color = polygonColorAt(i),
            focused = (i == controller.focusedIndex),
        )
    } + readOnlyOtherTissues.map { tissue ->
        MagnifierPolygon(
            outline = tissue.outline,
            color = clinicalColorFor(tissue.type),
            focused = false,
        )
    }

    val open = controller.openStroke
    val firstHalo: Offset? = if (open != null && fingerCanvasPx != null && canvasSize.width > 0f) {
        val firstCanvas = imageToCanvas(
            imagePos = open.firstPoint,
            canvasSize = canvasSize,
            imageSize = imageSize,
            zoomScale = zoomScale,
            zoomPan = zoomPan,
        )
        if (open.isClosureCandidate(fingerCanvasPx, firstCanvas)) open.firstPoint else null
    } else {
        null
    }

    val cue: Pair<Offset, Float>? =
        if (cueAlpha > 0f) cueContact?.let { it to cueAlpha } else null

    val resumePoint: Offset? = if (open != null && controller.activeGesture == null) {
        open.lastSampleImagePx
    } else {
        null
    }

    return MagnifierOverlay(
        polygonsImagePx = polygons,
        openStrokeImagePx = open?.samples,
        openStrokeColor = openStrokeColor,
        firstPointHaloImagePx = firstHalo,
        resumePointImagePx = resumePoint,
        dashedWoundsImagePx = readOnlyWounds.map { it.outline },
        nonTraversalCueImagePx = cue,
    )
}
