package com.twinskin.sdk.ui.annotation_editor.delineation.dashboard

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable

/**
 * Affirmative-choice dialog offered before opening the tissue
 * drawing screen for the last unresolved type. Not destructive,
 * so the confirm button uses primary colors (vs `ConfirmDialog`'s
 * error tint). Backdrop / system-back dismiss is silent
 * ([onDismiss]) and distinct from the explicit decline
 * ([onDecline]) — accidentally tapping outside should NOT
 * navigate the user into the drawing screen.
 */
@Composable
internal fun AutoFillDialog(
    title: String,
    body: String,
    confirmLabel: String,
    declineLabel: String,
    onConfirm: () -> Unit,
    onDecline: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(body) },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            ) { Text(confirmLabel) }
        },
        dismissButton = {
            TextButton(onClick = onDecline) { Text(declineLabel) }
        },
    )
}
