package com.twinskin.sdk.transfer

import kotlinx.coroutines.flow.Flow

internal interface FileTransferProvider {
    fun execute(
        id: String,
        url: String,
        path: String,
        type: TransferType,
        headers: Map<String, String> = emptyMap(),
    ): Flow<TransferUpdate>

}
