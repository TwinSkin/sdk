package com.twinskin.sdk.ui.annotation_editor.generic.flow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.annotation_editor.generic.i18n.SdkGenericStrings
import com.twinskin.sdk.ui.theme.BrandCard
import com.twinskin.sdk.ui.theme.PrimaryButton
import com.twinskin.sdk.ui.theme.WarningBanner

/**
 * Generic editor entry screen. Derivative of the wound editor's
 * `IntroScreen` with the wound-specific framing stripped:
 *
 *  - No "Step 1 of 2" — the generic editor is a single drawing step.
 *  - No help icon — no help slides for v1.
 *  - Body is one instructional paragraph, not two.
 *
 * The Resume banner appears above the body when [hasExistingState]
 * is true (the caller passed a non-empty `initial`). Cancel stays
 * in the footer either way; the single primary CTA is hidden when
 * the Resume banner takes over.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun GenericIntroScreen(
    hasExistingState: Boolean,
    strings: SdkGenericStrings,
    onResume: () -> Unit,
    onStart: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text(strings.introTitle) },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = strings.backContentDescription,
                        )
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    // Scrollable like the wound editor's IntroScreen —
                    // small heights / landscape otherwise clip the
                    // Resume banner's buttons out of reach.
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 24.dp),
            ) {
                if (hasExistingState) {
                    ResumeBanner(strings, onResume, onStart)
                    Spacer(Modifier.height(24.dp))
                }
                Spacer(Modifier.height(16.dp))
                // Prototype renders the title a second time at 24sp
                // Medium (NOT the 27sp Bold headlineMedium) — pixel-match
                // that explicitly rather than via a theme role.
                Text(
                    text = strings.introTitle,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontSize = 24.sp,
                        lineHeight = 30.sp,
                        fontWeight = FontWeight.Medium,
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.height(24.dp))
                Text(
                    text = strings.introDescription,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            WarningBanner(
                text = strings.warningBanner,
                icon = Icons.Filled.Warning,
                modifier = Modifier.padding(horizontal = 24.dp),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 24.dp, top = 12.dp, end = 24.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(
                    onClick = onCancel,
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.secondary,
                    ),
                ) { Text(strings.cancelButton) }
                if (!hasExistingState) {
                    Spacer(Modifier.width(12.dp))
                    PrimaryButton(text = strings.continueButton, onClick = onStart)
                }
            }
        }
    }
}

@Composable
private fun ResumeBanner(
    strings: SdkGenericStrings,
    onResume: () -> Unit,
    onStartFresh: () -> Unit,
) {
    BrandCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                strings.resumeBanner,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurface,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                // Prototype tints both resume actions teal (the deep
                // brand action color), not the slate footer-CTA color.
                Button(
                    onClick = onResume,
                    modifier = Modifier.weight(1f),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary,
                        contentColor = MaterialTheme.colorScheme.onSecondary,
                    ),
                ) { Text(strings.resumeButton) }
                TextButton(
                    onClick = onStartFresh,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.secondary,
                    ),
                ) { Text(strings.startFreshButton) }
            }
        }
    }
}
