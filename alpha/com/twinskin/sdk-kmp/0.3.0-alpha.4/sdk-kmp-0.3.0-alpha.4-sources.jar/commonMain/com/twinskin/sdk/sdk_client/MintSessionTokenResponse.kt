package com.twinskin.sdk.sdk_client

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.debug
import com.twinskin.sdk.error
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Internal, parsed view of the `POST /api/sdk/sessions/token` response
 * body the integrator forwards through [SdkAuthorizationProvider].
 * Integrators never construct or return this type — they deal only in
 * the opaque JSON string.
 *
 * [token] is the unified session JWT: sent as `Authorization: Bearer`
 * on every upload call AND handed to PowerSync as the sync credential.
 *
 * Timestamps are ISO-8601 strings on the wire (matching the server's
 * JSON encoding); callers who need a typed moment-in-time can parse
 * them themselves.
 */
@Serializable
internal data class MintSessionTokenResponse(
    val token: String,
    @SerialName("expires_at") val expiresAt: String,
)

private val sessionTokenJson = Json { ignoreUnknownKeys = true }

private const val SESSION_TOKEN_ENDPOINT = "POST /api/sdk/sessions/token"

/**
 * Parse the opaque payload returned by
 * [SdkAuthorizationProvider.fetchSessionToken]. Throws with a clear
 * diagnostic when the JSON is malformed — that indicates the
 * integrator's backend is not forwarding Twinskin's session-token
 * response shape.
 */
internal fun parseSessionTokenPayload(json: String): MintSessionTokenResponse =
    try {
        sessionTokenJson.decodeFromString(MintSessionTokenResponse.serializer(), json)
    } catch (e: Exception) {
        throw IllegalStateException(
            "SdkAuthorizationProvider.fetchSessionToken returned a payload " +
                "the SDK could not parse as a Twinskin session-token response. " +
                "Expected the verbatim body of $SESSION_TOKEN_ENDPOINT.",
            e,
        )
    }

/** The integrator's [SdkAuthorizationProvider] threw, returned blank, or returned an unparseable payload. */
internal class AuthorizationProviderException(message: String, cause: Throwable?) :
    IllegalStateException(message, cause)

/**
 * Fetch and parse a session token, logging failures at error level and
 * raising [AuthorizationProviderException]. [CancellationException] is
 * re-thrown untouched, never reported as an auth failure.
 */
internal suspend fun SdkAuthorizationProvider.fetchAndParseSessionToken(
    subjectRef: String,
    logger: SdkLogger?,
): MintSessionTokenResponse {
    val payload = try {
        fetchSessionToken(subjectRef)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Throwable) {
        val message =
            "Your SdkAuthorizationProvider.fetchSessionToken threw for " +
                "subjectRef='$subjectRef'. The SDK cannot authenticate without a " +
                "session token — check that your token endpoint is reachable and " +
                "returns the verbatim body of $SESSION_TOKEN_ENDPOINT."
        logger?.error(message, e)
        throw AuthorizationProviderException(message, e)
    }
    if (payload.isBlank()) {
        val message =
            "Your SdkAuthorizationProvider.fetchSessionToken returned a blank " +
                "payload for subjectRef='$subjectRef'. Expected the verbatim body " +
                "of $SESSION_TOKEN_ENDPOINT."
        logger?.error(message, null)
        throw AuthorizationProviderException(message, null)
    }
    return try {
        parseSessionTokenPayload(payload).also {
            logger?.debug(
                "session token fetched for subjectRef='$subjectRef', expiresAt=${it.expiresAt}",
            )
        }
    } catch (e: Throwable) {
        val message =
            "Your SdkAuthorizationProvider.fetchSessionToken returned a payload " +
                "the SDK could not parse for subjectRef='$subjectRef'. Expected the " +
                "verbatim body of $SESSION_TOKEN_ENDPOINT."
        logger?.error(message, e)
        throw e
    }
}
