package com.twinskin.sdk.ui.fallback

/**
 * Net-new luminosity signal, so the threshold is centralised here to stay
 * tunable; tuned conservatively so a borderline-lit scene never false-traps the
 * operator.
 */
public object LowLightProbe {
    /** Mean luma (0–255, Rec.601) at or below which the still reads low-light. */
    public const val MEAN_LUMA_THRESHOLD: Double = 50.0

    public fun isLowLight(meanLuma: Double): Boolean = meanLuma <= MEAN_LUMA_THRESHOLD
}
