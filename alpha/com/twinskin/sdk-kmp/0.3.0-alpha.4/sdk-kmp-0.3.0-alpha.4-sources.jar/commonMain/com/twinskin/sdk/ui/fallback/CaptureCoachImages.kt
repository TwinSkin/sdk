package com.twinskin.sdk.ui.fallback

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.painter.Painter

/**
 * Host-supplied images for the animated coaches. commonMain owns the motion and
 * perspective; the host supplies a [Painter] per slot (commonMain can't bundle
 * bitmaps) and the coach chooses the fit per location — `Fit` on the Step-1 skin
 * floor (whole image shows), `Crop` on phone screens and the tutorial-p2 wound.
 *
 *  - [woundLive] — the live / PhotoTaken orbit phone screen.
 *  - [woundMarker] — the Step-1 skin floor + Step-1 phone screen, and the
 *    tutorial-p2 centre wound + its orbit phone.
 *  - [markerReference] — the printed calibration pattern shown on the "Marker not
 *    detected" card; distinct from [woundMarker], which is a wound illustration.
 *
 * Any `null` slot falls back to the built-in vector rendering (the marker card
 * leaves its white image box empty).
 */
@Immutable
public class CaptureCoachImages(
    public val woundLive: Painter? = null,
    public val woundMarker: Painter? = null,
    public val markerReference: Painter? = null,
)

public val LocalCaptureCoachImages: ProvidableCompositionLocal<CaptureCoachImages> =
    staticCompositionLocalOf { CaptureCoachImages() }
