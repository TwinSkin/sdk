@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.i18n.sdkLocale
import com.twinskin.sdk.ui.capture.i18n.captureStringsFor
import com.twinskin.sdk.ui.theme.TwinSkinColors

/**
 * Translucent viewer top bar drawn OVER the dark stage (prototype
 * `ViewerTopBar`): a circular white close button on the left and a centered
 * cube icon + title in white. No solid surface — it floats on the stage, so
 * callers overlay it on top of the pane rather than reserving layout height.
 */
@TwinSkinInternalApi
@Composable
public fun ViewCaptureTopBar(
    title: String,
    onClose: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            // statusBarsPadding is the correct inset; the fixed top is a floor
            // so the header still clears the notch / clock area on hosts that
            // hide the status bar (where the inset resolves to zero).
            .statusBarsPadding()
            .padding(start = 14.dp, end = 14.dp, top = 18.dp),
    ) {
        ViewerCircleButton(
            icon = Icons.Default.Close,
            contentDescription = remember { captureStringsFor(sdkLocale()) }.viewerCloseContentDescription,
            onClick = onClose,
            modifier = Modifier.align(Alignment.CenterStart),
        )
        Row(
            modifier = Modifier.align(Alignment.Center),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = Icons.Default.ViewInAr,
                contentDescription = null,
                tint = TwinSkinColors.Cyan,
                modifier = Modifier.size(17.dp),
            )
            Spacer(Modifier.width(7.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
            )
        }
    }
}
