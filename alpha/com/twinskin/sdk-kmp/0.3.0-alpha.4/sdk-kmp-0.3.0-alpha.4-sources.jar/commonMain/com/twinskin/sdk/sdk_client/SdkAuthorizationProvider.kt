package com.twinskin.sdk.sdk_client

/**
 * Asks the integrator's backend for a fresh session-token payload for
 * a given subject. A typical implementation:
 *
 *  1. Authenticates / authorizes the caller against the integrator's
 *     own session.
 *  2. Calls Twinskin's `POST /api/sdk/sessions/token` endpoint with
 *     the integrator's private key and the supplied [subjectRef].
 *  3. Returns the response body verbatim.
 *
 * The SDK parses the response internally — integrators treat it as an
 * opaque payload. The subject is passed per-call because the minted
 * token is subject-scoped (upload authorization checks the subject
 * claim), so an SDK asking about a new subject necessarily needs a
 * new call.
 *
 * The publishable key is static per-app and lives in `TwinSkinConfig`,
 * not here.
 *
 * Implementations should be cheap and safe to call from any coroutine
 * context — the SDK invokes this lazily on every request so a 401-
 * driven retry picks up a refreshed response.
 *
 * Throwing, or returning a blank/unparseable payload, is logged at error
 * level (see `fetchAndParseSessionToken`).
 */
public fun interface SdkAuthorizationProvider {
    public suspend fun fetchSessionToken(subjectRef: String): String
}

/**
 * Demo/testing provider that always returns the same payload
 * regardless of [subjectRef]. Real host apps plug in a provider that
 * calls their own backend.
 */
internal class ConstantSessionTokenProvider(
    private val payload: String,
) : SdkAuthorizationProvider {
    override suspend fun fetchSessionToken(subjectRef: String): String = payload
}
