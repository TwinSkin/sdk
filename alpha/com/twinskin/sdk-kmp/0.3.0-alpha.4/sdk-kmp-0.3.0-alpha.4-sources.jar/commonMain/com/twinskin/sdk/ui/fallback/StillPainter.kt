package com.twinskin.sdk.ui.fallback

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter
import com.twinskin.sdk.ui.annotation_editor.loadImageFromPath

/**
 * Remember a [Painter] decoded from a captured-still file path, for the reference
 * thumbnail and the orbit coach's phone screen.
 *
 * Reuses the EXIF-aware [loadImageFromPath] the annotation editor already ships
 * rather than re-deriving a second file decoder. A null / blank path or a decode
 * failure yields `null` so callers fall back to the empty slot rather than crash.
 * Decoding is one-shot (`remember(path)`), off the orbit animation's frame path.
 */
@Composable
internal fun rememberStillPainter(path: String?): Painter? {
    if (path.isNullOrBlank()) return null
    return remember(path) {
        try {
            BitmapPainter(loadImageFromPath(path))
        } catch (_: Throwable) {
            null
        }
    }
}
