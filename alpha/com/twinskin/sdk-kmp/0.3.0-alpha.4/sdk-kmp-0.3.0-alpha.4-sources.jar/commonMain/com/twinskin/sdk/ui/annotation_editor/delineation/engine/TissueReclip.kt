package com.twinskin.sdk.ui.annotation_editor.delineation.engine

import androidx.compose.ui.geometry.Offset
import com.twinskin.sdk.geometry.intersect
import com.twinskin.sdk.geometry.pathToPolygons
import com.twinskin.sdk.geometry.polygonToPath
import com.twinskin.sdk.geometry.signedArea
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Tissue
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.reDensify
import kotlin.math.absoluteValue

/**
 * Report from one cascade pass: the tissue list to write back to the
 * store, plus before/after counts so M11 can surface the
 * "N tissue region(s) updated, M deleted" snackbar (spec §6.5.2).
 *
 * Per-source-tissue accounting:
 *  - [updatedCount] increments when an input tissue's intersection
 *    with the new wound differs from its original area (so a
 *    no-op "tissue fully inside, reshape doesn't touch it" doesn't
 *    bump the counter — see plan §M5b note);
 *  - [removedCount] increments when the intersection produces zero
 *    surviving pieces (fully outside, or every piece below [minArea]).
 *
 * Output tissue count can exceed [updatedCount] when a single source
 * tissue is split into multiple pieces by a non-convex new wound
 * outline (each piece is emitted as its own [Tissue] of the same
 * type — spec §7.2 "same-type touching tissues remain separate in
 * the model").
 */
internal data class TissueReclipReport(
    val updatedTissues: List<Tissue>,
    val updatedCount: Int,
    val removedCount: Int,
)

/**
 * Recomputes each tissue's outline against [newWoundOutline]
 * (spec §6.5.2 cascade — runs when the controller commits a wound
 * reshape on screen 2). Pure function: no store access, no side
 * effects, no controller awareness.
 *
 * Pipeline per tissue:
 *  1. `intersect(woundPath, tissuePath)` via the M1 Path-op
 *     primitive — the survivor set of points inside both the new
 *     wound and the original tissue.
 *  2. Split into connected components via [pathToPolygons]; drop
 *     any sub-path whose absolute area is below [minArea] (sliver
 *     artifacts of boolean ops).
 *  3. Re-densify each surviving piece via [reDensify] so the
 *     emitted tissue outlines sit at the canonical [2, 10]
 *     image-px spacing.
 *
 * @param minArea  caller-computed degenerate-sliver filter. The
 *                 plan's M11 caller uses
 *                 `max(24f, imageSize.width * imageSize.height * 5e-5f)`
 *                 (decision N). This function accepts it as a
 *                 parameter to stay pure and testable on synthetic
 *                 small geometries.
 */
internal fun reclipTissuesAgainstWound(
    tissues: List<Tissue>,
    newWoundOutline: List<Offset>,
    minArea: Float,
): TissueReclipReport {
    if (tissues.isEmpty()) {
        return TissueReclipReport(emptyList(), 0, 0)
    }
    // Degenerate wound (< 3 vertices) can't enclose anything — defensive
    // path so a caller that hands us a bad outline doesn't crash. M9
    // catches this on emit, but a pure function shouldn't assume it.
    if (newWoundOutline.size < 3) {
        return TissueReclipReport(emptyList(), 0, tissues.size)
    }

    val woundPath = polygonToPath(newWoundOutline)
    val out = mutableListOf<Tissue>()
    var updated = 0
    var removed = 0

    for (tissue in tissues) {
        if (tissue.outline.size < 3) {
            removed++
            continue
        }
        val tissuePath = polygonToPath(tissue.outline)
        val clip = intersect(woundPath, tissuePath)
        if (clip == null) {
            // Backend bailed on the boolean op — preserve the source
            // tissue rather than silently emit a removal.
            out += tissue
            continue
        }
        val pieces = pathToPolygons(clip)
            .filter { signedArea(it).absoluteValue >= minArea }

        if (pieces.isEmpty()) {
            removed++
            continue
        }

        val inputArea = signedArea(tissue.outline).absoluteValue
        val survivingArea = pieces.sumOf { signedArea(it).absoluteValue.toDouble() }.toFloat()
        val areaDelta = (inputArea - survivingArea).absoluteValue
        val isNoOp = pieces.size == 1 &&
            inputArea > 0f &&
            areaDelta / inputArea < NOOP_AREA_TOLERANCE

        if (isNoOp) {
            // Preserve the source outline verbatim — reDensify on a
            // path-op result re-samples the contour and would change
            // the point list even when geometry is unchanged. Keeping
            // the source means undo / equality checks downstream see
            // a true no-op.
            out += tissue
        } else {
            for (piece in pieces) {
                out += Tissue(type = tissue.type, outline = reDensify(piece))
            }
            updated++
        }
    }

    return TissueReclipReport(out, updated, removed)
}

/**
 * Tolerance band for "did the intersect change the tissue's area?"
 * 0.5 % matches the plan's hint. Below this delta the source tissue
 * is preserved verbatim; above it, the intersected pieces are
 * emitted (each through [reDensify]).
 */
private const val NOOP_AREA_TOLERANCE: Float = 0.005f
