package com.twinskin.sdk.capture

import com.twinskin.sdk.capture.crypto.AesGcmEncryptor
import com.twinskin.sdk.capture.crypto.rsaOaepSha256Encrypt
import com.twinskin.sdk.capture.crypto.secureRandomBytes
import com.twinskin.sdk.capture.io.AppendingFileSink
import com.twinskin.sdk.capture.io.ByteSink

/**
 * Encrypts a capture bundle using the chunked hybrid scheme:
 *
 *   - fresh AES-256 key + 12-byte base nonce per bundle
 *   - the AES key is wrapped with RSA-OAEP-SHA-256 using the env public key
 *   - the plaintext is sliced into [DEFAULT_CHUNK_SIZE]-byte chunks; each
 *     chunk is encrypted with AES-GCM using nonce
 *     `baseNonce[0..8] || counter_be32(chunk_index)`
 *
 * Output layout (also documented in
 * `packages/capture_pipeline/src/capture_pipeline/crypto/bundle.py`):
 *
 *     u16be(wrappedKeyLen) ‖ wrappedKey ‖ baseNonce(12) ‖ u32be(chunkSize)
 *     repeated:
 *       u32be(chunkPlaintextLen) ‖ ciphertext ‖ tag(16)
 *     terminator:
 *       u32be(0)
 */
internal open class BundleEncryptor(private val publicKeyDer: ByteArray) {

    open fun openEncryptingSink(outputPath: String): BundleEncryptingSink {
        val aesKey = ByteArray(32).also { secureRandomBytes(it) }
        val baseNonce = ByteArray(12).also { secureRandomBytes(it) }
        val wrappedKey = rsaOaepSha256Encrypt(publicKeyDer, aesKey)
        require(wrappedKey.size in 1..0xffff) {
            "wrapped key length out of range: ${wrappedKey.size}"
        }

        val sink = AppendingFileSink(outputPath)
        val header = ByteArray(2 + wrappedKey.size + 12 + 4)
        var o = 0
        header[o++] = ((wrappedKey.size ushr 8) and 0xff).toByte()
        header[o++] = (wrappedKey.size and 0xff).toByte()
        wrappedKey.copyInto(header, o); o += wrappedKey.size
        baseNonce.copyInto(header, o); o += 12
        header[o++] = ((DEFAULT_CHUNK_SIZE ushr 24) and 0xff).toByte()
        header[o++] = ((DEFAULT_CHUNK_SIZE ushr 16) and 0xff).toByte()
        header[o++] = ((DEFAULT_CHUNK_SIZE ushr 8) and 0xff).toByte()
        header[o] = (DEFAULT_CHUNK_SIZE and 0xff).toByte()
        sink.write(header, 0, header.size)

        return BundleEncryptingSink(
            sink = sink,
            encryptor = AesGcmEncryptor(aesKey, baseNonce),
            chunkSize = DEFAULT_CHUNK_SIZE,
        )
    }

    companion object {
        const val DEFAULT_CHUNK_SIZE: Int = 1 shl 20 // 1 MiB
    }
}

/**
 * Plaintext sink returned by [BundleEncryptor.openEncryptingSink]. Buffers
 * incoming bytes into chunk-sized blocks; flushes a complete chunk to disk
 * each time the buffer fills, and on [close] flushes the partial final chunk
 * + the zero-length end-of-stream marker.
 */
internal class BundleEncryptingSink internal constructor(
    private val sink: AppendingFileSink,
    private val encryptor: AesGcmEncryptor,
    private val chunkSize: Int,
) : ByteSink {

    private val scratch = ByteArray(chunkSize)
    private var scratchLen = 0
    private var closed = false

    override fun write(src: ByteArray, off: Int, len: Int) {
        check(!closed) { "BundleEncryptingSink already closed" }
        var srcPos = off
        var remaining = len
        while (remaining > 0) {
            val take = minOf(chunkSize - scratchLen, remaining)
            src.copyInto(scratch, scratchLen, srcPos, srcPos + take)
            scratchLen += take
            srcPos += take
            remaining -= take
            if (scratchLen == chunkSize) flushChunk()
        }
    }

    fun close() {
        if (closed) return
        closed = true
        try {
            if (scratchLen > 0) flushChunk()
            // End-of-stream marker.
            sink.write(EOF_MARKER, 0, 4)
        } finally {
            sink.close()
        }
    }

    private fun flushChunk() {
        val len = scratchLen
        scratchLen = 0
        val chunk = encryptor.encryptChunk(scratch, 0, len)
        val prefix = byteArrayOf(
            ((len ushr 24) and 0xff).toByte(),
            ((len ushr 16) and 0xff).toByte(),
            ((len ushr 8) and 0xff).toByte(),
            (len and 0xff).toByte(),
        )
        sink.write(prefix, 0, 4)
        sink.write(chunk.ciphertext, 0, chunk.ciphertext.size)
        sink.write(chunk.tag, 0, chunk.tag.size)
    }

    private companion object {
        private val EOF_MARKER = ByteArray(4) // all zero
    }
}
