package com.twinskin.sdk.ui.view_capture.subview

import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import com.twinskin.sdk.i18n.sdkLocale
import com.twinskin.sdk.ui.capture.i18n.captureStringsFor
import kotlinx.coroutines.delay

/**
 * Animated "Calculating…" label whose trailing dot count cycles
 * 1 → 2 → 3 → 1 every [dotIntervalMs] (default 400 ms — 1.2 s full
 * cycle: snappy enough to read as alive, slow enough not to
 * distract). M15.20.
 *
 * **Stable layout width.** The rendered string is always the same
 * length ("Calculating" + three dot slots); only the *colour* of
 * each trailing dot toggles between [color] (visible) and
 * `Color.Transparent` (invisible but still occupying its glyph
 * box). Without this trick the label's measured width changes
 * every frame and the surrounding `Row`'s `SpaceBetween` arrangement
 * shifts the "Calculating" base text horizontally with each tick —
 * the cycle reads as a jitter rather than a pulse.
 *
 * Accessibility: the rendered string changes every interval, but
 * screen readers see a static `contentDescription` (the unchanging
 * "Calculating…") via a semantics override — dot churn shouldn't
 * become a torrent of TTS announcements.
 */
@Composable
internal fun CalculatingText(
    base: String = captureStringsFor(sdkLocale()).viewerCalculating,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight? = null,
    dotIntervalMs: Long = 400L,
) {
    var dotCount by remember { mutableIntStateOf(1) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(dotIntervalMs)
            dotCount = if (dotCount >= 3) 1 else dotCount + 1
        }
    }
    val annotated = buildAnnotatedString {
        append(base)
        // Each of the three dot slots renders unconditionally — the
        // ones not yet "active" use a transparent span so layout
        // width is identical across the cycle.
        repeat(3) { idx ->
            val visible = idx < dotCount
            val slotColor = if (visible) color else Color.Transparent
            withStyle(SpanStyle(color = slotColor)) {
                append('.')
            }
        }
    }
    Text(
        text = annotated,
        modifier = modifier.semantics { contentDescription = "$base…" },
        style = style,
        color = color,
        fontWeight = fontWeight,
    )
}
