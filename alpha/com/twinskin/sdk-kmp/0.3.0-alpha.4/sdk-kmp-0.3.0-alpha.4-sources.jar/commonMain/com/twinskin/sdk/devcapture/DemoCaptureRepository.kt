package com.twinskin.sdk.devcapture

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.CaptureResult
import com.twinskin.sdk.capture.io.ensureDir
import com.twinskin.sdk.capture.io.fileExists
import com.twinskin.sdk.capture.io.readBytes
import com.twinskin.sdk.capture.io.renameFile
import com.twinskin.sdk.capture.io.writeBytes
import com.twinskin.sdk.sdk_client.SDK_API_PATH
import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider
import com.twinskin.sdk.sdk_client.fetchAndParseSessionToken
import com.twinskin.sdk.warn
import io.ktor.client.HttpClient
import io.ktor.client.request.HttpRequestBuilder
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.statement.bodyAsBytes
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpHeaders
import io.ktor.http.isSuccess
import kotlinx.serialization.json.Json

/**
 * Fetches the demo-capture catalog from `/api/sdk/demo/captures` and
 * downloads selected captures into a session's working dir, ready to
 * hand to `CaptureSession.submit(CaptureResult)`.
 *
 * ## Disk cache
 *
 * Once a catalog or a file has been fetched once, a copy is kept under
 * [cacheRoot] (typically `Purpose.DemoCache`). On the next call:
 *
 * - [listCatalog] tries the network first and falls back to the cached
 *   JSON if the network call fails. The catalog endpoint's URLs may be
 *   presigned and time-limited; a cached catalog can therefore list
 *   entries whose download URLs no longer resolve, which is acceptable
 *   for the picker because [download] only hits the URL on a cache
 *   miss anyway.
 * - [download] reuses any per-file cache hit and only fetches missing
 *   files. The whole cached entry is then copied into the session's
 *   `intoDir`, since the working dir is short-lived (deleted after the
 *   encrypted bundle is built).
 *
 * Cache writes go via a `.partial` temp + atomic rename, so a crashed
 * write leaves no half-file at the canonical cache path — the next
 * run treats that file as a miss and re-downloads it.
 *
 * One repository per capture session — `subjectRef` is used to mint
 * the session JWT for catalog + file requests, mirroring how
 * `SdkServerClient` works for live captures.
 */
internal class DemoCaptureRepository(
    private val httpClient: HttpClient,
    baseUrl: String,
    private val publishableKey: String,
    private val auth: SdkAuthorizationProvider,
    private val subjectRef: String,
    private val cacheRoot: String,
    private val logger: SdkLogger = SdkLogger.None,
) {
    private val apiBaseUrl: String = "${baseUrl.trimEnd('/')}$SDK_API_PATH"
    private val cacheRootNoSlash: String = cacheRoot.trimEnd('/')
    private val catalogCachePath: String = "$cacheRootNoSlash/catalog.json"

    suspend fun listCatalog(): List<DemoCaptureEntry> {
        ensureDir(cacheRootNoSlash)
        val fresh = runCatching { fetchCatalog() }
        fresh.onSuccess { return it }

        val cached = runCatching { readCachedCatalog() }.getOrNull()
        if (cached != null) {
            logger.warn(
                "DemoCaptureRepository: catalog fetch failed, " +
                    "using cached catalog (${cached.size} entries): " +
                    "${fresh.exceptionOrNull()?.message ?: "unknown error"}",
            )
            return cached
        }
        throw fresh.exceptionOrNull()
            ?: DemoCaptureException("Failed to fetch demo catalog: unknown error")
    }

    private suspend fun fetchCatalog(): List<DemoCaptureEntry> {
        val response = httpClient.get("$apiBaseUrl/demo/captures") {
            authenticate()
        }
        if (!response.status.isSuccess()) {
            throw DemoCaptureException(
                "Failed to fetch demo catalog: ${response.status.value} " +
                    response.bodyAsText(),
            )
        }
        val text = response.bodyAsText()
        val entries = JSON.decodeFromString<List<DemoCaptureEntry>>(text)
        writeAtomic(catalogCachePath, text.encodeToByteArray())
        return entries
    }

    private fun readCachedCatalog(): List<DemoCaptureEntry>? {
        if (!fileExists(catalogCachePath)) return null
        val text = readBytes(catalogCachePath).decodeToString()
        return JSON.decodeFromString(text)
    }

    /**
     * Download (or copy from cache) [entry] into [intoDir] and return a
     * [DemoDownload] the caller submits through the matching pipeline.
     *
     * - A video demo ([DemoCaptureEntry.videoUrl] non-null) yields
     *   [DemoDownload.Video]: the reference still + the orbit video, fed
     *   through the real accelerometer-capture submit path.
     * - An image demo yields [DemoDownload.Photosphere]: the reference
     *   still + per-arm frames.
     *
     * On any failure mid-download, partial files may exist at the
     * destination paths; the caller is responsible for cleanup
     * (typically via `session.cancel()` which deletes the entire
     * workingDir). The cache itself is unaffected by destination
     * failures.
     */
    suspend fun download(
        entry: DemoCaptureEntry,
        intoDir: String,
        onProgress: (downloaded: Int, total: Int) -> Unit,
    ): DemoDownload {
        val dirNoTrailingSlash = intoDir.trimEnd('/')
        val entryCacheDir = "$cacheRootNoSlash/${entry.id}"
        ensureDir(entryCacheDir)

        val videoUrl = entry.videoUrl
        if (videoUrl != null) {
            val total = 2
            var done = 0

            val photoPath = "$dirNoTrailingSlash/photo.jpg"
            materialize(
                url = entry.refUrl,
                cachePath = "$entryCacheDir/photo.jpg",
                destPath = photoPath,
            )
            done += 1
            onProgress(done, total)

            // Basename mirrors the on-disk filename the
            // CameraX/AVFoundation recorders write; the manifest only
            // records the basename, so the container extension carries
            // through for the server's ffmpeg dispatch.
            val videoName = videoFilenameFor(videoUrl)
            val videoPath = "$dirNoTrailingSlash/$videoName"
            materialize(
                url = videoUrl,
                cachePath = "$entryCacheDir/$videoName",
                destPath = videoPath,
            )
            done += 1
            onProgress(done, total)

            return DemoDownload.Video(
                photoPath = photoPath,
                videoPath = videoPath,
                markerVersion = entry.markerVersion,
            )
        }

        val total = 1 + entry.frameUrls.size
        var done = 0

        val photoPath = "$dirNoTrailingSlash/photo.jpg"
        materialize(
            url = entry.refUrl,
            cachePath = "$entryCacheDir/photo.jpg",
            destPath = photoPath,
        )
        done += 1
        onProgress(done, total)

        val framePaths = mutableListOf<String>()
        for ((index, url) in entry.frameUrls.withIndex()) {
            val frameName = "frame_${(index + 1).toString().padStart(3, '0')}.jpg"
            val framePath = "$dirNoTrailingSlash/$frameName"
            materialize(
                url = url,
                cachePath = "$entryCacheDir/$frameName",
                destPath = framePath,
            )
            framePaths.add(framePath)
            done += 1
            onProgress(done, total)
        }

        return DemoDownload.Photosphere(
            CaptureResult(
                photoPath = photoPath,
                framePaths = framePaths,
                markerVersion = entry.markerVersion,
            ),
        )
    }

    /**
     * Picks the local video basename from the catalog URL's extension so
     * the right container (`.mp4` / `.mov`) lands in the bundle. Strips
     * any query/fragment (presigned S3 GETs carry `?X-Amz-…`) and
     * lowercases before matching, so an uppercase iOS `.MOV` or a
     * signed `…/video.mov?sig=…` still resolves to `.mov`. Anything else
     * falls back to `.mp4`.
     */
    private fun videoFilenameFor(videoUrl: String): String {
        val path = videoUrl.substringBefore('?').substringBefore('#').lowercase()
        return if (path.endsWith(".mov")) "video.mov" else "video.mp4"
    }

    /**
     * Ensure [cachePath] has the bytes from [url], then copy them to
     * [destPath]. On a cache hit, the network is not consulted at all
     * — this is what lets the second run work offline.
     */
    private suspend fun materialize(url: String, cachePath: String, destPath: String) {
        val bytes = if (fileExists(cachePath)) {
            readBytes(cachePath)
        } else {
            val downloaded = downloadBytes(url)
            writeAtomic(cachePath, downloaded)
            downloaded
        }
        writeBytes(destPath, bytes)
    }

    private suspend fun downloadBytes(url: String): ByteArray {
        val absolute = resolveAgainstBase(url)
        val response = httpClient.get(absolute) { authenticate() }
        if (!response.status.isSuccess()) {
            throw DemoCaptureException(
                "Failed to download $absolute: ${response.status.value}",
            )
        }
        return response.bodyAsBytes()
    }

    private fun writeAtomic(path: String, bytes: ByteArray) {
        val tmp = "$path.partial"
        writeBytes(tmp, bytes)
        renameFile(tmp, path)
    }

    /**
     * The catalog endpoint returns paths relative to the SDK API root
     * (e.g. `demo/captures/<id>/<filename>`). Absolute URLs are passed
     * through unchanged so older servers (or future flexibility) still
     * work.
     */
    private fun resolveAgainstBase(url: String): String {
        if (url.startsWith("http://") || url.startsWith("https://")) return url
        return "$apiBaseUrl/${url.trimStart('/')}"
    }

    private suspend fun HttpRequestBuilder.authenticate() {
        val tokens = auth.fetchAndParseSessionToken(subjectRef, logger)
        header(HttpHeaders.Authorization, "Bearer ${tokens.token}")
        header("X-Publishable-Key", publishableKey)
    }

    private companion object {
        val JSON = Json { ignoreUnknownKeys = true }
    }
}

/**
 * Discriminated result of [DemoCaptureRepository.download], telling the
 * caller which submit pipeline the downloaded demo bundle feeds.
 */
internal sealed interface DemoDownload {
    /** An image demo — submit through the photosphere path. */
    data class Photosphere(val result: CaptureResult) : DemoDownload

    /**
     * A video demo — submit through the accelerometer-capture path. The
     * demo carries no IMU samples, so the caller builds an empty
     * `VideoMetaData()` for the bundle's `video_metadata.json`.
     */
    data class Video(
        val photoPath: String,
        val videoPath: String,
        val markerVersion: String?,
    ) : DemoDownload
}

internal class DemoCaptureException(message: String) : Exception(message)
