package com.twinskin.sdk.capture.fallback

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Polar-projection orientation vector — the 2D coordinate of the new
 * accelerometer sample in the plane perpendicular to the initial
 * (gravity-aligned) accelerometer vector.
 *
 * `theta` is the polar angle in radians (range `(-π, π]`). `intensity`
 * is the in-plane magnitude normalised by the initial-vector norm —
 * `0.0` means the new sample is aligned with the initial gravity (no
 * angular motion), `1.0` means the sample is fully perpendicular to it.
 */
public data class OrientationVector(
    val theta: Double,
    val intensity: Double,
)

/**
 * Sectoring math — byte-for-byte port of the web_app's
 * `computeOrientationVector` (`accelerometer_sensor_plus.dart` lines
 * 181-249). Kept as a pure object so a recorded IMU trace can be
 * replayed identically on Kotlin and Dart and the sector decisions
 * compared.
 */
public object OrientationMath {
    /**
     * Project `newAcc` onto the plane perpendicular to `initialAcc`
     * (the gravity vector latched at session start) and return the
     * 2D polar coordinate of the projection in a stable basis on that
     * plane. Output matches the Dart implementation bit-for-bit on
     * the same inputs.
     */
    public fun computeOrientationVector(
        initialAcc: Vec3,
        newAcc: Vec3,
    ): OrientationVector {
        val normInitial = sqrt(
            initialAcc.x * initialAcc.x +
                initialAcc.y * initialAcc.y +
                initialAcc.z * initialAcc.z,
        )
        val ux = initialAcc.x / normInitial
        val uy = initialAcc.y / normInitial
        val uz = initialAcc.z / normInitial

        val dot = newAcc.x * ux + newAcc.y * uy + newAcc.z * uz

        val projX = newAcc.x - dot * ux
        val projY = newAcc.y - dot * uy
        val projZ = newAcc.z - dot * uz

        val intensity = sqrt(projX * projX + projY * projY + projZ * projZ) / normInitial

        // Choice of arbitrary vector mirrors the Dart fallback: pick
        // (0, 0, 1) unless the initial unit vector is nearly aligned
        // with that axis, in which case fall back to (0, 1, 0).
        val aX: Double
        val aY: Double
        val aZ: Double
        if (abs(uz) < 0.9) {
            aX = 0.0; aY = 0.0; aZ = 1.0
        } else {
            aX = 0.0; aY = 1.0; aZ = 0.0
        }

        val b1x = aY * uz - aZ * uy
        val b1y = aZ * ux - aX * uz
        val b1z = aX * uy - aY * ux
        val b1Mag = sqrt(b1x * b1x + b1y * b1y + b1z * b1z)
        val nb1x = b1x / b1Mag
        val nb1y = b1y / b1Mag
        val nb1z = b1z / b1Mag

        val b2x = uy * nb1z - uz * nb1y
        val b2y = uz * nb1x - ux * nb1z
        val b2z = ux * nb1y - uy * nb1x

        val x2d = projX * nb1x + projY * nb1y + projZ * nb1z
        val y2d = projX * b2x + projY * b2y + projZ * b2z

        return OrientationVector(theta = atan2(y2d, x2d), intensity = intensity)
    }

    public data class Vec3(val x: Double, val y: Double, val z: Double)
}

/** Alias to keep the `computeOrientationVector` call site terse. */
public typealias Vec3 = OrientationMath.Vec3
