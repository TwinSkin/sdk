package com.twinskin.sdk.ui.annotation_editor.delineation.ui_helpers

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.SdkDelineationStrings

/**
 * One-shot informational dialog explaining the tissue-reclip
 * cascade to clinicians who reshape a wound that contains tissues.
 * Shown on entry to
 * [com.twinskin.sdk.ui.annotation_editor.delineation.flow.WoundDrawingScreen]
 * — never mid-gesture — when the store has at least one wound with
 * dependent tissues and the user hasn't permanently dismissed it
 * via the "Don't show again" checkbox.
 *
 * Replaces the spec §6.5.2 in-gesture confirmation dialog; the
 * reshape gesture itself now runs uninterrupted.
 */
@Composable
internal fun ReshapeAdvisoryDialog(
    strings: SdkDelineationStrings,
    initialDontShowAgain: Boolean = false,
    onDismiss: (dontShowAgain: Boolean) -> Unit,
) {
    var dontShowAgain by rememberSaveable { mutableStateOf(initialDontShowAgain) }
    AlertDialog(
        onDismissRequest = { onDismiss(dontShowAgain) },
        title = { Text(strings.reshapeAdvisoryTitle) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(strings.reshapeAdvisoryBody)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { dontShowAgain = !dontShowAgain }
                        .padding(vertical = 4.dp),
                ) {
                    Checkbox(
                        checked = dontShowAgain,
                        onCheckedChange = { dontShowAgain = it },
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(strings.dontShowAgainCheckbox)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onDismiss(dontShowAgain) }) {
                Text(strings.okButton)
            }
        },
    )
}
