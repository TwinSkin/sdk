package com.twinskin.sdk.geometry

import androidx.compose.ui.geometry.Offset
import kotlin.math.sqrt

/**
 * Projects [p] onto the line segment `[a, b]` and returns the closest
 * point on that segment (clamped to the endpoints when the projection
 * falls outside). Degenerate segments (a == b) return [a].
 */
internal fun nearestPointOnSegment(p: Offset, a: Offset, b: Offset): Offset {
    val abx = b.x - a.x
    val aby = b.y - a.y
    val len2 = abx * abx + aby * aby
    if (len2 == 0f) return a
    val t = ((p.x - a.x) * abx + (p.y - a.y) * aby) / len2
    val tc = when {
        t < 0f -> 0f
        t > 1f -> 1f
        else -> t
    }
    return Offset(a.x + tc * abx, a.y + tc * aby)
}

/**
 * Walks every segment of [poly] (closed: wraps last → first when [closed])
 * and returns the index of the segment containing the projection plus
 * the projection itself.
 *
 * The segment index `i` refers to the segment `(poly[i], poly[(i+1) % n])`
 * — i.e. the segment starting at vertex `i`. For open polylines, the
 * range is `0..size-2`; for closed polygons, `0..size-1`.
 *
 * Throws if [poly] has fewer than 2 points.
 */
internal fun nearestPointOnPolyline(
    p: Offset,
    poly: List<Offset>,
    closed: Boolean = true,
): Pair<Int, Offset> {
    require(poly.size >= 2) { "Polyline needs ≥ 2 points (got ${poly.size})" }
    val end = if (closed) poly.size else poly.size - 1
    var bestIdx = 0
    var bestPt = poly[0]
    var bestDist2 = Float.POSITIVE_INFINITY
    for (i in 0 until end) {
        val a = poly[i]
        val b = poly[(i + 1) % poly.size]
        val q = nearestPointOnSegment(p, a, b)
        val dx = q.x - p.x
        val dy = q.y - p.y
        val d2 = dx * dx + dy * dy
        if (d2 < bestDist2) {
            bestDist2 = d2
            bestIdx = i
            bestPt = q
        }
    }
    return bestIdx to bestPt
}

/**
 * Distance from [p] to the closest point on [poly]. See
 * [nearestPointOnPolyline] for the closed/open polyline semantics.
 */
internal fun distanceToPolyline(
    p: Offset,
    poly: List<Offset>,
    closed: Boolean = true,
): Float {
    val (_, q) = nearestPointOnPolyline(p, poly, closed)
    val dx = q.x - p.x
    val dy = q.y - p.y
    return sqrt(dx * dx + dy * dy)
}

/**
 * Minimum segment length (image-px) below which the teleport
 * detector ignores a segment's midpoint test. Short segments are by
 * construction the per-frame steps of a legitimate hug gesture
 * (spec §6.4.1 / §10.6.2): each pair of consecutive boundary
 * projections defines a tiny chord across the polygon's interior.
 * Without this filter the midpoint predicate fires on every hug
 * step and the gesture stalls.
 */
private const val TELEPORT_MIN_LENGTH_IMAGE_PX: Float = 15f
private const val TELEPORT_MIN_LENGTH_IMAGE_PX_SQ: Float =
    TELEPORT_MIN_LENGTH_IMAGE_PX * TELEPORT_MIN_LENGTH_IMAGE_PX

/**
 * Reports whether the segment from [from] to [to] is a teleport
 * across the interior of any polygon in [forbidden]: its midpoint
 * sits inside one of them AND its length is above
 * [TELEPORT_MIN_LENGTH_IMAGE_PX]. The length filter keeps a
 * legitimate hug gesture (whose per-frame chord is a thin sliver
 * with the midpoint barely inside) from being flagged.
 *
 * Returns false when [from] == [to], when [forbidden] is empty,
 * or when the segment is shorter than the threshold.
 */
internal fun segmentCrossesAnyForbidden(
    from: Offset,
    to: Offset,
    forbidden: List<List<Offset>>,
): Boolean {
    if (from == to || forbidden.isEmpty()) return false
    val dx = to.x - from.x
    val dy = to.y - from.y
    val lenSq = dx * dx + dy * dy
    if (lenSq < TELEPORT_MIN_LENGTH_IMAGE_PX_SQ) return false
    val midX = (from.x + to.x) * 0.5f
    val midY = (from.y + to.y) * 0.5f
    val midpoint = Offset(midX, midY)
    for (poly in forbidden) {
        if (pointInPolygon(midpoint, poly)) return true
    }
    return false
}
