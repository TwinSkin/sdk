package com.twinskin.sdk.view

/**
 * Interface-form alternative to the `suspend () -> Map<String, String>`
 * lambda accepted by [CaptureSource.GlbUrl].
 *
 * Kotlin callers typically use the lambda form directly. This
 * interface exists for non-Kotlin consumers (Swift, Java pre-Kotlin-20)
 * that can implement a Kotlin interface but can't easily construct a
 * `suspend` Kotlin lambda — [glbUrlSource] adapts implementations of
 * this interface into the lambda form.
 */
public interface AssetHeadersProvider {
    public suspend fun headers(): Map<String, String>
}

/**
 * Interface-accepting factory for [CaptureSource.GlbUrl]. See
 * [AssetHeadersProvider] for motivation. Pass `null` for no auth.
 */
public fun glbUrlSource(
    url: String,
    headersProvider: AssetHeadersProvider? = null,
): CaptureSource.GlbUrl = CaptureSource.GlbUrl(
    url = url,
    headersProvider = headersProvider.toLambda(),
)

private fun AssetHeadersProvider?.toLambda(): suspend () -> Map<String, String> =
    when (val provider = this) {
        null -> ({ emptyMap() })
        else -> ({ provider.headers() })
    }
