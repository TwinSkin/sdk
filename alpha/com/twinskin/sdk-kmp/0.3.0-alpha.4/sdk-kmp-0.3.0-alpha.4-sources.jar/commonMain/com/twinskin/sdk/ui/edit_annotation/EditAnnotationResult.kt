package com.twinskin.sdk.ui.edit_annotation

import com.twinskin.sdk.TwinSkinInternalApi

/** Outcome of an [EditAnnotationScreenHost] session. */
@TwinSkinInternalApi
public sealed class EditAnnotationResult {
    /** Submitted, creating measurement [revision]. */
    public data class Submitted(val revision: Long) : EditAnnotationResult()

    /** Dismissed without submitting. */
    public object Cancelled : EditAnnotationResult()
}
