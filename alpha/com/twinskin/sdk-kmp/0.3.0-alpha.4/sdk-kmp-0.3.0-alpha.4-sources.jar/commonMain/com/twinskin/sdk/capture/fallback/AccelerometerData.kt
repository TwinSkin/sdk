package com.twinskin.sdk.capture.fallback

import kotlinx.serialization.Serializable

/**
 * One IMU sample. Wire-equivalent of the web_app's
 * `AccelerometerData` (`packages/server/lib/src/front_apis/case/api.dart`)
 * — same field names, same JSON encoding, same types — so a payload
 * round-trips between SDK and web_app sessions without per-source
 * branching in the downstream pipeline.
 */
@Serializable
public data class AccelerometerData(
    val timestampMilliseconds: Long,
    val x: Double,
    val y: Double,
    val z: Double,
)
