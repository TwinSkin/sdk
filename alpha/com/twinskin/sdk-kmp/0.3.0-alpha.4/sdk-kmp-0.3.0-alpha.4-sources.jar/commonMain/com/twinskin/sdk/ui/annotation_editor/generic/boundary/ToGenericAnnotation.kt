package com.twinskin.sdk.ui.annotation_editor.generic.boundary

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import com.twinskin.sdk.capture.GenericAnnotation
import com.twinskin.sdk.capture.GenericRegion
import com.twinskin.sdk.capture.Point2D
import com.twinskin.sdk.geometry.reduceToRelevants
import com.twinskin.sdk.ui.annotation_editor.generic.GenericStore

/**
 * Boundary helper — turns the editor's internal polygons (image-px
 * outlines) into the wire-shape [GenericAnnotation] the server
 * consumes.
 *
 * Pipeline per polygon (mirrors `ToWoundAnnotation`):
 *  1. `reduceToRelevants(outline, 177°)` — collapse near-collinear
 *     runs into significant corners. Defines the wire shape;
 *     densification is **not** rerun here (closure / reshape commit
 *     already produce dense polygons at `[2, 10]` image-px spacing,
 *     and the reducer would only strip what densify just added).
 *  2. Reject if `reduced.size < 3` — `IllegalStateException`. A
 *     polygon that collapsed to a line or a point is a bug somewhere
 *     upstream (the controller should never let one commit), so fail
 *     fast.
 *  3. Normalise to `[0, 1]` via `(x / imageSize.width, y / imageSize.height)`.
 */
internal fun toGenericAnnotation(
    store: GenericStore,
    imageSize: Size,
): GenericAnnotation {
    require(imageSize.width > 0f && imageSize.height > 0f) {
        "imageSize must be positive (got $imageSize)"
    }
    val regions = store.polygons.mapIndexed { idx, outline ->
        val reduced = reduceToRelevants(outline, angleThresholdDeg = 177f)
        check(reduced.size >= 3) {
            "Polygon $idx collapsed to ${reduced.size} significant points after reduction — " +
                "outline must have at least 3 vertices after near-collinear filtering."
        }
        GenericRegion(points = reduced.toPoint2DContour(imageSize))
    }
    return GenericAnnotation(regions = regions)
}

private fun List<Offset>.toPoint2DContour(imageSize: Size): List<Point2D> {
    val w = imageSize.width.toDouble()
    val h = imageSize.height.toDouble()
    return map { Point2D(x = it.x.toDouble() / w, y = it.y.toDouble() / h) }
}
