package com.twinskin.sdk.ui.capture

import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.ui.capture.i18n.EnCaptureStrings
import kotlin.native.ObjCName

/** Operator-facing recommendation from the reference-image luminance probe (C ABI mirror — see `xfeat_ref_luminance_recommendation`). */
@TwinSkinInternalApi
@OptIn(kotlin.experimental.ExperimentalObjCName::class)
@Suppress("EnumEntryName")
public enum class RefRecommendation {
    ok,

    @ObjCName(swiftName = "retakeForFocus")
    retakeForFocus,

    @ObjCName(swiftName = "recommendTorch")
    recommendTorch,

    @ObjCName(swiftName = "retakeWithTorch")
    retakeWithTorch,

    @ObjCName(swiftName = "advisoryHighlightsClipped")
    advisoryHighlightsClipped,
    ;

    /**
     * Stable wire string for `SdkReferenceLuminance.recommendation`.
     * The strings travel verbatim into the upload-bundle manifest
     * and downstream pipelines pattern-match on them — any drift is
     * a wire break.
     */
    public val manifestCode: String
        get() = when (this) {
            ok -> "ok"
            retakeForFocus -> "retakeForFocus"
            recommendTorch -> "recommendTorch"
            retakeWithTorch -> "retakeWithTorch"
            advisoryHighlightsClipped -> "advisoryHighlightsClipped"
        }

    /**
     * True when the recommendation indicates the reference is too
     * dark and the torch is the operator's escape hatch. The verdict
     * card is shown only in this case — any other recommendation is
     * accepted with no overlay.
     */
    public val isLowLight: Boolean
        get() = this == recommendTorch || this == retakeWithTorch
}

/**
 * Why the marker-missing card surfaced on a reference attempt.
 * Entries use lowerCamelCase + `@ObjCName(swiftName=…)` so the K/N
 * Swift export keeps the entry names readable — the legacy K/N
 * bridge lowercases the whole entry name verbatim otherwise, so
 * `SeenRecently` would land in Swift as `.seenrecently`.
 */
@TwinSkinInternalApi
@OptIn(kotlin.experimental.ExperimentalObjCName::class)
@Suppress("EnumEntryName")
public enum class RefMarkerWarning {
    /**
     * The marker was visible in the live preview within the
     * recency window but not on the captured frame — likely glare,
     * motion blur, or last-moment drift out of frame.
     */
    @ObjCName(swiftName = "seenRecently")
    seenRecently,

    /** The marker has never been observed this session. */
    @ObjCName(swiftName = "neverSeen")
    neverSeen,

    /**
     * The marker decoded but at least one corner is too close to a
     * frame edge — the printed quiet zone has been cropped, which
     * degrades downstream pose / scale. Surfaced by the native
     * validator's `MARKER_CLIPPED` verdict (see
     * `MARKER_QUIET_ZONE_FRAC` in `marker_api.h`).
     */
    @ObjCName(swiftName = "markerClipped")
    markerClipped,
}

/**
 * Recency window for the live-marker hint, in milliseconds. When
 * the marker was last observed within this many ms of the shutter,
 * the marker-missing card surfaces the "seen recently" copy instead
 * of the "never seen" copy.
 */
@TwinSkinInternalApi
public const val LIVE_MARKER_RECENT_HINT_MS: Long = 2_000L

/**
 * Dwell time for the green "Ready!" overlay after the reference is
 * bound, in milliseconds. Long enough to register, short enough to
 * clear before the first per-arm capture lands.
 */
@TwinSkinInternalApi
public const val REF_READY_DISPLAY_MS: Long = 2_000L

@TwinSkinInternalApi
public fun isMarkerRecent(
    nowMs: Long,
    seenAtMs: Long?,
    hintWindowMs: Long = LIVE_MARKER_RECENT_HINT_MS,
): Boolean = seenAtMs != null && nowMs - seenAtMs <= hintWindowMs

/**
 * "Processing" window between the operator's "Capture reference"
 * tap and either the verdict card / marker-missing card surfacing
 * or the bound-and-sweep starting. The "Do not move" overlay is
 * shown when this returns true.
 */
@TwinSkinInternalApi
public fun isRefShutterCapturing(
    refButtonTapped: Boolean,
    refRetakeGatePending: Boolean,
    refVerdictPending: Boolean,
    refMarkerWarningPending: Boolean,
    isRefCaptureStage: Boolean,
): Boolean = refButtonTapped &&
    !refRetakeGatePending &&
    !refVerdictPending &&
    !refMarkerWarningPending &&
    isRefCaptureStage

/**
 * True when the tutorial overlay should render on top of the
 * preview. Surfaces once a reference image is bound, until the
 * operator dismisses it; the "don't show again" preference hides
 * it unless an explicit reopen request was made.
 */
@TwinSkinInternalApi
public fun shouldShowTutorial(
    hasReferenceImage: Boolean,
    tutorialDismissed: Boolean,
    dontShowAgain: Boolean,
    tutorialReopenRequested: Boolean,
): Boolean = hasReferenceImage &&
    !tutorialDismissed &&
    (!dontShowAgain || tutorialReopenRequested)

/**
 * True when the "?" reopen button should be tappable. Hidden once
 * any arm has been committed — re-opening mid-round would obscure
 * the live amber arm.
 */
@TwinSkinInternalApi
public fun tutorialReopenEnabled(
    hasReferenceImage: Boolean,
    isTutorialShowing: Boolean,
    hasAnyCapturedArms: Boolean,
): Boolean = hasReferenceImage && !isTutorialShowing && !hasAnyCapturedArms

/**
 * True while the demo-download / submit / post-submit phases own
 * the screen — the per-arm grid and devMode demo button stay
 * hidden so they cannot race the in-flight pipeline.
 */
@TwinSkinInternalApi
public fun isInDemoOrSubmitFlow(
    demoFlowActive: Boolean,
    submitting: Boolean,
): Boolean = demoFlowActive || submitting

/**
 * Swift/Android-facing bridge to the generated English capture strings.
 *
 * Public + `@TwinSkinInternalApi` because Swift (`CaptureView.swift`,
 * `CaptureRefShutterOverlays.swift`) and the Android photosphere overlays read
 * it directly, outside any Compose scope. Kotlin `@Composable` code should read
 * [com.twinskin.sdk.ui.capture.i18n.LocalCaptureStrings] instead. EN-only until
 * the Swift bridge is localised; the dispatch functions keep their signatures so
 * Swift call sites are unchanged.
 */
@TwinSkinInternalApi
public object CaptureViewCopy {
    public val doNotMove: String = EnCaptureStrings.doNotMove
    public val ready: String = EnCaptureStrings.ready
    public val holdSteady: String = EnCaptureStrings.holdSteady

    public val lowLightTitle: String = EnCaptureStrings.lowLightTitle
    public val lowLightBodyWithTorch: String = EnCaptureStrings.lowLightBodyWithTorch
    public val lowLightBodyNoTorch: String = EnCaptureStrings.lowLightBodyNoTorch
    public val lowLightRetakeWithTorch: String = EnCaptureStrings.lowLightRetakeWithTorch
    public val lowLightKeepCurrent: String = EnCaptureStrings.lowLightKeepCurrent

    public val markerMissingTitle: String = EnCaptureStrings.markerMissingTitle
    public val markerMissingSeenRecently: String = EnCaptureStrings.markerMissingSeenRecently
    public val markerMissingNeverSeen: String = EnCaptureStrings.markerMissingNeverSeen
    public val markerMissingRetake: String = EnCaptureStrings.markerMissingRetake

    public val markerClippedTitle: String = EnCaptureStrings.markerClippedTitle
    public val markerClippedBody: String = EnCaptureStrings.markerClippedBody

    /** Body copy for the marker-missing card, dispatched on warning. */
    public fun markerMissingBody(warning: RefMarkerWarning): String =
        when (warning) {
            RefMarkerWarning.seenRecently -> markerMissingSeenRecently
            RefMarkerWarning.neverSeen -> markerMissingNeverSeen
            RefMarkerWarning.markerClipped -> markerClippedBody
        }

    /** Title for the marker-missing card, dispatched on warning. */
    public fun markerMissingTitleFor(warning: RefMarkerWarning): String =
        when (warning) {
            RefMarkerWarning.seenRecently, RefMarkerWarning.neverSeen ->
                markerMissingTitle
            RefMarkerWarning.markerClipped -> markerClippedTitle
        }

    /** Body copy for the low-light card, dispatched on torch availability. */
    public fun lowLightBody(hasTorchUnit: Boolean): String =
        if (hasTorchUnit) lowLightBodyWithTorch else lowLightBodyNoTorch
}
