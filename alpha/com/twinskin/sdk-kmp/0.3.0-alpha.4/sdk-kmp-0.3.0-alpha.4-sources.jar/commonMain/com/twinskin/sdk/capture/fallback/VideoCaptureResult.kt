package com.twinskin.sdk.capture.fallback

import com.twinskin.sdk.capture.SdkReferenceLuminance

/** All paths must point inside [com.twinskin.sdk.capture.CaptureSession.workingDir]. */
public data class VideoCaptureResult(
    val photoPath: String,
    val videoPath: String,
    val videoMetadata: VideoMetaData,
    // Forwarded verbatim into the manifest's `marker_version`; `null` when no
    // marker decoded, no probe is wired, or the probe errored (never fabricated).
    val markerVersion: String? = null,
    // Forwarded verbatim into the manifest's `reference_luminance`; `null` when
    // no probe is wired or the native eval didn't run (never fabricated).
    val referenceLuminance: SdkReferenceLuminance? = null,
)
