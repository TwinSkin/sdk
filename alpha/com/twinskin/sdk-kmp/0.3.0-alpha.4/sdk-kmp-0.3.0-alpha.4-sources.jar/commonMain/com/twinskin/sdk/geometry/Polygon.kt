package com.twinskin.sdk.geometry

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import kotlin.math.absoluteValue
import kotlin.math.max
import kotlin.math.min

/**
 * Signed area of a closed polygon via the shoelace formula. Positive for
 * counter-clockwise vertex order, negative for clockwise. Caller takes
 * [absoluteValue] when orientation is irrelevant.
 *
 * Degenerate inputs (< 3 vertices) return `0f`.
 */
internal fun signedArea(poly: List<Offset>): Float {
    if (poly.size < 3) return 0f
    var acc = 0.0
    for (i in poly.indices) {
        val a = poly[i]
        val b = poly[(i + 1) % poly.size]
        acc += a.x.toDouble() * b.y.toDouble() - b.x.toDouble() * a.y.toDouble()
    }
    return (acc * 0.5).toFloat()
}

/**
 * Area-weighted centroid of a closed polygon (true centroid via shoelace).
 * Falls back to the arithmetic mean when the polygon is degenerate
 * (area ~ 0) so callers always get a defined point.
 */
internal fun centroid(poly: List<Offset>): Offset {
    if (poly.isEmpty()) return Offset.Zero
    if (poly.size < 3) return arithmeticMean(poly)

    var cx = 0.0
    var cy = 0.0
    var area2 = 0.0
    for (i in poly.indices) {
        val a = poly[i]
        val b = poly[(i + 1) % poly.size]
        val cross = a.x.toDouble() * b.y.toDouble() - b.x.toDouble() * a.y.toDouble()
        area2 += cross
        cx += (a.x + b.x).toDouble() * cross
        cy += (a.y + b.y).toDouble() * cross
    }
    if (area2.absoluteValue < 1e-9) return arithmeticMean(poly)
    val factor = 1.0 / (3.0 * area2)
    return Offset((cx * factor).toFloat(), (cy * factor).toFloat())
}

private fun arithmeticMean(poly: List<Offset>): Offset {
    var x = 0f
    var y = 0f
    for (p in poly) { x += p.x; y += p.y }
    val n = poly.size.toFloat()
    return Offset(x / n, y / n)
}

/**
 * Axis-aligned bounding box of [poly]. Empty for an empty input.
 */
internal fun bbox(poly: List<Offset>): Rect {
    if (poly.isEmpty()) return Rect.Zero
    var minX = Float.POSITIVE_INFINITY
    var minY = Float.POSITIVE_INFINITY
    var maxX = Float.NEGATIVE_INFINITY
    var maxY = Float.NEGATIVE_INFINITY
    for (p in poly) {
        minX = min(minX, p.x)
        minY = min(minY, p.y)
        maxX = max(maxX, p.x)
        maxY = max(maxY, p.y)
    }
    return Rect(minX, minY, maxX, maxY)
}

/**
 * Point-in-polygon by classical ray casting (Jordan curve theorem).
 * Returns true when [p] lies strictly inside [poly]. Points exactly on
 * an edge are an undefined boundary case (may return true or false
 * depending on edge orientation) — callers requiring boundary-strict
 * answers should layer their own tolerance on top of [distanceToPolyline].
 *
 * Degenerate inputs (< 3 vertices) return false.
 */
internal fun pointInPolygon(p: Offset, poly: List<Offset>): Boolean {
    if (poly.size < 3) return false
    var inside = false
    var j = poly.size - 1
    for (i in poly.indices) {
        val pi = poly[i]
        val pj = poly[j]
        val intersects =
            (pi.y > p.y) != (pj.y > p.y) &&
                p.x < (pj.x - pi.x) * (p.y - pi.y) / (pj.y - pi.y + 1e-12f) + pi.x
        if (intersects) inside = !inside
        j = i
    }
    return inside
}
