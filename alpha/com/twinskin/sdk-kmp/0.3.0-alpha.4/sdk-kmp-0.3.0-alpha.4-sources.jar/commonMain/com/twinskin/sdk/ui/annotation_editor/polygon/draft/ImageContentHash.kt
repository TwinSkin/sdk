package com.twinskin.sdk.ui.annotation_editor.polygon.draft

import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ImageBitmapConfig

/**
 * FNV-1a 64-bit hash of three horizontal pixel strips (top / middle /
 * bottom). Non-cryptographic — only used to key the draft store by
 * source bitmap; collisions across a single session are vanishingly
 * unlikely for clinical photos.
 *
 * Output format: `"<width>x<height>-<hexHash>-<configTag>"`. The
 * dimension and config prefixes keep otherwise-equivalent strip
 * hashes apart when the bitmap shape or pixel format differs.
 */
internal fun ImageBitmap.contentHash(): String {
    val w = width
    val h = height
    if (w <= 0 || h <= 0) return "0x0-0"

    val pixelsPerStrip = STRIP_PIXELS.coerceAtLeast(w)
    val rowsPerStrip = (pixelsPerStrip / w).coerceAtLeast(1)

    val midY = ((h - rowsPerStrip) / 2).coerceAtLeast(0)
    val bottomY = (h - rowsPerStrip).coerceAtLeast(0)
    val starts = setOf(0, midY, bottomY)

    var hash = FNV_OFFSET
    for (yStart in starts) {
        val stripH = rowsPerStrip.coerceAtMost(h - yStart)
        if (stripH <= 0) continue
        val buffer = IntArray(w * stripH)
        readPixels(
            buffer = buffer,
            startX = 0,
            startY = yStart,
            width = w,
            height = stripH,
            bufferOffset = 0,
            stride = w,
        )
        for (px in buffer) {
            hash = hash xor (px.toLong() and 0xFFFFFFFFL)
            hash = hash * FNV_PRIME
        }
    }

    val unsigned = hash.toULong().toString(16)
    return "${w}x${h}-${unsigned}-${configTag(config)}"
}

private fun configTag(c: ImageBitmapConfig): String = when (c) {
    ImageBitmapConfig.Argb8888 -> "argb8"
    ImageBitmapConfig.Alpha8 -> "a8"
    ImageBitmapConfig.Rgb565 -> "rgb565"
    ImageBitmapConfig.F16 -> "f16"
    ImageBitmapConfig.Gpu -> "gpu"
    else -> "x"
}

private const val FNV_OFFSET: Long = -3750763034362895579L      // 0xCBF29CE484222325
private const val FNV_PRIME: Long = 1099511628211L               // 0x100000001B3
private const val STRIP_PIXELS: Int = 256                        // ~1 KB per strip @ ARGB8
