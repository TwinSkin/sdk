package com.twinskin.sdk.capture

import com.twinskin.sdk.capture.io.ByteSink

/**
 * Streaming POSIX ustar (tar) writer. Writes one entry at a time through a
 * [ByteSink] without buffering the entry's payload. Each entry is a fixed
 * 512-byte ustar header followed by the file data, padded to the next 512-byte
 * boundary. [finish] writes the two-block end-of-archive marker.
 *
 * Names must be at most 100 bytes (no long-name extensions). Sizes must be
 * non-negative and fit in 11 octal digits (max 8 GiB).
 */
internal class TarStoreSink(private val out: ByteSink) {

    private var finished = false

    fun addEntry(name: String, size: Long, producer: (ByteSink) -> Unit) {
        check(!finished) { "addEntry after finish()" }
        require(size >= 0) { "negative entry size: $size" }
        val nameBytes = name.encodeToByteArray()
        require(nameBytes.size in 1..100) {
            "tar entry name must be 1..100 bytes, got ${nameBytes.size} for '$name'"
        }
        require(size <= 0x1FFFFFFFFL) {
            "tar entry size > 8 GiB not supported (no PAX): $size"
        }
        val header = buildUstarHeader(nameBytes, size)
        out.write(header, 0, header.size)

        var observed = 0L
        producer(ByteSink { src, off, len ->
            observed += len
            out.write(src, off, len)
        })
        check(observed == size) {
            "TarStoreSink: entry '$name' declared $size bytes but producer wrote $observed"
        }
        val pad = ((512 - (size % 512)) % 512).toInt()
        if (pad > 0) out.write(ZERO_BLOCK, 0, pad)
    }

    fun finish() {
        if (finished) return
        finished = true
        out.write(ZERO_BLOCK, 0, 512)
        out.write(ZERO_BLOCK, 0, 512)
    }

    private fun buildUstarHeader(nameBytes: ByteArray, size: Long): ByteArray {
        val h = ByteArray(512)
        nameBytes.copyInto(h, 0)
        writeOctalField(h, 100, 8, 420L)            // mode 0644 (decimal 420)
        writeOctalField(h, 108, 8, 0L)              // uid
        writeOctalField(h, 116, 8, 0L)              // gid
        writeOctalField(h, 124, 12, size)
        writeOctalField(h, 136, 12, 0L)             // mtime
        for (i in 0 until 8) h[148 + i] = 0x20      // checksum field placeholder = 8 spaces
        h[156] = '0'.code.toByte()                  // typeflag = regular file
        // magic "ustar\0", version "00"
        "ustar".encodeToByteArray().copyInto(h, 257)
        h[262] = 0
        h[263] = '0'.code.toByte()
        h[264] = '0'.code.toByte()
        var sum = 0
        for (b in h) sum += b.toInt() and 0xff
        // 6 octal digits + NUL + space at offset 148
        writeOctalString(h, 148, 6, sum.toLong())
        h[154] = 0
        h[155] = 0x20
        return h
    }

    /**
     * Write a value as octal digits zero-padded to (width - 1) characters,
     * followed by a NUL terminator. Standard tar field encoding.
     */
    private fun writeOctalField(buf: ByteArray, off: Int, width: Int, value: Long) {
        writeOctalString(buf, off, width - 1, value)
        buf[off + width - 1] = 0
    }

    private fun writeOctalString(buf: ByteArray, off: Int, width: Int, value: Long) {
        var v = value
        for (i in width - 1 downTo 0) {
            buf[off + i] = ('0'.code + (v and 7L).toInt()).toByte()
            v = v ushr 3
        }
    }

    companion object {
        private val ZERO_BLOCK = ByteArray(512)
    }
}
