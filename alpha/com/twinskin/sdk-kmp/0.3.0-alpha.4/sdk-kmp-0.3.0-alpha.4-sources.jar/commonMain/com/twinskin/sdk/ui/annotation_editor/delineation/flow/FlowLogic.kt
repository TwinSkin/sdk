package com.twinskin.sdk.ui.annotation_editor.delineation.flow

import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound

/**
 * Pure helpers shared by the canvas-hosting screens. Extracted to
 * top-level `internal fun`s so the predicates are jvmTest-covered
 * without a Compose harness.
 */

/**
 * Card-state recomputation after a wound reshape's tissue reclip
 * cascade (spec §7.3). One transition rule:
 *
 *  - `Drawn` + no surviving tissues of this type → `Open` (the user
 *    might want to draw new tissues; we don't auto-promote to
 *    `Absent` because the wipeout was algorithmic, not an explicit
 *    "no tissue here" decision).
 *  - `Absent` stays `Absent` (explicit user decision is sacred —
 *    the reshape cascade can't undo it).
 *  - `Open` stays `Open` (reclip can only remove/split, never add,
 *    so `Open + hasTissues` is unreachable from a reshape — but the
 *    branch is exhaustive against the enum either way).
 *  - `Drawn` + tissues still present → `Drawn` (no transition).
 *
 * The reverse transition (`Open` → `Drawn`) is owned by the
 * `TissueDrawingScreen`'s Back path: after the user has drawn at
 * least one tissue of a type, that screen flips the card to `Drawn`.
 * This function is reshape-cascade-only.
 */
internal fun recomputeCardStateAfterReclip(
    current: TissueCardState,
    typeStillHasTissues: Boolean,
): TissueCardState = when (current) {
    TissueCardState.Drawn -> if (typeStillHasTissues) TissueCardState.Drawn else TissueCardState.Open
    TissueCardState.Absent -> TissueCardState.Absent
    TissueCardState.Open -> TissueCardState.Open
}

/**
 * True when the focused wound has dependent tissues — the screen
 * shows a confirmation dialog before deleting (spec §6.5.1).
 * `wounds[idx].tissues.isEmpty()` is a no-dialog fast path.
 */
internal fun shouldShowDeleteConfirmation(woundIndex: Int, wounds: List<Wound>): Boolean {
    if (woundIndex !in wounds.indices) return false
    return wounds[woundIndex].tissues.isNotEmpty()
}
