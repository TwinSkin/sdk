package com.twinskin.sdk.ui.annotation_editor.polygon.engine

import androidx.compose.ui.geometry.Offset

/**
 * The gesture currently in flight on the [EditorController].
 * `activeGesture == null` means Idle (or Empty, depending on whether
 * any polygon/stroke exists).
 *
 * The spec's "one action at a time" principle (P3) is enforced by the
 * controller: while `activeGesture != null`, subsequent `onTouchDown`
 * calls return [GestureKind.None] (multi-finger arbitration is M8's
 * gesture-loop responsibility; the controller assumes single-finger
 * input — see [EditorController]'s class KDoc).
 */
internal sealed class ActiveGesture {
    /** Drawing or continuing an open stroke. */
    data class Stroke(val openStroke: OpenStroke) : ActiveGesture()

    /**
     * Reshaping an existing polygon. Geometry update on each
     * pointer-move is M5's responsibility; this state simply pins
     * the polygon index and remembers the pre-reshape outline so
     * undo can restore it atomically without per-move undo pushes.
     */
    data class Reshape(
        val polygonIdx: Int,
        val undoStartSnapshot: List<Offset>,
    ) : ActiveGesture()

    /**
     * Potential tap — touch-down landed inside a polygon. On
     * touch-up: if the cursor never moved more than
     * `TAP_SLOP_CANVAS_PX` from [downAt], transfer focus to the
     * tapped polygon. Otherwise silently no-op (spec §6.3.4, §6.3.5).
     */
    data class Tap(val downAt: Offset) : ActiveGesture()
}
