package com.twinskin.sdk.ui.annotation_editor.polygon.engine

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size

/**
 * Read-only context the [EditorController] and [GestureRouter] need
 * to translate canvas-space pointer events into image-space polygon
 * mutations.
 *
 * For M4 tests, identity transforms (scale = 1, pan = zero) keep
 * canvas-px and image-px in lockstep — the state machine logic is
 * coordinate-system-agnostic. M7 will refresh the real-zoom version
 * via `ZoomPanController`.
 *
 * @param canvasFromImageScale  multiplier from image-px to canvas-px
 *                              (uniform scale; no rotation in v1).
 * @param pan                   canvas-px offset of the image's
 *                              top-left in canvas space.
 * @param containmentPolygons   when non-null, a new stroke must
 *                              **start** inside one of these polygons
 *                              (screen 4: the wound list). Null on
 *                              screen 2 — any empty area starts a
 *                              new wound. Distinct from
 *                              [confinementOutline] — that's the
 *                              "must STAY inside" runtime clamp,
 *                              this is the "must START inside" gate.
 * @param forbiddenInteriors    polygons the active stroke / reshape
 *                              must not enter — vertices landing
 *                              inside are projected to the nearest
 *                              boundary point (spec §6.4). M11 must
 *                              NOT include the polygon being edited
 *                              (the controller would otherwise clamp
 *                              the polygon against itself).
 * @param confinementOutline    when non-null, the active stroke /
 *                              reshape must stay inside this
 *                              polygon — vertices landing outside
 *                              are projected to its nearest boundary
 *                              point (spec §8.4 — tissue-mode
 *                              parent-wound confinement). Null on
 *                              screen 2.
 */
internal data class GestureCtx(
    val canvasSize: Size,
    val imageSize: Size,
    val canvasFromImageScale: Float,
    val pan: Offset,
    val containmentPolygons: List<List<Offset>>? = null,
    val forbiddenInteriors: List<List<Offset>> = emptyList(),
    val confinementOutline: List<Offset>? = null,
) {
    /** Identity transform — the test default and the "unzoomed fit" runtime case. */
    companion object {
        fun identity(
            canvasSize: Size,
            imageSize: Size = canvasSize,
            containmentPolygons: List<List<Offset>>? = null,
            forbiddenInteriors: List<List<Offset>> = emptyList(),
            confinementOutline: List<Offset>? = null,
        ): GestureCtx = GestureCtx(
            canvasSize = canvasSize,
            imageSize = imageSize,
            canvasFromImageScale = 1f,
            pan = Offset.Zero,
            containmentPolygons = containmentPolygons,
            forbiddenInteriors = forbiddenInteriors,
            confinementOutline = confinementOutline,
        )
    }
}

internal fun GestureCtx.canvasToImage(canvasPos: Offset): Offset = Offset(
    (canvasPos.x - pan.x) / canvasFromImageScale,
    (canvasPos.y - pan.y) / canvasFromImageScale,
)

internal fun GestureCtx.imageToCanvas(imagePos: Offset): Offset = Offset(
    imagePos.x * canvasFromImageScale + pan.x,
    imagePos.y * canvasFromImageScale + pan.y,
)

/** Canvas-pixel distance between two image-pixel points, given this context's scale. */
internal fun GestureCtx.canvasDistance(imageA: Offset, imageB: Offset): Float {
    val dx = (imageA.x - imageB.x) * canvasFromImageScale
    val dy = (imageA.y - imageB.y) * canvasFromImageScale
    return kotlin.math.sqrt(dx * dx + dy * dy)
}
