package com.twinskin.sdk.ui.annotation_editor.delineation.draft

import com.russhwolf.settings.Settings

/**
 * Persistent editor-wide preferences. Distinct from [DraftStore]
 * because the lifetime is different: drafts are per-image and
 * ephemeral (cleared on validation), while preferences are
 * global and persist across sessions until the user opts back in.
 *
 * Today carries the reshape advisory and delete-confirmation
 * suppression flags. Future one-shot advisories / onboarding tips
 * land here too rather than spawning sibling abstractions.
 */
internal interface EditorPreferences {
    fun isReshapeAdvisoryDismissed(): Boolean
    fun setReshapeAdvisoryDismissed(value: Boolean)

    /**
     * When true, the WoundDrawingScreen Delete button skips the
     * wound-with-tissues confirmation dialog and deletes
     * immediately. Wounds without tissues never showed the dialog
     * and aren't affected by this flag.
     */
    fun isDeleteWoundConfirmationDismissed(): Boolean
    fun setDeleteWoundConfirmationDismissed(value: Boolean)
}

/**
 * [Settings]-backed [EditorPreferences]. Reuses the same
 * platform-specific [Settings] instance the [DraftStore] uses;
 * each flag's `_v1` key suffix reserves the option to
 * invalidate dismissals across major editor versions if we
 * change the warning's substance later.
 */
internal class SettingsBackedEditorPreferences(
    private val settings: Settings,
) : EditorPreferences {
    override fun isReshapeAdvisoryDismissed(): Boolean =
        settings.getBoolean(KEY_RESHAPE_ADVISORY_DISMISSED, defaultValue = false)

    override fun setReshapeAdvisoryDismissed(value: Boolean) {
        settings.putBoolean(KEY_RESHAPE_ADVISORY_DISMISSED, value)
    }

    override fun isDeleteWoundConfirmationDismissed(): Boolean =
        settings.getBoolean(KEY_DELETE_WOUND_CONFIRM_DISMISSED, defaultValue = false)

    override fun setDeleteWoundConfirmationDismissed(value: Boolean) {
        settings.putBoolean(KEY_DELETE_WOUND_CONFIRM_DISMISSED, value)
    }

    private companion object {
        const val KEY_RESHAPE_ADVISORY_DISMISSED = "wound_reshape_advisory_dismissed_v1"
        const val KEY_DELETE_WOUND_CONFIRM_DISMISSED = "delete_wound_confirmation_dismissed_v1"
    }
}
