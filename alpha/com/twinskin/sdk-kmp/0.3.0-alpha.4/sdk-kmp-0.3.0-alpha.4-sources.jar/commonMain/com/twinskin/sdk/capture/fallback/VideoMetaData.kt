package com.twinskin.sdk.capture.fallback

import kotlinx.serialization.Serializable

/**
 * SDK-side mirror of the web_app's `VideoMetaData`
 * (`packages/server/lib/src/front_apis/case/api.dart`). Field names —
 * including the long-standing `gyroscoptData` typo and the
 * `magnetoscopeData` mis-spelling — are reproduced verbatim so the
 * decrypt-side parser doesn't need a per-source branch.
 *
 * Per #503's contract, the SDK collects magnetometer samples for
 * completeness but does NOT emit them in the returned payload —
 * matches the web_app's `getSavedData`, which drops magnetometer too.
 * The field is kept on the model so a re-decode of an old web_app
 * payload still parses; SDK-produced payloads always emit `null`.
 */
@Serializable
public data class VideoMetaData(
    val accelerometerData: List<AccelerometerData>? = null,
    val gyroscoptData: List<AccelerometerData>? = null,
    val userAccelerometerData: List<AccelerometerData>? = null,
    val magnetoscopeData: List<AccelerometerData>? = null,
)
