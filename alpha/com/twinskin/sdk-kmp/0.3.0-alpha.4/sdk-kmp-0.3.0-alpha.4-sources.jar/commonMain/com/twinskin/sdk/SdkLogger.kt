package com.twinskin.sdk

// Declaration order is the threshold order — LevelFilteringLogger compares ordinals.
public enum class SdkLogLevel {
    Debug,
    Info,
    Warning,
    Error,
}

/** Diagnostic sink. Filtering happens upstream in [LevelFilteringLogger]. */
public fun interface SdkLogger {
    public fun log(level: SdkLogLevel, message: String, cause: Throwable?)

    public companion object {
        public val None: SdkLogger = SdkLogger { _, _, _ -> }

        public val Console: SdkLogger = SdkLogger { level, message, cause ->
            val suffix = cause?.let { " (${it::class.simpleName}: ${it.message})" }.orEmpty()
            println("[TwinSkin][${level.name.uppercase()}] $message$suffix")
        }
    }
}

internal fun SdkLogger.debug(message: String, cause: Throwable? = null): Unit =
    log(SdkLogLevel.Debug, message, cause)

internal fun SdkLogger.info(message: String, cause: Throwable? = null): Unit =
    log(SdkLogLevel.Info, message, cause)

internal fun SdkLogger.warn(message: String, cause: Throwable? = null): Unit =
    log(SdkLogLevel.Warning, message, cause)

internal fun SdkLogger.error(message: String, cause: Throwable? = null): Unit =
    log(SdkLogLevel.Error, message, cause)

/** Forwards only messages at or above [minLevel]; installed once at init. */
internal class LevelFilteringLogger(
    private val minLevel: SdkLogLevel,
    private val delegate: SdkLogger,
) : SdkLogger {
    override fun log(level: SdkLogLevel, message: String, cause: Throwable?) {
        if (level.ordinal >= minLevel.ordinal) delegate.log(level, message, cause)
    }
}
