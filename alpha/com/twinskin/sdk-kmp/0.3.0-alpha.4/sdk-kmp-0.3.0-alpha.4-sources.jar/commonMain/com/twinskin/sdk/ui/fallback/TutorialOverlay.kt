package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.capture.i18n.LocalCaptureStrings
import kotlinx.coroutines.launch

/**
 * Animated two-page capture tutorial. There is no video — both the on-demand Help
 * sheet and the first-run overlay render the same inline animated coaches. Page 1
 * teaches the single photo, page 2 the 20 s orbit.
 *
 * The pages are a gesture-swipeable [HorizontalPager]. The "Don't show again" row
 * drives [SdkUserPreferences.coachmarkDismissed] and is shown in BOTH entries, so
 * a user who dismissed the Help tutorial can re-enable it by unticking it.
 */
@Composable
private fun CaptureTutorial(
    onDismiss: () -> Unit,
    preferences: SdkUserPreferences?,
    dismissibleFromFirstPage: Boolean,
) {
    val colors = LocalAccelerometerCaptureColors.current
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 2 })
    val scope = rememberCoroutineScope()
    var dontShowAgain by remember { mutableStateOf(preferences?.coachmarkDismissed ?: false) }
    val onFirstPage = pagerState.currentPage == 0
    val showClose = dismissibleFromFirstPage || !onFirstPage

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        // Under the edge-to-edge activity the bottom CTA would draw under the nav
        // bar; consume `Vertical` safe-area so the CTA clears it and the top row
        // clears the cutout (0 where there is no bar, so it never double-pads).
        Column(
            modifier = Modifier.fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Vertical)),
        ) {
            Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp)) {
                if (showClose) {
                    Box(
                        modifier = Modifier.align(Alignment.CenterStart).size(40.dp)
                            .border(2.dp, colors.onPrimary, CircleShape).clickable { onDismiss() },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Outlined.Close, contentDescription = LocalCaptureStrings.current.tutorialClose, tint = colors.onPrimary)
                    }
                }
                Text(
                    text = if (onFirstPage) LocalCaptureStrings.current.tutorialStep1Title
                    else LocalCaptureStrings.current.tutorialStep2Title,
                    color = colors.onPrimary, fontSize = 20.sp, fontWeight = FontWeight.Normal,
                    // Reserve the close-button zone on both sides so the centred
                    // title wraps rather than underlapping the X on narrow screens.
                    textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center)
                        .fillMaxWidth()
                        .padding(horizontal = 56.dp),
                )
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxWidth().weight(1.4f),
            ) { page ->
                Box(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    if (page == 0) LevelCoach() else OrbitCoach()
                }
            }

            // The below-pager content scrolls so nothing clips on a short screen.
            // The Column is WEIGHTED so its height is bounded by its share of the
            // viewport, not its intrinsic content height: an unweighted
            // verticalScroll child reports its full content height and, racing the
            // weighted pager, starves the coach toward zero on a very short screen.
            // With both weighted the pager keeps the larger share (1.4 vs 1) and
            // overflow stays scrollable inside this bounded region.
            Column(
                modifier = Modifier.fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 10.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                CueRow(
                    cues = if (onFirstPage) listOf(
                        CuePic.Parallel to LocalCaptureStrings.current.cueFlatParallel,
                        CuePic.Distance to LocalCaptureStrings.current.cueDistance,
                        CuePic.Frame to LocalCaptureStrings.current.cueWoundMarker,
                    ) else listOf(
                        CuePic.Orbit to LocalCaptureStrings.current.cueMoveAround,
                        CuePic.Target to LocalCaptureStrings.current.cueFollowDot,
                        CuePic.Ring8 to LocalCaptureStrings.current.cueFillAll,
                    ),
                    modifier = Modifier.padding(horizontal = 6.dp),
                )

                Spacer(Modifier.height(12.dp))
                PageIndicator(
                    pageCount = 2,
                    activePage = pagerState.currentPage,
                    offsetFraction = pagerState.currentPageOffsetFraction,
                    colors = colors,
                )

                // Shown only when preferences are wired, so the row appears in both
                // the first-run and the on-demand Help tutorial.
                if (preferences != null) {
                    Spacer(Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Checkbox(checked = dontShowAgain, onCheckedChange = {
                            dontShowAgain = it; preferences.coachmarkDismissed = it
                        })
                        Box(modifier = Modifier.clickable {
                            dontShowAgain = !dontShowAgain; preferences.coachmarkDismissed = dontShowAgain
                        }) {
                            Text(LocalCaptureStrings.current.doNotShowAgain, color = colors.onPrimary, fontSize = 14.sp)
                        }
                    }
                } else {
                    Spacer(Modifier.height(10.dp))
                }

                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .background(colors.orbit, RoundedCornerShape(20.dp))
                        .clickable {
                            if (onFirstPage) scope.launch { pagerState.animateScrollToPage(1) } else onDismiss()
                        }
                        .padding(horizontal = 26.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = if (onFirstPage) LocalCaptureStrings.current.tutorialNext
                        else LocalCaptureStrings.current.tutorialGotIt,
                        color = colors.onOrbit, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                    )
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

/**
 * Page-indicator dots whose active pill slides as the pager is swiped, driven by
 * `currentPageOffsetFraction`. Gesture-driven rather than an
 * [androidx.compose.animation.core.Animatable] loop, so it's free of the XCover5
 * looping-animation freeze.
 */
@Composable
private fun PageIndicator(
    pageCount: Int,
    activePage: Int,
    offsetFraction: Float,
    colors: AccelerometerCaptureColors,
) {
    val dot = 7.dp
    val gap = 7.dp
    val activeWidth = 18.dp
    Box(contentAlignment = Alignment.CenterStart) {
        Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
            repeat(pageCount) { Box(Modifier.size(width = dot, height = dot).background(colors.outline, RoundedCornerShape(4.dp))) }
        }
        val position = (activePage + offsetFraction).coerceIn(0f, (pageCount - 1).toFloat())
        val slot = dot + gap
        Box(
            modifier = Modifier
                .padding(start = slot * position)
                .size(width = activeWidth, height = dot)
                .background(colors.orbit, RoundedCornerShape(4.dp)),
        )
    }
}

/**
 * On-demand tutorial opened by the [HelpButton]. Takes [preferences] so the
 * "Don't show again" row shows here too, letting a user re-enable the first-run
 * tutorial after dismissing it.
 */
@Composable
public fun TutorialOverlay(
    onDismiss: () -> Unit,
    preferences: SdkUserPreferences? = null,
) {
    CaptureTutorial(onDismiss = onDismiss, preferences = preferences, dismissibleFromFirstPage = true)
}

/**
 * First-run two-page tutorial; shown whenever the persisted
 * [SdkUserPreferences.coachmarkDismissed] flag is false.
 *
 * The seen-flag is written ONLY by the "Don't show again" checkbox, never on a
 * plain dismiss — so an unticked dismiss re-shows the tutorial next time. The
 * gate in [firstRunTutorialPending] keys off the same flag.
 */
@Composable
public fun FirstRunTutorialOverlay(
    preferences: SdkUserPreferences,
    onDismiss: () -> Unit,
) {
    CaptureTutorial(
        onDismiss = onDismiss,
        preferences = preferences,
        dismissibleFromFirstPage = false,
    )
}

@Composable
public fun ExitConfirmationDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        modifier = Modifier.fillMaxSize().background(colors.errorScrim).clickable { onDismiss() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier.padding(32.dp)
                .background(colors.surfaceContainer, RoundedCornerShape(16.dp))
                .border(1.dp, colors.outlineVariant, RoundedCornerShape(16.dp))
                .clickable(enabled = false) {}
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(LocalCaptureStrings.current.exitTitle, color = colors.onSurface, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Text(LocalCaptureStrings.current.exitBody,
                color = colors.onSurfaceVariant, fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier.weight(1f)
                        .border(2.dp, colors.outline, RoundedCornerShape(11.dp))
                        .clickable { onDismiss() }.padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(LocalCaptureStrings.current.exitDismiss, color = colors.onSurface, fontSize = 14.sp)
                }
                Spacer(Modifier.width(12.dp))
                Box(
                    modifier = Modifier.weight(1f)
                        .background(colors.error, RoundedCornerShape(11.dp))
                        .clickable { onConfirm() }.padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(LocalCaptureStrings.current.exitConfirm, color = colors.surface, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/**
 * Retake-confirmation dialog opened by tapping the reference thumbnail on
 * PhotoTaken. Mirrors [ExitConfirmationDialog]'s layout but uses the cyan accent
 * rather than the destructive red — retaking the reference photo is a routine
 * correction, not a session-ending action.
 */
@Composable
public fun RetakeConfirmationDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        modifier = Modifier.fillMaxSize().background(colors.errorScrim).clickable { onDismiss() },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier.padding(32.dp)
                .background(colors.surfaceContainer, RoundedCornerShape(16.dp))
                .border(1.dp, colors.outlineVariant, RoundedCornerShape(16.dp))
                .clickable(enabled = false) {}
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(LocalCaptureStrings.current.retakeTitle, color = colors.onSurface, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Text(LocalCaptureStrings.current.retakeBody,
                color = colors.onSurfaceVariant, fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier.weight(1f)
                        .border(2.dp, colors.outline, RoundedCornerShape(11.dp))
                        .clickable { onDismiss() }.padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(LocalCaptureStrings.current.retakeDismiss, color = colors.onSurface, fontSize = 14.sp)
                }
                Spacer(Modifier.width(12.dp))
                Box(
                    modifier = Modifier.weight(1f)
                        .background(colors.orbit, RoundedCornerShape(11.dp))
                        .clickable { onConfirm() }.padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(LocalCaptureStrings.current.retakeConfirm, color = colors.onOrbit, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
