@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.transfers

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.CaptureObserver
import com.twinskin.sdk.capture.PendingUpload

/**
 * Stateful wrapper that subscribes to a [CaptureObserver]'s
 * `observePendingUploads()` stream and renders [TransfersScreen] over the
 * latest snapshot. The queue survives process death — the SDK re-emits the
 * full list on every change, so the screen stays correct across restarts.
 *
 * Wire `observer = TwinSkin.captures` at the call site. Kept thin and
 * injectable so the screen can be exercised with a fake observer in tests.
 */
@TwinSkinInternalApi
@Composable
public fun TransfersScreenHost(
    observer: CaptureObserver,
    onViewResult: (PendingUpload) -> Unit = {},
    onRetry: (PendingUpload) -> Unit = {},
    onClose: () -> Unit = {},
) {
    val flow = remember(observer) { observer.observePendingUploads() }
    val uploads by flow.collectAsState(initial = emptyList())
    TransfersScreen(
        uploads = uploads,
        onRetry = onRetry,
        onViewResult = onViewResult,
        onClose = onClose,
    )
}
