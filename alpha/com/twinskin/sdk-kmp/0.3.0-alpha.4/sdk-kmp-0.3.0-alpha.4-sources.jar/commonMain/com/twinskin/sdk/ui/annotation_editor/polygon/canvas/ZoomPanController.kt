package com.twinskin.sdk.ui.annotation_editor.polygon.canvas

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import kotlin.math.max

/**
 * Holds the editor's zoom + pan transform.
 *
 * Spec §6.8 — two-finger pinch + translate. `scale` ranges from
 * `MIN_SCALE = 1` (fully fitted, centred) to `MAX_SCALE = 15`. Pan
 * is clamped so the zoomed image edges never reveal blank canvas
 * inside the viewport — at scale 1, pan is locked to zero; above
 * that, pan stops when an image edge reaches a canvas edge.
 *
 * Letterbox edge case: when the image's aspect ratio doesn't match
 * the canvas's, [fitTransform] produces letterboxing at fit. The
 * pan clamp uses the per-axis fitted dimension (the image's actual
 * canvas-pixel footprint at scale 1), so the letterboxed axis stays
 * pinned at 0 until the zoomed image exceeds the canvas on that
 * axis.
 *
 * Compose observation: the canvas reads [state] as a single
 * `State<Pair<Float, Offset>>` so a one-mutation transform change
 * invalidates one recomposition scope, not two parallel ones.
 */
internal class ZoomPanController(
    canvasSize: Size = Size.Zero,
    imageSize: Size = Size.Zero,
) {
    private var canvasSize: Size = canvasSize
        private set
    private var imageSize: Size = imageSize
        private set
    private var fit: FitTransform? = computeFit(canvasSize, imageSize)

    private val _state = mutableStateOf<Pair<Float, Offset>>(MIN_SCALE to Offset.Zero)

    /** Single State<Pair<scale, pan>> view; canvas reads `.value` once per frame. */
    val state: State<Pair<Float, Offset>> get() = _state

    val scale: Float get() = _state.value.first
    val offset: Offset get() = _state.value.second

    /**
     * Updates the viewport size (e.g. when the canvas resizes on a
     * device rotation). Re-clamps the current offset against the new
     * fit transform so a previously valid pan doesn't suddenly
     * expose letterboxed space.
     *
     * Pre-layout calls with a zero-sized canvas or image leave the
     * controller in a no-op state (zoom/pan ignored, transforms
     * return identity) until a real size arrives.
     */
    fun setViewport(canvasSize: Size, imageSize: Size) {
        this.canvasSize = canvasSize
        this.imageSize = imageSize
        this.fit = computeFit(canvasSize, imageSize)
        _state.value = scale to clampPan(offset, scale)
    }

    /**
     * Anchored zoom — sets [newScale] (clamped to `[1, 15]`) while
     * keeping the image point under [focalCanvas] visually fixed.
     * Standard pinch-to-zoom behavior: the point the user pinched
     * doesn't drift.
     *
     * Math: let `f = focalCanvas`. The image point under `f` at the
     * old transform is `f_img = canvasToImage(f, ..., oldScale, oldPan)`.
     * For `f_img` to map to the same `f` under the new transform:
     * `f = imageToCanvas(f_img, ..., newScale, newPan)`. Solving for
     * `newPan` and substituting through the centred-scale formula:
     * `newPan = f - centredAtNewScale(f_img) − centringOffset`.
     */
    fun setScaleAnchored(newScale: Float, focalCanvas: Offset) {
        if (fit == null) return
        val clampedScale = newScale.coerceIn(MIN_SCALE, MAX_SCALE)
        val (oldScale, oldPan) = _state.value
        if (clampedScale == oldScale) return

        // Image-pixel point under the focal at the OLD transform.
        val focalImage = canvasToImage(
            canvasPos = focalCanvas,
            canvasSize = canvasSize,
            imageSize = imageSize,
            zoomScale = oldScale,
            zoomPan = oldPan,
        )
        // What pan keeps focalImage under focalCanvas at the new scale?
        // imageToCanvas with zoomPan = 0 gives the centred-no-pan position;
        // newPan is the residual.
        val centredAtNewScale = imageToCanvas(
            imagePos = focalImage,
            canvasSize = canvasSize,
            imageSize = imageSize,
            zoomScale = clampedScale,
            zoomPan = Offset.Zero,
        )
        val newPan = clampPan(focalCanvas - centredAtNewScale, clampedScale)
        _state.value = clampedScale to newPan
    }

    /**
     * Translates the pan by [delta] (canvas pixels), clamped so the
     * image edges stay flush with the canvas edges (no letterbox
     * inside the visible viewport after a pan).
     */
    fun translateClamped(delta: Offset) {
        if (fit == null) return
        val current = _state.value
        val newPan = clampPan(current.second + delta, current.first)
        if (newPan != current.second) _state.value = current.first to newPan
    }

    /** Canvas-pixel position → image-pixel position under the current transform. */
    fun toScene(canvasPos: Offset): Offset {
        if (fit == null) return canvasPos
        return canvasToImage(
            canvasPos = canvasPos,
            canvasSize = canvasSize,
            imageSize = imageSize,
            zoomScale = scale,
            zoomPan = offset,
        )
    }

    /** Image-pixel position → canvas-pixel position under the current transform. */
    fun toCanvas(scenePos: Offset): Offset {
        if (fit == null) return scenePos
        return imageToCanvas(
            imagePos = scenePos,
            canvasSize = canvasSize,
            imageSize = imageSize,
            zoomScale = scale,
            zoomPan = offset,
        )
    }

    /**
     * Clamps [pan] so the zoomed image's edges don't reveal
     * letterbox / blank canvas inside the viewport. Per-axis range:
     * `±max(0, (scale × fittedDim − canvasDim) / 2)`. At `scale = 1`
     * with `fittedDim < canvasDim` (letterbox axis) the range
     * collapses to `[0, 0]`.
     */
    private fun clampPan(pan: Offset, atScale: Float): Offset {
        val fit = fit ?: return Offset.Zero
        val maxX = max(0f, (atScale * fit.fittedSize.width - canvasSize.width) * 0.5f)
        val maxY = max(0f, (atScale * fit.fittedSize.height - canvasSize.height) * 0.5f)
        return Offset(
            pan.x.coerceIn(-maxX, maxX),
            pan.y.coerceIn(-maxY, maxY),
        )
    }

    internal companion object {
        const val MIN_SCALE: Float = 1f
        const val MAX_SCALE: Float = 15f

        private fun computeFit(canvasSize: Size, imageSize: Size): FitTransform? {
            if (canvasSize.width <= 0f || canvasSize.height <= 0f) return null
            if (imageSize.width <= 0f || imageSize.height <= 0f) return null
            return fitTransform(canvasSize, imageSize)
        }
    }
}
