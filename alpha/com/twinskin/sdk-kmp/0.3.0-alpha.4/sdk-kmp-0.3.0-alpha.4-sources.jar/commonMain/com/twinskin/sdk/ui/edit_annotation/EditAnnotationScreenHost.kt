@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.edit_annotation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.i18n.sdkLocale
import com.twinskin.sdk.ui.annotation_editor.AnnotationEditorForCapture
import com.twinskin.sdk.ui.capture.i18n.captureStringsFor
import com.twinskin.sdk.ui.theme.TwinSkinColors
import com.twinskin.sdk.ui.view_capture.subview.ViewCaptureErrorView
import com.twinskin.sdk.view.CaptureSource
import com.twinskin.sdk.view.ViewCaptureState

/**
 * Standalone annotation-editor host: opens the editor for an existing capture,
 * seeded with the latest synced annotation, submits the edited contour itself,
 * and reports the [EditAnnotationResult]. No 3D viewer around it.
 */
@TwinSkinInternalApi
@Composable
public fun EditAnnotationScreenHost(
    captureId: String,
    subjectRef: String,
    onResult: (EditAnnotationResult) -> Unit,
) {
    var retryKey by remember { mutableIntStateOf(0) }
    val strings = remember { captureStringsFor(sdkLocale()) }
    val source = remember(captureId, subjectRef) {
        CaptureSource.CaptureId(id = captureId, subjectRef = subjectRef)
    }
    val session = remember(source, retryKey) { TwinSkinSdk.viewCapture(source) }
    DisposableEffect(session) { onDispose { session.close() } }

    val state by session.state.collectAsState()

    when (val current = state) {
        is ViewCaptureState.Error -> Box(modifier = Modifier.fillMaxSize()) {
            // ViewCaptureErrorView owns only Retry; add a Close so a
            // non-retryable error doesn't strand the caller awaiting a result.
            ViewCaptureErrorView(
                error = current.error,
                onRetry = { retryKey++ },
            )
            IconButton(
                onClick = { onResult(EditAnnotationResult.Cancelled) },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .statusBarsPadding()
                    .padding(8.dp),
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = strings.viewerCloseContentDescription,
                    tint = Color.White,
                )
            }
        }

        is ViewCaptureState.Ready -> {
            val image2D = current.image2D
            if (image2D == null) {
                EditAnnotationLoading(onClose = { onResult(EditAnnotationResult.Cancelled) })
            } else {
                // Freeze the seed at the first usable Ready. The session
                // keeps streaming; a server-side annotation update
                // mid-edit (another device submits, pipeline writes an
                // auto-contour) would otherwise re-key the editor's
                // store and silently wipe the clinician's in-progress,
                // unsubmitted work.
                val seed = remember(session) {
                    EditAnnotationSeed(
                        imageLocation = image2D.location,
                        annotation = current.annotation,
                        conditionType = current.conditionType,
                    )
                }
                AnnotationEditorForCapture(
                    imageLocation = seed.imageLocation,
                    existing = seed.annotation,
                    conditionType = seed.conditionType,
                    onDone = { annotation ->
                        val response = TwinSkinSdk.requireComponent().serverClient
                            .submitAnnotation(
                                captureId = captureId,
                                subjectRef = subjectRef,
                                annotation = annotation,
                            )
                        onResult(EditAnnotationResult.Submitted(response.revision))
                    },
                    onCancel = { onResult(EditAnnotationResult.Cancelled) },
                    onImageUnavailable = { onResult(EditAnnotationResult.Cancelled) },
                )
            }
        }

        else -> EditAnnotationLoading(onClose = { onResult(EditAnnotationResult.Cancelled) })
    }
}

/** Editor inputs captured at the first usable Ready — see the freeze note above. */
private data class EditAnnotationSeed(
    val imageLocation: String,
    val annotation: com.twinskin.sdk.capture.SdkAnnotation?,
    val conditionType: com.twinskin.sdk.capture.ConditionType?,
)

@Composable
private fun EditAnnotationLoading(onClose: () -> Unit) {
    val strings = remember { captureStringsFor(sdkLocale()) }
    Box(
        modifier = Modifier.fillMaxSize().background(TwinSkinColors.Surface),
        contentAlignment = Alignment.Center,
    ) {
        CircularProgressIndicator(color = TwinSkinColors.Cyan)
        // A Close so a hung sync isn't a dead end.
        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(8.dp),
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = strings.viewerCloseContentDescription,
                tint = TwinSkinColors.Ink,
            )
        }
    }
}
