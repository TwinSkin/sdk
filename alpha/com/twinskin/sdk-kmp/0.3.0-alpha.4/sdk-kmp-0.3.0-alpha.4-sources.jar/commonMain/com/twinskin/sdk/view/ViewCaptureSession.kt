@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.view

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.error
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext
import kotlin.time.Duration.Companion.seconds
import kotlin.time.TimeMark
import kotlin.time.TimeSource

/**
 * Public handle returned by [com.twinskin.sdk.TwinSkinSdk.viewCapture].
 *
 * Subscribes to a [CaptureResolver] and translates its event stream into the
 * [ViewCaptureState] that the Compose screen observes. Safe to close multiple
 * times; safe to ignore if the screen observes [state] directly.
 *
 * The constructor is public so advanced integrators (and test/demo code) can
 * wrap their own [CaptureResolver] implementations. The ordinary path is
 * [com.twinskin.sdk.TwinSkinSdk.viewCapture] — use this constructor only when
 * you want to bypass source-to-resolver mapping.
 */
public class ViewCaptureSession(
    private val resolver: CaptureResolver,
    context: CoroutineContext = Dispatchers.Default,
    private val logger: SdkLogger? = null,
) {
    private val scope = CoroutineScope(context + SupervisorJob())

    private val _state = MutableStateFlow<ViewCaptureState>(
        ViewCaptureState.Loading(LoadProgress.Indeterminate)
    )
    public val state: StateFlow<ViewCaptureState> = _state.asStateFlow()

    /**
     * Optimistic annotation pin (M15.15). When the host calls
     * [applyOptimisticAnnotation] after a confirmed `submitAnnotation`,
     * we stash the new value here and use it to override any subsequent
     * resolver emission whose annotation doesn't match — that's the
     * stale PowerSync row landing between submit-acked and server-row-
     * synced, which would otherwise flicker the 2D pane through
     * (NEW → OLD → NEW).
     *
     * Released when a resolver emission carries an annotation
     * structurally equal to the pinned value (server has caught up),
     * OR after [PENDING_OPTIMISTIC_TIMEOUT] (defensive — protects
     * against the pinned value never matching due to server-side
     * normalization differences we didn't anticipate).
     *
     * Single-threaded: all reads/writes happen from the resolver's
     * collect coroutine (on [scope]) or the public setter; the public
     * setter is documented as main-thread-only via the public API
     * KDoc, matching how every other Compose-facing handle is used.
     */
    private var pendingOptimisticAnnotation: SdkAnnotation? = null
    private var pendingOptimisticAt: TimeMark? = null

    /**
     * Measurement-staleness signal for the 2D pane. Drives the
     * "Calculating…" placeholder that hides stale measurement values
     * during the post-submit window.
     *
     * Derived from two sources:
     *  - The optimistic pin (sub-second flicker shield between
     *    `submitAnnotation` returning and PowerSync delivering the
     *    updated `sdk_captures` row).
     *  - `Ready.isMeasurementCalculating` (the SQL-derived row signal
     *    on every emission — survives screen unmount and process kill
     *    because it's sourced from synced state, not session memory).
     */
    public val isMeasurementStale: StateFlow<Boolean> =
        @Suppress("LeakingThis")
        state.map { st ->
            val pinActive = pendingOptimisticAnnotation != null &&
                (pendingOptimisticAt?.elapsedNow()?.let { it < PENDING_OPTIMISTIC_TIMEOUT } ?: false)
            pinActive ||
                (st as? ViewCaptureState.Ready)?.isMeasurementCalculating == true
        }.stateIn(scope, SharingStarted.Eagerly, false)

    private val job: Job = scope.launch {
        var hasResolvedOnce = false
        resolver.resolve()
            .catch { cause ->
                val error = classify(cause)
                logger?.error("viewCapture flow failed → $error", cause)
                _state.value = ViewCaptureState.Error(error)
            }
            .onCompletion {
                // A reactive resolver keeps streaming; a one-shot resolver
                // completes once the terminal Resolved has been emitted. Either
                // way, clear the isStreaming flag on completion.
                val current = _state.value
                if (current is ViewCaptureState.Ready && current.isStreaming) {
                    _state.value = current.copy(isStreaming = false)
                }
            }
            .collect { event ->
                when (event) {
                    is ResolverEvent.Progress -> {
                        if (!hasResolvedOnce) {
                            _state.value = ViewCaptureState.Loading(event.progress)
                        }
                    }
                    is ResolverEvent.Resolved -> {
                        val capture = event.capture
                        val effectiveAnnotation = honourOptimisticPin(capture.annotation)
                        // Ready needs at least one renderable surface.
                        // Until then, we're still resolving metadata.
                        _state.value = if (capture.model == null && capture.image2D == null) {
                            ViewCaptureState.Loading(LoadProgress.ResolvingMetadata)
                        } else {
                            ViewCaptureState.Ready(
                                asset = capture.model,
                                image2D = capture.image2D,
                                annotation = effectiveAnnotation,
                                measurement = capture.measurement,
                                summary = capture.summary,
                                isStreaming = !hasResolvedOnce, // reset later on completion
                                isMeasurementCalculating = capture.isMeasurementCalculating,
                                conditionType = capture.conditionType,
                            )
                        }
                        hasResolvedOnce = true
                    }
                }
            }
    }

    /**
     * Filters the [incoming] annotation through the optimistic-pin
     * gate (M15.15). When the pin is active and unexpired, an
     * incoming value that doesn't match the pin is suppressed (we
     * keep returning the pinned value); a match — or pin expiry —
     * releases the pin and the incoming value flows through normally.
     */
    private fun honourOptimisticPin(incoming: SdkAnnotation?): SdkAnnotation? {
        val pinned = pendingOptimisticAnnotation ?: return incoming
        val expired = pendingOptimisticAt?.elapsedNow()?.let { it >= PENDING_OPTIMISTIC_TIMEOUT }
            ?: true
        return if (expired || incoming == pinned) {
            pendingOptimisticAnnotation = null
            pendingOptimisticAt = null
            incoming
        } else {
            pinned
        }
    }

    /**
     * Replaces the annotation on the current [ViewCaptureState.Ready]
     * with [annotation], leaving every other field untouched (image,
     * 3D model, measurement, metadata, isStreaming). No-op when the
     * state isn't Ready (still loading / errored) — the next
     * [ResolverEvent.Resolved] from the underlying resolver will
     * naturally include the freshest annotation it sees.
     *
     * **M15.11 — optimistic refresh.** Called by the View Capture
     * host immediately after a successful `submitAnnotation` so the
     * 2D pane re-renders without waiting for PowerSync to round-trip
     * the new value back down from the server.
     *
     * **M15.15 — pin to suppress stale re-emissions.** Sets an
     * internal pin so resolver emissions carrying the *stale* OLD
     * value (the PowerSync row before the server's write propagated)
     * don't flicker the 2D pane through NEW → OLD → NEW. The pin
     * releases when an incoming emission's annotation structurally
     * equals [annotation] (server caught up) or after
     * [PENDING_OPTIMISTIC_TIMEOUT] (defensive against any server-side
     * normalization preventing exact equality).
     */
    public fun applyOptimisticAnnotation(annotation: SdkAnnotation) {
        val current = _state.value
        if (current is ViewCaptureState.Ready) {
            pendingOptimisticAnnotation = annotation
            pendingOptimisticAt = TimeSource.Monotonic.markNow()
            _state.value = current.copy(annotation = annotation)
        }
    }

    public fun close() {
        scope.cancel()
    }

    private companion object {
        /**
         * Upper bound on how long the optimistic pin can survive
         * without a matching resolver emission. 10 s comfortably
         * spans a healthy PowerSync round-trip while keeping the
         * fail-open window tight enough that a genuine server-side
         * value mismatch (the pinned value never appears upstream)
         * still surfaces within a few seconds.
         */
        val PENDING_OPTIMISTIC_TIMEOUT = 10.seconds
    }
}

private fun classify(cause: Throwable): ViewCaptureError = when (cause) {
    is kotlinx.coroutines.CancellationException -> throw cause
    is CaptureCredentialsException -> ViewCaptureError.Credentials(cause.cause ?: cause)
    is CaptureNetworkException -> ViewCaptureError.Network
    is CaptureNotFoundException -> ViewCaptureError.NotFound
    is CaptureInvalidAssetException -> ViewCaptureError.InvalidAsset(cause.reason)
    else -> if (looksLikeNetworkException(cause)) ViewCaptureError.Network
            else ViewCaptureError.Unknown(cause)
}

/**
 * Best-effort classification of raw network / IO failures thrown from inside
 * resolvers (timeouts, DNS failures, connection refused, dropped connections).
 *
 * Done by fully-qualified name rather than `is IOException` because the
 * relevant exception hierarchy differs per platform (Android: `java.io.IOException`
 * and sub-classes; iOS: ktor-darwin wraps `NSError` into its own type) and we
 * don't want to pull platform-specific types into commonMain or duplicate the
 * classifier per actual. Keeps working across ktor version bumps because it
 * only matches on stable public package prefixes.
 */
private fun looksLikeNetworkException(cause: Throwable): Boolean {
    var current: Throwable? = cause
    while (current != null) {
        val name = current::class.qualifiedName ?: current::class.simpleName ?: ""
        when {
            name.endsWith("IOException") -> return true
            name.endsWith("UnknownHostException") -> return true
            name.endsWith("SocketException") -> return true
            name.endsWith("SocketTimeoutException") -> return true
            name.endsWith("ConnectTimeoutException") -> return true
            name.endsWith("HttpRequestTimeoutException") -> return true
            name.endsWith("DarwinHttpRequestException") -> return true
        }
        current = current.cause
    }
    return false
}
