@file:OptIn(ExperimentalAtomicApi::class)

package com.twinskin.sdk.ui.fallback

import com.twinskin.sdk.capture.SdkReferenceLuminance
import com.twinskin.sdk.capture.fallback.AccelerometerDriver
import com.twinskin.sdk.capture.fallback.Pie
import com.twinskin.sdk.capture.fallback.VideoCaptureResult
import com.twinskin.sdk.capture.fallback.VideoMetaData
import com.twinskin.sdk.capture.fallback.VideoRecorder
import com.twinskin.sdk.transfer.currentTimeMillis
import kotlin.concurrent.atomics.AtomicBoolean
import kotlin.concurrent.atomics.ExperimentalAtomicApi
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

public class AccelerometerCaptureController(
    private val scope: CoroutineScope,
    private val recorder: VideoRecorder,
    private val driver: AccelerometerDriver,
    private val takeStillPhoto: suspend () -> String,
    private val videoOutputPath: () -> String,
    private val onResult: suspend (VideoCaptureResult) -> Unit,
    private val onError: (String) -> Unit = {},
    // Defaults to the no-false-positive verdict so a host that hasn't wired
    // metering renders today's flow unchanged and stamps no fabricated luminance.
    private val lowLightProbe: suspend (stillPath: String) -> LowLightProbeResult =
        { LowLightProbeResult.NotLowLight },
    // Defaults to "detected, no version" so a host that hasn't wired detection
    // never raises a false warning and never stamps an unverified version.
    private val markerProbe: suspend (stillPath: String) -> MarkerProbeResult =
        { MarkerProbeResult.Detected },
    private val captureDurationMs: Long = VIDEO_CAPTURE_DURATION_MS,
    private val timerTickMs: Long = VIDEO_CAPTURE_TIMER_TICK_MS,
    private val clock: () -> Long = ::currentTimeMillis,
    // `recorder.stop()` MUST NOT block the UI thread — CameraX's
    // follow-up `provider.unbindAll()` is posted to the main executor.
    private val stopDispatcher: CoroutineDispatcher = Dispatchers.Default,
) {
    private val _state =
        MutableStateFlow<AccelerometerCaptureScreenState>(AccelerometerCaptureScreenState.Initializing)
    public val state: StateFlow<AccelerometerCaptureScreenState> = _state.asStateFlow()

    private var pieJob: Job? = null
    private var guidanceJob: Job? = null
    private var timerJob: Job? = null
    private var stillPath: String? = null
    // Cleared on retake so a re-shot still re-probes.
    private var markerVersion: String? = null
    // Cleared on retake so a re-shot still re-probes.
    private var referenceLuminance: SdkReferenceLuminance? = null
    private var driverStarted: Boolean = false
    private val takingPhoto = AtomicBoolean(false)

    /** Wait is unbounded: never flip to ReadyForPhoto on a still-cold camera (#541-4). */
    public suspend fun markCameraReady() {
        if (_state.value !== AccelerometerCaptureScreenState.Initializing) return
        try {
            recorder.prepare()
        } catch (_: Throwable) {
            // Preview failure shouldn't gate the flow — wait on
            // cameraReady; the recorder will retry binding inside
            // start() when the shutter is tapped.
        }
        recorder.cameraReady.first { it }
        if (_state.value === AccelerometerCaptureScreenState.Initializing) {
            _state.value = AccelerometerCaptureScreenState.ReadyForPhoto
        }
    }

    public fun takePhoto() {
        if (_state.value !is AccelerometerCaptureScreenState.ReadyForPhoto) return
        // Atomic single-shot: a double-tap is dropped by the second
        // compareAndSet, so only one takeStillPhoto coroutine ever flies.
        if (!takingPhoto.compareAndSet(expectedValue = false, newValue = true)) return
        scope.launch {
            try {
                val path = takeStillPhoto()
                stillPath = path
                // Non-blocking: a probe throw falls back to the no-warning
                // verdict so it never traps the operator.
                val lowLight = try { lowLightProbe(path) } catch (_: Throwable) {
                    LowLightProbeResult.NotLowLight
                }
                val marker = try { markerProbe(path) } catch (_: Throwable) { MarkerProbeResult.Detected }
                markerVersion = marker.version
                referenceLuminance = lowLight.referenceLuminance
                _state.value = AccelerometerCaptureScreenState.PhotoTaken(
                    stillPath = path,
                    lowLight = lowLight.lowLight,
                    markerDetected = marker.detected,
                )
            } catch (t: Throwable) {
                failWith(t.message ?: "still capture failed")
            } finally {
                takingPhoto.store(false)
            }
        }
    }

    /**
     * Discard the still and return to [AccelerometerCaptureScreenState.ReadyForPhoto].
     * No-op outside [AccelerometerCaptureScreenState.PhotoTaken]; the
     * driver/recorder haven't started yet at this phase, so there is nothing to
     * tear down.
     */
    public fun retakePhoto() {
        if (_state.value !is AccelerometerCaptureScreenState.PhotoTaken) return
        stillPath = null
        markerVersion = null
        referenceLuminance = null
        _state.value = AccelerometerCaptureScreenState.ReadyForPhoto
    }

    public fun startRecording() {
        val photoState = _state.value as? AccelerometerCaptureScreenState.PhotoTaken ?: return
        val pieFlow: StateFlow<Pie>
        try {
            // Driver-side throws must route through failWith so the
            // recorder gets torn down — otherwise the state machine
            // sticks at PhotoTaken with no rollback on the next cancel.
            pieFlow = driver.start()
            driverStarted = true
            recorder.start(videoOutputPath())
        } catch (t: Throwable) {
            failWith(t.message ?: "video recorder failed to start")
            return
        }
        _state.value = AccelerometerCaptureScreenState.RecordingVideo(
            elapsedMs = 0L,
            pie = pieFlow.value,
        )
        pieJob = scope.launch {
            pieFlow.collect { pie -> mergePie(pie) }
        }
        // Presentation-only guidance — merged into the RecordingVideo state,
        // NEVER into the recorded bundle.
        guidanceJob = scope.launch {
            driver.guidance.collect { snapshot -> mergeGuidance(snapshot) }
        }
        timerJob = scope.launch {
            val startMs = clock()
            while (true) {
                delay(timerTickMs)
                val elapsed = clock() - startMs
                val current = _state.value as? AccelerometerCaptureScreenState.RecordingVideo
                    ?: return@launch
                if (elapsed >= captureDurationMs) {
                    _state.value = current.copy(elapsedMs = captureDurationMs)
                    finishRecording()
                    return@launch
                }
                _state.value = current.copy(elapsedMs = elapsed)
            }
        }
        stillPath = photoState.stillPath
    }

    public fun requestStop() {
        if (_state.value !is AccelerometerCaptureScreenState.RecordingVideo) return
        scope.launch { finishRecording() }
    }

    public fun cancel() {
        pieJob?.cancel(); pieJob = null
        guidanceJob?.cancel(); guidanceJob = null
        timerJob?.cancel(); timerJob = null
        try { recorder.cancel() } catch (_: Throwable) {}
        if (driverStarted) {
            try { driver.stop() } catch (_: Throwable) {}
            driverStarted = false
        }
    }

    private suspend fun finishRecording() {
        pieJob?.cancel(); pieJob = null
        guidanceJob?.cancel(); guidanceJob = null
        timerJob?.cancel(); timerJob = null
        // NonCancellable wraps the whole body: the timer-auto-stop path
        // cancels `timerJob` (itself) before this runs, so any suspend
        // call below — `recorder.stop()`, `onResult(...)` — would
        // otherwise throw CancellationException and surface to the
        // operator as "StandaloneCoroutine was cancelled" (#538).
        // The `recorder.stop()` block additionally hops to
        // Dispatchers.Default so the Android recorder's synchronous
        // latch wait does not pin the UI thread (CameraX schedules its
        // `provider.unbindAll()` follow-up on the main executor — that
        // post can only run if main is free).
        withContext(NonCancellable) {
            val videoPath: String
            val metadata: VideoMetaData
            try {
                videoPath = withContext(stopDispatcher) { recorder.stop() }
                metadata = driver.stop()
                driverStarted = false
            } catch (t: Throwable) {
                failWith(t.message ?: "recorder stop failed")
                return@withContext
            }
            _state.value = AccelerometerCaptureScreenState.Submitting(progressPercent = null)
            val still = stillPath ?: run {
                failWith("still photo missing on submit")
                return@withContext
            }
            try {
                onResult(VideoCaptureResult(
                    photoPath = still,
                    videoPath = videoPath,
                    videoMetadata = metadata,
                    markerVersion = markerVersion,
                    referenceLuminance = referenceLuminance,
                ))
            } catch (t: Throwable) {
                failWith(t.message ?: "submit failed")
            }
        }
    }

    public fun setSubmitProgress(progressPercent: Int?) {
        val current = _state.value as? AccelerometerCaptureScreenState.Submitting ?: return
        _state.value = current.copy(progressPercent = progressPercent)
    }

    private fun failWith(message: String) {
        pieJob?.cancel(); pieJob = null
        guidanceJob?.cancel(); guidanceJob = null
        timerJob?.cancel(); timerJob = null
        // recorder.cancel() is contractually no-op-safe in every state.
        try { recorder.cancel() } catch (_: Throwable) {}
        if (driverStarted) {
            try { driver.stop() } catch (_: Throwable) {}
            driverStarted = false
        }
        _state.value = AccelerometerCaptureScreenState.Error(message = message)
        onError(message)
    }

    private fun mergePie(pie: Pie) {
        val current = _state.value as? AccelerometerCaptureScreenState.RecordingVideo ?: return
        _state.value = current.copy(pie = pie)
    }

    private fun mergeGuidance(snapshot: GuidanceSnapshot) {
        val current = _state.value as? AccelerometerCaptureScreenState.RecordingVideo ?: return
        _state.value = current.copy(guidance = snapshot)
    }
}

