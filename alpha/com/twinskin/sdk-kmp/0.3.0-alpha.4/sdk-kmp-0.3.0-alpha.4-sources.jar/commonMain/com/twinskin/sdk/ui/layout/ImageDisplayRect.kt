package com.twinskin.sdk.ui.layout

/**
 * Geometry of a fit-and-center placement: given an image of pixel size
 * ([imageWidth] × [imageHeight]) rendered with `ContentScale.Fit` inside a
 * box of size ([boxWidth] × [boxHeight]), returns the rectangle of the box
 * that the image actually covers — ([offsetX], [offsetY]) being the
 * top-left of the displayed image inside the box, and ([displayWidth],
 * [displayHeight]) the image's drawn dimensions.
 *
 * Engineering invariant E13 (M15.9). Any contour overlay that consumes
 * normalized `WoundAnnotation` coordinates and sits on top of an
 * `Image(contentScale = ContentScale.Fit)` MUST align those coordinates
 * to the image's displayed rectangle (this struct), never to the host
 * `Canvas` / `Box`. Otherwise the overlay stretches across any
 * letterboxing the fit-and-center produced, drifting visibly out of the
 * image rectangle whenever image and box aspect ratios disagree.
 */
internal data class ImageDisplayRect(
    val offsetX: Float,
    val offsetY: Float,
    val displayWidth: Float,
    val displayHeight: Float,
)

internal fun imageRectInBox(
    imageWidth: Int,
    imageHeight: Int,
    boxWidth: Float,
    boxHeight: Float,
): ImageDisplayRect {
    if (imageWidth <= 0 || imageHeight <= 0 || boxWidth <= 0f || boxHeight <= 0f) {
        return ImageDisplayRect(0f, 0f, boxWidth.coerceAtLeast(0f), boxHeight.coerceAtLeast(0f))
    }
    val imageAspect = imageWidth.toFloat() / imageHeight.toFloat()
    val boxAspect = boxWidth / boxHeight
    return if (imageAspect > boxAspect) {
        val displayWidth = boxWidth
        val displayHeight = boxWidth / imageAspect
        ImageDisplayRect(
            offsetX = 0f,
            offsetY = (boxHeight - displayHeight) / 2f,
            displayWidth = displayWidth,
            displayHeight = displayHeight,
        )
    } else {
        val displayWidth = boxHeight * imageAspect
        val displayHeight = boxHeight
        ImageDisplayRect(
            offsetX = (boxWidth - displayWidth) / 2f,
            offsetY = 0f,
            displayWidth = displayWidth,
            displayHeight = displayHeight,
        )
    }
}
