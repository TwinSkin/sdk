package com.twinskin.sdk.capture

import com.twinskin.sdk.TwinSkinInternalApi
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.Json

/**
 * iOS-bridge helper: parse a JSON string into a [JsonElement].
 *
 * Swift consumers of `SdkCaptureMetadata.custom` need to construct
 * `Map<String, JsonElement>` values, but Kotlin/Native does not export
 * the `kotlinx.serialization.json.Json` singleton's `Default.shared`
 * unless something public references it. Exposing this top-level
 * function pins both `Json` and `JsonElement` into the framework's
 * Obj-C bridge, while keeping the rest of the SDK's serialization
 * plumbing internal.
 *
 * Marked `@TwinSkinInternalApi` because it is a bridging artifact, not
 * a stable integrator surface — Swift callers reach it through the
 * curated `CaptureMetadata.kotlin` accessor.
 */
@TwinSkinInternalApi
public fun parseJsonElement(json: String): JsonElement = Json.parseToJsonElement(json)
