package com.twinskin.sdk.ui.annotation_editor.polygon.engine

import androidx.compose.ui.geometry.Offset
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Continuous-drag reshape of a closed polygon (spec §6.3.3).
 *
 * Vertices within [influenceCanvasPx] of the **anchor** vertex are
 * displaced by `Δ = fingerImagePx − polygon[anchorIdx]`, scaled by a
 * raised-cosine weight that goes smoothly to zero at both endpoints
 * of the influence radius:
 *
 * ```
 * t  = (canvas-distance / influenceCanvasPx) ∈ [0, 1]
 * w  = 0.5 * (1 + cos(π * t))     ← raised cosine
 * wp = w ^ cosinePower             ← shape control (1.0 in v1)
 * ```
 *
 * Distances are converted to canvas-pixel space via
 * [canvasFromImageScale] so the influence radius feels the same at
 * any zoom level (spec §6.3.3 — "Influence radius: fixed at 40
 * canvas-px in v1, zoom-independent").
 *
 * Plan footnote: a raised cosine (zero derivative at both rim AND
 * centre) replaces the spec's quarter-cycle `cos(π/2 * t)` to
 * eliminate the visible kink at the rim. The visible difference is
 * a smoother blend; clinical accuracy is unchanged.
 */
internal fun applyReshape(
    polygon: List<Offset>,
    fingerImagePx: Offset,
    anchorIdx: Int,
    influenceCanvasPx: Float,
    canvasFromImageScale: Float,
    cosinePower: Float = 1f,
): List<Offset> {
    require(anchorIdx in polygon.indices) {
        "anchorIdx $anchorIdx out of bounds for polygon size ${polygon.size}"
    }
    require(influenceCanvasPx > 0f) {
        "influenceCanvasPx must be positive (got $influenceCanvasPx)"
    }
    require(canvasFromImageScale > 0f) {
        "canvasFromImageScale must be positive (got $canvasFromImageScale)"
    }

    val anchor = polygon[anchorIdx]
    val deltaX = fingerImagePx.x - anchor.x
    val deltaY = fingerImagePx.y - anchor.y

    val out = ArrayList<Offset>(polygon.size)
    for (v in polygon) {
        val dxImage = v.x - anchor.x
        val dyImage = v.y - anchor.y
        val canvasDist = sqrt(dxImage * dxImage + dyImage * dyImage) * canvasFromImageScale
        if (canvasDist >= influenceCanvasPx) {
            out += v
            continue
        }
        val t = canvasDist / influenceCanvasPx
        val w = 0.5f * (1f + cos((PI * t).toFloat()))
        val wp = if (cosinePower == 1f) w else w.pow(cosinePower)
        out += Offset(v.x + deltaX * wp, v.y + deltaY * wp)
    }
    return out
}

/**
 * Weighted Laplacian smoothing pass over the anchor's neighbourhood
 * (spec §6.3.3 — natural-curve feel). Each vertex within
 * `windowSize` indices of [anchorIdx] (treated circularly) is
 * lerped toward the midpoint of its neighbours, weighted by a
 * raised cosine of its distance-from-anchor along the index axis.
 *
 * Two iterations × 0.45 strength matches the Flutter `_relaxWindow`
 * reference and produces the right perceived smoothness without
 * collapsing the polygon's overall shape. Mutates [polygon] in place.
 *
 * Called once per pointer-move after [applyReshape], before
 * non-traversal clamping.
 */
internal fun relaxNeighbourhood(
    polygon: MutableList<Offset>,
    anchorIdx: Int,
    windowSize: Int,
    iterations: Int = 2,
    strength: Float = 0.45f,
) {
    require(anchorIdx in polygon.indices) {
        "anchorIdx $anchorIdx out of bounds for polygon size ${polygon.size}"
    }
    if (polygon.size < 3 || windowSize < 1) return
    val n = polygon.size
    // When the window covers more than half the polygon the modulo
    // collapse hits each index multiple times per iteration, which —
    // because the read snapshot is taken once per iteration — silently
    // reduces N iterations to a single effective pass. Clamp so each
    // unique index is visited at most once per iteration.
    val effectiveWindow = if (n <= 2 * windowSize) (n - 1) / 2 else windowSize
    if (effectiveWindow < 1) return

    repeat(iterations) {
        val snapshot = polygon.toList()
        for (offset in -effectiveWindow..effectiveWindow) {
            val i = ((anchorIdx + offset) % n + n) % n
            val prevI = (i - 1 + n) % n
            val nextI = (i + 1) % n
            val midX = 0.5f * (snapshot[prevI].x + snapshot[nextI].x)
            val midY = 0.5f * (snapshot[prevI].y + snapshot[nextI].y)
            val distFromAnchor = kotlin.math.abs(offset).toFloat()
            val w = 0.5f * (1f + cos((PI * distFromAnchor / effectiveWindow).toFloat()))
            val lerpT = strength * w
            polygon[i] = Offset(
                snapshot[i].x + (midX - snapshot[i].x) * lerpT,
                snapshot[i].y + (midY - snapshot[i].y) * lerpT,
            )
        }
    }
}
