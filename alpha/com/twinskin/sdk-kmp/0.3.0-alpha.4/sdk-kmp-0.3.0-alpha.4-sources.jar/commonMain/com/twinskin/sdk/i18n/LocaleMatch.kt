package com.twinskin.sdk.i18n

/**
 * Resolves [locale] to a shipped value via [select], applying the SDK's locale
 * fallback ladder: the exact tag (lowercased, `_` normalised to `-`), then the
 * primary language subtag, then [fallback].
 *
 * So `"fr-FR"` resolves to the `"fr"` table, `"pt-BR"` to the `"pt-br"` table
 * when that variant ships (else `"pt"`), and any tag the SDK doesn't ship to
 * [fallback] — English, the one guaranteed-complete table.
 *
 * [select] returns `null` for a tag it doesn't handle. The generated
 * `*StringsFor` dispatch and the hand-written delineation resolver both route
 * through here so region handling can't drift between areas.
 */
internal fun <T : Any> resolveLocale(
    locale: String,
    fallback: T,
    select: (String) -> T?,
): T {
    val tag = locale.lowercase().replace('_', '-')
    return select(tag) ?: select(tag.substringBefore('-')) ?: fallback
}
