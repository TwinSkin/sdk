package com.twinskin.sdk.transfer

internal enum class TransferType {
    UPLOAD,
    DOWNLOAD,
}

internal enum class TransferStatus {
    PENDING,
    ACTIVE,
    UNZIPPING,
    COMPLETED,
    FAILED,
    CANCELLED,
}

internal sealed class TransferUpdate {
    data class Progress(val percent: Int) : TransferUpdate()
    object Success : TransferUpdate()
    data class Failure(val error: String) : TransferUpdate()
}

/**
 * Result of asking the [UrlResolver] for a presigned upload URL.
 *
 * - [Url]: a valid URL was obtained — proceed with the HTTP PUT.
 * - [RetryableError]: no URL is available right now (e.g. no network, server busy).
 *   The SDK will retry later and, on iOS, schedule a BGProcessingTask so it can
 *   retry even after the app is suspended.
 * - [AlreadyExist]: the server already has this file. The upload is considered
 *   successful and the task transitions to COMPLETED immediately.
 */
internal sealed class UrlResult {
    data class Url(val url: String, val expiresAtEpochMs: Long?) : UrlResult()
    object RetryableError : UrlResult()
    object AlreadyExist : UrlResult()
}

/**
 * Callback injected into [TransferManager] to resolve a presigned S3 upload URL
 * from a stable [uploadKey]. Called on each upload attempt (including retries).
 */
internal typealias UrlResolver = suspend (uploadKey: String) -> UrlResult
