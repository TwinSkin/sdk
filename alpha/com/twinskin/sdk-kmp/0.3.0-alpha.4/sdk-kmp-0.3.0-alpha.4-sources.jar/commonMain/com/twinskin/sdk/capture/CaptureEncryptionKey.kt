// GENERATED FROM packages/sdk/encryption_keys/public.pem — DO NOT EDIT.
package com.twinskin.sdk.capture

import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

/**
 * Bundled capture encryption public key. Every SDK build encrypts capture
 * bundles to this single key — the integrator cannot override it. The
 * matching private key is committed at
 * `packages/sdk/encryption_keys/private.pem` and is the default used by
 * the Dart server when `SDK_DECRYPT_PRIVATE_KEYS` is unset.
 */
@OptIn(ExperimentalEncodingApi::class)
internal fun captureEncryptionPublicKeyDer(): ByteArray = Base64.decode(
    "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjVZVXCb/VFg6qFqQAyAsmF6d+DMKtzOIflJMAENbPVHvNxpCaC7KlW+nodY8dFfYnRwHdwOzPS7uQ/WnBJJFqSqkcLeoAYIDMgUDRr6vaDebICXlHxJaFauGLUn1cSCG7RQUzE6NI3iTe3NJjcyzcJXBiPp00g19cc3WdzYEA3VAB7K73xW+Zi40Jxfq1OSYjMHUbDujx5HYBfJE0cqA1R7OqF5P8d7JJPLyGFOJYTEm+DEkJFNIcmWBj4qUadPFs0WymBcEWwRJ7lHfdV98hB3KznpX1HW69cMxTsWeernGRG7j+ctn3ZSke1Djl5fZq2ikkSQ+B9jLleCI5D2mCwIDAQAB"
)
