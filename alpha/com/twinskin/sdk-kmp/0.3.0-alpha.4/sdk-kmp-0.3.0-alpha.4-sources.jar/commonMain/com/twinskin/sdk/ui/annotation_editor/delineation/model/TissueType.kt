package com.twinskin.sdk.ui.annotation_editor.delineation.model

/**
 * Internal type for the tissue palette.
 *
 * The editor exposes three clinical types via the dashboard cards
 * (necrosis, slough, granulation). Decision C in the plan also
 * requires that **unknown** wire strings round-trip unchanged through
 * the editor — see `ToWoundAnnotationTest`'s `Other("fibrinous")`
 * round-trip case for the boundary-level proof.
 *
 * The plan §M2 shows `TissueType` as a Kotlin `enum`, but an enum
 * can't carry arbitrary unknown wire strings. This sealed-class
 * representation keeps the type-safe API (`Necrosis`, `Slough`,
 * `Granulation` are singletons the UI matches against) while letting
 * unknown wire values survive as [Other] until M9 emits them again.
 *
 * `cardStates`, percentage rows, clinical colors, and i18n names only
 * apply to the three known values — see [knownValues]. The store
 * rejects [Other] as a card-state key.
 */
internal sealed class TissueType {
    abstract val wire: String

    data object Necrosis : TissueType() { override val wire: String = "necrosis" }
    data object Slough : TissueType() { override val wire: String = "slough" }
    data object Granulation : TissueType() { override val wire: String = "granulation" }

    /** Wire-only round-trip carrier — never reaches the dashboard. */
    data class Other(override val wire: String) : TissueType()

    companion object {
        /**
         * The three clinical types the dashboard / palette UI knows
         * about.
         *
         * `by lazy` (rather than an eager initializer) is load-bearing.
         * Sealed-class `data object` subclasses are independent JVM
         * classes whose `INSTANCE` static fields initialize on first
         * touch; an eager `listOf(Necrosis, Slough, Granulation)` in
         * the companion's `<clinit>` can resolve subclass references
         * to `null` if that subclass's class-init order is racy on the
         * test runner's classpath. Deferring resolution to first
         * access guarantees every subclass is loaded by then.
         */
        val knownValues: List<TissueType> by lazy { listOf(Necrosis, Slough, Granulation) }

        /**
         * Parses a wire string. Trims + matches case-insensitively
         * against the known values; falls back to [Other] so the raw
         * string survives the editor for round-trip emission.
         */
        fun fromWire(s: String): TissueType {
            val trimmed = s.trim()
            return knownValues.firstOrNull { it.wire.equals(trimmed, ignoreCase = true) }
                ?: Other(trimmed)
        }
    }
}
