package com.twinskin.sdk.capture.crypto

/** Platform-provided cryptographic primitives used by the capture bundle pipeline. */

/** Fills [out] with cryptographically secure random bytes. */
internal expect fun secureRandomBytes(out: ByteArray)

/**
 * RSA-OAEP with SHA-256 (MGF1-SHA-256) encrypt.
 *
 * [publicKeyDer] is the SubjectPublicKeyInfo DER encoding (X.509 — what a PEM block
 * labelled `PUBLIC KEY` decodes to).
 */
internal expect fun rsaOaepSha256Encrypt(publicKeyDer: ByteArray, plaintext: ByteArray): ByteArray

/** SHA-256 digest of [input]. Returns 32 raw bytes. */
internal expect fun sha256(input: ByteArray): ByteArray
