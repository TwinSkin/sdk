@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.renderer

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.twinskin.sdk.view.Asset3D

/**
 * Platform-native surface rendering a 3D [asset]. Android uses SceneView
 * (Filament + gltfio); iOS delegates to a Swift-side renderer registered on
 * [Ios3DRenderer] (the `sdk-ios` package wires GLTFKit2 + SceneKit by default).
 *
 * Callers depend only on this signature; replacing the renderer does not
 * affect the [com.twinskin.sdk.view.ViewCaptureSession] or the Compose screen.
 */
@Composable
public expect fun Model3DViewer(
    asset: Asset3D,
    modifier: Modifier,
)
