package com.twinskin.sdk.ui.annotation_editor.delineation.flow

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Tissue
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound
import com.twinskin.sdk.ui.annotation_editor.polygon.canvas.clinicalColorFor
import com.twinskin.sdk.ui.theme.TwinSkinColors

/**
 * The store's wounds with every [type] tissue replaced by [outlines]
 * (the drawing controller's in-flight polygons), each assigned to
 * its parent wound the same way the Back-commit does
 * ([resolveParentWoundIdx]). Feeds the live composition bar with the
 * exact wound set the eventual commit will produce, so the on-canvas
 * percentages can't disagree with the dashboard afterwards.
 */
internal fun woundsWithTypeReplaced(
    wounds: List<Wound>,
    type: TissueType,
    outlines: List<List<Offset>>,
): List<Wound> {
    val assignments: List<Pair<Int, Tissue>> = outlines.mapNotNull { outline ->
        if (outline.size < 3) return@mapNotNull null
        val parentIdx = resolveParentWoundIdx(outline, wounds)
        if (parentIdx < 0) null else parentIdx to Tissue(type, outline)
    }
    val grouped: Map<Int, List<Tissue>> = assignments.groupBy({ it.first }, { it.second })
    return wounds.mapIndexed { i, wound ->
        Wound(
            outline = wound.outline,
            tissues = wound.tissues.filter { it.type != type } + grouped[i].orEmpty(),
        )
    }
}

/**
 * Slim stacked composition bar rendered flush under the magnifier
 * strip (web_app's live `TissueCompositionBar` parity): one
 * clinical-color segment per typed share, the untyped remainder in
 * a neutral tint. Segments are weight-proportional; zero shares are
 * skipped. Full-bleed and unrounded — it reads as the magnifier's
 * bottom edge, not a floating chip.
 */
@Composable
internal fun TissueCompositionBar(
    percentages: Map<TissueType, Int>,
    modifier: Modifier = Modifier,
) {
    val untyped = (100 - percentages.values.sum()).coerceAtLeast(0)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(8.dp),
    ) {
        for (type in TissueType.knownValues) {
            val pct = percentages[type] ?: 0
            if (pct <= 0) continue
            Box(
                Modifier
                    .weight(pct.toFloat())
                    .fillMaxHeight()
                    .background(clinicalColorFor(type)),
            )
        }
        if (untyped > 0) {
            Box(
                Modifier
                    .weight(untyped.toFloat())
                    .fillMaxHeight()
                    .background(TwinSkinColors.Line.copy(alpha = 0.5f)),
            )
        }
    }
}
