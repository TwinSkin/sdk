package com.twinskin.sdk.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * TwinSkin brand color tokens — verbatim from the Claude Design prototype
 * `tokens.jsx` (the pixel source of truth), itself derived from the mobile
 * app's `material_theme.dart` + brand screenshots. These feed [TwinSkinTheme]
 * and the per-screen rebuilds.
 *
 * The dark capture palette is intentionally absent — Module A (Capture) is
 * owned by the capture engineer.
 *
 * Clinical canvas colors (open stroke, closed wound, tissue legend, 2D
 * overlay) carry clinical meaning — never re-theme them. The `Tissue*`
 * constants below are the single source of truth (the canvas
 * `painters.kt#clinicalColorFor` reads them); the open-stroke /
 * closed-polygon overlays are still mirrored in painters.kt.
 */
internal object TwinSkinColors {
    // Brand · cyan ramp
    val Cyan = Color(0xFF48CAE4)
    val CyanDeep = Color(0xFF00B4D8)
    val CyanSoft = Color(0xFF90E0EF)
    val CyanPale = Color(0xFFCAF0F8)

    // Teal inks (text) & actions
    val Ink = Color(0xFF16536C) // onSurface — primary text
    val Ink2 = Color(0xFF1F6F91) // onSurfaceVariant — secondary text
    val Slate = Color(0xFF3B646E) // secondary — filled buttons (primary CTA)
    val Teal = Color(0xFF006878) // TwinSkin deep
    val TealLink = Color(0xFF007EA7)

    // Surfaces
    val Surface = Color(0xFFF8FCFE)
    val CardSurface = Color(0xFFFFFFFF)
    val TintHi = Color(0xFFDDF1FA)
    val TintMid = Color(0xFFE6F6FC)
    val TintLow = Color(0xFFEFFAFE)
    val IconBg = Color(0xFFE6F6FC)

    // Lines
    val Line = Color(0xFFBCC9CC)
    val Line2 = Color(0xFF6D797D)
    val Hint = Color(0xFF9CB4BE)

    // Status
    val Error = Color(0xFFBA1A1A)
    val ErrorSoft = Color(0xFFEC635E)
    val Success = Color(0xFF00BF63)
    val SuccessSoft = Color(0xFF94DDB3)
    val Warning = Color(0xFF805611)
    val WarningContainer = Color(0xFFFFDDB4)

    // Clinical tissue colors — single source; painters.kt#clinicalColorFor reads these.
    val TissueNecrosis = Color(0xFF1A1A1A)
    val TissueSlough = Color(0xFFE0C200)
    val TissueGranulation = Color(0xFFD12A2A)
    val TissueOther = Color(0xFF888888)

    // Clinical canvas overlays (mirror of painters.kt)
    val OpenStroke = Color(0xFF2AB07A)
    val ClosedPolygon = Color(0xFFE07A2A)
    val Overlay2D = Color(0xFFFF6F61)

    // Dark viewer stage (viewer is dark per the prototype — not Module A)
    val ViewDark = Color(0xFF0B0F11)

    // On-colors
    val OnTeal = Color(0xFFFFFFFF)
    val OnCyan = Color(0xFF003A44)
    val OnSurface = Ink
    val OnSurfaceVariant = Ink2
}
