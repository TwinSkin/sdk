package com.twinskin.sdk.ui.annotation_editor.delineation.draft

import com.russhwolf.settings.Settings
import com.russhwolf.settings.set
import com.twinskin.sdk.ui.annotation_editor.delineation.Step
import com.twinskin.sdk.ui.annotation_editor.delineation.StoreSnapshot
import kotlinx.serialization.SerializationException
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

/**
 * Disk-backed slot for the in-progress delineation, keyed by an
 * [ImageBitmap] content hash so the same image always opens the same
 * draft. One slot per image; saving overwrites; clearing removes.
 *
 * Backing store is provided via [provideDraftSettings] (per-platform
 * `SharedPreferences` / `NSUserDefaults` / in-memory for tests). The
 * store itself is platform-agnostic — it speaks the [Settings]
 * interface only.
 *
 * Save is *not* internally debounced — the caller (M13's root
 * composable) wraps mutations in a 500 ms `LaunchedEffect` debouncer
 * so the per-stroke storm doesn't hammer the file system.
 *
 * Retention is bounded: an LRU index (most-recent-first list of image
 * hashes under [INDEX_KEY]) is maintained on every save, and slots
 * beyond [MAX_DRAFTS] are evicted. The backing `SharedPreferences` /
 * `NSUserDefaults` file is rewritten whole on every write, so an
 * unbounded namespace would make each 500 ms auto-save rewrite every
 * draft ever created.
 */
internal class DraftStore(private val settings: Settings) {

    /** Returns the saved draft for [imageHash], or null when nothing is stored. */
    fun load(imageHash: String): DraftCodec.Decoded? {
        val raw = settings.getStringOrNull(keyFor(imageHash)) ?: return null
        return DraftCodec.decode(raw)
    }

    /** Persists [snapshot] + [currentStep] under [imageHash], overwriting any prior draft. */
    fun save(imageHash: String, snapshot: StoreSnapshot, currentStep: Step) {
        settings[keyFor(imageHash)] = DraftCodec.encode(snapshot, currentStep)
        touchIndexAndEvict(imageHash)
    }

    /** Removes the draft for [imageHash]. Idempotent — clearing an empty slot is a no-op. */
    fun clear(imageHash: String) {
        settings.remove(keyFor(imageHash))
        writeIndex(readIndex().filter { it != imageHash })
    }

    /**
     * Persists [snapshot] when it carries any wounds, clears the slot
     * otherwise. The auto-save side of M15.12 — without this gate, a
     * Start-Fresh-then-auto-save flow used to leave an empty
     * `StoreSnapshot` on disk that the next mount surfaced as a Resume
     * banner restoring a blank canvas (actively losing the user's
     * choice to start fresh). Empty snapshots are semantically "nothing
     * to resume" and must clear the slot rather than persist.
     */
    fun saveOrClear(imageHash: String, snapshot: StoreSnapshot, currentStep: Step) {
        if (snapshot.wounds.isEmpty()) {
            clear(imageHash)
        } else {
            save(imageHash, snapshot, currentStep)
        }
    }

    /**
     * Moves [imageHash] to the front of the LRU index and evicts any
     * slots beyond [MAX_DRAFTS]. Slots written before the index existed
     * (pre-retention builds) are folded in as least-recent so old
     * installs converge on the cap instead of growing forever.
     */
    private fun touchIndexAndEvict(imageHash: String) {
        val ordered = mutableListOf(imageHash)
        for (hash in readIndex()) {
            if (hash !in ordered) ordered += hash
        }
        for (key in settings.keys) {
            if (!key.startsWith(SLOT_PREFIX)) continue
            val hash = key.removePrefix(SLOT_PREFIX)
            if (hash !in ordered) ordered += hash
        }
        for (hash in ordered.drop(MAX_DRAFTS)) {
            settings.remove(keyFor(hash))
        }
        writeIndex(ordered.take(MAX_DRAFTS))
    }

    private fun readIndex(): List<String> {
        val raw = settings.getStringOrNull(INDEX_KEY) ?: return emptyList()
        return try {
            Json.decodeFromString(indexSerializer, raw)
        } catch (_: SerializationException) {
            emptyList()
        } catch (_: IllegalArgumentException) {
            emptyList()
        }
    }

    private fun writeIndex(hashes: List<String>) {
        if (hashes.isEmpty()) {
            settings.remove(INDEX_KEY)
        } else {
            settings[INDEX_KEY] = Json.encodeToString(indexSerializer, hashes)
        }
    }

    private fun keyFor(imageHash: String): String = "$SLOT_PREFIX$imageHash"

    internal companion object {
        /** Retention cap — the least-recently-saved slots beyond it are evicted on save. */
        const val MAX_DRAFTS = 8

        // Namespaced inside the [Settings] backing store so non-draft
        // keys (if anything else ever shares this Settings instance)
        // don't collide.
        private const val KEY_PREFIX = "draft.v1"
        private const val SLOT_PREFIX = "$KEY_PREFIX:"
        private const val INDEX_KEY = "$KEY_PREFIX.index"

        private val indexSerializer = ListSerializer(String.serializer())
    }
}
