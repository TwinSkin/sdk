package com.twinskin.sdk.ui.annotation_editor.polygon.canvas

import androidx.compose.ui.geometry.Offset
import kotlin.math.sqrt

/**
 * Pure two-finger pinch math used by [DrawingCanvas]'s pointer-event
 * gesture loop. Extracted out of the composable so the math is
 * unit-testable without a Compose runtime.
 */

/** Geometric midpoint of two pointer positions. */
internal fun pinchCentroid(p1: Offset, p2: Offset): Offset =
    Offset((p1.x + p2.x) * 0.5f, (p1.y + p2.y) * 0.5f)

/**
 * Ratio `|p1 - p2| / |prevP1 - prevP2|` — multiplier the gesture loop
 * applies to the current `ZoomPanController.scale` when drives a
 * pinch frame. Returns `1f` when the previous distance is too small
 * to be a meaningful denominator (defensive guard against div-by-zero
 * on a "two fingers down on the same pixel" frame).
 */
internal fun pinchScaleRatio(
    p1: Offset,
    p2: Offset,
    prevP1: Offset,
    prevP2: Offset,
): Float {
    val prevDist = pinchDistance(prevP1, prevP2)
    if (prevDist < EPSILON) return 1f
    val newDist = pinchDistance(p1, p2)
    return newDist / prevDist
}

private fun pinchDistance(a: Offset, b: Offset): Float {
    val dx = a.x - b.x
    val dy = a.y - b.y
    return sqrt(dx * dx + dy * dy)
}

private const val EPSILON: Float = 1f
