package com.twinskin.sdk.capture

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.storage.SdkStorage

internal const val STALE_SDK_CAPTURE_DB_WINDOW_MS: Long = 30L * 24 * 60 * 60 * 1000

/**
 * Best-effort sweep of stale per-subject PowerSync SQLite files left
 * behind by `observeSubject`. Delegates to [storage]'s `Databases`
 * purpose and filters by the `twinskin_sdk_captures_` prefix so
 * only SDK-owned DBs (and their `-wal` / `-shm` sidecars) are
 * considered.
 *
 * A file currently open by a live `observeSubject` collector gets
 * touched by PowerSync on every write, so its `lastModified` stays
 * fresh and the age filter skips it.
 */
internal fun cleanupStaleSdkCaptureDbs(
    storage: SdkStorage,
    olderThanMs: Long,
    logger: SdkLogger,
) {
    storage.sweep(Purpose.Databases, olderThanMs, logger) { name ->
        name.startsWith(SDK_CAPTURES_DB_PREFIX)
    }
}
