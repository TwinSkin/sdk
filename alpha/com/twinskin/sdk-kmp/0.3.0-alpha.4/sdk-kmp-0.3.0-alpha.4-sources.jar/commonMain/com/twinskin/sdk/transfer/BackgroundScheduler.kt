package com.twinskin.sdk.transfer

/**
 * Platform bridge for scheduling background work when an upload cannot proceed immediately
 * (e.g. no network connectivity).
 *
 * On Android the implementation is a no-op: WorkManager already re-runs the CoroutineWorker
 * automatically once the [NetworkType.CONNECTED] constraint is satisfied.
 *
 * On iOS the implementation schedules a [BGProcessingTask] that wakes the app when a network
 * connection is available, so [TransferManager] can retry the URL-resolver → PUT loop even
 * after the app has been suspended by the OS.
 */
internal interface BackgroundScheduler {
    /**
     * Called when an upload task receives [UrlResult.RetryableError] and the app may be
     * suspended before the next retry. The scheduler should ensure the app is woken when
     * conditions improve (network available, etc.).
     *
     * May be called multiple times for the same [taskId] — implementations must be idempotent.
     */
    fun scheduleUploadRetry(taskId: String)

    /**
     * Called when a task no longer needs a background wakeup (completed, failed permanently,
     * or [UrlResult.AlreadyExist] received). The scheduler should cancel any pending request
     * to avoid unnecessary wakeups.
     */
    fun cancelUploadRetry(taskId: String)
}
