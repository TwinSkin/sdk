package com.twinskin.sdk.capture

/**
 * Public-facing view of one entry in the server's demo-capture
 * catalog. Returned by [CaptureSession.listDemoCaptures] so the UI
 * can present a picker when more than one demo is available. Carries
 * only the fields a picker needs — file URLs stay internal to the
 * SDK so the wire shape can evolve without an API break.
 */
public data class DemoCaptureSummary(
    public val id: String,
    public val name: String,
)
