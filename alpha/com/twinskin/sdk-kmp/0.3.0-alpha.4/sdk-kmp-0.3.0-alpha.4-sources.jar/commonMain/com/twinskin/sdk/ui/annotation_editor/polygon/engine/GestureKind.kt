package com.twinskin.sdk.ui.annotation_editor.polygon.engine

/**
 * Result of the [GestureRouter] decision tree (spec §10.2). The
 * controller consumes this and transitions its own state machine
 * accordingly — see [ActiveGesture].
 *
 *  - [Stroke]: start a new open stroke at the touch-down position.
 *  - [Resume]: the touch-down is within the resume zone of the
 *    in-progress open stroke; continue that stroke.
 *  - [Reshape]: the touch-down is near the focused polygon's contour;
 *    enter reshape mode on it.
 *  - [Tap]: the touch-down is inside an editable polygon. Resolved
 *    on touch-up (focus transfer if no significant drag).
 *  - [None]: the gesture is ignored. The controller may emit a
 *    [UiSignal] (e.g. "too far from open stroke" snackbar) before
 *    returning.
 */
internal sealed class GestureKind {
    data object Stroke : GestureKind()
    data object Resume : GestureKind()
    data class Reshape(val polygonIdx: Int) : GestureKind()
    data object Tap : GestureKind()
    data object None : GestureKind()
}
