package com.twinskin.sdk.view

/**
 * Read the entire contents of [path] into a byte array. Used by the
 * 2D pane to decode a downloaded reference image into a Compose
 * [androidx.compose.ui.graphics.ImageBitmap]. Throws on IO failure.
 */
internal expect suspend fun readImageBytes(path: String): ByteArray
