package com.twinskin.sdk.ui.annotation_editor.delineation.draft

import androidx.compose.ui.geometry.Offset
import com.twinskin.sdk.ui.annotation_editor.delineation.Step
import com.twinskin.sdk.ui.annotation_editor.delineation.StoreSnapshot
import com.twinskin.sdk.ui.annotation_editor.delineation.parseStepFromWire
import com.twinskin.sdk.ui.annotation_editor.delineation.toWire
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Tissue
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json

/**
 * JSON wire codec for delineation drafts.
 *
 * The on-disk format is a versioned envelope so a schema change in a
 * later release can simply bump [CURRENT_VERSION] and decode-time
 * version mismatches return null (the resume banner won't appear,
 * the user starts fresh — see plan §M2b).
 *
 * Coordinates are kept in image-pixel `Offset` space — the same
 * coordinate system the canvas uses. Drafts never carry the
 * normalised wire shape; that conversion is M9's job at validation
 * time. Decision A (the SDK doesn't normalise outside the
 * `WoundAnnotation` boundary).
 */
internal object DraftCodec {
    /** Bump on every wire-format change. Old drafts decode to null. */
    const val CURRENT_VERSION: Int = 1

    private val json = Json {
        ignoreUnknownKeys = true     // forward-compat: tolerate fields added later
        prettyPrint = false
    }

    /** Serialise [snapshot] + [step] to a JSON envelope. */
    fun encode(snapshot: StoreSnapshot, step: Step): String {
        val payload = DraftPayload(
            wounds = snapshot.wounds.map { it.toWire() },
            cardStates = snapshot.cardStates.entries.associate { (t, s) -> t.wire to s.name },
            currentStep = step.toWire(),
        )
        return json.encodeToString(
            DraftEnvelope.serializer(),
            DraftEnvelope(version = CURRENT_VERSION, payload = payload),
        )
    }

    /**
     * Parse a JSON envelope. Returns null on:
     *   - version mismatch (older or newer payload than this build groks)
     *   - JSON parse failure (corrupted draft)
     *   - shape failure (missing required fields)
     *
     * The caller (M2b's [DraftStore]) treats any null as "no resumable
     * draft" — the user starts fresh and the corrupted slot is left
     * alone for now (cleared on the next save).
     */
    fun decode(text: String): Decoded? {
        val envelope = try {
            json.decodeFromString(DraftEnvelope.serializer(), text)
        } catch (_: SerializationException) {
            return null
        } catch (_: IllegalArgumentException) {
            return null
        }
        if (envelope.version != CURRENT_VERSION) return null
        val payload = envelope.payload
        val wounds = payload.wounds.map { it.toModel() }
        val cardStates = mutableMapOf<TissueType, TissueCardState>()
        for ((wire, stateName) in payload.cardStates) {
            val type = TissueType.fromWire(wire)
            // Defensive — Other should never appear here (the encoder
            // only emits known card states), but if a future build
            // somehow ships one, drop it rather than crash.
            if (type !in TissueType.knownValues) continue
            val state = TissueCardState.entries.firstOrNull { it.name == stateName } ?: continue
            cardStates[type] = state
        }
        val step = parseStepFromWire(payload.currentStep) ?: return null
        return Decoded(StoreSnapshot(wounds, cardStates), step)
    }

    /** Decode result — both the store snapshot and the step the user was on. */
    data class Decoded(val snapshot: StoreSnapshot, val step: Step)

    // ---------- model ↔ wire conversions ----------

    private fun Wound.toWire() = WireWound(
        outline = outline.map { WirePoint(it.x, it.y) },
        tissues = tissues.map { it.toWire() },
    )

    private fun Tissue.toWire() = WireTissue(
        typeWire = type.wire,
        outline = outline.map { WirePoint(it.x, it.y) },
    )

    private fun WireWound.toModel() = Wound(
        outline = outline.map { Offset(it.x, it.y) },
        tissues = tissues.map { it.toModel() },
    )

    private fun WireTissue.toModel() = Tissue(
        type = TissueType.fromWire(typeWire),
        outline = outline.map { Offset(it.x, it.y) },
    )

}

// ---------- wire types ----------

@Serializable
private data class DraftEnvelope(
    @SerialName("version") val version: Int,
    @SerialName("payload") val payload: DraftPayload,
)

@Serializable
private data class DraftPayload(
    @SerialName("wounds") val wounds: List<WireWound>,
    @SerialName("cardStates") val cardStates: Map<String, String>,
    @SerialName("currentStep") val currentStep: String,
)

@Serializable
private data class WireWound(
    @SerialName("outline") val outline: List<WirePoint>,
    @SerialName("tissues") val tissues: List<WireTissue> = emptyList(),
)

@Serializable
private data class WireTissue(
    @SerialName("type") val typeWire: String,
    @SerialName("outline") val outline: List<WirePoint>,
)

@Serializable
private data class WirePoint(
    @SerialName("x") val x: Float,
    @SerialName("y") val y: Float,
)
