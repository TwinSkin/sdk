package com.twinskin.sdk.capture.fallback

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

public interface VideoRecorder {
    /** MUST return immediately; observe [cameraReady] for actual open. Idempotent. */
    public fun prepare() {}

    /**
     * Streaming-ready signal. Android emits `true` on first
     * `CameraState.OPEN` so the host gates the shutter on a real
     * cold-camera open. iOS uses the default `true`: `AVCapture-
     * Session.startRunning` is invoked synchronously inside
     * [prepare]'s caller and the iOS cold-camera tail is short
     * enough that the shutter race the Android observer closes
     * does not surface in practice — the iOS host can flip to
     * ReadyForPhoto without waiting on a separate signal.
     */
    public val cameraReady: StateFlow<Boolean>
        get() = ALWAYS_CAMERA_READY

    /** [outputPath] MUST live inside [com.twinskin.sdk.capture.CaptureSession.workingDir]. */
    public fun start(outputPath: String)

    public fun stop(): String

    /** MUST be safe to call before [start], after [stop], or after an error — never throws. */
    public fun cancel()
}

public expect fun createVideoRecorder(): VideoRecorder

public const val VIDEO_RECORDER_NOT_IMPLEMENTED_MESSAGE: String =
    "VideoRecorder is not implemented yet — see #505"

private val ALWAYS_CAMERA_READY: StateFlow<Boolean> =
    MutableStateFlow(true).asStateFlow()
