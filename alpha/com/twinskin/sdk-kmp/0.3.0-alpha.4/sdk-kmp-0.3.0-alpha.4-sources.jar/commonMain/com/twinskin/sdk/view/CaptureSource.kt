package com.twinskin.sdk.view

/**
 * Input to [com.twinskin.sdk.TwinSkinSdk.viewCapture]. Each variant resolves
 * to the same [ResolvedCapture] shape so the UI is source-agnostic.
 *
 * The [GlbUrl] variant is the "integrator-supplied URL" path — the SDK
 * fetches the URL as-is, attaching whatever [headers] the integrator
 * provides. The integrator is free to point the URL at its own backend,
 * a CDN, or (via a header bag) directly at Twinskin's
 * `/api/sdk/asset?key=…` endpoint with a session JWT. The SDK is
 * agnostic to the auth scheme.
 *
 * The [CaptureId] variant is the "SDK-managed" path: the SDK resolves
 * the capture against Twinskin directly using its own credentials —
 * integrators have nothing to wire beyond the id and the subject the
 * capture belongs to.
 */
public sealed class CaptureSource {
    /** A .glb file already on local storage. Path is a filesystem path. */
    public data class LocalGlb(val path: String) : CaptureSource()

    /**
     * Direct URL to a .glb file. Downloaded to the SDK cache.
     *
     * [headersProvider] is invoked by the resolver just before the HTTP
     * fetch — pass a suspending block that mints (or refreshes) whatever
     * the integrator's backend requires. Returning an empty map means
     * no auth. The returned headers are attached to the initial GET
     * only; every redirect (including the typical 302 → presigned S3 URL)
     * is followed by hand with no headers, so nothing the integrator
     * minted reaches the redirect target.
     *
     * A throw from [headersProvider] surfaces as
     * [ViewCaptureError.Credentials] with a "Retry" affordance in the
     * viewer UI, distinct from a download or parse failure.
     *
     * Note: not a `data class` — lambdas don't participate meaningfully
     * in `equals`/`hashCode`. `CaptureSource` isn't compared or
     * serialized so the loss is academic.
     */
    public class GlbUrl(
        public val url: String,
        public val headersProvider: suspend () -> Map<String, String> = { emptyMap() },
    ) : CaptureSource()

    /**
     * Capture identifier. Resolved via PowerSync against the integrator's
     * SDK environment using the SDK's own session credentials — the
     * integrator provides nothing beyond the id and the subject the capture
     * belongs to.
     *
     * `subjectRef` is required because the SDK's PowerSync token is
     * subject-scoped (`sdk:<envId>:<subjectRef>`); the capture id alone
     * cannot authorize the watch query.
     */
    public data class CaptureId(val id: String, val subjectRef: String) : CaptureSource()
}
