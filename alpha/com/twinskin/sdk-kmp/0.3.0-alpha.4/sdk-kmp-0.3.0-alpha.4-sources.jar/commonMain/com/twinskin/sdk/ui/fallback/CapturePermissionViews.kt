@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.ui.capture.i18n.EnCaptureStrings

@TwinSkinInternalApi
public enum class CapturePermissionPhase {
    Rationale,
    Granted,
    Blocked,
}

@TwinSkinInternalApi
public fun capturePermissionPhase(
    granted: Boolean,
    // permanentlyDenied: Android shouldShowRequestPermissionRationale==false after a denial;
    // iOS authorizationStatus is .denied/.restricted.
    permanentlyDenied: Boolean,
): CapturePermissionPhase = when {
    granted -> CapturePermissionPhase.Granted
    permanentlyDenied -> CapturePermissionPhase.Blocked
    else -> CapturePermissionPhase.Rationale
}

/**
 * Bridge to the generated English permission strings. Kept as an object (rather
 * than reading [com.twinskin.sdk.ui.capture.i18n.LocalCaptureStrings]) only so
 * the existing call sites are unchanged; the composables below could read the
 * CompositionLocal directly once permission copy is localised.
 */
@TwinSkinInternalApi
public object CapturePermissionCopy {
    public val rationaleTitle: String = EnCaptureStrings.permissionRationaleTitle
    public val rationaleBody: String = EnCaptureStrings.permissionRationaleBody
    public val rationaleCta: String = EnCaptureStrings.permissionRationaleCta

    public val blockedTitle: String = EnCaptureStrings.permissionBlockedTitle
    public val blockedBody: String = EnCaptureStrings.permissionBlockedBody
    public val blockedCta: String = EnCaptureStrings.permissionBlockedCta

    public val cancel: String = EnCaptureStrings.permissionCancel
}

@TwinSkinInternalApi
@Composable
public fun CapturePermissionRationale(
    onAllow: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    PermissionScrim(
        modifier = modifier,
        accent = colors.orbit,
        title = CapturePermissionCopy.rationaleTitle,
        body = CapturePermissionCopy.rationaleBody,
        primaryLabel = CapturePermissionCopy.rationaleCta,
        onPrimary = onAllow,
        onCancel = onCancel,
        colors = colors,
        badge = {
            Icon(
                Icons.Outlined.PhotoCamera,
                contentDescription = null,
                tint = colors.orbit,
                modifier = Modifier.size(28.dp),
            )
        },
    )
}

@TwinSkinInternalApi
@Composable
public fun CapturePermissionBlocked(
    onOpenSettings: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    PermissionScrim(
        modifier = modifier,
        accent = colors.warning,
        title = CapturePermissionCopy.blockedTitle,
        body = CapturePermissionCopy.blockedBody,
        primaryLabel = CapturePermissionCopy.blockedCta,
        onPrimary = onOpenSettings,
        onCancel = onCancel,
        colors = colors,
        badge = {
            Text("!", color = colors.warning, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        },
    )
}

@Composable
private fun PermissionScrim(
    modifier: Modifier,
    accent: Color,
    title: String,
    body: String,
    primaryLabel: String,
    onPrimary: () -> Unit,
    onCancel: () -> Unit,
    colors: AccelerometerCaptureColors,
    badge: @Composable () -> Unit,
) {
    Box(modifier = modifier.fillMaxSize().background(colors.surface)) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xCC060A0B), Color(0xED060A0B))))
                .padding(horizontal = 36.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier.size(56.dp).border(2.dp, accent, CircleShape),
                    contentAlignment = Alignment.Center,
                    content = { badge() },
                )
                Spacer(Modifier.height(18.dp))
                Text(
                    title,
                    color = colors.onSurface,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    body,
                    color = colors.onSurfaceVariant,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                )
            }
        }
        Row(
            // The host activity is edge-to-edge, so the bottom button row would
            // otherwise draw under the 3-button nav bar (A21s / XCover5) — clipping
            // the buttons. `safeDrawing` is 0 where there is no bar (gesture nav),
            // so it never double-pads, and it covers the iOS home indicator too.
            modifier = Modifier.align(Alignment.BottomCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom))
                .padding(horizontal = 22.dp, vertical = 22.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            PermissionActionButton(
                label = CapturePermissionCopy.cancel,
                primary = false,
                onClick = onCancel,
                colors = colors,
                modifier = Modifier.weight(1f),
            )
            PermissionActionButton(
                label = primaryLabel,
                primary = true,
                onClick = onPrimary,
                colors = colors,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun RowScope.PermissionActionButton(
    label: String,
    primary: Boolean,
    onClick: () -> Unit,
    colors: AccelerometerCaptureColors,
    modifier: Modifier = Modifier,
) {
    val base = if (primary) Modifier.background(colors.orbit, RoundedCornerShape(14.dp))
    else Modifier.border(1.dp, colors.outline, RoundedCornerShape(14.dp))
    Box(
        modifier = modifier.then(base)
            .clickable { onClick() }
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (primary) colors.onOrbit else colors.onSurface,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
