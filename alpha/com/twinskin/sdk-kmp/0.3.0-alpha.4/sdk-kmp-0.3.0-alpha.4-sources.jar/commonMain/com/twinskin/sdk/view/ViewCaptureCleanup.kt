package com.twinskin.sdk.view

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.storage.SdkStorage

internal const val STALE_VIEW_CAPTURE_WINDOW_MS: Long = 30L * 24 * 60 * 60 * 1000

/**
 * Age out [Purpose.ViewCapture] downloads (GLB models, reference
 * images) older than [olderThanMs]. Cache keys are content-addressed
 * (filename derived from the immutable S3 key), so anything aged out
 * is transparently re-downloaded next time the capture is opened.
 *
 * No filename filter — the entire `view-capture/` subdir is
 * SDK-owned. Includes legacy per-capture subdirs left by older SDK
 * versions; the platform sweep deletes those recursively.
 */
internal fun cleanupStaleViewCaptureFiles(
    storage: SdkStorage,
    olderThanMs: Long,
    logger: SdkLogger,
) {
    storage.sweep(Purpose.ViewCapture, olderThanMs, logger)
}
