package com.twinskin.sdk.ui.annotation_editor.delineation.model

import androidx.compose.runtime.Immutable
import androidx.compose.ui.geometry.Offset

/**
 * A tissue region — closed polygon in image-pixel coordinates plus its
 * type. Defensive-copies the [outline] list at construction (per plan
 * §M2 note); mutating the list passed in afterwards has no effect on
 * this instance.
 *
 * Hand-rolled (not `data class`) because Kotlin's `data class` doesn't
 * let `init {}` reassign val fields, and the plan requires the
 * defensive copy at construction time.
 */
@Immutable
internal class Tissue(
    val type: TissueType,
    outline: List<Offset>,
) {
    val outline: List<Offset> = outline.toList()

    fun copy(type: TissueType = this.type, outline: List<Offset> = this.outline): Tissue =
        Tissue(type, outline)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Tissue) return false
        return type == other.type && outline == other.outline
    }

    override fun hashCode(): Int = 31 * type.hashCode() + outline.hashCode()

    override fun toString(): String = "Tissue(type=$type, outline=$outline)"
}
