package com.twinskin.sdk.ui.fallback

import com.twinskin.sdk.capture.SdkReferenceLuminance

/**
 * Outcome of the low-light probe on the captured reference still.
 *
 * Carries two orthogonal signals so the probe can fail open for the UI without
 * fabricating a manifest value (mirrors [MarkerProbeResult]):
 * - [lowLight] drives the presentation-only torch/retake card. A probe error or
 *   unwired probe reads as `false` (no false "low light" warning).
 * - [referenceLuminance] is the native `xfeat_ref_luminance_eval` struct
 *   forwarded verbatim into the manifest's `reference_luminance`. Non-null ONLY
 *   when the native eval ran; `null` on probe error or no probe. Never fabricated.
 *
 * The two can diverge: a host that meters luma for the card but doesn't run the
 * native eval yields `lowLight` set with `referenceLuminance = null`.
 */
public data class LowLightProbeResult(
    val lowLight: Boolean,
    val referenceLuminance: SdkReferenceLuminance?,
) {
    public companion object {
        /** No-false-positive default: no card, no fabricated manifest value. */
        public val NotLowLight: LowLightProbeResult =
            LowLightProbeResult(lowLight = false, referenceLuminance = null)
    }
}
