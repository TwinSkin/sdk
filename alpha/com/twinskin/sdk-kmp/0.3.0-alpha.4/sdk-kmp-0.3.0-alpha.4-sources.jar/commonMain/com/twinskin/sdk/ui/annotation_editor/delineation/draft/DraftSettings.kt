package com.twinskin.sdk.ui.annotation_editor.delineation.draft

import com.russhwolf.settings.Settings

/**
 * Returns the platform-specific [Settings] backing store dedicated to
 * delineation drafts.
 *
 *  - Android: `SharedPreferencesSettings` over a private prefs file
 *    `twinskin_delineation_drafts`.
 *  - iOS: `NSUserDefaultsSettings` over a `twinskin_delineation_drafts`
 *    suite — isolated from the host app's defaults.
 *  - JVM (tests + desktop): in-memory `MapSettings` — tests never touch
 *    a real disk; desktop targets aren't a deployment target for this
 *    feature today.
 *
 * The dedicated namespace is the reason the SDK doesn't use
 * `multiplatform-settings`'s `Settings()` no-arg factory: the no-arg
 * factory shares storage with the host app's default prefs on Android,
 * which would let host code see / mutate the SDK's drafts.
 */
internal expect fun provideDraftSettings(): Settings
