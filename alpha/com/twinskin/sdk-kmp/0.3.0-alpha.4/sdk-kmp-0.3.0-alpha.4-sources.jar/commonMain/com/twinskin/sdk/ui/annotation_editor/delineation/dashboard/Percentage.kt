package com.twinskin.sdk.ui.annotation_editor.delineation.dashboard

import androidx.compose.ui.graphics.Path
import com.twinskin.sdk.geometry.difference
import com.twinskin.sdk.geometry.pathArea
import com.twinskin.sdk.geometry.polygonToPath
import com.twinskin.sdk.geometry.signedArea
import com.twinskin.sdk.geometry.union
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound
import kotlin.math.absoluteValue

/**
 * Percentage breakdown of the three known tissue types over the
 * union of every wound's area (spec §7.2 dashboard, decision L
 * refined to per-polygon claiming).
 *
 * **Algorithm — per-polygon exclusive claiming.** Every tissue
 * polygon (across all types and wounds) is walked in ascending order
 * of its own area; each polygon's net contribution is the
 * [difference] against the running "already claimed" region, and the
 * polygon is then unioned into the claimed region. A region covered
 * by several polygons is therefore awarded to the SMALLEST polygon
 * covering it — which for the clinical case of a tissue drawn inside
 * another means: the inner tissue keeps its full size and the outer
 * one is deducted by the inner one(s). This is decision L's
 * "smallest wins" made per-polygon rather than per-type: the old
 * type-level gross sort mis-awarded a small island of a globally
 * large type sitting inside a polygon of a globally small type.
 * Same-type nesting degrades gracefully — the nets of nested
 * same-type polygons sum to their union, so nothing double-counts.
 *
 * **Exactly-100 invariant.** The untyped remainder participates in
 * the rounding as a fourth bucket: its raw share is
 * `100 − Σ typed-raw` (geometrically, wound area minus the claimed
 * tissue area) and the largest-remainder apportionment distributes
 * exactly 100 integer points over the four buckets. When the wound
 * is fully covered (auto-fill or hand-drawn tiling), the untyped
 * raw share is boolean-op noise (« 1 %), it floors to 0, and the
 * three typed integers sum to exactly 100 — the dashboard's
 * `100 − sum(known)` footer disappears. The pre-refactor pipeline
 * apportioned to `floor(Σ typed-raw)`, so full coverage routinely
 * displayed 99 % + a phantom 1 % Untyped row.
 *
 * **Sum-exceeds-100 defence.** Numerical noise in [pathArea] over
 * the boolean-op tessellation can push the claimed total slightly
 * above the wounds area; the per-type net areas are scaled down by
 * `woundsArea / rawTotal` first, so raw typed shares always sum
 * to ≤ 100.
 *
 * **`Other` tissues.** [TissueType.Other] tissues are excluded from
 * the percentage computation and from the returned map. Their area
 * falls into the implicit untyped remainder — the dashboard renders
 * `100 − sum(known)` without naming the variant.
 *
 * **Map shape.** Always returns all three [TissueType.knownValues]
 * keys, even when their value is 0 — sparse maps would force `?: 0`
 * at every M11 call site.
 *
 * **Empty / degenerate inputs.** Returns all-zeros when
 * `woundsArea < 1` image-pixel² (covers both the empty-wounds
 * case and the all-degenerate-outlines case in one guard, no
 * division by zero).
 *
 * **Performance.** One [difference] + one [union] per tissue
 * polygon. Sub-millisecond for the typical 1–3 wound, handful-of-
 * tissues case but recomputed on every dashboard recomposition —
 * call sites memoise via `derivedStateOf` keyed on the store
 * revision.
 */
internal fun percentagesByType(wounds: List<Wound>): Map<TissueType, Int> {
    val zeros = TissueType.knownValues.associateWith { 0 }

    val woundsArea = wounds.sumOf { signedArea(it.outline).absoluteValue.toDouble() }
    if (woundsArea < ZERO_AREA_EPSILON) return zeros

    // Every known-type tissue polygon, smallest first. The claiming
    // order must be stable under coordinate scaling / translation, or
    // the ownership of an overlap between two near-equal-area
    // polygons flips with float noise and the same drawing reads
    // differently at a different image resolution. Two defences:
    // the sort area is a double-precision shoelace normalised by the
    // wound area (scale-cancelling), quantised to 0.1 %-of-wound
    // buckets so near-equal areas are treated as an exact tie; ties
    // break on the canonical type order, which is independent of
    // both the coordinates and the tissue list order.
    data class Piece(val type: TissueType, val path: Path, val bucket: Long)
    val pieces = wounds
        .flatMap { wound -> wound.tissues }
        .filter { it.type in TissueType.knownValues && it.outline.size >= 3 }
        .map {
            Piece(
                type = it.type,
                path = polygonToPath(it.outline),
                bucket = kotlin.math.round(
                    signedAreaDouble(it.outline) / woundsArea * 1000.0,
                ).toLong(),
            )
        }
        .sortedWith(
            compareBy({ it.bucket }, { TissueType.knownValues.indexOf(it.type) }),
        )

    // net_i = piece_i \ (∪ of all smaller pieces), computed by
    // sequential pairwise subtraction — ((P \ A) \ B) ≡ P \ (A ∪ B).
    // Each op stays a binary op between two user-drawn polygons; an
    // accumulated union path grows pathological for Skia and its
    // occasional op failure silently overcounts whole polygons,
    // which showed up as translation-dependent percentages.
    val netArea: MutableMap<TissueType, Double> =
        TissueType.knownValues.associateWith { 0.0 }.toMutableMap()
    for ((i, piece) in pieces.withIndex()) {
        var exclusive = piece.path
        for (j in 0 until i) {
            exclusive = difference(exclusive, pieces[j].path) ?: exclusive
        }
        netArea[piece.type] = netArea.getValue(piece.type) + pathArea(exclusive).toDouble()
    }

    val rawTotal = netArea.values.sum()
    val scale = if (rawTotal > woundsArea) woundsArea / rawTotal else 1.0

    // Raw typed percentages plus the untyped remainder as a fourth
    // bucket, so the apportionment target is exactly 100 and full
    // coverage can't strand the typed sum at 99 on rounding noise.
    var typedRaws: Map<TissueType, Double> = TissueType.knownValues.associateWith { t ->
        (netArea.getValue(t) * scale / woundsArea * 100.0).coerceAtLeast(0.0)
    }
    var untypedRaw = (100.0 - typedRaws.values.sum()).coerceAtLeast(0.0)

    // Full-coverage snap: a remainder below one display percent is
    // boolean-op noise or the sub-`minTissueArea` slivers the
    // auto-fill deliberately drops, not clinical information. Fold
    // it into the typed shares so a tiled wound reads exactly 100 %
    // instead of a phantom 1 % Untyped row.
    if (untypedRaw < 1.0 && typedRaws.values.sum() > 0.0) {
        val rescale = 100.0 / typedRaws.values.sum()
        typedRaws = typedRaws.mapValues { (_, v) -> v * rescale }
        untypedRaw = 0.0
    }

    // Largest-remainder apportionment over the four buckets to a
    // fixed target of 100. `null` keys the untyped bucket.
    val raws: Map<TissueType?, Double> =
        typedRaws.mapKeys { (k, _) -> k as TissueType? } + mapOf(null to untypedRaw)
    val floors: MutableMap<TissueType?, Int> =
        raws.mapValues { (_, v) -> v.toInt() }.toMutableMap()
    var remaining = 100 - floors.values.sum()
    if (remaining > 0) {
        val byFractionalRemainder = raws.entries.sortedByDescending { it.value - it.value.toInt() }
        for ((bucket, _) in byFractionalRemainder) {
            if (remaining <= 0) break
            floors[bucket] = floors.getValue(bucket) + 1
            remaining--
        }
    }
    return TissueType.knownValues.associateWith { floors.getValue(it) }
}

/** Double-precision |shoelace| — see the sort-stability note above. */
private fun signedAreaDouble(poly: List<androidx.compose.ui.geometry.Offset>): Double {
    if (poly.size < 3) return 0.0
    var acc = 0.0
    var j = poly.size - 1
    for (i in poly.indices) {
        acc += poly[j].x.toDouble() * poly[i].y.toDouble() -
            poly[i].x.toDouble() * poly[j].y.toDouble()
        j = i
    }
    return kotlin.math.abs(acc) * 0.5
}

private const val ZERO_AREA_EPSILON: Double = 1.0
