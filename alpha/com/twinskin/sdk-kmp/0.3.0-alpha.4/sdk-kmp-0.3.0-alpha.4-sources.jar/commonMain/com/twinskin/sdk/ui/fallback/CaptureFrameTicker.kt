package com.twinskin.sdk.ui.fallback

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameMillis

/**
 * LOW-END (load-bearing): the one clock all looping cues read. animateTo(tween)/rememberInfiniteTransition
 * freeze on weak GPUs under the composited camera preview; the withFrameMillis vsync ticker keeps producing values.
 */
@Composable
internal fun rememberFrameSeconds(): State<Float> {
    val secs = remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameMillis { it }
        while (true) {
            withFrameMillis { ms -> secs.value = (ms - start) / 1000f }
        }
    }
    return secs
}

internal fun pulse01(seconds: Float, periodSec: Float): Float {
    if (periodSec <= 0f) return 0f
    val phase = (seconds % periodSec) / periodSec
    return if (phase < 0.5f) phase * 2f else (1f - phase) * 2f
}

internal fun pulse(seconds: Float, periodSec: Float, lo: Float, hi: Float): Float =
    lo + (hi - lo) * pulse01(seconds, periodSec)
