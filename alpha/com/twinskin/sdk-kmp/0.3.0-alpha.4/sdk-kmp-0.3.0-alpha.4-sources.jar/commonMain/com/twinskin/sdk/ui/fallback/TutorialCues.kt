package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

public enum class CuePic { Parallel, Distance, Frame, Orbit, Target, Ring8 }

@Composable
public fun CueRow(
    cues: List<Pair<CuePic, String>>,
    modifier: Modifier = Modifier,
    colors: AccelerometerCaptureColors = LocalAccelerometerCaptureColors.current,
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        cues.forEach { (pic, label) ->
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                androidx.compose.foundation.layout.Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(colors.orbit.copy(alpha = 0.10f), RoundedCornerShape(13.dp))
                        .border(1.dp, colors.orbit.copy(alpha = 0.24f), RoundedCornerShape(13.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Canvas(modifier = Modifier.size(22.dp)) { drawCue(pic, colors.orbit) }
                }
                Text(label, color = colors.onSurface, fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, lineHeight = 13.sp)
            }
        }
    }
}

private fun DrawScope.drawCue(pic: CuePic, tint: Color) {
    val s = size.minDimension / 24f
    fun p(x: Float, y: Float) = Offset(x * s, y * s)
    val sw = 2f * s
    val stk = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
    // vararg Offset prohibited on JVM (value class); take a List
    fun poly(pts: List<Offset>) = Path().apply {
        moveTo(pts[0].x, pts[0].y); for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y)
    }
    when (pic) {
        CuePic.Parallel -> {
            drawRoundRect(tint, topLeft = p(4.5f, 5.5f), size = Size(15f * s, 4.5f * s),
                cornerRadius = CornerRadius(2.2f * s, 2.2f * s), style = stk)
            drawLine(tint, p(4.5f, 16.5f), p(19.5f, 16.5f), sw, StrokeCap.Round)
        }
        CuePic.Distance -> {
            drawLine(tint, p(12f, 4.5f), p(12f, 19.5f), sw, StrokeCap.Round)
            drawPath(poly(listOf(p(8.5f, 8f), p(12f, 4.5f), p(15.5f, 8f))), tint, style = stk)
            drawPath(poly(listOf(p(8.5f, 16f), p(12f, 19.5f), p(15.5f, 16f))), tint, style = stk)
        }
        CuePic.Frame -> {
            drawPath(poly(listOf(p(8.5f, 4f), p(6f, 4f), p(4f, 6f), p(4f, 8.5f))), tint, style = stk)
            drawPath(poly(listOf(p(15.5f, 4f), p(18f, 4f), p(20f, 6f), p(20f, 8.5f))), tint, style = stk)
            drawPath(poly(listOf(p(20f, 15.5f), p(20f, 18f), p(18f, 20f), p(15.5f, 20f))), tint, style = stk)
            drawPath(poly(listOf(p(8.5f, 20f), p(6f, 20f), p(4f, 18f), p(4f, 15.5f))), tint, style = stk)
            drawCircle(tint, 2f * s, center = p(12f, 12f))
        }
        CuePic.Orbit -> {
            drawArc(tint, startAngle = -50f, sweepAngle = 300f, useCenter = false,
                topLeft = p(4.5f, 4.5f), size = Size(15f * s, 15f * s), style = Stroke(width = sw, cap = StrokeCap.Round))
            drawPath(poly(listOf(p(15.7f, 8.5f), p(19.7f, 8.5f), p(19.7f, 4.5f))), tint, style = stk)
            drawCircle(tint, 2.4f * s, center = p(12f, 12f))
        }
        CuePic.Target -> {
            drawCircle(tint, 7.5f * s, center = p(12f, 12f), style = Stroke(width = sw))
            drawLine(tint, p(12f, 1.5f), p(12f, 4.5f), sw, StrokeCap.Round)
            drawLine(tint, p(12f, 19.5f), p(12f, 22.5f), sw, StrokeCap.Round)
            drawLine(tint, p(1.5f, 12f), p(4.5f, 12f), sw, StrokeCap.Round)
            drawLine(tint, p(19.5f, 12f), p(22.5f, 12f), sw, StrokeCap.Round)
            drawCircle(tint, 2.3f * s, center = p(12f, 12f))
        }
        CuePic.Ring8 -> {
            drawCircle(tint, 8f * s, center = p(12f, 12f), style = Stroke(width = sw))
            drawPath(poly(listOf(p(8.5f, 12.3f), p(10.9f, 14.7f), p(15.5f, 9.6f))), tint, style = stk)
        }
    }
}
