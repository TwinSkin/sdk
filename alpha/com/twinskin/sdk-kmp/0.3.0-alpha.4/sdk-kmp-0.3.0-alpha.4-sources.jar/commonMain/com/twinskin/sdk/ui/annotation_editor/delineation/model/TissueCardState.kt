package com.twinskin.sdk.ui.annotation_editor.delineation.model

/** State of one of the three tissue-type cards on the dashboard (screen 3). */
internal enum class TissueCardState { Open, Drawn, Absent }
