package com.twinskin.sdk.view

import com.twinskin.sdk.TwinSkinInternalApi
import kotlinx.coroutines.flow.Flow

/**
 * Turns a [CaptureSource] into a stream of [ResolverEvent]s.
 *
 * - One-shot resolvers (local/url/zip) emit a few [ResolverEvent.Progress]
 *   events and then a terminal [ResolverEvent.Resolved], and complete.
 * - Reactive resolvers (PowerSync, later) stay open and keep emitting
 *   [ResolverEvent.Resolved] whenever underlying data changes.
 */
@TwinSkinInternalApi
public interface CaptureResolver {
    public fun resolve(): Flow<ResolverEvent>
}

@TwinSkinInternalApi
public sealed class ResolverEvent {
    public data class Progress(val progress: LoadProgress) : ResolverEvent()
    public data class Resolved(val capture: ResolvedCapture) : ResolverEvent()
}
