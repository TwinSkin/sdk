package com.twinskin.sdk.capture.crypto

internal data class EncryptedChunk(val ciphertext: ByteArray, val tag: ByteArray)

/**
 * Streaming chunked AES-256-GCM encryptor.
 *
 * Each call to [encryptChunk] consumes a plaintext slice and produces a
 * ciphertext + 16-byte tag pair, using a 96-bit nonce derived as
 * `baseNonce[0..8] || counter_be32(chunkIndex)`. The counter starts at 0 on
 * construction and increments after every successful chunk.
 *
 * Construction validates that [key] is 32 bytes (AES-256) and [baseNonce]
 * is 12 bytes (GCM standard). The class is not thread-safe; the bundle
 * pipeline runs on a single coroutine.
 */
internal expect class AesGcmEncryptor(key: ByteArray, baseNonce: ByteArray) {

    fun encryptChunk(plaintext: ByteArray, off: Int, len: Int): EncryptedChunk
}
