package com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Single confirmation dialog used by every annotation-editor
 * destructive flow (Validate, Abandon session, Delete-with-tissues,
 * Reshape-with-tissues). Spec U11.
 *
 * Built on Material3 [AlertDialog]:
 *  - Modal scrim + back-button / ESC dismissal route through
 *    [onCancel] via `onDismissRequest`.
 *  - The destructive [Button] sits in `confirmButton` (END in
 *    LTR), tinted with `MaterialTheme.colorScheme.error`.
 *  - The neutral cancel [TextButton] sits in `dismissButton`
 *    (START in LTR).
 *
 * @param body  Plain-text body. The caller pre-formats any count
 *              interpolation inline
 *              (e.g., `"Delete this wound? It contains $n tissue region(s)."`).
 *
 * @param dontShowAgainLabel  When non-null, a checkbox
 *              row is rendered below the body and the destructive
 *              button invokes [onConfirmWithDontShowAgain] with
 *              the checkbox state instead of [onConfirm]. Use for
 *              destructive flows that the user can permanently
 *              dismiss; cancel never reads or persists the
 *              checkbox state. The label and the callback must be
 *              passed together (a [require] catches the partial
 *              configuration at composition time). Reading the
 *              checkbox in the body — rather than the original
 *              KDoc-suggested `bodyContent: @Composable` overload
 *              — keeps every existing 6-param call site
 *              unchanged; bodyContent overload is the right
 *              choice when the body needs richer content than a
 *              single Text + checkbox.
 */
@Composable
internal fun ConfirmDialog(
    title: String,
    body: String,
    destructiveLabel: String,
    cancelLabel: String,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
    dontShowAgainLabel: String? = null,
    onConfirmWithDontShowAgain: ((dontShowAgain: Boolean) -> Unit)? = null,
) {
    require(
        (dontShowAgainLabel == null) == (onConfirmWithDontShowAgain == null),
    ) {
        "ConfirmDialog: dontShowAgainLabel and onConfirmWithDontShowAgain must be passed " +
            "together (or both omitted) — partial configuration would silently drop the " +
            "checkbox state."
    }
    var dontShowAgain by rememberSaveable { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = {
            if (dontShowAgainLabel == null) {
                Text(body)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(body)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { dontShowAgain = !dontShowAgain }
                            .padding(vertical = 4.dp),
                    ) {
                        Checkbox(
                            checked = dontShowAgain,
                            onCheckedChange = { dontShowAgain = it },
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(dontShowAgainLabel)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (onConfirmWithDontShowAgain != null) {
                        onConfirmWithDontShowAgain(dontShowAgain)
                    } else {
                        onConfirm()
                    }
                },
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError,
                ),
            ) { Text(destructiveLabel, style = MaterialTheme.typography.labelLarge) }
        },
        dismissButton = {
            TextButton(onClick = onCancel) { Text(cancelLabel) }
        },
    )
}
