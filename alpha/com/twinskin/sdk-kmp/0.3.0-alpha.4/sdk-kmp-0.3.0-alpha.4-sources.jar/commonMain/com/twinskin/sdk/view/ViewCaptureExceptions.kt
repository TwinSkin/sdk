package com.twinskin.sdk.view

import com.twinskin.sdk.TwinSkinInternalApi

/**
 * Marker exceptions a [CaptureResolver] can throw so [ViewCaptureSession]
 * maps them to the corresponding [ViewCaptureError] variant. Any other
 * throwable becomes [ViewCaptureError.Unknown].
 *
 * Resolvers are free to keep throwing plain exceptions (e.g. a ktor
 * `ResponseException`) — the classifier falls through to Unknown in that
 * case. These types just let a resolver be explicit when it knows more.
 */
@TwinSkinInternalApi
public class CaptureNetworkException(
    message: String? = null,
    cause: Throwable? = null,
) : RuntimeException(message, cause)

@TwinSkinInternalApi
public class CaptureNotFoundException(
    message: String? = null,
) : RuntimeException(message)

@TwinSkinInternalApi
public class CaptureInvalidAssetException(
    public val reason: String,
) : RuntimeException(reason)

/**
 * Raised when a [CaptureSource.GlbUrl] `headersProvider` throws. Maps to
 * [ViewCaptureError.Credentials] so the viewer UI can show a
 * stage-specific message + Retry (which re-runs the provider).
 */
@TwinSkinInternalApi
public class CaptureCredentialsException(
    cause: Throwable,
) : RuntimeException("Failed to resolve credentials for asset download", cause)
