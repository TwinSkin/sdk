package com.twinskin.sdk.ui.view_capture

import com.twinskin.sdk.TwinSkinInternalApi

/** Callbacks [ViewCaptureScreen] invokes. One object so subviews can take only what they need. */
@TwinSkinInternalApi
public data class ViewCaptureActions(
    val onClose: () -> Unit = {},
    val onRetry: () -> Unit = {},
    /**
     * Tapped from the 2D pane's "Edit contour" affordance. `null` hides the
     * button — used by stateless previews/tests where editing is out of
     * scope, and by sources (LocalGlb / GlbUrl) that have no server-side
     * annotation to write back.
     */
    val onEditContour: (() -> Unit)? = null,
    /**
     * `true` while a `submitAnnotation` POST is in flight. Drives the 2D
     * pane's "Saving annotation…" pill. Resets to false once the POST
     * resolves (success or failure).
     */
    val isSavingAnnotation: Boolean = false,
)
