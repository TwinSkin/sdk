package com.twinskin.sdk.capture

import com.twinskin.sdk.sdk_client.GenericAnnotation as InternalGenericAnnotation
import com.twinskin.sdk.sdk_client.GenericRegion as InternalGenericRegion
import com.twinskin.sdk.sdk_client.Point2D as InternalPoint2D
import com.twinskin.sdk.sdk_client.SdkAnnotation as InternalSdkAnnotation
import com.twinskin.sdk.sdk_client.SdkCaptureStatus as InternalSdkCaptureStatus
import com.twinskin.sdk.sdk_client.TissueRegion as InternalTissueRegion
import com.twinskin.sdk.sdk_client.WoundAnnotation as InternalWoundAnnotation
import com.twinskin.sdk.sdk_client.WoundRegion as InternalWoundRegion

/**
 * Public SDK surface lives in `com.twinskin.sdk.capture`. These
 * aliases re-home the upload-client types the integrator references.
 *
 * Caveat: Kotlin/Native's Obj-C framework export doesn't surface
 * typealiases as nameable types — anything the Swift wrapper at
 * `packages/sdk/sdk-ios/` references by name must be a real Kotlin
 * class in `capture/`, not aliased here. See `ConditionType` in
 * `generate_kotlin_sdk_client.dart::_typeTargets`.
 */

public typealias SdkAnnotation = InternalSdkAnnotation
public typealias GenericAnnotation = InternalGenericAnnotation
public typealias WoundAnnotation = InternalWoundAnnotation
public typealias GenericRegion = InternalGenericRegion
public typealias WoundRegion = InternalWoundRegion
public typealias TissueRegion = InternalTissueRegion
public typealias Point2D = InternalPoint2D

internal typealias SdkCaptureStatus = InternalSdkCaptureStatus
