package com.twinskin.sdk.ui.annotation_editor.delineation.engine

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import com.twinskin.sdk.geometry.classifyRings
import com.twinskin.sdk.geometry.difference
import com.twinskin.sdk.geometry.pathToPolygons
import com.twinskin.sdk.geometry.pointInPolygon
import com.twinskin.sdk.geometry.polygonToPath
import com.twinskin.sdk.geometry.signedArea
import com.twinskin.sdk.geometry.union
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.reDensify
import kotlin.math.absoluteValue

/**
 * Double-tap region fill (web_app `discoverAtCanvasTap` parity):
 * returns the connected component of `wound \ covered` that contains
 * [tapImagePx], as a densified outline ready for
 * `EditorController.addPolygon` — or null when the tap doesn't sit
 * in fillable space (outside the wound, on an existing tissue, or
 * in a sub-[minArea] sliver), in which case the caller falls through
 * to the double-tap zoom toggle.
 *
 * [coveredOutlines] is every tissue outline of every type — the
 * screen passes the read-only other-type tissues plus the
 * controller's in-flight same-type polygons.
 *
 * **Ring selection.** The boolean difference encodes holes as extra
 * rings. The innermost ring containing the tap decides: a hole ring
 * means the tap actually sits on covered space that survived the
 * op's noise (refuse), an outer ring is the component to fill.
 * Same containment-depth classification as the auto-fill
 * (`classifyRings`) so the two fill paths can't disagree.
 */
internal fun fillRegionAt(
    woundOutline: List<Offset>,
    coveredOutlines: List<List<Offset>>,
    tapImagePx: Offset,
    minArea: Float,
): List<Offset>? {
    if (woundOutline.size < 3) return null
    if (!pointInPolygon(tapImagePx, woundOutline)) return null
    // Fast refusal: the tap sits on an existing tissue. Cheaper and
    // more robust than relying on the boolean op to carve an exact
    // hole under the finger.
    if (coveredOutlines.any { it.size >= 3 && pointInPolygon(tapImagePx, it) }) return null

    val woundPath = polygonToPath(woundOutline)
    val covered = coveredOutlines.filter { it.size >= 3 }.map { polygonToPath(it) }
    val remaining: Path = if (covered.isEmpty()) {
        woundPath
    } else {
        // Union-then-difference, with the auto-fill's per-tissue
        // sequential fallback when a Skia op bails (see
        // AutoFill.remainingPath for the rationale).
        val coveredUnion = covered.fold<Path, Path?>(Path()) { acc, p ->
            acc?.let { union(it, p) }
        }
        coveredUnion?.let { difference(woundPath, it) } ?: run {
            var r = woundPath
            for (p in covered) r = difference(r, p) ?: r
            r
        }
    }

    val rings = pathToPolygons(remaining).filter { it.size >= 3 }
    if (rings.isEmpty()) return null
    val holes = classifyRings(rings)
    var bestIdx = -1
    var bestArea = Float.MAX_VALUE
    for ((i, ring) in rings.withIndex()) {
        if (!pointInPolygon(tapImagePx, ring)) continue
        val area = signedArea(ring).absoluteValue
        if (area < bestArea) {
            bestArea = area
            bestIdx = i
        }
    }
    if (bestIdx < 0 || holes[bestIdx] || bestArea < minArea) return null
    return reDensify(rings[bestIdx])
}
