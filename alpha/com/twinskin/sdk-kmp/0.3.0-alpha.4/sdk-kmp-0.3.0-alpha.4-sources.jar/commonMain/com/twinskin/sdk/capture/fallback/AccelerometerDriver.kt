package com.twinskin.sdk.capture.fallback

import com.twinskin.sdk.ui.fallback.GuidanceSnapshot
import kotlin.math.PI
import kotlin.math.abs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Driver is not reusable; a second `start()` is a no-op. */
public interface AccelerometerDriver {
    public val angleThreshold: Double
    public fun start(): StateFlow<Pie>
    public fun stop(): VideoMetaData

    /**
     * Presentation-only signal published per accel sample, never written to
     * [VideoMetaData] or the bundle (recordings stay byte-identical). No-op
     * default keeps the ring/count/time with no cursor/cues.
     */
    public val guidance: StateFlow<GuidanceSnapshot>
        get() = NO_GUIDANCE
}

private val NO_GUIDANCE: StateFlow<GuidanceSnapshot> =
    MutableStateFlow(GuidanceSnapshot.UNRELIABLE).asStateFlow()

/** `accept*` methods MUST be called from a single producer thread per stream. */
internal class AccelerometerSampleAccumulator(
    val angleThreshold: Double,
) {
    val pie: MutableStateFlow<Pie> = MutableStateFlow(Pie.empty())

    val guidance: MutableStateFlow<GuidanceSnapshot> =
        MutableStateFlow(GuidanceSnapshot.UNRELIABLE)

    private var initialAcc: OrientationMath.Vec3? = null
    private val accEvents = mutableListOf<AccelerometerData>()
    private val userAccEvents = mutableListOf<AccelerometerData>()
    private val gyroEvents = mutableListOf<AccelerometerData>()
    private val magnetoEvents = mutableListOf<AccelerometerData>()

    // Latches across samples so the too-fast cue reads a stable rate, never
    // re-derived from the parity-locked event log.
    private var lastTheta: Double? = null
    private var lastThetaTsMs: Long? = null
    private var smoothedRate: Double = 0.0

    fun acceptAccelerometer(sample: AccelerometerData) {
        // web_app shape: the first sample latches gravity via
        // `stream.first` and is NOT appended to `_savedAccEvents`; only
        // subsequent events flow through `.listen(_onAccelemeterEvent)`,
        // which logs them. AC #3 calls for byte-identical JSON, so the
        // gravity-latch sample is dropped from the log here too.
        val initial = initialAcc ?: run {
            initialAcc = OrientationMath.Vec3(sample.x, sample.y, sample.z)
            return
        }
        accEvents += sample
        val v = OrientationMath.computeOrientationVector(
            initial,
            OrientationMath.Vec3(sample.x, sample.y, sample.z),
        )
        if (v.intensity >= angleThreshold) {
            pie.value = pie.value.copyWithAngle(v.theta)
        }
        publishGuidance(v, sample.timestampMilliseconds)
    }

    private fun publishGuidance(v: OrientationVector, tsMs: Long) {
        val prevTheta = lastTheta
        val prevTs = lastThetaTsMs
        // A non-finite orientation vector, or a sample after a huge gap (stream
        // dropped), marks the snapshot unreliable so the UI hides cursor + speed.
        val sampleFinite = v.theta.isFinite() && v.intensity.isFinite()
        val gapDropped = prevTs != null && (tsMs - prevTs) > MAX_RELIABLE_GAP_MS
        val reliable = sampleFinite && !gapDropped

        if (sampleFinite && prevTheta != null && prevTs != null) {
            val dtSec = (tsMs - prevTs).toDouble() / 1000.0
            if (dtSec > MIN_RATE_DT_SEC && !gapDropped) {
                // Shortest signed angular step so a ±π wrap isn't read as a huge spin.
                var delta = v.theta - prevTheta
                while (delta > PI) delta -= 2.0 * PI
                while (delta < -PI) delta += 2.0 * PI
                val instantRate = abs(delta) / dtSec
                smoothedRate += RATE_SMOOTHING * (instantRate - smoothedRate)
            }
        }
        // Only a finite sample updates the anchor; a NaN heading must not poison the next rate.
        if (sampleFinite) {
            lastTheta = v.theta
            lastThetaTsMs = tsMs
        }

        guidance.value = GuidanceSnapshot(
            headingRad = if (sampleFinite) v.theta else 0.0,
            headingRateRadPerSec = smoothedRate,
            // The SAME gate the pie write consults, so "Hold level" appears exactly when tilt stalls the sector.
            tiltBlocksSample = sampleFinite && v.intensity < angleThreshold,
            signalReliable = reliable,
        )
    }

    fun acceptUserAccelerometer(sample: AccelerometerData) {
        userAccEvents += sample
    }

    fun acceptGyroscope(sample: AccelerometerData) {
        gyroEvents += sample
    }

    fun acceptMagnetometer(sample: AccelerometerData) {
        magnetoEvents += sample
    }

    fun snapshotMetadata(): VideoMetaData = VideoMetaData(
        accelerometerData = if (accEvents.isEmpty()) null else accEvents.toList(),
        gyroscoptData = if (gyroEvents.isEmpty()) null else gyroEvents.toList(),
        userAccelerometerData =
            if (userAccEvents.isEmpty()) null else userAccEvents.toList(),
        // Magnetometer is intentionally excluded from the returned
        // payload — matches the web_app's `getSavedData`. The samples
        // are still gathered in [magnetoEvents] for parity with the
        // web_app's behaviour and to keep the door open for a future
        // sensor-fusion pass.
        magnetoscopeData = null,
    )
}

// One-pole EWMA so the ~200 Hz raw rate doesn't make the too-fast cue chatter;
// the floor guards a divide-by-near-zero on duplicate timestamps.
private const val RATE_SMOOTHING: Double = 0.12
private const val MIN_RATE_DT_SEC: Double = 0.001

// A gap ~2 orders of magnitude past the ~5 ms cadence means the IMU dropped (not
// jitter) → hide cursor; generous so normal operation never false-triggers.
private const val MAX_RELIABLE_GAP_MS: Long = 500L

public val DEFAULT_ANGLE_THRESHOLD: Double = PI / 6.0

public expect fun createAccelerometerDriver(angleThreshold: Double): AccelerometerDriver

public fun createAccelerometerDriver(): AccelerometerDriver =
    createAccelerometerDriver(DEFAULT_ANGLE_THRESHOLD)

internal fun MutableStateFlow<Pie>.readOnly(): StateFlow<Pie> = this.asStateFlow()
