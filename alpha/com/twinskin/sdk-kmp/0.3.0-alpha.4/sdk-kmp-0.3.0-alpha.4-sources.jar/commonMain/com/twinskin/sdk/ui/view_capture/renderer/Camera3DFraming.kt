@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.renderer

import com.twinskin.sdk.view.Model3DViewMetadata
import com.twinskin.sdk.view.Vector3
import kotlin.math.PI
import kotlin.math.tan

/**
 * Platform-agnostic framing decisions for the 3D viewer, shared by the Android
 * (Filament/SceneView) and iOS (SceneKit) renderers so the two stay in lock-step.
 *
 * The published GLB is re-oriented by the worker so the reference camera sits at
 * the origin looking down -Z. When marker-view metadata is present the mesh is
 * translated so the reference camera's optical-axis point lands on the origin,
 * the camera opens straight down -Z at the same depth, and the camera projection
 * matches the reference photo's FoV. When it's absent the renderer falls back to
 * centring the model's bounding box on the origin (today's behaviour).
 */
public object Camera3DFraming {

    /**
     * Translation to apply to the loaded model node so the framing reference
     * lands on the world origin.
     *
     * - With [metadata]: translate by `(0,0,-markerCenter.z)`, landing the
     *   reference camera's optical-axis point on the origin while keeping the
     *   marker off-axis (so the 3D view matches the 2D `ContentScale.Fit` framing,
     *   marker off-centre). Free orbit then pivots around that point.
     * - Without [metadata]: translate by `-boundingBoxCenter` (scaled to unit
     *   size by [unitScale]), the legacy bounding-box-centre behaviour.
     */
    public fun pivotTranslation(
        metadata: Model3DViewMetadata?,
        boundingBoxCenter: Vector3,
        unitScale: Float,
    ): Vector3 {
        if (metadata != null) {
            return Vector3(0f, 0f, -metadata.markerCenter.z)
        }
        return Vector3(
            -boundingBoxCenter.x * unitScale,
            -boundingBoxCenter.y * unitScale,
            -boundingBoxCenter.z * unitScale,
        )
    }

    /**
     * Initial camera position. With metadata the camera sits on +Z at the marker
     * depth (`(0,0,-markerCenter.z)`), looking straight down -Z at the
     * optical-axis point [pivotTranslation] lands on the origin — the baked
     * reference pose. Without metadata, fall back to a point [fallbackDistance]
     * in front of the origin along +Z.
     */
    public fun cameraPosition(
        metadata: Model3DViewMetadata?,
        fallbackDistance: Float,
    ): Vector3 =
        if (metadata != null) {
            Vector3(0f, 0f, -metadata.markerCenter.z)
        } else {
            Vector3(0f, 0f, fallbackDistance)
        }

    /**
     * Vertical field of view (degrees) to set on the camera, or null to keep the
     * renderer default when no metadata is available.
     */
    public fun fovYDeg(metadata: Model3DViewMetadata?): Float? = metadata?.fovYDeg

    /**
     * Decide the camera projection constraint that reproduces the 2D
     * `ContentScale.Fit` framing on a perspective camera looking down -Z with a
     * centered principal point.
     *
     * Reference aspect comes from the two reference FoVs:
     *   Aref = tan(fovX/2) / tan(fovY/2).
     * - viewport at least as wide as the reference (Avp >= Aref): height-limited,
     *   pin the VERTICAL FoV (the full image height fits; letterbox left/right).
     * - viewport narrower (Avp < Aref): width-limited, pin the HORIZONTAL FoV
     *   (the full image width fits; letterbox top/bottom).
     *
     * Falls back to VERTICAL-only (today's behaviour) when [fovXDeg] is null
     * (captures localized before #658) or the viewport aspect is non-positive.
     */
    public fun fovConstraint(
        fovYDeg: Float,
        fovXDeg: Float?,
        viewportAspect: Float,
    ): FovConstraint {
        if (fovXDeg == null || fovXDeg <= 0f || viewportAspect <= 0f) {
            return FovConstraint(FovAxis.VERTICAL, fovYDeg)
        }
        val halfX = (fovXDeg / 2f) * (PI.toFloat() / 180f)
        val halfY = (fovYDeg / 2f) * (PI.toFloat() / 180f)
        val refAspect = tan(halfX) / tan(halfY)
        return if (viewportAspect >= refAspect) {
            FovConstraint(FovAxis.VERTICAL, fovYDeg)
        } else {
            FovConstraint(FovAxis.HORIZONTAL, fovXDeg)
        }
    }

    /**
     * Metadata overload of [fovConstraint]; null when [metadata] is null,
     * mirroring [fovYDeg].
     */
    public fun fovConstraint(
        metadata: Model3DViewMetadata?,
        viewportAspect: Float,
    ): FovConstraint? {
        if (metadata == null) return null
        return fovConstraint(metadata.fovYDeg, metadata.fovXDeg, viewportAspect)
    }
}

/** Which FoV axis a renderer should pin to reproduce ContentScale.Fit (#658). */
public enum class FovAxis { VERTICAL, HORIZONTAL }

/** A resolved camera-projection constraint: pin [axis] to [fovDeg] degrees. */
public data class FovConstraint(val axis: FovAxis, val fovDeg: Float)
