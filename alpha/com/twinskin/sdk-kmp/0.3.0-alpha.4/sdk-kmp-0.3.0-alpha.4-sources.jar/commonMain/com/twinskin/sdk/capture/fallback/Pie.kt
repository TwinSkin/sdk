package com.twinskin.sdk.capture.fallback

import kotlin.math.PI
import kotlin.math.floor

/** Eight 45° sectors; one bool per sector flips true on the first in-band sample in that sector. */
public data class Pie(
    val capturedAngles: List<Boolean>,
) {
    public companion object {
        public const val NB_OF_SLICES: Int = 8

        public fun empty(): Pie = Pie(List(NB_OF_SLICES) { false })
    }

    public val percentage: Double
        get() = capturedAngles.count { it }.toDouble() / capturedAngles.size

    public val anglePerSection: Double
        get() = 2.0 * PI / capturedAngles.size

    public fun sectionOfAngle(angle: Double): Int {
        // Mirrors Dart's `((angle % (2π)) / anglePerSection).floor()`.
        // Kotlin's `%` keeps the sign of the dividend; emulate Dart's
        // always-non-negative `%` by adding 2π on the negative branch.
        val twoPi = 2.0 * PI
        var modded = angle % twoPi
        if (modded < 0) modded += twoPi
        return floor(modded / anglePerSection).toInt()
    }

    public fun copyWithAngle(angle: Double): Pie {
        val next = capturedAngles.toMutableList()
        next[sectionOfAngle(angle)] = true
        return Pie(next.toList())
    }
}
