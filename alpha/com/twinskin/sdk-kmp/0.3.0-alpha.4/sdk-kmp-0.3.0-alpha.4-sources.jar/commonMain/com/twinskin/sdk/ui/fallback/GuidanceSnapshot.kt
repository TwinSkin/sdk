package com.twinskin.sdk.ui.fallback

import com.twinskin.sdk.capture.fallback.Pie

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.floor

// Presentation-only: never written to VideoMetaData / the capture bundle, so it
// cannot affect measurement parity.
public data class GuidanceSnapshot(
    val headingRad: Double,
    val headingRateRadPerSec: Double,
    val tiltBlocksSample: Boolean,
    val signalReliable: Boolean = true,
) {
    public val headingDeg: Double
        get() {
            val twoPi = 2.0 * PI
            var m = headingRad % twoPi
            if (m < 0) m += twoPi
            return m / twoPi * 360.0
        }

    public val speed: CaptureSpeed
        get() {
            val degPerSec = abs(headingRateRadPerSec) / PI * 180.0
            return when {
                degPerSec > FAST_DEG_PER_SEC -> CaptureSpeed.Fast
                degPerSec < SLOW_DEG_PER_SEC -> CaptureSpeed.Slow
                else -> CaptureSpeed.Ok
            }
        }

    public companion object {
        public const val FAST_DEG_PER_SEC: Double = 55.0
        public const val SLOW_DEG_PER_SEC: Double = 6.0

        public val UNRELIABLE: GuidanceSnapshot = GuidanceSnapshot(
            headingRad = 0.0,
            headingRateRadPerSec = 0.0,
            tiltBlocksSample = false,
            signalReliable = false,
        )
    }
}

public enum class CaptureSpeed { Ok, Fast, Slow }

/**
 * Pure dial geometry, shared by the heading cursor / target / chevron renderer.
 * All angles are the SAME `theta` the recorded `Pie` consumes — **degrees,
 * 0 = 3 o'clock, increasing clockwise**. The drawn ring is mirrored about the
 * vertical axis at render time (see [polar]) so physical left/right read
 * correctly; this object's sector math is unaffected by that presentation-only
 * mirror.
 */
public object DialMath {
    public const val SECTORS: Int = Pie.NB_OF_SLICES
    public const val SECTOR_SWEEP_DEG: Float = 360f / SECTORS

    public fun headingSector(headingDeg: Double): Int {
        var m = headingDeg % 360.0
        if (m < 0) m += 360.0
        return (floor(m / SECTOR_SWEEP_DEG).toInt()) % SECTORS
    }

    public fun sectorCenterDeg(i: Int): Float = i * SECTOR_SWEEP_DEG + SECTOR_SWEEP_DEG / 2f

    public fun nextTarget(captured: List<Boolean>, headingDeg: Double): Int? {
        val here = headingSector(headingDeg)
        var best: Int? = null
        var bestDist = Int.MAX_VALUE
        for (k in 0 until SECTORS) {
            if (captured[k]) continue
            val d = minOf((k - here + SECTORS) % SECTORS, (here - k + SECTORS) % SECTORS)
            if (d < bestDist) { bestDist = d; best = k }
        }
        return best
    }
}
