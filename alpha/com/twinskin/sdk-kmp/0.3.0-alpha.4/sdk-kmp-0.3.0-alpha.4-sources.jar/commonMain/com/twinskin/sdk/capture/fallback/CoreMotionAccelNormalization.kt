package com.twinskin.sdk.capture.fallback

/**
 * Normalise an iOS CoreMotion accelerometer reading into the Android
 * `SensorManager` / `sensors_plus` frame BEFORE it feeds
 * [OrientationMath.computeOrientationVector] and lands in the recorded bundle.
 *
 * CoreMotion's `CMAccelerometerData.acceleration` (and `userAcceleration`) is
 * reported in **g** with the sign INVERTED versus Android `TYPE_ACCELEROMETER`
 * (which reports the specific force in m/s²). The web_app captures on iOS
 * through `sensors_plus`, whose iOS stream handler applies exactly
 * `x: -x*GRAVITY, y: -y*GRAVITY, z: -z*GRAVITY` (GRAVITY = 9.81) to "multiply by
 * gravity and adjust sign values to align with Android"
 * (`sensors_plus` 7.0.0, `FPPStreamHandlerPlus.swift`).
 *
 * The 9.81 scale cancels in the orientation math (intensity divides by the
 * initial-vector norm; theta is a projection angle) — but the SIGN does NOT.
 * Negating all three axes of both the latched gravity vector and the live sample
 * reflects the computed heading (`theta → −theta`), because the perpendicular
 * basis the math builds from the gravity unit vector flips handedness with it.
 * That reflection is the observed bug: iOS tilt LEFT filled the TOP sector and
 * TOP filled the RIGHT, mirrored versus Android. Applying the `sensors_plus`
 * transform here makes iOS recorded accelerometer data — and therefore the dial
 * heading — match Android and the web_app byte-for-byte in convention.
 *
 * Applied to BOTH the raw accelerometer stream (orientation input + recorded)
 * and the deviceMotion user-acceleration stream (recorded only). Gyroscope and
 * magnetometer are passed through unchanged — `sensors_plus` does not transform
 * them either.
 */
internal const val CORE_MOTION_GRAVITY: Double = 9.81

/**
 * `sensors_plus`'s iOS accel transform: negate every axis and scale by gravity.
 * Returns a ready-to-record [AccelerometerData] carrying the unmodified
 * [timestampMilliseconds].
 */
internal fun normalizeCoreMotionAccel(
    timestampMilliseconds: Long,
    x: Double,
    y: Double,
    z: Double,
): AccelerometerData = AccelerometerData(
    timestampMilliseconds = timestampMilliseconds,
    x = -x * CORE_MOTION_GRAVITY,
    y = -y * CORE_MOTION_GRAVITY,
    z = -z * CORE_MOTION_GRAVITY,
)
