@file:OptIn(TwinSkinInternalApi::class)

package com.twinskin.sdk

import com.twinskin.sdk.capture.CaptureEntry
import com.twinskin.sdk.capture.CaptureObserver
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.PendingUpload
import com.twinskin.sdk.capture.SdkCaptureMetadata
import com.twinskin.sdk.sdk_client.SdkAuthorizationProvider
import com.twinskin.sdk.sdk_client.fetchAndParseSessionToken
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.view.CaptureSource
import com.twinskin.sdk.view.ViewCaptureSession
import com.twinskin.sdk.view.resolvers.CaptureIdResolver
import com.twinskin.sdk.view.resolvers.HttpGlbResolver
import com.twinskin.sdk.view.resolvers.LocalGlbResolver
import kotlin.concurrent.Volatile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow

/**
 * Public façade for the TwinSkin SDK. Host apps only touch two entry
 * points:
 *
 * - `initialize(...)` — called once from the application entry point
 *   (Android: `fun TwinSkinSdk.initialize(app, config)` from androidMain;
 *   iOS: `fun TwinSkinSdk.initialize(config)` from iosMain).
 * - [startCapture] — open a fresh capture session; the `CaptureScreen`
 *   composable drives it.
 *
 * Everything inside the SDK is wired via constructor-injected components
 * (see [TwinSkinSdkComponent]). This object is only the final façade so
 * integrators don't have to assemble the graph themselves.
 */
public object TwinSkinSdk {
    /**
     * The installed wiring graph, or `null` before [initialize]. A
     * [MutableStateFlow] rather than a plain `@Volatile var` so the
     * observation surface ([captures]) can *await* init reactively
     * instead of throwing — see [DeferredCaptureObserver]. Reads that
     * genuinely require an initialized SDK still go through
     * [requireComponent], which throws as before.
     */
    private val componentState = MutableStateFlow<TwinSkinSdkComponent?>(null)

    private val component: TwinSkinSdkComponent?
        get() = componentState.value

    @Volatile
    private var localeOverride: String? = null

    /** Open a new capture session. The server is only contacted when the session is submitted. */
    public fun startCapture(metadata: SdkCaptureMetadata): CaptureSession =
        requireComponent().captureApi.startCapture(metadata)

    /**
     * Observe captures known to this SDK instance. The returned [CaptureObserver]
     * is a read-only view; it never drives capture lifecycle. See
     * [CaptureObserver.observePendingUploads] for the canonical use case
     * (background upload progress UI).
     *
     * Safe to read and collect before [initialize]: the returned observer is a
     * cold facade whose flows suspend until the SDK is initialized, then begin
     * emitting. This is what lets an integrator wire observation at app launch
     * (or navigate to a subject-scoped screen) without ordering it after init —
     * matching the SDK's lazy-init contract. Before this facade existed, reading
     * `captures` before init threw, which on iOS crossed the Kotlin/Native →
     * Swift boundary from a non-`@Throws` getter and aborted the host process.
     */
    public val captures: CaptureObserver
        get() = DeferredCaptureObserver

    /**
     * [CaptureObserver] facade that defers to the installed
     * [TwinSkinSdkComponent.captureObserver] once init lands. Each returned
     * flow is cold: on collection it awaits the first non-null component
     * ([awaitComponent]) and then streams the real observer's flow verbatim.
     * A collector started before init simply parks until the component is
     * installed; if the SDK is never initialized (e.g. an integrator whose
     * server config never arrives) the flow stays open and silent rather than
     * throwing.
     */
    private object DeferredCaptureObserver : CaptureObserver {
        override fun observePendingUploads(): Flow<List<PendingUpload>> =
            flow { emitAll(awaitComponent().captureObserver.observePendingUploads()) }

        override fun observeSubject(subjectRef: String): Flow<List<CaptureEntry>> =
            flow { emitAll(awaitComponent().captureObserver.observeSubject(subjectRef)) }

        override fun observeCapture(captureId: String, subjectRef: String): Flow<CaptureEntry?> =
            flow { emitAll(awaitComponent().captureObserver.observeCapture(captureId, subjectRef)) }
    }

    private suspend fun awaitComponent(): TwinSkinSdkComponent =
        componentState.filterNotNull().first()

    /**
     * `true` when [TwinSkinConfig.devMode] was set on init. Read by the
     * built-in capture screens to decide whether to surface the
     * "Use demo capture" affordance.
     */
    public val devMode: Boolean
        get() = requireComponent().devMode

    /**
     * `true` when [TwinSkinConfig.verboseFrameLogs] was set on init.
     * Read by the photosphere capture screens to decide whether to
     * write the on-device diagnostic sidecars — see the field on
     * [TwinSkinConfig] for the full list + storage footprint.
     */
    public val verboseFrameLogs: Boolean
        get() = requireComponent().verboseFrameLogs

    public val captureMode: CaptureMode
        get() = requireComponent().captureMode

    /**
     * The active locale override, or `null` when unset (or before init). The
     * runtime [setLocale] value wins over the init-time [TwinSkinConfig.locale];
     * the string layer reads this via [com.twinskin.sdk.i18n.sdkLocale] and
     * falls back to the device locale when it is `null`. Non-throwing so string
     * resolution stays safe outside an initialized SDK.
     */
    internal val configuredLocale: String?
        get() = localeOverride ?: component?.locale

    /**
     * Override the SDK UI locale at runtime. Takes precedence over
     * [TwinSkinConfig.locale] and the device locale for any built-in SDK screen
     * (capture + annotation editor) opened *after* this call — screens already
     * on-screen keep their resolved locale until reopened. Pass a language tag
     * such as `"fr"`, or `null` to clear the override and fall back to the
     * init-time config / device locale. Thread-safe and safe to call before
     * `initialize(...)`. See `packages/sdk/docs/translations.md`.
     */
    public fun setLocale(locale: String?) {
        localeOverride = locale
    }

    /**
     * Diagnostic surface — see [TwinSkinDebug]. Not part of the stable
     * public API; the schema can change in any minor release.
     */
    public val debug: TwinSkinDebug
        get() = TwinSkinDebug(requireComponent())

    /**
     * View a previously-captured 3D model. Returns a [ViewCaptureSession] whose
     * `state` StateFlow the host Compose screen observes. Close the session
     * when the screen is torn down.
     */
    public fun viewCapture(source: CaptureSource): ViewCaptureSession {
        val component = requireComponent()
        val resolver = when (source) {
            is CaptureSource.LocalGlb -> LocalGlbResolver(source.path)
            is CaptureSource.GlbUrl -> HttpGlbResolver(
                url = source.url,
                cacheDir = component.storage.dir(Purpose.ViewCapture),
                headersProvider = source.headersProvider,
                logger = component.logger,
            )
            is CaptureSource.CaptureId -> {
                val serverClient = component.serverClient
                CaptureIdResolver(
                    captureId = source.id,
                    subjectRef = source.subjectRef,
                    captureObserver = component.captureObserver,
                    assetUrlBuilder = { s3Key ->
                        // The /asset redirect endpoint is session-token authenticated.
                        // The 302 target is a presigned S3 URL that expects no auth —
                        // headers are stripped on redirect by `downloadToPath`.
                        val tokens = serverClient.auth.fetchAndParseSessionToken(
                            source.subjectRef,
                            component.logger,
                        )
                        val url = "${serverClient.apiBaseUrl}/asset?key=$s3Key"
                        val headers = mapOf(
                            io.ktor.http.HttpHeaders.Authorization to "Bearer ${tokens.token}",
                            "X-Publishable-Key" to serverClient.publishableKey,
                        )
                        url to headers
                    },
                    cacheDir = component.storage.dir(com.twinskin.sdk.storage.Purpose.ViewCapture),
                    downloadAsset = { url, destPath, headers ->
                        com.twinskin.sdk.view.downloadToPath(
                            url = url,
                            destPath = destPath,
                            headers = headers,
                            onProgress = { _, _ -> },
                        )
                    },
                    logger = component.logger,
                )
            }
        }
        return ViewCaptureSession(resolver, logger = component.logger)
    }

    /**
     * Idempotent: a second call is a no-op so hosts that (for example) wire
     * initialization from both an `Application` and a splash screen don't have
     * to guard it themselves. Any [TwinSkinSdkComponent] built for the second
     * call is discarded.
     */
    internal fun install(built: TwinSkinSdkComponent): Boolean =
        componentState.compareAndSet(null, built)

    /**
     * Whether [initialize] has run in this process. SDK-owned Android
     * activities consult this on create: after a background process
     * death the system restores them before the host app re-initializes
     * the SDK, and composing against a missing component would crash.
     *
     * Not `@TwinSkinInternalApi`: the iOS presenter layer gates SDK-screen
     * presentation on this across the ObjC/Swift bridge, where opt-in-gated
     * declarations aren't emitted into the generated framework header.
     */
    public val isInitialized: Boolean get() = component != null

    internal fun requireComponent(): TwinSkinSdkComponent =
        component ?: error("TwinSkinSdk.initialize(...) must be called before using the SDK.")

    /** For tests only — clears the installed component so the next `initialize` succeeds. */
    internal fun resetForTests() {
        componentState.value = null
        localeOverride = null
    }
}

/**
 * Integrator-supplied configuration. [baseUrl] is the Twinskin API server's
 * scheme+host(+port) root — e.g. `https://prod.dermatoo.com` — and defaults
 * to production; demo / local-dev hosts pass an override. The SDK appends
 * `/api/sdk` for API calls and `/powersync` for the realtime stream itself,
 * so integrators only configure the host once.
 */
public data class TwinSkinConfig(
    val publishableKey: String,
    val authorizationProvider: SdkAuthorizationProvider,
    val baseUrl: String = PROD_BASE_URL,
    /** `null` → [SdkLogger.Console]; pass [SdkLogger.None] to silence. */
    val logger: SdkLogger? = null,
    /** Minimum level reaching [logger]; `null` → [effectiveLogLevel]. */
    val logLevel: SdkLogLevel? = null,
    /**
     * When true, the camera screen surfaces a "Use demo capture" button that
     * downloads a server-served capture and submits it through the normal
     * upload pipeline. Intended for QA / demo / integrator-test builds; leave
     * `false` in production.
     */
    val devMode: Boolean = false,
    /**
     * Umbrella opt-in for the SDK's on-device diagnostic sidecars:
     * `frame_log.jsonl`, `pose_log.json`, `reference_keypoints.json`,
     * and the per-Nth analyser-frame grayscale JPEGs under
     * `live_frames/`. None of these ever ride the encrypted upload
     * bundle (the tar packer whitelists `view_NN_rXaY.jpg` only), but
     * when `true` they accumulate ~25–120 MB per capture in the app
     * sandbox. Default `false` so a Release build is silent on disk;
     * integrators flip it on for field-issue triage.
     */
    val verboseFrameLogs: Boolean = false,
    /**
     * Which capture pipeline this SDK instance launches when
     * [TwinSkin.startCapture] is called. Default
     * [CaptureMode.AccelerometerCapture] (the Capture V2 fallback —
     * accelerometer + video — pipeline); [CaptureMode.Photosphere] opts
     * into the marker-validated photosphere screen. The selected mode is
     * stamped on every persisted capture row so the upload pipeline can
     * pick the matching bundle layout long after the originating session
     * has ended.
     */
    val captureMode: CaptureMode = CaptureMode.AccelerometerCapture,
    /**
     * Integrator locale override for the SDK's built-in UI (capture screens and
     * annotation editor). `null` (default) uses the device locale. A language
     * tag such as `"fr"`; the SDK falls back to English for any locale it does
     * not ship yet. See `packages/sdk/docs/translations.md`.
     */
    val locale: String? = null,
    /**
     * **Dev/test only.** When [devMode] is `true` and this provider returns a
     * positive byte count, the capture pipeline appends an extra
     * `debug_padding.bin` entry of that size to the encrypted bundle before
     * upload — a way to exercise large-bundle upload resilience without
     * producing a real capture that big. The entry is deliberately kept out
     * of the manifest so only the upload path carries it. Invoked once per
     * submit. `null` (default) and non-dev builds inject nothing.
     */
    @TwinSkinInternalApi
    val debugBundlePaddingBytesProvider: (() -> Long)? = null,
) {
    /**
     * The capture mode actually used at launch. Mode selection is a
     * dev-only capability in this version: production (`devMode = false`)
     * always runs [CaptureMode.AccelerometerCapture] regardless of
     * [captureMode]; only `devMode = true` honours an explicit choice.
     */
    internal val effectiveCaptureMode: CaptureMode
        get() = if (devMode) captureMode else CaptureMode.AccelerometerCapture

    /**
     * Resolved padding-byte source for the capture pipeline. Inert (always
     * `0`) unless [devMode] is set and a provider was supplied, so the
     * injection is unreachable in a production build regardless of the
     * field value. Negative provider results are clamped to `0`.
     */
    internal val effectiveDebugBundlePaddingBytes: () -> Long
        @OptIn(TwinSkinInternalApi::class)
        get() {
            val provider = debugBundlePaddingBytesProvider
            return if (devMode && provider != null) {
                { provider().coerceAtLeast(0L) }
            } else {
                { 0L }
            }
        }

    /** Explicit [logLevel], else [SdkLogLevel.Debug] in dev / [SdkLogLevel.Warning] in prod. */
    internal val effectiveLogLevel: SdkLogLevel
        get() = logLevel ?: if (devMode) SdkLogLevel.Debug else SdkLogLevel.Warning

    internal val effectiveLogger: SdkLogger
        get() = LevelFilteringLogger(effectiveLogLevel, logger ?: SdkLogger.Console)

    public companion object {
        public const val PROD_BASE_URL: String = "https://prod.dermatoo.com"
    }
}
