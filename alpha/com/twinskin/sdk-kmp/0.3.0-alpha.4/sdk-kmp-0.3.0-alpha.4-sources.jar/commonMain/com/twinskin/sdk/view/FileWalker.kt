package com.twinskin.sdk.view

/** Recursively list .glb files inside [dir]. Returns absolute paths. */
internal expect fun listGlbFiles(dir: String): List<String>
