package com.twinskin.sdk.ui.annotation_editor.polygon.engine

import androidx.compose.ui.geometry.Offset
import com.twinskin.sdk.geometry.densifyInPlace

/**
 * Re-densifies [poly] so every consecutive vertex pair sits in
 * `[min, max]` image-pixel spacing. Convenience wrapper around the
 * mutable-in-place [densifyInPlace] primitive — returns a fresh
 * immutable list so callers can drop it straight into the
 * controller's `_polygons` slot or into the M9 boundary builder.
 *
 * Defaults `[2, 10]` track the spec's "~5 image-px" sampling
 * convention (convergent average ≈ `(min + max) / 2`).
 *
 * Called at three places in the pipeline:
 *   1. closure commit (M4 `commitClosure`) — densify the just-closed
 *      polygon's stitched-from-EMA samples;
 *   2. reshape commit (M5 `onTouchUp(Reshape)`) — re-normalise after
 *      vertices were pushed around by the cosine falloff + relax;
 *   3. M9 `toWoundAnnotation` boundary — final pass before emit.
 */
internal fun reDensify(
    poly: List<Offset>,
    min: Float = 2f,
    max: Float = 10f,
): List<Offset> {
    val mutable = poly.toMutableList()
    densifyInPlace(mutable, minSpacingPx = min, maxSpacingPx = max, closed = true)
    return mutable.toList()
}
