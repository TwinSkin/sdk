@file:OptIn(ExperimentalMaterial3Api::class, com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.twinskin.sdk.i18n.sdkLocale
import com.twinskin.sdk.ui.capture.i18n.captureStringsFor
import com.twinskin.sdk.ui.theme.TwinSkinTheme
import com.twinskin.sdk.ui.view_capture.subview.ViewCaptureErrorView
import com.twinskin.sdk.ui.view_capture.subview.ViewCaptureLoadingView
import com.twinskin.sdk.ui.view_capture.subview.ViewCaptureReadyView
import com.twinskin.sdk.ui.view_capture.subview.ViewCaptureTopBar
import com.twinskin.sdk.view.ViewCaptureState

/**
 * Stateless screen. Takes a [ViewCaptureState] and an [ViewCaptureActions]
 * and renders the appropriate subview on the dark viewer stage — no IO, no
 * coroutines, no platform deps. Use [ViewCaptureScreenHost] when you want the
 * screen to own a [com.twinskin.sdk.view.ViewCaptureSession]; use this
 * composable directly in tests and previews.
 *
 * The translucent close/title top bar floats over the stage. Loading and
 * Error get a fixed-title bar here; Ready owns its own bar so the title can
 * flip "3D Viewer" / "2D View" with the active tab.
 */
@TwinSkinInternalApi
@Composable
public fun ViewCaptureScreen(
    state: ViewCaptureState,
    actions: ViewCaptureActions = ViewCaptureActions(),
) {
    TwinSkinTheme {
        val strings = remember { captureStringsFor(sdkLocale()) }
        Box(Modifier.fillMaxSize()) {
            when (state) {
                is ViewCaptureState.Loading -> {
                    ViewCaptureLoadingView(state.progress)
                    ViewCaptureTopBar(title = strings.viewerTitle, onClose = actions.onClose)
                }
                is ViewCaptureState.Error -> {
                    ViewCaptureErrorView(state.error, actions.onRetry)
                    ViewCaptureTopBar(title = strings.viewerTitle, onClose = actions.onClose)
                }
                is ViewCaptureState.Ready -> ViewCaptureReadyView(
                    ready = state,
                    onClose = actions.onClose,
                    onEditContour = actions.onEditContour,
                    isSavingAnnotation = actions.isSavingAnnotation,
                )
            }
        }
    }
}
