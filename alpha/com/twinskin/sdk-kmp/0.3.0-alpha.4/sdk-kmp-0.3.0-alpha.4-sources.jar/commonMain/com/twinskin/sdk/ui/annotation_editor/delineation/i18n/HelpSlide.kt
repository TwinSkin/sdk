package com.twinskin.sdk.ui.annotation_editor.delineation.i18n

import androidx.compose.runtime.Composable

/**
 * One slide in the per-screen help dialog.
 *
 * The optional [diagram] field is an inline `@Composable` lambda
 * that the help dialog renders between the title and body. v1
 * ships diagrams for the 8 gesture slides (4 wound + 4 tissue);
 * the 4 non-gesture slides leave [diagram] null and stay
 * text-only. Diagrams reuse the canvas painters
 * (`drawClosedPolygon`, `drawDashedWound`, `drawOpenStroke`,
 * `drawFirstPointHalo`, `clinicalColorFor`) so help matches the
 * drawing surface exactly.
 */
internal data class HelpSlide(
    val title: String,
    val body: String,
    val diagram: (@Composable () -> Unit)? = null,
)

/**
 * All four screens' help slide lists. Slide counts match
 * spec §M12: Intro = 2, WoundDrawing = 4, TissueDashboard = 2,
 * TissueDrawing = 4. M12 ships v1 EN content with diagrams on
 * the gesture slides; M14b's golden tests lock the visual
 * contract.
 */
internal data class HelpSlideStrings(
    val intro: List<HelpSlide>,
    val woundDrawing: List<HelpSlide>,
    val tissueDashboard: List<HelpSlide>,
    val tissueDrawing: List<HelpSlide>,
)
