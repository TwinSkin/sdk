package com.twinskin.sdk.ui.annotation_editor.polygon.orientation

import androidx.compose.runtime.Composable

/**
 * Locks the host platform's UI orientation for the duration of the
 * surrounding composition (spec §13.5). M13's root composable
 * (`WoundAnnotationEditor`) calls this once at the top of its
 * body so the canvas geometry doesn't change mid-session.
 *
 * **Per-platform behaviour:**
 *  - **Android.** Uses the host [android.app.Activity]'s
 *    `requestedOrientation = SCREEN_ORIENTATION_LOCKED`, then
 *    restores the previous value on dispose. Whatever orientation
 *    the clinician started in is frozen; rotating the device
 *    mid-session is a no-op.
 *  - **iOS.** Increments [OrientationLockCounter.depth] on enter,
 *    decrements on dispose. The integrator's `AppDelegate` reads
 *    `TwinSkin.uiKit.preferredOrientationMask` from
 *    `supportedInterfaceOrientationsFor` to honour the SDK's
 *    intent. See `TwinSkinUiKit` for the wiring snippet.
 *  - **JVM (tests).** No-op. The lock has no headless analogue.
 *
 * **Re-entrance.** The counter (and the per-platform behaviour
 * built on it) is re-entrant via [OrientationLockCounter]: a
 * future composable that nests `LockOrientationDuringSession`
 * inside another instance increments the depth twice and only
 * relinquishes the lock when both dispose.
 */
@Composable
internal expect fun LockOrientationDuringSession()

/**
 * Re-entrant lock counter — public surface for the iOS
 * `TwinSkinUiKit` and the test target. Always accessed from the
 * main thread (Compose's recomposition + DisposableEffect cleanup
 * both run on the main thread); no atomic / lock required.
 *
 * **Capped at zero.** A spurious [exit] without a matching [enter]
 * is silently absorbed (depth stays at 0) rather than going
 * negative — the iOS mask getter wouldn't notice the difference,
 * but a future caller might iterate depth and get confused by a
 * negative value.
 */
internal object OrientationLockCounter {
    private var _depth: Int = 0

    /** Current lock depth. Zero ⇒ no session active, > 0 ⇒ at least one. */
    val depth: Int get() = _depth

    /** Increments the depth on session entry. */
    fun enter() {
        _depth++
    }

    /** Decrements the depth on session exit. Capped at zero. */
    fun exit() {
        if (_depth > 0) _depth--
    }

    /** Test-only — resets the depth between iterations. */
    internal fun resetForTests() {
        _depth = 0
    }
}
