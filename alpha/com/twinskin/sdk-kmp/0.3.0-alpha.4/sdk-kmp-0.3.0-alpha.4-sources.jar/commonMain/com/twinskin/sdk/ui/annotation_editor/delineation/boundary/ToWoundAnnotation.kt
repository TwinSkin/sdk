package com.twinskin.sdk.ui.annotation_editor.delineation.boundary

import androidx.compose.ui.geometry.Size
import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.Point2D
import com.twinskin.sdk.capture.TissueRegion
import com.twinskin.sdk.capture.WoundAnnotation
import com.twinskin.sdk.capture.WoundRegion
import com.twinskin.sdk.debug
import com.twinskin.sdk.geometry.reduceToRelevants
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound

/**
 * Boundary helper (spec §11.1). Turns the editor's internal [Wound]
 * list into the wire-shape [WoundAnnotation] the server consumes.
 *
 * Pipeline per wound:
 *  1. `reduceToRelevants(outline, 177°)` — collapse near-collinear
 *     runs into significant corners. This is the topology-preserving
 *     step that defines the wire shape. Densification is **not** run
 *     here — closure (M6) and reshape commit (M6) already produce
 *     polygons at canonical `[2, 10]` image-px spacing, and
 *     densifying before reducing would only add points the reducer
 *     would strip again.
 *  2. Reject if `reduced.size < 3` — spec §11.1 integrity case. A
 *     wound whose outline collapsed to a line or a point is a bug
 *     somewhere upstream (the controller should never let one
 *     commit), so we fail fast with [IllegalStateException] rather
 *     than silently dropping it.
 *  3. Same reduce for each tissue, but **non-fatal**: tissues that
 *     collapse to `<3` significant points are logged and dropped.
 *     Tissues are best-effort context for the wound; a degenerate
 *     tissue shouldn't lose the entire wound annotation.
 *  4. Normalise to `[0, 1]` via `(x / imageSize.width, y / imageSize.height)`
 *     — spec §11.1's coordinate convention. `Point2D` stores `Double`,
 *     so the conversion widens float-precision Compose offsets at
 *     the boundary (negligible — the polygons came from finger
 *     touches sampled to single-pixel precision).
 *
 * `TissueType.wire` is the round-trip key for the unknown-string
 * carrier ([Other]); known types (Necrosis/Slough/Granulation)
 * emit their canonical lowercase wire names verbatim per
 * decision C.
 *
 * **Containment.** Tissue-inside-wound containment is the runtime
 * gesture-loop's contract (per-vertex clamp + segment-crossing
 * detector — see [EditorController]); the boundary trusts that
 * invariant and does not re-verify it. `ToWoundAnnotationPropertyTest`
 * pins the contract from the boundary side by generating tissues
 * that lie inside their parent wound and asserting every emitted
 * tissue contour stays inside its wound contour.
 *
 * @param wounds      editor-side wounds, with outlines in image-px.
 * @param imageSize   source image size, used for normalisation.
 * @param logger      optional sink for dropped-tissue warnings. M13's
 *                    root composable supplies the SDK's logger via
 *                    `TwinSkinSdk.requireComponent().logger`; tests
 *                    pass a fake or `null`.
 */
internal fun toWoundAnnotation(
    wounds: List<Wound>,
    imageSize: Size,
    logger: SdkLogger? = null,
): WoundAnnotation {
    require(imageSize.width > 0f && imageSize.height > 0f) {
        "imageSize must be positive (got $imageSize)"
    }
    val regions = wounds.mapIndexed { woundIdx, wound ->
        val reducedOutline = reduceToRelevants(wound.outline, angleThresholdDeg = 177f)
        check(reducedOutline.size >= 3) {
            "Wound $woundIdx collapsed to ${reducedOutline.size} significant points after reduction — " +
                "outline must have at least 3 vertices after near-collinear filtering."
        }
        val tissueRegions = wound.tissues.mapIndexedNotNull { tissueIdx, tissue ->
            val reducedTissue = reduceToRelevants(tissue.outline, angleThresholdDeg = 177f)
            if (reducedTissue.size < 3) {
                logger?.debug(
                    "toWoundAnnotation: dropping tissue $tissueIdx of wound $woundIdx — " +
                        "outline collapsed to ${reducedTissue.size} significant points after reduction.",
                )
                null
            } else {
                TissueRegion(
                    tissueType = tissue.type.wire,
                    contour = reducedTissue.toPoint2DContour(imageSize),
                )
            }
        }
        WoundRegion(
            contour = reducedOutline.toPoint2DContour(imageSize),
            tissues = tissueRegions,
        )
    }
    return WoundAnnotation(regions = regions)
}

private fun List<androidx.compose.ui.geometry.Offset>.toPoint2DContour(imageSize: Size): List<Point2D> {
    val w = imageSize.width.toDouble()
    val h = imageSize.height.toDouble()
    return map { Point2D(x = it.x.toDouble() / w, y = it.y.toDouble() / h) }
}
