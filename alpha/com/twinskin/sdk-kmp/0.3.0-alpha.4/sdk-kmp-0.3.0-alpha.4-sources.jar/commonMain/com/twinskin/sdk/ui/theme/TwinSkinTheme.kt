package com.twinskin.sdk.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The display family used across the brand. The mobile app ships Montserrat;
 * bundling the actual `.ttf` into the KMP SDK is blocked by the documented
 * Compose-Multiplatform `composeResources` packing bug (see the SDK
 * `CLAUDE.md` "demo-shared can't use Compose Resources" note), so for now we
 * apply the Montserrat-specified type *scale* (sizes / weights / tracking) on
 * top of [FontFamily.Default]. When the font is bundled, this is the single
 * line to swap.
 */
internal val TwinSkinFontFamily: FontFamily = FontFamily.Default

/**
 * Brand color scheme. Brand tokens from [TwinSkinColors] mapped onto the
 * Material3 roles the SDK's editor / viewer / transfer composables already
 * consume (`primary`, `surfaceVariant`, `error`, `outline`, …). Light only —
 * the capture module owns its dark scheme.
 */
private val TwinSkinColorScheme = lightColorScheme(
    // The prototype's filled primary CTA is SLATE, with teal/cyan as accents.
    primary = TwinSkinColors.Slate,
    onPrimary = TwinSkinColors.OnTeal,
    primaryContainer = TwinSkinColors.TintHi,
    onPrimaryContainer = TwinSkinColors.Ink,
    secondary = TwinSkinColors.Teal,
    onSecondary = TwinSkinColors.OnTeal,
    secondaryContainer = TwinSkinColors.TintHi,
    onSecondaryContainer = TwinSkinColors.Ink,
    tertiary = TwinSkinColors.Cyan,
    onTertiary = TwinSkinColors.OnCyan,
    tertiaryContainer = TwinSkinColors.CyanSoft,
    onTertiaryContainer = TwinSkinColors.Ink,
    error = TwinSkinColors.Error,
    onError = TwinSkinColors.OnTeal,
    errorContainer = TwinSkinColors.WarningContainer,
    onErrorContainer = TwinSkinColors.Warning,
    background = TwinSkinColors.Surface,
    onBackground = TwinSkinColors.Ink,
    surface = TwinSkinColors.Surface,
    onSurface = TwinSkinColors.OnSurface,
    surfaceVariant = TwinSkinColors.TintMid,
    onSurfaceVariant = TwinSkinColors.OnSurfaceVariant,
    outline = TwinSkinColors.Line,
    outlineVariant = TwinSkinColors.TintHi,
)

/**
 * Type scale per spec §03. Roles map onto Material3 text styles: Display →
 * headline*, Title → title*, Body → body*, Label/button → label*. UPPERCASE
 * + tracking on buttons is applied at the call site / component, not baked
 * into the style.
 */
private val TwinSkinTypography = Typography().run {
    copy(
        headlineLarge = headlineLarge.copy(
            fontFamily = TwinSkinFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 30.sp,
            lineHeight = 34.sp,
        ),
        headlineMedium = headlineMedium.copy(
            fontFamily = TwinSkinFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 27.sp,
            lineHeight = 31.sp,
        ),
        titleLarge = titleLarge.copy(
            fontFamily = TwinSkinFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 22.sp,
            lineHeight = 28.sp,
        ),
        titleMedium = titleMedium.copy(
            fontFamily = TwinSkinFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 18.sp,
            lineHeight = 24.sp,
        ),
        titleSmall = titleSmall.copy(
            fontFamily = TwinSkinFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp,
            lineHeight = 20.sp,
        ),
        bodyLarge = bodyLarge.copy(
            fontFamily = TwinSkinFontFamily,
            fontSize = 16.sp,
            lineHeight = 24.sp,
        ),
        bodyMedium = bodyMedium.copy(
            fontFamily = TwinSkinFontFamily,
            fontSize = 15.sp,
            lineHeight = 22.sp,
        ),
        bodySmall = bodySmall.copy(
            fontFamily = TwinSkinFontFamily,
            fontSize = 13.sp,
            lineHeight = 18.sp,
        ),
        labelLarge = labelLarge.copy(
            fontFamily = TwinSkinFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            letterSpacing = 0.6.sp,
        ),
        labelMedium = labelMedium.copy(
            fontFamily = TwinSkinFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            letterSpacing = 0.5.sp,
        ),
        labelSmall = labelSmall.copy(
            fontFamily = TwinSkinFontFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            letterSpacing = 0.5.sp,
        ),
    )
}

/** Corner radii per spec §04: buttons/small 12, cards/medium 16, sheets/large 24. */
private val TwinSkinShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

/**
 * Drop-in brand theme. Each SDK entry-point composable (viewer, editors,
 * transfers) wraps its content in this so the TwinSkin identity renders
 * regardless of the host/partner app's own [MaterialTheme]. Light surfaces
 * only; capture screens keep their dedicated dark scheme.
 */
@Composable
internal fun TwinSkinTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TwinSkinColorScheme,
        typography = TwinSkinTypography,
        shapes = TwinSkinShapes,
        content = content,
    )
}

/** Plain-label text style for the spec's UPPERCASE button labels (+0.6 tracking). */
internal val ButtonLabelStyle: TextStyle
    @Composable get() = MaterialTheme.typography.labelLarge
