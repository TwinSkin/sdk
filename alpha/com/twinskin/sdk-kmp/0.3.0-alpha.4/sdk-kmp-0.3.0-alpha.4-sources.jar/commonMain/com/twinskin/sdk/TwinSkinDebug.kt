package com.twinskin.sdk

import com.twinskin.sdk.db.TransferTask
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.TransferType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Diagnostic surface. NOT a stable API — the schema can change in any
 * minor release. Intended for the SDK's own demo apps and for
 * integrators triaging field issues with us. Do not build product
 * features against this; use [TwinSkinSdk.captures] instead.
 */
public class TwinSkinDebug internal constructor(private val component: TwinSkinSdkComponent) {
    /**
     * Snapshot stream of every transfer the SDK has scheduled
     * (capture-bundle uploads + asset downloads), keyed by SDK-internal
     * id. Cold flow — work only happens while a collector is active.
     */
    public fun observeTransfers(): Flow<List<TransferSnapshot>> =
        component.transferManager.observeAllTasks()
            .map { tasks -> tasks.map(::toSnapshot) }

    private fun toSnapshot(task: TransferTask): TransferSnapshot = TransferSnapshot(
        id = task.id,
        kind = TransferSnapshot.Kind.fromWire(task.type),
        status = TransferSnapshot.Status.fromWire(task.status),
        progressPercent = task.progress.toInt(),
        errorMessage = task.errorMessage,
    )
}

/**
 * Snapshot of one in-flight or terminal transfer as observed by
 * [TwinSkinDebug.observeTransfers]. Diagnostic only — fields may be
 * added or removed between SDK versions.
 */
public data class TransferSnapshot(
    val id: String,
    val kind: Kind,
    val status: Status,
    val progressPercent: Int,
    val errorMessage: String?,
) {
    public enum class Kind {
        Upload,
        Download;

        internal companion object {
            fun fromWire(raw: String): Kind = when (raw) {
                TransferType.UPLOAD.name -> Upload
                TransferType.DOWNLOAD.name -> Download
                else -> error("Unknown transfer type: $raw")
            }
        }
    }

    public enum class Status {
        Pending,
        Active,
        Unzipping,
        Completed,
        Failed,
        Cancelled;

        internal companion object {
            fun fromWire(raw: String): Status = when (raw) {
                TransferStatus.PENDING.name -> Pending
                TransferStatus.ACTIVE.name -> Active
                TransferStatus.UNZIPPING.name -> Unzipping
                TransferStatus.COMPLETED.name -> Completed
                TransferStatus.FAILED.name -> Failed
                TransferStatus.CANCELLED.name -> Cancelled
                else -> error("Unknown transfer status: $raw")
            }
        }
    }
}
