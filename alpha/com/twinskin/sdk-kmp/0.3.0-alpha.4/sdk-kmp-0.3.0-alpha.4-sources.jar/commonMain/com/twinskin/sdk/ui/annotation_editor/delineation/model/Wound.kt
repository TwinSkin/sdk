package com.twinskin.sdk.ui.annotation_editor.delineation.model

import androidx.compose.runtime.Immutable
import androidx.compose.ui.geometry.Offset

/**
 * One wound — closed polygon in image-pixel coordinates plus the
 * tissue regions nested inside it.
 *
 * Defensive-copies both the [outline] and [tissues] lists at
 * construction (per plan §M2 note: "never mutate the lists
 * post-construction" applies to all caller-provided lists, not just
 * the polygon). Each `Tissue` child also defensive-copies its own
 * polygon — the two defenses together rule out the class of bugs
 * where a caller hangs onto a list reference and mutates it under the
 * editor's feet, bypassing the store's revision bump.
 *
 * Hand-rolled (not `data class`) for the same reason as [Tissue]:
 * Kotlin's `data class` doesn't let `init {}` re-assign val fields.
 */
@Immutable
internal class Wound(
    outline: List<Offset>,
    tissues: List<Tissue> = emptyList(),
) {
    val outline: List<Offset> = outline.toList()
    val tissues: List<Tissue> = tissues.toList()

    fun copy(outline: List<Offset> = this.outline, tissues: List<Tissue> = this.tissues): Wound =
        Wound(outline, tissues)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is Wound) return false
        return outline == other.outline && tissues == other.tissues
    }

    override fun hashCode(): Int = 31 * outline.hashCode() + tissues.hashCode()

    override fun toString(): String = "Wound(outline=$outline, tissues=$tissues)"
}
