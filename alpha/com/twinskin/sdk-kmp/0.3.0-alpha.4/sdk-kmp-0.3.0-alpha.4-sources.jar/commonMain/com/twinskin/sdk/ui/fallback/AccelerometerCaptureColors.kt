package com.twinskin.sdk.ui.fallback

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
public data class AccelerometerCaptureColors(
    val surface: Color = Color(0xFF0F1416),
    val onSurface: Color = Color(0xFFDEE3E5),
    val error: Color = Color(0xFFFF6F61),
    val orbit: Color = Color(0xFF48CAE4),
    val orbitInactive: Color = Color(0x38FFFFFF),
    val progress: Color = Color(0xFFD32F2F),
    val progressComplete: Color = Color(0xFF00BF63),
    val scrim: Color = Color(0xCC000000),
    val errorScrim: Color = Color(0xE6000000),
    val topBarBackground: Color = Color(0x99000000),
    val onPrimary: Color = Color.White,

    val onOrbit: Color = Color(0xFF06303A),
    val secondary: Color = Color(0xFFA3CED9),
    val warning: Color = Color(0xFFF5BC6F),
    val onSurfaceVariant: Color = Color(0xFFBCC9CC),
    val outline: Color = Color(0xFF9AAAAE),
    val outlineVariant: Color = Color(0xFF2C3539),
    val surfaceContainer: Color = Color(0xFF161D1F),
)

public val LocalAccelerometerCaptureColors: ProvidableCompositionLocal<AccelerometerCaptureColors> =
    staticCompositionLocalOf { AccelerometerCaptureColors() }
