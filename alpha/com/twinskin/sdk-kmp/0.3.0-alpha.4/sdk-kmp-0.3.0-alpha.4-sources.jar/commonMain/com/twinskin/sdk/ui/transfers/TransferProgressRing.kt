package com.twinskin.sdk.ui.transfers

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * Circular upload ring matching the prototype `UploadScreen` SVG: a 50px ring
 * (r = 21, 5px stroke) on a [track] background with the progress arc sweeping
 * clockwise from 12 o'clock in [accent]. Center shows the integer percent
 * while uploading, or a check once [complete].
 *
 * Mirrors `screens_flow.jsx` → `UploadScreen` (rotate(-90deg), strokeLinecap
 * round, strokeDashoffset = circumference × (1 - pct/100)).
 *
 * @param progress 0..1 sweep fraction; ignored when [indeterminate].
 * @param indeterminate true when [CaptureState.Uploading.progressPercent] is null
 *   (bundle still packing) — draws a full faint arc with no percent label.
 */
@Composable
internal fun TransferProgressRing(
    progress: Float,
    accent: Color,
    track: Color,
    complete: Boolean,
    indeterminate: Boolean,
    modifier: Modifier = Modifier,
) {
    val animated by animateFloatAsState(
        targetValue = if (complete) 1f else progress.coerceIn(0f, 1f),
        label = "transferRing",
    )
    Box(modifier = modifier.size(50.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(50.dp)) {
            val strokeWidth = 5.dp.toPx()
            val inset = strokeWidth / 2f
            val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
            val topLeft = Offset(inset, inset)
            drawArc(
                color = track,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth),
            )
            val sweep = if (indeterminate && !complete) 360f else 360f * animated
            if (sweep > 0f) {
                drawArc(
                    color = accent,
                    startAngle = -90f,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(
                        width = strokeWidth,
                        cap = if (indeterminate && !complete) StrokeCap.Butt else StrokeCap.Round,
                    ),
                )
            }
        }
        when {
            complete -> Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(22.dp),
            )
            !indeterminate -> Text(
                text = "${(animated * 100).toInt()}%",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}
