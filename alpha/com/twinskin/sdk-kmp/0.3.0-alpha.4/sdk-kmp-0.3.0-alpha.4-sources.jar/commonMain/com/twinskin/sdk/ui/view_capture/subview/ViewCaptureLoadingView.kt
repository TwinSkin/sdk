@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.i18n.sdkLocale
import com.twinskin.sdk.ui.capture.i18n.captureStringsFor
import com.twinskin.sdk.ui.theme.TwinSkinColors
import com.twinskin.sdk.view.LoadProgress

/**
 * Dark-stage loading screen (prototype `ViewerLoadingScreen`): a cyan progress
 * ring around a cube glyph, then "Loading 3D model" + a "Fetching mesh &
 * textures · NN%" sub-line. When [progress] carries a determinate byte ratio
 * the ring reflects it; otherwise the ring sweeps continuously and the percent
 * sub-line is dropped.
 *
 * The translucent top bar is owned by [ViewCaptureReadyView]'s siblings and
 * drawn by the screen-level composable, not here — this view is the stage body.
 */
@TwinSkinInternalApi
@Composable
public fun ViewCaptureLoadingView(progress: LoadProgress) {
    val fraction = progress.determinateFraction()
    ViewerStageBackground(
        modifier = Modifier.fillMaxSize(),
        centerYFraction = 0.38f,
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val strings = remember { captureStringsFor(sdkLocale()) }
            ProgressCube(fraction = fraction)
            Spacer(Modifier.height(22.dp))
            Text(
                text = strings.viewerLoadingTitle,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = if (fraction != null) {
                    strings.viewerLoadingDetailPercent((fraction * 100).toInt().toString())
                } else {
                    strings.viewerLoadingDetail
                },
                color = Color.White.copy(alpha = 0.55f),
                fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun ProgressCube(fraction: Float?) {
    val transition = rememberInfiniteTransition(label = "loadingRing")
    val sweepStart by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "loadingRingSweep",
    )
    Box(contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(64.dp)) {
            val strokeWidth = 5.dp.toPx()
            val inset = strokeWidth / 2f
            val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
            val topLeft = Offset(inset, inset)
            drawArc(
                color = Color.White.copy(alpha = 0.12f),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )
            val (start, sweep) = if (fraction != null) {
                -90f to (360f * fraction.coerceIn(0f, 1f))
            } else {
                (sweepStart - 90f) to 90f
            }
            drawArc(
                color = TwinSkinColors.Cyan,
                startAngle = start,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            )
        }
        Icon(
            imageVector = Icons.Default.ViewInAr,
            contentDescription = null,
            tint = TwinSkinColors.Cyan,
            modifier = Modifier.size(26.dp),
        )
    }
}

private fun LoadProgress.determinateFraction(): Float? = when (this) {
    is LoadProgress.Downloading -> total?.let {
        if (it > 0) (bytesRead.toFloat() / it.toFloat()).coerceIn(0f, 1f) else null
    }
    LoadProgress.Indeterminate,
    LoadProgress.ResolvingCredentials,
    LoadProgress.ResolvingMetadata,
    -> null
}
