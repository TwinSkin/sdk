package com.twinskin.sdk.ui.annotation_editor

import com.twinskin.sdk.capture.ConditionType
import com.twinskin.sdk.capture.GenericAnnotation
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.capture.WoundAnnotation

/** Which annotation editor a capture should open. */
internal enum class AnnotationEditorKind { Wound, Generic }

/**
 * Picks the editor for a capture. An [existing] annotation pins its own type so
 * re-editing never switches editors; otherwise the choice follows [conditionType].
 */
internal fun selectAnnotationEditorKind(
    existing: SdkAnnotation?,
    conditionType: ConditionType?,
): AnnotationEditorKind = when (existing) {
    is WoundAnnotation -> AnnotationEditorKind.Wound
    is GenericAnnotation -> AnnotationEditorKind.Generic
    null -> if (conditionType == ConditionType.Wound) {
        AnnotationEditorKind.Wound
    } else {
        AnnotationEditorKind.Generic
    }
}
