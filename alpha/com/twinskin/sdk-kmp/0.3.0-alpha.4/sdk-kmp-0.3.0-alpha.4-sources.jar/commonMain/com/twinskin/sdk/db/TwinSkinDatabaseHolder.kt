@file:OptIn(ExperimentalAtomicApi::class)

package com.twinskin.sdk.db

import kotlin.concurrent.atomics.AtomicReference
import kotlin.concurrent.atomics.ExperimentalAtomicApi

internal object TwinSkinDatabaseHolder {
    private val database = AtomicReference<TwinSkinDatabase?>(null)

    fun acquire(factory: DatabaseDriverFactory): TwinSkinDatabase {
        database.load()?.let { return it }
        val createdDriver = factory.create()
        val created = TwinSkinDatabase(createdDriver)
        return if (database.compareAndSet(null, created)) {
            created
        } else {
            createdDriver.close()
            database.load()!!
        }
    }

    /**
     * Reset the held database so a fresh acquire constructs a new one. Test-only:
     * production has one process-singleton DB whose lifetime is the process lifetime.
     */
    internal fun resetForTest() {
        database.store(null)
    }
}
