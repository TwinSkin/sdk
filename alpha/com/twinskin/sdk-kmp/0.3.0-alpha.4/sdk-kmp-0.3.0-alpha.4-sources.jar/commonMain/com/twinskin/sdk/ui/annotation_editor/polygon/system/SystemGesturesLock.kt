package com.twinskin.sdk.ui.annotation_editor.polygon.system

import androidx.compose.runtime.Composable

/**
 * Defers platform system edge gestures for the duration of the
 * surrounding composition (spec §13.x — M15.6 round-18 fix).
 * `WoundAnnotationEditor` calls this once at the top of its body
 * alongside `LockOrientationDuringSession()` so a stroke that
 * reaches the left/right edge of the device screen doesn't
 * inadvertently trigger an iOS back-swipe or home-indicator pull
 * that interrupts the session.
 *
 * **Per-platform behaviour:**
 *  - **iOS.** Increments [SystemGesturesLockCounter.depth] on enter,
 *    decrements on dispose. The integrator's host `UIViewController`
 *    reads `TwinSkin.uiKit.preferredScreenEdgesDeferringSystemGestures`
 *    + `TwinSkin.uiKit.prefersHomeIndicatorAutoHidden` from
 *    `preferredScreenEdgesDeferringSystemGestures` /
 *    `prefersHomeIndicatorAutoHidden` to honour the SDK's intent.
 *    See `TwinSkinUiKit` for the wiring snippet.
 *  - **Android.** No-op for now. Android back-swipe interception
 *    (if needed) can be added later via `PredictiveBackHandler`
 *    once field data shows users tripping it during editing.
 *  - **JVM (tests).** No-op other than driving the counter so
 *    `SystemGesturesLockCounterTest` exercises the entry/exit
 *    semantics on the test target.
 *
 * **Re-entrance.** The counter (and the per-platform behaviour
 * built on it) is re-entrant via [SystemGesturesLockCounter]: a
 * future composable that nests `DeferSystemGesturesDuringSession`
 * inside another instance increments the depth twice and only
 * relinquishes the deferral when both dispose.
 */
@Composable
internal expect fun DeferSystemGesturesDuringSession()

/**
 * Re-entrant lock counter — public surface for the iOS
 * `TwinSkinUiKit` getters and the test target. Always accessed from
 * the main thread (Compose's recomposition + DisposableEffect
 * cleanup both run on the main thread); no atomic / lock required.
 *
 * **Capped at zero.** A spurious [exit] without a matching [enter]
 * is silently absorbed (depth stays at 0) rather than going
 * negative — the iOS getter wouldn't notice the difference, but a
 * future caller might iterate depth and get confused by a negative
 * value.
 */
internal object SystemGesturesLockCounter {
    private var _depth: Int = 0

    /** Current lock depth. Zero ⇒ no session active, > 0 ⇒ at least one. */
    val depth: Int get() = _depth

    /** Increments the depth on session entry. */
    fun enter() {
        _depth++
    }

    /** Decrements the depth on session exit. Capped at zero. */
    fun exit() {
        if (_depth > 0) _depth--
    }

    /** Test-only — resets the depth between iterations. */
    internal fun resetForTests() {
        _depth = 0
    }
}
