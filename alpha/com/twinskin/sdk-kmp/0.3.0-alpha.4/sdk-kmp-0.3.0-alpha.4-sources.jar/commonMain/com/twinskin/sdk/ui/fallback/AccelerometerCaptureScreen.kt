package com.twinskin.sdk.ui.fallback

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.FlashAuto
import androidx.compose.material.icons.outlined.FlashOff
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.TwinSkinSdk
import com.twinskin.sdk.ui.capture.i18n.EnCaptureStrings
import com.twinskin.sdk.ui.capture.i18n.LocalCaptureStrings
import com.twinskin.sdk.ui.capture.i18n.ProvideSdkCaptureStrings
import com.twinskin.sdk.capture.CaptureSession
import com.twinskin.sdk.capture.DemoCaptureSummary
import com.twinskin.sdk.transfer.currentTimeMillis
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
public fun AccelerometerCaptureScreen(
    controller: AccelerometerCaptureController,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
    demoSession: CaptureSession? = null,
    onDemoSubmitted: () -> Unit = {},
    torchControl: TorchControl? = null,
    userPreferences: SdkUserPreferences = SdkUserPreferences.inMemory(),
    cameraPreview: @Composable () -> Unit = {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black))
    },
    coachImages: CaptureCoachImages = CaptureCoachImages(),
    haptics: CaptureHaptics = remember { CaptureHaptics(now = ::currentTimeMillis) },
) {
    val state by controller.state.collectAsState()
    val colors = LocalAccelerometerCaptureColors.current

    DisposableEffect(controller) { onDispose { controller.cancel() } }

    // Eyes-free haptics driven off the state stream so they fire on real transitions;
    // throttle/latching lives in [CaptureHaptics].
    LaunchedEffect(controller, haptics) {
        var lastPhase: Int = -1
        var lastSectors = 0
        controller.state.collect { s ->
            when (s) {
                is AccelerometerCaptureScreenState.PhotoTaken -> {
                    if (lastPhase != PHASE_PHOTO) haptics.fire(CaptureHapticEvent.PhotoCaptured)
                    lastPhase = PHASE_PHOTO
                }
                is AccelerometerCaptureScreenState.RecordingVideo -> {
                    if (lastPhase != PHASE_RECORDING) {
                        haptics.fire(CaptureHapticEvent.RecordingStarted)
                        lastSectors = 0
                    }
                    lastPhase = PHASE_RECORDING
                    val sectors = s.pie.capturedAngles.count { it }
                    if (sectors > lastSectors) haptics.fire(CaptureHapticEvent.SectorFilled)
                    lastSectors = sectors
                    val g = s.guidance?.takeIf { it.signalReliable }
                    if (g?.speed == CaptureSpeed.Fast && !s.isComplete) {
                        haptics.fire(CaptureHapticEvent.TooFast)
                    }
                    if (s.isComplete) haptics.fire(CaptureHapticEvent.OrbitComplete)
                }
                is AccelerometerCaptureScreenState.Error -> {
                    if (lastPhase != PHASE_ERROR) haptics.fire(CaptureHapticEvent.Error)
                    lastPhase = PHASE_ERROR
                }
                AccelerometerCaptureScreenState.ReadyForPhoto -> lastPhase = PHASE_READY
                else -> Unit
            }
        }
    }

    var showExitConfirm by remember { mutableStateOf(false) }
    var showTutorial by remember { mutableStateOf(false) }
    // Re-shows on every capture open unless `coachmarkDismissed` is set, which is
    // written ONLY by the "Don't show again" checkbox — never on a plain dismiss,
    // so an unticked dismiss leaves it false and the tutorial shows again.
    var showFirstRun by remember { mutableStateOf(firstRunTutorialPending(userPreferences)) }
    var showRetakeConfirm by remember { mutableStateOf(false) }
    var flashMode by remember { mutableStateOf(FlashMode.Off) }

    val devMode = TwinSkinSdk.devMode
    val demoScope = rememberCoroutineScope()
    var demoStep by remember { mutableStateOf<DemoCaptureStep?>(null) }
    var demoPickerOptions by remember { mutableStateOf<List<DemoCaptureSummary>?>(null) }
    var demoError by remember { mutableStateOf<String?>(null) }

    // Latched at PhotoTaken so the thumbnail keeps showing the still through
    // RecordingVideo, where the state no longer carries the path. Reset on retake.
    var capturedStillPath by remember { mutableStateOf<String?>(null) }
    (state as? AccelerometerCaptureScreenState.PhotoTaken)?.let { capturedStillPath = it.stillPath }

    // "Continue without measurement" only dismisses the marker card; it must NOT
    // auto-start the orbit. Reset whenever we leave PhotoTaken so a fresh still
    // re-raises the warning.
    var markerWarningDismissed by remember { mutableStateOf(false) }
    if (state !is AccelerometerCaptureScreenState.PhotoTaken) markerWarningDismissed = false

    val torch: TorchControl? = torchControl
    val flashSupported = torch?.isAvailable() == true
    val torchLatched = flashMode == FlashMode.On

    // A dark still defaults the torch ON so it's lit when the low-light card appears and persists
    // into Step 2 + recording; operator can toggle off.
    val lowLightNow = (state as? AccelerometerCaptureScreenState.PhotoTaken)?.lowLight == true
    LaunchedEffect(lowLightNow) {
        if (lowLightNow && torch != null && flashSupported && flashMode != FlashMode.On) {
            flashMode = FlashMode.On
            torch.applyFlashMode(FlashMode.On)
        }
    }

    ProvideSdkCaptureStrings {
    CompositionLocalProvider(LocalCaptureCoachImages provides coachImages) {
    BoxWithConstraints(modifier = modifier.fillMaxSize().background(colors.surface)) {
        val dialSize: Dp = (maxWidth * 0.56f)
            .coerceIn(150.dp, 236.dp)
            .coerceAtMost(maxHeight * 0.42f)

        // The preview ignores safe areas by design, but fixed-offset top chrome
        // must clear the status bar / cutout. `safeDrawing` is 0 where there is no
        // bar, so adding it never double-pads.
        val topInset: Dp = WindowInsets.safeDrawing.asPaddingValues().calculateTopPadding()

        // Under the edge-to-edge activity, bottom controls anchored by fixed dp
        // would draw under the nav bar; add `safeDrawing` (0 where there is no
        // bottom bar, so it never double-pads).
        val bottomInset: Dp = WindowInsets.safeDrawing.asPaddingValues().calculateBottomPadding()

        cameraPreview()

        when (val s = state) {
            is AccelerometerCaptureScreenState.Initializing -> InitializingOverlay()
            is AccelerometerCaptureScreenState.Submitting ->
                if (s.progressPercent == null) PreparingOverlay()
                else BackgroundUploadOverlay(uploadPercent = s.progressPercent, onDone = onCancel)
            is AccelerometerCaptureScreenState.Error ->
                ErrorOverlay(message = s.message, onClose = onCancel)
            else -> Unit
        }

        if (state.showsLiveChrome) {
            val recording = state as? AccelerometerCaptureScreenState.RecordingVideo
            CaptureTopBar(
                recording = recording,
                onCancel = { showExitConfirm = true },
                onHelp = { showTutorial = true },
                helpVisible = !showFirstRun,
            )
            if (torchLatched && (recording != null || state is AccelerometerCaptureScreenState.PhotoTaken)) {
                TorchPill(modifier = Modifier.align(Alignment.TopCenter).padding(top = topInset + 60.dp))
            }
        }

        if (state.showsLiveChrome && devMode && demoSession != null && demoStep == null) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    // Offset below the 54.dp top bar so it clears the cancel/title/help row.
                    .padding(top = topInset + 60.dp, end = 16.dp),
                color = Color.Black.copy(alpha = 0.6f),
                shape = MaterialTheme.shapes.small,
            ) {
                TextButton(
                    onClick = {
                        demoScope.launch {
                            val catalog = try {
                                demoSession.listDemoCaptures()
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                demoError = e.message ?: "Demo capture failed"
                                return@launch
                            }
                            when {
                                catalog.isEmpty() ->
                                    demoError = EnCaptureStrings.noDemoAvailable
                                catalog.size == 1 -> useDemoCapture(
                                    session = demoSession,
                                    entryId = catalog.single().id,
                                    onStateChange = { demoStep = it },
                                    onSubmitted = onDemoSubmitted,
                                    onError = { demoError = it },
                                )
                                else -> demoPickerOptions = catalog
                            }
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                ) {
                    Text(LocalCaptureStrings.current.useDemo, color = Color.White)
                }
            }
        }

        when (val s = state) {
            is AccelerometerCaptureScreenState.ReadyForPhoto -> {
                if (!showFirstRun) {
                    LiveLevelCoach(
                        modifier = Modifier.align(Alignment.TopCenter)
                            .padding(top = maxHeight * 0.06f)
                            .fillMaxWidth()
                            .height(maxHeight * 0.58f),
                    )
                }
                CaptureBottom(bottomInset = bottomInset) {
                    StepPill(number = "1", label = LocalCaptureStrings.current.stepTakePhoto)
                    Spacer(Modifier.height(13.dp))
                    CaptureShutter(kind = ShutterKind.TakePhoto, onTap = controller::takePhoto)
                }
            }

            is AccelerometerCaptureScreenState.PhotoTaken -> {
                val stillPainter = rememberStillPainter(s.stillPath)
                PreviewOrbitCoach(
                    modifier = Modifier.align(Alignment.Center).size(dialSize),
                    capturedStill = stillPainter,
                )
                CaptureBottom(bottomInset = bottomInset) {
                    StepPill(number = "2", label = LocalCaptureStrings.current.stepStartOrbit)
                    Spacer(Modifier.height(13.dp))
                    CaptureShutter(kind = ShutterKind.StartOrbit, onTap = controller::startRecording)
                }
                ReferenceThumbnail(
                    onRetake = { showRetakeConfirm = true },
                    thumbnail = { StillThumbnail(stillPainter) },
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 21.dp + bottomInset),
                )
                // Non-blocking: the operator can ignore the card and start the orbit.
                val lowLightCardShown = s.lowLight && torch != null && flashSupported
                if (s.lowLight && torch != null && flashSupported) {
                    LowLightCard(
                        torchOn = torchLatched,
                        onToggleTorch = { on ->
                            flashMode = if (on) FlashMode.On else FlashMode.Off
                            torch.applyFlashMode(flashMode)
                        },
                        onRetake = controller::retakePhoto,
                    )
                }
                // Yields to the low-light card when both would fire — they share
                // the same single centre-slot.
                if (!s.markerDetected && !lowLightCardShown && !markerWarningDismissed) {
                    MarkerWarningCard(
                        onRetakeWithMarker = controller::retakePhoto,
                        // Dismiss only; the operator then taps the Step-2 shutter.
                        // Must NOT call startRecording here.
                        onContinueWithout = { markerWarningDismissed = true },
                        // The printed calibration pattern (the artifact to lay flat
                        // by the lesion), NOT the lesion illustration.
                        markerImage = {
                            coachImages.markerReference?.let {
                                Image(
                                    painter = it,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(9.dp)),
                                    contentScale = ContentScale.Fit,
                                )
                            }
                        },
                    )
                }
            }

            is AccelerometerCaptureScreenState.RecordingVideo -> {
                val g: GuidanceSnapshot? = s.guidance?.takeIf { it.signalReliable }
                val speed = g?.speed ?: CaptureSpeed.Ok
                val tiltBad = g?.tiltBlocksSample == true
                val status = CaptureStatus.resolve(s.isComplete, tiltBad, speed)

                CaptureStatusLine(status, Modifier.align(Alignment.TopCenter).padding(top = topInset + 70.dp))
                CaptureBottom(bottomInset = bottomInset) {
                    CaptureDial(
                        captured = s.pie.capturedAngles,
                        mode = if (s.isComplete) DialMode.Complete else DialMode.Recording,
                        remainingFraction = s.remainingFraction,
                        // At the reference pose the azimuth is undefined; gating the
                        // heading to null keeps the cursor/target/chevron from
                        // wandering the ring. Presentation only — recorded theta /
                        // Pie / VideoMetaData are untouched.
                        headingDeg = g?.headingDeg?.takeIf { !tiltBad },
                        speed = speed,
                        tiltBad = tiltBad,
                        modifier = Modifier.size(dialSize),
                    )
                    Spacer(Modifier.height(10.dp))
                    MutedPill(LocalCaptureStrings.current.stopEarly)
                    Spacer(Modifier.height(10.dp))
                    CaptureShutter(kind = ShutterKind.StopRecording, onTap = controller::requestStop)
                }
                // Tap disabled during recording: a mid-record reset is
                // parity-affecting and out of scope.
                ReferenceThumbnail(
                    onRetake = {},
                    enabled = false,
                    thumbnail = { StillThumbnail(rememberStillPainter(capturedStillPath)) },
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 21.dp + bottomInset),
                )
            }

            else -> Unit
        }

        val flashFabVisible = flashSupported && torch != null && (
            state is AccelerometerCaptureScreenState.ReadyForPhoto ||
                (torchLatched && (state is AccelerometerCaptureScreenState.PhotoTaken ||
                    state is AccelerometerCaptureScreenState.RecordingVideo))
            )
        if (flashFabVisible && torch != null) {
            FlashFab(
                mode = flashMode,
                onClick = {
                    val next = nextFlashMode(flashMode)
                    flashMode = next
                    torch.applyFlashMode(next)
                },
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 22.dp, bottom = 41.dp + bottomInset),
            )
        }

        if (showExitConfirm) {
            ExitConfirmationDialog(
                onConfirm = { showExitConfirm = false; onCancel() },
                onDismiss = { showExitConfirm = false },
            )
        }

        // C7 (R4/#567): confirm before discarding the captured still. Only
        // meaningful on PhotoTaken — `retakePhoto()` is a no-op elsewhere — so
        // the dialog auto-closes if the phase moves on.
        if (showRetakeConfirm && state is AccelerometerCaptureScreenState.PhotoTaken) {
            RetakeConfirmationDialog(
                onConfirm = { showRetakeConfirm = false; controller.retakePhoto() },
                onDismiss = { showRetakeConfirm = false },
            )
        }

        if (showFirstRun && state is AccelerometerCaptureScreenState.ReadyForPhoto) {
            FirstRunTutorialOverlay(
                preferences = userPreferences,
                onDismiss = { showFirstRun = false },
            )
        }

        if (showTutorial) {
            // Pass preferences so the Help tutorial also shows the "Don't show
            // again" checkbox; unticking it re-enables the first-run tutorial.
            TutorialOverlay(onDismiss = { showTutorial = false }, preferences = userPreferences)
        }

        when (val ds = demoStep) {
            is DemoCaptureStep.Downloading ->
                DemoDownloadOverlay(downloaded = ds.downloaded, total = ds.total)
            DemoCaptureStep.Submitting -> PreparingOverlay()
            null -> Unit
        }

        demoPickerOptions?.let { options ->
            DemoCapturePickerDialog(
                options = options,
                onDismiss = { demoPickerOptions = null },
                onPick = { chosen ->
                    demoPickerOptions = null
                    demoScope.launch {
                        useDemoCapture(
                            session = demoSession ?: return@launch,
                            entryId = chosen.id,
                            onStateChange = { demoStep = it },
                            onSubmitted = onDemoSubmitted,
                            onError = { demoError = it },
                        )
                    }
                },
            )
        }

        demoError?.let { message ->
            ErrorOverlay(message = message, onClose = { demoError = null })
        }
    }
    }
    }
}

/**
 * The first-run tutorial is pending unless suppressed via the "Don't show again"
 * checkbox. The persisted [SdkUserPreferences.coachmarkDismissed] flag is written
 * ONLY when the box is ticked, so an unticked dismiss re-shows it on the next open.
 */
internal fun firstRunTutorialPending(prefs: SdkUserPreferences): Boolean = !prefs.coachmarkDismissed

// Coarse phase keys so the haptics effect fires once per transition, not on every
// elapsedMs/pie recomposition within a phase.
private const val PHASE_READY = 0
private const val PHASE_PHOTO = 1
private const val PHASE_RECORDING = 2
private const val PHASE_ERROR = 3

private val AccelerometerCaptureScreenState.showsLiveChrome: Boolean
    get() = this is AccelerometerCaptureScreenState.ReadyForPhoto ||
        this is AccelerometerCaptureScreenState.PhotoTaken ||
        this is AccelerometerCaptureScreenState.RecordingVideo

@Composable
private fun FlashFab(mode: FlashMode, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val colors = LocalAccelerometerCaptureColors.current
    val on = mode == FlashMode.On
    Box(
        modifier = modifier
            .size(46.dp)
            .background(if (on) colors.orbit else Color(0x80081215), CircleShape)
            .border(1.5.dp, if (on) colors.orbit else Color(0xD0FFFFFF), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = when (mode) {
                FlashMode.Off -> Icons.Outlined.FlashOff
                FlashMode.Auto -> Icons.Outlined.FlashAuto
                FlashMode.On -> Icons.Outlined.FlashOn
            },
            contentDescription = when (mode) {
                FlashMode.Off -> LocalCaptureStrings.current.flashOff
                FlashMode.Auto -> LocalCaptureStrings.current.flashAuto
                FlashMode.On -> LocalCaptureStrings.current.flashOn
            },
            tint = if (on) colors.onOrbit else Color.White,
            modifier = Modifier.size(21.dp),
        )
    }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.CaptureTopBar(
    recording: AccelerometerCaptureScreenState.RecordingVideo?,
    onCancel: () -> Unit,
    onHelp: () -> Unit,
    helpVisible: Boolean,
) {
    val colors = LocalAccelerometerCaptureColors.current
    Box(
        // Clear the status bar / cutout so the X / title / help row isn't hidden
        // under it (`safeDrawing` is 0 where there is no bar). The near-solid black
        // scrim is painted on the OUTER box, before the inset padding, so it also
        // covers the cutout strip the bar sits below, then fades into the feed.
        modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth()
            .background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.88f), Color.Black.copy(alpha = 0.88f), Color.Transparent),
                ),
            )
            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top))
            .height(54.dp)
            .padding(horizontal = 12.dp),
    ) {
        Box(
            modifier = Modifier.align(Alignment.CenterStart).size(36.dp)
                .border(2.dp, colors.onPrimary, CircleShape)
                .clickable { onCancel() },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Outlined.Close, contentDescription = LocalCaptureStrings.current.cancel, tint = colors.onPrimary)
        }

        if (recording != null) {
            Row(
                modifier = Modifier.align(Alignment.Center),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(7.dp),
            ) {
                Box(Modifier.size(9.dp).background(colors.progress, CircleShape))
                Text("0:" + recording.remainingSeconds.coerceAtLeast(0).toString().padStart(2, '0'),
                    color = colors.onPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        } else {
            Text(LocalCaptureStrings.current.screenTitle, color = colors.onPrimary, fontSize = 16.sp,
                modifier = Modifier.align(Alignment.Center))
        }

        if (helpVisible) {
            Box(modifier = Modifier.align(Alignment.CenterEnd)) { HelpButton(onClick = onHelp) }
        }
    }
}

@Composable
private fun androidx.compose.foundation.layout.BoxScope.CaptureBottom(
    bottomInset: Dp = 0.dp,
    content: @Composable () -> Unit,
) {
    Column(
        modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 26.dp + bottomInset),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) { content() }
}

/**
 * Fills the [ReferenceThumbnail] slot with the captured still. A null painter
 * (not yet decoded or decode failure) leaves the slot's black backing.
 */
@Composable
private fun StillThumbnail(painter: Painter?) {
    if (painter != null) {
        Image(
            painter = painter,
            contentDescription = null,
            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(9.dp)),
            contentScale = ContentScale.Crop,
        )
    }
}

private sealed class DemoCaptureStep {
    data class Downloading(val downloaded: Int, val total: Int) : DemoCaptureStep()
    data object Submitting : DemoCaptureStep()
}

private suspend fun useDemoCapture(
    session: CaptureSession,
    entryId: String,
    onStateChange: (DemoCaptureStep?) -> Unit,
    onSubmitted: () -> Unit,
    onError: (String) -> Unit,
) {
    try {
        onStateChange(DemoCaptureStep.Downloading(downloaded = 0, total = 1))
        session.submitDemoCapture(entryId = entryId) { d, t ->
            onStateChange(DemoCaptureStep.Downloading(downloaded = d, total = t))
        }
        onStateChange(DemoCaptureStep.Submitting)
        onSubmitted()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        onError(e.message ?: "Demo capture failed")
        onStateChange(null)
    }
}

@Composable
private fun DemoDownloadOverlay(downloaded: Int, total: Int) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                LocalCaptureStrings.current.demoDownloading,
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
            )
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { (downloaded.toFloat() / total.coerceAtLeast(1)).coerceIn(0f, 1f) },
                modifier = Modifier.width(240.dp),
            )
            Spacer(Modifier.height(8.dp))
            Text("$downloaded / $total", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DemoCapturePickerDialog(
    options: List<DemoCaptureSummary>,
    onDismiss: () -> Unit,
    onPick: (DemoCaptureSummary) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(LocalCaptureStrings.current.demoPickTitle) },
        text = {
            Column {
                for (option in options) {
                    TextButton(
                        onClick = { onPick(option) },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(option.name, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(LocalCaptureStrings.current.cancel) }
        },
    )
}
