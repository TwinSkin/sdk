package com.twinskin.sdk.ui.annotation_editor.delineation.i18n

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import com.twinskin.sdk.ui.annotation_editor.delineation.help.CloseByProximityDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.DoubleTapFillDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.DoubleTapZoomDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.OneTypeAtATimeDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.OtherTypeReadOnlyDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.ReshapeParentWoundDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.ReshapeWoundDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.ResumeOpenStrokeDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.TissueInsideWoundDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.help.TraceWoundDiagram
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType

/**
 * The delineation editor consumes its translated strings as the flat generated
 * [SdkDelineationStrings], exactly like every other SDK screen. Two things it
 * shows aren't plain text and so can't come from the generator: the tissue-name
 * lookup keyed by the [TissueType] enum, and the help slides, which pair each
 * translated title/body with a `@Composable` gesture diagram. These helpers
 * build both from the generated text getters — the diagrams are wired here in
 * code because a drawing can't live in the translations JSON.
 */

/** Localised display name for [type], falling back to its wire value. */
internal fun tissueTypeNameFor(s: SdkDelineationStrings, type: TissueType): String =
    when (type) {
        TissueType.Necrosis -> s.tissueTypeNecrosis
        TissueType.Slough -> s.tissueTypeSlough
        TissueType.Granulation -> s.tissueTypeGranulation
        else -> type.wire
    }

/**
 * Per-screen help slides: text from [s], gesture diagrams wired in code. Plain
 * (non-`@Composable`) so the slide content is unit-testable; the diagram fields
 * are just lambda values here and are only invoked later by the help dialog.
 */
internal fun helpSlidesOf(s: SdkDelineationStrings): HelpSlideStrings = HelpSlideStrings(
    intro = listOf(
        HelpSlide(s.helpIntro1Title, s.helpIntro1Body),
        HelpSlide(s.helpIntro2Title, s.helpIntro2Body),
    ),
    woundDrawing = listOf(
        HelpSlide(s.helpWound1Title, s.helpWound1Body, diagram = { TraceWoundDiagram() }),
        HelpSlide(s.helpWound2Title, s.helpWound2Body, diagram = { CloseByProximityDiagram() }),
        HelpSlide(s.helpWound3Title, s.helpWound3Body, diagram = { ResumeOpenStrokeDiagram() }),
        HelpSlide(s.helpWound4Title, s.helpWound4Body, diagram = { ReshapeWoundDiagram() }),
        HelpSlide(s.helpWound5Title, s.helpWound5Body, diagram = { DoubleTapZoomDiagram() }),
    ),
    tissueDashboard = listOf(
        HelpSlide(s.helpDashboard1Title, s.helpDashboard1Body),
        HelpSlide(s.helpDashboard2Title, s.helpDashboard2Body),
    ),
    tissueDrawing = listOf(
        HelpSlide(s.helpTissue1Title, s.helpTissue1Body, diagram = { TissueInsideWoundDiagram() }),
        HelpSlide(s.helpTissue2Title, s.helpTissue2Body, diagram = { OneTypeAtATimeDiagram() }),
        HelpSlide(s.helpTissue3Title, s.helpTissue3Body, diagram = { ReshapeParentWoundDiagram() }),
        HelpSlide(s.helpTissue4Title, s.helpTissue4Body, diagram = { OtherTypeReadOnlyDiagram() }),
        HelpSlide(s.helpTissue5Title, s.helpTissue5Body, diagram = { DoubleTapFillDiagram() }),
    ),
)

/** [helpSlidesOf] `remember`ed on [s] so the slides aren't rebuilt each recomposition. */
@Composable
internal fun rememberHelpSlides(s: SdkDelineationStrings): HelpSlideStrings =
    remember(s) { helpSlidesOf(s) }
