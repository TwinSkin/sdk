@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.transfers

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.capture.CaptureState
import com.twinskin.sdk.capture.PendingUpload
import com.twinskin.sdk.i18n.sdkLocale
import com.twinskin.sdk.ui.capture.i18n.captureStringsFor
import com.twinskin.sdk.ui.theme.BrandCard
import com.twinskin.sdk.ui.theme.TwinSkinColors

/**
 * One [PendingUpload] rendered in the prototype's transfer-card language
 * (`screens_flow.jsx` → `UploadScreen`). Branches on the upload's
 * [CaptureState]:
 *  - [CaptureState.Uploading] — cyan [TransferProgressRing] + percent + linear
 *    bar + "photosphere bundle" subline.
 *  - [CaptureState.Uploaded] / [CaptureState.Analyzing] / [CaptureState.Succeeded]
 *    — ring resolves to a green check, "View 3D result" CTA on the screen.
 *  - [CaptureState.Failed] — error-tinted bordered card, warning icon,
 *    "Upload failed · …", Retry + delete.
 *
 * States that don't surface on the `pendingUploads` stream fall through to a
 * neutral uploading-style row.
 */
@Composable
internal fun TransferCard(
    upload: PendingUpload,
    onRetry: () -> Unit,
    onViewResult: () -> Unit,
    modifier: Modifier = Modifier,
) {
    when (val state = upload.state) {
        is CaptureState.Uploading ->
            ActiveTransferCard(upload, state.progressPercent, complete = false, modifier = modifier)
        CaptureState.Uploaded, CaptureState.Analyzing, CaptureState.Succeeded ->
            ActiveTransferCard(upload, progress = 100, complete = true, onViewResult = onViewResult, modifier = modifier)
        is CaptureState.Failed ->
            FailedCard(upload, state.message, onRetry, modifier)
        else ->
            ActiveTransferCard(upload, progress = null, complete = false, modifier = modifier)
    }
}

/**
 * Uploading / complete card. While in flight: cyan ring + percent + bar.
 * On completion the ring + bar flip to success green and the card grows a
 * "View 3D result" CTA. Mirrors the prototype's single card morphing between
 * the two states rather than two distinct cards.
 */
@Composable
private fun ActiveTransferCard(
    upload: PendingUpload,
    progress: Int?,
    complete: Boolean,
    modifier: Modifier = Modifier,
    onViewResult: (() -> Unit)? = null,
) {
    val accent = if (complete) TwinSkinColors.Success else MaterialTheme.colorScheme.tertiary
    val track = TwinSkinColors.TintHi
    val fraction = (progress ?: 0) / 100f
    val strings = remember { captureStringsFor(sdkLocale()) }

    BrandCard(modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TransferProgressRing(
                    progress = fraction,
                    accent = accent,
                    track = track,
                    complete = complete,
                    indeterminate = progress == null,
                )
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    SubjectTitle(upload.subjectRef)
                    Text(
                        text = if (complete) strings.viewerTransferSentSubline else strings.viewerTransferUploadingSubline,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.width(10.dp))
                Icon(
                    imageVector = Icons.Filled.CloudUpload,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(20.dp),
                )
            }
            Spacer(Modifier.height(14.dp))
            ProgressBar(
                fraction = if (complete) 1f else fraction,
                accent = accent,
                track = track,
            )
            if (complete && onViewResult != null) {
                Spacer(Modifier.height(14.dp))
                com.twinskin.sdk.ui.theme.PrimaryButton(
                    text = strings.viewerTransferViewResult,
                    onClick = onViewResult,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

/** 6dp linear bar — tintHi track, accent fill, fully rounded (prototype). */
@Composable
private fun ProgressBar(fraction: Float, accent: Color, track: Color) {
    val animated by animateFloatAsState(fraction.coerceIn(0f, 1f), label = "transferBar")
    Box(
        Modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(track),
    ) {
        Box(
            Modifier
                .fillMaxWidth(animated)
                .height(6.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(accent),
        )
    }
}

/**
 * Failed transfer — error-soft bordered [BrandCard], error-tinted warning
 * circle, "Upload failed · …" in error color, Retry (slate filled, refresh
 * glyph) + a square outlined delete button. Both actions currently route to
 * [onRetry] (re-enqueue); the host owns the destructive path.
 */
@Composable
private fun FailedCard(
    upload: PendingUpload,
    message: String?,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BrandCard(
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.5.dp,
                color = TwinSkinColors.ErrorSoft.copy(alpha = 0.33f),
                shape = RoundedCornerShape(18.dp),
            ),
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(TwinSkinColors.Error.copy(alpha = 0.08f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Warning,
                        contentDescription = null,
                        tint = TwinSkinColors.Error,
                        modifier = Modifier.size(24.dp),
                    )
                }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    SubjectTitle(upload.subjectRef)
                    Text(
                        text = message ?: remember { captureStringsFor(sdkLocale()) }.viewerTransferFailedSubline,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
            Spacer(Modifier.height(13.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                RetryButton(onClick = onRetry, modifier = Modifier.weight(1f))
                DeleteButton(onClick = onRetry)
            }
        }
    }
}

/** Slate-filled Retry pill with a leading refresh glyph (prototype). */
@Composable
private fun RetryButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(11.dp))
            .background(MaterialTheme.colorScheme.primary)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Filled.Refresh,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(16.dp),
        )
        Spacer(Modifier.width(7.dp))
        Text(
            text = remember { captureStringsFor(sdkLocale()) }.viewerRetryAction.uppercase(),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onPrimary,
        )
    }
}

/** Square outlined delete button matching the prototype's 48px trash affordance. */
@Composable
private fun DeleteButton(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(11.dp))
            .border(1.5.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(11.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Outlined.Delete,
            contentDescription = remember { captureStringsFor(sdkLocale()) }.viewerTransferDelete,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(19.dp),
        )
    }
}

@Composable
private fun SubjectTitle(subjectRef: String) {
    Text(
        text = remember { captureStringsFor(sdkLocale()) }.viewerTransferSubject(subjectRef),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}
