package com.twinskin.sdk.ui.annotation_editor.polygon.engine

import androidx.compose.ui.geometry.Offset

/**
 * One-shot UI signals raised by the [EditorController]. The screen
 * (M11) drains these and surfaces them as snackbars / haptics /
 * store-mutations at the Scaffold level.
 *
 * The controller can't host a `SnackbarHostState` itself (it'd
 * couple the pure state machine to Compose UI), so it appends
 * signals to a sink the screen consumes via
 * [EditorController.consumeSignal].
 *
 * **Signal vs persistent state.** Signals are one-shot UI ephemera,
 * **not** part of the controller's persistent state. Property tests
 * that compare controller equality across undo passes must filter
 * the signal queue out of the comparison — see
 * `EditorControllerPropertyTest`'s undo-all-equality test.
 *
 * **Screen-side undo coupling.** On each commit-class signal
 * ([StrokeClosed], [ReshapeCommitted], [PolygonDeleted]) the screen
 * attaches a `store.snapshot()` to the controller's top
 * [UndoEntry] via [EditorController.attachSideStateToTopUndo] before
 * applying the store mutation. [UndoApplied] carries that payload
 * back as [UndoApplied.sideState], which the screen casts to
 * `StoreSnapshot` and feeds to `store.restore(...)`. The controller's
 * `_undoStack` is the single source of truth — no parallel screen
 * stack — so the two cannot drift across config change or eviction
 * at the [EditorController.UNDO_STACK_MAX] cap. [UndoApplied] is
 * **conditionally** emitted: skipped when the popped entry's
 * polygons match the current polygons (orphan stroke-start entries
 * drained via palier-undo), keeping the signal contract aligned
 * with visible polygon changes.
 */
internal sealed class UiSignal {
    /** Touch-down arrived > 50 canvas-px from the open stroke's last sample (spec §6.2.3). */
    data object TooFarFromOpenStroke : UiSignal()

    /**
     * A new polygon was just sealed via stroke closure (spec §6.2.5).
     * The screen pushes a [com.twinskin.sdk.ui.annotation_editor.delineation.DelineationStore.snapshot]
     * onto its `storeUndoStack`, then mirrors the new polygon to the
     * store (on screen 2: `store.addWound(Wound(controller.polygons[polygonIdx], emptyList()))`;
     * on screen 4: the screen accumulates closed polygons and writes
     * them back on screen exit).
     */
    data class StrokeClosed(val polygonIdx: Int) : UiSignal()

    /**
     * A reshape gesture was committed on touch-up. The screen runs
     * the M5b tissue-reclip cascade against [postReshapeOutline]
     * and updates the store. The [preReshapeOutline] payload is
     * diagnostic; the canonical revert path is via the screen's
     * `storeUndoStack`.
     */
    data class ReshapeCommitted(
        val polygonIdx: Int,
        val preReshapeOutline: List<Offset>,
        val postReshapeOutline: List<Offset>,
    ) : UiSignal()

    /**
     * The focused polygon was deleted. The screen mirrors the
     * removal to the store (`store.removeWound(polygonIdx)` on
     * screen 2; tissue removal on screen 4). The
     * [deletedPolygon] payload is diagnostic.
     */
    data class PolygonDeleted(
        val polygonIdx: Int,
        val deletedPolygon: List<Offset>,
    ) : UiSignal()

    /**
     * A commit-level undo was popped from `_undoStack` and the
     * polygon list reverted to the entry's state. Conditionally
     * emitted: skipped when the popped entry's polygons match the
     * current polygons (an orphan stroke-start entry whose stroke
     * was drained via palier-undo without closing). [sideState]
     * carries the opaque host-attached payload from
     * [UndoEntry.sideState] — the screen restores its external
     * state from it (typically a `StoreSnapshot`).
     */
    data class UndoApplied(
        val sideState: Any?,
        /**
         * Identity token of the redo entry this undo pushed — the
         * screen passes it to
         * [EditorController.attachSideStateToRedoEntry] with its
         * pre-restore store snapshot. Carrying the entry identity in
         * the signal (instead of "attach to top of stack") keeps the
         * attach correct when several undo taps batch into one
         * conflated drain pass: with top-of-stack attachment, the
         * first undo's redo entry would keep a null sideState and a
         * later redo would restore polygons while silently skipping
         * the store restore.
         */
        val redoEntryToken: Any? = null,
    ) : UiSignal()

    /**
     * A redo entry was re-applied. Mirror of [UndoApplied]:
     * [sideState] is the snapshot the screen attached (via
     * [EditorController.attachSideStateToRedoEntry]) while draining
     * the corresponding UndoApplied; the screen feeds it back to its
     * store. [undoEntryToken] identifies the undo entry this redo
     * pushed — the screen attaches its CURRENT (pre-restore) store
     * snapshot to it via
     * [EditorController.attachSideStateToUndoEntry], because redo is
     * itself undoable. Same batched-drain rationale as
     * [UndoApplied.redoEntryToken].
     */
    data class RedoApplied(
        val sideState: Any?,
        val undoEntryToken: Any? = null,
    ) : UiSignal()
}
