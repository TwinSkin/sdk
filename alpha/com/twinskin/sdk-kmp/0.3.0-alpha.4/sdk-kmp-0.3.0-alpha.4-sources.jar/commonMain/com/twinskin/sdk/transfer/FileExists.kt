package com.twinskin.sdk.transfer

internal expect fun fileExists(path: String): Boolean
