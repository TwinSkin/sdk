@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.capture.GenericAnnotation
import com.twinskin.sdk.capture.Point2D
import com.twinskin.sdk.capture.SdkAnnotation
import com.twinskin.sdk.capture.SdkMeasurement
import com.twinskin.sdk.capture.WoundAnnotation
import com.twinskin.sdk.capture.WoundMeasurement
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.polygon.canvas.clinicalColorFor
import com.twinskin.sdk.ui.layout.imageRectInBox
import com.twinskin.sdk.ui.theme.TwinSkinColors

/**
 * Stateless 2D pane (prototype `Pane2D`): the reference image, the coral
 * outline overlay (12%-alpha fill + 2.6 px stroke with a soft glow), a dashed
 * white major-axis leader line, and a centered measurement pill — drawn over
 * the dark viewer stage.
 *
 * Annotation coordinates are normalized 0..1 in the reference image's frame,
 * so the overlay tracks the displayed image regardless of layout size.
 *
 * [showReadout] keeps the legacy below-image measurement list for the UI
 * catalog; the production viewer suppresses it (`false`) because the bottom
 * sheet carries the metric grid, and only borrows [measurement] here to place
 * the major-axis leader + pill.
 *
 * Pass [image] = null to render a loading state — useful while the host is
 * decoding bytes off disk.
 */
@TwinSkinInternalApi
@Composable
public fun Capture2DView(
    image: ImageBitmap?,
    annotation: SdkAnnotation?,
    measurement: SdkMeasurement?,
    modifier: Modifier = Modifier,
    isSubmitting: Boolean = false,
    showReadout: Boolean = true,
) {
    val polygons = annotation?.toRenderablePolygons().orEmpty()
    // Pinch-to-zoom + pan state, shared by the image and its overlay so the
    // wound/tissue outlines track the photo. Clamped to [1x, 5x]; panning is
    // bounded to the scaled content so the image can't be flung off-screen.
    var scale by remember(image) { mutableStateOf(1f) }
    var offset by remember(image) { mutableStateOf(Offset.Zero) }
    Column(modifier = modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.Black)
                .clipToBounds(),
            contentAlignment = Alignment.Center,
        ) {
            if (image == null) {
                CircularProgressIndicator(color = OverlayPolygonColor)
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(image) {
                            detectTransformGestures { centroid, pan, zoom, _ ->
                                val newScale = (scale * zoom).coerceIn(1f, 5f)
                                // Keep the pinch centroid stable while zooming.
                                val k = newScale / scale
                                offset = (offset + centroid - centroid * k) + pan
                                scale = newScale
                                val maxX = (size.width * (scale - 1f)) / 2f
                                val maxY = (size.height * (scale - 1f)) / 2f
                                offset = Offset(
                                    offset.x.coerceIn(-maxX, maxX),
                                    offset.y.coerceIn(-maxY, maxY),
                                )
                                if (scale == 1f) offset = Offset.Zero
                            }
                        }
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        },
                ) {
                    Image(
                        bitmap = image,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit,
                    )
                    // M15.14 — hide the (stale, pre-submit) annotation overlay
                    // while a submit is in flight; the optimistic update
                    // restores it the instant submitAnnotation succeeds.
                    if (!isSubmitting && polygons.isNotEmpty()) {
                        OutlineOverlay(
                            polygons = polygons,
                            imageWidth = image.width,
                            imageHeight = image.height,
                            zoomScale = scale,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
                if (isSubmitting) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.35f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        CircularProgressIndicator(color = OverlayPolygonColor)
                    }
                }
            }
        }
        if (showReadout && measurement != null) {
            HorizontalDivider()
            MeasurementsSection(
                measurement = measurement,
                isSubmitting = isSubmitting,
                modifier = Modifier
                    .heightIn(max = 280.dp)
                    .verticalScroll(rememberScrollState()),
            )
        }
    }
}

/**
 * One polygon to render on the 2D pane: normalized vertices + the stroke
 * color. Wound contours use the coral overlay color; tissue regions inside a
 * wound use their clinical tissue color so the user sees the tissue
 * composition drawn in place.
 */
private data class RenderablePolygon(val points: List<Point2D>, val color: Color)

private fun SdkAnnotation.toRenderablePolygons(): List<RenderablePolygon> = when (this) {
    is GenericAnnotation -> regions.map { RenderablePolygon(it.points, OverlayPolygonColor) }
    is WoundAnnotation -> buildList {
        regions.forEach { wound ->
            add(RenderablePolygon(wound.contour, OverlayPolygonColor))
            // Draw each tissue region inside the wound in its clinical color.
            wound.tissues.forEach { tissue ->
                add(RenderablePolygon(tissue.contour, tissueOverlayColor(tissue.tissueType)))
            }
        }
    }
}

internal fun tissueOverlayColor(type: String): Color = when (type.lowercase()) {
    // Overlay-only wire aliases with no [TissueType] representation.
    "necrotic" -> clinicalColorFor(TissueType.Necrosis)
    "epithelial", "epithelialization", "epithelization" -> TwinSkinColors.CyanSoft
    // Unknown wires parse to [TissueType.Other] → gray.
    else -> clinicalColorFor(TissueType.fromWire(type))
}

@Composable
private fun OutlineOverlay(
    polygons: List<RenderablePolygon>,
    imageWidth: Int,
    imageHeight: Int,
    zoomScale: Float,
    modifier: Modifier = Modifier,
) {
    Canvas(modifier = modifier) {
        val rect = imageRectInBox(
            imageWidth = imageWidth,
            imageHeight = imageHeight,
            boxWidth = size.width,
            boxHeight = size.height,
        )
        if (rect.displayWidth <= 0f || rect.displayHeight <= 0f) return@Canvas
        fun px(p: Point2D) = Offset(
            rect.offsetX + p.x.toFloat() * rect.displayWidth,
            rect.offsetY + p.y.toFloat() * rect.displayHeight,
        )
        // Stroke width shrinks as the user zooms in so the outline stays a
        // thin hairline over the photo rather than a thick band. Divided by
        // the current zoom so it's visually constant on-screen.
        val strokePx = (1.4.dp.toPx() / zoomScale).coerceAtLeast(0.6.dp.toPx())
        for (polygon in polygons) {
            if (polygon.points.size < 2) continue
            val color = polygon.color
            val path = Path().apply {
                val first = px(polygon.points.first())
                moveTo(first.x, first.y)
                for (i in 1 until polygon.points.size) {
                    val p = px(polygon.points[i])
                    lineTo(p.x, p.y)
                }
                close()
            }
            // Faint translucent fill + a soft glow underlay (approximates the
            // prototype's drop-shadow), then the crisp thin stroke.
            drawPath(path = path, color = color.copy(alpha = 0.10f))
            drawPath(path = path, color = color.copy(alpha = 0.25f), style = Stroke(width = strokePx * 2f))
            drawPath(path = path, color = color, style = Stroke(width = strokePx))
        }
    }
}

private val OverlayPolygonColor: Color = Color(0xFFFF6F61)
