package com.twinskin.sdk.geometry

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size

/** image-pixel `Offset` → unit `[0..1]` `Offset`. */
internal fun normalise(imagePx: Offset, imageSize: Size): Offset =
    Offset(imagePx.x / imageSize.width, imagePx.y / imageSize.height)

/** unit `[0..1]` `Offset` → image-pixel `Offset`. */
internal fun denormalise(unitPt: Offset, imageSize: Size): Offset =
    Offset(unitPt.x * imageSize.width, unitPt.y * imageSize.height)

internal fun normalise(imagePts: List<Offset>, imageSize: Size): List<Offset> =
    imagePts.map { normalise(it, imageSize) }

internal fun denormalise(unitPts: List<Offset>, imageSize: Size): List<Offset> =
    unitPts.map { denormalise(it, imageSize) }
