package com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers

import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType

/**
 * Typed haptic event taxonomy for the annotation editor (spec U5).
 *
 * Compose Multiplatform 1.10 exposes two cross-platform haptic
 * primitives — [HapticFeedbackType.LongPress] (stronger) and
 * [HapticFeedbackType.TextHandleMove] (lighter). The six annotation
 * editor events fan out across the two tiers along a deliberate
 * **commit-vs-continuation** axis:
 *
 *  - **Commit class** → [HapticFeedbackType.LongPress]
 *    ([StrokeCommit], [ReshapeCommit], [DeleteConfirmed],
 *    [ValidateEmitted]). One-shot state-changing actions. A
 *    stronger pulse fires once per event; the clinician feels
 *    "something committed" each time.
 *
 *  - **Continuation class** → [HapticFeedbackType.TextHandleMove]
 *    ([NonTraversalContact], [ResumeAccepted]). In-flight cues that
 *    fire repeatedly during a gesture (every clamp contact while
 *    the finger slides along a forbidden boundary, every successful
 *    stroke resume). A quieter pulse keeps the channel informative
 *    without overwhelming the commit-class events — a clinician
 *    feeling a strong haptic on every contact would start ignoring
 *    the channel entirely.
 *
 * The commit / continuation distinction is load-bearing. Don't
 * tweak the categorisation without thinking through the UX
 * implications.
 */
internal sealed class HapticEvent(internal val type: HapticFeedbackType) {
    /** Wound or tissue closure committed (stroke sealed into a polygon). */
    data object StrokeCommit : HapticEvent(HapticFeedbackType.LongPress)

    /** Reshape gesture committed (polygon outline atomically updated on lift). */
    data object ReshapeCommit : HapticEvent(HapticFeedbackType.LongPress)

    /** Destructive delete confirmed (focused polygon removed). */
    data object DeleteConfirmed : HapticEvent(HapticFeedbackType.LongPress)

    /** Validate button confirmed (annotation submitted to the server). */
    data object ValidateEmitted : HapticEvent(HapticFeedbackType.LongPress)

    /** Mid-stroke contact with a forbidden polygon's boundary (spec §6.4 clamp). */
    data object NonTraversalContact : HapticEvent(HapticFeedbackType.TextHandleMove)

    /** Touch-down within an open stroke's resume zone (spec §6.2.3). */
    data object ResumeAccepted : HapticEvent(HapticFeedbackType.TextHandleMove)
}

/**
 * Emits [event]'s haptic via this ambient [HapticFeedback]. Designed
 * for the pattern:
 *
 * ```
 * val haptic = LocalHapticFeedback.current
 * // ...later, inside a callback / LaunchedEffect:
 * haptic.emit(HapticEvent.StrokeCommit)
 * ```
 *
 * The screens capture [LocalHapticFeedback] once at composition
 * time and reuse the captured reference from non-composable
 * contexts (gesture-loop callbacks, controller signal drains).
 */
internal fun HapticFeedback.emit(event: HapticEvent) {
    performHapticFeedback(event.type)
}
