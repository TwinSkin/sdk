package com.twinskin.sdk.ui.annotation_editor

import androidx.compose.ui.graphics.ImageBitmap

/**
 * Load an encoded image (JPEG/PNG/HEIC) from disk into a Compose
 * [ImageBitmap], honouring EXIF orientation. The on-device annotation
 * editor and 2D pane consume this — both display photos that may
 * carry an EXIF rotation tag set by the capture-time pipeline.
 *
 * Implemented per-platform: Android decodes via `BitmapFactory` and
 * applies the EXIF orientation through a `Matrix.postRotate`/flip
 * pass; iOS/JVM use Skiko's `Image.makeFromEncoded` which already
 * honours EXIF on decode.
 */
public expect fun loadImageFromPath(path: String): ImageBitmap

/**
 * Decode encoded image bytes already in memory, honouring EXIF
 * orientation like [loadImageFromPath]. Consumed by the annotation
 * editor's capture path ([AnnotationEditorForCapture]) and by the
 * demo screens that ship sample images inside the app bundle.
 */
public expect fun ByteArray.toImageBitmap(): ImageBitmap
