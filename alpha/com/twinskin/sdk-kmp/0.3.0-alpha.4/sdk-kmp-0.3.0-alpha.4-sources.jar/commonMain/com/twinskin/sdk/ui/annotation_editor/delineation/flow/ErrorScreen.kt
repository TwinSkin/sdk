package com.twinskin.sdk.ui.annotation_editor.delineation.flow

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.SdkDelineationStrings
import com.twinskin.sdk.ui.theme.PrimaryButton
import com.twinskin.sdk.ui.theme.TwinSkinColors

/**
 * Last-resort UI shown when the root composable catches an uncaught
 * throwable from a gesture loop, the auto-save flow, or the
 * suspending `onDone` callback (spec C1), rebuilt against the
 * prototype `WeErrorScreen`: a centred `warnSoft` circle (82 dp)
 * holding a `warn`-tinted warning glyph, a title, a body paragraph,
 * and a full-width Dismiss CTA pinned at the bottom.
 *
 * The draft has already been flushed by the
 * [kotlinx.coroutines.CoroutineExceptionHandler] before this
 * composes, so the user's work is preserved on disk; the dismiss
 * button just exits the editor (the integrator handles what to do
 * next — typically navigate back to the host app).
 */
@Composable
internal fun ErrorScreen(
    error: Throwable,
    strings: SdkDelineationStrings,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxSize(),
        color = TwinSkinColors.Surface,
    ) {
        Column(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 34.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    modifier = Modifier.size(82.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Surface(
                        modifier = Modifier.size(82.dp),
                        shape = CircleShape,
                        color = TwinSkinColors.WarningContainer,
                    ) {}
                    Icon(
                        imageVector = Icons.Filled.Warning,
                        contentDescription = null,
                        tint = TwinSkinColors.Warning,
                        modifier = Modifier.size(38.dp),
                    )
                }
                Spacer(Modifier.height(24.dp))
                Text(
                    text = strings.errorScreenTitle,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                    ),
                    color = TwinSkinColors.Ink,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = strings.errorScreenBody,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TwinSkinColors.Ink2,
                    textAlign = TextAlign.Center,
                )
                error.message?.let { msg ->
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = TwinSkinColors.Hint,
                        textAlign = TextAlign.Center,
                    )
                }
            }
            PrimaryButton(
                text = strings.dismissButton,
                onClick = onDismiss,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(start = 24.dp, end = 24.dp, bottom = 30.dp),
            )
        }
    }
}
