package com.twinskin.sdk.ui.fallback

public enum class CaptureHapticEvent {
    PhotoCaptured,
    RecordingStarted,
    SectorFilled,
    TooFast,
    OrbitComplete,
    Error,
}

public expect fun performCaptureHaptic(event: CaptureHapticEvent)

/**
 * TooFast fires at most once per [tooFastThrottleMs] (else the ~200 Hz signal
 * vibrates continuously); confirm/complete/error latch one-shot per session;
 * SectorFilled is per-call (the caller diffs the pie).
 */
public class CaptureHaptics(
    private val tooFastThrottleMs: Long = TOO_FAST_THROTTLE_MS,
    private val now: () -> Long,
    private val emit: (CaptureHapticEvent) -> Unit = ::performCaptureHaptic,
) {
    // Nullable (not a Long sentinel) so the first fire can't depend on
    // `now() - Long.MIN_VALUE` overflowing negative and suppressing it.
    private var lastTooFastMs: Long? = null
    private val firedOnce = mutableSetOf<CaptureHapticEvent>()

    public fun fire(event: CaptureHapticEvent) {
        val allowed = when (event) {
            CaptureHapticEvent.TooFast -> {
                val t = now()
                val last = lastTooFastMs
                (last == null || t - last >= tooFastThrottleMs).also { if (it) lastTooFastMs = t }
            }
            CaptureHapticEvent.OrbitComplete,
            CaptureHapticEvent.Error,
            CaptureHapticEvent.PhotoCaptured,
            CaptureHapticEvent.RecordingStarted,
            -> firedOnce.add(event)
            CaptureHapticEvent.SectorFilled -> true
        }
        if (allowed) emit(event)
    }

    public companion object {
        public const val TOO_FAST_THROTTLE_MS: Long = 1_500L
    }
}
