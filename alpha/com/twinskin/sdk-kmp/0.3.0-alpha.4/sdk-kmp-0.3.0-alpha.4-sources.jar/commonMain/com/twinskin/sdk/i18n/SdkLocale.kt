package com.twinskin.sdk.i18n

import com.twinskin.sdk.TwinSkinSdk

/**
 * The host device's current language code — lowercase 2-letter when the
 * platform can report one (e.g. "en", "fr"), else "en".
 */
internal expect fun deviceLocale(): String

/**
 * The locale the SDK's UI should render in: the runtime override or the
 * integrator's configured [com.twinskin.sdk.TwinSkinConfiguration.locale] (both
 * via [com.twinskin.sdk.TwinSkinSdk.configuredLocale]) when set, otherwise the
 * device locale, lowercased.
 *
 * The generated `*StringsFor` dispatch matches on the full language tag
 * (`Language.name`, e.g. "pt-br") and routes through
 * [com.twinskin.sdk.i18n.resolveLocale], which strips a region/script suffix
 * and retries on the primary subtag (so "fr-FR" reaches the "fr" table) before
 * falling back to English. See packages/sdk/docs/translations.md.
 */
internal fun sdkLocale(): String =
    (TwinSkinSdk.configuredLocale ?: deviceLocale()).lowercase()
