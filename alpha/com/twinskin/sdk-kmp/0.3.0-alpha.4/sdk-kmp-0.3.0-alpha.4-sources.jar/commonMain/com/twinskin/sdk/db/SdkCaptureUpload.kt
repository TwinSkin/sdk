package com.twinskin.sdk.db

import kotlin.Long
import kotlin.String

public data class SdkCaptureUpload(
  public val captureId: String,
  public val userRef: String,
  public val subjectRef: String,
  public val conditionType: String?,
  public val captureGroup: String?,
  public val bodyLocationJson: String?,
  public val customJson: String?,
  public val deviceInfoJson: String?,
  public val encryptedPath: String,
  public val transferTaskId: String?,
  public val annotationPending: Long,
  public val captureMode: String?,
  public val createdAt: Long,
  public val updatedAt: Long,
)
