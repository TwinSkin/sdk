@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.i18n.sdkLocale
import com.twinskin.sdk.ui.capture.i18n.captureStringsFor
import com.twinskin.sdk.ui.theme.TwinSkinColors
import com.twinskin.sdk.ui.view_capture.renderer.Model3DViewer
import com.twinskin.sdk.view.Asset3D
import com.twinskin.sdk.view.ViewCaptureState

/**
 * Ready viewer (prototype `ViewerScreen`): a dark radial-gradient stage with a
 * floating close/title top bar and a floating 3D/2D segmented tab pill, over a
 * bottom-sheet metadata panel.
 *
 * Layout per available data:
 *  - both panes → tab pill toggles 3D ↔ 2D, title flips with the tab.
 *  - 3D only / 2D only → single pane, no pill, fixed title.
 *
 * The 3D pane carries a right-side tool rail (rotate / recenter / grid chips)
 * and a "Drag to rotate" hint. The 2D pane carries a bottom-right cyan "Edit
 * contour" pill (only when [onEditContour] is wired and a 2D image exists).
 */
@TwinSkinInternalApi
@Composable
public fun ViewCaptureReadyView(
    ready: ViewCaptureState.Ready,
    onClose: () -> Unit = {},
    onEditContour: (() -> Unit)? = null,
    isSavingAnnotation: Boolean = false,
) {
    val asset = ready.asset
    val image2D = ready.image2D
    val hasBoth = asset != null && image2D != null
    val canEditContour = onEditContour != null && image2D != null

    // "3d" / "2d". With only one pane, the tab is forced to that pane.
    var tab by remember(hasBoth, asset != null) {
        mutableStateOf(if (asset != null) "3d" else "2d")
    }
    val showing3D = tab == "3d" && asset != null
    val strings = remember { captureStringsFor(sdkLocale()) }
    val title = if (showing3D) strings.viewerTitle else strings.viewerTitle2d

    // The dark background fills edge-to-edge (so the status-bar strip is dark
    // and its icons stay legible). The floating top bar / tab pill carry their
    // own statusBarsPadding so the controls sit below the clock/battery.
    Column(Modifier.fillMaxSize().background(TwinSkinColors.ViewDark)) {
        ViewerStageBackground(modifier = Modifier.fillMaxWidth().weight(1f)) {
            // Pane behind everything.
            if (showing3D) {
                Model3DViewer(asset = asset!!, modifier = Modifier.fillMaxSize())
            } else if (image2D != null) {
                // Measurements live in the bottom sheet, so the stage's 2D pane
                // shows only the photo + coral outline + major-axis leader.
                // showReadout=false suppresses the pane's own readout footer so
                // the sheet's metric grid isn't duplicated.
                ViewCapture2DPane(
                    image2D = image2D,
                    annotation = ready.annotation,
                    measurement = ready.measurement,
                    isSavingAnnotation = isSavingAnnotation,
                    showReadout = false,
                    modifier = Modifier.fillMaxSize(),
                )
            } else if (asset != null) {
                Model3DViewer(asset = asset, modifier = Modifier.fillMaxSize())
            }

            ViewCaptureTopBar(title = title, onClose = onClose)

            if (hasBoth) {
                ViewerTabPill(
                    tabs = listOf("3d" to "3D", "2d" to "2D"),
                    selectedKey = tab,
                    onSelect = { tab = it },
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .statusBarsPadding()
                        .padding(top = 52.dp),
                )
            }

            // "Drag to rotate" hint stays (the 3D viewer genuinely supports
            // drag-to-rotate). The tool rail (rotate/recenter/grid) was removed
            // — those chips had no backing action. The streaming "LIVE" badge
            // was removed too: it overlapped the image and added no value here.
            if (showing3D) {
                DragToRotateHint(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 14.dp),
                )
            }

            if (!showing3D && canEditContour) {
                EditContourPill(
                    onClick = { onEditContour?.invoke() },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 14.dp, bottom = 16.dp),
                )
            }
        }

        ViewerMetadataSheet(
            summary = ready.summary,
            measurement = ready.measurement,
            isSubmitting = isSavingAnnotation || ready.isMeasurementCalculating,
        )
    }
}

@Composable
private fun DragToRotateHint(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.RotateRight,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.70f),
            modifier = Modifier.size(15.dp),
        )
        Text(
            text = remember { captureStringsFor(sdkLocale()) }.viewerDragToRotate,
            color = Color.White.copy(alpha = 0.70f),
            fontSize = 11.5.sp,
        )
    }
}

@Composable
private fun EditContourPill(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(TwinSkinColors.Cyan)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Default.Straighten,
            contentDescription = null,
            tint = TwinSkinColors.OnCyan,
            modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = remember { captureStringsFor(sdkLocale()) }.viewerEditContour,
            color = TwinSkinColors.OnCyan,
            fontSize = 13.5.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}
