package com.twinskin.sdk.ui.annotation_editor.delineation.flow

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.backhandler.BackHandler
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import com.twinskin.sdk.ui.annotation_editor.delineation.DelineationStore
import com.twinskin.sdk.ui.annotation_editor.polygon.canvas.DrawingCanvas
import com.twinskin.sdk.ui.annotation_editor.polygon.canvas.ZoomPanController
import com.twinskin.sdk.ui.annotation_editor.polygon.draft.EditorControllerSaver
import com.twinskin.sdk.ui.annotation_editor.delineation.draft.EditorPreferences
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.EditorController
import com.twinskin.sdk.ui.annotation_editor.polygon.engine.UiSignal
import com.twinskin.sdk.ui.annotation_editor.delineation.engine.reclipTissuesAgainstWound
import com.twinskin.sdk.ui.annotation_editor.delineation.help.HelpDialog
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.SdkDelineationStrings
import com.twinskin.sdk.ui.annotation_editor.delineation.i18n.rememberHelpSlides
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueCardState
import com.twinskin.sdk.ui.annotation_editor.delineation.model.TissueType
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Wound
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.ConfirmDialog
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.HapticEvent
import com.twinskin.sdk.ui.annotation_editor.delineation.ui_helpers.EditorBar
import com.twinskin.sdk.ui.annotation_editor.delineation.ui_helpers.EditorToolbar
import com.twinskin.sdk.ui.annotation_editor.delineation.ui_helpers.ReshapeAdvisoryDialog
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.TransientHint
import com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers.emit
import com.twinskin.sdk.ui.theme.TwinSkinColors
import kotlinx.coroutines.delay

/**
 * Screen 2 — wound contour drawing (spec §6). Hosts a
 * [DrawingCanvas] with no parent-wound containment plus a toolbar
 * (Undo, Delete, Next) and the four confirmation dialogs (delete,
 * reshape, abandon, plus the implicit Validate gate via Next).
 *
 * **Controller / store sync.** The controller is the source of
 * truth for the editor's in-flight polygon list. The store mirrors
 * the controller's commit events via the [UiSignal] channel:
 *  - [UiSignal.StrokeClosed] → `store.addWound(...)`.
 *  - [UiSignal.ReshapeCommitted] → M5b cascade
 *    (`reclipTissuesAgainstWound`) + `store.replaceWound(...)` +
 *    card-state recompute per spec §7.3.
 *  - [UiSignal.PolygonDeleted] → `store.removeWound(...)` +
 *    card-state recompute.
 *  - [UiSignal.UndoApplied] → `store.restore(sideState)` using the
 *    [StoreSnapshot] colocated on the controller's UndoEntry (attached
 *    via [EditorController.attachSideStateToTopUndo] when the commit
 *    signal fires). No parallel screen-side stack — the controller's
 *    undo stack is the single source of truth.
 *
 * **Reshape-with-tissues dialog (spec §6.5.2).** A
 * [LaunchedEffect] observes the controller's `activeGesture` via
 * the revision counter. When it transitions into Reshape on a
 * wound with dependent tissues AND the user hasn't confirmed any
 * reshape this session yet, the screen calls
 * `controller.cancelActiveGesture()` to revert the polygon and
 * shows the confirmation dialog. On confirm the
 * `reshapeConfirmedThisSession` flag flips, the user re-touches,
 * the gesture proceeds normally. On cancel the polygon stays
 * reverted; the flag stays false.
 *
 * **Non-traversal haptic.** A [LaunchedEffect] observes
 * `controller.lastStrokeClampContact` and fires
 * [HapticEvent.NonTraversalContact] on the null→non-null
 * transition only — once per "first contact with a boundary",
 * not once per move while sliding along it.
 */
@OptIn(ExperimentalMaterial3Api::class, androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable
internal fun WoundDrawingScreen(
    image: ImageBitmap,
    imageSize: Size,
    store: DelineationStore,
    minTissueArea: Float,
    strings: SdkDelineationStrings,
    editorPreferences: EditorPreferences,
    onBack: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // Key the saver on the store reference so a fresh hydration in
    // `WoundAnnotationEditor` (new `initial` or `imageSize` →
    // `remember(initial, imageSize)` creates a new store) invalidates
    // the controller's SaveableStateRegistry slot and re-runs the
    // seeding lambda below. Without this key, the slot survives
    // across editor mount cycles (Validate → close → re-open) and
    // restores stale state — typically an empty controller after a
    // Start Fresh in a previous session — even when the freshly
    // hydrated store carries the user's actual wounds (M15.16).
    // Rotation within a single session keeps the store reference
    // stable, so the saver still works for its original purpose
    // (config-change preservation).
    val controller: EditorController = rememberSaveable(store, saver = EditorControllerSaver) {
        // Invariant: if a wound exists, a polygon is focused.
        // Match commitClosure's "most recently drawn takes focus"
        // by seeding with lastIndex on re-entry; without this the
        // Delete button would be disabled-on-entry even when a wound
        // is clearly visible.
        val existing = store.wounds.map { it.outline }
        EditorController.fromState(
            polygons = existing,
            focusedIndex = if (existing.isNotEmpty()) existing.lastIndex else null,
        )
    }
    val zoomPan: ZoomPanController = remember(imageSize) {
        ZoomPanController(canvasSize = Size.Zero, imageSize = imageSize)
    }
    val snackbarHostState: SnackbarHostState = remember { SnackbarHostState() }
    val haptic = LocalHapticFeedback.current

    var pendingDeleteIdx by remember { mutableStateOf<Int?>(null) }
    var pendingAbandon by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }

    // System back mirrors the top-bar chevron — without this an
    // Android back gesture finished the host activity, destroying
    // every drawn contour with no abandon confirmation.
    BackHandler {
        if (controller.polygons.isNotEmpty()) pendingAbandon = true else onBack()
    }
    // Entry-time reshape advisory: shown when the store has at least
    // one wound with tissues AND the user hasn't permanently
    // dismissed it.
    var showReshapeAdvisory by remember { mutableStateOf(false) }
    LaunchedEffect(store, editorPreferences) {
        val anyWoundHasTissues = store.wounds.any { it.tissues.isNotEmpty() }
        if (!anyWoundHasTissues) return@LaunchedEffect
        if (!editorPreferences.isReshapeAdvisoryDismissed()) {
            showReshapeAdvisory = true
        }
    }

    // Transient hint (TooFar feedback + one-shot reshape teach).
    // hintNonce restarts the auto-dismiss timer on every new trigger
    // so rapid taps keep the hint visible without playing the
    // snackbar's enter/exit animation chain.
    var hintText by remember { mutableStateOf<String?>(null) }
    var hintDurationMs by remember { mutableStateOf(1200L) }
    var hintNonce by remember { mutableStateOf(0) }
    fun showHint(text: String, durationMs: Long = 1200L) {
        hintText = text
        hintDurationMs = durationMs
        hintNonce += 1
    }
    LaunchedEffect(hintNonce) {
        if (hintText != null) {
            delay(hintDurationMs)
            hintText = null
        }
    }
    // Reshape discoverability: the drag-to-adjust gesture has no
    // on-canvas affordance, so teach it right after the first contour
    // of this screen visit closes — the moment the user first has
    // something to adjust. Survives rotation; resets per visit.
    var reshapeHintShown by rememberSaveable { mutableStateOf(false) }

    // Non-traversal haptic on null→non-null transition only.
    LaunchedEffect(controller) {
        var prev: Offset? = null
        snapshotFlow { controller.lastStrokeClampContact.value }.collect { current ->
            if (current != null && prev == null) {
                haptic.emit(HapticEvent.NonTraversalContact)
            }
            prev = current
        }
    }

    // Signal drain: applies controller events to the store.
    LaunchedEffect(controller, store) {
        snapshotFlow { controller.revision.value }.collect {
            while (true) {
                val signal = controller.consumeSignal() ?: break
                when (signal) {
                    UiSignal.TooFarFromOpenStroke -> {
                        // Bypass SnackbarHost — feedback needs to
                        // arrive within ~96 ms of the tap rather than
                        // ~200–400 ms through the snackbar animation
                        // chain. Rendered by the TransientHint
                        // composable below.
                        showHint(strings.tooFarFromOpenStroke)
                    }
                    is UiSignal.StrokeClosed -> {
                        controller.attachSideStateToTopUndo(store.snapshot())
                        val newOutline = controller.polygons[signal.polygonIdx]
                        store.addWound(Wound(outline = newOutline, tissues = emptyList()))
                        haptic.emit(HapticEvent.StrokeCommit)
                        if (!reshapeHintShown) {
                            reshapeHintShown = true
                            showHint(strings.reshapeHint, durationMs = 3500L)
                        }
                    }
                    is UiSignal.ReshapeCommitted -> {
                        controller.attachSideStateToTopUndo(store.snapshot())
                        val existing = store.wounds[signal.polygonIdx]
                        val report = reclipTissuesAgainstWound(
                            tissues = existing.tissues,
                            newWoundOutline = signal.postReshapeOutline,
                            minArea = minTissueArea,
                        )
                        store.replaceWound(
                            signal.polygonIdx,
                            Wound(signal.postReshapeOutline, report.updatedTissues),
                        )
                        recomputeCardStatesFromStore(store)
                        val touched = report.updatedCount + report.removedCount
                        if (touched > 0) {
                            snackbarHostState.showSnackbar(
                                strings.tissuesAdjustedSnack(
                                    report.updatedCount.toString(),
                                    report.removedCount.toString(),
                                ),
                            )
                        }
                        haptic.emit(HapticEvent.ReshapeCommit)
                    }
                    is UiSignal.PolygonDeleted -> {
                        controller.attachSideStateToTopUndo(store.snapshot())
                        store.removeWound(signal.polygonIdx)
                        recomputeCardStatesFromStore(store)
                        haptic.emit(HapticEvent.DeleteConfirmed)
                    }
                    is UiSignal.UndoApplied -> {
                        // Colocate the pre-restore store state on the redo
                        // entry THIS undo pushed (token-identified — several
                        // undo signals can batch into one drain pass), so
                        // redo can bring the store back in lockstep.
                        controller.attachSideStateToRedoEntry(
                            signal.redoEntryToken,
                            store.snapshot(),
                        )
                        val snapshot = signal.sideState
                            as? com.twinskin.sdk.ui.annotation_editor.delineation.StoreSnapshot
                        if (snapshot != null) store.restore(snapshot)
                    }
                    is UiSignal.RedoApplied -> {
                        controller.attachSideStateToUndoEntry(
                            signal.undoEntryToken,
                            store.snapshot(),
                        )
                        val snapshot = signal.sideState
                            as? com.twinskin.sdk.ui.annotation_editor.delineation.StoreSnapshot
                        if (snapshot != null) store.restore(snapshot)
                    }
                }
            }
        }
    }

    // Observe a state read so the bottom-bar buttons recompose
    // when controller state changes (undoStackSize, focusedIndex,
    // polygons, openStroke are plain `var`s, not State — but they
    // all bump `revision` on change).
    @Suppress("UNUSED_VARIABLE") val rev = controller.revision.value

    Surface(modifier = modifier.fillMaxSize(), color = TwinSkinColors.Surface) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                EditorBar(
                    title = strings.woundTitle,
                    onBack = {
                        if (controller.polygons.isNotEmpty()) pendingAbandon = true else onBack()
                    },
                    backContentDescription = strings.backContentDescription,
                    onHelp = { showHelp = true },
                    helpContentDescription = strings.helpContentDescription,
                )
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    DrawingCanvas(
                        image = image,
                        imageSize = imageSize,
                        controller = controller,
                        zoomPan = zoomPan,
                        readOnlyWounds = emptyList(),
                        readOnlyOtherTissues = emptyList(),
                        canvasContentDescription = strings.woundCanvasContentDescription,
                        magnifierContentDescription = strings.magnifierContentDescription,
                    )
                    // Above the toolbar, not over the magnifier
                    // (review feedback).
                    TransientHint(
                        text = hintText,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 16.dp),
                    )
                }
                EditorToolbar(
                    undoLabel = strings.undoButton,
                    onUndo = { controller.undo() },
                    undoEnabled = controller.undoStackSize > 0 || controller.openStroke != null,
                    redoLabel = strings.redoButton,
                    onRedo = { controller.redo() },
                    redoEnabled = controller.redoStackSize > 0 && controller.openStroke == null,
                    deleteLabel = strings.deleteButton,
                    onDelete = {
                        // Open-stroke discard takes precedence — no
                        // confirmation needed, the stroke was never
                        // committed (spec §6 / U13b).
                        if (controller.openStroke != null) {
                            controller.deleteFocused()
                            return@EditorToolbar
                        }
                        val focused = controller.focusedIndex ?: return@EditorToolbar
                        // When the user has previously ticked
                        // "Don't show again" on the wound-with-tissues
                        // confirm dialog, skip it and delete immediately.
                        val needsConfirm =
                            shouldShowDeleteConfirmation(focused, store.wounds) &&
                                !editorPreferences.isDeleteWoundConfirmationDismissed()
                        if (needsConfirm) {
                            pendingDeleteIdx = focused
                        } else {
                            controller.deleteFocused()
                        }
                    },
                    deleteEnabled = controller.focusedIndex != null || controller.openStroke != null,
                    primaryLabel = strings.nextButton,
                    onPrimary = onNext,
                    primaryEnabled = controller.polygons.isNotEmpty() &&
                        controller.openStroke == null,
                )
            }
            SnackbarHost(
                snackbarHostState,
                // Nav-bar inset — see TissueDashboardScreen's host.
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBars),
            )
        }
    }

    if (showReshapeAdvisory) {
        ReshapeAdvisoryDialog(
            strings = strings,
            onDismiss = { dontShowAgain ->
                showReshapeAdvisory = false
                if (dontShowAgain) {
                    editorPreferences.setReshapeAdvisoryDismissed(true)
                }
            },
        )
    }

    pendingDeleteIdx?.let { idx ->
        val tissueCount = store.wounds.getOrNull(idx)?.tissues?.size ?: 0
        ConfirmDialog(
            title = strings.deleteDialogTitle,
            body = strings.deleteDialogBody(tissueCount.toString()),
            destructiveLabel = strings.deleteButton,
            cancelLabel = strings.cancelButton,
            // The checkbox-aware confirm callback is the active path;
            // the no-arg [onConfirm] is unused but required by
            // ConfirmDialog's signature.
            onConfirm = {},
            onCancel = { pendingDeleteIdx = null },
            dontShowAgainLabel = strings.dontShowAgainCheckbox,
            onConfirmWithDontShowAgain = { dontShowAgain ->
                pendingDeleteIdx = null
                if (dontShowAgain) {
                    editorPreferences.setDeleteWoundConfirmationDismissed(true)
                }
                controller.deleteFocused()
            },
        )
    }

    if (pendingAbandon) {
        ConfirmDialog(
            title = strings.abandonDialogTitle,
            body = strings.abandonDialogBody,
            destructiveLabel = strings.leaveButton,
            cancelLabel = strings.stayButton,
            onConfirm = {
                pendingAbandon = false
                onBack()
            },
            onCancel = { pendingAbandon = false },
        )
    }

    if (showHelp) {
        HelpDialog(
            slides = rememberHelpSlides(strings).woundDrawing,
            strings = strings,
            onClose = { showHelp = false },
        )
    }
}

private fun recomputeCardStatesFromStore(store: DelineationStore) {
    for (type in TissueType.knownValues) {
        val current = store.cardStates[type] ?: TissueCardState.Open
        val hasTissues = store.tissuesOfType(type).isNotEmpty()
        val next = recomputeCardStateAfterReclip(current, hasTissues)
        if (next != current) store.setCardState(type, next)
    }
}
