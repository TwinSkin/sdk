@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.annotation_editor.generic

import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ImageBitmap
import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.GenericAnnotation
import com.twinskin.sdk.i18n.sdkLocale
import com.twinskin.sdk.ui.annotation_editor.generic.boundary.toGenericAnnotation
import com.twinskin.sdk.ui.annotation_editor.generic.flow.GenericDrawingScreen
import com.twinskin.sdk.ui.annotation_editor.generic.flow.GenericIntroScreen
import com.twinskin.sdk.ui.annotation_editor.generic.i18n.genericStringsFor
import com.twinskin.sdk.ui.annotation_editor.polygon.orientation.LockOrientationDuringSession
import com.twinskin.sdk.ui.annotation_editor.polygon.system.DeferSystemGesturesDuringSession
import com.twinskin.sdk.ui.theme.TwinSkinTheme
import kotlinx.coroutines.launch

/**
 * Public entry point for the generic annotation editor — sibling to
 * [com.twinskin.sdk.ui.annotation_editor.WoundAnnotationEditor] for
 * use cases that don't need the wound/tissue model: free-form
 * colored polygons on a reference image, returned as a
 * [GenericAnnotation] payload.
 *
 * **Flow.** Two screens — Intro → Drawing. Intro mirrors the wound
 * editor's resume-or-fresh choice when [initial] is non-empty;
 * otherwise it's a single Continue CTA. Drawing reuses the
 * polygon-engine canvas (zoom/pan, undo, finger-leash, reshape) with
 * a single Undo · Delete · Validate bottom bar (uniform green-open /
 * orange-closed contour colors — no per-polygon palette). Validate
 * sends the [GenericAnnotation] through [onDone].
 *
 * **Lifecycle.**
 *  - Configuration changes preserve the current [GenericStep] via
 *    `rememberSaveable(stateSaver = genericStepSaver)` and the
 *    canvas content via `EditorControllerSaver`.
 *  - No disk-backed draft: an interrupted session leaves no trace
 *    on disk. Resume only triggers when [initial] is non-empty.
 *  - Orientation is locked for the session's duration (spec §13.5).
 *
 * **Save retries.** A failed [onDone] surfaces a retry snackbar on
 * the drawing screen; tapping Retry re-invokes [onDone] with the
 * same payload. Dismissing the snackbar without retrying leaves the
 * user on the drawing screen with everything intact.
 *
 * @param image    The source image. Must have positive dimensions.
 *                 Re-keying [image] resets the editor's internal state.
 * @param onDone   Invoked when the user validates the annotation.
 *                 Suspending so the editor can drive the submission
 *                 UI (in-flight indicator, retry snackbar) before
 *                 the caller's coroutine returns.
 * @param onCancel Invoked when the user abandons the session
 *                 (back from Intro / abandon-confirmed from
 *                 Drawing).
 * @param initial  Optional pre-seeded [GenericAnnotation]
 *                 (re-edit flow). Defaults to an empty annotation.
 */
@TwinSkinInternalApi
@Composable
public fun GenericAnnotationEditor(
    image: ImageBitmap,
    onDone: suspend (GenericAnnotation) -> Unit,
    onCancel: () -> Unit,
    initial: GenericAnnotation = GenericAnnotation(regions = emptyList()),
) {
    require(image.width > 0 && image.height > 0) {
        "image must have positive dimensions (got ${image.width} × ${image.height})"
    }

    LockOrientationDuringSession()
    DeferSystemGesturesDuringSession()

    val strings = remember { genericStringsFor(sdkLocale()) }
    val imageSize = remember(image) { Size(image.width.toFloat(), image.height.toFloat()) }
    val isEditExisting = initial.regions.isNotEmpty()

    val store = remember(initial, imageSize) {
        GenericStore.fromInitial(initial, imageSize)
    }

    var step: GenericStep by rememberSaveable(image, stateSaver = genericStepSaver) {
        mutableStateOf<GenericStep>(GenericStep.Intro)
    }

    var submitting by remember { mutableStateOf(false) }
    val saveSnackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    TwinSkinTheme {
    when (step) {
        GenericStep.Intro -> GenericIntroScreen(
            hasExistingState = isEditExisting,
            strings = strings,
            onResume = { step = GenericStep.Drawing },
            onStart = {
                // Wipe imported regions on Start fresh so the user
                // lands on a genuinely blank canvas — mirrors the
                // wound editor's M15.7 semantics.
                store.clear()
                step = GenericStep.Drawing
            },
            onCancel = onCancel,
        )
        GenericStep.Drawing -> {
            GenericDrawingScreen(
                image = image,
                imageSize = imageSize,
                store = store,
                strings = strings,
                isSubmitting = submitting,
                snackbarHostState = saveSnackbar,
                onBack = onCancel,
                onValidate = {
                    if (submitting) return@GenericDrawingScreen
                    scope.launch {
                        while (true) {
                            submitting = true
                            // The boundary emit is INSIDE the runCatching:
                            // its degenerate-polygon check used to throw in
                            // a scope with no exception handler and crash
                            // the host app instead of surfacing the retry
                            // snackbar. Cancellation (editor unmounted
                            // mid-submit) is teardown, not a save failure.
                            val result = runCatching {
                                onDone(toGenericAnnotation(store, imageSize))
                            }.onFailure {
                                if (it is kotlinx.coroutines.CancellationException) throw it
                            }
                            submitting = false
                            if (result.isSuccess) return@launch
                            val outcome = saveSnackbar.showSnackbar(
                                message = strings.saveFailedSnackbar,
                                actionLabel = strings.retryAction,
                                duration = SnackbarDuration.Indefinite,
                            )
                            if (outcome != SnackbarResult.ActionPerformed) return@launch
                        }
                    }
                },
            )
        }
    }
    }
}
