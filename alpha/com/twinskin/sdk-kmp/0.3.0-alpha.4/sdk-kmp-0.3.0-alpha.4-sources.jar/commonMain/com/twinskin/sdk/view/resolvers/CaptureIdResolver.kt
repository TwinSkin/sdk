@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.view.resolvers

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.CaptureEntry
import com.twinskin.sdk.capture.CaptureObserver
import com.twinskin.sdk.capture.CaptureState
import com.twinskin.sdk.debug
import com.twinskin.sdk.error
import com.twinskin.sdk.view.Asset3D
import com.twinskin.sdk.view.Asset3DFormat
import com.twinskin.sdk.view.CaptureNotFoundException
import com.twinskin.sdk.view.CaptureResolver
import com.twinskin.sdk.view.CaptureViewerSummary
import com.twinskin.sdk.view.Image2DAsset
import com.twinskin.sdk.view.LoadProgress
import com.twinskin.sdk.view.ResolvedCapture
import com.twinskin.sdk.view.ResolverEvent
import com.twinskin.sdk.view.cachedFileExists
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow

/**
 * Reactive resolver: subscribes to the capture's PowerSync row and
 * emits a fresh [ResolverEvent.Resolved] whenever the joined row
 * changes (status, asset key, latest annotation). Asset downloads are
 * gated on key changes — annotation edits don't trigger redownloads.
 *
 * Cache layout: `<cacheDir>/<captureId>-<sha256(s3Key) hex16>.<ext>`.
 * Stable per S3 key, so a re-opened capture is offline-friendly. Flat
 * (no per-capture subdir) so [SdkStorage.sweep] can age out unused
 * entries by their own file mtime — a subdir's mtime doesn't track
 * the freshness of files inside it.
 *
 * Asset URL minting and download are injected so tests can drive the
 * resolver without an HTTP server. Production wires
 * `assetUrlBuilder` to mint the session-token Authorization header
 * pair, and `downloadAsset` to call `downloadToPath`.
 */
internal class CaptureIdResolver(
    private val captureId: String,
    private val subjectRef: String,
    private val captureObserver: CaptureObserver,
    private val assetUrlBuilder: suspend (s3Key: String) -> Pair<String, Map<String, String>>,
    private val cacheDir: String,
    private val downloadAsset: suspend (url: String, destPath: String, headers: Map<String, String>) -> Unit,
    private val logger: SdkLogger? = null,
) : CaptureResolver {

    /** Convenience constructor used in tests where headers are uninteresting. */
    constructor(
        captureId: String,
        subjectRef: String,
        captureObserver: CaptureObserver,
        assetUrlBuilder: suspend (s3Key: String) -> Pair<String, Map<String, String>>,
        cacheDir: String,
        downloadAsset: suspend (url: String, destPath: String) -> Unit,
    ) : this(
        captureId = captureId,
        subjectRef = subjectRef,
        captureObserver = captureObserver,
        assetUrlBuilder = assetUrlBuilder,
        cacheDir = cacheDir,
        downloadAsset = { url, dest, _ -> downloadAsset(url, dest) },
        logger = null,
    )

    override fun resolve(): Flow<ResolverEvent> = channelFlow {
        var lastImageKey: String? = null
        var image2DPath: String? = null
        var lastGlbKey: String? = null
        var glbPath: String? = null

        captureObserver.observeCapture(captureId, subjectRef).collect { row ->
            if (row == null) {
                throw CaptureNotFoundException(
                    "Capture $captureId not found for subject $subjectRef",
                )
            }
            // 2D first — usually lands first in the pipeline.
            val imageKey = row.referenceImageKey
            if (imageKey != null && imageKey != lastImageKey) {
                send(ResolverEvent.Progress(LoadProgress.Downloading(0L, null)))
                image2DPath = downloadIfMissing(imageKey, "jpg")
                lastImageKey = imageKey
            }
            val glbKey = row.resultPreview3dGlbKey
            if (glbKey != null && glbKey != lastGlbKey) {
                send(ResolverEvent.Progress(LoadProgress.Downloading(0L, null)))
                glbPath = downloadIfMissing(glbKey, "glb")
                lastGlbKey = glbKey
            }
            val resolved = ResolvedCapture(
                model = glbPath?.let {
                    Asset3D(it, Asset3DFormat.GLB, viewMetadata = row.markerView)
                },
                image2D = image2DPath?.let { Image2DAsset(it) },
                annotation = row.latestAnnotation,
                measurement = row.latestMeasurement,
                summary = buildSummary(row),
                isMeasurementCalculating = row.isMeasurementCalculating,
                conditionType = row.conditionType,
            )
            send(ResolverEvent.Resolved(resolved))
        }
    }

    private suspend fun downloadIfMissing(s3Key: String, ext: String): String {
        val destPath = "$cacheDir/$captureId-${stableUrlHash(s3Key)}.$ext"
        if (cachedFileExists(destPath)) {
            logger?.debug("[viewCapture cap-id $captureId] cache HIT $s3Key → $destPath")
            return destPath
        }
        val (url, headers) = try {
            assetUrlBuilder(s3Key)
        } catch (e: CancellationException) { throw e }
        catch (t: Throwable) {
            logger?.error("[viewCapture cap-id $captureId] credentials FAILED for $s3Key", t)
            throw t
        }
        try {
            downloadAsset(url, destPath, headers)
        } catch (e: CancellationException) { throw e }
        catch (t: Throwable) {
            logger?.error(
                "[viewCapture cap-id $captureId] download FAILED for $s3Key: " +
                    "${t::class.simpleName}: ${t.message}",
                t,
            )
            throw t
        }
        logger?.debug("[viewCapture cap-id $captureId] downloaded $s3Key → $destPath")
        return destPath
    }

    /**
     * Clinician-facing header facts. Skips internal fields (capture id, subject
     * ref, raw status) — those help SDK debugging but aren't useful at the
     * bedside. Per-region measurement rows are rendered separately by the
     * viewer's MeasurementsSection (which reads the structured `measurement`
     * and shows every region), so they aren't carried here.
     */
    private fun buildSummary(row: CaptureEntry): CaptureViewerSummary = CaptureViewerSummary(
        capturedAtEpochMs = row.updatedAtEpochMs.takeIf { it > 0L },
        analysisPending = row.state != CaptureState.Succeeded,
    )
}
