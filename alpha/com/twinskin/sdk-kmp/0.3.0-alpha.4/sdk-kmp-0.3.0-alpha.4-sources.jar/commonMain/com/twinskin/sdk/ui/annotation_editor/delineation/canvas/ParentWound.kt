package com.twinskin.sdk.ui.annotation_editor.delineation.canvas

import androidx.compose.ui.geometry.Offset
import com.twinskin.sdk.geometry.centroid
import com.twinskin.sdk.geometry.pointInPolygon
import com.twinskin.sdk.ui.annotation_editor.delineation.model.Tissue

/**
 * Screen-4-only parent-wound resolution helpers (spec §8.5).
 *
 * The DrawingCanvas owns parent-wound state for the lifetime of one
 * gesture / one focus session and resolves the wound via these
 * helpers. M11 doesn't see them — parent-wound is gesture-local
 * concern, not store-level.
 */

/**
 * Index of the first wound in [wounds] that contains [touchImage],
 * or `null` if none does. First-match is fine in v1 — wound overlap
 * is forbidden (spec §6.4.3), so at most one wound contains any
 * given image-pixel point.
 *
 * Used at stroke-start: the wound the finger is currently inside
 * becomes the parent for the entire stroke (spec §8.5 "established
 * at the tissue stroke's commit").
 */
internal fun parentWoundIdxAt(touchImage: Offset, wounds: List<List<Offset>>): Int? {
    for ((i, wound) in wounds.withIndex()) {
        if (pointInPolygon(touchImage, wound)) return i
    }
    return null
}

/**
 * Index of the wound containing [tissue]'s centroid, or `null` if
 * the centroid lands outside every wound (defensive — shouldn't
 * happen for a tissue committed via the normal flow, but a malformed
 * seed could trigger it).
 *
 * Used when a reshape gesture starts on an existing tissue — the
 * parent stays fixed for the gesture's duration (spec §8.5).
 */
internal fun parentWoundOfTissue(tissue: Tissue, wounds: List<List<Offset>>): Int? =
    parentWoundIdxAt(centroid(tissue.outline), wounds)
