@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.ui.theme.TwinSkinColors
import kotlin.math.max

/**
 * Shared dark-stage primitives for the viewer rebuild — the radial-gradient
 * stage background, the floating segmented tab pill, the blurred-look tool
 * chips, and the circular close button. Pulled out of the per-pane files so
 * the 3D pane, 2D pane, loading and error screens all draw the SAME stage.
 *
 * "Blur" in the prototype is approximated with translucent fills — Compose
 * Multiplatform 1.10's `Modifier.blur` is Android-only at this layer, so a
 * real backdrop blur would diverge between platforms; the semi-transparent
 * fills track the mockup's look without that risk.
 */

internal val ViewerStageTop = Color(0xFF1C2A30)

/**
 * The dark radial-gradient stage: `radial-gradient(80% 80% at 50% 36%,
 * #1c2a30 0%, #0B0F11 100%)`. [centerYFraction] lets the loading screen nudge
 * the focus to 38% per the prototype while the ready stage uses 36%.
 *
 * The brush is built in [drawBehind] so it can size to the box's pixels — the
 * gradient radius is 80% of the larger dimension, matching the CSS spread.
 */
@Composable
internal fun ViewerStageBackground(
    modifier: Modifier = Modifier,
    centerYFraction: Float = 0.36f,
    content: @Composable BoxScope.() -> Unit = {},
) {
    Box(
        modifier = modifier
            .background(TwinSkinColors.ViewDark)
            .drawBehind {
                val radius = max(size.width, size.height) * 0.80f
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(ViewerStageTop, TwinSkinColors.ViewDark),
                        center = Offset(size.width * 0.5f, size.height * centerYFraction),
                        radius = radius,
                    ),
                )
            },
    ) { content() }
}

/** A floating segmented tab pill (3D / 2D) drawn over the dark stage. */
@Composable
internal fun ViewerTabPill(
    tabs: List<Pair<String, String>>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color.Black.copy(alpha = 0.40f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        for ((key, label) in tabs) {
            val active = key == selectedKey
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(9.dp))
                    .background(if (active) TwinSkinColors.Cyan else Color.Transparent)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { onSelect(key) }
                    .padding(horizontal = 22.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = label,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (active) TwinSkinColors.OnCyan else Color.White.copy(alpha = 0.70f),
                )
            }
        }
    }
}


/** Translucent circular icon button (the top-bar close affordance). */
@Composable
internal fun ViewerCircleButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.12f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = Color.White,
            modifier = Modifier.size(19.dp),
        )
    }
}
