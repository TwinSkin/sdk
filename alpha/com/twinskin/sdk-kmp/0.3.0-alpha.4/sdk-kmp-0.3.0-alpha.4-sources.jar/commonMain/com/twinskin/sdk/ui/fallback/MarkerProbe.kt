package com.twinskin.sdk.ui.fallback

/**
 * Outcome of the marker probe on the captured reference still.
 *
 * Carries two orthogonal signals so the probe can fail open for the UI without
 * fabricating a manifest value (mirrors [LowLightProbeResult]):
 * - [detected] drives the presentation-only warning card. A probe error or
 *   unwired probe reads as `true` (no false "marker not detected" warning).
 * - [version] is forwarded verbatim into the manifest's `marker_version`.
 *   Non-null ONLY when the expected calibration marker decoded; `null` on
 *   absence, probe error, or no probe. Never fabricated.
 *
 * The two can diverge: a probe error yields `detected = true, version = null`.
 */
public data class MarkerProbeResult(
    val detected: Boolean,
    val version: String?,
) {
    public companion object {
        /**
         * Mirrors the photosphere path's literal verbatim, so an
         * accelerometer-capture bundle carries the SAME `marker_version` the
         * photosphere flow would for the same printed marker.
         */
        public const val EXPECTED_MARKER_VERSION: String = "v3"

        /** No-false-positive default: no warning, no fabricated manifest value. */
        public val Detected: MarkerProbeResult = MarkerProbeResult(detected = true, version = null)

        /** Expected marker positively decoded — warning cleared, version stamped. */
        public val Expected: MarkerProbeResult =
            MarkerProbeResult(detected = true, version = EXPECTED_MARKER_VERSION)

        /** Marker absent — raise the warning card, no version. */
        public val Absent: MarkerProbeResult = MarkerProbeResult(detected = false, version = null)
    }
}
