package com.twinskin.sdk.ui.annotation_editor.polygon.ui_helpers

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Sub-100ms transient toast for high-frequency, low-density UI
 * hints (e.g. "Too far from the current stroke"). Bypasses
 * Material 3 [androidx.compose.material3.SnackbarHost] — the
 * snackbar's enter/exit chain feels sluggish for sub-frame
 * finger-down feedback.
 *
 * Composition-driven — caller flips [text] from null to non-null on
 * the trigger and back to null on a timer (or on the next
 * trigger). The 80 ms fade-in puts the hint visibly on-screen
 * within ~96 ms of the state change; the 150 ms fade-out feels
 * smooth without lingering. No queue.
 *
 * **When NOT to use.** This is a one-line transient hint. Multi-
 * line content, action affordances (Retry, Undo), or anything the
 * user is meant to read at their own pace belongs on the snackbar
 * — keep [androidx.compose.material3.SnackbarHostState] for those.
 */
@Composable
internal fun TransientHint(
    text: String?,
    modifier: Modifier = Modifier,
) {
    AnimatedVisibility(
        visible = text != null,
        enter = fadeIn(animationSpec = tween(durationMillis = 80)),
        exit = fadeOut(animationSpec = tween(durationMillis = 150)),
        modifier = modifier,
    ) {
        Surface(
            color = MaterialTheme.colorScheme.inverseSurface,
            contentColor = MaterialTheme.colorScheme.inverseOnSurface,
            shape = MaterialTheme.shapes.small,
            tonalElevation = 6.dp,
        ) {
            Text(
                text = text.orEmpty(),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}
