package com.twinskin.sdk.capture

import com.twinskin.sdk.TwinSkinInternalApi
import com.twinskin.sdk.capture.io.fileExists
import com.twinskin.sdk.capture.io.listDir

// view_AAA_rXaY.jpg — AAA = 3-digit azimuth (000..359), X = round, Y = arm.
private val viewFilenamePattern = Regex("""^view_\d{3}_r\d+a\d+\.jpg$""")

/**
 * `markerVersion` is in-memory ref state — caller overrides via `copy()`.
 * Public for K/N → Swift exposure; [TwinSkinInternalApi] gates integrators.
 * @throws IllegalStateException if `ref_image.jpg` is missing.
 */
@TwinSkinInternalApi
public fun bundleDirToCaptureResult(sessionDir: String): CaptureResult {
    val refPath = "$sessionDir/ref_image.jpg"
    check(fileExists(refPath)) {
        "expected ref_image.jpg in $sessionDir after finalize"
    }

    // Whitelist canonical photosphere naming so debug snapshots in the
    // same dir don't get scooped into the encrypted upload.
    val framePaths = listDir(sessionDir)
        .filter { viewFilenamePattern.matches(it) }
        .sorted()
        .map { "$sessionDir/$it" }

    return CaptureResult(
        photoPath = refPath,
        framePaths = framePaths,
        markerVersion = null,
    )
}
