@file:OptIn(com.twinskin.sdk.TwinSkinInternalApi::class)

package com.twinskin.sdk.ui.view_capture.subview

import com.twinskin.sdk.TwinSkinInternalApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twinskin.sdk.capture.GenericMeasurement
import com.twinskin.sdk.capture.SdkMeasurement
import com.twinskin.sdk.capture.WoundMeasurement
import com.twinskin.sdk.capture.WoundRegionMeasurement
import com.twinskin.sdk.capture.epochMillisToIso8601
import com.twinskin.sdk.i18n.sdkLocale
import com.twinskin.sdk.ui.capture.i18n.SdkCaptureStrings
import com.twinskin.sdk.ui.capture.i18n.captureStringsFor
import com.twinskin.sdk.ui.theme.TwinSkinColors
import com.twinskin.sdk.view.CaptureViewerSummary

/**
 * Viewer metadata bottom sheet (prototype `MetadataPanel`): a grab handle,
 * a header (eyebrow / capture title / date-clinician / "Analyzed" chip),
 * and — for wounds — a Measurements/Tissues sub-tab toggle. Measurements is a
 * 2-column grid of metric cards; Tissues is a stacked bar + legend.
 *
 * This composite reads the real [com.twinskin.sdk.view.ViewCaptureState.Ready]
 * rather than the prototype's hardcoded sample, so several mockup affordances
 * degrade against the live data model (see the per-section notes below).
 */
@TwinSkinInternalApi
@Composable
internal fun ViewerMetadataSheet(
    summary: CaptureViewerSummary,
    measurement: SdkMeasurement?,
    isSubmitting: Boolean,
    modifier: Modifier = Modifier,
) {
    val strings = remember { captureStringsFor(sdkLocale()) }
    val isWound = measurement is WoundMeasurement
    // The resolver's summary carries only the capture timestamp and the
    // analysis-pending flag; the prototype's rich subject/clinician/body-location
    // header isn't available, so the sub-line degrades to the timestamp and the
    // title falls back to a generic label.
    val analysisPending = summary.analysisPending
    val captured = summary.capturedAtEpochMs?.let { formatCapturedTimestamp(it) }
    val eyebrow = if (isWound) strings.viewerSheetEyebrowWound else strings.viewerSheetEyebrowGeneric

    // Draggable height: the sheet snaps between a collapsed peek and an
    // expanded height. The drag gesture is attached to the WHOLE sheet — drag
    // anywhere on it to move it up/down, not just the handle. Internal content
    // scrolling is DISABLED while collapsed (so a drag anywhere just moves the
    // sheet) and only ENABLED once expanded (where the content may exceed the
    // height). Nav-bar inset keeps the bottom tiles clear of the system nav bar.
    val density = LocalDensity.current
    val collapsedPx = with(density) { 300.dp.toPx() }
    val expandedPx = with(density) { 600.dp.toPx() }
    var heightPx by remember { mutableStateOf(collapsedPx) }
    val sheetHeight = with(density) { heightPx.toDp() }
    val expanded = heightPx >= (collapsedPx + expandedPx) / 2f
    val scrollState = rememberScrollState()

    fun snap() {
        val mid = (collapsedPx + expandedPx) / 2f
        heightPx = if (heightPx >= mid) expandedPx else collapsedPx
    }

    // Lets the sheet resize from drags that the inner scroll would otherwise
    // eat: a drag DOWN (dragging to close) is consumed by the sheet first
    // whenever the content is already scrolled to the top; a drag UP grows the
    // sheet until it's fully expanded, after which the scroll takes over. This
    // is what makes "drag anywhere to open AND close" work even over the
    // scrollable metric list.
    val nestedScroll = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val dy = available.y
                if (dy > 0f && scrollState.value == 0 && heightPx > collapsedPx) {
                    // Dragging down with nothing left to scroll up → shrink sheet.
                    val consume = (heightPx - collapsedPx).coerceAtMost(dy)
                    heightPx -= consume
                    return Offset(0f, consume)
                }
                if (dy < 0f && heightPx < expandedPx) {
                    // Dragging up while not fully expanded → grow sheet first.
                    val consume = (expandedPx - heightPx).coerceAtMost(-dy)
                    heightPx += consume
                    return Offset(0f, -consume)
                }
                return Offset.Zero
            }
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onVerticalDrag = { _, dragAmount ->
                        heightPx = (heightPx - dragAmount).coerceIn(collapsedPx, expandedPx)
                    },
                    onDragEnd = { snap() },
                )
            },
        color = TwinSkinColors.Surface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        shadowElevation = 12.dp,
    ) {
        Column(
            modifier = Modifier
                .height(sheetHeight)
                .navigationBarsPadding()
                .nestedScroll(nestedScroll),
        ) {
            // Grab handle — also tappable to toggle collapsed/expanded.
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) {
                        heightPx = if (expanded) collapsedPx else expandedPx
                    },
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    Modifier
                        .size(width = 40.dp, height = 5.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(TwinSkinColors.Line),
                )
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scrollState)
                    .padding(start = 18.dp, end = 18.dp, top = 6.dp, bottom = 18.dp),
            ) {
                SheetHeader(
                    eyebrow = eyebrow,
                    captured = captured,
                    analysisPending = analysisPending,
                    strings = strings,
                )
                if (isWound) {
                    Spacer(Modifier.height(14.dp))
                    WoundSheetBody(
                        measurement = measurement as WoundMeasurement,
                        isSubmitting = isSubmitting,
                        strings = strings,
                    )
                } else {
                    Spacer(Modifier.height(13.dp))
                    MetricGrid(
                        cards = measurement.toMetricCards(strings),
                        isSubmitting = isSubmitting,
                    )
                }
            }
        }
    }
}

@Composable
private fun SheetHeader(
    eyebrow: String,
    captured: String?,
    analysisPending: Boolean,
    strings: SdkCaptureStrings,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                text = eyebrow,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.2.sp,
                color = TwinSkinColors.Ink2,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = strings.viewerSheetTitle,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TwinSkinColors.Ink,
            )
            if (captured != null) {
                Spacer(Modifier.height(1.dp))
                Text(
                    text = captured,
                    fontSize = 12.sp,
                    color = TwinSkinColors.Ink2,
                )
            }
        }
        AnalysisChip(pending = analysisPending, strings = strings)
    }
}

/** "Analyzed" / "In progress" status chip with a sparkle glyph. */
@Composable
private fun AnalysisChip(pending: Boolean, strings: SdkCaptureStrings) {
    val (bg, fg, label) = if (pending) {
        Triple(TwinSkinColors.WarningContainer, TwinSkinColors.Warning, strings.viewerStatusInProgress)
    } else {
        Triple(Color(0xFFE4F7EC), TwinSkinColors.Success, strings.viewerStatusAnalyzed)
    }
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(9.dp))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = fg,
            modifier = Modifier.size(13.dp),
        )
        Spacer(Modifier.width(5.dp))
        Text(text = label, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = fg)
    }
}

@Composable
private fun WoundSheetBody(
    measurement: WoundMeasurement,
    isSubmitting: Boolean,
    strings: SdkCaptureStrings,
) {
    val tissueSegments = measurement.toTissueSegments()
    var subTab by remember { mutableStateOf(WoundSubTab.Measurements) }

    // Only offer the Tissues sub-tab when structured tissue data exists;
    // otherwise the sheet shows the metric grid alone (no empty bar).
    if (tissueSegments.isNotEmpty()) {
        SubTabToggle(selected = subTab, onSelect = { subTab = it }, strings = strings)
        Spacer(Modifier.height(13.dp))
    }

    if (tissueSegments.isEmpty() || subTab == WoundSubTab.Measurements) {
        MetricGrid(cards = measurement.toMetricCards(strings), isSubmitting = isSubmitting)
    } else {
        TissueComposition(segments = tissueSegments)
    }
}

private enum class WoundSubTab { Measurements, Tissues }

@Composable
private fun SubTabToggle(
    selected: WoundSubTab,
    onSelect: (WoundSubTab) -> Unit,
    strings: SdkCaptureStrings,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(11.dp))
            .background(TwinSkinColors.TintHi)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        SubTabButton(strings.viewerTabMeasurements, selected == WoundSubTab.Measurements, Modifier.weight(1f)) {
            onSelect(WoundSubTab.Measurements)
        }
        SubTabButton(strings.viewerTabTissues, selected == WoundSubTab.Tissues, Modifier.weight(1f)) {
            onSelect(WoundSubTab.Tissues)
        }
    }
}

@Composable
private fun SubTabButton(
    label: String,
    active: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        color = if (active) TwinSkinColors.CardSurface else Color.Transparent,
        shape = RoundedCornerShape(8.dp),
        shadowElevation = if (active) 2.dp else 0.dp,
    ) {
        Box(Modifier.padding(vertical = 8.dp), Alignment.Center) {
            Text(
                text = label,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (active) TwinSkinColors.Ink else TwinSkinColors.Ink2,
            )
        }
    }
}

// ── Metric grid ────────────────────────────────────────────

/** One metric card's data. [region] labels the card when several regions exist. */
internal data class MetricCard(
    val label: String,
    val value: String,
    val unit: String,
    val icon: ImageVector,
)

@Composable
private fun MetricGrid(cards: List<MetricCard>, isSubmitting: Boolean) {
    if (cards.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        cards.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                MetricCardCell(row[0], isSubmitting, Modifier.weight(1f))
                if (row.size > 1) {
                    MetricCardCell(row[1], isSubmitting, Modifier.weight(1f))
                } else {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun MetricCardCell(card: MetricCard, isSubmitting: Boolean, modifier: Modifier) {
    Surface(
        modifier = modifier,
        color = TwinSkinColors.CardSurface,
        shape = RoundedCornerShape(14.dp),
        shadowElevation = 2.dp,
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(28.dp).clip(CircleShape).background(TwinSkinColors.TintMid),
                    Alignment.Center,
                ) {
                    Icon(card.icon, null, tint = TwinSkinColors.Teal, modifier = Modifier.size(15.dp))
                }
                Spacer(Modifier.width(7.dp))
                Text(
                    card.label,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TwinSkinColors.Ink2,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(10.dp))
            if (isSubmitting) {
                CalculatingText(color = TwinSkinColors.Ink2, fontWeight = FontWeight.Bold)
            } else {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        card.value,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = TwinSkinColors.Ink,
                        maxLines = 1,
                    )
                    if (card.unit.isNotEmpty()) {
                        Spacer(Modifier.width(3.dp))
                        Text(
                            card.unit,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TwinSkinColors.Ink2,
                            maxLines = 1,
                            modifier = Modifier.padding(bottom = 2.dp),
                        )
                    }
                }
            }
        }
    }
}

// ── Tissue composition ─────────────────────────────────────

internal data class TissueSegment(
    val name: String,
    val fraction: Float,
    val color: Color,
)

@Composable
private fun TissueComposition(segments: List<TissueSegment>) {
    Surface(
        color = TwinSkinColors.CardSurface,
        shape = RoundedCornerShape(14.dp),
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(15.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(13.dp)
                    .clip(RoundedCornerShape(7.dp)),
            ) {
                segments.forEach { seg ->
                    Box(
                        Modifier
                            .weight(seg.fraction.coerceAtLeast(0.0001f))
                            .fillMaxHeight()
                            .background(seg.color),
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                segments.forEach { seg ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(11.dp).clip(RoundedCornerShape(4.dp)).background(seg.color))
                        Spacer(Modifier.width(10.dp))
                        Text(
                            seg.name,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = TwinSkinColors.Ink,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            "${(seg.fraction * 100).roundToIntCompat()}%",
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = TwinSkinColors.Ink,
                        )
                    }
                }
            }
        }
    }
}

// ── Real-data derivation ───────────────────────────────────
//
// Maps the structured measurement into the sheet's view-models. A capture can
// carry SEVERAL regions; the grid surfaces all of them — when there's more
// than one, each card's label is suffixed with the region index so no region
// is collapsed into the first.

private fun SdkMeasurement?.toMetricCards(strings: SdkCaptureStrings): List<MetricCard> = when (this) {
    null -> emptyList()
    is GenericMeasurement -> regions.toMetricCards(
        strings = strings,
        surface = { it.surfaceMm2 },
        perimeter = { it.perimeterMm },
        maxDepth = { it.maxDepthMm },
        volume = { it.volumeMm3 },
    )
    is WoundMeasurement -> regions.toMetricCards(
        strings = strings,
        surface = { it.surfaceMm2 },
        perimeter = { it.perimeterMm },
        maxDepth = { it.maxDepthMm },
        volume = { it.volumeMm3 },
    )
}

private fun <R> List<R>.toMetricCards(
    strings: SdkCaptureStrings,
    surface: (R) -> Double,
    perimeter: (R) -> Double?,
    maxDepth: (R) -> Double?,
    volume: (R) -> Double?,
): List<MetricCard> = buildList {
    val multi = this@toMetricCards.size > 1
    this@toMetricCards.forEachIndexed { index, region ->
        val suffix = if (multi) " · " + strings.viewerRegionShort((index + 1).toString()) else ""
        addAreaCard(strings.viewerMetricArea + suffix, surface(region))
        perimeter(region)?.let { addLenCard(strings.viewerMetricPerimeter + suffix, it, Icons.Default.Straighten) }
        maxDepth(region)?.let { addLenCard(strings.viewerMetricMaxDepth + suffix, it, Icons.Default.Layers) }
        volume(region)?.let { addVolumeCard(strings.viewerMetricVolume + suffix, it) }
    }
}

private fun MutableList<MetricCard>.addAreaCard(label: String, surfaceMm2: Double) {
    val (value, unit) = formatArea(surfaceMm2)
    add(MetricCard(label, value, unit, Icons.Default.GridOn))
}

private fun MutableList<MetricCard>.addLenCard(label: String, lengthMm: Double, icon: ImageVector) {
    val (value, unit) = formatLength(lengthMm)
    add(MetricCard(label, value, unit, icon))
}

private fun MutableList<MetricCard>.addVolumeCard(label: String, volumeMm3: Double) {
    val (value, unit) = formatVolume(volumeMm3)
    add(MetricCard(label, value, unit, Icons.Default.ViewInAr))
}

/**
 * Tissue segments for the stacked bar. Only [WoundRegionMeasurement] carries
 * structured `tissues`; generic captures never do, so the Tissues sub-tab is
 * suppressed for them. Several wound regions' tissues are summed by type, then
 * normalised to fractions.
 */
private fun WoundMeasurement.toTissueSegments(): List<TissueSegment> {
    val byType = linkedMapOf<String, Double>()
    regions.forEach { region: WoundRegionMeasurement ->
        region.tissues.forEach { tissue ->
            byType[tissue.tissueType] = (byType[tissue.tissueType] ?: 0.0) + tissue.surfaceMm2
        }
    }
    val total = byType.values.sum()
    if (total <= 0.0) return emptyList()
    return byType.entries.map { (type, area) ->
        TissueSegment(
            name = tissueDisplayName(type),
            fraction = (area / total).toFloat(),
            color = tissueColor(type),
        )
    }
}

private fun tissueDisplayName(type: String): String =
    type.replace('_', ' ').replaceFirstChar { if (it.isLowerCase()) it.uppercaseChar() else it }

// Clinical color coding must match the 2D overlay exactly — one mapping.
private fun tissueColor(type: String): Color = tissueOverlayColor(type)

// commonMain has no printf; emit "value" + "unit" pairs with cm preference.

private fun formatLength(mm: Double): Pair<String, String> =
    if (mm >= 10) roundTo1(mm / 10) to "cm" else roundTo1(mm) to "mm"

private fun formatArea(mm2: Double): Pair<String, String> {
    val cm2 = mm2 / 100.0
    return if (cm2 >= 1) roundTo2(cm2) to "cm²" else roundTo1(mm2) to "mm²"
}

private fun formatVolume(mm3: Double): Pair<String, String> {
    val cm3 = mm3 / 1000.0
    return if (cm3 >= 1) roundTo2(cm3) to "cm³" else roundTo1(mm3) to "mm³"
}

private fun roundTo1(v: Double): String = v.formatFixed(1)
private fun roundTo2(v: Double): String = v.formatFixed(2)

private fun Double.formatFixed(decimals: Int): String {
    var factor = 1L
    repeat(decimals) { factor *= 10 }
    val scaled = kotlin.math.round(this * factor).toLong()
    val sign = if (scaled < 0) "-" else ""
    val mag = kotlin.math.abs(scaled)
    val frac = (mag % factor).toString().padStart(decimals, '0').trimEnd('0')
    return if (frac.isEmpty()) "$sign${mag / factor}" else "$sign${mag / factor}.$frac"
}

private fun Float.roundToIntCompat(): Int = kotlin.math.round(this).toInt()

/**
 * `epochMillisToIso8601` returns `YYYY-MM-DDTHH:MM:SSZ`. Trim seconds for a
 * calmer clinician-facing timestamp; keep `UTC` (a timezone identifier, not
 * translated) so callers reading across time zones aren't misled.
 */
private fun formatCapturedTimestamp(epochMs: Long): String {
    if (epochMs <= 0L) return "—"
    val iso = epochMillisToIso8601(epochMs)
    val tIdx = iso.indexOf('T')
    if (tIdx < 0 || iso.length < tIdx + 6) return iso
    val date = iso.substring(0, tIdx)
    val hourMinute = iso.substring(tIdx + 1, tIdx + 6)
    return "$date $hourMinute UTC"
}
