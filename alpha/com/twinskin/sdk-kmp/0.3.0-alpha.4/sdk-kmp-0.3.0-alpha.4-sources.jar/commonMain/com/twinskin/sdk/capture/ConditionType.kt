// GENERATED CODE — DO NOT EDIT BY HAND
// Source: lib/src/database/schema.dart
// Regenerate: fvm dart run tool/generate_kotlin_sdk_client.dart

package com.twinskin.sdk.capture

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
public enum class ConditionType {
    @SerialName("wound") Wound,
    @SerialName("generic") Generic;
}
