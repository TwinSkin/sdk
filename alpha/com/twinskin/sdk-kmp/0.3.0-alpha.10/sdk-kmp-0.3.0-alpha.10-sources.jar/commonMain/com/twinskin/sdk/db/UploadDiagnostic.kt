package com.twinskin.sdk.db

import kotlin.Long
import kotlin.String

public data class UploadDiagnostic(
  public val id: String,
  public val captureId: String,
  public val subjectRef: String,
  public val userRef: String,
  public val payload: String,
  public val sent: Long,
  public val lastAttemptAt: Long,
)
