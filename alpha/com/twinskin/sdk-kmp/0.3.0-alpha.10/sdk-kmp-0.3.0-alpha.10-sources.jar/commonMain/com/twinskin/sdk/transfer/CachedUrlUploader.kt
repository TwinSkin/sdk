package com.twinskin.sdk.transfer

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.debug
import com.twinskin.sdk.info
import com.twinskin.sdk.warn

internal sealed class CachedUploadOutcome {
    object Done : CachedUploadOutcome()
    object NeedsRefresh : CachedUploadOutcome()
    object RetryLater : CachedUploadOutcome()
    data class PermanentFailure(val reason: String) : CachedUploadOutcome()
}

internal sealed class HttpPutResult {
    object Success : HttpPutResult()
    object UrlExpired : HttpPutResult()
    data class ClientError(val statusCode: Int) : HttpPutResult()
    object TransientError : HttpPutResult()
}

internal typealias HttpPutFn = suspend (
    url: String,
    localPath: String,
    onProgress: suspend (Long, Long) -> Unit,
) -> HttpPutResult

internal class CachedUrlUploader(
    private val database: TwinSkinDatabase,
    private val httpPut: HttpPutFn,
    private val clock: () -> Long,
    private val logger: SdkLogger,
    private val pathResolver: PathResolver = IdentityPathResolver,
) {
    suspend fun attempt(
        taskId: String,
        onProgress: suspend (Long, Long) -> Unit = { _, _ -> },
    ): CachedUploadOutcome {
        val row = database.transferTaskQueries.selectById(taskId).executeAsOneOrNull()
            ?: return CachedUploadOutcome.PermanentFailure("task row not found")

        // localPath is stored in storage-relative form (iOS strips the volatile
        // container prefix); re-anchor to an absolute path before touching the disk.
        val localPath = pathResolver.fromStorage(row.localPath)

        if (!fileExists(localPath)) {
            val msg = "File not found: $localPath"
            database.transferTaskQueries.updateStatusAndError(
                status = TransferStatus.FAILED.name,
                errorMessage = msg,
                updatedAt = clock(),
                id = taskId,
            )
            return CachedUploadOutcome.PermanentFailure(msg)
        }

        val cachedUrl = row.presignedUrl
        val expiresAt = row.presignedUrlExpiresAt
        val now = clock()
        val urlIsUsable = cachedUrl != null && expiresAt != null && now < expiresAt - SAFETY_MARGIN_MS
        if (!urlIsUsable) return CachedUploadOutcome.NeedsRefresh

        val diagnostics = UploadDiagnostics(database)
        val attemptId = "$taskId-${clock()}"
        diagnostics.record(taskId, "put_started", attemptId)
        val result = httpPut(cachedUrl, localPath, onProgress)
        diagnostics.record(taskId, "put_finished", attemptId, when (result) {
            HttpPutResult.Success -> "success"
            HttpPutResult.UrlExpired -> "url_expired"
            is HttpPutResult.ClientError -> "http_error"
            HttpPutResult.TransientError -> "network_error"
        })
        return when (result) {
            HttpPutResult.Success -> {
                database.transferTaskQueries.updateStatus(
                    status = TransferStatus.COMPLETED.name,
                    updatedAt = clock(),
                    id = taskId,
                )
                // The bundle stays: a 2xx is the phone's reading of one PUT, and
                // only the server's release (BundleReleaseConfirmer) condemns it.
                logger.info("upload[$taskId] succeeded")
                CachedUploadOutcome.Done
            }
            HttpPutResult.UrlExpired -> {
                database.transferTaskQueries.clearPresignedUrl(updatedAt = clock(), id = taskId)
                CachedUploadOutcome.NeedsRefresh
            }
            is HttpPutResult.ClientError -> {
                val msg = "PUT failed: HTTP ${result.statusCode}"
                logger.debug("CachedUrlUploader[$taskId] $msg")
                database.transferTaskQueries.updateStatusAndError(
                    status = TransferStatus.FAILED.name,
                    errorMessage = msg,
                    updatedAt = clock(),
                    id = taskId,
                )
                CachedUploadOutcome.PermanentFailure(msg)
            }
            HttpPutResult.TransientError -> {
                logger.warn("CachedUrlUploader[$taskId] transient PUT failure — RetryLater")
                CachedUploadOutcome.RetryLater
            }
        }
    }

    private companion object {
        const val SAFETY_MARGIN_MS = 60_000L
    }
}
