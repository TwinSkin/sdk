package com.twinskin.sdk.db.shared

import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.AfterVersion
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.twinskin.sdk.db.SdkCaptureUploadQueries
import com.twinskin.sdk.db.TransferTaskQueries
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.db.UploadDiagnosticQueries
import kotlin.Long
import kotlin.Unit
import kotlin.reflect.KClass

internal val KClass<TwinSkinDatabase>.schema: SqlSchema<QueryResult.Value<Unit>>
  get() = TwinSkinDatabaseImpl.Schema

internal fun KClass<TwinSkinDatabase>.newInstance(driver: SqlDriver): TwinSkinDatabase = TwinSkinDatabaseImpl(driver)

private class TwinSkinDatabaseImpl(
  driver: SqlDriver,
) : TransacterImpl(driver),
    TwinSkinDatabase {
  override val sdkCaptureUploadQueries: SdkCaptureUploadQueries = SdkCaptureUploadQueries(driver)

  override val transferTaskQueries: TransferTaskQueries = TransferTaskQueries(driver)

  override val uploadDiagnosticQueries: UploadDiagnosticQueries = UploadDiagnosticQueries(driver)

  public object Schema : SqlSchema<QueryResult.Value<Unit>> {
    override val version: Long
      get() = 4

    override fun create(driver: SqlDriver): QueryResult.Value<Unit> {
      driver.execute(null, """
          |CREATE TABLE SdkCaptureUpload (
          |    captureId       TEXT    NOT NULL PRIMARY KEY,
          |    userRef         TEXT    NOT NULL,
          |    subjectRef      TEXT    NOT NULL,
          |    conditionType   TEXT,
          |    captureGroup    TEXT,
          |    bodyLocationJson TEXT,
          |    customJson      TEXT,
          |    deviceInfoJson  TEXT,
          |    encryptedPath   TEXT    NOT NULL,
          |    transferTaskId  TEXT,
          |    -- 1 while a ConditionType.Generic capture is still waiting for the
          |    -- user to trace and submit an annotation; flipped to 0 by the
          |    -- submitAnnotation success path. Wound captures are written with 0.
          |    annotationPending  INTEGER NOT NULL DEFAULT 0,
          |    -- Which capture pipeline produced this bundle, persisted as a
          |    -- nullable wire string ("photosphere" | "accelerometer_capture") so the
          |    -- upload pipeline can pick the matching bundle layout long after
          |    -- the originating session has ended. NULL on legacy rows (every
          |    -- pre-CaptureMode upload was photosphere); readers default to
          |    -- "photosphere" via CaptureMode.fromWireValue.
          |    captureMode     TEXT,
          |    createdAt       INTEGER NOT NULL DEFAULT 0,
          |    updatedAt       INTEGER NOT NULL DEFAULT 0,
          |    -- Epoch ms of the server's "released" answer to POST /upload/confirm-bundle.
          |    -- NULL keeps the bundle on disk: a COMPLETED transfer alone is the phone's
          |    -- reading of one PUT, and on 2026-09-20 that reading was wrong.
          |    serverReleasedAt INTEGER
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE TransferTask (
          |    id           TEXT    NOT NULL PRIMARY KEY,
          |    url          TEXT    NOT NULL,
          |    localPath    TEXT    NOT NULL,
          |    type         TEXT    NOT NULL,
          |    status       TEXT    NOT NULL,
          |    progress     INTEGER NOT NULL DEFAULT 0,
          |    errorMessage TEXT,
          |    unzip        INTEGER NOT NULL DEFAULT 0,
          |    headers      TEXT,
          |    createdAt    INTEGER NOT NULL DEFAULT 0,
          |    updatedAt    INTEGER NOT NULL DEFAULT 0,
          |    presignedUrl              TEXT,
          |    presignedUrlExpiresAt     INTEGER
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE TABLE UploadDiagnostic (
          |    id TEXT NOT NULL PRIMARY KEY,
          |    captureId TEXT NOT NULL,
          |    subjectRef TEXT NOT NULL,
          |    userRef TEXT NOT NULL,
          |    payload TEXT NOT NULL,
          |    sent INTEGER NOT NULL DEFAULT 0,
          |    lastAttemptAt INTEGER NOT NULL DEFAULT 0
          |)
          """.trimMargin(), 0)
      driver.execute(null, """
          |CREATE UNIQUE INDEX TransferTask_active_upload
          |    ON TransferTask(url)
          |    WHERE type = 'UPLOAD' AND status IN ('PENDING', 'ACTIVE', 'UNZIPPING')
          """.trimMargin(), 0)
      return QueryResult.Unit
    }

    private fun migrateInternal(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
    ): QueryResult.Value<Unit> {
      if (oldVersion <= 1 && newVersion > 1) {
        driver.execute(null, """
            |CREATE TABLE SdkCaptureUpload_v2_migrate (
            |    captureId       TEXT    NOT NULL PRIMARY KEY,
            |    userRef         TEXT    NOT NULL,
            |    subjectRef      TEXT    NOT NULL,
            |    conditionType   TEXT,
            |    captureGroup    TEXT,
            |    bodyLocationJson TEXT,
            |    customJson      TEXT,
            |    deviceInfoJson  TEXT,
            |    encryptedPath   TEXT    NOT NULL,
            |    transferTaskId  TEXT,
            |    annotationPending  INTEGER NOT NULL DEFAULT 0,
            |    captureMode     TEXT,
            |    createdAt       INTEGER NOT NULL,
            |    updatedAt       INTEGER NOT NULL
            |)
            """.trimMargin(), 0)
        driver.execute(null, """
            |INSERT INTO SdkCaptureUpload_v2_migrate (
            |    captureId, userRef, subjectRef, conditionType, captureGroup,
            |    bodyLocationJson, customJson, deviceInfoJson, encryptedPath,
            |    transferTaskId, annotationPending, createdAt, updatedAt
            |)
            |SELECT
            |    captureId, userRef, subjectRef, conditionType, captureGroup,
            |    bodyLocationJson, customJson, deviceInfoJson, encryptedPath,
            |    transferTaskId, annotationPending, createdAt, updatedAt
            |FROM SdkCaptureUpload
            """.trimMargin(), 0)
        driver.execute(null, "DROP TABLE SdkCaptureUpload", 0)
        driver.execute(null, "ALTER TABLE SdkCaptureUpload_v2_migrate RENAME TO SdkCaptureUpload", 0)
      }
      if (oldVersion <= 2 && newVersion > 2) {
        driver.execute(null, """
            |CREATE TABLE UploadDiagnostic (
            |    id TEXT NOT NULL PRIMARY KEY,
            |    captureId TEXT NOT NULL,
            |    subjectRef TEXT NOT NULL,
            |    userRef TEXT NOT NULL,
            |    payload TEXT NOT NULL,
            |    sent INTEGER NOT NULL DEFAULT 0,
            |    lastAttemptAt INTEGER NOT NULL DEFAULT 0
            |)
            """.trimMargin(), 0)
      }
      if (oldVersion <= 3 && newVersion > 3) {
        driver.execute(null, "ALTER TABLE SdkCaptureUpload ADD COLUMN serverReleasedAt INTEGER", 0)
      }
      return QueryResult.Unit
    }

    override fun migrate(
      driver: SqlDriver,
      oldVersion: Long,
      newVersion: Long,
      vararg callbacks: AfterVersion,
    ): QueryResult.Value<Unit> {
      var lastVersion = oldVersion

      callbacks.filter { it.afterVersion in oldVersion until newVersion }
      .sortedBy { it.afterVersion }
      .forEach { callback ->
        migrateInternal(driver, oldVersion = lastVersion, newVersion = callback.afterVersion + 1)
        callback.block(driver)
        lastVersion = callback.afterVersion + 1
      }

      if (lastVersion < newVersion) {
        migrateInternal(driver, lastVersion, newVersion)
      }
      return QueryResult.Unit
    }
  }
}
