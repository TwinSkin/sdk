package com.twinskin.sdk.db

import app.cash.sqldelight.Transacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.twinskin.sdk.db.shared.newInstance
import com.twinskin.sdk.db.shared.schema
import kotlin.Unit

public interface TwinSkinDatabase : Transacter {
  public val sdkCaptureUploadQueries: SdkCaptureUploadQueries

  public val transferTaskQueries: TransferTaskQueries

  public val uploadDiagnosticQueries: UploadDiagnosticQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.Value<Unit>>
      get() = TwinSkinDatabase::class.schema

    public operator fun invoke(driver: SqlDriver): TwinSkinDatabase = TwinSkinDatabase::class.newInstance(driver)
  }
}
