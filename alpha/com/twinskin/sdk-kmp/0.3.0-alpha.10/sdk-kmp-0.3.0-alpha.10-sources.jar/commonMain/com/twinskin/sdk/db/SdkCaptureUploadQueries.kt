package com.twinskin.sdk.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlCursor
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class SdkCaptureUploadQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> selectById(captureId: String, mapper: (
    captureId: String,
    userRef: String,
    subjectRef: String,
    conditionType: String?,
    captureGroup: String?,
    bodyLocationJson: String?,
    customJson: String?,
    deviceInfoJson: String?,
    encryptedPath: String,
    transferTaskId: String?,
    annotationPending: Long,
    captureMode: String?,
    createdAt: Long,
    updatedAt: Long,
    serverReleasedAt: Long?,
  ) -> T): Query<T> = SelectByIdQuery(captureId) { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5),
      cursor.getString(6),
      cursor.getString(7),
      cursor.getString(8)!!,
      cursor.getString(9),
      cursor.getLong(10)!!,
      cursor.getString(11),
      cursor.getLong(12)!!,
      cursor.getLong(13)!!,
      cursor.getLong(14)
    )
  }

  public fun selectById(captureId: String): Query<SdkCaptureUpload> = selectById(captureId, ::SdkCaptureUpload)

  public fun <T : Any> selectAll(mapper: (
    captureId: String,
    userRef: String,
    subjectRef: String,
    conditionType: String?,
    captureGroup: String?,
    bodyLocationJson: String?,
    customJson: String?,
    deviceInfoJson: String?,
    encryptedPath: String,
    transferTaskId: String?,
    annotationPending: Long,
    captureMode: String?,
    createdAt: Long,
    updatedAt: Long,
    serverReleasedAt: Long?,
  ) -> T): Query<T> = Query(501_951_934, arrayOf("SdkCaptureUpload"), driver, "SdkCaptureUpload.sq", "selectAll", "SELECT SdkCaptureUpload.captureId, SdkCaptureUpload.userRef, SdkCaptureUpload.subjectRef, SdkCaptureUpload.conditionType, SdkCaptureUpload.captureGroup, SdkCaptureUpload.bodyLocationJson, SdkCaptureUpload.customJson, SdkCaptureUpload.deviceInfoJson, SdkCaptureUpload.encryptedPath, SdkCaptureUpload.transferTaskId, SdkCaptureUpload.annotationPending, SdkCaptureUpload.captureMode, SdkCaptureUpload.createdAt, SdkCaptureUpload.updatedAt, SdkCaptureUpload.serverReleasedAt FROM SdkCaptureUpload ORDER BY createdAt DESC") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5),
      cursor.getString(6),
      cursor.getString(7),
      cursor.getString(8)!!,
      cursor.getString(9),
      cursor.getLong(10)!!,
      cursor.getString(11),
      cursor.getLong(12)!!,
      cursor.getLong(13)!!,
      cursor.getLong(14)
    )
  }

  public fun selectAll(): Query<SdkCaptureUpload> = selectAll(::SdkCaptureUpload)

  public fun <T : Any> selectOrphans(mapper: (
    captureId: String,
    userRef: String,
    subjectRef: String,
    conditionType: String?,
    captureGroup: String?,
    bodyLocationJson: String?,
    customJson: String?,
    deviceInfoJson: String?,
    encryptedPath: String,
    transferTaskId: String?,
    annotationPending: Long,
    captureMode: String?,
    createdAt: Long,
    updatedAt: Long,
    serverReleasedAt: Long?,
  ) -> T): Query<T> = Query(-1_539_338_616, arrayOf("SdkCaptureUpload"), driver, "SdkCaptureUpload.sq", "selectOrphans", "SELECT SdkCaptureUpload.captureId, SdkCaptureUpload.userRef, SdkCaptureUpload.subjectRef, SdkCaptureUpload.conditionType, SdkCaptureUpload.captureGroup, SdkCaptureUpload.bodyLocationJson, SdkCaptureUpload.customJson, SdkCaptureUpload.deviceInfoJson, SdkCaptureUpload.encryptedPath, SdkCaptureUpload.transferTaskId, SdkCaptureUpload.annotationPending, SdkCaptureUpload.captureMode, SdkCaptureUpload.createdAt, SdkCaptureUpload.updatedAt, SdkCaptureUpload.serverReleasedAt FROM SdkCaptureUpload WHERE transferTaskId IS NULL") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5),
      cursor.getString(6),
      cursor.getString(7),
      cursor.getString(8)!!,
      cursor.getString(9),
      cursor.getLong(10)!!,
      cursor.getString(11),
      cursor.getLong(12)!!,
      cursor.getLong(13)!!,
      cursor.getLong(14)
    )
  }

  public fun selectOrphans(): Query<SdkCaptureUpload> = selectOrphans(::SdkCaptureUpload)

  public fun selectAnnotationPending(captureId: String): Query<Long> = SelectAnnotationPendingQuery(captureId) { cursor ->
    cursor.getLong(0)!!
  }

  public fun <T : Any> selectUnreleased(mapper: (
    captureId: String,
    userRef: String,
    subjectRef: String,
    conditionType: String?,
    captureGroup: String?,
    bodyLocationJson: String?,
    customJson: String?,
    deviceInfoJson: String?,
    encryptedPath: String,
    transferTaskId: String?,
    annotationPending: Long,
    captureMode: String?,
    createdAt: Long,
    updatedAt: Long,
    serverReleasedAt: Long?,
  ) -> T): Query<T> = Query(1_814_175_769, arrayOf("SdkCaptureUpload"), driver, "SdkCaptureUpload.sq", "selectUnreleased", "SELECT SdkCaptureUpload.captureId, SdkCaptureUpload.userRef, SdkCaptureUpload.subjectRef, SdkCaptureUpload.conditionType, SdkCaptureUpload.captureGroup, SdkCaptureUpload.bodyLocationJson, SdkCaptureUpload.customJson, SdkCaptureUpload.deviceInfoJson, SdkCaptureUpload.encryptedPath, SdkCaptureUpload.transferTaskId, SdkCaptureUpload.annotationPending, SdkCaptureUpload.captureMode, SdkCaptureUpload.createdAt, SdkCaptureUpload.updatedAt, SdkCaptureUpload.serverReleasedAt FROM SdkCaptureUpload WHERE serverReleasedAt IS NULL") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3),
      cursor.getString(4),
      cursor.getString(5),
      cursor.getString(6),
      cursor.getString(7),
      cursor.getString(8)!!,
      cursor.getString(9),
      cursor.getLong(10)!!,
      cursor.getString(11),
      cursor.getLong(12)!!,
      cursor.getLong(13)!!,
      cursor.getLong(14)
    )
  }

  public fun selectUnreleased(): Query<SdkCaptureUpload> = selectUnreleased(::SdkCaptureUpload)

  /**
   * @return The number of rows updated.
   */
  public fun insert(
    captureId: String,
    userRef: String,
    subjectRef: String,
    conditionType: String?,
    captureGroup: String?,
    bodyLocationJson: String?,
    customJson: String?,
    deviceInfoJson: String?,
    encryptedPath: String,
    transferTaskId: String?,
    annotationPending: Long,
    captureMode: String?,
    createdAt: Long,
    updatedAt: Long,
  ): QueryResult<Long> {
    val result = driver.execute(1_294_996_128, """
        |INSERT INTO SdkCaptureUpload (captureId, userRef, subjectRef, conditionType, captureGroup, bodyLocationJson, customJson, deviceInfoJson, encryptedPath, transferTaskId, annotationPending, captureMode, createdAt, updatedAt)
        |VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """.trimMargin(), 14) {
          var parameterIndex = 0
          bindString(parameterIndex++, captureId)
          bindString(parameterIndex++, userRef)
          bindString(parameterIndex++, subjectRef)
          bindString(parameterIndex++, conditionType)
          bindString(parameterIndex++, captureGroup)
          bindString(parameterIndex++, bodyLocationJson)
          bindString(parameterIndex++, customJson)
          bindString(parameterIndex++, deviceInfoJson)
          bindString(parameterIndex++, encryptedPath)
          bindString(parameterIndex++, transferTaskId)
          bindLong(parameterIndex++, annotationPending)
          bindString(parameterIndex++, captureMode)
          bindLong(parameterIndex++, createdAt)
          bindLong(parameterIndex++, updatedAt)
        }
    notifyQueries(1_294_996_128) { emit ->
      emit("SdkCaptureUpload")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateTransferTaskId(
    transferTaskId: String?,
    updatedAt: Long,
    captureId: String,
  ): QueryResult<Long> {
    val result = driver.execute(1_711_348_251, """UPDATE SdkCaptureUpload SET transferTaskId = ?, updatedAt = ? WHERE captureId = ?""", 3) {
          var parameterIndex = 0
          bindString(parameterIndex++, transferTaskId)
          bindLong(parameterIndex++, updatedAt)
          bindString(parameterIndex++, captureId)
        }
    notifyQueries(1_711_348_251) { emit ->
      emit("SdkCaptureUpload")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateAnnotationPending(
    annotationPending: Long,
    updatedAt: Long,
    captureId: String,
  ): QueryResult<Long> {
    val result = driver.execute(-634_175_336, """UPDATE SdkCaptureUpload SET annotationPending = ?, updatedAt = ? WHERE captureId = ?""", 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, annotationPending)
          bindLong(parameterIndex++, updatedAt)
          bindString(parameterIndex++, captureId)
        }
    notifyQueries(-634_175_336) { emit ->
      emit("SdkCaptureUpload")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteById(captureId: String): QueryResult<Long> {
    val result = driver.execute(1_801_227_396, """DELETE FROM SdkCaptureUpload WHERE captureId = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, captureId)
        }
    notifyQueries(1_801_227_396) { emit ->
      emit("SdkCaptureUpload")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun updateServerReleasedAt(
    serverReleasedAt: Long?,
    updatedAt: Long,
    captureId: String,
  ): QueryResult<Long> {
    val result = driver.execute(1_154_418_371, """UPDATE SdkCaptureUpload SET serverReleasedAt = ?, updatedAt = ? WHERE captureId = ?""", 3) {
          var parameterIndex = 0
          bindLong(parameterIndex++, serverReleasedAt)
          bindLong(parameterIndex++, updatedAt)
          bindString(parameterIndex++, captureId)
        }
    notifyQueries(1_154_418_371) { emit ->
      emit("SdkCaptureUpload")
    }
    return result
  }

  private inner class SelectByIdQuery<out T : Any>(
    public val captureId: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SdkCaptureUpload", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SdkCaptureUpload", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(-1_619_317_931, """SELECT SdkCaptureUpload.captureId, SdkCaptureUpload.userRef, SdkCaptureUpload.subjectRef, SdkCaptureUpload.conditionType, SdkCaptureUpload.captureGroup, SdkCaptureUpload.bodyLocationJson, SdkCaptureUpload.customJson, SdkCaptureUpload.deviceInfoJson, SdkCaptureUpload.encryptedPath, SdkCaptureUpload.transferTaskId, SdkCaptureUpload.annotationPending, SdkCaptureUpload.captureMode, SdkCaptureUpload.createdAt, SdkCaptureUpload.updatedAt, SdkCaptureUpload.serverReleasedAt FROM SdkCaptureUpload WHERE captureId = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, captureId)
    }

    override fun toString(): String = "SdkCaptureUpload.sq:selectById"
  }

  private inner class SelectAnnotationPendingQuery<out T : Any>(
    public val captureId: String,
    mapper: (SqlCursor) -> T,
  ) : Query<T>(mapper) {
    override fun addListener(listener: Query.Listener) {
      driver.addListener("SdkCaptureUpload", listener = listener)
    }

    override fun removeListener(listener: Query.Listener) {
      driver.removeListener("SdkCaptureUpload", listener = listener)
    }

    override fun <R> execute(mapper: (SqlCursor) -> QueryResult<R>): QueryResult<R> = driver.executeQuery(1_570_492_613, """SELECT annotationPending FROM SdkCaptureUpload WHERE captureId = ?""", mapper, 1) {
      var parameterIndex = 0
      bindString(parameterIndex++, captureId)
    }

    override fun toString(): String = "SdkCaptureUpload.sq:selectAnnotationPending"
  }
}
