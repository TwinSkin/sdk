package com.twinskin.sdk.db

import app.cash.sqldelight.Query
import app.cash.sqldelight.TransacterImpl
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import kotlin.Any
import kotlin.Long
import kotlin.String

public class UploadDiagnosticQueries(
  driver: SqlDriver,
) : TransacterImpl(driver) {
  public fun <T : Any> pending(mapper: (
    id: String,
    captureId: String,
    subjectRef: String,
    userRef: String,
    payload: String,
    sent: Long,
    lastAttemptAt: Long,
  ) -> T): Query<T> = Query(-1_127_431_691, arrayOf("UploadDiagnostic"), driver, "UploadDiagnostic.sq", "pending", "SELECT UploadDiagnostic.id, UploadDiagnostic.captureId, UploadDiagnostic.subjectRef, UploadDiagnostic.userRef, UploadDiagnostic.payload, UploadDiagnostic.sent, UploadDiagnostic.lastAttemptAt FROM UploadDiagnostic WHERE sent = 0 ORDER BY lastAttemptAt, rowid LIMIT 100") { cursor ->
    mapper(
      cursor.getString(0)!!,
      cursor.getString(1)!!,
      cursor.getString(2)!!,
      cursor.getString(3)!!,
      cursor.getString(4)!!,
      cursor.getLong(5)!!,
      cursor.getLong(6)!!
    )
  }

  public fun pending(): Query<UploadDiagnostic> = pending(::UploadDiagnostic)

  public fun countAll(): Query<Long> = Query(-1_277_315_724, arrayOf("UploadDiagnostic"), driver, "UploadDiagnostic.sq", "countAll", "SELECT COUNT(*) FROM UploadDiagnostic") { cursor ->
    cursor.getLong(0)!!
  }

  /**
   * @return The number of rows updated.
   */
  public fun insert(
    id: String,
    captureId: String,
    subjectRef: String,
    userRef: String,
    payload: String,
  ): QueryResult<Long> {
    val result = driver.execute(1_434_257_051, """INSERT INTO UploadDiagnostic(id, captureId, subjectRef, userRef, payload) VALUES (?, ?, ?, ?, ?)""", 5) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
          bindString(parameterIndex++, captureId)
          bindString(parameterIndex++, subjectRef)
          bindString(parameterIndex++, userRef)
          bindString(parameterIndex++, payload)
        }
    notifyQueries(1_434_257_051) { emit ->
      emit("UploadDiagnostic")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun acknowledge(id: String): QueryResult<Long> {
    val result = driver.execute(557_628_410, """DELETE FROM UploadDiagnostic WHERE id = ?""", 1) {
          var parameterIndex = 0
          bindString(parameterIndex++, id)
        }
    notifyQueries(557_628_410) { emit ->
      emit("UploadDiagnostic")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun deleteAcknowledged(): QueryResult<Long> {
    val result = driver.execute(672_113_525, """DELETE FROM UploadDiagnostic WHERE sent = 1""", 0)
    notifyQueries(672_113_525) { emit ->
      emit("UploadDiagnostic")
    }
    return result
  }

  /**
   * @return The number of rows updated.
   */
  public fun defer(lastAttemptAt: Long, id: String): QueryResult<Long> {
    val result = driver.execute(318_462_800, """UPDATE UploadDiagnostic SET lastAttemptAt = ? WHERE id = ?""", 2) {
          var parameterIndex = 0
          bindLong(parameterIndex++, lastAttemptAt)
          bindString(parameterIndex++, id)
        }
    notifyQueries(318_462_800) { emit ->
      emit("UploadDiagnostic")
    }
    return result
  }
}
