package com.twinskin.sdk.transfer

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.warn

internal sealed class WorkerOutcome {
    object Success : WorkerOutcome()
    data class Failure(val reason: String) : WorkerOutcome()
    object Retry : WorkerOutcome()
}

/**
 * Orchestrates one upload attempt for the worker / background handler:
 * (1) try the cached presigned URL via [CachedUrlUploader]; (2) on
 * [CachedUploadOutcome.NeedsRefresh], call the optional [refresh] hook
 * (only available when the SDK is initialized) to mint a fresh URL,
 * persist it on the row, and re-attempt the PUT. Returns a single
 * [WorkerOutcome] the caller maps to platform-specific result codes
 * (WorkManager Result.{success,failure,retry} on Android; URLSession
 * task completion on iOS).
 */
internal class UploadAttemptRunner(
    private val database: TwinSkinDatabase,
    private val cachedUploader: CachedUrlUploader,
    private val refresh: (suspend (taskId: String, uploadKey: String) -> UrlResult)?,
    private val clock: () -> Long,
    private val logger: SdkLogger,
) {
    suspend fun run(
        taskId: String,
        uploadKey: String,
        onProgress: suspend (Long, Long) -> Unit,
    ): WorkerOutcome {
        return when (val outcome = cachedUploader.attempt(taskId, onProgress)) {
            CachedUploadOutcome.Done -> WorkerOutcome.Success
            is CachedUploadOutcome.PermanentFailure -> WorkerOutcome.Failure(outcome.reason)
            CachedUploadOutcome.RetryLater -> WorkerOutcome.Retry
            CachedUploadOutcome.NeedsRefresh -> {
                val refresher = refresh
                if (refresher == null) {
                    logger.warn("UploadAttemptRunner[$taskId] needs refresh but SDK not initialized — Retry")
                    return WorkerOutcome.Retry
                }
                when (val resolved = refresher(taskId, uploadKey)) {
                    is UrlResult.Url -> {
                        // The server is expected to include `upload_url_expires_at`;
                        // older / mis-deployed servers omit it, leaving expiresAt NULL.
                        // Without a value, CachedUrlUploader classifies the row as
                        // NeedsRefresh again and the runner falls into the `else -> Retry`
                        // branch below — a silent infinite loop with exponential backoff
                        // and no progress visible to anyone. Fall back to a short
                        // conservative window so the second attempt actually PUTs, and
                        // log loudly so the server-side misconfiguration is diagnosable.
                        val expiresAtEpochMs = resolved.expiresAtEpochMs ?: run {
                            logger.warn(
                                "UploadAttemptRunner[$taskId] resolver returned URL with no expiresAt — " +
                                    "server may be missing the upload_url_expires_at field; " +
                                    "using ${RESOLVED_TTL_FALLBACK_MS / 60_000} min fallback",
                            )
                            clock() + RESOLVED_TTL_FALLBACK_MS
                        }
                        database.transferTaskQueries.updatePresignedUrl(
                            presignedUrl = resolved.url,
                            presignedUrlExpiresAt = expiresAtEpochMs,
                            updatedAt = clock(),
                            id = taskId,
                        )
                        when (val second = cachedUploader.attempt(taskId, onProgress)) {
                            CachedUploadOutcome.Done -> WorkerOutcome.Success
                            is CachedUploadOutcome.PermanentFailure -> WorkerOutcome.Failure(second.reason)
                            else -> WorkerOutcome.Retry
                        }
                    }
                    UrlResult.AlreadyExist -> {
                        UploadDiagnostics(database).record(taskId, "already_received")
                        // The bundle stays until the server releases it: AlreadyExist also
                        // answers for a capture the server failed before its upload landed.
                        database.transferTaskQueries.updateStatus(TransferStatus.COMPLETED.name, clock(), taskId)
                        WorkerOutcome.Success
                    }
                    UrlResult.RetryableError -> {
                        UploadDiagnostics(database).record(taskId, "url_retry")
                        WorkerOutcome.Retry
                    }
                }
            }
        }
    }

    private companion object {
        const val RESOLVED_TTL_FALLBACK_MS = 30L * 60L * 1000L
    }
}
