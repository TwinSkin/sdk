package com.twinskin.sdk.capture

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.capture.io.fileSize
import com.twinskin.sdk.db.TransferTask
import com.twinskin.sdk.info
import com.twinskin.sdk.sdk_client.ConfirmBundleRequest
import com.twinskin.sdk.sdk_client.SdkServerClient
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.storage.SdkStorage
import com.twinskin.sdk.transfer.TransferManager
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.TransferType
import com.twinskin.sdk.transfer.fileExists
import com.twinskin.sdk.warn
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes
import kotlin.time.Duration.Companion.seconds

/**
 * Asks the server, for every upload that finished on this device, whether the
 * bundle may be deleted, and records the answer on the [SdkCaptureStore] row.
 *
 * The PUT's own 2xx is not evidence: on 2026-09-20 a rejected PUT was recorded
 * as a success and the only copy of the capture was deleted (rimbaud!4414).
 * The server releases a bundle once S3 holds it and the decrypt step has read
 * it; anything else is a hold and the file stays.
 *
 * [run] suspends forever. It confirms what is pending, then waits for the next
 * finished upload; while a hold or a failed call leaves rows unconfirmed it
 * retries with a doubling delay instead.
 *
 * [bundleSizeBytes] takes the bundle's file name, not its stored path: that
 * path is absolute and iOS moves the app container between installs, so a
 * lookup by path would call a moved bundle gone and release it unconfirmed.
 */
internal class BundleReleaseConfirmer(
    private val store: SdkCaptureStore,
    private val serverClient: SdkServerClient,
    private val transferManager: TransferManager,
    private val bundleSizeBytes: (fileName: String) -> Long?,
    private val logger: SdkLogger = SdkLogger.None,
    private val initialRetryDelay: Duration = 30.seconds,
    private val maxRetryDelay: Duration = 15.minutes,
) {
    /** Confirms every awaiting upload once. Returns how many are still unreleased. */
    suspend fun confirmOnce(): Int {
        var unreleased = 0
        for (record in store.findAwaitingServerRelease()) {
            val released = try {
                confirm(record)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                logger.warn("confirmBundle failed for ${record.captureId}; keeping the bundle", e)
                false
            }
            if (!released) unreleased++
        }
        return unreleased
    }

    private suspend fun confirm(record: SdkCaptureUploadRecord): Boolean {
        val size = bundleSizeBytes(record.encryptedPath.substringAfterLast('/'))
        if (size == null) {
            logger.warn("Bundle for ${record.captureId} is already gone; nothing left to keep")
            store.markServerReleased(record.captureId)
            return true
        }
        val response = serverClient.confirmBundle(
            ConfirmBundleRequest(
                userRef = record.request.userRef,
                subjectRef = record.request.subjectRef,
                captureId = record.captureId,
                bundleSizeBytes = size,
            ),
        )
        if (!response.released) {
            logger.info("Server holds the bundle for ${record.captureId}: ${response.holdReason}")
            return false
        }
        store.markServerReleased(record.captureId)
        logger.info("Server released the bundle for ${record.captureId}")
        return true
    }

    suspend fun run(): Nothing {
        var retryDelay = initialRetryDelay
        while (true) {
            val seen = transferManager.observeAllTasks().value.completedUploadIds()
            if (confirmOnce() == 0) {
                retryDelay = initialRetryDelay
                awaitNewCompletedUpload(seen)
            } else {
                withTimeoutOrNull(retryDelay) { awaitNewCompletedUpload(seen) }
                retryDelay = (retryDelay * 2).coerceAtMost(maxRetryDelay)
            }
        }
    }

    // Compared against a snapshot taken before confirmOnce, so an upload that
    // finishes during the confirm round is not missed.
    private suspend fun awaitNewCompletedUpload(seen: Set<String>) {
        transferManager.observeAllTasks().first { it.completedUploadIds() != seen }
    }

    private fun List<TransferTask>.completedUploadIds(): Set<String> =
        asSequence()
            .filter { it.type == TransferType.UPLOAD.name && it.status == TransferStatus.COMPLETED.name }
            .map { it.id }
            .toSet()
}

/** Size of the named bundle in [storage]'s current bundles directory, or null when absent. */
internal fun bundleSizeIn(storage: SdkStorage): (fileName: String) -> Long? = { fileName ->
    val path = "${storage.dir(Purpose.EncryptedBundles)}/$fileName"
    if (fileExists(path)) fileSize(path) else null
}
