package com.twinskin.sdk.capture

import com.twinskin.sdk.SdkLogger
import com.twinskin.sdk.db.TransferTask
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.storage.Purpose
import com.twinskin.sdk.storage.SdkStorage
import com.twinskin.sdk.transfer.TransferManager
import com.twinskin.sdk.transfer.TransferStatus
import com.twinskin.sdk.transfer.TransferType
import com.twinskin.sdk.warn
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.combine

/**
 * Delete the [Purpose.EncryptedBundles] files of uploads the user cancelled and
 * of finished uploads the server has released ([releasedBundleNames], from
 * [SdkCaptureStore]). A COMPLETED task by itself deletes nothing: it is the
 * phone's reading of one PUT, and on 2026-09-20 that reading was wrong.
 *
 * A file is deleted on the evidence of its row, never on the absence of one.
 * [CaptureApi] creates the bundle, encrypts into it for seconds, and only then
 * inserts the row; a list that names no owner for a file proves nothing about it.
 * Row-less leftovers are [sweepLeftoverBundles]'s job.
 */
internal fun pruneBundles(
    storage: SdkStorage,
    tasks: List<TransferTask>,
    releasedBundleNames: Set<String>,
    logger: SdkLogger,
) {
    val released = tasks.bundleNames(TransferStatus.COMPLETED) intersect releasedBundleNames
    val finished = released + tasks.bundleNames(TransferStatus.CANCELLED)
    if (finished.isEmpty()) return
    storage.wipe(Purpose.EncryptedBundles, logger) { name -> name in finished }
}

/**
 * Delete every [Purpose.EncryptedBundles] file no capture can still need: what a
 * crash left half-written, and bundles whose rows are gone or released.
 *
 * Only sound while nothing can be writing a bundle, so `TwinSkinSdk.initialize`
 * calls it before it installs the component that starts captures.
 *
 * [retainedBundlePaths] are the bundles of every capture the server has not
 * released ([SdkCaptureStore.retainedBundlePaths]): waiting for a transfer
 * ([CaptureApi.recover] re-enqueues those from the same file), uploading, or
 * uploaded and awaiting the server's word. Bundles are matched by file name:
 * those paths are stored absolute, and iOS moves the app container between
 * installs.
 */
internal fun sweepLeftoverBundles(
    storage: SdkStorage,
    tasks: List<TransferTask>,
    retainedBundlePaths: List<String>,
    logger: SdkLogger,
) {
    val needed = tasks.bundleNames(
        TransferStatus.PENDING,
        TransferStatus.ACTIVE,
        TransferStatus.FAILED,
    ) + retainedBundlePaths.map { it.fileName() }
    storage.wipe(Purpose.EncryptedBundles, logger) { name -> name !in needed }
}

/**
 * [sweepLeftoverBundles] against the database as it stands. Never throws: a
 * cleanup must not break `initialize`.
 */
internal fun sweepLeftoverBundles(
    storage: SdkStorage,
    database: TwinSkinDatabase,
    logger: SdkLogger,
) {
    runCatching {
        sweepLeftoverBundles(
            storage = storage,
            tasks = database.transferTaskQueries.selectAll().executeAsList(),
            retainedBundlePaths = SdkCaptureStore(database).retainedBundlePaths(),
            logger = logger,
        )
    }.onFailure { logger.warn("SdkStorage: leftover bundle sweep failed", it) }
}

/**
 * Re-run [pruneBundles] on every change to the task table or the upload rows,
 * so a bundle is reclaimed as soon as the server releases it — including
 * uploads a background worker finished while the app was dead, which show up
 * in the first database read.
 *
 * Suspends forever; call from a long-lived coroutine.
 */
internal suspend fun observeAndPruneBundles(
    storage: SdkStorage,
    transferManager: TransferManager,
    store: SdkCaptureStore,
    logger: SdkLogger,
) {
    combine(transferManager.observeAllTasks(), store.observeAll()) { tasks, records ->
        val released = records.asSequence()
            .filter { it.serverReleasedAtEpochMs != null }
            .map { it.encryptedPath.fileName() }
            .toSet()
        tasks to released
    }.collect { (tasks, released) ->
        pruneBundles(storage, tasks, released, logger)
    }
}

private fun List<TransferTask>.bundleNames(vararg statuses: TransferStatus): Set<String> {
    val names = statuses.map { it.name }
    return asSequence()
        .filter { it.type == TransferType.UPLOAD.name && it.status in names }
        .map { it.localPath.fileName() }
        .toSet()
}

private fun String.fileName(): String = substringAfterLast('/')
