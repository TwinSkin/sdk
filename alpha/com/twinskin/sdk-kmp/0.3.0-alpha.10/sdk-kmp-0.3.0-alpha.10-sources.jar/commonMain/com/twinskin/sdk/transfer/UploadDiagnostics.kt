package com.twinskin.sdk.transfer

import com.twinskin.sdk.capture.crypto.secureRandomBytes
import com.twinskin.sdk.db.TwinSkinDatabase
import com.twinskin.sdk.sdk_client.SdkServerClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

internal class UploadDiagnostics(private val database: TwinSkinDatabase) {
    fun record(taskId: String, kind: String, attemptId: String = taskId, outcome: String? = null) {
        try {
            val task = database.transferTaskQueries.selectById(taskId).executeAsOneOrNull() ?: return
            if (task.type != TransferType.UPLOAD.name) return
            val capture = database.sdkCaptureUploadQueries.selectById(task.url).executeAsOneOrNull() ?: return
            val id = ByteArray(16).also { secureRandomBytes(it) }.joinToString("") { (it.toInt() and 255).toString(16).padStart(2, '0') }
            val payload = JsonObject(buildMap {
                put("schemaVersion", JsonPrimitive(1))
                put("id", JsonPrimitive(id))
                put("attemptId", JsonPrimitive(attemptId))
                put("kind", JsonPrimitive(kind))
                put("atEpochMs", JsonPrimitive(currentTimeMillis()))
                outcome?.let { put("outcome", JsonPrimitive(it)) }
            }).toString()
            database.uploadDiagnosticQueries.insert(id, capture.captureId, capture.subjectRef, capture.userRef, payload)
        } catch (_: Exception) {
            // Diagnostic storage must not change transfer success or retry decisions.
        }
    }

    internal suspend fun flush(send: suspend (String, String, String, String) -> Unit) {
        database.uploadDiagnosticQueries.deleteAcknowledged()
        for (event in database.uploadDiagnosticQueries.pending().executeAsList()) {
            try {
                send(event.captureId, event.subjectRef, event.userRef, event.payload)
                database.uploadDiagnosticQueries.acknowledge(event.id)
            } catch (error: CancellationException) {
                throw error
            } catch (_: Exception) {
                database.uploadDiagnosticQueries.defer(currentTimeMillis(), event.id)
            }
        }
    }

    fun publishIn(scope: CoroutineScope, client: SdkServerClient) = scope.launch {
        while (true) {
            try {
                flush(client::recordUploadDiagnostic)
            } catch (error: CancellationException) {
                throw error
            } catch (_: Exception) {
                // Keep the outbox intact across offline periods and older server deployments.
            }
            delay(30_000)
        }
    }
}
